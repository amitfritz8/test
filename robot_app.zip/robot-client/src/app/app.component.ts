import { Component } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { FormGroup, FormControl, Validators } from "@angular/forms";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  script = "";
  title = "robot-client";
  error = false;
  showTrace = false;
  isshow = false;
  numbers = [0, 1, 2, 3, 4, 5];
  errorMessage: string;
  urlBase = "http://localhost:8081";
  robotPosition: any = {};
  pathTrace = [];
  scriptForm = new FormGroup({
    script: new FormControl("", [Validators.required])
  });
  constructor(private http: HttpClient) {}
  ngOnInit() {
    this.drawRobot(null);
  }
  onChange(value){
	if (value.target.value.trim().length == 0) {
		this.error = false;
	}  
  }
  placeRobot() {
    this.http
      .post(
        this.urlBase + "/robot/script/execute",
        this.scriptForm.controls.script.value
      )
      .subscribe(
        response => {
          if (response !== null && response !== undefined) {
            this.robotPosition = response;
            this.error = false;
            this.showTrace = true;
            this.pathTrace = this.robotPosition.pathTrace;
            this.drawRobot(this.robotPosition);
          }
        },
        response => {
          this.error = true;
          this.showTrace = false;
		  this.drawRobot(null);
		  if(response.error.message===undefined){
			this.errorMessage = response.statusText + " or Server is unreachable.";
		  }else{
			this.errorMessage = response.error.message;
		  }
        }
      );
  }
  drawRobot(robot) {
    var canvas: HTMLCanvasElement = <HTMLCanvasElement>(
      document.getElementById("robotCanvas")
    );
    var ctx: CanvasRenderingContext2D = canvas.getContext("2d");
    ctx.clearRect(0, 0, 360, 360);
    ctx.fillStyle = "#b81717";
    let w = 360;
    let h = 360;
    ctx.strokeStyle = "#2196F3";
    ctx.lineWidth = 2;
    for (let x = 0; x <= w; x += 60) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      for (let y = 0; y <= h; y += 60) {
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
      }
    }
    ctx.stroke();
    if (!this.error) {
      ctx.fillRect(robot.x * 60, robot.y * 60, 60, 60);
      ctx.fillStyle = "blue";
      if (robot.facing === "EAST") {
        ctx.fillRect((robot.x + 1) * 60 - 10, (robot.y + 1) * 60 - 35, 10, 10);
      } else if (robot.facing === "WEST") {
        ctx.fillRect((robot.x + 1) * 60 - 60, (robot.y + 1) * 60 - 35, 10, 10);
      } else if (robot.facing === "NORTH") {
        ctx.fillRect((robot.x + 1) * 60 - 35, (robot.y + 1) * 60 - 60, 10, 10);
      } else if (robot.facing === "SOUTH") {
        ctx.fillRect((robot.x + 1) * 60 - 35, (robot.y + 1) * 60 - 10, 10, 10);
      }
    }
  }
}
