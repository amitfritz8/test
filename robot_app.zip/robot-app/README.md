# Application: Robot Navigator Game.

## Technical Details:

Backend: Java 8.1, Maven(3.8.1) and Spring Boot(2.2.5)
Frontend: Angular CLI: 6.2.9, Node: 8.12.0 and Angular: 6.1.10 

## Code problem details:

Develop a simple environment for a robot where you could control it using this predefined script:

POSITION 1 3 EAST //sets the initial position for the robot as x, y.
FORWARD 3 //lets the robot do 3 steps forward
WAIT //lets the robot do nothing
TURNAROUND //lets the robot turn around
FORWARD 1 //lets the robot do 1 step forward
RIGHT //lets the robot turn right
FORWARD 2 //lets the robot do 2 steps forward

This script should be sent as it is from a frontend to a backend as a single chunk using a POST Method. After the script execution, UI should render a new robot position on the grid and a direction it looks to.

Please implement a movement/business logic using Java+Spring in backend. Frontend should be only responsible for submitting the script and rendering robot on the grid.

For aesthetic reasons you should limit the grid in the Frontend for the robot to 5 x 5 steps. The initial grid position is 0,0 and is in the top left corner.
It is optional, if the backend will be also aware of the grid limits

## Zip file description 
 1. robot-client ->  Angular 6 client application
 2. robot-app -> Spring Boot Java Application
 3. robot-app-0.0.1.jar -> to run the application (including packaged UI)directly on http://localhost:8081 [java -jar robot-app-0.0.1.jar]

## How to play the Games Instantly with java installed in the System.

Step 1. Open the zip file "robot_app_idealo.zip".
Step 2. Please make sure JAVA 8 or higher installed in the System.
Step 3. Go to the extracted path and run in the command line 
         "java -jar robot-app-0.0.1.jar"
Step 4. Done:) Start playing the game opening the URL: http://localhost:8081. Example below.

#e.g.
Enter the following script and robot's final position will be shown in the UI and furthermore we can write the more commands in script to navigate the robot in different direction.
Always starts from POSITION command at the top and play the Game.

POSITION 1 3 EAST
FORWARD 3
WAIT
TURNAROUND
FORWARD 1
RIGHT
FORWARD 2


## How to build and run from Spring Boot Application alone.

Step 1. Go to root folder of project "robot-app" and make sure Maven 3.x and JAVA 8.x or higher version installed.
 
Step 1. run in command line ->  mvn clean install

Step 2. After successfull build, this is packaged as a "robot-app-0.0.1.jar" under "robot-app/target" folder. 

Step 3. run in command line -  "java -jar target/robot-app-0.0.1.jar"

Step 4. I have already packaged the UI build in JAVA Spring Boot(under src/main/resources/static). So nothing to do unless want to do some changes in the UI. If some changes has to be done then please follow the instructions below down the line separately to update the package.

Step 4. Open the browser and go to http://localhost:8081
Step 5. Enter script and Play Games. Done Thanks :)


##If any changes are done in the angular application. These are the below steps to build the Angular and copy the build file in the Spring Boot application static resources so that updated UI will also run within Spring Boot application.

Step 1. Please make sure NodeJS is installed in the system.
Step 2. Go to robot-client folder.
Step 3. run in command line -> npm install. It will install all the dependencies.
Step 4. run in command line -> npm run build. It will execute and build all the UI artifacts and copy the arficates(using copyfiles package of NPM) in the static resources of Spring Boot Java application.
Step 4. Build the spring boot Jar and run the Jar as previously mentioned above.

## How to run Angular Client and Spring Boot Application separately and Play the Game.

To run Java Spring Boot Application

Step 1: First start the JAVA Spring Boot application. It will run in port 8081. It can be changed using the server.port properties.
Please follow the same procedure mentioned above to start the JAVA application.

To start Angular Client Application

Step 1. Please make sure NodeJS is installed in the system.
Step 2. Go to robot-client folder
Step 3. run in command line -> npm install
Step 4. run in command line -> npm run build
Step 5. run in command line -> npm run start
Step 6. It will start the Angular client server.
Step 7. Go to the URL http://localhost:4200/

Step 8. Done Thanks:) Play the Game.









