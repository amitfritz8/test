package com.idealo.robot.app.processor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.idealo.robot.app.constant.AppConstant;
import com.idealo.robot.app.constant.Command;
import com.idealo.robot.app.model.Robot;
import com.idealo.robot.app.navigator.RobotNavigatorImpl;

/**
 * 
 * @author amit
 * This class is responsible for validating and processing the script.
 */

@Component
public class ScriptProcessor {

	@Autowired
	RobotNavigatorImpl robotNavigator;
	Robot robot = null;

	public Robot processScript(String script) throws Exception {
		String[] ary = script.trim().split("\\n");
		if (ary[0]!=null && 
				!ary[0].trim().contains(Command.POSITION.toString())) {
			throw new Exception(AppConstant.INVALID_POSTION_SCRIPT_MSG);
		}
		for (String str : ary) {
			String[] commands = null;
			if(!str.isEmpty()) {
				commands = str.trim().split("\\s+");
				validateAndBuild(commands);
			}
		}
		return robot;
	}

	private Robot validateAndBuild(String[] commands) throws Exception {

		if (commands != null && commands.length > 0) {
			 if (commands[0].equals(Command.POSITION.toString())) {
				if (commands.length != 4) {
					throw new IllegalArgumentException(
							String.format(AppConstant.INVALID_POSITION_SCRIPT_PARAM, commands[0]));
				} else {
					try {
						robot = robotNavigator.positionRobot(Integer.parseInt(commands[1]),
								Integer.parseInt(commands[2]), commands[3]);
					} catch (NumberFormatException e) {
						throw new NumberFormatException(AppConstant.INVALID_SCRIPT + commands[0] + " " + commands[1]
								+ " " + commands[2] + " " + commands[3]);
					}

				}
			} else if (commands[0].equals(Command.FORWARD.toString())) {
				if (commands.length != 2) {
					throw new IllegalArgumentException(
							String.format(AppConstant.INVALID_FORWARD_SCRIPT_PARAM, commands[0]));
				} else {
					try {
						robot = robotNavigator.moveForward(Integer.parseInt(commands[1]), robot);
					} catch (NumberFormatException e) {
						throw new NumberFormatException(AppConstant.INVALID_SCRIPT + commands[0] + " " + commands[1]);
					}
				}
			} else if (commands[0].equals(Command.RIGHT.toString())) {
				if (commands.length > 1) {
					throw new IllegalArgumentException(AppConstant.INVALID_SCRIPT + commands[0]);
				} else {
					robot = robotNavigator.rotate(commands[0], robot);
				}
			} else if (commands[0].equals(Command.LEFT.toString())) {
				if (commands.length > 1) {
					throw new IllegalArgumentException(AppConstant.INVALID_SCRIPT + commands[0]);
				} else {
					robot = robotNavigator.rotate(commands[0], robot);
				}
			} else if (commands[0].equals(Command.TURNAROUND.toString())) {
				if (commands.length > 1) {
					throw new IllegalArgumentException(AppConstant.INVALID_SCRIPT + commands[0]);
				} else {
					robot = robotNavigator.rotate(commands[0], robot);
				}
			} else if (commands[0].equals(Command.WAIT.toString())) {
				if (commands.length > 1) {
					throw new IllegalArgumentException(AppConstant.INVALID_SCRIPT + commands[0]);
				} else {
					robotNavigator.waiting(robot);
				}
			} else {
				throw new Exception(AppConstant.INVALID_SCRIPT + commands[0]);
			}
		} else {
			throw new Exception(AppConstant.INVALID_SCRIPT);
		}

		return robot;
	}

}
