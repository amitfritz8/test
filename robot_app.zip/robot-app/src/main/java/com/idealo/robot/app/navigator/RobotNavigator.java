package com.idealo.robot.app.navigator;

import com.idealo.robot.app.model.Robot;

public interface RobotNavigator {
	
	Robot positionRobot(int x, int y, String facing) throws Exception;
	
	Robot moveForward(int steps, Robot robot) throws Exception;
	
	Robot rotate(String rotate, Robot robot) throws Exception;
	
	void waiting(Robot robot);

}
