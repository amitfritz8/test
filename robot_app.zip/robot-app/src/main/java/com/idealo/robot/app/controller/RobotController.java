package com.idealo.robot.app.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.idealo.robot.app.constant.AppConstant;
import com.idealo.robot.app.model.Robot;
import com.idealo.robot.app.processor.ScriptProcessor;


@RestController
@RequestMapping("/robot")
@CrossOrigin
public class RobotController {

	@Autowired
	ScriptProcessor scriptProcessor;
	
	@PostMapping(value="/script/execute")
	public Robot execute(@RequestBody String script) throws Exception {
		if(script!=null && !script.isEmpty()) {
			return scriptProcessor.processScript(script);
		}else {
			throw new Exception(AppConstant.INVALID_SCRIPT);
		}
	}
}
