package com.idealo.robot.app.navigator;

import org.springframework.stereotype.Component;

import com.idealo.robot.app.constant.AppConstant;
import com.idealo.robot.app.constant.Command;
import com.idealo.robot.app.model.Robot;
/**
 * 
 * @author amit
 * RobotNavigatorImpl controls the robot movement.
 */
@Component
public class RobotNavigatorImpl implements RobotNavigator{

	@Override
    public Robot positionRobot(int x, int y, String facing) throws Exception {
		FacingMovement newFacing = null;
		try {
			newFacing = FacingMovement.valueOf(facing);
		} catch (IllegalArgumentException ex) { 
			throw new IllegalArgumentException(AppConstant.FACING_PARAM_ERROR_MSG + FacingMovement.getAllFacingAsString());
		}
		if(x < FacingMovement.X_MIN || x > FacingMovement.X_MAX || y < FacingMovement.Y_MIN || y > FacingMovement.Y_MAX) {
        	throw new IllegalArgumentException(String.format(AppConstant.GRID_RANGE_ERROR_MESSAGE, Command.POSITION));
        }
        Robot robot = new Robot(x, y , newFacing.name());
        robot.getPathTrace().add(robot.toString() + String.format(AppConstant.COMMAND_POSITION_ERROR_MSG, Command.POSITION, x, y, facing) );
		return robot;
    }

	@Override
    public Robot moveForward(int steps, Robot robot) throws Exception {
		Robot newRobotPostion = null;
		FacingMovement facing = FacingMovement.valueOf(robot.getFacing());
		try {
			newRobotPostion = facing.moveForward(robot, steps);
		} catch (IllegalArgumentException ex) { 
			throw new IllegalArgumentException(String.format(AppConstant.GRID_RANGE_ERROR_MESSAGE, Command.FORWARD));
		}
		newRobotPostion.getPathTrace().add(newRobotPostion.toString() + String.format(AppConstant.COMMAND_ERROR_MSG, Command.FORWARD, steps));
		return newRobotPostion;
	}
	
	@Override
    public Robot rotate(String rotate, Robot robot) throws Exception {
		Robot rotatingRobot = null;
		FacingMovement newRotatingFacing = null;

		try {
			newRotatingFacing = FacingMovement.valueOf(rotate);
		} catch (IllegalArgumentException ex) { 
			throw new IllegalArgumentException(AppConstant.FACING_PARAM_ERROR_MSG + FacingMovement.getAllFacingAsString());
		}
		
		try {
			rotatingRobot = newRotatingFacing.rotate(robot);
		} catch (IllegalArgumentException ex) { 
			throw new IllegalArgumentException(AppConstant.FACING_PARAM_ERROR_MSG + FacingMovement.getAllFacingAsString());
		}
		rotatingRobot.getPathTrace().add(rotatingRobot.toString() +  String.format(AppConstant.COMMAND_ERROR_ROTATE_MSG, rotate) );
		return rotatingRobot;
	}

	@Override
    public void waiting(Robot robot) {
    	robot.getPathTrace().add(AppConstant.NO_MOVEMENT_FOR_WAIT_MSG);
    }

}
