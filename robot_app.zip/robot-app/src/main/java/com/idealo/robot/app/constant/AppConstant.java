package com.idealo.robot.app.constant;

public interface AppConstant {

	String GRID_RANGE_ERROR_MESSAGE = "The postion of robot(X,Y) must be within 0 and 5 inclusive. Please correct %s in the script";
	String FACING_PARAM_ERROR_MSG = "The 'Facing' parameter must be ";
	String COMMAND_ERROR_MSG = " [ Command: %s %s ]";
	String COMMAND_ERROR_ROTATE_MSG = " [ Command: %s ]";
	String COMMAND_POSITION_ERROR_MSG = " [ Command: %s %s %s %s ]";
	String X_Y_PRARAM_REQUIRED_MSG="The 'X or Y' parameter must be ...";
	String FORWARD_RANGE_ERROR_MSG="The FORWARD steps parameter must be in the range 0 and 5 inclusive.";
	String UNKOWN_OPERATION = "Unknown operations";
	String NO_MOVEMENT_FOR_WAIT_MSG = "No movement. [Command: WAIT]";
	String INVALID_POSITION_SCRIPT_PARAM = "Invalid Script %s. Four parameter expected (e.g. POSITION 1 3 EAST)";
	String INVALID_FORWARD_SCRIPT_PARAM = "Invalid Script %s. Two parameter expected (e.g. FORWARD 3)";

	String INVALID_SCRIPT = "Invalid Script ";
	String INVALID_POSTION_SCRIPT_MSG = "Invalid Script. It should start with the POSITION Command.";
}
