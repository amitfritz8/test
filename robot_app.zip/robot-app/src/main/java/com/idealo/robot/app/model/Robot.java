package com.idealo.robot.app.model;

import java.util.ArrayList;

public class Robot {
	private Integer x;
	private Integer y;
	private String facing;
	private ArrayList<String> pathTrace = new ArrayList<>();

	public Robot() {
	}

	public Robot(Integer x, Integer y, String facing) {
		super();
		this.x = x;
		this.y = y;
		this.facing = facing;
	}

	public Integer getX() {
		return x;
	}

	public void setX(Integer x) {
		this.x = x;
	}

	public Integer getY() {
		return y;
	}

	public void setY(Integer y) {
		this.y = y;
	}

	public String getFacing() {
		return facing;
	}

	public void setFacing(String facing) {
		this.facing = facing;
	}

	public ArrayList<String> getPathTrace() {
		return pathTrace;
	}

	public void setPathTrace(ArrayList<String> pathTrace) {
		this.pathTrace = pathTrace;
	}

	public String toString() {
		return "X: = " + this.x + ", Y: = " + this.y + " and facing:= " + this.facing;
	}

}
