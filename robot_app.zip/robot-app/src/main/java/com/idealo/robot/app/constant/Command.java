package com.idealo.robot.app.constant;

public enum Command {

	POSITION,
	FORWARD,
	LEFT,
	RIGHT,
	TURNAROUND,
	WAIT
}