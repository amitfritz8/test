package com.idealo.robot.app.navigator;

import com.idealo.robot.app.constant.AppConstant;
import com.idealo.robot.app.model.Robot;

/**
 * 
 * @author amit
 * This class builds the final facing position of robot as per the script.
 *
 */

public enum FacingMovement {

	NORTH(1), WEST(2), SOUTH(3), EAST(4),

	LEFT(-1), RIGHT(0), TURNAROUND(-2);

	public static final Integer X_MIN = 0;
	public static final Integer Y_MIN = 0;
	public static final Integer X_MAX = 5;
	public static final Integer Y_MAX = 5;

	public Robot moveForward(Robot robot, int steps) throws Exception {
		Integer newX, newY;
		
		if(steps < 0 || steps > 5) {
			throw new IllegalArgumentException(AppConstant.FORWARD_RANGE_ERROR_MSG);
		}
		switch (this) {
		case NORTH:
			newY = robot.getY() - steps;
			robot.setY(newY);
			if (newY < Y_MIN) {
				throw new IllegalArgumentException(AppConstant.X_Y_PRARAM_REQUIRED_MSG);
			}
			return robot;
		case SOUTH:
			newY = robot.getY() + steps;
			robot.setY(newY);
			if (newY > Y_MAX) {
				throw new IllegalArgumentException(AppConstant.X_Y_PRARAM_REQUIRED_MSG);
			}
			return robot;
		case EAST:
			newX = robot.getX() + steps;
			robot.setX(newX);
			if (newX > X_MAX) {
				throw new IllegalArgumentException(AppConstant.X_Y_PRARAM_REQUIRED_MSG);
			}
			return robot;
		case WEST:
			newX = robot.getX() - steps;
			robot.setX(newX);
			if (newX < X_MIN) {
				throw new IllegalArgumentException(AppConstant.X_Y_PRARAM_REQUIRED_MSG);
			}
			return robot;
		default:
			throw new Exception(AppConstant.UNKOWN_OPERATION + this);
		}
	}

	public Robot rotate(Robot robot) throws Exception {
		FacingMovement newFacing;
		int facingId;
		int newFacingId = 0;
		FacingMovement facing = FacingMovement.valueOf(robot.getFacing());

		switch (this) {
		case LEFT:
			facingId = facing.getId();
			newFacingId = facingId + 1;
			newFacing = byId(newFacingId);
			robot.setFacing(newFacing.name());
			return robot;
		case RIGHT:
			facingId = facing.getId();
			newFacingId = facingId - 1;
			newFacing = byId(newFacingId);
			robot.setFacing(newFacing.name());
			return robot;
		case TURNAROUND:
			facingId = facing.getId();
			if(facingId==1) {
				newFacingId = 3;
			}else if(facingId==2) {
				newFacingId = 4;
			}else if(facingId==3) {
				newFacingId = 1;
			}else if(facingId==4) {
				newFacingId = 2;
			}
			newFacing = byId(newFacingId);
			robot.setFacing(newFacing.name());
			return robot;
		default:
			throw new Exception(AppConstant.UNKOWN_OPERATION + this);
		}
	}

	private final int id;

	private FacingMovement(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public static FacingMovement byId(int id) {
		for (FacingMovement facing : FacingMovement.values()) {
			if (facing.id == id) {
				return facing;
			}
		}
		return null;
	}

	public static String getAllFacingAsString() {
		return EAST.name() + ", " + WEST.name() + ", " + NORTH.name() + ", " + SOUTH.name();
	}
}
