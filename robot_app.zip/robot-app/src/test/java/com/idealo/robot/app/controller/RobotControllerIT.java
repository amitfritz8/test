package com.idealo.robot.app.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.idealo.robot.app.RobotApplication;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, classes = RobotApplication.class)
public class RobotControllerIT {

	@Autowired
	private TestRestTemplate restTemplate;

	@Test
	public void test_script_executed_successfullly() throws Exception {

		String requestBody = "POSITION 1 3 EAST\n" + "FORWARD 3\n" + "WAIT\n" + "TURNAROUND\n" + "FORWARD 1\n"
				+ "RIGHT\n" + "FORWARD 2";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> request = new HttpEntity(requestBody, headers);
		ResponseEntity<String> response = this.restTemplate.postForEntity("/robot/script/execute", request,
				String.class);
		System.out.println(response.getBody());
		String expectedResponse = "{\"x\":3,\"y\":1,\"facing\":\"NORTH\"}";
		JSONAssert.assertEquals("Test fail for Status Codes", "200", String.valueOf(response.getStatusCodeValue()),
				true);
		JSONAssert.assertEquals(expectedResponse, response.getBody(), false);
	}
	
	@Test
	public void test_Exception_for_invalid_script() throws Exception {

		String requestBody = "POSITIO 1 3 EAST\n" + "FORWARD 3\n" + "WAIT\n" + "TURNAROUND\n" + "FORWARD 1\n"
				+ "RIGHT\n" + "FORWARD 2";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> request = new HttpEntity(requestBody, headers);
		ResponseEntity<String> response = this.restTemplate.postForEntity("/robot/script/execute", request,
				String.class);
		System.out.println(response.getBody());
		String expectedResponse = "{\"message\":\"Invalid Script. It should start with the POSITION Command.\"}";
		JSONAssert.assertEquals("Test fail for Status Codes", "500", String.valueOf(response.getStatusCodeValue()),
				true);
		JSONAssert.assertEquals(expectedResponse, response.getBody(), false);
	}
	
	@Test
	public void test_Exception_for_robot_moving_outside_grid_range() throws Exception {

		String requestBody = "POSITION 1 3 EAST\n" + "FORWARD 3\n" + "WAIT\n" + "TURNAROUND\n" + "FORWARD 1\n"
				+ "RIGHT\n" + "FORWARD 6";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> request = new HttpEntity(requestBody, headers);
		ResponseEntity<String> response = this.restTemplate.postForEntity("/robot/script/execute", request,
				String.class);
		System.out.println(response.getBody());
		String expectedResponse = "{\"message\":\"The postion of robot(X,Y) must be within 0 and 5 inclusive. Please correct FORWARD in the script\"}";
		JSONAssert.assertEquals("Test fail for Status Codes", "400", String.valueOf(response.getStatusCodeValue()),
				true);
		JSONAssert.assertEquals(expectedResponse, response.getBody(), false);
	}

}
