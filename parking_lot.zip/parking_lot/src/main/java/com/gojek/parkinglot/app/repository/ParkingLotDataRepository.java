package com.gojek.parkinglot.app.repository;


import com.gojek.parkinglot.app.exception.ParkingLotException;
import com.gojek.parkinglot.app.model.Vehicle;
import com.gojek.parkinglot.app.util.ParkingLotHelper;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ParkingLotDataRepository {

    private int capacity;
    private AtomicInteger numberOfOccupiedSlots = new AtomicInteger(0);
    private AtomicInteger slotNo = new AtomicInteger(0);

    private Vehicle[] totalSlotAvailable = null;

    Map<String, HashSet<String>> setOfRegNoByColorMap = new ConcurrentHashMap<>();
    Map<String, HashSet<Integer>> setOfSlotNoByColorMap = new ConcurrentHashMap<>();
    Map<String, Integer> slotNoByRegNoMap = new ConcurrentHashMap<>();
    PriorityBlockingQueue<Integer> nearestAvailableSlotPQ = new PriorityBlockingQueue<>(10);
    private static ParkingLotDataRepository instance = null;

    private ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    public static ParkingLotDataRepository getInstance() {
        if (instance == null) {
            synchronized (ParkingLotDataRepository.class) {
                if (instance == null) {
                    instance = new ParkingLotDataRepository();
                }
            }
        }
        return instance;
    }

    public void allocateParkingLotSpace(int capacity) throws ParkingLotException {
        if (totalSlotAvailable != null) {
            throw new ParkingLotException("Parking Lot already exist and Cannot be recreated again");
        }
        lock.writeLock().lock();
        this.capacity = capacity;
        totalSlotAvailable = new Vehicle[capacity];
        System.out.println("Created a parking lot with " + capacity + " slots");
        lock.writeLock().unlock();
    }

    public void parkVehicle(Vehicle vehicle) throws ParkingLotException {
        if(totalSlotAvailable==null){
            throw new ParkingLotException("Parking Lot Space Does Not exist");
        }
        lock.writeLock().lock();
        int allocatedSlotNo = 0;
        if (isParkingSpaceFull()) {
            System.out.println("Sorry, parking lot is full");
        } else if (totalSlotAvailable != null) {
            allocatedSlotNo = getNearestSlotAvailableToPark();
            if (allocatedSlotNo != -1) {
                totalSlotAvailable[allocatedSlotNo-1] = vehicle;
            } else {
                allocatedSlotNo = slotNo.incrementAndGet();
                totalSlotAvailable[allocatedSlotNo-1] = vehicle;
            }
            ParkingLotHelper.mapRegNoToVehicleColor(vehicle.getColor(), vehicle.getRegistrationNo(),setOfRegNoByColorMap);
            ParkingLotHelper.mapSlotNumbersToVehicleColor(vehicle.getColor(), allocatedSlotNo, setOfSlotNoByColorMap);
            ParkingLotHelper.mapSlotNumberToVehicleRegNo(vehicle.getRegistrationNo(), allocatedSlotNo,slotNoByRegNoMap);
            numberOfOccupiedSlots.incrementAndGet();
            System.out.println("Allocated slot number: " + (allocatedSlotNo));
            lock.writeLock().unlock();
        }
    }

    public void unParkVehicle(int slotNo) throws ParkingLotException{
        if(totalSlotAvailable==null){
            throw new ParkingLotException("Parking Lot Does Not exist");
        }else if(totalSlotAvailable[slotNo]==null){
            throw new ParkingLotException("There is no vehicle parked in this slot no.");
        }
        lock.writeLock().lock();
        nearestAvailableSlotPQ.add(slotNo);
        if (totalSlotAvailable != null) {
            updateMapping(slotNo);
            totalSlotAvailable[slotNo - 1] = null;
        }
        numberOfOccupiedSlots.decrementAndGet();
        System.out.println("Slot number " + slotNo + " is free");
        lock.writeLock().unlock();
    }

    private void updateMapping(int slotNo) {
        Vehicle vehicle = totalSlotAvailable[slotNo];
        slotNoByRegNoMap.remove(slotNo);
        Set<Integer> slotNos = setOfSlotNoByColorMap.get(vehicle.getColor());
        Set<String> regNos = setOfRegNoByColorMap.get(vehicle.getColor());
        if (!regNos.isEmpty()) {
            regNos.remove(vehicle.getRegistrationNo());
        }
        if (!slotNos.isEmpty()) {
            slotNos.remove(slotNo);
        }
    }

    public void getStatus() throws ParkingLotException {
        if (totalSlotAvailable == null) {
            throw new ParkingLotException("Sorry..Parking Lot is not created");
        } else if (numberOfOccupiedSlots.get() == 0) {
            throw new ParkingLotException("Sorry..Parking Lot is empty");
        }
        lock.readLock().lock();
        if (numberOfOccupiedSlots.get() > 0) {
            System.out.println("Slot No.\tRegistration No \tColour");
            for (int i = 0; i < totalSlotAvailable.length; i++) {
                Vehicle vehicle = totalSlotAvailable[i];
                if (vehicle != null) {
                    System.out.println(i + 1 + "\t\t\t" + vehicle.getRegistrationNo() + " \t\t" + vehicle.getColor());
                }
            }
        }
        lock.readLock().unlock();
    }

    public int getNearestSlotAvailableToPark() {
        if (!nearestAvailableSlotPQ.isEmpty()) {
            return nearestAvailableSlotPQ.poll();
        }
        return -1;
    }

    private boolean isParkingSpaceFull() {
        if (totalSlotAvailable != null && numberOfOccupiedSlots.get() == capacity) {
            return true;
        }
        return false;
    }

    public void getAllRegNoByColor(String color) throws ParkingLotException {

        Set<String> regNos = setOfRegNoByColorMap.get(color);
        if (regNos != null) {
            lock.readLock().lock();
            int count = 0;
            for (String regNo : regNos) {
                count++;
                if (count == regNos.size()) {
                    System.out.print(regNo);
                    System.out.println();
                } else {
                    System.out.print(regNo + ",  ");
                }
            }
            lock.readLock().unlock();
        } else {
            throw new ParkingLotException("This color(" + color + ") vehicle does not exist");

        }
    }

    public void getAllSlotNoByColor(String color) throws ParkingLotException {
        Set<Integer> slotNos = setOfSlotNoByColorMap.get(color);
        if (slotNos != null) {
            lock.readLock().lock();
            int count = 0;
            for (Integer slotNo : slotNos) {
                count++;
                if (count == slotNos.size()) {
                    System.out.print(slotNo);
                    System.out.println();
                } else {
                    System.out.print(slotNo + ", ");
                }
            }
            lock.readLock().unlock();
        } else {
            throw new ParkingLotException("This color(" + color + ") vehicle does not exist");
        }
    }

    public void getSlotNoByRegNo(String regNo){

        if (!slotNoByRegNoMap.isEmpty()) {
            lock.readLock().lock();
            Integer slotNo = slotNoByRegNoMap.get(regNo);
            if (slotNo != null) {
                System.out.println(slotNoByRegNoMap.get(regNo));
            } else {
                System.out.println("Not found");
            }
            lock.readLock().unlock();
        }

    }

    public int getNoOfAvailableSlots() {
        return capacity - numberOfOccupiedSlots.get();
    }
}