package com.gojek.parkinglot.app.processor.impl;

import com.gojek.parkinglot.app.exception.ParkingLotException;
import com.gojek.parkinglot.app.processor.AbstractProcessor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandLineInteractiveProcessor extends AbstractProcessor {

    public void process() throws ParkingLotException, IOException {
        System.out.println("Welcome to Gojek Parking Lot Application");
        System.out.println("Type Exit to end the application");

        BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));

        while (true) {
            String inputString = bufferRead.readLine();
            if(inputString.equalsIgnoreCase("exit")){
                break;
            }
            validateAndExecute(inputString);
        }
    }

}

