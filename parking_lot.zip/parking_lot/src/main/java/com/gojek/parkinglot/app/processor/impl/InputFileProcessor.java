package com.gojek.parkinglot.app.processor.impl;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.gojek.parkinglot.app.exception.ParkingLotException;
import com.gojek.parkinglot.app.processor.AbstractProcessor;


public class InputFileProcessor extends AbstractProcessor {


    private String filePath = null;

    public InputFileProcessor(String filePath) {
        this.filePath = filePath;
    }

    public void process() throws ParkingLotException, IOException {
    	InputStream inputStream = getClass().getResourceAsStream("/"+filePath);
        BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
        String line;
        while ((line = br.readLine()) != null) {
            validateAndExecute(line);
        }
    }

}
