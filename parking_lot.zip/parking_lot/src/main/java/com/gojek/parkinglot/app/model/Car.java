package com.gojek.parkinglot.app.model;

public class Car extends Vehicle
{
	public Car(String registrationNo, String color) {
		super(registrationNo, color);

	}
}
