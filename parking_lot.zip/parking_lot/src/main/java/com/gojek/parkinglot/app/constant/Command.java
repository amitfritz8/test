package com.gojek.parkinglot.app.constant;

public enum Command {
    CREATE("create_parking_lot"),
    PARK("park"),
    LEAVE("leave"),
    STATUS("status"),
    GET_ALL_REG_NO_BY_COLOR_OF_CAR("registration_numbers_for_cars_with_colour"),
    GET_ALL_SLOT_NO_BY_COLOR_OF_CAR("slot_numbers_for_cars_with_colour"),
    GET_SLOT_NO_FOR_REG_NO("slot_number_for_registration_number");

    private final String name;

     Command(String command) {
        this.name = command;
    }

    public static Command getCommand(String command) {
        for (Command c : values()) {
            if (c.toString().equals(command)) {
                return c;
            }
        }
        return null;
    }

    public String toString() {
        return name;
    }

}
