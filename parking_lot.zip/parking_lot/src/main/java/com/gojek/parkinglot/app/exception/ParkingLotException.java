package com.gojek.parkinglot.app.exception;


public class ParkingLotException extends Exception
{
    String msg;

    public ParkingLotException(String msg){
        super(msg);
    }

}
