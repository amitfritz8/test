package com.gojek.parkinglot.app.processor;

import com.gojek.parkinglot.app.constant.Command;
import com.gojek.parkinglot.app.exception.ParkingLotException;
import com.gojek.parkinglot.app.model.Car;
import com.gojek.parkinglot.app.service.ParkingLotService;
import com.gojek.parkinglot.app.service.impl.ParkingLotServiceImpl;
import java.io.IOException;

public abstract class AbstractProcessor
{
	private ParkingLotService parkingLotService = new ParkingLotServiceImpl();

	public void validateAndExecute(String inputString) throws ParkingLotException {
		String[] inputStrArr = inputString.split(" ");
		Command command = Command.getCommand(inputStrArr[0]);

		if(command == null) {
			System.out.println("Invalid command");
			return;
		}

		switch(command) {
			case CREATE:
				if(inputStrArr.length != 2) {
					throw new ParkingLotException("Invalid input command : " + command);
				}
				int numberOfParkingSlots = Integer.parseInt(inputStrArr[1]);
				parkingLotService.createParkingLot(numberOfParkingSlots);
				break;
			case PARK:
				if(inputStrArr.length != 3) {
					throw new ParkingLotException("Invalid input for command : " + command);
				}
				String regNo = inputStrArr[1];
				String color = inputStrArr[2];
				parkingLotService.parkVehicle(new Car(regNo, color));
				break;
			case LEAVE:
				if(inputStrArr.length != 2) {
					throw new ParkingLotException("Invalid input for command : " + command);
				}
				int slotNo = Integer.parseInt(inputStrArr[1]);
				parkingLotService.unParkVehicle(slotNo);
				break;
			case STATUS:
				if(inputStrArr.length != 1) {
					throw new ParkingLotException("Invalid input for command : " + command);
				}
				parkingLotService.getStatus();
				break;
			case GET_ALL_REG_NO_BY_COLOR_OF_CAR:
				if(inputStrArr.length != 2) {
					throw new ParkingLotException("Invalid input for command : " + command);
				}
				parkingLotService.getAllRegNoByColor(inputStrArr[1]);
				break;
			case GET_ALL_SLOT_NO_BY_COLOR_OF_CAR:
				if(inputStrArr.length != 2) {
					throw new ParkingLotException("Invalid input for command : " + command);
				}
				parkingLotService.getAllSlotNoByColor(inputStrArr[1]);
				break;
			case GET_SLOT_NO_FOR_REG_NO:
				if(inputStrArr.length != 2) {
					throw new ParkingLotException("Invalid input for command : " + command);
				}
				parkingLotService.getSlotNoByRegNo(inputStrArr[1]);
				break;
		}
	}

	public abstract void process() throws ParkingLotException, IOException;
}
