package com.gojek.parkinglot.app.service;


import com.gojek.parkinglot.app.exception.ParkingLotException;
import com.gojek.parkinglot.app.model.Vehicle;

public interface ParkingLotService {

    void createParkingLot(int capacity) throws ParkingLotException;

    void parkVehicle(Vehicle vehicle) throws ParkingLotException;

    void unParkVehicle(int slotNo) throws ParkingLotException;

    void getStatus() throws ParkingLotException;

    void getAllRegNoByColor(String color) throws ParkingLotException;

    void getAllSlotNoByColor(String color) throws ParkingLotException;

    void getSlotNoByRegNo(String regNo);

}
