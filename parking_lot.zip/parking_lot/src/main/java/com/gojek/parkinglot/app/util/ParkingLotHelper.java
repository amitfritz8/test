package com.gojek.parkinglot.app.util;

import java.util.HashSet;
import java.util.Map;

public class ParkingLotHelper {

    public static void mapRegNoToVehicleColor(String color, String regNo, Map<String, HashSet<String>> setOfRegNoByColorMap) {
        if (setOfRegNoByColorMap.get(color) != null) {
            setOfRegNoByColorMap.get(color).add(regNo);
        } else {
            HashSet<String> setRegNo = new HashSet<>();
            setRegNo.add(regNo);
            setOfRegNoByColorMap.put(color, setRegNo);
        }
    }

    public static void mapSlotNumberToVehicleRegNo(String regNo, int slotNo, Map<String,Integer> slotNoByRegNoMap) {
        slotNoByRegNoMap.put(regNo, slotNo);
    }

    public static void mapSlotNumbersToVehicleColor(String color, int slotNo, Map<String, HashSet<Integer>> setOfSlotNoByColorMap) {
        if (setOfSlotNoByColorMap.get(color) != null) {
            setOfSlotNoByColorMap.get(color).add(slotNo);
        } else {
            HashSet<Integer> setSlotNo = new HashSet<>();
            setSlotNo.add(slotNo);
            setOfSlotNoByColorMap.put(color, setSlotNo);
        }
    }
}
