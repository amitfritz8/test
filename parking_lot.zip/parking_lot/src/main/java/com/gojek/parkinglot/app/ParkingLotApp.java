package com.gojek.parkinglot.app;

import com.gojek.parkinglot.app.exception.ParkingLotException;
import com.gojek.parkinglot.app.processor.AbstractProcessor;
import com.gojek.parkinglot.app.processor.impl.CommandLineInteractiveProcessor;
import com.gojek.parkinglot.app.processor.impl.InputFileProcessor;

import java.io.IOException;

public class ParkingLotApp
{
    public static void main(String[] args) throws ParkingLotException, IOException {

        AbstractProcessor processor = null;
        if(args.length >= 1) {
            processor = new InputFileProcessor(args[0]);
        } else {
            processor = new CommandLineInteractiveProcessor();
        }
        processor.process();
    }

}
