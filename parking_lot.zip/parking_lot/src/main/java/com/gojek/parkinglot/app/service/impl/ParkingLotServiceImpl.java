package com.gojek.parkinglot.app.service.impl;


import com.gojek.parkinglot.app.exception.ParkingLotException;
import com.gojek.parkinglot.app.model.Vehicle;
import com.gojek.parkinglot.app.repository.ParkingLotDataRepository;
import com.gojek.parkinglot.app.service.ParkingLotService;

public class ParkingLotServiceImpl implements ParkingLotService {

    ParkingLotDataRepository parkingLotDataRepository = ParkingLotDataRepository.getInstance();

    @Override
    public void createParkingLot(int capacity) throws ParkingLotException {
        parkingLotDataRepository.allocateParkingLotSpace(capacity);
    }

    @Override
    public void parkVehicle(Vehicle vehicle) throws ParkingLotException {
        parkingLotDataRepository.parkVehicle(vehicle);
    }

    @Override
    public void unParkVehicle(int slotNo) throws ParkingLotException {
        parkingLotDataRepository.unParkVehicle(slotNo);
    }

    @Override
    public void getStatus() throws ParkingLotException {
        parkingLotDataRepository.getStatus();
    }

    @Override
    public void getAllRegNoByColor(String color) throws ParkingLotException {
        parkingLotDataRepository.getAllRegNoByColor(color);
    }

    @Override
    public void getAllSlotNoByColor(String color) throws ParkingLotException {
        parkingLotDataRepository.getAllSlotNoByColor(color);
    }

    @Override
    public void getSlotNoByRegNo(String regNo) {
        parkingLotDataRepository.getSlotNoByRegNo(regNo);
    }
}

