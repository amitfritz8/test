package com.gojek.parkinglot.app.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import com.gojek.parkinglot.app.exception.ParkingLotException;
import com.gojek.parkinglot.app.model.Car;


public class ParkingLotRepositoryTest {

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    ParkingLotDataRepository parkingLotDataRepository = null;

    @Before
    public void init() {
        System.setOut(new PrintStream(outContent));
        parkingLotDataRepository = new ParkingLotDataRepository();
    }

    @After
    public void cleanUp() {
        System.setOut(null);
        parkingLotDataRepository = null;
    }

    @Test
    public void testAllocateParkingLotSpace() throws ParkingLotException {
        parkingLotDataRepository.allocateParkingLotSpace(10);
        assertTrue("Created a parking lot with 10 slots".equalsIgnoreCase(outContent.toString().trim()));
    }

    @Test
    public void testAlreadyExistParkingLot() throws ParkingLotException {
        parkingLotDataRepository.allocateParkingLotSpace(6);
        assertTrue("Created a parking lot with 6 slots".equalsIgnoreCase(outContent.toString().trim()));
        Exception exception = Assertions.assertThrows(ParkingLotException.class, () -> {
            parkingLotDataRepository.allocateParkingLotSpace(20);
        });
        String expectedMessage = "Parking Lot already exist and Cannot be recreated again";
        String actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    public void testParkingLotCapacity() throws ParkingLotException {
        parkingLotDataRepository.allocateParkingLotSpace(10);
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-1234", "White"));
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-9999", "White"));
        parkingLotDataRepository.parkVehicle(new Car("KA-01-BB-0001", "Black"));
        assertEquals(7, parkingLotDataRepository.getNoOfAvailableSlots());
    }

    @Test
    public void testIfParkingLotIsEmpty() throws ParkingLotException {
        Exception exception = Assertions.assertThrows(ParkingLotException.class, () -> {
            parkingLotDataRepository.getStatus();
        });
        String expectedMessage = "Sorry..Parking Lot is not created";
        String actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(expectedMessage));
        Exception exception1 = Assertions.assertThrows(ParkingLotException.class, () -> {
            parkingLotDataRepository.allocateParkingLotSpace(20);
            parkingLotDataRepository.getStatus();
        });
        String expectedMessage1 = "Sorry..Parking Lot is empty";
        String actualMessage1 = exception1.getMessage();
        assertTrue(actualMessage1.contains(expectedMessage1));
    }

    @Test
    public void testIfParkingLotIsFull() throws ParkingLotException {
        parkingLotDataRepository.allocateParkingLotSpace(2);
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-1234", "White"));
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-9999", "White"));
        parkingLotDataRepository.parkVehicle(new Car("KA-01-BB-0001", "Black"));
        assertTrue("Createdaparkinglotwith2slotsAllocatedslotnumber:1Allocatedslotnumber:2Sorry,parkinglotisfull"
                .equalsIgnoreCase(outContent.toString().trim().replaceAll("\\s", "")));
    }

    @Test
    public void testGetNearestSlotAvailableToPark() throws ParkingLotException {
        parkingLotDataRepository.allocateParkingLotSpace(3);
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-1234", "White"));
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-9999", "White"));
        parkingLotDataRepository.parkVehicle(new Car("KA-01-BB-0001", "Black"));
        parkingLotDataRepository.unParkVehicle(2);
        assertEquals(2, parkingLotDataRepository.getNearestSlotAvailableToPark());
    }

    @Test
    public void testUnParkVehicle() throws ParkingLotException {
        parkingLotDataRepository.allocateParkingLotSpace(3);
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-1234", "White"));
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-9999", "White"));
        parkingLotDataRepository.parkVehicle(new Car("KA-01-BB-0001", "Black"));
        parkingLotDataRepository.unParkVehicle(2);
        assertTrue("Createdaparkinglotwith3slotsAllocatedslotnumber:1Allocatedslotnumber:2Allocatedslotnumber:3Slotnumber2isfree".equalsIgnoreCase(outContent.toString().trim().replaceAll("\\s", "")));
    }

    @Test
    public void testStatus() throws Exception {
        parkingLotDataRepository.allocateParkingLotSpace(8);
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-1234", "White"));
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-9999", "White"));
        parkingLotDataRepository.getStatus();
        assertTrue("Createdaparkinglotwith8slotsAllocatedslotnumber:1Allocatedslotnumber:2SlotNo.RegistrationNoColour1KA-01-HH-1234White2KA-01-HH-9999White".equalsIgnoreCase(outContent.toString().trim().replaceAll("\\s", "")));

    }

    @Test
    public void testGetSlotsByRegNo() throws Exception {
        parkingLotDataRepository.allocateParkingLotSpace(7);
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-1234", "White"));
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-9999", "White"));
        parkingLotDataRepository.getAllRegNoByColor("White");
        assertEquals("Createdaparkinglotwith7slotsAllocatedslotnumber:1Allocatedslotnumber:2KA-01-HH-1234,KA-01-HH-9999", outContent.toString().trim().replaceAll("\\s", ""));

    }

    @Test
    public void testGetSlotsByColor() throws Exception {
        parkingLotDataRepository.allocateParkingLotSpace(7);
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-1234", "White"));
        parkingLotDataRepository.parkVehicle(new Car("KA-01-HH-9999", "White"));
        parkingLotDataRepository.getAllSlotNoByColor("White");
        assertEquals("Createdaparkinglotwith7slotsAllocatedslotnumber:1Allocatedslotnumber:21,2", outContent.toString().trim().replaceAll("\\s", ""));
    }
}