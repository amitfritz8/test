export const APP_CONSTANTS = {
  title: 'gene-ui',
  name: 'gene-ui',
  id: 'app-id',
  fullName: 'Genesis'
};
