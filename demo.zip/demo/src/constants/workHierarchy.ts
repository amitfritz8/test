export const WORK_HIERARCHY_CONST = {
  PORTFOLIO_ID: 'portfolioID',
  PORTFOLIO_NAME: 'portfolioName',
  WORKSTREAM_ID: 'workstreamID',
  WORKSTREAM_NAME: 'workstreamName',
  SUB_WORKSTREAM_ID: 'subWorkStreamId',
  SUB_WORKSTREAM_NAME: 'subWorkstreamName',
  WORKSTREAM: 'workstream',
  PORTFOLIO: 'portfolio',
  SUB_WORKSTREAM: 'subWorkstream',
  SCENARIO: 'scenario',
  CURRENCY_CODE_TYPE:'currencyCodeType'
};
