// tslint:disable-next-line: one-variable-per-declaration
export const URL_PREFIX = {
    AUTH : '/auth',
    PORTFOLIO : '/portfolio',
    PEOPLE : '/people',
    REPORTS : '/gene-reports',
};
