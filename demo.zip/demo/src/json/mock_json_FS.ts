export const summaryData1 = [
  {
    name: 'financial summary',
    glGroups: [
      {
        name: 'total investment',
        monthlyFinanceTotal: ['2908', '3434', '432', '2778', '20087', '32478', '3478', '3243', '2000', '5654', '4565', '5465'],
        overAllSum: '78787',
        totalSum: '8788',
        glCategories: [
          {
            name: 'capex',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            // quarterly: ['2000', '3434', '432', '234', '234'],
            portfolioTotal: '7878700',
            totalSum: '8788',
          },
          {
            name: 'opex',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            // quarterly: ['2000', '3434', '432', '234', '234'],
            overAllSum: '7878700',
            totalSum: '8788',
          }
        ]
      },
      {
        name: 'total P&L',
        monthlyFinanceTotal: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
        // quarterly: ['2000', '3434', '432', '234', '234'],
        overAllSum: '78787',
        totalSum: '8788',
        glCategories: [
          {
            name: 'opex',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '7878700',
            totalSum: '8788',
          },
          {
            name: 'ownership',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            // quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '7878700',
            totalSum: '8788',
          },
          {
            name: 'it depreciation',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            // quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '7878700',
            totalSum: '8788',
          }
        ]
      }
    ]
  },
  {
    name: 'breakdown by cost type',
    glGroups: [
      {
        name: 'seed funding',
        monthlyFinanceTotal: ['2978', '3434', '432', '2778', '20087', '32478', '3478', '3243', '2000', '5654', '4565', '5465'],
        // quarterly: ['2000', '3434', '432', '234', '234', '3242'],
        overAllSum: '78787',
        totalSum: '8788',
        glCategories: [
          {
            name: 'resource',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '78787',
            totalSum: '8788',
          },
          {
            name: 'software',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '78787',
            totalSum: '8788',
          },
          {
            name: 'hardware',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '78787',
            totalSum: '8788',
          },
          {
            name: 'others',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '78787',
            totalSum: '8788',
          }
        ]
      },
      {
        name: 'HLE',
        monthlyFinanceTotal: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
        quarterly: ['2000', '3434', '432', '234', '234', '3242'],
        overAllSum: '78787',
        totalSum: '8788',
        glCategories: [
          {
            name: 'resource',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '78787',
            totalSum: '8788',
          },
          {
            name: 'software',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '78787',
            totalSum: '8788',
          },
          {
            name: 'hardware',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '78787',
            totalSum: '8788',
          },
          {
            name: 'others',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '78787',
            totalSum: '8788',
          }
        ]
      },
      {
        name: 'financial details',
        monthlyFinanceTotal: ['2224', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
        // quarterly: ['2000', '3434', '432', '234', '234', '3242'],
        overAllSum: '78787',
        totalSum: '8788',
        glCategories: [
          {
            name: 'resource',
            subTitleList: [
              {
                name: 'FTE',
                monthly: ['2222', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                // quarterly: ['2000', '3434', '432', '234', '234', '3242'],
                overAllSum: '78787',
              },
              {
                name: 'Man-days',
                monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                // quarterly: ['2000', '3434', '432', '234', '234', '3242'],
                overAllSum: '78787',
              },
              {
                name: 'cost',
                monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                // quarterly: ['2000', '3434', '432', '234', '234', '3242'],
                overAllSum: '78787',
              }
            ],
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            // quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '787800',
            totalSum: '98989',
            costDetails: [
              {
                itemName: 'Team Mermaid',
                subItemName: 'TM1001',
                monthlyCost: '234',
                //title:'cost',
                // monthly:['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                unitDetails: [
                  {
                    title: 'FTE',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  },
                  {
                    title: '% alloc',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  },
                  {
                    title: 'Man-days',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  },
                  {
                    title: 'cost',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  }
                ]
              },
              {
                itemName: 'GFARRTM1',
                subItemName: 'TM2991',
                monthlyCost: '302',
                //title:'cost',
                // monthly:['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                unitDetails: [
                  {
                    title: 'FTE',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  },
                  {
                    title: '% alloc',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  },
                  {
                    title: 'Man-days',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  },
                  {
                    title: 'cost',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  }
                ]
              },
              {
                itemName: 'UX Designer',
                subItemName: 'SA Capgemini',
                monthlyCost: '5,000',
                //title:'cost',
                // monthly:['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                unitDetails: [
                  {
                    title: 'FTE',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  },
                  {
                    title: '% alloc',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  },
                  {
                    title: 'Man-days',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  },
                  {
                    title: 'cost',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  }
                ]
              }
            ]
          },
          {
            name: 'software',
            subTitle: 'cost',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            // quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '787800',
            totalSum: '98989',
            costDetails: [
              {
                itemName: 'Miscrosoft',
                subItemName: 'temp',
                monthlyCost: '5000',
                title: 'cost',
                monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                unitDetails: [
                  {
                    title: 'unit',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  },
                  {
                    title: 'cost',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  }
                ]
              }
            ]
          },
          {
            name: 'hardware',
            subTitle: 'cost',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            // quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '7878700',
            totalSum: '45435',
            costDetails: [
              {
                itemName: 'Miscrosoft',
                subItemName: 'temp',
                monthlyCost: '5000',
                title: 'cost',
                monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                unitDetails: [
                  {
                    title: 'unit',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  },
                  {
                    title: 'cost',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  }
                ]
              }
            ]
          },
          {
            name: 'others',
            subTitle: 'cost',
            monthlyFinance: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465'],
            // quarterly: ['2000', '3434', '432', '234', '234', '3242'],
            overAllSum: '7878700',
            totalSum: '45435',
            costDetails: [
              {
                itemName: 'Miscrosoft',
                subItemName: 'temp',
                monthlyCost: '5000',
                title: 'cost',
                monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                unitDetails: [
                  {
                    title: 'unit',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  },
                  {
                    title: 'cost',
                    monthly: ['2000', '3434', '432', '234', '234', '3242', '3444', '3243', '2000', '5654', '4565', '5465', '4565'],
                    overAllSum: '32004',
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  }
]

export const MonthlyDataForBreakdownByCost = {
    "name": "Breakdown by cost type",
    "costSettingsViewList": [
        {
            "name": "HLE",
            "monthlyCostSettings": [
                88.000000000,
                88.000000000,
                730.000000000,
                730.000000000,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0
            ],
            "quarterlyCostSettings": null,
            "yearlyCostSettings": null,
            "costSettingsTotal": 1636.000000000,
            "costSettingsOverAllTotal": 1636.000000000,
            "costTypeCategoryViewList": [
                {
                    "name": "Hardware",
                    "monthlyCostTypes": [
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ],
                    "quarterlyCostType": {},
                    "yearlyCostType": {},
                    "costTypeTotal": 0,
                    "costTypeOverAllTotal": 0,
                    "individualYearSummaryForQuarterly": {}
                },
                {
                    "name": "Others",
                    "monthlyCostTypes": [
                        0,
                        0,
                        145.000000000,
                        145.000000000,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ],
                    "quarterlyCostType": {},
                    "yearlyCostType": {},
                    "costTypeTotal": 290.000000000,
                    "costTypeOverAllTotal": 580.000000000,
                    "individualYearSummaryForQuarterly": {}
                },
                {
                    "name": "Resource",
                    "monthlyCostTypes": [
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ],
                    "quarterlyCostType": {},
                    "yearlyCostType": {},
                    "costTypeTotal": 0,
                    "costTypeOverAllTotal": 0,
                    "individualYearSummaryForQuarterly": {}
                },
                {
                    "name": "Software",
                    "monthlyCostTypes": [
                        88.000000000,
                        88.000000000,
                        220.000000000,
                        220.000000000,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ],
                    "quarterlyCostType": {},
                    "yearlyCostType": {},
                    "costTypeTotal": 616.000000000,
                    "costTypeOverAllTotal": 1056.000000000,
                    "individualYearSummaryForQuarterly": {}
                }
            ],
            "individualYearSummaryForQuarterly": null
        },
        {
          "name": "Seed Funding",
          "monthlyCostSettings": [
            125.000000000,
            125.000000000,
            125.000000000,
            125.000000000,
            125.000000000,
            125.000000000,
            125.000000000,
            125.000000000,
            125.000000000,
            125.000000000,
            125.000000000,
            125.000000000
          ],
          "quarterlyCostSettings": null,
          "yearlyCostSettings": null,
          "costSettingsTotal": 1500.000000000,
          "costSettingsOverAllTotal": 2000.000000000,
          "costTypeCategoryViewList": [
            {
              "name": "Hardware",
              "monthlyCostTypes": null,
              "yearlyCostType": null,
              "costTypeTotal": 375.000000000,
              "costTypeOverAllTotal": 1000.000000000,
              "individualYearSummaryForQuarterly": null,
              "quarterlyCostType": null,
              "monthlyCostSummary": null,
              "quarterlyCostSummary": null,
              "yearlyCostSummary": null,
              "monthlyUnitCostList": null,
              "quarterlyUnitCostList": null,
              "yearlyUnitCostList": null,
              "monthlyResources": [
                {
                  "surrId": 1609,
                  "monthNumber": "01",
                  "value": 31.250000000
                },
                {
                  "surrId": 1610,
                  "monthNumber": "02",
                  "value": 31.250000000
                },
                {
                  "surrId": 1611,
                  "monthNumber": "03",
                  "value": 31.250000000
                },
                {
                  "surrId": 1612,
                  "monthNumber": "04",
                  "value": 31.250000000
                },
                {
                  "surrId": 1613,
                  "monthNumber": "05",
                  "value": 31.250000000
                },
                {
                  "surrId": 1614,
                  "monthNumber": "06",
                  "value": 31.250000000
                },
                {
                  "surrId": 1615,
                  "monthNumber": "07",
                  "value": 31.250000000
                },
                {
                  "surrId": 1616,
                  "monthNumber": "08",
                  "value": 31.250000000
                },
                {
                  "surrId": 1617,
                  "monthNumber": "09",
                  "value": 31.250000000
                },
                {
                  "surrId": 1618,
                  "monthNumber": "10",
                  "value": 31.250000000
                },
                {
                  "surrId": 1619,
                  "monthNumber": "11",
                  "value": 31.250000000
                },
                {
                  "surrId": 1620,
                  "monthNumber": "12",
                  "value": 31.250000000
                }
              ]
            },
            {
              "name": "Others",
              "monthlyCostTypes": null,
              "yearlyCostType": null,
              "costTypeTotal": 375.000000000,
              "costTypeOverAllTotal": 1000.000000000,
              "individualYearSummaryForQuarterly": null,
              "quarterlyCostType": null,
              "monthlyCostSummary": null,
              "quarterlyCostSummary": null,
              "yearlyCostSummary": null,
              "monthlyUnitCostList": null,
              "quarterlyUnitCostList": null,
              "yearlyUnitCostList": null,
              "monthlyResources": [
                {
                  "surrId": 1626,
                  "monthNumber": "01",
                  "value": 31.250000000
                },
                {
                  "surrId": 1627,
                  "monthNumber": "02",
                  "value": 31.250000000
                },
                {
                  "surrId": 1628,
                  "monthNumber": "03",
                  "value": 31.250000000
                },
                {
                  "surrId": 1629,
                  "monthNumber": "04",
                  "value": 31.250000000
                },
                {
                  "surrId": 1630,
                  "monthNumber": "05",
                  "value": 31.250000000
                },
                {
                  "surrId": 1631,
                  "monthNumber": "06",
                  "value": 31.250000000
                },
                {
                  "surrId": 1632,
                  "monthNumber": "07",
                  "value": 31.250000000
                },
                {
                  "surrId": 1633,
                  "monthNumber": "08",
                  "value": 31.250000000
                },
                {
                  "surrId": 1634,
                  "monthNumber": "09",
                  "value": 31.250000000
                },
                {
                  "surrId": 1635,
                  "monthNumber": "10",
                  "value": 31.250000000
                },
                {
                  "surrId": 1636,
                  "monthNumber": "11",
                  "value": 31.250000000
                },
                {
                  "surrId": 1637,
                  "monthNumber": "12",
                  "value": 31.250000000
                }
              ]
            },
            {
              "name": "Resource",
              "monthlyCostTypes": null,
              "yearlyCostType": null,
              "costTypeTotal": 375.000000000,
              "costTypeOverAllTotal": 1000.000000000,
              "individualYearSummaryForQuarterly": null,
              "quarterlyCostType": null,
              "monthlyCostSummary": null,
              "quarterlyCostSummary": null,
              "yearlyCostSummary": null,
              "monthlyUnitCostList": null,
              "quarterlyUnitCostList": null,
              "yearlyUnitCostList": null,
              "monthlyResources": [
                {
                  "surrId": 1575,
                  "monthNumber": "01",
                  "value": 31.250000000
                },
                {
                  "surrId": 1576,
                  "monthNumber": "02",
                  "value": 31.250000000
                },
                {
                  "surrId": 1577,
                  "monthNumber": "03",
                  "value": 31.250000000
                },
                {
                  "surrId": 1578,
                  "monthNumber": "04",
                  "value": 31.250000000
                },
                {
                  "surrId": 1579,
                  "monthNumber": "05",
                  "value": 31.250000000
                },
                {
                  "surrId": 1580,
                  "monthNumber": "06",
                  "value": 31.250000000
                },
                {
                  "surrId": 1581,
                  "monthNumber": "07",
                  "value": 31.250000000
                },
                {
                  "surrId": 1582,
                  "monthNumber": "08",
                  "value": 31.250000000
                },
                {
                  "surrId": 1583,
                  "monthNumber": "09",
                  "value": 31.250000000
                },
                {
                  "surrId": 1584,
                  "monthNumber": "10",
                  "value": 31.250000000
                },
                {
                  "surrId": 1585,
                  "monthNumber": "11",
                  "value": 31.250000000
                },
                {
                  "surrId": 1586,
                  "monthNumber": "12",
                  "value": 31.250000000
                }
              ]
            },
            {
              "name": "Software",
              "monthlyCostTypes": null,
              "yearlyCostType": null,
              "costTypeTotal": 375.000000000,
              "costTypeOverAllTotal": 1000.000000000,
              "individualYearSummaryForQuarterly": null,
              "quarterlyCostType": null,
              "monthlyCostSummary": null,
              "quarterlyCostSummary": null,
              "yearlyCostSummary": null,
              "monthlyUnitCostList": null,
              "quarterlyUnitCostList": null,
              "yearlyUnitCostList": null,
              "monthlyResources": [
                {
                  "surrId": 1592,
                  "monthNumber": "01",
                  "value": 31.250000000
                },
                {
                  "surrId": 1593,
                  "monthNumber": "02",
                  "value": 31.250000000
                },
                {
                  "surrId": 1594,
                  "monthNumber": "03",
                  "value": 31.250000000
                },
                {
                  "surrId": 1595,
                  "monthNumber": "04",
                  "value": 31.250000000
                },
                {
                  "surrId": 1596,
                  "monthNumber": "05",
                  "value": 31.250000000
                },
                {
                  "surrId": 1597,
                  "monthNumber": "06",
                  "value": 31.250000000
                },
                {
                  "surrId": 1598,
                  "monthNumber": "07",
                  "value": 31.250000000
                },
                {
                  "surrId": 1599,
                  "monthNumber": "08",
                  "value": 31.250000000
                },
                {
                  "surrId": 1600,
                  "monthNumber": "09",
                  "value": 31.250000000
                },
                {
                  "surrId": 1601,
                  "monthNumber": "10",
                  "value": 31.250000000
                },
                {
                  "surrId": 1602,
                  "monthNumber": "11",
                  "value": 31.250000000
                },
                {
                  "surrId": 1603,
                  "monthNumber": "12",
                  "value": 31.250000000
                }
              ]
            }
          ]
          },
        {
          "name": "Financial Details",
          "monthlyCostSettings": null,
          "quarterlyCostSettings": null,
          "yearlyCostSettings": null,
          "costSettingsTotal": 0,
          "costSettingsOverAllTotal": 0,
          "costTypeCategoryViewList": [
              {
                  "name": "Hardware",
                  "monthlyCostTypes": [
                      0,
                      0,
                      167.00000,
                      167.00000,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0
                  ],
                  "yearlyCostType": null,
                  "costTypeTotal": 334.00000,
                  "costTypeOverAllTotal": 497.00000,
                  "individualYearSummaryForQuarterly": null,
                  "quarterlyCostType": null,
                  "monthlyCostSummary": null,
                  "quarterlyCostSummary": null,
                  "yearlyCostSummary": null,
                  "monthlyUnitCostList": [
                      {
                          "name": "GOVERNANCE, RISK & CONTROL - GOVERNANCE, RISK & CONTROL",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": [
                              0,
                              0,
                              4.000000000,
                              4.000000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "costs": [
                              0,
                              0,
                              1.00000,
                              1.00000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 8.000000000,
                          "costOverAllTotal": 2.00000,
                          "yearlyCostOverAllTotal": 4.00000,
                          "yearlyUnitOverAllTotal": 16.000000000
                      },
                      {
                          "name": "OS - Linux",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": [
                              0,
                              0,
                              22.500000000,
                              22.500000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "costs": [
                              0,
                              0,
                              5.00000,
                              5.00000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 45.000000000,
                          "costOverAllTotal": 10.00000,
                          "yearlyCostOverAllTotal": 40.00000,
                          "yearlyUnitOverAllTotal": 130.500000000
                      },
                      {
                          "name": "OS - Windows",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": [
                              0,
                              0,
                              28.500000000,
                              28.500000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "costs": [
                              0,
                              0,
                              10.00000,
                              10.00000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 57.000000000,
                          "costOverAllTotal": 20.00000,
                          "yearlyCostOverAllTotal": 40.00000,
                          "yearlyUnitOverAllTotal": 130.500000000
                      },
                      {
                          "name": "Database - MOT storage",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": [
                              0,
                              0,
                              2.500000000,
                              2.500000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "costs": [
                              0,
                              0,
                              50.00000,
                              50.00000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 5.000000000,
                          "costOverAllTotal": 100.00000,
                          "yearlyCostOverAllTotal": 450.00000,
                          "yearlyUnitOverAllTotal": 22.500000000
                      },
                      {
                          "name": "Database - CAS storage",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": [
                              0,
                              0,
                              5.000000000,
                              5.000000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "costs": [
                              0,
                              0,
                              100.00000,
                              100.00000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 10.000000000,
                          "costOverAllTotal": 200.00000,
                          "yearlyCostOverAllTotal": 450.00000,
                          "yearlyUnitOverAllTotal": 22.500000000
                      },
                      {
                          "name": "Security - Security Measures",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": [
                              0,
                              0,
                              3.000000000,
                              3.000000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "costs": [
                              0,
                              0,
                              1.00000,
                              1.00000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 6.000000000,
                          "costOverAllTotal": 2.00000,
                          "yearlyCostOverAllTotal": 3.00000,
                          "yearlyUnitOverAllTotal": 9.000000000
                      },
                      {
                          "name": "Other Hardware",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": null,
                          "costs": [
                              0,
                              0,
                              0.500000000,
                              0.500000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 0,
                          "costOverAllTotal": 2.000000000,
                          "yearlyCostOverAllTotal": 0,
                          "yearlyUnitOverAllTotal": 0
                      }
                  ],
                  "quarterlyUnitCostList": null,
                  "yearlyUnitCostList": null
              },
              {
                  "name": "Others",
                  "monthlyCostTypes": [
                      0,
                      0,
                      1.000000000,
                      10.500000000,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0
                  ],
                  "yearlyCostType": null,
                  "costTypeTotal": 11.500000000,
                  "costTypeOverAllTotal": 11.500000000,
                  "individualYearSummaryForQuarterly": null,
                  "quarterlyCostType": null,
                  "monthlyCostSummary": null,
                  "quarterlyCostSummary": null,
                  "yearlyCostSummary": null,
                  "monthlyUnitCostList": [
                      {
                          "name": "Project Management",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": null,
                          "costs": [
                              0,
                              0,
                              0.500000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 0,
                          "costOverAllTotal": 2.000000000,
                          "yearlyCostOverAllTotal": 0,
                          "yearlyUnitOverAllTotal": 0
                      },
                      {
                          "name": "Others5",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": null,
                          "costs": [
                              0,
                              0,
                              0.500000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 0,
                          "costOverAllTotal": 2.000000000,
                          "yearlyCostOverAllTotal": 0,
                          "yearlyUnitOverAllTotal": 0
                      },
                      {
                          "name": "Others5",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": null,
                          "costs": [
                              0,
                              0,
                              0,
                              0.500000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 0,
                          "costOverAllTotal": 2.000000000,
                          "yearlyCostOverAllTotal": 0,
                          "yearlyUnitOverAllTotal": 0
                      },
                      {
                          "name": "Others5",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": null,
                          "costs": [
                              0,
                              0,
                              0,
                              10.000000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 0,
                          "costOverAllTotal": 2.000000000,
                          "yearlyCostOverAllTotal": 0,
                          "yearlyUnitOverAllTotal": 0
                      }
                  ],
                  "quarterlyUnitCostList": null,
                  "yearlyUnitCostList": null
              },
              {
                  "name": "Resource",
                  "monthlyCostTypes": null,
                  "yearlyCostType": null,
                  "costTypeTotal": 0,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": null,
                  "quarterlyCostType": null,
                  "monthlyCostSummary": null,
                  "quarterlyCostSummary": null,
                  "yearlyCostSummary": null,
                  "monthlyUnitCostList": null,
                  "quarterlyUnitCostList": null,
                  "yearlyUnitCostList": null
              },
              {
                  "name": "Software",
                  "monthlyCostTypes": [
                      0,
                      0,
                      5009.000000000,
                      5009.000000000,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0
                  ],
                  "yearlyCostType": null,
                  "costTypeTotal": 10018.000000000,
                  "costTypeOverAllTotal": 15018.000000000,
                  "individualYearSummaryForQuarterly": null,
                  "quarterlyCostType": null,
                  "monthlyCostSummary": null,
                  "quarterlyCostSummary": null,
                  "yearlyCostSummary": null,
                  "monthlyUnitCostList": [
                      {
                          "name": "IBM - Dashboard",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": [
                              0,
                              0,
                              2.000000000,
                              2.000000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "costs": [
                              0,
                              0,
                              5000.000000000,
                              5000.000000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 4.000000000,
                          "costOverAllTotal": 10000.000000000,
                          "yearlyCostOverAllTotal": 15006.000000000,
                          "yearlyUnitOverAllTotal": 8.000000000
                      },
                      {
                          "name": "IBM - Lotus",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": [
                              0,
                              0,
                              1.000000000,
                              1.000000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "costs": [
                              0,
                              0,
                              3.000000000,
                              3.000000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 2.000000000,
                          "costOverAllTotal": 6.000000000,
                          "yearlyCostOverAllTotal": 15006.000000000,
                          "yearlyUnitOverAllTotal": 8.000000000
                      },
                      {
                          "name": "Microsoft - Messagner",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": [
                              0,
                              0,
                              2.000000000,
                              2.000000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "costs": [
                              0,
                              0,
                              6.000000000,
                              6.000000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 4.000000000,
                          "costOverAllTotal": 12.000000000,
                          "yearlyCostOverAllTotal": 12.000000000,
                          "yearlyUnitOverAllTotal": 4.000000000
                      },
                      {
                          "name": "Other Software",
                          "currencyCode": "SGD",
                          "currencyValue": "2500",
                          "periodType": "monthly",
                          "units": null,
                          "costs": [
                              0,
                              0,
                              0.500000000,
                              0.500000000,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                          ],
                          "quarterlyUnitTotal": [],
                          "quarterlyCostTotal": [],
                          "yearlyUnitTotal": [],
                          "yearlyCostTotal": [],
                          "unitOverAllTotal": 0,
                          "costOverAllTotal": 1.000000000,
                          "yearlyCostOverAllTotal": 0,
                          "yearlyUnitOverAllTotal": 0
                      }
                  ],
                  "quarterlyUnitCostList": null,
                  "yearlyUnitCostList": null
              }
          ],
          "individualYearSummaryForQuarterly": null
      }
    ]
}

export const QuarterlyDataForBreakdownByCost = {
  "name": "Breakdown by cost type",
  "costSettingsViewList": [
      {
          "name": "HLE",
          "monthlyCostSettings": null,
          "quarterlyCostSettings": {
            "2019": [
              906.000000000,
              730.000000000,
              0,
              0
          ],
              "2020": [
                  906.000000000,
                  730.000000000,
                  0,
                  0
              ]
          },
          "yearlyCostSettings": null,
          "costSettingsTotal": 0,
          "costSettingsOverAllTotal": 1636.000000000,
          "costTypeCategoryViewList": [
              {
                  "name": "Hardware",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {
                    "2019": [
                      0,
                      0,
                      0,
                      0
                  ],
                      "2020": [
                          0,
                          0,
                          0,
                          0
                      ]
                  },
                  "yearlyCostType": {},
                  "costTypeTotal": 0,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {
                    "2019":0,
                      "2020": 0
                  }
              },
              {
                  "name": "Others",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {
                    "2019": [
                      290.000000000,
                      290.000000000,
                      0,
                      0
                  ],
                      "2020": [
                          290.000000000,
                          290.000000000,
                          0,
                          0
                      ]
                  },
                  "yearlyCostType": {},
                  "costTypeTotal": 580.000000000,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {
                    "2019": 580.000000000,
                      "2020": 580.000000000
                  }
              },
              {
                  "name": "Resource",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {
                    "2019": [
                      0,
                      0,
                      0,
                      0
                  ],
                      "2020": [
                          0,
                          0,
                          0,
                          0
                      ]
                  },
                  "yearlyCostType": {},
                  "costTypeTotal": 0,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {
                      "2020": 0
                  }
              },
              {
                  "name": "Software",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {
                    "2019": [
                      616.000000000,
                      440.000000000,
                      0,
                      0
                  ],
                      "2020": [
                          616.000000000,
                          440.000000000,
                          0,
                          0
                      ]
                  },
                  "yearlyCostType": {},
                  "costTypeTotal": 1056.000000000,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {
                    "2019": 1056.000000000,
                      "2020": 1056.000000000
                  }
              }
          ],
          "individualYearSummaryForQuarterly": {
            "2019": 1636.000000000,
              "2020": 1636.000000000
          }
      },
      {
          "name": "Seed Funding",
          "monthlyCostSettings": null,
          "quarterlyCostSettings": {
              "2019": [
                  0,
                  55.000000000,
                  0,
                  0
              ],
              "2020": [
                  275.000000000,
                  275.000000000,
                  0,
                  0
              ]
          },
          "yearlyCostSettings": null,
          "costSettingsTotal": 0,
          "costSettingsOverAllTotal": 605.000000000,
          "costTypeCategoryViewList": [
              {
                  "name": "Hardware",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {
                      "2019": [
                          0,
                          0,
                          0,
                          0
                      ],
                      "2020": [
                          55.000000000,
                          55.000000000,
                          0,
                          0
                      ]
                  },
                  "yearlyCostType": {},
                  "costTypeTotal": 110.000000000,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {
                      "2019": 0,
                      "2020": 110.000000000
                  }
              },
              {
                  "name": "Others",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {
                      "2019": [
                          0,
                          0,
                          0,
                          0
                      ],
                      "2020": [
                          55.000000000,
                          55.000000000,
                          0,
                          0
                      ]
                  },
                  "yearlyCostType": {},
                  "costTypeTotal": 110.000000000,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {
                      "2019": 0,
                      "2020": 110.000000000
                  }
              },
              {
                  "name": "Resource",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {
                      "2019": [
                          0,
                          0,
                          0,
                          0
                      ],
                      "2020": [
                          0,
                          0,
                          0,
                          0
                      ]
                  },
                  "yearlyCostType": {},
                  "costTypeTotal": 0,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {
                      "2019": 0,
                      "2020": 0
                  }
              },
              {
                  "name": "Software",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {
                      "2019": [
                          0,
                          55.000000000,
                          0,
                          0
                      ],
                      "2020": [
                          55.000000000,
                          55.000000000,
                          0,
                          0
                      ]
                  },
                  "yearlyCostType": {},
                  "costTypeTotal": 165.000000000,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {
                      "2019": 55.000000000,
                      "2020": 110.000000000
                  }
              }
          ],
          "individualYearSummaryForQuarterly": {
              "2019": 55.000000000,
              "2020": 550.000000000
          }
      },
      {
        "name": "Financial Details",
        "monthlyCostSettings": null,
        "quarterlyCostSettings": null,
        "yearlyCostSettings": null,
        "costSettingsTotal": 0,
        "costSettingsOverAllTotal": 0,
        "costTypeCategoryViewList": [
          {
            "name": "Hardware",
            "monthlyCostTypes": null,
            "yearlyCostType": null,
            "costTypeTotal": 0,
            "costTypeOverAllTotal": 3896.00000,
            "individualYearSummaryForQuarterly": {
              "2020": 3896.00000
            },
            "quarterlyCostType": {
              "2019": [
                1948.00000,
                1948.00000,
                0,
                0
              ]
            },
            "monthlyCostSummary": null,
            "quarterlyCostSummary": null,
            "yearlyCostSummary": null,
            "monthlyUnitCostList": null,
            "quarterlyUnitCostList": {
              "2020": [
                {
                  "name": "OS - Windows",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    28.500000000,
                    28.500000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    600.00000,
                    600.00000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 3896.00000,
                  "yearlyUnitOverAllTotal": 270.000000000
                },
                {
                  "name": "OS - Mac",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    49.500000000,
                    49.500000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    678.00000,
                    678.00000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 3896.00000,
                  "yearlyUnitOverAllTotal": 270.000000000
                },
                {
                  "name": "Database - MOT storage",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    2.500000000,
                    2.500000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    50.00000,
                    50.00000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 3896.00000,
                  "yearlyUnitOverAllTotal": 270.000000000
                },
                {
                  "name": "Database - CAS storage",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    5.000000000,
                    5.000000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    50.00000,
                    50.00000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 3896.00000,
                  "yearlyUnitOverAllTotal": 270.000000000
                },
                {
                  "name": "Other Hardware Others3",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    
                  ],
                  "quarterlyCostTotal": [
                    0.333333333,
                    0.333333333,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0.666666666,
                  "yearlyCostOverAllTotal": 0,
                  "yearlyUnitOverAllTotal": 0
                }
              ],
              "2019": [
                {
                  "name": "OS - Linux",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    22.500000000,
                    22.500000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    500.00000,
                    500.00000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 3896.00000,
                  "yearlyUnitOverAllTotal": 270.000000000
                },
                {
                  "name": "OS - Solaris",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    27.000000000,
                    27.000000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    70.00000,
                    70.00000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 3896.00000,
                  "yearlyUnitOverAllTotal": 270.000000000
                },
                {
                  "name": "OS - Windows",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    28.500000000,
                    28.500000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    600.00000,
                    600.00000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 3896.00000,
                  "yearlyUnitOverAllTotal": 270.000000000
                },
                {
                  "name": "OS - Mac",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    49.500000000,
                    49.500000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    678.00000,
                    678.00000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 3896.00000,
                  "yearlyUnitOverAllTotal": 270.000000000
                },
                {
                  "name": "Database - MOT storage",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    2.500000000,
                    2.500000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    50.00000,
                    50.00000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 3896.00000,
                  "yearlyUnitOverAllTotal": 270.000000000
                },
                {
                  "name": "Other Hardware Others3",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    
                  ],
                  "quarterlyCostTotal": [
                    0.333333333,
                    0.333333333,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0.666666666,
                  "yearlyCostOverAllTotal": 0,
                  "yearlyUnitOverAllTotal": 0
                }
              ]
            },
            "yearlyUnitCostList": null
          },
          {
            "name": "Others",
            "monthlyCostTypes": null,
            "yearlyCostType": null,
            "costTypeTotal": 0,
            "costTypeOverAllTotal": 1.333333332,
            "individualYearSummaryForQuarterly": {
              "2019": 0.666666666,
              "2020": 0.666666666
            },
            "quarterlyCostType": {
              "2019": [
                0.333333333,
                0.333333333,
                0,
                0
              ],
              "2020": [
                0.333333333,
                0.333333333,
                0,
                0
              ]
            },
            "monthlyCostSummary": null,
            "quarterlyCostSummary": null,
            "yearlyCostSummary": null,
            "monthlyUnitCostList": null,
            "quarterlyUnitCostList": {
              "2019": [
                {
                  "name": "Project Management",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    
                  ],
                  "quarterlyCostTotal": [
                    0.333333333,
                    0.333333333,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 1.333333332,
                  "yearlyCostOverAllTotal": 0,
                  "yearlyUnitOverAllTotal": 0
                }
              ],
              "2020": [
                {
                  "name": "Others5",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    
                  ],
                  "quarterlyCostTotal": [
                    0.333333333,
                    0.333333333,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 1.333333332,
                  "yearlyCostOverAllTotal": 0,
                  "yearlyUnitOverAllTotal": 0
                }
              ]
            },
            "yearlyUnitCostList": null
          },
          {
            "name": "Software",
            "monthlyCostTypes": null,
            "yearlyCostType": null,
            "costTypeTotal": 0,
            "costTypeOverAllTotal": 1636.000000000,
            "individualYearSummaryForQuarterly": {
              "2020": 1636.000000000
            },
            "quarterlyCostType": {
              "2020": [
                818.000000000,
                818.000000000,
                0,
                0
              ]
            },
            "monthlyCostSummary": null,
            "quarterlyCostSummary": null,
            "yearlyCostSummary": null,
            "monthlyUnitCostList": null,
            "quarterlyUnitCostList": {
              "2020": [
                {
                  "name": "IBM - Dashboard",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    4.000000000,
                    4.000000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    92.000000000,
                    92.000000000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 1636.000000000,
                  "yearlyUnitOverAllTotal": 39.000000000
                },
                {
                  "name": "IBM - Lotus",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    1.500000000,
                    1.500000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    36.000000000,
                    36.000000000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 1636.000000000,
                  "yearlyUnitOverAllTotal": 39.000000000
                },
                {
                  "name": "Microsoft - Messagner",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    2.000000000,
                    2.000000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    90.000000000,
                    90.000000000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 1636.000000000,
                  "yearlyUnitOverAllTotal": 39.000000000
                },
                {
                  "name": "Oracle - OraSQL",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    6.000000000,
                    6.000000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    540.000000000,
                    540.000000000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 1636.000000000,
                  "yearlyUnitOverAllTotal": 39.000000000
                },
                {
                  "name": "Oracle - SQLClient",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    6.000000000,
                    6.000000000,
                    0,
                    0
                  ],
                  "quarterlyCostTotal": [
                    60.000000000,
                    60.000000000,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0,
                  "yearlyCostOverAllTotal": 1636.000000000,
                  "yearlyUnitOverAllTotal": 39.000000000
                },
                {
                  "name": "Other Software Others2",
                  "currencyCode": "SGD",
                  "currencyValue": "2500",
                  "periodType": "quarterly",
                  "units": null,
                  "costs": null,
                  "quarterlyUnitTotal": [
                    
                  ],
                  "quarterlyCostTotal": [
                    0.333333333,
                    0.333333333,
                    0,
                    0
                  ],
                  "yearlyUnitTotal": [
                    
                  ],
                  "yearlyCostTotal": [
                    
                  ],
                  "unitOverAllTotal": 0,
                  "costOverAllTotal": 0.666666666,
                  "yearlyCostOverAllTotal": 0,
                  "yearlyUnitOverAllTotal": 0
                }
              ]
            },
            "yearlyUnitCostList": null
          }
        ],
        "individualYearSummaryForQuarterly":{
          "2020": 1948.00000,
        }
      }
  ]
}

export const YearlyDataForBreakdownByCost ={
  "name": "Breakdown by cost type",
  "costSettingsViewList": [
      {
          "name": "HLE",
          "monthlyCostSettings": null,
          "quarterlyCostSettings": null,
          "yearlyCostSettings": {
              "2020": 1636.000000000
          },
          "costSettingsTotal": 0,
          "costSettingsOverAllTotal": 1636.000000000,
          "costTypeCategoryViewList": [
              {
                  "name": "Hardware",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {},
                  "yearlyCostType": {
                      "2020": 0
                  },
                  "costTypeTotal": 0,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {}
              },
              {
                  "name": "Others",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {},
                  "yearlyCostType": {
                      "2020": 580.000000000
                  },
                  "costTypeTotal": 580.000000000,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {}
              },
              {
                  "name": "Resource",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {},
                  "yearlyCostType": {
                      "2020": 0
                  },
                  "costTypeTotal": 0,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {}
              },
              {
                  "name": "Software",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {},
                  "yearlyCostType": {
                      "2020": 1056.000000000
                  },
                  "costTypeTotal": 1056.000000000,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {}
              }
          ],
          "individualYearSummaryForQuarterly": null
      },
      {
          "name": "Seed Funding",
          "monthlyCostSettings": null,
          "quarterlyCostSettings": null,
          "yearlyCostSettings": {
              "2019": 55.000000000,
              "2020": 550.000000000
          },
          "costSettingsTotal": 0,
          "costSettingsOverAllTotal": 605.000000000,
          "costTypeCategoryViewList": [
              {
                  "name": "Hardware",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {},
                  "yearlyCostType": {
                      "2019": 0,
                      "2020": 110.000000000
                  },
                  "costTypeTotal": 110.000000000,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {}
              },
              {
                  "name": "Others",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {},
                  "yearlyCostType": {
                      "2019": 0,
                      "2020": 110.000000000
                  },
                  "costTypeTotal": 110.000000000,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {}
              },
              {
                  "name": "Resource",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {},
                  "yearlyCostType": {
                      "2019": 0,
                      "2020": 0
                  },
                  "costTypeTotal": 0,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {}
              },
              {
                  "name": "Software",
                  "monthlyCostTypes": [
                      0
                  ],
                  "quarterlyCostType": {},
                  "yearlyCostType": {
                      "2019": 55.000000000,
                      "2020": 110.000000000
                  },
                  "costTypeTotal": 165.000000000,
                  "costTypeOverAllTotal": 0,
                  "individualYearSummaryForQuarterly": {}
              }
          ],
          "individualYearSummaryForQuarterly": null
      },
      {
        "name": "Financial Details",
        "monthlyCostSettings": null,
        "quarterlyCostSettings": null,
        "yearlyCostSettings": null,
        "costSettingsTotal": 0,
        "costSettingsOverAllTotal": 0,
        "costTypeCategoryViewList": [
            {
                "name": "Hardware",
                "monthlyCostTypes": null,
                "yearlyCostType": {
                    "2020": 3896.00000
                },
                "costTypeTotal": 0,
                "costTypeOverAllTotal": 3896.00000,
                "individualYearSummaryForQuarterly": null,
                "quarterlyCostType": null,
                "monthlyCostSummary": null,
                "quarterlyCostSummary": null,
                "yearlyCostSummary": null,
                "monthlyUnitCostList": null,
                "quarterlyUnitCostList": null,
                "yearlyUnitCostList": {
                    "2020": [
                        {
                            "name": "OS - Linux",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                45.000000000
                            ],
                            "yearlyCostTotal": [
                                1000.00000
                            ],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0,
                            "yearlyUnitOverAllTotal": 0
                        },
                        {
                            "name": "OS - Solaris",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                54.000000000
                            ],
                            "yearlyCostTotal": [
                                140.00000
                            ],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0,
                            "yearlyUnitOverAllTotal": 0
                        },
                        {
                            "name": "OS - Windows",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                57.000000000
                            ],
                            "yearlyCostTotal": [
                                1200.00000
                            ],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0,
                            "yearlyUnitOverAllTotal": 0
                        },
                        {
                            "name": "OS - Mac",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                99.000000000
                            ],
                            "yearlyCostTotal": [
                                1356.00000
                            ],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0,
                            "yearlyUnitOverAllTotal": 0
                        },
                        {
                            "name": "Database - MOT storage",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                5.000000000
                            ],
                            "yearlyCostTotal": [
                                100.00000
                            ],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0,
                            "yearlyUnitOverAllTotal": 0
                        },
                        {
                            "name": "Database - CAS storage",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                10.000000000
                            ],
                            "yearlyCostTotal": [
                                100.00000
                            ],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0,
                            "yearlyUnitOverAllTotal": 0
                        },
                        {
                            "name": "Other Hardware Others3",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                0.666666666
                            ],
                            "yearlyCostTotal": [],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0.666666666,
                            "yearlyUnitOverAllTotal": 0
                        }
                    ]
                }
            },
            {
                "name": "Others",
                "monthlyCostTypes": null,
                "yearlyCostType": {
                    "2019": 0.666666666,
                    "2020": 0.666666666
                },
                "costTypeTotal": 0,
                "costTypeOverAllTotal": 1.333333332,
                "individualYearSummaryForQuarterly": null,
                "quarterlyCostType": null,
                "monthlyCostSummary": null,
                "quarterlyCostSummary": null,
                "yearlyCostSummary": null,
                "monthlyUnitCostList": null,
                "quarterlyUnitCostList": null,
                "yearlyUnitCostList": {
                    "2019": [
                        {
                            "name": "Project Management",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                0.666666666
                            ],
                            "yearlyCostTotal": [],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 1.333333332,
                            "yearlyUnitOverAllTotal": 0
                        }
                    ],
                    "2020": [
                        {
                            "name": "Others5",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                0.666666666
                            ],
                            "yearlyCostTotal": [],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 1.333333332,
                            "yearlyUnitOverAllTotal": 0
                        }
                    ]
                }
            },
            {
                "name": "Resource",
                "monthlyCostTypes": null,
                "yearlyCostType": null,
                "costTypeTotal": 0,
                "costTypeOverAllTotal": 0,
                "individualYearSummaryForQuarterly": null,
                "quarterlyCostType": null,
                "monthlyCostSummary": null,
                "quarterlyCostSummary": null,
                "yearlyCostSummary": null,
                "monthlyUnitCostList": null,
                "quarterlyUnitCostList": null,
                "yearlyUnitCostList": null
            },
            {
                "name": "Software",
                "monthlyCostTypes": null,
                "yearlyCostType": {
                    "2020": 1636.000000000
                },
                "costTypeTotal": 0,
                "costTypeOverAllTotal": 1636.000000000,
                "individualYearSummaryForQuarterly": null,
                "quarterlyCostType": null,
                "monthlyCostSummary": null,
                "quarterlyCostSummary": null,
                "yearlyCostSummary": null,
                "monthlyUnitCostList": null,
                "quarterlyUnitCostList": null,
                "yearlyUnitCostList": {
                    "2020": [
                        {
                            "name": "IBM - Dashboard",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                8.000000000
                            ],
                            "yearlyCostTotal": [
                                184.000000000
                            ],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0,
                            "yearlyUnitOverAllTotal": 0
                        },
                        {
                            "name": "IBM - Lotus",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                3.000000000
                            ],
                            "yearlyCostTotal": [
                                72.000000000
                            ],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0,
                            "yearlyUnitOverAllTotal": 0
                        },
                        {
                            "name": "Microsoft - Messagner",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                4.000000000
                            ],
                            "yearlyCostTotal": [
                                180.000000000
                            ],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0,
                            "yearlyUnitOverAllTotal": 0
                        },
                        {
                            "name": "Oracle - OraSQL",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                12.000000000
                            ],
                            "yearlyCostTotal": [
                                1080.000000000
                            ],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0,
                            "yearlyUnitOverAllTotal": 0
                        },
                        {
                            "name": "Oracle - SQLClient",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                12.000000000
                            ],
                            "yearlyCostTotal": [
                                120.000000000
                            ],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0,
                            "yearlyUnitOverAllTotal": 0
                        },
                        {
                            "name": "Other Software Others2",
                            "currencyCode": "SGD",
                            "currencyValue": "2500",
                            "periodType": "yearly",
                            "units": null,
                            "costs": null,
                            "quarterlyUnitTotal": [],
                            "quarterlyCostTotal": [],
                            "yearlyUnitTotal": [
                                0.666666666
                            ],
                            "yearlyCostTotal": [],
                            "unitOverAllTotal": 0,
                            "costOverAllTotal": 0,
                            "yearlyCostOverAllTotal": 0.666666666,
                            "yearlyUnitOverAllTotal": 0
                        }
                    ]
                }
            }
        ],
        "individualYearSummaryForQuarterly": null
    },
  ]
}