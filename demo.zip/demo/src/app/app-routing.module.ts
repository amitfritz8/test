import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LoggedinGuard } from "./common/guards/login.guards";
import { PreLoggedinGuard } from "./common/guards/pre-login.guards";

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    canActivate: [PreLoggedinGuard]
  },
  {
    path: 'home',
    loadChildren: () => import('src/app/common/module/appcommon.module').then(m => m.AppCommonModule),
    canActivate: [LoggedinGuard]
  },
  {
    path: 'not_found',
    loadChildren: () => import('src/app/not-found/not-found-routing.module').then(m => m.NotFoundRoutingModule)
  },
  {
    path: "",
    redirectTo: "login",
    pathMatch: "full"
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

