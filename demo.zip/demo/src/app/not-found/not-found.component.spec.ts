import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {NotFoundComponent} from './not-found.component';
import {configureTestSuite} from 'ng-bullet';

describe('NotFoundComponent', () => {
  let component: NotFoundComponent;
  let fixture: ComponentFixture<NotFoundComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [NotFoundComponent]
    })
    fixture = TestBed.createComponent(NotFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });
})
;
