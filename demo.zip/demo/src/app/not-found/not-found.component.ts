import {Component} from '@angular/core';

@Component({
    template: ` 
        <div class="container">
            <h1>Sorry, You don't have access</h1>
        </div>`,
})
export class NotFoundComponent {
};
