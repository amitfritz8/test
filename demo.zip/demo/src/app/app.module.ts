import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { MaterialModule } from './material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { OverlayModule } from '@angular/cdk/overlay';

// motamo
import { MatomoModule } from 'ngx-matomo';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from "./login/login.component";
import { LoaderComponent } from "./common/component/loader/loader.component";
import { LoginService } from "./login/login.service";
import { LoggedinGuard } from "./common/guards/login.guards";
import { PreLoggedinGuard } from "./common/guards/pre-login.guards";
import { AppInterceptor } from "./common/interceptor/app.interceptor";
import { AppConfigService } from "./common/service/app-config.service";
import { CstWindow } from "./common/service/window.service";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { DateUtility } from 'src/app/common/utility/date-utility';

import { DatePipe } from '@angular/common';

import { MAT_SNACK_BAR_DEFAULT_OPTIONS } from "@angular/material/snack-bar";
import { CommonService } from 'src/app/common/service/common.service';

const IMPORTMODULES = [BrowserModule, AppRoutingModule, MaterialModule, FormsModule, ReactiveFormsModule, HttpClientModule, MatomoModule, BrowserAnimationsModule, NgbModule, OverlayModule];
const DECALARATIONMODULES = [AppComponent, LoginComponent, LoaderComponent];

@NgModule({
  declarations: DECALARATIONMODULES,
  imports: IMPORTMODULES,
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AppInterceptor,
      multi: true
    },
    {
      provide: MAT_SNACK_BAR_DEFAULT_OPTIONS,
      useValue: {
        duration: 2000
      }
    },
    LoginService,
    PreLoggedinGuard,
    LoggedinGuard,
    AppConfigService,
    CstWindow,
    DateUtility,
    CommonService,
    DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
