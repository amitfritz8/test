import { NgModule } from "@angular/core";
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../common/module/shared.module';

const routes: Routes = [
  {
    path: 'genericsummary',
    loadChildren:  () => import('src/app/admin/generic-data-summary/generic-data-summary-routing.module').then(m => m.GenericDataSummaryRoutingModule)
  },
  {
    path: 'genericvalue',
    loadChildren: () => import('src/app/admin/generic-data-value/generic-data-value-routing.module').then(m => m.GenericDataValueRoutingModule)
  },
  {
    path: 'nongenericData',
    loadChildren: () => import('src/app/admin/non-generic-data/non-generic-data-routing.module').then(m => m.NonGenericDataRoutingModule)
  },
  {
    path: '',
    redirectTo: 'genericsummary',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule
  ],
  declarations: [

  ],
  exports: [
  ],
  entryComponents: []
})

export class AdminRoutingModule {}
