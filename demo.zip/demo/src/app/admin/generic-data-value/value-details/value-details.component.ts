import { Component, OnInit, AfterViewInit, Input, Output, EventEmitter, Attribute } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, FormArray, Validators, FormControl } from '@angular/forms';
import { RestService } from 'src/app/common/service/rest.service';
import { MatDialog } from '@angular/material/dialog';
import { DataService } from 'src/app/common/service/data.service';
import {CommonDialogComponent} from '../../../common/component/dialogues/common-dialog/common-dialog-component';
import {CommonService} from '../../../common/service/common.service';

@Component({
  selector: 'app-value-details',
  templateUrl: './value-details.component.html',
  styleUrls: ['./value-details.component.scss']
})
export class ValueDetailsComponent implements OnInit {

  @Input() action: string;
  @Input() element: any;
  @Input() selectedValue: any;
  @Output() back: EventEmitter<boolean> = new EventEmitter();
  attrList: any;
  initialData: any = [];
  valueForm: FormGroup;
  submitted = false;
  datavalues: any = [];
  isErrorExists:boolean = false;
  msg: string;
  // test : any = ['weight', 'symbol']

  constructor(private fb: FormBuilder, private route: ActivatedRoute, private router: Router,private dataService : DataService,
    private restService: RestService, public dialog: MatDialog, private commonService: CommonService) {
    this.restService.track('GENERIC VALUE DETAILS');
  }

  ngOnInit() {
    if (this.element) {
      this.datavalues = [];
      let group = {};
      for (var prop in this.element) {
        // creating data object to be displayed dynamically on ui
        this.datavalues.push({ 'key': prop, 'value': this.element[prop], 'maxlength': 1000 });

        //creating dynamic form fields
        group[prop] = [this.element[prop], [Validators.required, Validators.maxLength(1000)]]
      }
      this.initialData = this.fb.group(group).value;
      this.valueForm = this.fb.group(group);
    }

    //defaulting active status for add new page.
    if (this.action === 'add' && this.element.hasOwnProperty('Status')) {
      this.valueForm.patchValue({
        Status: 'active',
      });
    }
  }

  // Edit form
  editForm() {
    this.action = 'edit';
  }

  goback() {
    this.back.emit(true);
  }
  // Save Action
  save() {
    const controls = this.valueForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        this.valueForm.controls[name].markAsTouched();
      }
    }
    if (this.valueForm.invalid) {
      this.valueForm.markAllAsTouched();
    } else if (this.valueForm.valid) {
      // Assigning form values to object
      for (let i = 0; i < this.datavalues.length; i++) {
        if (this.valueForm.controls.hasOwnProperty(this.datavalues[i].key)) {
          this.datavalues[i].value = this.valueForm.controls[this.datavalues[i].key].value;
          //console.log(i + ' ' + this.datavalues[i] + ' ' + this.datavalues[i].value);
        }
      }
      let requestObj = {};
      for (let j = 0; j < this.datavalues.length; j++) {
        if (this.action === 'add' && this.datavalues[j].key != 'id') {
          requestObj[this.datavalues[j].key] = this.datavalues[j].value;
        } else if (this.action !== 'add') {
          requestObj[this.datavalues[j].key] = this.datavalues[j].value;
        }
      }
      let status = '';
      for (let j = 0; j < this.datavalues.length; j++) {
        if (this.datavalues[j].key === 'Status') {
          //console.log(this.datavalues[j].key + '' + this.datavalues[j].value);
          status = this.datavalues[j].value;
        }
      }

      let dataObject = { 'dataValues': requestObj };
      //console.log(this.valueForm.controls.Status);
      if (this.action === 'edit') {
        //console.log(this.datavalues);
        if (status === 'inactive' && this.initialData['Status'] === 'active') {
          const dialogRef = this.dialog.open(CommonDialogComponent, {
            data: {
              type: 'alert',
              contentTitle: "Set to Inactive?",
              content: `Your request to set Ref Data Type to "Inactive" will result in associated Ref Data Values to be no longer available for selection.'`,
              cancelTxt: 'Cancel',
              confirmTxt: 'Set Inactive'
            }
          });
          dialogRef.afterClosed().subscribe(result => {
            if (result === 'yes') {
              this.restService.put(`/people/data/dataValues/values?id=${requestObj['id']}&code=${requestObj['code']}`, dataObject).subscribe(data => {
                this.back.emit(true);
              });
            }
          });
        }
        else {
          this.restService.put(`/people/data/dataValues/values?id=${requestObj['id']}&code=${requestObj['code']}`, dataObject).subscribe(data => {

            if(data['errorFlag']!== null)
            {
            this.isErrorExists= true;
            this.dataService.getCustomMessage(data['message']);
            this.dataService.getFlag(data['errorFlag']);
              this.commonService.showSnackBar({
                type: 'success',
                message: data.message
              });
           }
          });
        }
      } else if (this.action === 'add') {
        if (status === 'inactive' && this.valueForm.controls.Status.touched && this.valueForm.controls.Status.dirty) {
          const dialogRef = this.dialog.open(CommonDialogComponent, {
            data: {
              type: 'alert',
              contentTitle: 'Set to Inactive?',
              content: 'Your request to set Ref Data Type to "Inactive" will result in associated Ref Data Values to be no longer available for selection.',
              cancelTxt: 'Cancel',
              confirmTxt: 'Set Inactive'
            }
          });
          dialogRef.afterClosed().subscribe(result => {
            if (result === 'yes') {
              this.restService.post(`/people/data/dataValues/values/${requestObj['code']}`, dataObject).subscribe(data => {
                this.back.emit(true);
              });
            }
          });
        }
        else {
          this.restService.post(`/people/data/dataValues/values/${requestObj['code']}`, dataObject).subscribe(data => {
          //  this.back.emit(true);
          if(data['errorFlag']!== null)
          {
          this.isErrorExists= true;
          this.dataService.getCustomMessage(data['message']);
          this.dataService.getFlag(data['errorFlag']);
            this.commonService.showSnackBar({
              type: 'success',
              message: data.message
            });
         }
          });
        }
      }
    }
  }
  // convenience getters for easy access to form fields
  get f() { return this.valueForm.controls; }
}
