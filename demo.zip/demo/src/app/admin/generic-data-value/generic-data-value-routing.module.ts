import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {SharedModule} from '../../common/module/shared.module';
import {GenericDataValueComponent} from './generic-data-value.component';
import {ValueDetailsComponent} from './value-details/value-details.component';

const routes: Routes = [
  {path: '', component: GenericDataValueComponent},
  {path: 'value-details', component : ValueDetailsComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule
  ],
  declarations: [GenericDataValueComponent, ValueDetailsComponent]
})

export class GenericDataValueRoutingModule {
}
