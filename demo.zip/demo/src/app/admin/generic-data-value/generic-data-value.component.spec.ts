// import {async, ComponentFixture, TestBed, fakeAsync} from '@angular/core/testing';

// import {GenericDataValueComponent} from './generic-data-value.component';
// import {FormsModule} from '@angular/forms';
// import {NO_ERRORS_SCHEMA} from '@angular/core';
// import {MaterialModule} from 'src/app/material.module';
// import { RestService } from 'src/app/common/service/rest.service';
// import { DataService } from 'src/app/common/service/data.service';
// import {DataTableService} from 'src/app/common/service/dataTable.service';
// import {NoopAnimationsModule} from '@angular/platform-browser/animations';
// import {of} from 'rxjs';
// import {HttpClientTestingModule} from '@angular/common/http/testing';
// import {RouterTestingModule} from '@angular/router/testing';
// import {configureTestSuite} from 'ng-bullet';

// describe('GenericDataValueComponent', () => {
//   let component: GenericDataValueComponent;
//   let fixture: ComponentFixture<GenericDataValueComponent>;
//   configureTestSuite(() => {
//     TestBed.configureTestingModule({
//       imports: [MaterialModule, FormsModule, HttpClientTestingModule,
//         RouterTestingModule, NoopAnimationsModule],
//       schemas: [NO_ERRORS_SCHEMA],
//       declarations: [GenericDataValueComponent],
//       providers: [{provide: RestService, useClass: MockRestService}, DataService, DataTableService]
//     })
//     fixture = TestBed.createComponent(GenericDataValueComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('should call for getTableData', (done: DoneFn) => {
//     spyOn(component, 'getTableData').and.callThrough();
//     component.getTableData();
//     expect(component.getTableData).toHaveBeenCalled();
//     done();
//   });

//   it('should call for applyFilter', (done: DoneFn) => {
//     spyOn(component, 'applyFilter').and.callThrough();
//     component.applyFilter('test');
//     expect(component.applyFilter).toHaveBeenCalled();
//     done();
//   });

//   it('should call for onBackClicked', (done: DoneFn) => {
//     component.detailsview = false;
//     spyOn(component, 'getTableData');
//     component.onBackClicked('test');
//     expect(component.getTableData).toHaveBeenCalled();
//     done();
//   });

//   it('should call for onRefDataSelection', (done: DoneFn) => {

//     component.refDataList = [{key: 'abc', value: 'abc'}];

//     spyOn(component, 'onRefDataSelection').and.callThrough();
//     component.onRefDataSelection({value: 'abc'});
//     expect(component.onRefDataSelection).toHaveBeenCalled();
//     done();
//   });

//   it('should call for getDisplayColumns', (done: DoneFn) => {
//     spyOn(component, 'getDisplayColumns').and.callThrough();
//     component.getDisplayColumns();
//     expect(component.getDisplayColumns).toHaveBeenCalled();
//     done();
//   });

//   it('should call for ngAfterViewInit', (done: DoneFn) => {
//     spyOn(component, 'ngAfterViewInit').and.callThrough();
//     component.ngAfterViewInit();
//     expect(component.ngAfterViewInit).toHaveBeenCalled();
//     done();
//   });

//   it('should call for getDataForDataType', (done: DoneFn) => {
//     spyOn(component, 'getDataForDataType').and.callThrough();
//     component.getDataForDataType();
//     expect(component.getDataForDataType).toHaveBeenCalled();
//     done();
//   });

//   it('should call for gotoDetails', (done: DoneFn) => {
//     spyOn(component, 'gotoDetails').and.callThrough();
//     component.gotoDetails({Status: 'abc'}, 'test');
//     expect(component.gotoDetails).toHaveBeenCalled();
//     done();
//   });

//   it('should call for gotoDetails', (done: DoneFn) => {
//     spyOn(component, 'gotoDetails').and.callThrough();
//     component.gotoDetails('test', 'test');
//     expect(component.gotoDetails).toHaveBeenCalled();
//     done();
//   });

//   it('should call for sortData', (done: DoneFn) => {
//     spyOn(component, 'sortData').and.callThrough();
//     component.sortData('test');
//     expect(component.sortData).toHaveBeenCalled();
//     done();
//   });

//   it('should call for getFilterValues', (done: DoneFn) => {
//     spyOn(component, 'getFilterValues').and.callThrough();
//     component.getFilterValues('test');
//     expect(component.getFilterValues).toHaveBeenCalled();
//     done();
//   });
// });

// class MockRestService {
//   get() {
//     return of([
//       {
//         'dataValues': {
//           'id': '107',
//           'code': '1075',
//           'adas': 'active',
//           'Status': 'active'
//         }
//       }
//     ]);
//   }

//   post(url, data) {
//     return of(['201907']);
//   }
//   track(pageName: string) {
//     return null;
//   }
// }
