import {TestBed} from '@angular/core/testing';
import {AdminRoutingModule} from 'src/app/admin/admin-routing.module';
import {configureTestSuite} from 'ng-bullet';

describe('AdminRoutingModule', () => {
  let service: AdminRoutingModule;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      // schemas: [NO_ERRORS_SCHEMA],
      providers: [AdminRoutingModule]
    })
    service = TestBed.get(AdminRoutingModule);
  });

  it('should create', () => {
    expect(service).toBeTruthy();
    expect(service).toBeDefined();
  });
});
