import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { RestService } from '../../common/service/rest.service';
import { SummaryData, Attributes } from '../../common/model/generic-ref-data';
import { Subscription } from 'rxjs';
import { DataService } from '../../common/service/data.service';
import { CommonService } from "src/app/common/service/common.service";

@Component({
  selector: 'app-generic-data-summary',
  templateUrl: './generic-data-summary.component.html',
  styleUrls: ['./generic-data-summary.component.scss']
})
export class GenericDataSummaryComponent implements OnInit, AfterViewInit {

  displayedColumns: string[] = ['code', 'name', 'status', 'goldenSource', 'interimSource',
    'owner1Bankid', 'ownerDeptname', 'updateMethod', 'updateFreq', 'seeMore','edit'];
  dataSource: MatTableDataSource<SummaryData> = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  detailsview: boolean = false;
  action: string = '';
  element: any;
  subscription: Subscription;
  searchText: string = '';

  constructor(private restService: RestService, private dataService: DataService, private commonService: CommonService) {
    this.restService.track('GENERIC DATA SUMMARY');
    this.dataSource = new MatTableDataSource();

    this.subscription = this.dataService.getMessage().subscribe(message => {
      if (this.detailsview == true) {
        this.getData();
      }
    });

    this.commonService.recieveMessage({
      title: "Generic Ref Data Summary"
    })
  }

  ngOnInit() {
    this.getData();
    this.searchText = "";
    this.commonService.setDocumentTitle('ADMIN GENERIC DATA SUMMARY');
    this.commonService.trackPageView();
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  gotoDetails(event, element, action) {

    if (action !== 'add') {
      this.restService.get(`/people/data/dataSummary/values/${element.code}`).subscribe(data => {
        this.detailsview = true;
        this.action = action;
        data['dataSummary'].status = data['dataSummary'].status.toLowerCase();
        this.element = data;
      });
    } else {
      var dataSummary = new SummaryData('', '', '', '', '', '', '', '', '', '', '', '', '', '');
      var attributes = [{ attrNo: 1, attr: '' }];
      this.detailsview = true;
      this.action = action;
      this.element = { 'dataSummary': dataSummary, 'attributes': attributes };
    }
  }

  getData() {
    this.restService.get(`/people/data/dataSummary/values`).subscribe(data => {
      data.forEach(element => {
        if (element['status'] !== null) {
          element['status'] = element['status'].toUpperCase();
        }
      });
      this.dataSource.data = data;
      this.dataSource.sort = this.sort;
      this.dataSource.sortingDataAccessor = (data, header) => {
        if (typeof (data[header]) != 'number') {
          return data[header].toString().toLowerCase();
        } else {
          return data[header];
        }
      }
      this.dataSource.paginator = this.paginator;
      this.dataSource.filter = '';
    });
    this.detailsview = false;
  }

  onBackClicked(e) {
    this.getData();
  }

  getPaginationClass(dataSource: any): string{
    if(!dataSource || dataSource.data.length === 0){
      return 'hide';
    }
    return 'visible';
  }

  getStatusClass(status: string):string{
    if(status.toLowerCase()==='active'){
      return 'completed'
    } else if(status.toLowerCase()==='inactive'){
      return 'inactive';
    } else if(status.toLowerCase()==='planned'){
      return 'pending';
    }
  }
}
