import { Component, OnInit, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { RestService } from 'src/app/common/service/rest.service';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { PortfolioDialogComponent } from 'src/app/common/component/dialogues/portfolio-dialog/portfolio-dialog.component';
import { MatSort } from '@angular/material/sort';
import { DataTableService } from 'src/app/common/service/dataTable.service';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { DataService } from 'src/app/common/service/data.service';
import { CommonService } from 'src/app/common/service/common.service';
import { MatPaginator } from '@angular/material/paginator';
import { Subscription } from 'rxjs';
import * as _ from 'lodash';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonDialogComponent } from 'src/app/common/component/dialogues/common-dialog/common-dialog-component';
import { PortfolioService } from '../portfolio-details/portfolio.service';
import { CreateSnapshotComponent } from 'src/app/common/component/dialogues/create-snapshot/create-snapshot.component';

@Component({
  selector: 'app-portfolio-listing',
  templateUrl: './portfolio-listing.component.html',
  styleUrls: ['./portfolio-listing.component.scss']
})
export class PortfolioListingComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  displayedColumns: string[] = ['workType', 'portfolioName', 'platformName', 'budgetSystemOwner', 'budgetStatus'];
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  workTypeFilter = new FormControl('');
  portFolioNameFilter = new FormControl('');
  platformFilter = new FormControl('');
  bdgSysOwnerFilter = new FormControl('');
  bdgStatusFilter = new FormControl('');
  copyTo: Array<string>;
  copyFrom: Array<string>;
  filterValues = {
    workType: '',
    portfolioName: '',
    platformName: '',
    budgetSystemOwner: '',
    budgetStatus: '',
    portfolioId: ''
  };
  disableCreateSnapshot = true;
  showFilter = false;
  searchText = '';
  bdgSysOwnerList = [];
  platformList = [];
  bdgStatusList = [];
  workTypeList = [];
  workTypeSortOrder = {};
  dataLength: any;
  displayCount: number = 0;
  iniTotal: number = 0;
  enhTotal: number = 0;
  iniNewCount: number = 0;
  inflightCount: number = 0;
  otherCount: number = 0;
  refData = {
    'categoryList': []
  }
  scenario: any;
  respType: any = 'text';
  // observers
  uamsFilterSubscription: Subscription;
  pageSubscription: Subscription;
  reportingFlag = '';
  rprtDrpdown = [];

  constructor(private http: HttpClient, private restService: RestService, public dialog: MatDialog, private router: Router,
    private readonly dataTableService: DataTableService, private dataService: DataService, private commonService: CommonService, private ps: PortfolioService) {
    this.dataSource = new MatTableDataSource();
    const roles = JSON.parse(sessionStorage.getItem('roles'));
    for (var role in roles) {
      if (role === 'GENE_DBS_ADMIN' || role === 'GENE_DBS_FINANCE') {
        this.disableCreateSnapshot = false;
      }
    }
    this.restService.track('PORTFOLIO');
    this.commonService.recieveMessage({
      title: "Portfolio Listing",
      btns: {
        primary: {
          text: 'Create Portfolio',
          clbk: this.onCreatePortfolioClick.bind(this)
        },
        moreOptions: [
          {
            text: 'Create Snapshot',
            clbk: this.onCopyPortfolioClick.bind(this),
            disabled: this.disableCreateSnapshot
          }
        ]
      },
    });
    this.refData = {
      'categoryList': []
    }
  }

  ngOnInit() {
    this.reportingFlag = 'Yes,No';
    this.getDropdownListForFilter();
    this.getSnapshotDropdowns();
    this.scenario = 'Forecast';
    //this.restService.get(URL_PREFIX.PORTFOLIO + '/data/non-generic/scenario').subscribe(data => {
    this.restService.get('assets/json/mock/scenario.json').subscribe(data => {
      this.refData['categoryList'] = data
    });
    // this.getCurrencyCodeData();
    this.uamsFilterSubscription = this.commonService.broadCastMessage.subscribe(data => {
      this.getData();
      this.getPlaformList();
    });
  }
  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }
  applyFilter(filterValue: string) {
    if (this.showFilter) {
      this.showFilter = false;
    }
    for (var i in this.filterValues) {
      this.filterValues[i] = filterValue.trim().toLowerCase();
    }
    this.dataSource.filter = JSON.stringify(this.filterValues);
    this.dataSource.filterPredicate = this.dataTableService.tableFilterForSearch();
    this.dataLength = this.dataSource.filteredData.length;
    this.updateDisplayCount();
  }

  onCreatePortfolioClick() {
    // this.isErrorExists = false;
    // this.isSuccessMsg = false;
    const dialogRef = this.dialog.open(PortfolioDialogComponent, {
      data: {
        header: 'Create Portfolio',
        body: 'this is the body content'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      // this.errorData = result;
      if (result['errorFlag'] === '0') {
        //   //this.isSuccessMsg = true;
        //   this.dataService.getCustomMessage(result['message']);
        //   this.dataService.getFlag(result['errorFlag']);
      }
      this.getData();
    });

  }

  onCopyPortfolioClick() {
    const dialogRef = this.dialog.open(CreateSnapshotComponent, {
      data: {
        header: 'Copy Scenario to',
        copyTo: this.copyTo,
        copyFrom: this.copyFrom,
        copyToCallback: this.copyToCallback.bind(this)
      }
    });
  }
  copyToCallback(postData) {
    try {
      this.http.post(URL_PREFIX.PORTFOLIO + `/data/copy/copySnapshot`, postData, {
        headers: new HttpHeaders({ 'Authorization': 'Bearer ' + localStorage.getItem('access_token') }),
        responseType: this.respType
      }).subscribe(data => {
        this.dialog.open(CommonDialogComponent, {
          data: {
            type: 'success',
            contentTitle: "Snapshot created successfully",
            content: `All Data From the ${postData.scenarioFrom} Scenario has been copied to the activity as a new version`,
            confirmTxt: "Done"
          }
        });
      },
        err => {
          console.log(err);
        })
    } catch (e) {
      console.log(e);
    }
  }
  getSnapshotDropdowns() {
    try {
      this.ps.getFromData({ requestType: 'Portfolio' }).subscribe(
        data => {
          this.copyFrom = data;
        },
        err => {
          console.log(err);
        })
    } catch (e) {
      console.log(e);
    }
  }

  toggleFilter(e) {
    this.searchText = '';
    this.showFilter = !this.showFilter;
    if (this.filterValues) {
      for (let field in this.filterValues) {
        this.filterValues[field] = '';
      }
      this.dataSource.filter = JSON.stringify(this.filterValues);
    }
    this.workTypeFilter.setValue('');
    this.portFolioNameFilter.setValue('');
    this.platformFilter.setValue('');
    this.bdgStatusFilter.setValue('');
    this.bdgSysOwnerFilter.setValue('');
  }
  // getting empolyee status from db for statusList
  getDropdownListForFilter() {
    this.bdgStatusList = [];
    this.bdgSysOwnerList = [];
    this.platformList = [];
    this.workTypeList = [];
    const list = ['Budget Status', 'Budget System Owner', 'Work Type', 'PF_Reporting Flag_Listing'];
    this.restService.post(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues', list).subscribe(data => {
      data['Work Type'].forEach((element) => {
        this.workTypeList.push({ key: element.desc, value: element.value });
        this.workTypeSortOrder[element.desc] = element.attr1;
      });
      data['Budget Status'].forEach((element: { value: any; }) => {
        this.bdgStatusList.push({ key: element.value, value: element.value });
      });
      data['Budget System Owner'].forEach((element: { value: any; }) => {
        this.bdgSysOwnerList.push({ key: element.value, value: element.value });
      });
      data['PF_Reporting Flag_Listing'].forEach(element => {
        this.rprtDrpdown.push({ key: element.value, value: element.desc });
      });
      this.bdgStatusList.unshift({ key: 'all', value: 'All' });
      this.bdgSysOwnerList.unshift({ key: 'all', value: 'All' });
      this.workTypeList.unshift({ key: 'all', value: 'All' });
    });
  }
  getPlaformList() {
    this.platformList = [];
    let selecetdPlatforms = JSON.parse(sessionStorage.getItem('selectedPIwithNames'));
    selecetdPlatforms.forEach(element => {
      this.platformList.push({ key: element.platformIndex + ' - ' + element.platform, value: element.platformIndex + ' - ' + element.platform });
    });
    this.platformList.unshift({ key: 'all', value: 'All' });
  }
  // get table data
  getData() {

    const platform = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    let idAndRoles =
    {
      oneBankId: localStorage.getItem('userOneBankId'),
      roles: Object.keys(JSON.parse(sessionStorage.getItem('roles'))),
      locations: locations,
      platform: platform,
      scenario: this.scenario,
      reportingFlag: this.reportingFlag ? this.reportingFlag.split(',') : []
    }
    //this.restService.get(URL_PREFIX.PORTFOLIO + `/data/portfolio/listing?scenario=${this.scenario}`).subscribe(data => {
  //  this.restService.post(URL_PREFIX.PORTFOLIO + `/data/portfolio/listing`, idAndRoles).subscribe(data => {
    this.restService.get('assets/json/mock/listing.json').subscribe(data => {
  
  if(!_.isEmpty(this.workTypeSortOrder)){
        data.sort((a,b) => {
          if(a.workType && b.workType && !isNaN(this.workTypeSortOrder[a.workType]) && !isNaN(this.workTypeSortOrder[b.workType])){
            return +this.workTypeSortOrder[a.workType] - +this.workTypeSortOrder[b.workType];
          }
        });
      }

      this.dataSource.data = data;
      this.dataSource.sort = this.sort;
      this.dataSource.sortingDataAccessor = (data, header) => {
        if (this.displayedColumns.includes(header)) {
          if (typeof (data[header]) != 'number' && data[header]) {
            return data[header].toString().toLowerCase();
          } else {
            return data[header];
          }
        }
      }
      this.dataSource.sort = this.sort;
      this.dataLength = this.dataSource.data.length;
      this.dataSource.paginator = this.paginator;
      this.updateDisplayCount();
      this.pageSubscription = this.paginator.page.subscribe(v => {
        this.updateDisplayCount();
      });
      this.checkForUpdatedCounts(this.dataSource.data);
    });
    this.filterChanges();
  }

  ngOnDestroy() {
    this.pageSubscription ? this.pageSubscription.unsubscribe() : '';
    this.uamsFilterSubscription.unsubscribe();
  }

  updateDisplayCount() {
    this.displayCount = (this.paginator.pageIndex + 1) * 20 > this.dataLength ? this.dataLength : (this.paginator.pageIndex + 1) * 20;
  }

  filterChanges() {
    this.workTypeFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.workType = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
    this.portFolioNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.portfolioName = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
    this.platformFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.platformName = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
    this.bdgStatusFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.budgetStatus = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
    this.bdgSysOwnerFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.budgetSystemOwner = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
  }
  getMoreInfo(row) {
    sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID, row.portfolioId);
    sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME, row.portfolioName);
    this.dataService.sendMessageItemChange(WORK_HIERARCHY_CONST.PORTFOLIO);
    this.router.navigateByUrl('home/portfolio/createPortfolio/showPortfolio');
  }
  checkForUpdatedCounts(data) {
    this.updateCount(data);
    this.updateDisplayCount();
  }
  updateCount(data) {
    this.iniTotal = 0;
    this.iniNewCount = 0;
    this.inflightCount = 0;
    this.enhTotal = 0;
    this.otherCount = 0;
    data.forEach(element => {
      if (element['workType'] && element['workType'].toLowerCase() == 'ini') {
        this.iniTotal += 1;
      }
      if (element['workType'] && element['workType'].toLowerCase() == 'ini' && element['budgetStatus'] &&
        element['budgetStatus'].toLowerCase().includes('new')) {
        this.iniNewCount += 1;
      } else if (element['workType'] && element['workType'].toLowerCase() == 'ini' && element['budgetStatus'] &&
        element['budgetStatus'].toLowerCase().includes('inflight')) {
        this.inflightCount += 1;
      } else if (element['workType'] && element['workType'].toLowerCase() == 'ini') {
        this.otherCount += 1;
      }
      if (element['workType'] && element['workType'].toLowerCase() == 'enh') {
        this.enhTotal += 1;
      }
    });
  }
  clear_search() {
    this.searchText = '';
    this.applyFilter(this.searchText);
  }

  scenarioSelected(event) {
    this.scenario = event.value.trim();
    this.getData();
  }

  reportingFlagSelected(event) {
    this.reportingFlag = event.value.trim();
    this.getData();
  }
}

