import { Component, OnInit, Input, AfterViewInit, OnChanges, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { RestService } from 'src/app/common/service/rest.service';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import * as moment from 'moment';
import * as $ from 'jquery';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { DataService } from 'src/app/common/service/data.service';
import * as _ from 'lodash';
import { CommonService } from 'src/app/common/service/common.service';

@Component({
  selector: 'app-financial-summary',
  templateUrl: './financial-summary.component.html',
  styleUrls: ['./financial-summary.component.scss'],
  providers: [],
})
export class FinancialSummaryComponent implements OnInit, AfterViewInit, OnChanges {
  @Input() saveCliked;
  @Output() seedFundingUpdatedData = new EventEmitter<any>();
  currencyCode: any;
  category: any;
  selectedTimestamp: any;
  currencyDropDownList = [];
  refData = {
    'categoryList': [],
    'costType': [],
    'costSettings': []
  };
  showBreakdownByCost = false;
  panelOpenState = [];
  panelState = [];
  summaryData = [];
  dataHeaderList = {
    monthly: [],
    yearly: [],
    quarterly: []
  };
  currentDate: any;
  currentMonth: any;
  currentYear: any;
  currentQuarter: any;
  workStreamId = '';
  subWorkStreamId = '';
  subWorkStreamName = '';
  totalYearsList = [];
  selectedYear = '';
  quarterlyList = [];
  selectedQuarListIndex: any;
  yearlyList = [];
  selectedYListIndex: any;
  portfolioId: string;
  @Input() showCostSettings: any;
  @Input() editAction: Boolean;
  @Input() subWSchanged: any;
  @Input() moduleIndicator: string;
  financialSummaryObject = {
    'editObject': {},
    'seedFunding': {},
    'finDetails': {},
    'currencyCodes': [],
    'currencyCode': '',
    'seedFund_overallTotalDiff': 0,
    'FD_overallTotalDiff': 0,
    'seedFund_overallTotal': null,
    'FD_overallTotal': null
  };
  keyDates = {
    startDate: '',
    goLiveDate: '',
    depreStartDate: ''
  };
  depreMonthInd: any;
  userLoggedInCountry: any;
  scenarioDropdown: Array<string> = [];
  constructor(private router: Router, private restService: RestService, private dataService: DataService, private commonService: CommonService) {
  }

  ngOnInit() {
    this.summaryData = [];
    this.subWorkStreamId = sessionStorage.getItem('subWorkStreamId');
    this.subWorkStreamName = sessionStorage.getItem('subWorkstreamName');
    this.workStreamId = sessionStorage.getItem('workstreamID');
    this.portfolioId = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID);
    this.refData = {
      'categoryList': [],
      'costType': [],
      'costSettings': []
    };
    this.financialSummaryObject = {
      'editObject': {},
      'seedFunding': {},
      'finDetails': {},
      'currencyCodes': [],
      'currencyCode': '',
      'seedFund_overallTotalDiff': 0,
      'FD_overallTotalDiff': 0,
      'seedFund_overallTotal': null,
      'FD_overallTotal': null
    };
    this.quarterlyList = [];
    this.totalYearsList = [];
    this.keyDates = {
      startDate: '',
      goLiveDate: '',
      depreStartDate: ''
    };
    this.depreMonthInd = 11;
    this.yearlyList = [];
    this.category = 'Forecast';
    this.selectedTimestamp = 'monthly';
    this.currencyDropDownList = [];
    this.loadData();
    this.dataHeaderList = {
      monthly: ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec', 'total'],
      quarterly: ['q1', 'q2', 'q3', 'q4', 'total'],
      yearly: []
    };
    this.panelOpenState = [];
    this.panelState = [];
    this.userLoggedInCountry = localStorage.getItem('userLoggedInCountry');
    this.dataService.setScenario(this.category);
  }

  loadData() {
    this.getCurrencyCodes();
    this.getScenarioData();
    this.getCurrentMQY();
    this.getKeyDates();
  }

  ngAfterViewInit() {
    let wid = 0;
    // let editActionInd = this.editAction;
    $(window).scroll(function () {
      let currentScroll = $(window).scrollTop();
      if (currentScroll >= 150) {
        $('#titleDiv').addClass('sticky-header');
        $('#titleDiv').css({
          width: $('.summaryTypeDiv').width()
        })
      } else if (currentScroll < 200) {
        $('#titleDiv').removeClass('sticky-header');
        $('#titleDiv').css({
          width: '100%'
        });
        if (wid == 0) {
          wid = $('#titleDiv').width();
        }
      }
    });
    //updating editObject for seed funding
    this.financialSummaryObject.editObject = {
      "startDate": '',
      "goLiveDate": '',
      "scenario": this.category,
      "currencyCode": this.currencyCode,
      "currencyCodes": this.currencyDropDownList,
      "userLoggedInCountry": this.userLoggedInCountry,
      "monthlySeedFundingData": {},
      "monthlyFinancialDetailsResources": {},
      "workStreamId": this.workStreamId,
      "subWorkStreamId": this.subWorkStreamId,
      "subWorkStreamName": this.subWorkStreamName,
      "dateCreated": "",
      "modifiedDate": "",
      "createdBy": "",
      "modifiedBy": ""
    };
  }
  // Added to reflect changes when parent changes.
  ngOnChanges(): void {
    if (this.saveCliked) {
      this.seedFundingUpdatedData.emit(this.financialSummaryObject.editObject);
    }
    // if (sessionStorage.getItem('subWorkStreamId') && this.subWSchanged == sessionStorage.getItem('subWorkStreamId')) {
    //   this.ngOnInit();
    // }
  }
  //get currency code dropdown
  getCurrencyCodes() {
    if (this.moduleIndicator != 'portfolio') {
      this.restService.get(URL_PREFIX.PORTFOLIO + `/financial/currency-code?workStreamId=${this.workStreamId}`).subscribe(data => {
        this.currencyCode = data[0];
        sessionStorage.setItem(WORK_HIERARCHY_CONST.CURRENCY_CODE_TYPE, data[0]);
        this.financialSummaryObject.editObject['currencyCode'] = data[0];
        this.getTotalYears(true);
      });
      this.restService.get(URL_PREFIX.PORTFOLIO + `/financial/currency-codes?workStreamId=${this.workStreamId}`).subscribe(data => {
        this.currencyDropDownList = data;
        this.financialSummaryObject.editObject['currencyCodes'] = this.currencyDropDownList;
      })
    } else {
      this.currencyCode = "SGD";
      this.financialSummaryObject.editObject['currencyCode'] = this.currencyCode;
      this.currencyDropDownList = ["SGD"];
      this.financialSummaryObject.editObject['currencyCodes'] = this.currencyDropDownList;
      this.getTotalYears(true);
    }
  }
  //After selecting timestamp
  getDetails(timeFrame) {
    this.showBreakdownByCost = false;
    this.selectedTimestamp = timeFrame;
    if (timeFrame == 'monthly') {
      this.getMonthlyData();
    }
    else if (timeFrame == 'quarterly') {
      this.updateQuarterlyList();
      // setting header for display based upon selected range of years
      this.updateHearderForQuar();
      this.getQuarterlyData();
    } else if (timeFrame == 'yearly') {
      for (let i = 0; i < 10; i++) {
        this.dataHeaderList['yearly'][i] = this.totalYearsList[i] ? this.totalYearsList[i] : '';
      }
      this.getYearlyData();
    }
  }
  // after updating total num of years update quarterlyList
  updateQuarterlyList() {
    let numOfYears = this.totalYearsList.length;
    this.quarterlyList = [];
    let j = 0;
    // diving num of years in groups of 2 for display for quarter
    for (let i = 0; i < numOfYears; i++) {
      this.quarterlyList[j] = [];
      if (this.totalYearsList[i]) {
        this.quarterlyList[j].push(this.totalYearsList[i]);
      }
      if (this.totalYearsList[i + 1]) {
        this.quarterlyList[j].push(this.totalYearsList[i + 1]);
      }
      i = i + 1;
      j++;
    }
    // finding current year quarter
    for (let x = 0; x < this.quarterlyList.length; x++) {
      if (this.quarterlyList[x].includes(this.currentYear.toString()) || (!_.includes(this.totalYearsList, this.currentYear.toString())
        && this.quarterlyList[x].includes(this.totalYearsList[this.totalYearsList.length - 1]))) {
        this.selectedQuarListIndex = x;
      }
    }
  }
  //divide total num of years in groups of 10
  updateYearlyList() {
  }
  // updating dataHeaderList for quarterly selection
  updateHearderForQuar() {
    if (this.quarterlyList[this.selectedQuarListIndex].length == 2) {
      this.dataHeaderList['quarterly'] = ['q1', 'q2', 'q3', 'q4', 'total', 'q1', 'q2', 'q3', 'q4', 'total'];
    } else {
      this.dataHeaderList['quarterly'] = ['q1', 'q2', 'q3', 'q4', 'total', '', '', '', '', ''];
    }
  }
  //ref data values
  getRefData() {
    const list = ['cost type', 'cost settings'];
    this.restService.post(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues', list).subscribe(data => {
      data['cost type'].forEach((element: { value: any; desc: any; }) => {
        this.refData['costType'].push({ key: element.desc, value: element.value });
      });
      data['cost settings'].forEach((element: { value: any; desc: any; }) => {
        this.refData['costSettings'].push({ key: element.desc, value: element.value });
      });
      this.getMonthlyData();
    })
  }
  getScenarioData() {
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/non-generic/scenario').subscribe(
      data => {
        this.refData.categoryList = data;
      },
      err => {
        console.log(err);
      });
  }
  moveToCostSetting() {
    this.commonService.expandEvent.emit('costSetting');
    this.router.navigate(['/home/portfolio/createPortfolio/subworkstream/' + sessionStorage.getItem('subWorkStreamId') + '/cost-setting'], { state: { editAction: this.editAction } })
      .then(success => console.log('navigation success?', success))
      .catch(console.error);
    sessionStorage.setItem(WORK_HIERARCHY_CONST.SCENARIO, this.category);
  }
  getCurrentMQY() {
    let d = new Date();
    this.currentDate = d.getDate();
    this.currentMonth = d.getMonth();
    this.currentQuarter = moment().quarter();
    this.currentYear = d.getFullYear();
    // this.selectedYear = (this.currentYear).toString();
  }
  getTotalYears(isInitial: boolean) {
    let fin_year_get_url: string;

    if (this.moduleIndicator == 'portfolio') {
      fin_year_get_url = URL_PREFIX.PORTFOLIO + `/data/portfolio/listOfFinYears?portfolioId=${this.portfolioId}&scenario=${this.category}`
    }
    else if (this.moduleIndicator == 'workStream') {
      fin_year_get_url = URL_PREFIX.PORTFOLIO + `/data/workstream/listOfFinYears?workStreamId=${this.workStreamId}&scenario=${this.category}`
    } else {
      fin_year_get_url = URL_PREFIX.PORTFOLIO + `/financial/listOfFinYears?workStreamId=${this.workStreamId}&subWorkStreamId=${this.subWorkStreamId}
    &scenario=${this.category}&subWorkStreamName=${this.subWorkStreamName}`
    }
    this.restService.get(fin_year_get_url).subscribe(data => {
      if (data && data.length > 0) {
        this.totalYearsList = data.sort();
        if (_.includes(this.totalYearsList, this.currentYear.toString())) {
          this.selectedYear = this.currentYear.toString();
        } else {
          this.selectedYear = this.totalYearsList[this.totalYearsList.length - 1];
        }
      } else {
        this.totalYearsList = [this.currentYear.toString()];
        this.selectedYear = this.currentYear.toString();
      }
      if (isInitial) {
        this.getRefData();
      } else {
        if (this.selectedTimestamp == 'monthly') {
          this.getMonthlyData();
        } else if (this.selectedTimestamp = 'quarterly') {
          this.updateQuarterlyList();
          // setting header for display based upon selected range of years
          this.updateHearderForQuar();
          this.getQuarterlyData();
        } else {
          this.getYearlyData();
        }
      }
    });
  }
  getKeyDates() {
    this.restService.get(URL_PREFIX.PORTFOLIO + "/data/subworkstream/listOfKeyDates/" + this.subWorkStreamId + "/" + this.subWorkStreamName + "/" + this.category).subscribe(data => {
      if (data) {
        this.keyDates.startDate = data.startDate;
        this.keyDates.goLiveDate = data.goLiveDate;
        this.keyDates.depreStartDate = data.depreStartDate;
        this.depreMonthInd = this.keyDates.depreStartDate ? Number(this.keyDates.depreStartDate.substring(5, 7)) - 1 : 11;
        this.financialSummaryObject.editObject['startDate'] = this.keyDates.startDate;
        this.financialSummaryObject.editObject['goLiveDate'] = this.keyDates.goLiveDate;
      }
    });
  }
  scenarioSelected(e) {

    this.category = e.value;
    this.dataService.setScenario(this.category);
    this.getTotalYears(false);

  }
  currencySelected(e) {
    this.showBreakdownByCost = false;
    this.currencyCode = e.value;
    // this.getTotalYears();
    if (this.selectedTimestamp == 'monthly') {
      this.getMonthlyData();
    } else if (this.selectedTimestamp = 'quarterly') {
      this.updateQuarterlyList();
      // setting header for display based upon selected range of years
      this.updateHearderForQuar();
      this.getQuarterlyData();
    } else {
      this.getYearlyData();
    }
  }
  changePeriod(direction) {
    this.showBreakdownByCost = false;
    if (this.selectedTimestamp == 'monthly' && direction == 'prev') {
      for (let i = 0; i < this.totalYearsList.length; i++) {
        if (this.totalYearsList[i] == this.selectedYear && i !== 0) {
          this.selectedYear = this.totalYearsList[i - 1];
          break;
        }
      }
      this.getMonthlyData();
    } else if (this.selectedTimestamp == 'monthly' && direction == 'next') {
      for (let i = 0; i < this.totalYearsList.length; i++) {
        if (this.totalYearsList[i] == this.selectedYear && i !== (this.totalYearsList.length - 1)) {
          this.selectedYear = this.totalYearsList[i + 1];
          break;
        }
      }
      this.getMonthlyData();
    } else if (this.selectedTimestamp == 'quarterly' && direction == 'prev') {
      if (this.selectedQuarListIndex != 0) {
        this.selectedQuarListIndex = this.selectedQuarListIndex - 1;
        this.updateHearderForQuar();
        this.updateQuarterlyDataForFinSummary(this.summaryData[0]);
        this.updateQuarterlyDataForCostSetting(this.summaryData[1]);
      }
    } else if (this.selectedTimestamp == 'quarterly' && direction == 'next') {
      if (this.selectedQuarListIndex != this.quarterlyList.length - 1) {
        this.selectedQuarListIndex = this.selectedQuarListIndex + 1;
        this.updateQuarterlyDataForFinSummary(this.summaryData[0]);
        this.updateQuarterlyDataForCostSetting(this.summaryData[1]);
      }
    }

  }
  getMonthlyData() {
    this.summaryData = [];
    this.showBreakdownByCost = false;
    this.getMonthlyDataForFinancialCaseSummary();
  }
  getMonthlyDataForFinancialCaseSummary() {
    let fin_get_url: string;

    if (this.moduleIndicator == 'portfolio') {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/data/portfolio/breakdown-financial-data?scenario=${this.category}&ccyCode=${this.currencyCode}&portfolioId=${this.portfolioId}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    }
    else if (this.moduleIndicator == 'workStream') {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/data/workstream/breakdown-financial-data?scenario=${this.category}&ccyCode=${this.currencyCode}&workStreamId=${this.workStreamId}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    } else {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/financial/data?scenario=${this.category}&ccyCode=${this.currencyCode}&workStreamId=${this.workStreamId}&subWorkStreamId=${this.subWorkStreamId}&subWorkStreamName=${this.subWorkStreamName}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    }
    this.restService.get(fin_get_url).subscribe(data => {
      this.summaryData[0] = (data[this.category]);
      // for GL groups
      if (this.summaryData[0]['glGroups']) {
        this.getGlGroupMonthlyData(this.summaryData[0]['glGroups']);
      }
      this.managePanelStateForFinSummary();
      this.getMonthlyDataForBreakdownByCost();
    });
  }
  getGlGroupMonthlyData(e) {
    e.forEach(element => {
      if (element['monthlyFinanceTotal'].length == 0) {
        element['monthlyFinanceTotal'] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
      }
      // for glCategories
      element['glCategories'].forEach(d => {
        if (d['monthlyFinance'].length == 0) {
          d['monthlyFinance'] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        }
      });
    });
  }
  getMonthlyDataForBreakdownByCost() {
    let fin_get_url: string;
    if (this.moduleIndicator == 'portfolio') {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/data/portfolio/breakdown-cost-data?scenario=${this.category}&ccyCode=${this.currencyCode}&portfolioId=${this.portfolioId}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    }
    else if (this.moduleIndicator == 'workStream') {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/data/workstream/breakdown-cost-data?scenario=${this.category}&ccyCode=${this.currencyCode}&workStreamId=${this.workStreamId}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    } else {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/financial/breakDownCostData?scenario=${this.category}&ccyCode=${this.currencyCode}&workStreamId=${this.workStreamId}&subWorkStreamId=${this.subWorkStreamId}&subWorkStreamName=${this.subWorkStreamName}&period=${this.selectedYear}&periodType=${this.selectedTimestamp}`
    }
    this.restService.get(fin_get_url).subscribe(data => {
      this.summaryData[1] = (data[this.category]);
      // for breakdown by cost
      if (this.summaryData[1]['costSettingsViewList']) {
        this.getCostSettingResourceMonthlyData(this.summaryData[1]);
      }
      this.managePanelStateForCostSetting();
    });
  }
  getCostSettingResourceMonthlyData(e) {
    e['costSettingsViewList'].forEach((element, index) => {
      // In editmode checking for already updated data for selected year.
      let seedFundingCheck = (this.getKeyForRefData(this.refData['costSettings'], element.name) == 'seed_funding' &&
        this.financialSummaryObject['seedFunding'].hasOwnProperty(this.selectedYear) && this.financialSummaryObject['seedFunding'][this.selectedYear].name == element.name);
      let finDetailsCheck = (this.getKeyForRefData(this.refData['costSettings'], element.name) == 'fin_details' &&
        this.financialSummaryObject['finDetails'].hasOwnProperty(this.selectedYear) && this.financialSummaryObject['finDetails'][this.selectedYear].name == element.name)
      if (this.editAction && seedFundingCheck) {
        this.summaryData[1]['costSettingsViewList'][index] = this.financialSummaryObject['seedFunding'][this.selectedYear];
        this.summaryData[1]['costSettingsViewList'][index]['costSettingsOverAllTotal'] = this.financialSummaryObject.seedFund_overallTotal;
      } else if (this.editAction && finDetailsCheck) {
        this.summaryData[1]['costSettingsViewList'][index] = this.financialSummaryObject['finDetails'][this.selectedYear];
        this.summaryData[1]['costSettingsViewList'][index]['costSettingsOverAllTotal'] = this.financialSummaryObject.FD_overallTotal;
      } else {
        if (this.getKeyForRefData(this.refData['costSettings'], element.name) == 'seed_funding') {
          element['costSettingsOverAllTotal'] = this.financialSummaryObject.seedFund_overallTotal ? this.financialSummaryObject.seedFund_overallTotal : element['costSettingsOverAllTotal'];
        } else {
          element['costSettingsOverAllTotal'] = this.financialSummaryObject.FD_overallTotal ? this.financialSummaryObject.FD_overallTotal : element['costSettingsOverAllTotal'];
        }
        if (element['monthlyCostSettings'] && element['monthlyCostSettings'].length == 0 || !element['monthlyCostSettings']) {
          element['monthlyCostSettings'] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        }
        // for costTypeCategoryViewList
        element['costTypeCategoryViewList'].forEach(d => {
          if ((this.getKeyForRefData(this.refData['costSettings'], element.name) == 'fin_details') && d.name == 'Resource') {
            d['monthlyCostTypesResource'] = d['monthlyCostTypesResource'] || [];
            d['monthlyCostTypesResource'][0] = d['monthlyCostTypesResource'][0] || [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            d['monthlyCostTypesResource'][1] = d['monthlyCostTypesResource'][1] || [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            d['monthlyCostTypesResource'][2] = d['monthlyCostTypesResource'][2] || [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          }
          d['monthly'] = [];
          if (d['monthlyResources'] && d['monthlyResources'].length == 0 || !d['monthlyResources']) {
            d['monthlyResources'] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            for (let i = 0; i <= 11; i++) {
              d['monthly'].push({ monthNumber: i + 1, value: 0 });
            }
          } else if (d['monthlyResources'] && d['monthlyResources'].length > 0) {
            for (let i = 0; i <= 11; i++) {
              d['monthly'][i] = d['monthlyResources'][i] ? d['monthlyResources'][i] : { value: 0, surrId: '', monthNumber: i + 1 };
            }
          }
        });
        if ((this.getKeyForRefData(this.refData['costSettings'], element.name) == 'fin_details')) {
          this.getJsonFormatForFD(element);
        }
      }
    });
    this.showBreakdownByCost = true;
  }
  managePanelStateForFinSummary() {
    this.panelOpenState[0] = [];
    if (this.summaryData[0]['glGroups']) {
      for (let i = 0; i < this.summaryData[0]['glGroups'].length; i++) {
        this.panelOpenState[0].push(false);
      }
    }
  }
  managePanelStateForCostSetting() {
    this.panelOpenState[1] = [];
    if (this.summaryData[1]['costSettingsViewList']) {
      for (let i = 0; i < this.summaryData[1]['costSettingsViewList'].length; i++) {
        this.panelOpenState[1].push(false);
        if (this.summaryData[1]['costSettingsViewList'][i].name == 'Financial Details') {
          for (let j = 0; j < this.summaryData[1]['costSettingsViewList'][i]['costTypeCategoryViewList'].length; j++) {
            this.panelState.push(false);
          }
        }
      }
    }
  }
  managePanelState() {
    this.summaryData.forEach((ele, index) => {
      this.panelOpenState[index] = [];
      if (ele['glGroups'])
        for (let i = 0; i < ele['glGroups'].length; i++) {
          this.panelOpenState[index].push(false);
        }
    });
  }
  // modifying FD data for UI.
  getJsonFormatForFD(e) {
    e['costTypeCategoryViewList'].forEach(category => {
      if (category['monthlyUnitCostList']) {
        category['unitCostList'] = [];
        category['monthlyUnitCostList'].forEach(item => {
          item['monthlyResourcesCosts'] = item['monthlyResourcesCosts'] || [];
          for (let i = 0; i <= 11; i++) {
            item['monthlyResourcesCosts'][i] = item['monthlyResourcesCosts'][i] ? item['monthlyResourcesCosts'][i] : { value: 0, surrId: '', monthNumber: i + 1 };
          }
          if (category.name != 'Resource') {
            //creating new list for ease in html for showing cost and unit.
            item['unitCostDetails'] = [];
            if (item['monthlyResourcesUnits']) {
              item['unitCostDetails'].push({
                'title': 'Unit',
                'monthly': item['monthlyResourcesUnits'],
                'monthlyTotal': 0,
                'overAllSum': item.unitOverAllTotal
              })
            }
            item['unitCostDetails'].push({
              'title': 'Cost',
              'monthly': item['monthlyResourcesCosts'],
              'monthlyTotal': _.sumBy(item['monthlyResourcesCosts'], 'value'),
              'overAllSum': item.yearlyCostOverAllTotal
            });
          } else {
            //creating new list for ease in html for showing cost and unit.
            item['unitCostDetails'] = [];
            if (item['monthlyResourcesFTEs']) {
              item['unitCostDetails'].push({
                'title': 'FTE',
                'monthly': item['monthlyResourcesFTEs'],
                'monthlyTotal': 0,
                'overAllSum': 0
              });
            }
            if (item['monthlyResourcesAllocations']) {
              item['unitCostDetails'].push({
                'title': '%alloc',
                'monthly': item['monthlyResourcesAllocations'],
                'monthlyTotal': 0,
                'overAllSum': 0
              });
            }
            if (item['monthlyResourcesManDays']) {
              item['unitCostDetails'].push({
                'title': 'Man-days',
                'monthly': item['monthlyResourcesManDays'],
                'monthlyTotal': 0,
                'overAllSum': 0
              });
            }
            item['unitCostDetails'].push({
              'title': 'Cost',
              'monthly': item['monthlyResourcesCosts'],
              'monthlyTotal': _.sumBy(item['monthlyResourcesCosts'], 'value'),
              'overAllSum': item.costOverAllTotal
            });
          }
          category['unitCostList'].push(item);
        });
      }
    });
  }

  getQuarterlyData() {
    this.summaryData = [];
    this.getQuarterlyDataForFinancialCaseSummary();
  }
  getQuarterlyDataForFinancialCaseSummary() {
    let fin_get_url: string;
    if (this.moduleIndicator == 'portfolio') {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/data/portfolio/breakdown-financial-data?scenario=${this.category}&ccyCode=${this.currencyCode}&portfolioId=${this.portfolioId}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    }
    else if (this.moduleIndicator == 'workStream') {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/data/workstream/breakdown-financial-data?scenario=${this.category}&ccyCode=${this.currencyCode}&workStreamId=${this.workStreamId}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    } else {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/financial/data?scenario=${this.category}&ccyCode=${this.currencyCode}&workStreamId=${this.workStreamId}&subWorkStreamId=${this.subWorkStreamId}&subWorkStreamName=${this.subWorkStreamName}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    }
    this.restService.get(fin_get_url).subscribe(data => {
      this.summaryData[0] = (data[this.category]);
      this.updateQuarterlyDataForFinSummary(this.summaryData[0]);
      this.managePanelStateForFinSummary();
      this.getQuarterlyDataForBreakdownByCost();
    });
  }
  getQuarterlyDataForBreakdownByCost() {
    let fin_get_url: string;
    if (this.moduleIndicator == 'portfolio') {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/data/portfolio/breakdown-cost-data?scenario=${this.category}&ccyCode=${this.currencyCode}&portfolioId=${this.portfolioId}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    }
    else if (this.moduleIndicator == 'workStream') {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/data/workstream/breakdown-cost-data?scenario=${this.category}&ccyCode=${this.currencyCode}&workStreamId=${this.workStreamId}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    } else {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/financial/breakDownCostData?scenario=${this.category}&ccyCode=${this.currencyCode}&workStreamId=${this.workStreamId}&subWorkStreamId=${this.subWorkStreamId}&subWorkStreamName=${this.subWorkStreamName}&period=${this.selectedYear}&periodType=${this.selectedTimestamp}`
    }
    this.restService.get(fin_get_url).subscribe(data => {
      this.summaryData[1] = (data[this.category]);
      this.updateQuarterlyDataForCostSetting(this.summaryData[1]);
      this.managePanelStateForCostSetting();
    });
  }
  updateQuarterlyDataForCostSetting(e) {
    //for cost Settings
    e['costSettingsViewList'].forEach(element => {
      element['quarterly'] = [];
      element['QCostSettings'] = {};
      element['QCostSettings'] = Object.assign({}, element['quarterlyCostSettings']);
      var checkEmpty = !element['quarterlyCostSettings'] || (_.isEmpty(element['quarterlyCostSettings'])) ||
        (this.quarterlyList[this.selectedQuarListIndex][0] && !(_.has(element['quarterlyCostSettings'], this.quarterlyList[this.selectedQuarListIndex][0]))) ||
        (this.quarterlyList[this.selectedQuarListIndex][1] && !(_.has(element['quarterlyCostSettings'], this.quarterlyList[this.selectedQuarListIndex][1])));
      if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 1) {
        element['QCostSettings'] = {};
        element['QCostSettings'][this.quarterlyList[this.selectedQuarListIndex][0]] = [0, 0, 0, 0];
      } else if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 2) {
        if (!_.has(element['quarterlyCostSettings'], this.quarterlyList[this.selectedQuarListIndex][0])) {
          element['QCostSettings'][this.quarterlyList[this.selectedQuarListIndex][0]] = [0, 0, 0, 0];
        }
        if (!_.has(element['quarterlyCostSettings'], this.quarterlyList[this.selectedQuarListIndex][1])) {
          element['QCostSettings'][this.quarterlyList[this.selectedQuarListIndex][1]] = [0, 0, 0, 0];
        }
      } else if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 0) {
        element['QCostSettings'] = {};
        element['QCostSettings'][this.currentYear] = [0, 0, 0, 0];
      }
      let keys = Object.keys(element['QCostSettings']);
      let firstYear = this.quarterlyList[this.selectedQuarListIndex][0];
      let secondYear = this.quarterlyList[this.selectedQuarListIndex][1];
      for (let i = 0; i < keys.length; i++) {
        if (keys[i] == firstYear) {
          if (element['QCostSettings'] && element['QCostSettings'][firstYear]) {
            element['QCostSettings'][firstYear].forEach(v => {
              element['quarterly'].push(v);
            });
          } else {
            element['quarterly'] = [0, 0, 0, 0];
          }
          element['quarterly'].push(element['individualYearSummaryForQuarterly'][firstYear] ? element['individualYearSummaryForQuarterly'][firstYear] : "");
        } else if (keys[i] == secondYear) {
          if (element['QCostSettings'] && element['QCostSettings'][secondYear]) {
            element['QCostSettings'][secondYear].forEach(v => {
              element['quarterly'].push(v);
            });
          } else {
            element['quarterly'] = element['quarterly'].concat([0, 0, 0, 0]);
          }
          element['quarterly'].push(element['individualYearSummaryForQuarterly'][secondYear] ? element['individualYearSummaryForQuarterly'][secondYear] : "");
        }
      }
      if (!firstYear && element['quarterly'].length == 0) {
        for (let j = 0; j < 5; j++) {
          element['quarterly'].push('');
        }
      }
      if (!secondYear && element['quarterly'].length == 5) {
        for (let j = 0; j < 5; j++) {
          element['quarterly'].push('');
        }
      }
      // for Cost Types
      element['costTypeCategoryViewList'].forEach(ele => {
        if ((this.getKeyForRefData(this.refData['costSettings'], element.name) == 'fin_details') && ele.name == 'Resource') {
          this.getCostTypeTotalListforResource(ele);
        } else {
          ele['quarterly'] = [];
          ele['QCostType'] = {};
          ele['QCostType'] = Object.assign({}, ele['quarterlyCostType']);
          var checkEmpty = !ele['quarterlyCostType'] || (_.isEmpty(ele['quarterlyCostType']))
            || (this.quarterlyList[this.selectedQuarListIndex][0] && !(_.has(ele['quarterlyCostType'], this.quarterlyList[this.selectedQuarListIndex][0]))) ||
            (this.quarterlyList[this.selectedQuarListIndex][1] && !(_.has(ele['quarterlyCostType'], this.quarterlyList[this.selectedQuarListIndex][1])));
          if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 1) {
            ele['QCostType'] = {};
            ele['QCostType'][this.quarterlyList[this.selectedQuarListIndex][0]] = [0, 0, 0, 0];
          } else if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 2) {
            if (!ele['QCostType'] || (_.isEmpty(ele['QCostType']))) {
              ele['QCostType'] = {};
            }
            if (!(_.has(ele['QCostType'], this.quarterlyList[this.selectedQuarListIndex][0]))) {
              ele['QCostType'][this.quarterlyList[this.selectedQuarListIndex][0]] = [0, 0, 0, 0];
            }
            if (!(_.has(ele['QCostType'], this.quarterlyList[this.selectedQuarListIndex][1]))) {
              ele['QCostType'][this.quarterlyList[this.selectedQuarListIndex][1]] = [0, 0, 0, 0];
            }
          } else if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 0) {
            ele['QCostType'] = {};
            ele['QCostType'][this.currentYear] = [0, 0, 0, 0];
          }
          let keys = Object.keys(ele['QCostType']);
          let firstYear = this.quarterlyList[this.selectedQuarListIndex][0];
          let secondYear = this.quarterlyList[this.selectedQuarListIndex][1];
          for (let i = 0; i < keys.length; i++) {
            if (keys[i] == firstYear) {
              if (ele['QCostType'] && ele['QCostType'][firstYear]) {
                ele['QCostType'][firstYear].forEach(v => {
                  ele['quarterly'].push(v);
                });
              } else {
                ele['quarterly'] = [0, 0, 0, 0]
              }
              ele['quarterly'].push(ele['individualYearSummaryForQuarterly'] && ele['individualYearSummaryForQuarterly'][firstYear] ? ele['individualYearSummaryForQuarterly'][firstYear] : 0);
            } else if (keys[i] == secondYear) {
              if (ele['quarterly'] && ele['quarterly'].length == 0) {
                ele['quarterly'] = [0, 0, 0, 0, 0];
              }
              if (ele['QCostType'] && ele['QCostType'][secondYear]) {
                ele['QCostType'][secondYear].forEach(v => {
                  ele['quarterly'].push(v);
                });
              } else {
                ele['quarterly'] = ele['quarterly'].concat([0, 0, 0, 0]);
              }
              ele['quarterly'].push(ele['individualYearSummaryForQuarterly'] && ele['individualYearSummaryForQuarterly'][secondYear] ? ele['individualYearSummaryForQuarterly'][secondYear] : 0);
            }
          }
          if (!firstYear && ele['quarterly'].length == 0) {
            for (let j = 0; j < 5; j++) {
              ele['quarterly'].push('');
            }
          }
          if (!secondYear && ele['quarterly'].length == 5) {
            for (let j = 0; j < 5; j++) {
              ele['quarterly'].push('');
            }
          }
        }
      });
      //changes for financial Details
      if ((this.getKeyForRefData(this.refData['costSettings'], element.name) == 'fin_details')) {
        this.getJsonFormatForFDForQuarterly(element);
      }
    });
  }

  getCostTypeTotalListforResource(ele) {
    ele['quarterly'] = [];
    ele['QFTEType'] = {};
    ele['QMandaysType'] = {};
    ele['QCostType'] = {};
    ele['QFTEType'] = Object.assign({}, ele['quarterlyFTEType']);
    ele['QMandaysType'] = Object.assign({}, ele['quarterlyMandaysType']);
    ele['QCostType'] = Object.assign({}, ele['quarterlyCostType']);
    ele['quarterly'][0] = this.getQuarterlyCostTypeViewForResource(ele, 'QFTEType', 'quarterlyFTEType', 0);
    ele['quarterly'][1] = this.getQuarterlyCostTypeViewForResource(ele, 'QMandaysType', 'quarterlyMandaysType', 1);
    ele['quarterly'][2] = this.getQuarterlyCostTypeViewForResource(ele, 'QCostType', 'quarterlyCostType', 2);
  }
  getQuarterlyCostTypeViewForResource(ele, dummyList, actualList, index) {
    ele['quarterly'][index] = [];
    var checkEmpty = !ele[actualList] || (_.isEmpty(ele[actualList]))
      || (this.quarterlyList[this.selectedQuarListIndex][0] && !(_.has(ele[actualList], this.quarterlyList[this.selectedQuarListIndex][0]))) ||
      (this.quarterlyList[this.selectedQuarListIndex][1] && !(_.has(ele[actualList], this.quarterlyList[this.selectedQuarListIndex][1])));

    var checkEmptyForIndiResCost = !ele['individualYearSummaryForQuarterlyForResource'] || (_.isEmpty(ele['individualYearSummaryForQuarterlyForResource']))
      || (this.quarterlyList[this.selectedQuarListIndex][0] && !(_.has(ele['individualYearSummaryForQuarterlyForResource'], this.quarterlyList[this.selectedQuarListIndex][0]))) ||
      (this.quarterlyList[this.selectedQuarListIndex][1] && !(_.has(ele['individualYearSummaryForQuarterlyForResource'], this.quarterlyList[this.selectedQuarListIndex][1])));

    if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 1) {
      ele[dummyList] = {};
      ele[dummyList][this.quarterlyList[this.selectedQuarListIndex][0]] = [0, 0, 0, 0];
    } else if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 2) {
      if (!ele[dummyList] || (_.isEmpty(ele[dummyList]))) {
        ele[dummyList] = {};
      }
      if (!(_.has(ele[dummyList], this.quarterlyList[this.selectedQuarListIndex][0]))) {
        ele[dummyList][this.quarterlyList[this.selectedQuarListIndex][0]] = [0, 0, 0, 0];
      }
      if (!(_.has(ele[dummyList], this.quarterlyList[this.selectedQuarListIndex][1]))) {
        ele[dummyList][this.quarterlyList[this.selectedQuarListIndex][1]] = [0, 0, 0, 0];
      }
    } else if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 0) {
      ele[dummyList] = {};
      ele[dummyList][this.currentYear] = [0, 0, 0, 0];
    }
    let keys = Object.keys(ele[dummyList]);
    let firstYear = this.quarterlyList[this.selectedQuarListIndex][0];
    let secondYear = this.quarterlyList[this.selectedQuarListIndex][1];
    for (let i = 0; i < keys.length; i++) {
      if (keys[i] == firstYear) {
        if (ele[dummyList] && ele[dummyList][firstYear]) {
          ele[dummyList][firstYear].forEach(v => {
            ele['quarterly'][index].push(v);
          });
        } else {
          ele['quarterly'][index] = [0, 0, 0, 0]
        }
        ele['quarterly'][index].push(!checkEmptyForIndiResCost && ele['individualYearSummaryForQuarterlyForResource'][firstYear] ? ele['individualYearSummaryForQuarterlyForResource'][firstYear][index] : 0);
      } else if (keys[i] == secondYear) {
        if (ele['quarterly'][index] && ele['quarterly'][index].length == 0) {
          ele['quarterly'][index] = [0, 0, 0, 0, 0];
        }
        if (ele[dummyList] && ele[dummyList][secondYear]) {
          ele[dummyList][secondYear].forEach(v => {
            ele['quarterly'][index].push(v);
          });
        } else {
          ele['quarterly'][index] = ele['quarterly'][index].concat([0, 0, 0, 0]);
        }
        ele['quarterly'][index].push(!checkEmptyForIndiResCost && ele['individualYearSummaryForQuarterlyForResource'][secondYear] ? ele['individualYearSummaryForQuarterlyForResource'][secondYear][index] : 0);
      }
    }
    if (!firstYear && ele['quarterly'][index].length == 0) {
      for (let j = 0; j < 5; j++) {
        ele['quarterly'][index].push('');
      }
    }
    if (!secondYear && ele['quarterly'][index].length == 5) {
      for (let j = 0; j < 5; j++) {
        ele['quarterly'][index].push('');
      }
    }
    return ele['quarterly'][index];
  }

  getJsonFormatForFDForQuarterly(e) {
    e['costTypeCategoryViewList'].forEach(item => {
      item['unitCostListOfAll'] = [];
      item['unitCostList'] = [];
      item['quarterlyUnitCostList'] = item['quarterlyUnitCostList'] ? item['quarterlyUnitCostList'] : {};
      let keys = Object.keys(item['quarterlyUnitCostList']);
      let firstYear = this.quarterlyList[this.selectedQuarListIndex][0];
      let secondYear = this.quarterlyList[this.selectedQuarListIndex][1];
      for (let i = 0; i < keys.length; i++) {
        if (keys[i] == firstYear) {
          if (item['quarterlyUnitCostList'] && item['quarterlyUnitCostList'][firstYear]) {
            item['quarterlyUnitCostList'][firstYear].forEach(v => {
              v['year'] = firstYear;
              item['unitCostListOfAll'].push(v);
            });
          }
        }
        if (keys[i] == secondYear) {
          if (item['quarterlyUnitCostList'] && item['quarterlyUnitCostList'][secondYear]) {
            item['quarterlyUnitCostList'][secondYear].forEach(v => {
              v['year'] = secondYear;
              item['unitCostListOfAll'].push(v);
            });
          }
        }
      }
      if (item.name == 'Resource') {
        this.getUnitCostDetailsListForResourceForFD(item, firstYear, secondYear);
      } else {
        item['unitCostListOfAll'].forEach(i => {
          i['QCostTotal'] = [];
          i['QUnitTotal'] = [];
        });
        item['unitCostList'] = _.unionBy(item['unitCostListOfAll'], 'refSurrId');
        item['unitCostList'].forEach(uniq => {
          uniq.QCostTotal = (!uniq.quarterlyCostTotal || (uniq.quarterlyCostTotal && uniq.quarterlyCostTotal.length == 0)) ? [0, 0, 0, 0] : Object.assign([], uniq.quarterlyCostTotal);
          uniq.QCostTotal.push(_.sum(uniq.quarterlyCostTotal));
          if (uniq.quarterlyUnitTotal && !_.isEmpty(uniq.quarterlyUnitTotal)) {
            uniq.QUnitTotal = Object.assign([], uniq.quarterlyUnitTotal);
            uniq.QUnitTotal.push(0);
          }
          item['unitCostListOfAll'].forEach(all => {
            if (uniq.refSurrId == all.refSurrId && uniq.year != all.year) {
              all.QCostTotal = (!all.quarterlyCostTotal || (all.quarterlyCostTotal && all.quarterlyCostTotal.length == 0)) ? [0, 0, 0, 0] : Object.assign([], all.quarterlyCostTotal);
              all.QCostTotal.push(_.sum(all.quarterlyCostTotal));
              if (all.quarterlyUnitTotal && !_.isEmpty(all.quarterlyUnitTotal)) {
                all.QUnitTotal = Object.assign([], all.quarterlyUnitTotal);
                all.QUnitTotal.push(0);
              }
              if (uniq.year == firstYear) {
                uniq.QCostTotal = uniq.QCostTotal.concat(all.QCostTotal);
                if (uniq.quarterlyUnitTotal && !_.isEmpty(uniq.quarterlyUnitTotal)) {
                  uniq.QUnitTotal = uniq.QUnitTotal.concat(all.QUnitTotal);
                }
              } else if (uniq.year == secondYear) {
                uniq.QCostTotal = all.QCostTotal.concat(uniq.QCostTotal);
                if (all.quarterlyUnitTotal && !_.isEmpty(all.quarterlyUnitTotal)) {
                  uniq.QUnitTotal = all.QUnitTotal.concat(uniq.QUnitTotal);
                }
              }
            }
          });
          if (uniq.QCostTotal && uniq.QCostTotal.length == 5) {
            if (uniq.year == firstYear) {
              uniq.QCostTotal = uniq.QCostTotal.concat([0, 0, 0, 0, 0]);
            } else if (uniq.year == secondYear) {
              uniq.QCostTotal = ([0, 0, 0, 0, 0]).concat(uniq.QCostTotal);
            } else if (!secondYear) {
              uniq.QCostTotal = uniq.QCostTotal.concat([0, 0, 0, 0, 0]);
            }
          }
          if (uniq.QUnitTotal && uniq.QUnitTotal.length == 5) {
            if (uniq.year == firstYear) {
              uniq.QUnitTotal = uniq.QUnitTotal.concat([0, 0, 0, 0, 0]);
            } else if (uniq.year == secondYear) {
              uniq.QUnitTotal = ([0, 0, 0, 0, 0]).concat(uniq.QUnitTotal);
            } else if (!secondYear) {
              uniq.QUnitTotal = uniq.QUnitTotal.concat([0, 0, 0, 0, 0]);
            }
          }
        });
        item['unitCostList'].forEach(costUnit => {
          //creating new list for ease in html for showing cost and unit.
          costUnit['unitCostDetails'] = [];
          if (costUnit.QUnitTotal && !_.isEmpty(costUnit.QUnitTotal)) {
            costUnit['unitCostDetails'].push({
              'title': 'Unit',
              'quarterly': costUnit.QUnitTotal,
              'overAllSum': 0
            })
          }
          costUnit['unitCostDetails'].push({
            'title': 'Cost',
            'quarterly': costUnit.QCostTotal,
            'overAllSum': costUnit.yearlyCostOverAllTotal
          });
        });
        // rearranging json so that others are at bottom.
        item['unitCostList'].sort((a, b) => (a.name.substring(0, 5) == 'Other' && b.name.substring(0, 5) != 'Other') ? 1 : -1);
      }
    });
    this.showBreakdownByCost = true;
  }

  getUnitCostDetailsListForResourceForFD(item, firstYear, secondYear) {
    item['unitCostListOfAll'].forEach(i => {
      i['QCostTotal'] = [];
    });
    item['unitCostList'] = _.unionBy(item['unitCostListOfAll'], 'refSurrId');
    item['unitCostList'].forEach(costUnit => {
      //creating new list for ease in html for showing cost and unit.
      costUnit['unitCostDetails'] = [];
    });
    this.getListOfDisplayOfResourceForFD(item, firstYear, secondYear, 'QFTETotal', 'quarterlyFTETotal', 'FTE');
    this.getListOfDisplayOfResourceForFD(item, firstYear, secondYear, 'QAllocTotal', 'quarterlyAllocationTotal', '%alloc');
    this.getListOfDisplayOfResourceForFD(item, firstYear, secondYear, 'QManDayTotal', 'quarterlyMandaysTotal', 'Man-days');
    this.getListOfDisplayOfResourceForFD(item, firstYear, secondYear, 'QCostTotal', 'quarterlyCostTotal', 'Cost');
  }

  getListOfDisplayOfResourceForFD(item, firstYear, secondYear, dummyList, actualList, type) {
    item['unitCostList'].forEach(uniq => {
      if (type == 'Cost') {
        uniq[dummyList] = (!uniq[actualList] || (uniq[actualList] && uniq[actualList].length == 0)) ? [0, 0, 0, 0] : Object.assign([], uniq[actualList]);
        uniq[dummyList].push(_.sum(uniq[actualList]));
      } else {
        if (uniq[actualList] && !_.isEmpty(uniq[actualList])) {
          uniq[dummyList] = Object.assign([], uniq[actualList]);
          (type == 'Man-days') ? uniq[dummyList].push(_.sum(uniq[actualList])) : uniq[dummyList].push(0);
        }
      }
      item['unitCostListOfAll'].forEach(all => {
        if (uniq.refSurrId == all.refSurrId && uniq.year != all.year) {
          if (type == 'Cost') {
            all[dummyList] = (!all[actualList] || (all[actualList] && all[actualList].length == 0)) ? [0, 0, 0, 0] : Object.assign([], all[actualList]);
            all[dummyList].push(_.sum(all[actualList]));
          } else {
            if (all[actualList] && !_.isEmpty(all[actualList])) {
              all[dummyList] = Object.assign([], all[actualList]);
              (type == 'Man-days') ? all[dummyList].push(_.sum(all[actualList])) : all[dummyList].push(0);
            }
          }
          if (uniq[dummyList] && uniq.year == firstYear) {
            if (uniq[actualList] && !_.isEmpty(uniq[actualList])) {
              uniq[dummyList] = uniq[dummyList].concat(all[dummyList]);
            }
          } else if (uniq[dummyList] && uniq.year == secondYear) {
            if (all[actualList] && !_.isEmpty(all[actualList])) {
              uniq[dummyList] = all[dummyList].concat(uniq[dummyList]);
            }
          }
        }
      });
      if (uniq[dummyList] && uniq[dummyList].length == 5) {
        if (uniq.year == firstYear) {
          uniq[dummyList] = uniq[dummyList].concat([0, 0, 0, 0, 0]);
        } else if (uniq.year == secondYear) {
          uniq[dummyList] = ([0, 0, 0, 0, 0]).concat(uniq[dummyList]);
        } else if (!secondYear) {
          uniq[dummyList] = uniq[dummyList].concat([0, 0, 0, 0, 0]);
        }
      }
    });
    item['unitCostList'].forEach(costUnit => {
      //creating new list for ease in html for showing cost and unit.
      if (costUnit[dummyList] && !_.isEmpty(costUnit[dummyList])) {
        if (type == 'Cost') {
          costUnit['unitCostDetails'].push({
            'title': type,
            'quarterly': costUnit[dummyList],
            'overAllSum': costUnit.yearlyCostOverAllTotal
          })
        } else {
          costUnit['unitCostDetails'].push({
            'title': type,
            'quarterly': costUnit[dummyList],
            'overAllSum': 0
          })
        }
      }
    });
    // rearranging json so that others are at bottom.
    item['unitCostList'].sort((a, b) => (a.name.substring(0, 5) == 'Other' && b.name.substring(0, 5) != 'Other') ? 1 : -1);
  }

  updateQuarterlyDataForFinSummary(e) {
    //for GL groups
    e['glGroups'].forEach(element => {
      element['quarterly'] = [];
      element['QSummary'] = {};
      element['QSummary'] = Object.assign({}, element['quarterlySummary']);
      var checkEmpty = !element['quarterlySummary'] || (_.isEmpty(element['quarterlySummary'])) ||
        (this.quarterlyList[this.selectedQuarListIndex][0] && !(_.has(element['quarterlySummary'], this.quarterlyList[this.selectedQuarListIndex][0]))) ||
        (this.quarterlyList[this.selectedQuarListIndex][1] && !(_.has(element['quarterlySummary'], this.quarterlyList[this.selectedQuarListIndex][1])));
      if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 1) {
        element['QSummary'] = {};
        element['QSummary'][this.quarterlyList[this.selectedQuarListIndex][0]] = [0, 0, 0, 0];
      } else if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 2) {
        if (!_.has(element['quarterlySummary'], this.quarterlyList[this.selectedQuarListIndex][0])) {
          element['QSummary'][this.quarterlyList[this.selectedQuarListIndex][0]] = [0, 0, 0, 0];
        }
        if (!_.has(element['quarterlySummary'], this.quarterlyList[this.selectedQuarListIndex][1])) {
          element['QSummary'][this.quarterlyList[this.selectedQuarListIndex][1]] = [0, 0, 0, 0];
        }
      } else if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 0) {
        element['QSummary'] = {};
        element['QSummary'][this.currentYear] = [0, 0, 0, 0];
      }
      let keys = Object.keys(element['QSummary']);
      let firstYear = this.quarterlyList[this.selectedQuarListIndex][0];
      let secondYear = this.quarterlyList[this.selectedQuarListIndex][1];
      for (let i = 0; i < keys.length; i++) {
        if (keys[i] == firstYear) {
          if (element['QSummary'] && element['QSummary'][firstYear]) {
            element['QSummary'][firstYear].forEach(v => {
              element['quarterly'].push(v);
            });
          } else {
            element['quarterly'] = [0, 0, 0, 0];
          }
          element['quarterly'].push(element['individualYearSummaryForQuarterly'][firstYear] ? element['individualYearSummaryForQuarterly'][firstYear] : "");
        } else if (keys[i] == secondYear) {
          if (element['QSummary'] && element['QSummary'][secondYear]) {
            element['QSummary'][secondYear].forEach(v => {
              element['quarterly'].push(v);
            });
          } else {
            element['quarterly'] = element['quarterly'].concat([0, 0, 0, 0]);
          }
          element['quarterly'].push(element['individualYearSummaryForQuarterly'][secondYear] ? element['individualYearSummaryForQuarterly'][secondYear] : "");
        }
      }
      if (!firstYear && element['quarterly'].length == 0) {
        for (let j = 0; j < 5; j++) {
          element['quarterly'].push('');
        }
      }
      if (!secondYear && element['quarterly'].length == 5) {
        for (let j = 0; j < 5; j++) {
          element['quarterly'].push('');
        }
      }
      // for GL categories
      element['glCategories'].forEach(ele => {
        ele['quarterly'] = [];
        ele['QFinance'] = {};
        ele['QFinance'] = Object.assign({}, ele['quarterlyFinance']);
        var checkEmpty = !ele['quarterlyFinance'] || (_.isEmpty(ele['quarterlyFinance']))
          || (this.quarterlyList[this.selectedQuarListIndex][0] && !(_.has(ele['quarterlyFinance'], this.quarterlyList[this.selectedQuarListIndex][0]))) ||
          (this.quarterlyList[this.selectedQuarListIndex][1] && !(_.has(ele['quarterlyFinance'], this.quarterlyList[this.selectedQuarListIndex][1])));
        if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 1) {
          ele['QFinance'] = {};
          ele['QFinance'][this.quarterlyList[this.selectedQuarListIndex][0]] = [0, 0, 0, 0];
        } else if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 2) {
          if (!ele['QFinance'] || (_.isEmpty(ele['QFinance']))) {
            ele['QFinance'] = {};
          }
          if (!(_.has(ele['QFinance'], this.quarterlyList[this.selectedQuarListIndex][0]))) {
            ele['QFinance'][this.quarterlyList[this.selectedQuarListIndex][0]] = [0, 0, 0, 0];
          }
          if (!(_.has(ele['QFinance'], this.quarterlyList[this.selectedQuarListIndex][1]))) {
            ele['QFinance'][this.quarterlyList[this.selectedQuarListIndex][1]] = [0, 0, 0, 0];
          }
        } else if (checkEmpty && this.quarterlyList[this.selectedQuarListIndex] && this.quarterlyList[this.selectedQuarListIndex].length == 0) {
          ele['QFinance'] = {};
          ele['QFinance'][this.currentYear] = [0, 0, 0, 0];
        }
        let keys = Object.keys(ele['QFinance']);
        let firstYear = this.quarterlyList[this.selectedQuarListIndex][0];
        let secondYear = this.quarterlyList[this.selectedQuarListIndex][1];
        for (let i = 0; i < keys.length; i++) {
          if (keys[i] == firstYear) {
            if (ele['QFinance'] && ele['QFinance'][firstYear]) {
              ele['QFinance'][firstYear].forEach(v => {
                ele['quarterly'].push(v);
              });
            } else {
              ele['quarterly'] = [0, 0, 0, 0]
            }
            ele['quarterly'].push(ele['individualYearSummaryForQuarterly'] && ele['individualYearSummaryForQuarterly'][firstYear] ? ele['individualYearSummaryForQuarterly'][firstYear] : 0);
          } else if (keys[i] == secondYear) {
            if (ele['quarterly'] && ele['quarterly'].length == 0) {
              ele['quarterly'] = [0, 0, 0, 0, 0];
            }
            if (ele['QFinance'] && ele['QFinance'][secondYear]) {
              ele['QFinance'][secondYear].forEach(v => {
                ele['quarterly'].push(v);
              });
            } else {
              ele['quarterly'] = ele['quarterly'].concat([0, 0, 0, 0]);
            }
            ele['quarterly'].push(ele['individualYearSummaryForQuarterly'] && ele['individualYearSummaryForQuarterly'][secondYear] ? ele['individualYearSummaryForQuarterly'][secondYear] : 0);
          }
        }
        if (!firstYear && ele['quarterly'].length == 0) {
          for (let j = 0; j < 5; j++) {
            ele['quarterly'].push('');
          }
        }
        if (!secondYear && ele['quarterly'].length == 5) {
          for (let j = 0; j < 5; j++) {
            ele['quarterly'].push('');
          }
        }
      });
    });
  }

  getYearlyData() {
    this.summaryData = [];
    this.getYearlyDataForFinancialCostSummary();
  }

  getYearlyDataForFinancialCostSummary() {
    let fin_get_url: string;
    if (this.moduleIndicator == 'portfolio') {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/data/portfolio/breakdown-financial-data?scenario=${this.category}&ccyCode=${this.currencyCode}&portfolioId=${this.portfolioId}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    }
    else if (this.moduleIndicator == 'workStream') {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/data/workstream/breakdown-financial-data?scenario=${this.category}&ccyCode=${this.currencyCode}&workStreamId=${this.workStreamId}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    } else {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/financial/data?scenario=${this.category}&ccyCode=${this.currencyCode}&workStreamId=${this.workStreamId}&subWorkStreamId=${this.subWorkStreamId}&subWorkStreamName=${this.subWorkStreamName}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    }
    this.restService.get(fin_get_url).subscribe(data => {
      this.summaryData[0] = (data[this.category]);
      this.summaryData[0]['glGroups'].forEach(element => {
        element['yearly'] = [];
        let yearly = Object.values(element['yearlySummary']);
        for (let i = 0; i < 10; i++) {
          element['yearly'][i] = yearly[i] ? yearly[i] : '';
        }
        // for glCategories
        element['glCategories'].forEach(ele => {
          ele['yearly'] = []
          let yearly = Object.values(ele['yearlySummary']);
          for (let i = 0; i < 10; i++) {
            ele['yearly'][i] = yearly[i] ? yearly[i] : '';
          }
        });
      })
      this.managePanelStateForFinSummary();
      this.getYearlyDataForBreakdownByCost();
    });
  }
  getYearlyDataForBreakdownByCost() {
    let fin_get_url: string;
    if (this.moduleIndicator == 'portfolio') {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/data/portfolio/breakdown-cost-data?scenario=${this.category}&ccyCode=${this.currencyCode}&portfolioId=${this.portfolioId}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    }
    else if (this.moduleIndicator == 'workStream') {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/data/workstream/breakdown-cost-data?scenario=${this.category}&ccyCode=${this.currencyCode}&workStreamId=${this.workStreamId}&period=${this.selectedYear}&typeOfData=${this.selectedTimestamp}`
    } else {
      fin_get_url = URL_PREFIX.PORTFOLIO + `/financial/breakDownCostData?scenario=${this.category}&ccyCode=${this.currencyCode}&workStreamId=${this.workStreamId}&subWorkStreamId=${this.subWorkStreamId}&subWorkStreamName=${this.subWorkStreamName}&period=${this.selectedYear}&periodType=${this.selectedTimestamp}`
    }
    this.restService.get(fin_get_url).subscribe(data => {
      this.summaryData[1] = (data[this.category]);
      this.summaryData[1]['costSettingsViewList'].forEach(element => {
        element['yearly'] = [];
        let checkEmpty = !element['yearlyCostSettings'] || (_.isEmpty(element['yearlyCostSettings']));
        if (checkEmpty) {
          element['yearlyCostSettings'] = {};
          for (let i = 0; i < this.totalYearsList.length; i++) {
            element['yearlyCostSettings'][this.totalYearsList[i]] = 0;
          }
        }
        let yearly = Object.values(element['yearlyCostSettings']);
        for (let i = 0; i < 10; i++) {
          element['yearly'][i] = yearly[i] ? yearly[i] : '';
        }
        // for costTypeCategoryViewList
        element['costTypeCategoryViewList'].forEach(ele => {
          ele['yearly'] = []
          if (ele.name == 'Resource' && (this.getKeyForRefData(this.refData['costSettings'], element.name) == 'fin_details')) {
            this.getYearlyCostTypeHeaderOfResourceForFD(ele, 'yearlyFTEType', 0);
            this.getYearlyCostTypeHeaderOfResourceForFD(ele, 'yearlyMandaysType', 1);
            this.getYearlyCostTypeHeaderOfResourceForFD(ele, 'yearlyCostType', 2);
          } else {
            let checkEmpty = !ele['yearlyCostType'] || (_.isEmpty(ele['yearlyCostType']));
            if (checkEmpty) {
              ele['yearlyCostType'] = {};
              for (let i = 0; i < this.totalYearsList.length; i++) {
                ele['yearlyCostType'][this.totalYearsList[i]] = 0;
              }
            }
            for (let i = 0; i < 10; i++) {
              ele['yearly'][i] = (this.totalYearsList[i] && ele['yearlyCostType'][this.totalYearsList[i]]) ? ele['yearlyCostType'][this.totalYearsList[i]] :
                (this.totalYearsList[i] && !ele['yearlyCostType'][this.totalYearsList[i]]) ? ((ele['yearlyCostType'][this.totalYearsList[i + 1]]) ? 0 : '') : '';
            }
          }
        });
        //changes for financial Details
        if ((this.getKeyForRefData(this.refData['costSettings'], element.name) == 'fin_details')) {
          this.getJsonFormatForFDForYearly(element);
        }
      })
      this.managePanelStateForCostSetting();
      this.showBreakdownByCost = true;
    });
  }
  getYearlyCostTypeHeaderOfResourceForFD(ele, type, index) {
    ele['yearly'][index] = [];
    let checkEmpty = !ele[type] || (_.isEmpty(ele[type]));
    if (checkEmpty) {
      ele[type] = {};
      for (let i = 0; i < this.totalYearsList.length; i++) {
        ele[type][this.totalYearsList[i]] = 0;
      }
    }
    for (let i = 0; i < 10; i++) {
      ele['yearly'][index][i] = (this.totalYearsList[i] && ele[type][this.totalYearsList[i]]) ? ele[type][this.totalYearsList[i]] :
        (this.totalYearsList[i] && !ele[type][this.totalYearsList[i]]) ? ((ele[type][this.totalYearsList[i + 1]]) ? 0 : '') : '';
    }
  }

  getJsonFormatForFDForYearly(element) {
    element['costTypeCategoryViewList'].forEach(item => {
      item['unitCostListOfAll'] = [];
      item['unitCostList'] = [];
      item['yearlyUnitCostList'] = item['yearlyUnitCostList'] ? item['yearlyUnitCostList'] : {};
      let keys = Object.keys(item['yearlyUnitCostList']);
      for (let i = 0; i < keys.length; i++) {
        if (item['yearlyUnitCostList'] && item['yearlyUnitCostList'][keys[i]]) {
          item['yearlyUnitCostList'][keys[i]].forEach(v => {
            v['year'] = keys[i];
            item['unitCostListOfAll'].push(v);
          });
        }
      }
      item['unitCostList'] = _.unionBy(item['unitCostListOfAll'], 'refSurrId');
      item['unitCostList'].forEach(costUnit => {
        //creating new list for ease in html for showing cost and unit.
        costUnit['unitCostDetails'] = [];
      });
      if (item.name == 'Resource') {
        this.getUnitCostDetailsListForResourceForFDYearly(item, 'yearlyFTETotal', 'YFTETotal', 'FTE');
        this.getUnitCostDetailsListForResourceForFDYearly(item, 'yearlyAllocationTotal', 'YAllocationTotal', '%alloc');
        this.getUnitCostDetailsListForResourceForFDYearly(item, 'yearlyMandaysTotal', 'YMandaysTotal', 'Man-days');
        this.getUnitCostDetailsListForResourceForFDYearly(item, 'yearlyCostTotal', 'YCostTotal', 'Cost');
      } else {
        item['unitCostList'].forEach(uniq => {
          uniq['YCostTotal'] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          uniq['YUnitTotal'] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          uniq.yearlyCostTotal = (!uniq.yearlyCostTotal || (uniq.yearlyCostTotal && uniq.yearlyCostTotal.length == 0)) ? [0] : uniq.yearlyCostTotal;
          item['unitCostListOfAll'].forEach(all => {
            if (uniq.refSurrId == all.refSurrId && uniq.year == all.year) {
              for (let i = 0; i < this.totalYearsList.length; i++) {
                if (uniq.year == this.totalYearsList[i]) {
                  uniq.YCostTotal[i] = uniq.yearlyCostTotal[0];
                  if (uniq.yearlyUnitTotal) {
                    uniq.YUnitTotal[i] = uniq.yearlyUnitTotal[0];
                  }
                }
              }
            } else if (uniq.refSurrId == all.refSurrId && uniq.year != all.year) {
              all.yearlyCostTotal = (!all.yearlyCostTotal || (all.yearlyCostTotal && all.yearlyCostTotal.length == 0)) ? [0] : all.yearlyCostTotal;
              for (let i = 0; i < this.totalYearsList.length; i++) {
                if (uniq.year == this.totalYearsList[i]) {
                  uniq.YCostTotal[i] = uniq.yearlyCostTotal[0];
                  if (uniq.yearlyUnitTotal) {
                    uniq.YUnitTotal[i] = uniq.yearlyUnitTotal[0];
                  }
                }
                if (all.year == this.totalYearsList[i]) {
                  uniq.YCostTotal[i] = all.yearlyCostTotal[0];
                  if (all.yearlyUnitTotal) {
                    uniq.YUnitTotal[i] = all.yearlyUnitTotal[0];
                  }
                }
              }
            }
          });
          for (let i = 0; i < 10; i++) {
            uniq.YCostTotal[i] = uniq.YCostTotal[i] ? uniq.YCostTotal[i] : 0;
            if (uniq.YUnitTotal) {
              uniq.YUnitTotal[i] = uniq.YUnitTotal[i] ? uniq.YUnitTotal[i] : 0
            }
          }
        });
        item['unitCostList'].forEach(costUnit => {
          //creating new list for ease in html for showing cost and unit.
          costUnit['unitCostDetails'] = [];
          if (costUnit.YUnitTotal && !_.isEmpty(costUnit.YUnitTotal)) {
            costUnit['unitCostDetails'].push({
              'title': 'Unit',
              'yearly': costUnit.YUnitTotal,
              'overAllSum': 0
            })
          }
          costUnit['unitCostDetails'].push({
            'title': 'Cost',
            'yearly': costUnit.YCostTotal,
            'overAllSum': _.sum(costUnit.YCostTotal)
          });
        });
        // rearranging json so that others are at bottom.
        item['unitCostList'].sort((a, b) => (a.name.substring(0, 5) == 'Other' && b.name.substring(0, 5) != 'Other') ? 1 : -1);
      }
    });
  }

  getUnitCostDetailsListForResourceForFDYearly(item, listType, tempList, type) {
    item['unitCostList'].forEach(uniq => {
      uniq[tempList] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
      if (type == 'Cost') {
        uniq[listType] = (!uniq[listType] || (uniq[listType] && uniq[listType].length == 0)) ? [0] : uniq[listType];
      }
      item['unitCostListOfAll'].forEach(all => {
        if (uniq.refSurrId == all.refSurrId && uniq.year == all.year) {
          for (let i = 0; i < this.totalYearsList.length; i++) {
            if (uniq.year == this.totalYearsList[i] && uniq[listType]) {
              uniq[tempList][i] = uniq[listType][0];
            }
          }
        } else if (uniq.refSurrId == all.refSurrId && uniq.year != all.year) {
          if (type == 'Cost') {
            all[listType] = (!all[listType] || (all[listType] && all[listType].length == 0)) ? [0] : all[listType];
          }
          for (let i = 0; i < this.totalYearsList.length; i++) {
            if (uniq.year == this.totalYearsList[i] && uniq[listType]) {
              uniq[tempList][i] = uniq[listType][0];
            }
            if (all.year == this.totalYearsList[i] && all[listType]) {
              uniq[tempList][i] = all[listType][0];
            }
          }
        }
      });
      if (uniq[tempList]) {
        for (let i = 0; i < 10; i++) {
          uniq[tempList][i] = uniq[tempList][i] ? uniq[tempList][i] : 0
        }
      }
    });
    item['unitCostList'].forEach(costUnit => {
      //creating new list for ease in html for showing cost and unit.
      if (costUnit[listType] && !_.isEmpty(costUnit[listType])) {
        if (type == 'Cost') {
          costUnit['unitCostDetails'].push({
            'title': type,
            'yearly': costUnit[tempList],
            'overAllSum': _.sum(costUnit[tempList])
          })
        } else {
          costUnit['unitCostDetails'].push({
            'title': type,
            'yearly': costUnit[tempList],
            'overAllSum': 0
          })
        }
      }
    });
    // rearranging json so that others are at bottom.
    item['unitCostList'].sort((a, b) => (a.name.substring(0, 5) == 'Other' && b.name.substring(0, 5) != 'Other') ? 1 : -1);
  }
  // updating total based upon users changes.
  editFS(editIndex, costType, costInput, itemIndex, unitTitle) {
    this.summaryData[1]['costSettingsViewList'].forEach(element => {
      if ((element.name == costInput) && this.getKeyForRefData(this.refData['costSettings'], element.name) == 'seed_funding') {
        let monthlyOverAllTotal = [];
        // for updating cost type sum
        element['costTypeCategoryViewList'].forEach(resource => {
          let costTypeTotal = 0;
          resource['monthlyCostTypesEdited'] = resource['monthlyCostTypesEdited'] || [];
          resource['monthlyCostTypes'] = resource['monthlyCostTypes'] || [];
          resource['monthly'].forEach((month, index) => {
            costTypeTotal = costTypeTotal + Number(month.value);
            // updating original monthlyCostTypes as per monthly
            if (index == editIndex && resource.name == costType) {
              if (resource['monthlyCostTypesEdited'] && resource['monthlyCostTypesEdited'].length > 0) {
                resource['monthlyCostTypesEdited'].forEach((monthRecord) => {
                  if (monthRecord['monthNumber'] == index + 1) {
                    monthRecord.value = month.value;
                  } else {
                    resource['monthlyCostTypesEdited'].push(month);
                  }
                });
              } else {
                resource['monthlyCostTypesEdited'].push(month);
              }
            }
            resource['monthlyCostTypesEdited'] = _.uniqBy(resource['monthlyCostTypesEdited'], 'monthNumber');
            resource['monthlyCostTypes'][index] = Number(month.value);
          });
          // for updating overall cost type sum
          let diff = costTypeTotal - resource.costTypeTotal;
          resource.costTypeOverAllTotal = resource.costTypeOverAllTotal + diff;
          resource.costTypeTotal = costTypeTotal;
        });
        // for updating monthly overall total for cost setting
        for (let i = 0; i <= 11; i++) {
          let monthTotal = 0;
          element['costTypeCategoryViewList'].forEach(resource => {
            monthTotal = monthTotal + Number(resource['monthly'][i].value)
          });
          monthlyOverAllTotal.push(monthTotal);
        }
        element.monthlyCostSettings = monthlyOverAllTotal;
        //for updating overall monthly total
        let overAllTotalMonthly = 0;
        for (let i = 0; i <= 11; i++) {
          overAllTotalMonthly = overAllTotalMonthly + element.monthlyCostSettings[i];
        }
        // for updating overall cost setting sum
        this.financialSummaryObject.seedFund_overallTotalDiff = overAllTotalMonthly - element.costSettingsTotal;
        element.costSettingsOverAllTotal = element.costSettingsOverAllTotal + this.financialSummaryObject.seedFund_overallTotalDiff;
        this.financialSummaryObject.seedFund_overallTotal = element.costSettingsOverAllTotal;
        element.costSettingsTotal = overAllTotalMonthly;
        //maintaining edit object for seed funding
        this.financialSummaryObject['seedFunding'][this.selectedYear] = element;
        let _selectedYearData = [];
        element['costTypeCategoryViewList'].forEach(eachCategory => {
          _selectedYearData.push({ 'costType': eachCategory.name, 'monthlyData': eachCategory.monthlyCostTypesEdited })
        });
        // keeping edited data in editObject['monthlySeedFundingData'] for save action.
        this.financialSummaryObject.editObject['monthlySeedFundingData'][this.selectedYear] = _selectedYearData;
      }
      else if ((element.name == costInput) && this.getKeyForRefData(this.refData['costSettings'], element.name) == 'fin_details') {
        let monthlyOverAllTotal = [];
        // for updating cost type sum
        element['costTypeCategoryViewList'].forEach(resource => {
          resource['monthlyCostTypeDataList'] = resource['monthlyCostTypeDataList'] || [];
          resource['unitCostList'] = resource['unitCostList'] || [];
          if (resource.name == 'Resource') {
            resource['monthlyCostTypesResource'] = resource['monthlyCostTypesResource'] || [];
          } else {
            resource['monthlyCostTypes'] = resource['monthlyCostTypes'] || [];
          }
          resource['unitCostList'].forEach((item, index) => {
            item['unitCostDetails'] = item['unitCostDetails'] || [];
            resource['monthlyCostTypeDataList'][index] = resource['monthlyCostTypeDataList'][index] || {
              'surrId': item['refSurrId'],
              'name': item['name'],
              'monthlyData': [],
              'fteAllocData': [],
            };
            if (resource.name == costType && itemIndex == index) {
              //updating cost when we update units.
              if (unitTitle == 'Unit' || unitTitle == 'FTE' || unitTitle == 'Cost') {
                item['unitCostDetails'][0]['monthly'][editIndex].value = item['unitCostDetails'][0]['monthly'][editIndex].value ? item['unitCostDetails'][0]['monthly'][editIndex].value : 0;
              } else if (unitTitle == '%alloc') {
                item['unitCostDetails'][1]['monthly'][editIndex].value = item['unitCostDetails'][1]['monthly'][editIndex].value ? item['unitCostDetails'][1]['monthly'][editIndex].value : 0;
              }
              if (resource.name == 'Resource') {
                if (item['unitCostDetails'].length > 1) {
                  item['unitCostDetails'][2]['monthly'][editIndex].value =
                    (item['unitCostDetails'][0]['monthly'][editIndex].value * item['unitCostDetails'][1]['monthly'][editIndex].value * item.fdManDays) / 100;
                  item['unitCostDetails'][3]['monthly'][editIndex].value =
                    (item['unitCostDetails'][2]['monthly'][editIndex].value * item.blendedCost);
                }
                // updating FET & alloc changes and keeping them for request object
                if (item['unitCostDetails'] && item['unitCostDetails'].length > 1) {
                  if (unitTitle == 'FTE') {
                    this.updateJsonForEditResource(item, resource, index, editIndex, 0, 'fteAllocData', 'FTE');
                  } else if (unitTitle == '%alloc') {
                    this.updateJsonForEditResource(item, resource, index, editIndex, 1, 'fteAllocData', '%alloc');
                  } else {
                    this.updateJsonForEditResource(item, resource, index, editIndex, 3, 'monthlyData', '');
                  }
                } else if (item['unitCostDetails'] && item['unitCostDetails'].length == 1) {
                  this.updateJsonForEditResource(item, resource, index, editIndex, 0, 'monthlyData', '');
                }
              } else {
                if (item['unitCostDetails'].length > 1) {
                  item['unitCostDetails'][1]['monthly'][editIndex].value =
                    item['unitCostDetails'][0]['monthly'][editIndex].value * item.unitPriceValue;
                }
                // updating unit changes and keeping them for request object
                item['unitCostDetails'][0]['monthly'].forEach((month, monthindex) => {
                  if (editIndex == monthindex) {
                    if (resource['monthlyCostTypeDataList'][index]['monthlyData'] && resource['monthlyCostTypeDataList'][index]['monthlyData'].length > 0) {
                      resource['monthlyCostTypeDataList'][index]['monthlyData'].forEach(monthRecord => {
                        if (monthRecord['monthNumber'] == editIndex + 1) {
                          (item['unitCostDetails'][0].title == 'Unit') ? monthRecord.unit = month.value : monthRecord.value = month.value;
                        } else {
                          if (item['unitCostDetails'][0].title == 'Unit') {
                            resource['monthlyCostTypeDataList'][index]['monthlyData'].push({
                              'surrId': month.surrId,
                              'unit': month.value,
                              'monthNumber': month.monthNumber
                            });
                          } else {
                            resource['monthlyCostTypeDataList'][index]['monthlyData'].push({
                              'surrId': month.surrId,
                              'value': month.value,
                              'monthNumber': month.monthNumber
                            });
                          }
                        }
                      });
                    } else {
                      if (item['unitCostDetails'][0].title == 'Unit') {
                        resource['monthlyCostTypeDataList'][index]['monthlyData'].push({
                          'surrId': month.surrId,
                          'unit': month.value,
                          'monthNumber': month.monthNumber
                        });
                      } else {
                        resource['monthlyCostTypeDataList'][index]['monthlyData'].push({
                          'surrId': month.surrId,
                          'value': month.value,
                          'monthNumber': month.monthNumber
                        });
                      }
                    }
                  }
                });
              }
              resource['monthlyCostTypeDataList'][index]['monthlyData'] = _.uniqBy(resource['monthlyCostTypeDataList'][index]['monthlyData'], 'monthNumber');
              resource['monthlyCostTypeDataList'][index]['fteAllocData'] = _.uniqBy(resource['monthlyCostTypeDataList'][index]['fteAllocData'], 'monthNumber');
              //updating total by month of resource once the unit is updated.
              let monthTotal = 0, yearlyTotalforItem = 0, diffInMonthlyTotal = 0, mandaysTotal = 0,
                yearlyTotalforMandaysItem = 0, diffInMonthlyTotalOfMandays = 0, FTEMOnthlyTotal = 0;
              resource['unitCostList'].forEach((itemInResource, itemIdx) => {
                if (resource.name == 'Resource') {
                  if (itemIdx == itemIndex && (itemInResource['unitCostDetails'][3] || itemInResource['unitCostDetails'][2])) {
                    yearlyTotalforItem = _.sumBy(itemInResource['unitCostDetails'][3]['monthly'], 'value');
                    yearlyTotalforMandaysItem = _.sumBy(itemInResource['unitCostDetails'][2]['monthly'], 'value');
                    diffInMonthlyTotal = yearlyTotalforItem - itemInResource['unitCostDetails'][3]['monthlyTotal'];
                    diffInMonthlyTotalOfMandays = yearlyTotalforMandaysItem - itemInResource['unitCostDetails'][2]['monthlyTotal'];
                    //updating overall total of individual item i.e resource
                    itemInResource['unitCostDetails'][3]['overAllSum'] = diffInMonthlyTotal + itemInResource['unitCostDetails'][3]['overAllSum'];
                    itemInResource['unitCostDetails'][3]['monthlyTotal'] = yearlyTotalforItem;
                    itemInResource['unitCostDetails'][2]['overAllSum'] = diffInMonthlyTotalOfMandays + itemInResource['unitCostDetails'][2]['overAllSum'];
                    itemInResource['unitCostDetails'][2]['monthlyTotal'] = yearlyTotalforMandaysItem;
                  }
                  if (itemInResource['unitCostDetails'] && itemInResource['unitCostDetails'].length > 1) {
                    monthTotal = monthTotal + Number(itemInResource['unitCostDetails'][3]['monthly'][editIndex].value);
                    mandaysTotal = mandaysTotal + Number(itemInResource['unitCostDetails'][2]['monthly'][editIndex].value);
                    FTEMOnthlyTotal = FTEMOnthlyTotal + Number(itemInResource['unitCostDetails'][0]['monthly'][editIndex].value);
                  } else if (itemInResource['unitCostDetails'] && itemInResource['unitCostDetails'].length == 1) {
                    monthTotal = monthTotal + Number(itemInResource['unitCostDetails'][0]['monthly'][editIndex].value);
                  }
                } else {
                  if (itemIdx == itemIndex && itemInResource['unitCostDetails'][1]) {
                    yearlyTotalforItem = _.sumBy(itemInResource['unitCostDetails'][1]['monthly'], 'value');
                    diffInMonthlyTotal = yearlyTotalforItem - itemInResource['unitCostDetails'][1]['monthlyTotal'];
                    //updating overall total of individual item i.e hardware/software
                    itemInResource['unitCostDetails'][1]['overAllSum'] = diffInMonthlyTotal + itemInResource['unitCostDetails'][1]['overAllSum'];
                    itemInResource['unitCostDetails'][1]['monthlyTotal'] = yearlyTotalforItem;
                  } else if (itemIdx == itemIndex && itemInResource['unitCostDetails'][0]) {
                    yearlyTotalforItem = _.sumBy(itemInResource['unitCostDetails'][0]['monthly'], 'value');
                    diffInMonthlyTotal = yearlyTotalforItem - itemInResource['unitCostDetails'][0]['monthlyTotal'];
                    //updating overall total of individual item i.e hardware/software
                    itemInResource['unitCostDetails'][0]['overAllSum'] = diffInMonthlyTotal + itemInResource['unitCostDetails'][0]['overAllSum'];
                    itemInResource['unitCostDetails'][0]['monthlyTotal'] = yearlyTotalforItem;
                  }
                  monthTotal = monthTotal + (itemInResource['unitCostDetails'][0].title == 'Cost' ? (Number(itemInResource['unitCostDetails'][0]['monthly'][editIndex].value)) :
                    Number(itemInResource['unitCostDetails'][1]['monthly'][editIndex].value));
                }
              });
              // for updating total cost type for that year
              if (resource.name == 'Resource') {
                let diffInCostTypeTotal = monthTotal - Number(resource['monthlyCostTypesResource'][2][editIndex]);
                let diffInMandaysTypeTotal = mandaysTotal - Number(resource['monthlyCostTypesResource'][1][editIndex]);
                resource['costTypeTotalResource'][1] = resource['costTypeTotalResource'][1] + diffInMandaysTypeTotal;
                resource['costTypeTotalResource'][2] = resource['costTypeTotalResource'][2] + diffInCostTypeTotal;
                resource['monthlyCostTypesResource'][2][editIndex] = monthTotal;
                resource['monthlyCostTypesResource'][1][editIndex] = mandaysTotal;
                resource['monthlyCostTypesResource'][0][editIndex] = FTEMOnthlyTotal;
                // for updating overall total of cost type
                resource['costTypeOverAllTotalResource'][2] = resource['costTypeOverAllTotal'][2] + diffInCostTypeTotal;
                resource['costTypeOverAllTotalResource'][1] = resource['costTypeOverAllTotal'][1] + diffInMandaysTypeTotal;
              } else {
                let diffInCostTypeTotal = monthTotal - Number(resource['monthlyCostTypes'][editIndex]);
                resource['costTypeTotal'] = resource['costTypeTotal'] + diffInCostTypeTotal;
                resource['monthlyCostTypes'][editIndex] = monthTotal;
                // for updating overall total of cost type
                resource['costTypeOverAllTotal'] = resource['costTypeOverAllTotal'] + diffInCostTypeTotal;
              }
            }
          });
        });
        // for updating monthly overall total for cost setting
        for (let i = 0; i <= 11; i++) {
          let monthTotal = 0, mandaysTotal = 0, fteTotal = 0;
          element['costTypeCategoryViewList'].forEach(resource => {
            if (resource.name == 'Resource') {
              monthTotal = monthTotal + (resource['monthlyCostTypesResource'][2][i] ? resource['monthlyCostTypesResource'][2][i] : 0);
            } else {
              monthTotal = monthTotal + (resource['monthlyCostTypes'][i] ? resource['monthlyCostTypes'][i] : 0);
            }
          });
          monthlyOverAllTotal.push(monthTotal);
        }
        element.monthlyCostSettings = monthlyOverAllTotal;
        //for updating overall monthly total
        let overAllTotalMonthly = 0;
        for (let i = 0; i <= 11; i++) {
          overAllTotalMonthly = overAllTotalMonthly + element.monthlyCostSettings[i];
        }
        // for updating overall cost setting sum
        this.financialSummaryObject.FD_overallTotalDiff = overAllTotalMonthly - element.costSettingsTotal;
        element.costSettingsOverAllTotal = element.costSettingsOverAllTotal + this.financialSummaryObject.FD_overallTotalDiff;
        this.financialSummaryObject.FD_overallTotal = element.costSettingsOverAllTotal;
        element.costSettingsTotal = overAllTotalMonthly;
        //maintaining edit object for FD
        this.financialSummaryObject['finDetails'][this.selectedYear] = element;
        let _selectedYearData = [];
        element['costTypeCategoryViewList'].forEach(eachCategory => {
          _selectedYearData.push({ 'costType': eachCategory.name, 'monthlyCostTypeDataList': eachCategory.monthlyCostTypeDataList })
        });
        // keeping edited data in editObject['monthlyFinancialDetailsResources'] for save action.
        this.financialSummaryObject.editObject['monthlyFinancialDetailsResources'][this.selectedYear] = _selectedYearData;
      }
    });
  }

  updateJsonForEditResource(item, resource, index, editIndex, unitTitleIndex, list, unitTitle) {
    item['unitCostDetails'][unitTitleIndex]['monthly'].forEach((month, monthindex) => {
      if (editIndex == monthindex) {
        if (resource['monthlyCostTypeDataList'][index][list] && resource['monthlyCostTypeDataList'][index][list].length > 0) {
          resource['monthlyCostTypeDataList'][index][list].forEach(monthRecord => {
            if (monthRecord['monthNumber'] == editIndex + 1) {
              if (unitTitle == 'FTE') {
                monthRecord.fteValue = month.value;
              } else if (unitTitle == '%alloc') {
                monthRecord.allocationValue = month.value;
              } else {
                monthRecord.value = month.value;
              }
            } else {
              if (item['unitCostDetails'].length > 1) {
                resource['monthlyCostTypeDataList'][index][list].push({
                  'surrId': month.surrId,
                  'value': (unitTitle == '' ? month.value : 0),
                  'monthNumber': month.monthNumber,
                  'allocationValue': (unitTitle == '%alloc' ? month.value : item['unitCostDetails'][1]['monthly'][monthindex].value),
                  'fteValue': (unitTitle == 'FTE' ? month.value : item['unitCostDetails'][0]['monthly'][monthindex].value)
                });
              } else {
                resource['monthlyCostTypeDataList'][index][list].push({
                  'surrId': month.surrId,
                  'value': (unitTitle == '' ? month.value : 0),
                  'monthNumber': month.monthNumber,
                  'allocationValue': 0,
                  'fteValue': 0
                });
              }

            }
          });
        } else {
          if (item['unitCostDetails'].length > 1) {
            resource['monthlyCostTypeDataList'][index][list].push({
              'surrId': month.surrId,
              'value': (unitTitle == '' ? month.value : 0),
              'monthNumber': month.monthNumber,
              'allocationValue': (unitTitle == '%alloc' ? month.value : item['unitCostDetails'][1]['monthly'][monthindex].value),
              'fteValue': (unitTitle == 'FTE' ? month.value : item['unitCostDetails'][0]['monthly'][monthindex].value)
            });
          } else {
            resource['monthlyCostTypeDataList'][index][list].push({
              'surrId': month.surrId,
              'value': (unitTitle == '' ? month.value : 0),
              'monthNumber': month.monthNumber,
              'allocationValue': 0,
              'fteValue': 0
            });
          }
        }
      }
    });
  }

  getKeyForRefData(list, dataValue) {
    let result = _.filter(list, function (element) {
      return (element ? (element.value == dataValue) : false)
    });
    return (result[0].key);
  }
}
