import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/common/module/shared.module';
import { EditSubworkstreamComponent } from './edit-subworkstream.component';

const routes: Routes = [
    {path: '', component: EditSubworkstreamComponent}
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
  ],
  declarations: [
    EditSubworkstreamComponent
  ],
  exports: [],
  entryComponents: []
})

export class EditSubworkstreamRoutingModule {
}