import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EditSubworkstreamComponent } from './edit-subworkstream.component';

//import { EditSubWorkstreamComponent } from './edit-subworkstream.component';

xdescribe('EditSubWorkstreamComponent', () => {
  let component: EditSubworkstreamComponent;
  let fixture: ComponentFixture<EditSubworkstreamComponent>;
  

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditSubworkstreamComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditSubworkstreamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
