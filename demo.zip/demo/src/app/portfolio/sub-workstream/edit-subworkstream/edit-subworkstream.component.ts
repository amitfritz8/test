import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, ValidationErrors, ValidatorFn, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { Trie } from 'prefix-trie-ts';
import { Observable, Subscription } from 'rxjs';
import { map, delay, startWith } from 'rxjs/operators';
import { DatePipe } from '@angular/common';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import { OthersDialogComponent } from 'src/app/common/component/dialogues/others-dialog/others-dialog-component';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/toPromise';
import { CommonService } from 'src/app/common/service/common.service';
import { CommonDialogComponent } from 'src/app/common/component/dialogues/common-dialog/common-dialog-component';
import * as _ from 'lodash';

export class AppDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
    let monthList = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    if (displayFormat === 'input') {
      const day = date.getDate();
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      return `${day} ${monthList[month - 1]} ${year}`;
    } else {
      return date.toDateString();
    }
  }
}

export const APP_DATE_FORMATS =
{
  parse: {
    dateInput: { month: 'short', year: 'numeric', day: 'numeric' },
  },
  display: {
    dateInput: 'input',
    monthYearLabel: { year: 'numeric', month: 'numeric' },
    dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric' },
    monthYearA11yLabel: { year: 'numeric', month: 'long' },
  }
};

@Component({
  selector: 'app-edit-workstream',
  templateUrl: './edit-subworkstream.component.html',
  styleUrls: ['./edit-subworkstream.component.scss', '../../workstream/edit-workstream/edit-workstream.component.scss'],
  providers: [
    {
      provide: DateAdapter, useClass: AppDateAdapter
    },
    {
      provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
    }
  ],
})
export class EditSubworkstreamComponent implements OnInit, OnDestroy {

  // isExpanded = false;
  // panelOpenState = true;
  showWMinput: boolean = false;
  subWorkstreamForm: FormGroup;
  filteredEmployees: Observable<any>;
  filteredAppCodes: Observable<any>;
  filteredProductCodes: Observable<any>;
  filteredApproverNames: Observable<string[]>[] = [];
  subWorkStreamSurrId: any = [];
  checkValidOptionForWorkManager: boolean;
  subWorkStreamId: any = [];
  scenarioDropdownApprover: any = ['Forecast'];
  subWorkStreamDesc: any;
  workstreamID: any;
  countryDropdown: any = [];
  action: string = 'add';
  subWorkstreamName: any;
  portfolioId: any;
  trie = new Trie([]);
  employeeList = [];
  portfolioName: any;
  resSuccess: boolean;
  workStreamData: any = [];
  subPlatformData: any = [];
  isSubWorkStreamNameExist: boolean;
  showName: string;
  PlatformDropdownList: any = [];
  data: any;
  employeeMap = new Map<string, string>();
  benefitTypeDropDownList: any = [];
  thematicsDropdown: any = [];
  businesSegmentDropdown: any = [];
  horizonDropDownList: any = [];
  workStatusDropdown: any = [];
  agileOrWaterfallDropdown: any = [];
  pcCodeDropdownList: any = [];
  appCodeDropDownList: any = [];
  workStreamSurrId: any;
  showSideNavigation = false;
  populateCountry: any;
  subPlatFormName: any;
  appCodeDesc: any;
  productCodeDesc: any;
  productCodeDropDownList: any = [];
  keyDatesDisplayDates: any = [];
  selectedScenarioIndex: any;
  budgetSelected: boolean;
  fungibilitySelected: boolean;
  offCycleSelected: boolean;
  selScenario: any;
  scenarioDropdown: any = [];
  scenarioDropdownSubWorkStream: any = [];
  keyDates: any = [];
  isErrorExists: boolean;
  subWorkstreamManagerData: any;
  subWorkstreamManagerDataVals: any[];
  workManagerData: any;
  goLiveDate: any;
  swEngStartDate: any;
  forecastActual = '';
  subWorkStremApprovals = [];
  approversData: any = [];
  roleDropdown: any = [];
  employeeAsApprover: any = [];
  actionsForApprover: any = [];
  scenario: any = [];
  platformIndex: string = '';
  hasDuplicateRecord: any = [];
  selectDisabled: any = [];
  subworkstreamApprovalExists: boolean = false;
  hasDuplicateRecordForStaffName: any = [];
  hiddenSubWorkStreamName: string;
  docsTypesDropdown: any = [];
  othersData: any = [];
  othersFileData: any = [];
  // currencyDropDownList = [];
  isValidSwEngStartDate: boolean = false;
  saveCliked: boolean = false;
  monthlyFinancialResource: any;
  KeyDatesChangeErrMsg: string;
  todayDate: Date = new Date();
  currencyCode: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.CURRENCY_CODE_TYPE);
  timer: any;

  restrictKeyDates: boolean = false;
  approverPattern = {}; duplicateApproverPattetn = {}; duplicateWorkmanager = {};

  headerInfo;
  tabObserver: Subscription;
  selectedTab: string;
  showSaveBtn: boolean = true;
  maxStartDate; maxEndDate; maxLiveDate;

  isScenarioExist: boolean = false;
  isForecastChanges: boolean = false;
  errScenarioMsg: string = '';
  existingKeyDates: any;

  constructor(private fb: FormBuilder, private datePipe: DatePipe, private router: Router, private restService: RestService, private dataService: DataService,
    private dateUtility: DateUtility, private dialog: MatDialog, private http: HttpClient, private changeDetector: ChangeDetectorRef,
    private commonService: CommonService ) {
    this.headerInfo = {
      title: sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME),
      show_filters: false,
      additional_info: sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID),
      tabs: ['Work Profile', 'Work Managers', 'Key Dates', 'Approvers', 'Financials', 'Others']
    }
    this.selectedTab = sessionStorage.getItem('currentTab');
    this.headerInfo.prevent_idx_update = (this.selectedTab != '' && this.headerInfo.tabs.indexOf(this.selectedTab) >= 0);
    if (this.headerInfo.prevent_idx_update) {
      this.commonService.updateTab.emit(this.selectedTab);
    }
    this.commonService.recieveMessage(this.headerInfo);
  }

  private approverValidator(idx): ValidatorFn {
    return (group: FormGroup): ValidationErrors => {
      let role = group.controls['role'];
      let scenario = group.controls['scenario'];
      let oneBankId = group.controls['oneBankId'];
      if (oneBankId.value == '') {
        group.controls['staffName'].setErrors({ required: true });
      } else if (oneBankId.value != '' && scenario.value != '' && role.value != '' && !_.isEmpty(this.duplicateApproverPattetn)) {
        let str = `${role.value}-${oneBankId.value}-${scenario.value}`;
        if (this.duplicateApproverPattetn[idx] == str) {
          group.controls['staffName'].setErrors({ error: true });
          return;
        } else {
          group.controls['staffName'].setErrors(null);
          return;
        }
      } else {
        group.controls['staffName'].setErrors(null);
        return;
      }
    };
  }

  // key date validator
  private maxDateValidator(minDate: Date, field: string): ValidatorFn {
    return (ctrl: FormControl): ValidationErrors => {
      if (minDate) {
        if (new Date(new Date(ctrl.value).toDateString()) < new Date(minDate.toDateString()) && field === 'startDate') {
          return { 'datePreceed': true };
        } else if (new Date(new Date(ctrl.value).toDateString()) > new Date(minDate.toDateString()) && field !== 'startDate') {
          return { 'dateExceed': true };
        }
      }
      return null;
    };
  }

  private wrkMngrValidator(idx): ValidatorFn {
    return (group: FormGroup): ValidationErrors => {
      let email = group.controls['emailAddress'];
      if (email.value != '' && !_.isEmpty(this.duplicateWorkmanager)) {
        if (this.duplicateWorkmanager[idx] == email.value) {
          group.controls['staffName'].setErrors({ duplicate: true });
          return;
        } else {
          group.controls['staffName'].setErrors(null);
          return;
        }
      } else {
        group.controls['staffName'].setErrors(null);
        return;
      }
    };
  }

  ngOnInit() {

    // tab observer
    this.tabObserver = this.commonService.selectedTab.subscribe(data => {
      this.selectedTab = data;
    });

    // this.currencyDropDownList = ['SGD', 'HKD'];
    this.saveCliked = false;
    this.getKeyDatesChangeError();
    this.subWorkstreamForm = this.fb.group({
      workStreamSurrId: [''],
      workStreamId: [''],
      workManagers: this.fb.array([]),
      workManagerName: ['', []],
      subWorkStreamSurrId: [''],
      subWorkStreamId: [''],
      subWorkStreamDesc: ['', [Validators.required]],
      subWorkStreamName: ['', [Validators.required]],
      subWorkstreamKeydatesForm: this.fb.array([]),
      subPlatformName: [''],
      subWorkStreamRef: [''],
      appCode: [''],
      appCodeDesc: [''],
      productCode: [''],
      productCodeDesc: [''],
      dateCreated: [''],
      createdBy: [''],
      deliveryUnit: [''],
      workType: [''],
      scenarioName: ['', []],
      approvers: this.fb.array([]),
      others: this.fb.array([]),
      lepccodesBuild: this.fb.array([]),
      lepccodesOperate: this.fb.array([])
    });
    this.getData();
    this.getKeyDates();
    this.getOthersData();
    this.getScenarioData();
    //api call for add/edit of approvers
    //adding scenarios
    this.scenario = '';
    this.restService.get(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues/scenario').subscribe(scenario => {
      if (scenario) {
        scenario.forEach(c => {
          const subWrkStreamName = this.subWorkstreamForm.controls.subWorkStreamName.value;
          if (subWrkStreamName && subWrkStreamName.substring(0, 5) == 'SWS0-' && (c.desc && c.desc.toLowerCase() == 'total')) {
            this.scenario = 'Budget';
          } else if (subWrkStreamName && subWrkStreamName.substring(0, 5) != 'SWS0-' && (c.desc && c.desc.toLowerCase() == 'others')) {
            this.scenario = 'Forecast/Actual';
          }
        });
      }
    });

    //adding actions list
    this.actionsForApprover = [];
    this.restService.get(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues/workflow action').subscribe(action => {
      if (action) {
        action.forEach(c => {
          if (c.value != 'Approval') {
            this.actionsForApprover.push({ value: c.value });
          }
        });
      }
    });

    //getting roles
    this.roleDropdown = [];
    this.platformIndex = this.portfolioId ? this.portfolioId.substring(1, 3) : '';
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/non-generic/stakeholders/role?platformIndex=${this.platformIndex}`).subscribe(roles => {
      if (roles) {
        roles.forEach(element => {
          this.roleDropdown.push({ value: element });
        });
      }
    });

    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/subworkstream/getApprovals/' + this.subWorkStreamId + '/' + this.hiddenSubWorkStreamName).subscribe(data => {
      this.approversData = data;
      // setting up list for staffName based upon roles.
      if (this.approversData) {
        this.approversData.forEach((data, index) => {
          this.restService.get(URL_PREFIX.PORTFOLIO + `/data/non-generic/stakeholders/staffnames?platformIndex=${this.platformIndex}&role=${data.role}`).subscribe(staffList => {
            let that = this;
            if (staffList) {
              this.employeeAsApprover[index] = [];
              Object.entries(staffList).forEach(function (obj) {
                that.employeeAsApprover[index].push({ key: obj[0], value: obj[1] });
              });
            }
            this.selectDisabled[index] = false;
          });

          if (data.scenario == 'Forecast' || data.scenario == 'Financial Case') {
            let str = `${data.role}-${data.oneBankId}-${data.scenario}`;

            if (Object.values(this.approverPattern).indexOf(str) < 0) {
              this.approverPattern[index] = str;
              this.hasDuplicateRecordForStaffName[index] = false;
            } else {
              this.duplicateApproverPattetn[index] = str;
              this.hasDuplicateRecordForStaffName[index] = true;
            }
          }
        });
      }
      this.setApprovers();
    });

    //this.getWorkManagers();
    this.filteredEmployees = this.subWorkstreamForm.controls.workManagerName.valueChanges
      .pipe(
        map(empName => empName.length > 1 ? this._filterEmployee(empName) : []),
        delay(500)
      );
  }

  ngOnDestroy() {
    this.tabObserver.unsubscribe();
    sessionStorage.removeItem('currentTab');
    clearTimeout(this.timer);
  }

  showExtensionDailogue() {
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'confirm',
        contentTitle: 'Unsaved Changes',
        content: 'You have been editing this for more than 30 minutes, would you like to continue?\n Otherwise you will lose Changes',
        confirmTxt: 'Continue',
        confirmCallBack: this.extendLock.bind(this)
      }
    });
  }

  showRefreshDailogue() {
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'confirm',
        contentTitle: 'Refresh page',
        content: 'You are no longer holding the lock to edit this SubWorkstream.\n Please refresh to get latest changes.',
        confirmTxt: 'Refresh',
        confirmCallBack: this.refreshPage.bind(this)
      }
    });
  }

  refreshPage(dialogRef) {
    dialogRef.close();
    this.router.navigateByUrl(`home/portfolio/createPortfolio/subworkstream/${this.subWorkStreamId}`);
  }

  extendLock(dialogRef) {
    dialogRef.close();
    let editLog = {
      portfolioId: this.subWorkStreamId,
      portfolioType: 'SubWorkstream',
      portfolioName: this.hiddenSubWorkStreamName,
      staffDisplayName: JSON.parse(localStorage.getItem('userinfo')).displayName
    };
    this.restService.options = { responseType: 'text' };
    this.restService.put(URL_PREFIX.PORTFOLIO + '/editlock/extend', editLog).subscribe(data => {
      console.log(data);
      if (data === 'Success') {
        console.log('Lock extended');
        this.timer = setTimeout(() => {
          this.showExtensionDailogue();
        }, 1800000);
      }
    },
      err => {
        console.log('Locke extension failed');
        if (err instanceof HttpErrorResponse) {
          if (err.status === 410) {
            this.showRefreshDailogue();
            console.log('Referesh the page');
          }
        }
      });
    this.restService.options = {};
  }

  private _filterEmployee(data: any) {
    return this.trie.getPrefix(data);
  }

  // check scenario exist
  getScenarionExist() {
    this.restService.get(`${URL_PREFIX.PORTFOLIO}/data/subworkstream/checkForecastExistsForSWS/${sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID)}/${sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME)}`).subscribe(data => {
      if (data) {
        this.isScenarioExist = data;
        this.getScenarioExistMsg();
      }
    })
  }

  // get scenarion exist msg
  getScenarioExistMsg() {
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=NOTICE_KEYDATE_CHANGE`).subscribe(data => {
      this.errScenarioMsg = data['message'];
    });
  }

  getData() {
    this.action = this.dataService.getAction();
    const list = ['Country', 'Workstream Dates Config', 'SubWorkstream Document Type'];
    this.restService.post(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues/', list).subscribe(data => {
      data.Country.forEach(element => {
        this.countryDropdown.push({ value: element.desc, display: element.value });
      });
      // data['Workstream Dates Config'].forEach((workStreamDates: any) => {
      //   this.scenarioDropdown.push({ key: workStreamDates.value, value: workStreamDates.value });
      // });
      data['SubWorkstream Document Type'].forEach(element => {
        this.docsTypesDropdown.push({ value: element.value, display: element.desc });
      });

    });
    this.scenarioDropdownSubWorkStream.push('Forecast');
    if (this.action == 'edit') {
      this.workstreamID = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID);
      this.subWorkStreamId = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID);
      this.hiddenSubWorkStreamName = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME);
      this.portfolioId = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID);
      this.editSubWorkstream(this.subWorkStreamId, this.hiddenSubWorkStreamName);
    }
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/portfolio/latestworkdayrecord').subscribe(data => {
      if (data != null) {
        data.forEach(val => {
          const str = val.emailAddress as string;
          if (str) {
            this.trie.addWord(str);
            this.employeeList.push(str);
            this.employeeMap.set(val.emailAddress, val.staffName);
          }
        });
        this.employeeList.sort();
        this.getWorkManagers();
      }
    });

    this.getScenarionExist();
  }

  getScenarioData() {
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/non-generic/scenario').subscribe(
      data => {
        this.scenarioDropdown = data;
      },
      err => {
        console.log(err);
      });
  }

  get f() {
    return this.subWorkstreamForm.controls;
  }

  cnfmClbk(dialogRef) {
    dialogRef.close();
    this.dataService.setActiveTab(this.selectedTab);
    this.router.navigateByUrl(`home/portfolio/createPortfolio/subworkstream/${this.subWorkStreamId}`);
  }


  goback() {
    if (this.subWorkstreamForm.touched) {
      const dialogRef = this.dialog.open(CommonDialogComponent, {
        data: {
          type: 'warning',
          contentTitle: 'Unsaved Changes',
          content: 'You are leaving with unsaved changes, any changes will be lost.\nAre you sure you want to leave this page?',
          confirmTxt: 'Proceed',
          cancelTxt: 'Cancel',
          confirmCallBack: this.cnfmClbk.bind(this)
        }
      });
    } else {
      this.dataService.setActiveTab(this.selectedTab);
      this.router.navigateByUrl(`home/portfolio/createPortfolio/subworkstream/${this.subWorkStreamId}`);
    }
  }

  checkSubWorkProfileForm() {
    if (this.subWorkstreamForm.controls.subWorkStreamDesc.invalid) {
      return true;
    }
    return false;
  }

  checkKeydateChanges(): boolean {
    let flag = false;
    if (this.isScenarioExist && !_.isEmpty(this.existingKeyDates) && this.restrictKeyDates) {
      _.forEach(this.getkeyDatesForm().controls, (data) => {
        let ctrl = data as FormGroup;
        if (ctrl.controls.scenarioName.value === 'Forecast') {
          if (ctrl.controls.startDate.value != '' && new Date(new Date(ctrl.controls.startDate.value).toDateString()).getTime() != new Date(new Date(this.existingKeyDates.startDate).toDateString()).getTime()) {
            return flag = true;
          } else if (ctrl.controls.swEngStartDate.value != '' && new Date(new Date(ctrl.controls.swEngStartDate.value).toDateString()).getTime() != new Date(new Date(this.existingKeyDates.swEngStartDate).toDateString()).getTime()) {
            return flag = true;
          } else if (ctrl.controls.goLiveDate.value != '' && new Date(new Date(ctrl.controls.goLiveDate.value).toDateString()).getTime() != new Date(new Date(this.existingKeyDates.goLiveDate).toDateString()).getTime()) {
            return flag = true;
          } else if (ctrl.controls.endDate.value != '' && new Date(new Date(ctrl.controls.endDate.value).toDateString()).getTime() != new Date(new Date(this.existingKeyDates.endDate).toDateString()).getTime()) {
            flag = true;
          } else {
            flag = false;
          }
        }
      });
    }
    return flag;
  }

  saveSubworkstream() {
    let temp = Object.assign({}, this.headerInfo);
    temp.prevent_idx_update = true;
    this.saveCliked = true;
    const controls = this.subWorkstreamForm.controls;
    // const controls2 = this.subWorkstreamKeydatesForm.controls;
    this.subWorkstreamForm.controls.workStreamSurrId.setValue(this.workStreamData.workStreamSurrId);

    for (const name in controls) {
      if (controls[name].invalid) {
        this.subWorkstreamForm.controls[name].markAsTouched();
      }
    }
    if (this.subWorkstreamForm.invalid) {
      let err_tabs = [];

      if (this.checkSubWorkProfileForm()) {
        err_tabs.push('Work Profile');
      }

      if (this.subWorkstreamForm.controls.workManagers.invalid) {
        err_tabs.push('Work Managers');
      }

      if (this.getkeyDatesForm().invalid) {
        err_tabs.push('Key Dates');
      }

      if (this.subWorkstreamForm.controls.approvers.invalid) {
        err_tabs.push('Approvers');
      }

      temp.err_tabs = err_tabs;
      this.selectedTab = err_tabs[0];
      this.commonService.updateTab.emit(this.selectedTab);
      this.commonService.recieveMessage(temp);

      this.commonService.showSnackBar({
        type: 'alert',
        message: 'Your changes can\'t be saved due to errors in some fields'
      });

      this.subWorkstreamForm.markAllAsTouched();
    } else if (this.subWorkstreamForm.valid) {
      this.commonService.recieveMessage(temp);
      if (!this.checkKeydateChanges()) {
        this.saveSWS();
      } else {
        const dialogRef = this.dialog.open(CommonDialogComponent, {
          data: {
            type: 'confirm',
            contentTitle: 'KeyDates Altered',
            content: this.errScenarioMsg,
            cancelTxt: 'Cancel',
            confirmTxt: 'Continue',
            confirmCallBack: this.updateSws.bind(this)
          }
        });
      }
    }
  }

  updateSws(dialogRef) {
    dialogRef.close();
    this.saveSWS();
  }

  saveSWS() {
    let list = this.subWorkstreamForm.value;

    this.portfolioId = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID);
    this.portfolioName = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME);
    this.subWorkstreamForm.controls.workStreamSurrId.setValue(this.workStreamData.workStreamSurrId);
    this.subWorkstreamForm.controls.workStreamId.setValue(this.workStreamData.workStreamId);
    // tslint:disable-next-line: no-shadowed-variable
    const controls = this.subWorkstreamForm.controls;
    this.subWorkstreamForm.controls.workStreamSurrId.setValue(this.workStreamData.workStreamSurrId);
    for (const name in controls) {
      if (controls[name].invalid) {
        this.subWorkstreamForm.controls[name].markAsTouched();
      }
    }
    this.subWorkstreamForm.controls.workStreamSurrId.setValue(this.workStreamData.workStreamSurrId);
    this.subWorkstreamForm.controls.subWorkStreamSurrId.setValue(this.workStreamData.subWorkStreamSurrId);
    this.subWorkstreamForm.controls.subPlatformName.setValue(this.workStreamData.subPlatformName);
    this.subWorkstreamForm.controls.subWorkStreamId.setValue(this.workStreamData.subWorkStreamId);
    this.subWorkstreamForm.controls.workStreamId.setValue(this.workStreamData.workStreamId);

    let workStreamLepccodes = [];
    let deletedWorkStreamLepccodes=[];

    this.subWorkstreamForm.controls.lepccodesBuild.value.forEach(element => {
      if(element.lepcbuild && element.lepcbuild != null) {
        element.lePcCode = element.lepcbuild;
      }
      delete element.lepcbuild;
      element.mapWorkPccodeSurrId = element.workstreamPccodeSurrId;
      element.portfolioId = this.portfolioId;
      element.workstreamId = this.workstreamID;
      element.workStreamName = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME);
      element.buildOperate = element.buildOperate;
      element.subWorkstreamId = this.subWorkStreamId;
      element.subWorkStreamName = this.workStreamData.subWorkStreamName;
      element.reportingFlag = 'Yes';
      element.activeInd = element.activeInd;
      if (element.activeInd === 'true') {
        workStreamLepccodes.push(element);
      }else if(element['mapWorkPccodeSurrId'] !== 0 && element.activeInd === 'false'){
        deletedWorkStreamLepccodes.push(element);
      }
    });

    this.subWorkstreamForm.controls.lepccodesOperate.value.forEach(element => {
      if(element.lePCCodeOperate && element.lePCCodeOperate != null) {
        element.lePcCode = element.lePCCodeOperate;
      }
      delete element.lePCCodeOperate;
      element.mapWorkPccodeSurrId = element.workstreamPccodeSurrId;
      element.portfolioId = this.portfolioId;
      element.workstreamId = this.workstreamID;
      element.workStreamName = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME);
      element.buildOperate = element.buildOperate;
      element.subWorkstreamId = this.subWorkStreamId;
      element.subWorkStreamName = this.subWorkstreamName;
      element.reportingFlag = 'Yes';
      element.activeInd = element.activeInd;
      if (element.activeInd === 'true') {
        workStreamLepccodes.push(element);
      }else if(element['mapWorkPccodeSurrId'] !== 0 && element.activeInd === 'false'){
        deletedWorkStreamLepccodes.push(element);
      }
    });

    setTimeout(() => {
      let obj = Object.assign({}, this.subWorkstreamForm.value);
      delete obj['subWorkstreamKeydatesForm'];
      delete obj['approvers'];
      delete obj['others'];
      delete obj['others'];
      delete obj['scenarioName'];
      delete obj['workManagerName'];
      delete obj['workManagers'];

      if(this.monthlyFinancialResource){
        this.monthlyFinancialResource['currencyCode'] = this.currencyCode;
      }
      const prepareData = {
        portFolioSubWorkStreamEntity: obj,
        portfolioId: this.portfolioId,
        portfolioName: this.portfolioName,
        workStreamId: sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID),
        workStreamName: sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME),
        currencyCode: this.currencyCode,
        workManagers: this.subWorkstreamForm.value.workManagers,
        keyDates: this.subWorkstreamForm.controls.subWorkstreamKeydatesForm.value,
        subWorkStreamApproves: this.subWorkstreamForm.controls.approvers.value,
        monthlyFinancialResource: this.monthlyFinancialResource,
        lePcodesMapping: workStreamLepccodes,
        deletedLePcodesMapping: deletedWorkStreamLepccodes
      }
      this.restService.post(URL_PREFIX.PORTFOLIO + '/data/subworkstream/edit/updateSubWorkstream', prepareData).subscribe(data => {
        if (data !== null && data.subWorkStreamId !== null) {
          this.processFiles(this.subWorkstreamForm.controls.others);
          this.workStreamData = data;
          sessionStorage.setItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME, prepareData.portFolioSubWorkStreamEntity.subWorkStreamName);
          this.dataService.setActiveTab(this.selectedTab);
          this.resSuccess = true;
          this.commonService.showSnackBar({
            type: 'success',
            message: 'Subworkstream Updated'
          });
        }
      },
        error => {
           console.log('Sws update failed');
          if (error instanceof HttpErrorResponse) {
            if (error.status === 424) {
              this.commonService.showSnackBar({
                type: 'alert',
                message: error.error,
                duration: 10000
              });
            }
          }
        }
      );
    });
  }

  workManagers(): FormArray {
    return this.subWorkstreamForm.get('workManagers') as FormArray;
  }

  changeToggle(event) {
    // console.log('Toggle Event: ', event);
    // console.log(this.subWorkstreamForm);
  }

  changeCheckedBox(event) {
    // console.log('CheckBox Event: ', event);
    // console.log(this.subWorkstreamForm);
  }

  public displayProperty(value) {
    if (value) {
      return '';
    }
  }

  addWorkManagers(event): void {
    this.typeOption();
    this.showWMinput = false;
    if (!this.checkValidOptionForWorkManager) {
      // this.workstreamID = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID);
      const empData = this.subWorkstreamForm.get('workManagerName').value;
      const empName = this.employeeMap.get(empData);
      // console.log('empData: ', empData);
      const data = {
        subWsMgrSurrId: '',
        delegateInd: [false, []],
        emailAddress: empData,
        oneBankId: empData.replace(/@.*$/, ''),
        staffName: empName,
        role: 'tech',
        workstreamID: this.workstreamID,
        activeInd: true,
        subWorkStreamName: sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME),

      };
      this.workManagers().push(this.createWorkManager(data));
    }
    else {
      //this.checkValidOptionForWorkManager = false;
    }
  }

  deleteWorkManager(index) {
    this.workManagers().value[index].activeInd = false;
    const workManager = this.workManagers().controls[index] as FormArray;
    const ctrl = workManager.controls as any;
    if (Object.values(this.duplicateWorkmanager).indexOf(ctrl.emailAddress.value) >= 0) {
      delete this.duplicateWorkmanager[_.findKey(this.duplicateWorkmanager, function (o) {
        return o == ctrl.emailAddress.value
      })];
    } else {
      this.trie.addWord(ctrl.emailAddress.value);
    }
    ctrl.activeInd.value = false;
    if (this.workManagers().value[index].subWsMgrSurrId === '') {
      this.workManagers().removeAt(index);
    } else {
      (this.workManagers().at(index) as FormGroup).controls['staffName'].setErrors(null);
    }
  }

  createWorkManager(empdata): FormGroup {
    this.trie.removeWord(empdata.emailAddress);
    return this.fb.group(
      {
        subWsMgrSurrId: [empdata.subWsMgrSurrId, []],
        workstreamID: [empdata.portfolioId, []],
        subWorkStreamName: sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME),
        oneBankId: [empdata.oneBankId, []],
        staffName: [empdata.staffName, []],
        role: [empdata.role, []],
        delegateInd: [empdata.delegateInd == 'true', []],
        activeInd: [true, []],
        emailAddress: empdata.emailAddress
      }, { validator: this.wrkMngrValidator(this.workManagers().length) });
  }

  approvers(): FormArray {
    return this.subWorkstreamForm.get('approvers') as FormArray;
  }

  typeOption() {
    let ind = false;
    this.subWorkstreamForm.value.workManagers.forEach(e => {

      if (!this.checkValidOptionForWorkManager && e.staffName === this.subWorkstreamForm.controls.workManagerName.value.staffName) {
        this.checkValidOptionForWorkManager = true;
        ind = true;
      }
    });
    if (ind === false) {
      this.checkValidOptionForWorkManager = false;
    }
  }

  editSubWorkstream(subworkstreamID, subWorkStreamName) {
    this.loadDropdowns();
    let staffName = JSON.parse(localStorage.getItem('userinfo')).displayName;
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/portfolio/common/getportfoliodata/${subworkstreamID}/SubWorkstream/${subWorkStreamName}?staffName=${staffName}`).subscribe(data => {
      this.workStreamData = data;
      this.subWorkstreamForm.controls.subWorkStreamName.setValue(data.subWorkStreamName);
      this.subWorkstreamForm.controls.subWorkStreamDesc.setValue(data.subWorkStreamDesc);
      this.subWorkstreamForm.controls.subWorkStreamSurrId.setValue(data.subWorkStreamSurrId);
      this.subWorkstreamForm.controls.subWorkStreamId.setValue(data.subWorkStreamId);
      this.subWorkstreamForm.controls.workStreamId.setValue(data.workStreamId);
      this.subWorkstreamForm.controls.subWorkStreamRef.setValue(data.subWorkStreamRef);
      this.subWorkstreamForm.controls.appCodeDesc.setValue(data.appCode);
      this.subWorkstreamForm.controls.appCodeDesc.setValue(data.appCodeDesc);
      this.subWorkstreamForm.controls.productCodeDesc.setValue(data.productCodeDesc);
      this.subWorkstreamForm.controls.dateCreated.setValue(data.dateCreated);
      this.subWorkstreamForm.controls.createdBy.setValue(data.createdBy);
      this.subWorkstreamForm.controls.workStreamSurrId.setValue(data.workStreamSurrId);
      this.subWorkstreamForm.controls.workStreamId.setValue(data.workStreamId);
      this.subWorkstreamForm.controls.deliveryUnit.setValue(data.deliveryUnit);
      this.subWorkstreamForm.controls.workType.setValue(data.workType);

      if (data.editable === 'NO') {
        this.commonService.showSnackBar({ type: 'alert', message: 'This Sub-Workstream is being edited by ' + data.staffName + ' \n Your changes will not be saved', duration: 5000 });
        this.showSaveBtn = false;
      } else {
        // Track and show dailogue for lock extension
        this.timer = setTimeout(() => {
          this.showExtensionDailogue();
        }, 1800000);
      }
    });
    this.getSubWorkStreamLePCCodes(subworkstreamID,subWorkStreamName);
  }

  loadDropdowns() {
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/appCode/list').subscribe(data => {
      this.data = data;
      data.forEach(element => {
        this.appCodeDropDownList.push({ key: element.appCode, value: element.appCodeName });
      });
      this.filteredAppCodes = this.subWorkstreamForm.controls.appCodeDesc.valueChanges
        .pipe(
          startWith(''),
          map(value => this._filterAppCodes(value))
        );
    });
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/productCode/list').subscribe(data => {
      this.data = data;
      data.forEach(element => {
        this.productCodeDropDownList.push({ key: element.l0Node, value: element.l0Desc });
      });
      this.filteredProductCodes = this.subWorkstreamForm.controls.productCodeDesc.valueChanges
        .pipe(
          startWith(''),
          map(value => this._filterProductCodes(value))
        );
    });
  }

  updateAppCode(data) {
    this.subWorkstreamForm.patchValue({
      'appCode': data.key,
      'appCodeDesc': data.value
    })
  }

  updatePrdCode(data) {
    this.subWorkstreamForm.patchValue({
      'productCode': data.key,
      'productCodeDesc': data.value
    })
  }

  private _filterAppCodes(value: any): any[] {
    value = value ? value : '';
    return this.appCodeDropDownList
      .filter(option => (option.key?.toLowerCase().includes(value.toLowerCase()) || option.value?.toLowerCase().includes(value.toLowerCase())));
  }

  private _filterProductCodes(value: any): any[] {
    value = value ? value : '';
    return this.productCodeDropDownList
      .filter(option => (option.key?.toLowerCase().includes(value.toLowerCase()) || option.value?.toLowerCase().includes(value.toLowerCase())));
  }

  enteredsubPlatFormName(e: { value: any; }) {
    this.appCodeDesc = e.value;
  }

  enteredProductCodeDesc(e: { value: any; }) {
    this.productCodeDesc = e.value;
  }

  scenarios(): FormArray {
    return this.subWorkstreamForm.get('scenarios') as FormArray;
  }

  getKeyDates() {
    const id = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID);
    this.hiddenSubWorkStreamName = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME);
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/subworkstream/keyDatesList/${sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID)}/${id}/${this.hiddenSubWorkStreamName}`).subscribe(data => {

      // check workstream key dates
      if (data.workStreamKeyDates && data.workStreamKeyDates.length > 0) {
        if (data.workStreamKeyDates[0] && data.workStreamKeyDates[0].scenarioName == 'Forecast') {
          this.maxStartDate = new Date(data.workStreamKeyDates[0].startDate);
          this.maxEndDate = new Date(data.workStreamKeyDates[0].endDate);
          this.maxLiveDate = new Date(data.workStreamKeyDates[0].goLiveDate);
        }
      }
      this.setKeyDates(data.subWorkStreamKeyDates)
    });
  }

  setKeyDates(keyDates) {
    let control = <FormArray>this.subWorkstreamForm.controls.subWorkstreamKeydatesForm;
    _.forEach(keyDates, (data) => {
      if (data.scenarioName == 'Forecast') {
        this.existingKeyDates = data;
        this.restrictKeyDates = true;
        control.push(this.fb.group({
          swsDateSurrId: [data.swsDateSurrId],
          subWorkStreamId: [data.subWorkStreamId],
          workStreamId: [data.workStreamId],
          subWorkStreamName: [data.subWorkStreamName],
          scenarioName: [data.scenarioName],
          approvalDate: [data.approvalDate],
          startDate: [data.startDate, [Validators.required, this.maxDateValidator(this.maxStartDate, 'startDate')]],
          goLiveDate: [data.goLiveDate, [Validators.required, this.maxDateValidator(this.maxLiveDate, 'liveDate')]],
          swEngStartDate: [data.swEngStartDate, [Validators.required]],
          endDate: [data.endDate, [Validators.required, this.maxDateValidator(this.maxEndDate, 'endDate')]],
          activeInd: [data.activeInd, []]
        }));
      } else {
        control.push(this.fb.group({
          swsDateSurrId: [data.swsDateSurrId],
          subWorkStreamId: [data.subWorkStreamId],
          workStreamId: [data.workStreamId],
          subWorkStreamName: [data.subWorkStreamName],
          scenarioName: [data.scenarioName],
          approvalDate: [data.approvalDate],
          startDate: [data.startDate],
          goLiveDate: [data.goLiveDate],
          swEngStartDate: [data.swEngStartDate],
          endDate: [data.endDate],
          activeInd: [data.activeInd]
        }));
      }
    });

  }

  addScenario(_event: any) {
    let ctrl = this.getkeyDatesForm();
    ctrl.push(this.fb.group({
      swsDateSurrId: [''],
      subWorkStreamId: [sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID)],
      workStreamId: [sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID)],
      subWorkStreamName: [sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME)],
      scenarioName: ['Forecast'],
      approvalDate: [''],
      startDate: [new Date(), [Validators.required, this.maxDateValidator(this.maxStartDate, 'startDate')]],
      goLiveDate: ['', [Validators.required, this.maxDateValidator(this.maxLiveDate, 'liveDate')]],
      swEngStartDate: ['', [Validators.required]],
      endDate: ['', [Validators.required, this.maxDateValidator(this.maxEndDate, 'endDate')]],
      activeInd: true,
    }));
    this.restrictKeyDates = true;
  }

  deleteKeyDats(index) {

    this.getkeyDatesForm().value[index].activeInd = false;
    const keyDates = this.getkeyDatesForm().controls[index] as FormArray;
    const ctrl = keyDates.controls as any;
    ctrl.activeInd.value = false;
    if (this.getkeyDatesForm().value[index].scenarioName == 'Forecast') {
      this.restrictKeyDates = false;
    }
    if (this.getkeyDatesForm().value[index].swsDateSurrId === '') {
      this.getkeyDatesForm().removeAt(index);
    }
  }

  getkeyDatesForm(): FormArray {
    return this.subWorkstreamForm.controls.subWorkstreamKeydatesForm as FormArray;
  }

  dateFormatISO(millisecondsDate?: any) {
    return this.dateUtility.dateFormatterISO(millisecondsDate);
  }

  getWorkManagers() {
    this.workManagers().clear();
    const id = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID);
    this.hiddenSubWorkStreamName = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME);
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/subworkstream/getworkmanagers/' + id + '/' + this.hiddenSubWorkStreamName).subscribe(data => {
      this.subWorkstreamManagerData = data[0];
      let existingWrkMng = [];
      this.subWorkstreamManagerDataVals = Object.values(this.subWorkstreamManagerData);
      if (this.subWorkstreamManagerDataVals[0] != null) {
        this.subWorkstreamManagerDataVals[0].forEach((data: any, idx) => {
          existingWrkMng.indexOf(data.emailAddress) < 0 ? existingWrkMng.push(data.emailAddress) : this.duplicateWorkmanager[idx] = data.emailAddress;
          this.workManagers().push(this.createWorkManager(data));
        });
      }
    });
  }

  setApprovers() {
    let control = <FormArray>this.subWorkstreamForm.controls.approvers;
    if (this.approversData) {
      this.approversData.forEach((x, idx) => {
        if (x.scenario == 'Forecast' || x.scenario == 'Financial Case') {
          control.push(this.fb.group({
            swsApproveSurrId: x.swsApproveSurrId,
            workStreamId: this.workstreamID,
            subWorkStreamId: this.subWorkStreamId,
            subWorkStreamName: sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME),
            portfolioId: this.portfolioId,
            oneBankId: [x.oneBankId, [Validators.required]],
            role: [x.role, [Validators.required]],
            delegateInd: [x.delegateInd == 'true' ? true : false, []],
            staffName: [x.staffName, [Validators.required]],
            scenario: [x.scenario, [Validators.required]],
            action: [x.action, [Validators.required]],
            notifyInd: [x.notify, []],
            effectiveStartDate: x.effectiveStartDate,
            effectiveEndDate: x.effectiveEndDate,
            activeInd: x.activeInd
          }, { validator: this.approverValidator(control.length) }));
        } else {
          control.push(this.fb.group({
            swsApproveSurrId: x.swsApproveSurrId,
            workStreamId: this.workstreamID,
            subWorkStreamId: this.subWorkStreamId,
            subWorkStreamName: sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME),
            portfolioId: this.portfolioId,
            oneBankId: [x.oneBankId],
            role: [x.role],
            delegateInd: [x.delegateInd == 'true' ? true : false, []],
            staffName: [x.staffName],
            scenario: [x.scenario],
            action: [x.action],
            notifyInd: [x.notify],
            effectiveStartDate: x.effectiveStartDate,
            effectiveEndDate: x.effectiveEndDate,
            activeInd: x.activeInd
          }))
        }
      })
    }
  }

  deleteApprover(data, index) {
    this.approvers().value[index].activeInd = false;
    let approversList = this.approvers().controls[index] as FormArray;
    const control = approversList.controls as any;
    control.activeInd.value = false;
    if (this.approvers().value[index].swsApproveSurrId === '') {
      this.approvers().removeAt(index);
    } else {
      console.log((this.approvers().at(index) as FormGroup));
      (this.approvers().at(index) as FormGroup).controls['staffName'].setErrors(null);
    }

    if (data.oneBankId != '' && data.scenario != '' && data.role != '') {
      let str = `${data.role}-${data.oneBankId}-${data.scenario}`;
      this.hasDuplicateRecordForStaffName.splice(index, 1);
      if (Object.values(this.duplicateApproverPattetn).indexOf(str) >= 0) {
        delete this.duplicateApproverPattetn[_.findKey(this.duplicateApproverPattetn, function (o) {
          return o == str
        })];
      } else {
        delete this.approverPattern[_.findKey(this.approverPattern, function (o) {
          return o == str
        })];
      }
    }
  }

  addApprover() {
    if (this.subWorkstreamForm.controls.approvers.valid) {
      let control = <FormArray>this.subWorkstreamForm.controls.approvers;
      this.approversData = control.value;
      control.push(
        this.fb.group({
          swsApproveSurrId: '',
          workStreamId: this.workstreamID,
          subWorkStreamId: this.subWorkStreamId,
          portfolioId: this.portfolioId,
          role: ['', [Validators.required]],
          delegateInd: [false, []],
          oneBankId: ['', [Validators.required]],
          staffName: ['', [Validators.required]],
          scenario: ['Forecast', [Validators.required]],
          action: ['', [Validators.required]],
          notifyInd: [{ value: '', disabled: true }, []],
          effectiveStartDate: '',
          effectiveEndDate: '',
          activeInd: 'true',
          subWorkStreamName: sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME),
        }, { validator: this.approverValidator(control.length) })
      );
      this.approversData = control.value;
      this.selectDisabled[this.approversData.length - 1] = true;
      this.hasDuplicateRecordForStaffName[this.approversData.length - 1] = false;
    } else {
      let controls = this.approvers().controls;
      controls.forEach((element, index) => {
        for (const name in element['controls']) {
          if (element['controls'][name].invalid) {
            this.approvers().controls[index]['controls'][name].markAsTouched();
          }
        }
      });
    }
  }

  private _filterApproverStaffName(value: any, index: number): any[] {
    return this.employeeAsApprover[index]
      .filter(option => option.value.toLowerCase().includes(value.toLowerCase()));
  }

  checkDuplicateApprover(str, index ) {
    //check for duplicate approver
    if (Object.values(this.approverPattern).indexOf(str) < 0) {
      this.hasDuplicateRecordForStaffName[index] = false
      this.approverPattern[index] = str;
      this.duplicateApproverPattetn[index] && this.duplicateApproverPattetn[index] == str? delete this.duplicateApproverPattetn[index] : '';
    } else {
      this.duplicateApproverPattetn[index] = str;
      this.hasDuplicateRecordForStaffName[index] = true;
      this.approverPattern[index] && this.approverPattern[index] == str ? delete this.approverPattern[index] : '';
    }
    this.approvers().at(index).updateValueAndValidity();
  }

  selectedRoleForApprover(e, data, index) {

    if (data && data.oneBankId != '' && data.scenario != '') {
      this.hasDuplicateRecordForStaffName[index] = false;

      let str = `${data.role}-${data.oneBankId}-${data.scenario}`;
      this.checkDuplicateApprover(str, index);
    }

    let that = this;
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/non-generic/stakeholders/staffnames?platformIndex=${this.platformIndex}&role=${e.value}`).subscribe(staffList => {
      if (staffList) {
        that.employeeAsApprover[index] = [];
        Object.entries(staffList).forEach(function (obj) {
          that.employeeAsApprover[index].push({ key: obj[0], value: obj[1] });
        });
      }
      this.selectDisabled[index] = false;
    });
  }

  onSelectOfDelegate(i, e) {
    // console.log('CheckBox Event: ', e);
    // console.log(this.subWorkstreamForm);
  }

  onSelectApprover(e, data, index) {
    const empOneBankId = this.employeeAsApprover[index].filter(emp => e.option.value == emp.value);
    ((this.approvers()).at(index) as FormGroup).get('oneBankId').patchValue(empOneBankId[0].key);
    if (data && data.role != '' && data.scenario != '') {
      let str = `${data.role}-${empOneBankId[0].key}-${data.scenario}`;
      this.checkDuplicateApprover(str, index);
    }
  }

  bindApproverNames(index) {
    var arrayControl = this.subWorkstreamForm.get('approvers') as FormArray;
    this.filteredApproverNames[index] = arrayControl.at(index).get('staffName').valueChanges
      .pipe(
        startWith(''),
        map(value => this._filterApproverNames(value, index))
      );
  }

  private _filterApproverNames(value: any, index: number): any[] {
    return this.employeeAsApprover[index]
      .filter(option => option.value.toLowerCase().includes(value.toLowerCase()));
  }

  onSelectScenario(e, data, index) {
    //check for duplicate approver
    if (data && data.oneBankId && data.oneBankId != '' && data.role && data.role != '') {
      this.hasDuplicateRecordForStaffName[index] = false;

      let str = `${data.role}-${data.oneBankId}-${data.scenario}`;
      this.checkDuplicateApprover(str, index);
    }
  }

  addDocument() {
    const dialogRef = this.dialog.open(OthersDialogComponent, {
      data: {
        other: this.fb.group({
          othersEntity: this.fb.group({
            swsOthersSurrId: 0,
            workStreamId: this.workstreamID,
            subWorkStreamId: this.subWorkStreamId,
            subWorkStreamName: sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME),
            documentName: '',
            documentType: '',
            description: '',
            filePath: '',
            modifiedBy: '',
            dateModified: '',
            createdBy: '',
            dateCreated: '',
            activeInd: true
          }),
          file: null
        }),
        documentTypes: this.docsTypesDropdown,
        header: 'Add Documents'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.addOthers(result.controls)
    });

  }

  addOthers(others: any) {

    if (this.subWorkstreamForm.controls.others.valid) {
      let control = <FormArray>this.subWorkstreamForm.controls.others;
      this.othersData = control.value;
      control.push(
        this.fb.group(others)
      )
      this.othersData = control.value;
      this.selectDisabled[this.othersData.length - 1] = true;
      this.hasDuplicateRecord[this.othersData.length - 1] = false;

    } else {
      let controls = this.others().controls;
      controls.forEach((element, index) => {
        for (const name in element['controls']) {
          if (element['controls'][name].invalid) {
            this.others().controls[index]['controls'][name].markAsTouched();
          }
        }
      });
    }
  }

  deleteOther(index: any) {
    let othersList = this.others().controls[index] as FormArray;
    const control = othersList.controls as any;
    control.othersEntity.controls.activeInd.value = false;
    if (control.othersEntity.controls.swsOthersSurrId.value === 0) {
      this.others().removeAt(index)
    }
    control.isEdited.value = true;
  }

  others(): FormArray {
    return this.subWorkstreamForm.get('others') as FormArray;
  }

  editOther(index: any) {
    const dialogRef = this.dialog.open(OthersDialogComponent, {
      data: {
        other: this.others().controls[index],
        documentTypes: this.docsTypesDropdown,
        header: 'Edit Documents'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.others().controls[index] = this.fb.group(result.controls);
    });
  }

  async processFiles(othersObj) {
    for (var i = 0; i < othersObj.length; i++) {
      this.dataService.loaderHandler(true);
      if (othersObj.controls[i].controls.isEdited.value) {
        await this.uploadService(othersObj.controls[i]).toPromise();
      }
    }
    this.dataService.loaderHandler(false);
    this.dataService.setActiveTab(this.selectedTab);
    this.router.navigateByUrl(`home/portfolio/createPortfolio/subworkstream/${this.subWorkStreamId}`);
  }

  uploadService(other: any) {

    let fileRequest: FormData = new FormData();
    const options = { headers: new HttpHeaders({ 'Authorization': 'Bearer ' + localStorage.getItem('access_token') }) };
    fileRequest.append('workStreamId', other.controls.othersEntity.controls.workStreamId.value);
    fileRequest.append('documentType', other.controls.othersEntity.controls.documentType.value);
    fileRequest.append('description', other.controls.othersEntity.controls.description.value);
    fileRequest.append('file', other.controls.file.value);
    //  fileRequest.append('subWorkStreamName',sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME));
    fileRequest.append('activeInd', other.controls.othersEntity.controls.activeInd.value);
    fileRequest.append('createdBy', other.controls.othersEntity.controls.createdBy.value);
    fileRequest.append('dateCreated', this.datePipe.transform(other.controls.othersEntity.controls.dateCreated.value, 'yyyy-MM-dd hh:mm:ss'));
    fileRequest.append('modifiedBy', other.controls.othersEntity.controls.modifiedBy.value);
    fileRequest.append('dateModified', this.datePipe.transform(other.controls.othersEntity.controls.dateModified.value, 'yyyy-MM-dd hh:mm:ss'));
    fileRequest.append('filePath', other.controls.othersEntity.controls.filePath.value);
    fileRequest.append('documentName', other.controls.othersEntity.controls.documentName.value);
    fileRequest.append('swsOthersSurrId', other.controls.othersEntity.controls.swsOthersSurrId.value);
    return this.http.post(URL_PREFIX.PORTFOLIO + '/file/subworkstream/upload?subWorkStreamId=' + other.controls.othersEntity.controls.subWorkStreamId.value + '&subWorkStreamName=' + sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME), fileRequest, options);

  }

  getOthersData() {
    const subWorkStreamId = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID);
    this.hiddenSubWorkStreamName = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME);
    this.restService.get(URL_PREFIX.PORTFOLIO + '/file/others/subworkstreams/' + subWorkStreamId + '/' + this.hiddenSubWorkStreamName).subscribe(data => {
      if (data != null && data !== '') {
        const testData = Object.values(data);
        this.othersData = [].concat.apply([], testData);
        this.othersFileData = data;
        this.setOthersData();
      }
    });

  }

  setOthersData() {
    let control = <FormArray>this.subWorkstreamForm.controls.others;
    if (this.othersData) {
      this.othersData.forEach(x => {
        control.push(this.fb.group({
          othersEntity: this.fb.group({
            swsOthersSurrId: x.swsOthersSurrId,
            workStreamId: x.workStreamId,
            subWorkStreamId: x.subWorkStreamId,
            subWorkStreamName: sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME),
            portfolioId: this.portfolioId,
            documentName: x.documentName,
            documentType: x.documentType,
            description: x.description,
            modifiedBy: x.modifiedBy,
            dateModified: x.dateModified,
            createdBy: x.createdBy,
            dateCreated: x.dateCreated,
            activeInd: x.activeInd,
            filePath: x.filePath
          }),
          file: new File([''], x.documentName),
          isEdited: false
        }))
      });
    }
  }

  getSeedFundingUpdatedData(event) {
    this.monthlyFinancialResource = event || {};
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustom(date);
  }

  getKeyDatesChangeError() {
    this.restService.get(URL_PREFIX.PEOPLE + '/data/dataValues/sys-msg?msgKey=ERR_KEYDATESCHANGE_FINANCIALS').subscribe(data => {
      this.KeyDatesChangeErrMsg = data.message;
    });
  }

  download(data) {

  }

  lepccodesBuild(): FormArray {
    return this.subWorkstreamForm.get('lepccodesBuild') as FormArray;
  }

  lepccodesOperate(): FormArray {
    return this.subWorkstreamForm.get('lepccodesOperate') as FormArray;
  }

  getSubWorkStreamLePCCodes(subWorkStreamId: string, subWorkStreamName:string) {
    let subWorkSreamIdName = {
      workStreamId: this.workstreamID,
      subWorkStreamId: subWorkStreamId,
      subWorkStreamName: subWorkStreamName
    };
    this.restService.post(URL_PREFIX.PORTFOLIO + '/data/subworkstream/pccodes/edit',subWorkSreamIdName).subscribe(data => {
      this.setLepcBuild(data);
      this.setLepcOperate(data);
    });
  }

  setLepcBuild(data: any) {
    let control = <FormArray>this.subWorkstreamForm.controls.lepccodesBuild;

    if (data) {
      data.forEach(x => {
        if (x.buildOperate == 'build') {
          control.push(this.fb.group({
            lepcbuild: [x.lePcCode, []],
            workstreamPccodeSurrId: [x.subWorkStreamMapSurrId, []],
            buildOperate: [x.buildOperate, []],
            activeInd: [x.subWorkStreamLinked]
          }))
        }
      });
    }
  }

  setLepcOperate(data: any) {
    let control = <FormArray>this.subWorkstreamForm.controls.lepccodesOperate;

    if (data) {
      data.forEach(x => {
        if (x.buildOperate == 'operate') {
          control.push(this.fb.group({
            lePCCodeOperate: [x.lePcCode, []],
            workstreamPccodeSurrId: [x.subWorkStreamMapSurrId, []],
            buildOperate: [x.buildOperate, []],
            activeInd: [x.subWorkStreamLinked]
          }))
        }
      });
    }

  }

  getMinLiveDate(data){
    if(data != ''){
      let date = new Date(data);
      date.setDate(date.getDate()+1);
      return date;
    }else{
      return '';
    }
  }

  getMaxStartDate(){
    if(this.maxLiveDate && this.maxLiveDate != ''  && !isNaN(this.maxLiveDate.getTime())){
      let date = new Date(this.maxLiveDate);
      date.setDate(date.getDate()-1);
      return new Date(date);
    }else{
      return '';
    }
  }

  getCheckboxValueForOperate(index,event) {
    ((this.subWorkstreamForm.get('lepccodesOperate') as FormArray).at(index) as FormGroup).get('activeInd').patchValue(event.checked.toString());
  }
  getCheckboxValueForBuild(index,event){
    ((this.subWorkstreamForm.get('lepccodesBuild') as FormArray).at(index) as FormGroup).get('activeInd').patchValue(event.checked.toString());
  }
}
