import {Component, OnInit, OnDestroy, ChangeDetectorRef, AfterViewInit} from '@angular/core';
import {FormBuilder} from '@angular/forms';
import {DateUtility} from 'src/app/common/utility/date-utility';
import {Router} from '@angular/router';
import {RestService} from 'src/app/common/service/rest.service';
import {DataService} from 'src/app/common/service/data.service';
import {MatDialog} from '@angular/material/dialog';
import {TimeFormat} from 'src/app/common/pipes/timeFormater.pipe';
import {WORK_HIERARCHY_CONST} from 'src/constants/workHierarchy';
import {Subscription} from 'rxjs';
import {URL_PREFIX} from 'src/constants/urlsprefix';
import {HttpClient} from '@angular/common/http';
import {CommonService} from 'src/app/common/service/common.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-sub-workstream',
  templateUrl: './sub-workstream.component.html',
  styleUrls: ['./sub-workstream.component.scss', '../portfolio-details/view-portfolio/view-portfolio.component.scss'],
})
export class SubWorkstreamComponent implements OnInit, OnDestroy, AfterViewInit {
  portfolioID: any;
  portfolioNameFinal: any;
  hiddensubWorkStreamID: any;
  subWorkStreamName: string;
  subscription: Subscription;
  showSideNavigation = false;
  workstreamID: any;
  subPlatformData: any = [];
  subPlatFormName: any;
  keyDates: any = [];
  workstreamWorkMgr: any = [];
  scenarioMap = new Map<string, any>();
  subWorkStreamMgrMap = new Map<string, any>();
  subWorkStreamWorkMgr: any = [];
  subWorkStreamApproval: any = [];
  selectedTab: any;
  subWorkManagerSubWorkStreamId: any;
  SubWorkStreamApprovalId: any;
  subworkstreamMgrExists: boolean;
  subWorkStreamDates: any[];
  subWorkManagerSubWorkStreamId1: string[];
  subworkstreamDatesExists: boolean;
  SubWorkStreamId: any;
  subworkstreamApprovalExists: boolean;
  othersDataExists: boolean;
  othersFileData: any = [];
  subWSchanged: any;


  workstreamLePccodesEntities: any = [];
  buildLepcCodeData: any = [];
  operateLepcCodeData: any = [];

  headerInfo;
  tabObserver: Subscription;

  constructor(private fb: FormBuilder, private dateUtility: DateUtility, private route: Router, private restService: RestService, private dataService: DataService, public dialog: MatDialog,
              public formattime: TimeFormat, private http: HttpClient, private changeDetector: ChangeDetectorRef, private commonService: CommonService) {
    this.hiddensubWorkStreamID = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID);
    this.subWorkStreamName = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME);

    this.headerInfo = {
      title: sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME),
      show_filters: false,
      additional_info: sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID),
      tabs: ['Work Profile', 'Work Managers', 'Key Dates', 'Approvers', 'Financials', 'Others'],
      btns: {
        primary: {
          text: 'Edit Subworkstream',
          clbk: this.editSubWorkstream.bind(this)
        }
      }
    }
    this.headerInfo.prevent_idx_update = (this.dataService.getActiveTab() != '' && this.headerInfo.tabs.indexOf(this.dataService.getActiveTab()) >= 0);
    this.selectedTab = this.headerInfo.prevent_idx_update ? this.dataService.getActiveTab() : this.headerInfo.tabs[0];
    this.commonService.recieveMessage(this.headerInfo);
    sessionStorage.setItem('currentTab', this.selectedTab);
  }

  datavalues: any = [];
  subWorkStreamData: any = [];
  isErrorExists = false;

  ngOnInit() {
    this.getData();
    this.getOthersData();
    this.getWorkStreamKeyDates();
    this.subscription = this.dataService.itemChange.subscribe(msg => {
      if (msg === WORK_HIERARCHY_CONST.SUB_WORKSTREAM) {
        this.headerInfo.prevent_idx_update = false;
        this.headerInfo.title = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME);
        this.headerInfo.additional_info = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID);
        this.commonService.recieveMessage(this.headerInfo);
        this.selectedTab = this.headerInfo.tabs[0];
        this.getData();
        this.getWorkStreamKeyDates();
        this.getWorkMangersData();
        this.getApprovalsData();
        this.getOthersData();
        this.subWSchanged = sessionStorage.getItem('subWorkStreamId');
      }
    });
    this.hiddensubWorkStreamID = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID);
    this.subWorkStreamName = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME);
    this.getWorkMangersData();
    this.getApprovalsData();

    // tab observer
    this.tabObserver = this.commonService.selectedTab.subscribe(data => {
      this.selectedTab = data;
      sessionStorage.setItem('currentTab', this.selectedTab);
    });
  }

  ngAfterViewInit() {
    if (this.dataService.getActiveTab() && this.dataService.getActiveTab() != '' && this.headerInfo.tabs.indexOf(this.dataService.getActiveTab()) >= 0) {
      this.commonService.updateTab.emit(this.selectedTab);
      this.dataService.setActiveTab('');
    }
  }

  getWorkMangersData() {
    this.subworkstreamMgrExists = false;
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/subworkstream/getworkmanagers/' + this.hiddensubWorkStreamID + '/' + this.subWorkStreamName).subscribe(data => {
      if (data[0] != null && data[0] !== '') {
        this.subWorkStreamWorkMgr = [];
        this.subWorkManagerSubWorkStreamId = Object.keys(data[0]);
        if (this.subWorkManagerSubWorkStreamId != null && this.subWorkManagerSubWorkStreamId != '' && this.subWorkManagerSubWorkStreamId != 'undefined') {
          data[0][this.subWorkManagerSubWorkStreamId].forEach((e: { values: any; }) => {
            this.subworkstreamMgrExists = true;
            this.subWorkStreamWorkMgr.push(e);
          });
        }
      }
    });
  }

  getApprovalsData() {
    this.subworkstreamApprovalExists = false;
    // for testing - remove
    // this.restService.get(URL_PREFIX.PORTFOLIO + '/data/subworkstream/getApprovals/P19SG-19534-I0570-P19').subscribe (data => {
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/subworkstream/getApprovals/' + this.hiddensubWorkStreamID + '/' + this.subWorkStreamName).subscribe(data => {
      if (data != null && data !== '') {
        this.subWorkStreamApproval = [];
        data.forEach((e: { values: any; }) => {
          this.subworkstreamApprovalExists = true;
          this.subWorkStreamApproval.push(e);
        });
      }
    });
  }

  getData() {
    this.hiddensubWorkStreamID = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID);
    this.subWorkStreamName = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME);
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/portfolio/common/getportfoliodata/${this.hiddensubWorkStreamID}/SubWorkstream/${this.subWorkStreamName}?staffName=`).subscribe(data => {
      this.subWorkStreamData = data;
    });
    this.workstreamID = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID);
    this.getSubPlatformName(this.workstreamID);
    this.getWorkStreamPccodes();
  }

  goback() {
    this.route.navigateByUrl('home/portfolio');
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustom(date);
  }

  timeFormat(date?: Date) {
    const d = new Date(date);
    let time = d.getHours() + ':' + d.getMinutes();
    return this.formattime.transform(time);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.tabObserver.unsubscribe();
  }

  editSubWorkstream() {
    //this.action = 'edit';
    this.dataService.setAction('edit');
    this.route.navigateByUrl('home/portfolio/createPortfolio/subworkstream/' + this.hiddensubWorkStreamID + '/editSubworkstream');
  }

  getSubPlatformName(workstreamID) {
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/portfolio/common/getportfoliodata/${workstreamID}/WorkStream/''?staffName=`).subscribe(platFormdata => {
      this.subPlatformData = platFormdata;
      this.subPlatFormName = platFormdata.subPlatFormName;
    });
  }

  getWorkStreamKeyDates() {
    this.keyDates = [];
    this.subworkstreamDatesExists = false;
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/subworkstream/keyDatesList/${sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID)}/${this.hiddensubWorkStreamID}/${this.subWorkStreamName}`).subscribe(data => {
      if (data.subWorkStreamKeyDates && data.subWorkStreamKeyDates != null && data.subWorkStreamKeyDates.length > 0) {
        this.subworkstreamDatesExists = true;
        this.keyDates = data.subWorkStreamKeyDates;
        _.forEach(data, (val) => {
          if (val.scenarioName === 'Forecast') {
            this.dataService.setStartDate(this.dateFormatISO((val.startDate)));
            this.dataService.setSwEngStartDate(this.dateFormatISO(val.swEngStartDate));
            this.dataService.setGoLiveDate(this.dateFormatISO(val.goLiveDate));
            this.dataService.setEndDate(this.dateFormatISO(val.endDate));
          }
        })
      }
    });
  }

  getWorkStreamPccodes() {
    this.keyDates = [];
    this.buildLepcCodeData = [];
    this.operateLepcCodeData = [];
    let subWorkSreamIdName = {
      workStreamId: this.workstreamID,
      subWorkStreamId: this.hiddensubWorkStreamID,
      subWorkStreamName: this.subWorkStreamName
    };
    this.restService.post(URL_PREFIX.PORTFOLIO + '/data/subworkstream/pccodes/view', subWorkSreamIdName).subscribe(data => {
      this.workstreamLePccodesEntities = data;
      this.workstreamLePccodesEntities.forEach((element: { buildOperate: string; lePCCode: any; allocationPercent: any; }) => {
        if (element.buildOperate === 'build') {
          this.buildLepcCodeData.push({pcCode: element.lePCCode, pcCodeDesc: element.lePCCode, allocationPercent: element.allocationPercent});
        } else if (element.buildOperate === 'operate') {
          this.operateLepcCodeData.push({pcCode: element.lePCCode, pcCodeDesc: element.lePCCode, allocationPercent: element.allocationPercent});
        }
      });
    });
  }

  dateFormatISO(millisecondsDate?: any) {
    return this.dateUtility.dateFormatterISO(millisecondsDate);
  }

  getOthersData() {
    this.othersFileData = '';
    this.restService.get(URL_PREFIX.PORTFOLIO + '/file/others/subworkstreams/' + this.hiddensubWorkStreamID + '/' + this.subWorkStreamName).subscribe(data => {
      if (data != null && data !== '') {
        this.othersDataExists = true;
        this.othersFileData = data;
        this.changeDetector.detectChanges();
        this.changeDetector.markForCheck();
      }
    });
  }

  downloadFile(index: any, documentName: any) {
    window.location.href = URL_PREFIX.PORTFOLIO + '/file/download/subworkstream/' + index + '/' + documentName;
  }
}
