import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HLEComponent } from './hle.component';

xdescribe('HLEComponent', () => {
  let component: HLEComponent;
  let fixture: ComponentFixture<HLEComponent>;
  

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HLEComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HLEComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
