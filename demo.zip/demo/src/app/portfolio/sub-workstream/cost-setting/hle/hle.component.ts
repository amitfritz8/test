import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder, FormArray, FormControl, ValidatorFn } from '@angular/forms';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { DataService } from 'src/app/common/service/data.service';
import { DateAdapter, MAT_DATE_FORMATS, NativeDateAdapter } from '@angular/material/core';
import { RestService } from 'src/app/common/service/rest.service';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import * as _ from 'lodash';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { AppDateAdapter } from 'src/app/common/service/appDateAdapter';
import { APP_DATE_FORMATS } from 'src/app/common/service/appDateAdapter';
import { MatDialog } from '@angular/material/dialog';
//import { CostSettingsSaveComponent } from 'src/app/components/dialogues/cost-settings-save/cost-settings-save.component';
import { CommonService } from 'src/app/common/service/common.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-hle',
  templateUrl: './hle.component.html',
  styleUrls: ['./hle.component.scss'],
  providers: [
    {
      provide: DateAdapter, useClass: AppDateAdapter
    },
    {
      provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
    }
  ]
})
export class HLEComponent implements OnInit {

  hleform: FormGroup;
  currencyCode: any;
  category: any;
  selectedTimestamp: any;
  //HLEFinancialInputmessage: String;
  //currencyDropDownList = [];
  currencyCodeDefault: any;
  currencyMap = new Map();
  categoryList = [];
  hleData: any;
  editAction: boolean;
  data: any;
  totalInvestment: Number;
  totalPL: Number;
  temp: any;
  glCategoryKeysArray = [];
  glCategoryList = [];
  startDate: any;
  goLiveDate: any;
  HLEKeyDatesErrorMsg: string;
  keyDatesErrorExists: boolean = false;
  startMonthLaterThanCurrentSystemMonthErrMsg:String;
  startMonthLaterThanCurrentSystemMonth: boolean = false;
  workStreamId: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID);
  subWorkStreamId: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID);
  subWorkStreamName: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME);
  scenario: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.SCENARIO);
  currencyCodeType: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.CURRENCY_CODE_TYPE);
  currentDate:any;

  constructor(private restService: RestService, private router: Router, private fb: FormBuilder, private dataService: DataService,
    public dialog: MatDialog, private dateUtility: DateUtility, private commonService: CommonService,private datePipe: DatePipe) {
  }

  ngOnInit() {
    this.editAction = history.state.editAction;
    this.getData();
    this.getHLEKeydatesError();
    this.getHLEKeydatesErrorForStartMonthLaterThanCurrentSystemMonth();
    this.hleform = this.fb.group({
      startDate: ['', [Validators.required]],
      goLiveDate: ['', [Validators.required]],
      currencyCodeType: this.currencyCodeType,
      workStreamId: this.workStreamId,
      subWorkStreamId: this.subWorkStreamId,
      subWorkStreamName: this.subWorkStreamName,
      dateCreated: [''],
      createdBy: [''],
      modifiedBy: [''],
      modifiedDate: [''],
      scenario: this.scenario,
      financialInputGroup: this.fb.array([])
    });
   // this.getFinancialInputData();
  }

  getData() {
    this.restService.get(URL_PREFIX.PORTFOLIO + '/financial/hleData?workStreamId=' + this.workStreamId + "&subWorkStreamId=" + this.subWorkStreamId + "&subWorkStreamName=" + this.subWorkStreamName + "&currencyCodeType=" + this.currencyCodeType + "&scenario=" + this.scenario).subscribe(data => {
      if (Object.keys(data).length) {
        this.hleData = data;
        this.hleform.controls.startDate.setValue(this.hleData.startDate);
        this.hleform.controls.goLiveDate.setValue(this.hleData.goLiveDate);
        if(this.hleform.controls.startDate.value){
          this.currentDate = this.datePipe.transform(new Date(), 'yyyy-MM');
          this.startDate = this.datePipe.transform(this.hleform.controls.startDate.value, 'yyyy-MM');
          if(this.startDate < this.currentDate){
            this.startMonthLaterThanCurrentSystemMonth = true;
          }else{
            this.startMonthLaterThanCurrentSystemMonth = false;
          }
        }
        this.getHeader();
        this.setHleData();
      }
    },
      error => {
        if (error.status !== null) {
          console.log(error + 'error');
          let control = this.hleform.controls;
          if (!control.startDate.value && !control.goLiveDate.value) {
            this.keyDatesErrorExists = true;
          } else {
            this.keyDatesErrorExists = false;
          }
        }
      });
  }

  // getFinancialInputData() {
  //   this.restService.get(URL_PREFIX.PEOPLE + '/data/dataValues/sys-msg?msgKey=MSG_INFO_HLE_Financial_Input').subscribe(data => {
  //     this.HLEFinancialInputmessage = data.message;
  //   });
  // }


  get financialInputGroupArray() {
    return this.hleform.get('financialInputGroup') as FormArray;
  }
  onSave() {
    let controls = this.hleform.controls;
    if (!controls.startDate.value && !controls.goLiveDate.value) {
      this.keyDatesErrorExists = true;
    }
    else {
      this.keyDatesErrorExists = false;
    }
    if (!this.keyDatesErrorExists) {
      let control = <FormArray>this.hleform.controls.financialInputGroup;
      for (let index = 0; index < control.value.length; index++) {
        const element = control.value[index];
        if (element.costType == 'Total') {
          control.value.splice(index, 1);
        }
        for (let index = 0; index < element.dynamicData.length; index++) {
          const x = element.dynamicData[index];
          if (x.glCategoryName == 'Total') {
            element.dynamicData.splice(index, 1);
          }

        }
      }
      if (!this.keyDatesErrorExists) {
        const request = this.hleform.value;
        this.restService.post(URL_PREFIX.PORTFOLIO + '/financial/saveHleData', request).subscribe(data => {
          this.editAction = false;
          // this.dataService.setActiveTab('1');
          this.commonService.showSnackBar({
            type: 'success',
            message: "HLE updated successfully"
          })
          this.router.navigateByUrl('/home/portfolio/createPortfolio/subworkstream/' + sessionStorage.getItem('subWorkStreamId') + '/cost-setting');
          this.hleData = [];
          //this.totalAmount=0;
          this.getData();
        }, error => {
          if (error.status !== null) {
            //this.dataService.setActiveTab('4');
            this.router.navigateByUrl('/home/portfolio/createPortfolio/subworkstream/' + sessionStorage.getItem('subWorkStreamId'));
          }
        });
      }
    }
  }

  getHeader() {
    let array: [];
    array = this.hleData.financialInputGroup[0].dynamicData;
    this.glCategoryKeysArray = [];
    this.glCategoryList = [];
    // this.glCategoryKeysArray.push('Cost Type');
    _.forIn(array, (e) => {
      this.glCategoryKeysArray.push(e['glCategoryName']);
      this.glCategoryList.push(e['glCategoryName']);
    })
    this.glCategoryKeysArray.push('Total');
    this.glCategoryList.push('Total');
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustom(date);
  }

  setHleData() {
    //this.hleform.controls.financialInputGroup=this.fb.array([]);
    let control = <FormArray>this.hleform.controls.financialInputGroup;
    let horiTotal = 0; //row rotalling
    for (let index = 0; index < this.hleData.financialInputGroup.length; index++) {
      const element = this.hleData.financialInputGroup[index];
      _.forIn(element.dynamicData, (v, k) => {
        if (k == 'Total') {
          delete element.dynamicData[k];
        }
      })
    }

    for (let index = 0; index < this.hleData.financialInputGroup.length; index++) {
      const element = this.hleData.financialInputGroup[index];
      _.forIn(element.dynamicData, (e) => {
        // if(element.dynamicData[k].equalIgnoreCase('Total')){
        horiTotal = e.value + horiTotal;
        //  }
      })
      // element.dynamicData.Total = horiTotal;
      element.dynamicData.push({
        "hleSurrId": 0,
        "costType": element.costType,
        "glCategoryName": "Total",
        "value": horiTotal
      })
      horiTotal = 0;
    }
    this.hleData.userLoggedInCountry = localStorage.getItem('userLoggedInCountry');

    let dynamicData: any = [];
    for (let index = 0; index < this.glCategoryList.length; index++) {
      const element = this.glCategoryList[index];
      dynamicData.push({
        "hleSurrId": 0,
        "costType": "Total",
        "glCategoryName": element,
        "value": 0
      })
    }

    this.hleData.financialInputGroup.push({
      'costType': 'Total',
      'dynamicData': dynamicData
    });

    let total = 0; //column totalling
    for (let index = 0; index < this.glCategoryList.length; index++) {
      const element = this.glCategoryList[index];
      this.hleData.financialInputGroup.forEach(x => {
        if (x['costType'] != 'Total') {
          _.forIn(x.dynamicData, (e) => {
            if (element == e.glCategoryName) {
              total = total + Number(e.value);
            }
          })
        } else {
          _.forIn(x.dynamicData, (e) => {
            if (element == e.glCategoryName) {
              e.value = Number(total);
            }
          })
          // x.dynamicData[element] = total;
          total = 0;
        }
      });
    }
    this.totalInvestment = 0;
    this.totalPL = 0;
    _.forIn(this.hleData.financialInputGroup[this.hleData.financialInputGroup.length - 1].dynamicData, (e) => {

      if (e.glCategoryName && e.glCategoryName.toLowerCase() === "capex") {
        this.totalInvestment = Number(e.value);
      } else if (e.glCategoryName && e.glCategoryName.toLowerCase() === "opex") {
        this.totalInvestment = Number(this.totalInvestment) + Number(e.value);
        this.totalPL = Number(this.totalPL) + Number(e.value);
      } else if (e.glCategoryName && e.glCategoryName.toLowerCase() === "ownership") {
        this.totalPL = Number(this.totalPL) + Number(e.value);
      } else if (e.glCategoryName && e.glCategoryName.toLowerCase() === "it depreciation") {
        this.totalPL = Number(this.totalPL) + Number(e.value);
      }
    })

    if (this.hleData.financialInputGroup) {
      let initial: FormGroup;
      this.hleData.financialInputGroup.forEach(x => {
        initial = this.fb.group({
          costType: this.fb.control(x['costType']),
          dynamicData: this.fb.array([])
        })
        let fg = <FormArray>initial.get('dynamicData');

        let hTotal = 0;
        _.forIn(x.dynamicData, (x) => {
          //fg.addControl(k, this.fb.control(v));
          fg.push(this.fb.group({
            hleSurrId: x.hleSurrId,
            costType: x.costType,
            glCategoryName: x.glCategoryName,
            value: x.value
          }))
        })
        control.push(initial);
      })

    }
  }

  getTotal(type: string, rowIndex) {
    let vTotal = 0;
    let hTotal = 0;
    //capex data to IT depreciation data patching    
    let itDeprecitaionValue = 0;
    let financialInputGroup = <FormArray>this.hleform.controls.financialInputGroup;
    const ele = financialInputGroup.value[rowIndex];
    if(type && type.toLowerCase() === "capex"){
      ele.dynamicData.forEach(e => {
        if (e['glCategoryName'] && e['glCategoryName'].toLowerCase() === 'capex') {
            itDeprecitaionValue = e.value;
        }
        });
      ((((this.hleform.get('financialInputGroup') as FormArray).at(rowIndex) as FormGroup)
      .get('dynamicData') as FormArray).at(ele.dynamicData.length - 2) as FormGroup).get('value').patchValue(itDeprecitaionValue);
      itDeprecitaionValue=0;
    }

    //column totalling
    let vItDepreTotal=0;
    let dynamicDataLength = ((this.hleData.financialInputGroup.length) - 1);
    let control = <FormArray>this.hleform.controls.financialInputGroup;
    control.value.forEach(x => {
      if (x['costType'] && x['costType'].toLowerCase() != 'total') {
        _.forIn(x.dynamicData, (e) => {
          if (type == e.glCategoryName) {
            vTotal = vTotal + Number(e.value);
          }
          if (type.toLowerCase() ==="capex" && e.glCategoryName.toLowerCase() ==="it depreciation") {
            vItDepreTotal = vItDepreTotal + Number(e.value);
          }
        })
      } else {
        _.forIn(x.dynamicData, (e) => {
          if (type == e.glCategoryName) {
            e.value = Number(vTotal);
          }
        })
      }
    });
    let dydata = ((this.hleform.get('financialInputGroup') as FormArray).at(dynamicDataLength) as FormGroup)
      .get('dynamicData'); 
    for (let index = 0; index < dydata.value.length; index++) {
      const x = dydata.value[index];
      if (type == x.glCategoryName) {
        ((((this.hleform.get('financialInputGroup') as FormArray).at(dynamicDataLength) as FormGroup)
          .get('dynamicData') as FormArray).at(index) as FormGroup).get('value').patchValue(vTotal);         
      }
      //IT Depre vTotal patching
      if(type.toLowerCase() ==="capex" && x.glCategoryName.toLowerCase() ==="it depreciation"){
        ((((this.hleform.get('financialInputGroup') as FormArray).at(dynamicDataLength) as FormGroup)
        .get('dynamicData') as FormArray).at(index) as FormGroup).get('value').patchValue(vItDepreTotal); 
      }
    }

    //row totalling
    let horiTotal = 0;
    let financialInputGroupcontrol = <FormArray>this.hleform.controls.financialInputGroup;
    const element = financialInputGroupcontrol.value[rowIndex];
    element.dynamicData.forEach(e => {

      if (e['glCategoryName'] != 'Total') {
        horiTotal = e.value + horiTotal;
      }
    });
    ((((this.hleform.get('financialInputGroup') as FormArray).at(rowIndex) as FormGroup)
      .get('dynamicData') as FormArray).at(element.dynamicData.length - 1) as FormGroup).get('value').patchValue(horiTotal);
    horiTotal = 0;

    for (let index = 0; index < dydata.value.length; index++) {
      const x = dydata.value[index];
      if (x.glCategoryName != 'Total') {
        hTotal = x.value + hTotal;
      }
    }
    ((((this.hleform.get('financialInputGroup') as FormArray).at(dynamicDataLength) as FormGroup)
      .get('dynamicData') as FormArray).at(dynamicDataLength) as FormGroup).get('value').patchValue(hTotal);

    //Total investement and Total P&L totalling
    this.totalInvestment = 0;
    this.totalPL = 0;
    _.forIn(<FormArray>this.hleform.controls.financialInputGroup.value[this.hleData.financialInputGroup.length - 1].dynamicData, (e) => {

      if (e.glCategoryName && e.glCategoryName.toLowerCase() === "capex") {
        this.totalInvestment = Number(e.value);
      } else if (e.glCategoryName && e.glCategoryName.toLowerCase() === "opex") {
        this.totalInvestment = Number(this.totalInvestment) + Number(e.value);
        this.totalPL = Number(this.totalPL) + Number(e.value);
      } else if (e.glCategoryName && e.glCategoryName.toLowerCase() === "ownership") {
        this.totalPL = Number(this.totalPL) + Number(e.value);
      } else if (e.glCategoryName && e.glCategoryName.toLowerCase() === "it depreciation") {
        this.totalPL = Number(this.totalPL) + Number(e.value);
      }
    })

  }
  getHLEKeydatesError() {
    this.restService.get(URL_PREFIX.PEOPLE + '/data/dataValues/sys-msg?msgKey=ERR_KEYDATESBLANK_COSTSETTINGHLE').subscribe(data => {
      this.HLEKeyDatesErrorMsg = data.message;
    });
  }

  getHLEKeydatesErrorForStartMonthLaterThanCurrentSystemMonth() {
    this.restService.get(URL_PREFIX.PEOPLE + '/data/dataValues/sys-msg?msgKey=ERR_STARTMONTH_LATERTHAN_CURRENTMONTH_COSTSETTINGHLE').subscribe(data => {
      this.startMonthLaterThanCurrentSystemMonthErrMsg = data.message;
    });
  }
}

