import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CostSettingComponent } from './cost-setting.component';

xdescribe('CostSettingComponent', () => {
  let component: CostSettingComponent;
  let fixture: ComponentFixture<CostSettingComponent>;
  

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CostSettingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CostSettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
