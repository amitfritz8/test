// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { SeedFundingComponent } from './seed-funding.component';

// describe('SeedFundingComponent', () => {
//   let component: SeedFundingComponent;
//   let fixture: ComponentFixture<SeedFundingComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ SeedFundingComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(SeedFundingComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
