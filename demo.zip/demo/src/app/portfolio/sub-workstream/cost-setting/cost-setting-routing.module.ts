import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CostSettingComponent } from './cost-setting.component';
import { HLEComponent } from './hle/hle.component';
import { SharedModule } from 'src/app/common/module/shared.module';
import { FinancialDetailsComponent } from './financial-details/financial-details.component';
import { SeedFundingComponent } from './seed-funding/seed-funding.component';

const routes: Routes = [
  { path: '', component: CostSettingComponent },
  { path: 'hle', component: HLEComponent },
  { path: 'financial-details', component: FinancialDetailsComponent },
  {
    path: 'seed-funding', component: SeedFundingComponent
  }

];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
  ],
  declarations: [
    CostSettingComponent,
    HLEComponent,
    FinancialDetailsComponent,
    SeedFundingComponent
  ],
  exports: [],
  entryComponents: []
})

export class CostSettingRoutingModule {
}