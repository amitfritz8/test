import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateWorkstreamComponent } from './create-workstream.component';

xdescribe('CreateWorkstreamComponent', () => {
  let component: CreateWorkstreamComponent;
  let fixture: ComponentFixture<CreateWorkstreamComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateWorkstreamComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateWorkstreamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
