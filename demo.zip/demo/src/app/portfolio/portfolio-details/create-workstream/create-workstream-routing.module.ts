import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/common/module/shared.module';
import { CreateWorkstreamComponent } from './create-workstream.component';

const routes: Routes = [
    {path: '', component: CreateWorkstreamComponent}
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
  ],
  declarations: [
    CreateWorkstreamComponent
  ],
  exports: [],
  entryComponents: []
})

export class CreateWorkStreamRoutingModule {
}