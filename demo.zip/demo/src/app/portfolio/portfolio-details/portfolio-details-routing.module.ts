import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/common/module/shared.module';
import { PortfolioService } from './portfolio.service';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('src/app/portfolio/portfolio-details/view-portfolio/view-portfolio-routing.module').then(m => m.ViewPortfolioRoutingModule),
  },
  {
    path: 'editPortfolio',
    loadChildren: () => import('src/app/portfolio/portfolio-details/edit-portfolio/edit-portfolio-routing.module').then(m => m.EditPortfolioRoutingModule),
  },
  {
    path: 'createWorkstream',
    loadChildren: () => import('src/app/portfolio/portfolio-details/create-workstream/create-workstream-routing.module').then(m => m.CreateWorkStreamRoutingModule),
  }

];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
  ],
  declarations: [
  ],
  providers: [PortfolioService],
  exports: [],
  entryComponents: []
})

export class PortfolioDetailsRoutingModule {
}
