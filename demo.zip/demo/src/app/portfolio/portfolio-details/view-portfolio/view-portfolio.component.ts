import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { MatDialog } from '@angular/material/dialog';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { TimeFormat } from 'src/app/common/pipes/timeFormater.pipe';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import { CopyScenarioDialogComponent } from 'src/app/common/component/dialogues/copy-scenario-dialog/copy-scenario-dialog.component';
import { CommonService } from 'src/app/common/service/common.service';
import { Subscription } from 'rxjs';
import { PortfolioService } from '../portfolio.service';
import { CommonDialogComponent } from 'src/app/common/component/dialogues/common-dialog/common-dialog-component';
import { ApproverDialogComponent } from 'src/app/common/component/dialogues/approver-dialog/approver-dialog.component';
import { DatePipe } from '@angular/common';
import * as _ from 'lodash';

@Component({
  selector: 'app-view-portfolio',
  templateUrl: './view-portfolio.component.html',
  styleUrls: ['./view-portfolio.component.scss']
})
export class ViewPortfolioComponent implements OnInit, OnDestroy, AfterViewInit {
  portfolioID: any;
  portfolioNameFinal: any;
  hiddenportfolioID: any;
  scenarioDrop: any;
  showSideNavigation = false;
  portId: any;
  workstreamID: any;
  portfolioMgrExists = false;
  workstreamMgrExists = false;
  keyDatesNames: any;
  selectedTab: string;
  headerInfo;
  tabObeserver: Subscription;
  copyTo: Array<string>;
  approverScenarios: Array<string>;

  constructor(private fb: FormBuilder, private dateUtility: DateUtility, private route: Router, private restService: RestService, private dataService: DataService,
    public dialog: MatDialog, public formattime: TimeFormat, private commonService: CommonService, private ps: PortfolioService, private datepipe: DatePipe) {
    this.hiddenportfolioID = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID);
    this.headerInfo = {
      title: sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME),
      show_filters: false,
      additional_info: sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID),
      tabs: ['Work Profile', 'Work Managers', 'Key Dates', 'Approvers', 'Financials'],
      btns: {
        primary: {
          text: 'Edit Portfolio',
          clbk: this.editClbk.bind(this)
        },
        addclbk: this.addCreateWorkstream.bind(this),
        moreOptions: [
          {
            text: 'Copy Scenario to',
            clbk: this.copyScenario.bind(this),
            disabled: false
          }
        ]
      }
    }
    this.headerInfo.prevent_idx_update = (this.dataService.getActiveTab() != '' && this.headerInfo.tabs.indexOf(this.dataService.getActiveTab()) >= 0);
    this.selectedTab = this.headerInfo.prevent_idx_update ? this.dataService.getActiveTab() : this.headerInfo.tabs[0];
    this.commonService.recieveMessage(this.headerInfo);
    sessionStorage.setItem('currentTab',this.selectedTab);
  }
  portfolioform: FormGroup;
  datavalues: any = [];
  portfolioData: any = [];
  portfolioWorkMgr: any = [];
  workstreamWorkMgr: any = [];
  keyDatesTotal: any = [];
  isErrorExists = false;
  WkStrmMgrMap = new Map<string, any>();
  scenarioMap = new Map<string, any>();
  approversMap = new Map<string, any>();
  approversData: any;
  approversNames: any;
  approversTotal: any = [];

  ngOnInit() {
    this.getData();
    this.getWorkStreamKeyDates();
    this.getApprovers();
    this.getCopyScenarios();
    this.getCopyScenarioApprover();

    // for updating tabs
    this.tabObeserver = this.commonService.selectedTab.subscribe(data => {
      this.selectedTab = data;
      sessionStorage.setItem('currentTab',this.selectedTab);
    })

  }
  ngAfterViewInit() {
    if (this.dataService.getActiveTab() != '' && this.headerInfo.tabs.indexOf(this.dataService.getActiveTab()) >= 0) {
      this.commonService.updateTab.emit(this.selectedTab);
      this.dataService.setActiveTab('');
    }
  }

  editClbk() {
    this.editPortfolio(this.portfolioData.portfolioId);
  }

  ngOnDestroy() {
    // this.commonService.msg2Tab(0);
    this.tabObeserver.unsubscribe();
  }

  getData() {
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/portfolio/common/getportfoliodata/${this.hiddenportfolioID}/Portfolio/''?staffName=`).subscribe(data => {
      this.portfolioData = data;
    });
    
    this.portfolioMgrExists = false;
    this.workstreamMgrExists = false;
    this.workstreamWorkMgr = [];
    this.portfolioWorkMgr = [];
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/portfolio/getworkmanagers/' + this.hiddenportfolioID).subscribe(data => {
      if (data[0] != null && data[0] !== '' && !_.isEmpty(data[0])) {
        this.portId = Object.keys(data[0]);
        if (this.portId != null && this.portId !== '') {
          data[0][this.portId].forEach((wkMgr: { values: any; }) => {
            this.portfolioMgrExists = true;
            this.portfolioWorkMgr.push(wkMgr);
          });
        }
      }
      if (data[1] != null && data[1] != null && !_.isEmpty(data[1])) {
        Object.keys(data[1]).forEach(wkstrmId => {
          if (wkstrmId != null && wkstrmId !== '') {
            this.workstreamID = wkstrmId;
            data[1][this.workstreamID].forEach((wkMgr1: { values: any; }) => {
              this.workstreamMgrExists = true;
              this.workstreamWorkMgr.push(wkMgr1);
            });
            this.WkStrmMgrMap.set(this.workstreamID, this.workstreamWorkMgr);
            this.workstreamWorkMgr = [];
          }

        });
      }
    });

  }
  goback() {
    this.route.navigateByUrl('home/portfolio');
  }
  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustom(date);
  }
  timeFormat(date?: Date) {
    const d = new Date(date);
    const time = d.getHours() + ':' + d.getMinutes();
    return this.formattime.transform(time);
  }
  addCreateWorkstream() {
    this.route.navigateByUrl('home/portfolio/createPortfolio/showPortfolio/createWorkstream');
    this.dataService.setAction('add');
  }

  copyToCallback(postData) {
    try {
      this.ps.copyTo(postData).subscribe(data => {
        this.getApprovers();
        this.getWorkStreamKeyDates();
        this.dialog.open(CommonDialogComponent, {
          data: {
            type: 'success',
            contentTitle: "Your Data has been copied successfully",
            content: `All Data From the ${postData.scenarioFrom} Scenario has been copied to the ${postData.scenarioTo}.You may now preview the data in the relevant scenarios`,
            confirmTxt: "Done"
          }
        });
      },
        err => {
          console.log(err);
        })
    } catch (e) {
      console.log(e);
    }
  }

  approverCallback(postData) {
    try {
      let fData = new FormData();
      fData.append('approvalDate', `${this.datepipe.transform(postData.approvalDate, 'yyyy-MM-dd')} ${this.datepipe.transform(new Date(), 'hh:mm:ss')}`);
      fData.append('createdBy', localStorage.getItem('userOneBankId'));
      fData.append('workStreamId', '');
      fData.append('workStreamName', '');
      fData.append('portfolioId', sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID));
      fData.append('scenarioTo', postData.scenarioTo);
      fData.append('description', '');
      _.forEach(postData.file, (file) => {
        fData.append('file', file);
      });
      this.ps.postApprovers(fData).subscribe(
        data => {
          this.getApprovers();
          this.dialog.open(CommonDialogComponent, {
            data: {
              type: 'success',
              contentTitle: "Your scenario has been marked as approved",
              content: `You will not able to make any further edits to the scenario data. Please contact your administrator if you need to make any changes`,
              confirmTxt: "Done"
            }
          });
        },
        err => {
          console.log(err);
        });
    } catch (e) {
      console.log(e);
    }
  }

  getCopyScenarios() {
    try {
      this.ps.getScenario({ requestType: 'Portfolio' }).subscribe(
        data => {
          this.copyTo = data;
        },
        err => {
          console.log(err);
        })
    } catch (e) {
      console.log(e);
    }
  }

  getCopyScenarioApprover() {
    try {
      this.ps.getApprovers({ requestType: 'Portfolio', id: sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID) }).subscribe(
        data => {
          this.approverScenarios = data;
          if (this.headerInfo.btns.moreOptions.length > 1 && this.headerInfo.btns.moreOptions[1].text == 'Mark as Approved') {
            this.headerInfo.btns.moreOptions[1].disabled = data.length <= 0;
          } else {
            this.headerInfo.btns.moreOptions.push(
              {
                text: 'Mark as Approved',
                clbk: this.approveScenario.bind(this),
                disabled: data.length <= 0,
              }
            )
          }
          this.commonService.recieveMessage(this.headerInfo);
        },
        err => {
          console.log(err);
        }
      )
    } catch (e) {
      console.log(e);
    }
  }

  copyScenario() {
    const dialogRef = this.dialog.open(CopyScenarioDialogComponent, {
      data: {
        header: 'Copy Scenario to',
        copyTo: this.copyTo,
        copyFrom: ['Forecast'],
        workStreamId: null,
        portFolioId: sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID),
        copyToCallback: this.copyToCallback.bind(this)
      }
    });
  }

  approveScenario() {
    const dialogRef = this.dialog.open(ApproverDialogComponent, {
      data: {
        header: 'Mark as Approved',
        approveTo: this.approverScenarios,
        callback: this.approverCallback.bind(this)
      }
    });
  }

  editPortfolio(portfolioId: any) {
    this.route.navigateByUrl('home/portfolio/createPortfolio/showPortfolio/editPortfolio');
  }
  // tslint:disable-next-line: variable-name
  navToWrkStream(_data: any, activeTab: string) {
    sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID, _data.value[0].workStreamId);
    this.dataService.sendMessageItemChange(WORK_HIERARCHY_CONST.WORKSTREAM);
    this.dataService.setActiveTab(activeTab);
    this.route.navigateByUrl('home/portfolio/createPortfolio/workstream/' + _data.value[0].workStreamId);
  }

  getWorkStreamKeyDates() {
    this.scenarioMap = new Map<string, any>();
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/workstream/listOfKeyDatesPortfolio/' + this.hiddenportfolioID).subscribe(data => {
      this.scenarioDrop = data;
      if (this.scenarioDrop[0] != null) {
        Object.keys(this.scenarioDrop[0]).forEach(keyDateName => {
          if (keyDateName != null && keyDateName !== '') {
            this.keyDatesNames = keyDateName;
            this.scenarioDrop[0][this.keyDatesNames].forEach((datesName: { values: any; }) => {
              this.keyDatesTotal.push(datesName);
            });
            const isTrue = keyDateName.includes('WS0');
            if (isTrue) {
              this.scenarioMap.set(this.keyDatesNames, this.keyDatesTotal);
            }
            this.keyDatesTotal = [];
          }
        });
      }

      if (this.scenarioDrop[0] != null) {
        Object.keys(this.scenarioDrop[0]).forEach(keyDateName => {
          if (keyDateName != null && keyDateName !== '') {
            this.keyDatesNames = keyDateName;
            this.scenarioDrop[0][this.keyDatesNames].forEach((datesName: { values: any; }) => {
              this.keyDatesTotal.push(datesName);
            });
            const isTrue = keyDateName.includes('WS0');
            if (!isTrue) {
              this.scenarioMap.set(this.keyDatesNames, this.keyDatesTotal);
            }
            this.keyDatesTotal = [];
          }
        });
      }
    });
  }

  getApprovers() {
    this.approversMap = new Map<string, any>();
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/portfolio/approvers/' + this.hiddenportfolioID).subscribe(data => {
      this.approversData = data;
      if (this.approversData[0] != null) {
        Object.keys(this.approversData[0]).forEach(name => {
          if (name != null && name !== '') {
            this.approversNames = name;
            this.approversData[0][this.approversNames].forEach(approName => {
              this.approversTotal.push(approName);
            });
            const isTrue = name.includes('WS0');
            if (isTrue) {
              this.approversMap.set(this.approversNames, this.approversTotal);
            }
            this.approversTotal = [];
          }
        });
      }

      if (this.approversData[0] != null) {
        Object.keys(this.approversData[0]).forEach(name => {
          if (name != null && name !== '') {
            this.approversNames = name;
            this.approversData[0][this.approversNames].forEach(approName => {
              this.approversTotal.push(approName);
            });
            const isTrue = name.includes('WS0');
            if (!isTrue) {
              this.approversMap.set(this.approversNames, this.approversTotal);
            }
            this.approversTotal = [];
          }
        });
      }
    });
  }

  asIsOrder(a, b) {
    return 1;
  }
}
