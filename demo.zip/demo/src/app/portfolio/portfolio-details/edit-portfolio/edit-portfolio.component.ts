import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, ValidatorFn, ValidationErrors } from '@angular/forms';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { TimeFormat } from 'src/app/common/pipes/timeFormater.pipe';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { Observable, Subscription } from 'rxjs';
import { startWith, map, delay } from 'rxjs/operators';
import { Trie } from 'prefix-trie-ts';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import { CommonService } from 'src/app/common/service/common.service';
import { CommonDialogComponent } from 'src/app/common/component/dialogues/common-dialog/common-dialog-component';
import { HttpErrorResponse } from '@angular/common/http';
import * as _ from 'lodash';

@Component({
  selector: 'app-edit-portfolio',
  templateUrl: './edit-portfolio.component.html',
  styleUrls: ['./edit-portfolio.component.scss']
})
export class EditPortfolioComponent implements OnInit, OnDestroy {
  showWMinput: boolean = false;
  trie = new Trie([]);
  employeeMap = new Map<string, string>();
  portfolioName: any;
  hiddenportfolioID: any;
  isPortfolioNameExist: boolean;
  portfolioId: any;
  resSuccess: boolean;
  budgetStatusSelectedToolTip: any;
  planningCycleSelectedTooltip: any;
  budgetSystemOwnerSelectedToolTip: any;
  portSurrId: any;
  showSideNavigation = false;
  role = 'bu';
  filteredEmployees: Observable<any>;
  portfolioForm: FormGroup;
  portfolioData: any = [];
  isErrorExists = false;
  selPortfolioName: any;
  workTypeDropdown: any = [];
  budgetStatusList: any = [];
  planningCycleList: any = [];
  budgetSystemOwnerList: any = [];
  thematicsDropdown: any = [];
  businesSegmentDropdown: any = [];
  horizonDropDownList: any = [];
  workStatusDropdown: any = [];
  agileOrWaterfallDropdown: any = [];
  reportingFlagDropdown: any = [];
  defaultWorkType: any;
  prepareData: any;
  employeeList = [];
  checkValidOptionForWorkManager = false;
  workManagerData = [];
  portfolioManagerData = [];
  portfolioManagerDataVals = [];
  empdata = {};
  staffName: string;
  tempOneBankIds = [];
  selThematic: any;
  selHorizon: any;
  //selbizSegment: any;
  selAgileWaterFall: any;
  selBizSegment: any;
  thematic: any;
  bizSegment: any;
  agileWaterFall: any;
  reportingFlag: any;
  headerInfo;
  selectedTab: string;
  tabObserver: Subscription;
  showSaveBtn: boolean = true;
  timer: any;
  duplicateWorkmanager: object = {};

  constructor(private formBuilder: FormBuilder, private dateUtility: DateUtility, private route: Router, private restService: RestService, private dataService: DataService,
    public dialog: MatDialog, public formattime: TimeFormat, private commonService: CommonService) {
    this.hiddenportfolioID = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID);
    this.portfolioName = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME);
    this.portfolioForm = this.formBuilder.group({
      portfolioName: ['', [Validators.required, Validators.maxLength(100)]],
      initiationYear: ['', [Validators.required]],
      workType: ['', []],
      primaryPlatformName: ['', [Validators.required]],
      workManagers: this.formBuilder.array([]),
      workManagerName: ['', []],
      portfolioRefId: [''],
      portfolioDesc: ['', [Validators.required]],
      platformName: ['', [Validators.required]],
      budgetStatus: ['', [Validators.required]],
      planningCycle: [''],
      budgetSystemOwner: ['', [Validators.required]],
      bizSegment: [''],
      thematic: ['', [Validators.required]],
      horizon: ['', [Validators.required]],
      agileWaterFall: ['', [Validators.required]],
      portSurrId: [''],
      portfolioId: [''],
      dateCreated: [''],
      createdBy: [''],
      reportingFlag: ['', [Validators.required]]
    });

    this.headerInfo = {
      title: sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME),
      show_filters: false,
      additional_info: sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID),
      tabs: ['Work Profile', 'Work Managers']
    }
    this.selectedTab = (_.includes(this.headerInfo.tabs, sessionStorage.getItem('currentTab'))) ? sessionStorage.getItem('currentTab') : this.headerInfo.tabs[0];
    this.headerInfo.prevent_idx_update = (this.selectedTab != '' && this.headerInfo.tabs.indexOf(this.selectedTab) >= 0);
    if (this.headerInfo.prevent_idx_update) {
      this.commonService.updateTab.emit(this.selectedTab);
    }
    this.commonService.recieveMessage(this.headerInfo);
  }

  private wrkMngrValidator(idx): ValidatorFn {
    return (group: FormGroup): ValidationErrors => {
      let email = group.controls['emailAddress'];
      if (email.value != '' && !_.isEmpty(this.duplicateWorkmanager)) {
        if (this.duplicateWorkmanager[idx] == email.value) {
          group.controls['staffName'].setErrors({ duplicate: true });
          return;
        } else {
          group.controls['staffName'].setErrors(null);
          return;
        }
      } else {
        group.controls['staffName'].setErrors(null);
        return;
      }
    };
  }

  private _filterEmployee(data: any) {
    return this.trie.getPrefix(data);
  }

  workManagers(): FormArray {
    return this.portfolioForm.get('workManagers') as FormArray;
  }

  typeOption() {
    let ind = false;
    this.portfolioForm.value.workManagers.forEach(e => {

      if (!this.checkValidOptionForWorkManager && e.staffName == this.portfolioForm.controls.workManagerName.value.staffName) {
        this.checkValidOptionForWorkManager = true;
        ind = true;
        //this.portfolioForm.controls.workManagerName.setErrors({ notInOption: true });
      }
    });
    if (ind == false) {
      this.checkValidOptionForWorkManager = false;
    }
  }

  ngOnInit() {
    this.getData();
    this.getDropDownLists();
    this.filteredEmployees = this.portfolioForm.controls.workManagerName.valueChanges
      .pipe(
        map(empName => empName.length > 1 ? this._filterEmployee(empName) : []),
        delay(500)
      );

    // for updating tabs
    this.tabObserver = this.commonService.selectedTab.subscribe(data => {
      this.selectedTab = data;
    })

  }

  ngOnDestroy() {
    // this.commonService.msg2Tab(0);
    this.tabObserver.unsubscribe();
    sessionStorage.removeItem('currentTab');
    clearTimeout(this.timer);
  }

  showExtensionDailogue() {
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'confirm',
        contentTitle: 'Unsaved Changes',
        content: 'You have been editing this for more than 30 minutes, would you like to continue?\n Otherwise you will lose Changes',
        confirmTxt: 'Continue',
        confirmCallBack: this.extendLock.bind(this)
      }
    });
  }

  showRefreshDailogue() {
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'confirm',
        contentTitle: 'Refresh page',
        content: 'You are no longer holding the lock to edit this Portfolio.\n Please refresh to get latest changes.',
        confirmTxt: 'Refresh',
        confirmCallBack: this.refreshPage.bind(this)
      }
    });
  }

  refreshPage(dialogRef) {
    dialogRef.close();
    this.route.navigateByUrl('home/portfolio/createPortfolio/showPortfolio');
  }

  extendLock(dialogRef) {
    dialogRef.close();
    let editLog = {
      portfolioId: this.hiddenportfolioID,
      portfolioType: "Portfolio",
      portfolioName: this.portfolioName,
      staffDisplayName: JSON.parse(localStorage.getItem('userinfo')).displayName
    };
    this.restService.options = { responseType: 'text' };
    this.restService.put(URL_PREFIX.PORTFOLIO + '/editlock/extend', editLog).subscribe(data => {
      console.log(data);
      if (data === 'Success') {
        console.log("Lock extended");
        this.timer = setTimeout(() => {
          this.showExtensionDailogue();
        }, 1800000);
      }
    },
      err => {
        console.log("Locke extension failed");
        if (err instanceof HttpErrorResponse) {
          if (err.status === 410) {
            this.showRefreshDailogue();
            console.log("Referesh the page");
          }
        }
      });
  }

  addWorkManagers(event): void {
    this.showWMinput = false;
    if (!this.checkValidOptionForWorkManager) {
      const empData = this.portfolioForm.get('workManagerName').value;
      const empName = this.employeeMap.get(empData);
      const data = {
        portMgrSurrId: '',
        delegateInd: [false],
        emailAddress: empData,
        oneBankId: empData.replace(/@.*$/, ''),
        staffName: empName,
        role: 'tech',
        portfolioId: this.hiddenportfolioID,
        activeInd: true,
      };
      this.workManagers().push(this.createWorkManager(data));
    }
  }

  changeToggle(event) {
    console.log('Toggle Event: ', event);
    console.log(this.portfolioForm);
  }

  changeCheckedBox(event) {
    console.log('CheckBox Event: ', event);
    console.log(this.portfolioForm);
  }

  public displayProperty(value) {
    if (value) {
      return '';
    }
  }

  deleteWorkManager(index) {
    this.workManagers().value[index].activeInd = false;
    const workManager = this.workManagers().controls[index] as FormArray;
    const ctrl = workManager.controls as any;
    ctrl.activeInd.value = false;
    if (Object.values(this.duplicateWorkmanager).indexOf(ctrl.emailAddress.value) >= 0) {
      delete this.duplicateWorkmanager[_.findKey(this.duplicateWorkmanager, function (o) {
        return o == ctrl.emailAddress.value
      })];
    } else {
      this.trie.addWord(ctrl.emailAddress.value);
    }
    if (this.workManagers().value[index].portMgrSurrId == '') {
      this.workManagers().removeAt(index);
    } else {
      (this.workManagers().at(index) as FormGroup).controls['staffName'].setErrors(null);
    }
  }

  createWorkManager(empdata): FormGroup {
    this.trie.removeWord(empdata.emailAddress);
    return this.formBuilder.group(
      {
        portMgrSurrId: [empdata.portMgrSurrId, []],
        portfolioId: [empdata.portfolioId, []],
        oneBankId: [empdata.oneBankId, []],
        staffName: [empdata.staffName, []],
        role: [empdata.role, []],
        delegateInd: [empdata.delegateInd == 'true', []],
        activeInd: [true, []],
        emailAddress: empdata.emailAddress
      }, { validator: this.wrkMngrValidator(this.workManagers().length) });
  }

  getData() {
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/portfolio/latestworkdayrecord').subscribe(data => {
      if (data != null) {
        data.forEach(val => {
          const str = val.emailAddress as string;
          if (str) {
            this.trie.addWord(str);
            this.employeeList.push(str);
            this.employeeMap.set(val.emailAddress, val.staffName);
          }
        });
        this.employeeList.sort();
        this.getWorkManagers();
      }
    });
    let staffName = JSON.parse(localStorage.getItem('userinfo')).displayName;
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/portfolio/common/getportfoliodata/${this.hiddenportfolioID}/Portfolio/${this.portfolioName}?staffName=${staffName}`).subscribe(data => {
      // this.defaultInitiationYear = data.initiationYear;
      const workTypeData = data.workType;
      //this.defaultWorkType = data.workType;
      if (workTypeData === 'I') {
        this.defaultWorkType = 'Initiative';
      } else {
        this.defaultWorkType = 'Enhancement';
      }
      // this.defaultPlatformName = data.platformName;
      // this.defaultPrimaryPlatformName = data.primaryPlatformName;
      this.portfolioForm.controls.portfolioName.setValue(data.portfolioName);
      this.portfolioForm.controls.portfolioDesc.setValue(data.portfolioDesc);
      this.portfolioForm.controls.initiationYear.setValue(data.initiationYear);
      this.portfolioForm.controls.platformName.setValue(data.platformName);
      this.portfolioForm.controls.primaryPlatformName.setValue(data.primaryPlatformName);
      this.portfolioForm.controls.portfolioRefId.setValue(data.portfolioRefId);
      this.portfolioForm.controls.budgetStatus.setValue(data.budgetStatus);
      this.portfolioForm.controls.planningCycle.setValue(data.planningCycle);
      this.portfolioForm.controls.budgetSystemOwner.setValue(data.budgetSystemOwner);
      this.portfolioForm.controls.dateCreated.setValue(data.dateCreated);
      this.portfolioForm.controls.createdBy.setValue(data.createdBy);
      this.portfolioForm.controls.bizSegment.setValue(data.bizSegment);
      this.portfolioForm.controls.thematic.setValue(data.thematic);
      this.portfolioForm.controls.horizon.setValue(data.horizon);
      this.portfolioForm.controls.agileWaterFall.setValue(data.agileWaterFall);
      this.portfolioForm.controls.reportingFlag.setValue(data.reportingFlag);
      this.portfolioData = data;
      if(data.editable === 'NO'){
        this.commonService.showSnackBar({type:'alert', message:'This Portfolio is being edited by '+data.staffName+' \n Your changes will not be saved', duration:5000});
        this.showSaveBtn = false;
      }else{
         // Track and show dailogue for lock extension
        this.timer = setTimeout(() => {
          this.showExtensionDailogue();
        },1800000)
      }
    });
  }

  getWorkManagers() {
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/portfolio/getworkmanagers/' + this.hiddenportfolioID).subscribe(data => {
      this.portfolioManagerData = data[0];
      this.portfolioManagerDataVals = Object.values(this.portfolioManagerData);
      this.workManagerData = data[1];
      let existingWrkMng = [];
      if (this.portfolioManagerDataVals[0] != null) {
        this.portfolioManagerDataVals[0].forEach((data, idx) => {
          existingWrkMng.indexOf(data.emailAddress) < 0 ? existingWrkMng.push(data.emailAddress) : this.duplicateWorkmanager[idx] = data.emailAddress;
          this.workManagers().push(this.createWorkManager(data));
        });
      }

      console.log('portfolioManagerData: ', this.portfolioManagerData);
    });
  }

  getDropDownLists() {
    const list = ['Budget Status', 'Planning Cycle', 'Budget System Owner', 'Thematics', 'Business Segment', 'Horizon', 'Agile/Waterfall', 'PF_Reporting Flag'];
    this.restService.post(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues', list).subscribe(data => {
      data['Budget Status'].forEach((element: { value: any; }) => {
        this.budgetStatusList.push({ key: element.value, value: element.value });
      });
      data['Planning Cycle'].forEach((element: { value: any; }) => {
        this.planningCycleList.push({ key: element.value, value: element.value });
      });
      data['Budget System Owner'].forEach((element: { value: any; }) => {
        this.budgetSystemOwnerList.push({ key: element.value, value: element.value });
      });
      data.Thematics.forEach(element => {
        this.thematicsDropdown.push({ value: element.value, display: element.value });
      });
      data['Business Segment'].forEach(element => {
        this.businesSegmentDropdown.push({ value: element.value, display: element.value });
      });
      data.Horizon.forEach(element => {
        this.horizonDropDownList.push({ value: element.value, display: element.value });
      });
      data['Agile/Waterfall'].forEach(element => {
        this.agileOrWaterfallDropdown.push({ value: element.value, display: element.value });
      });
      data['PF_Reporting Flag'].forEach(element => {
        this.reportingFlagDropdown.push({ value: element.value, display: element.value });
      });
    });
    var str = this.hiddenportfolioID;
    var platformIndex = str.substring(1, str.indexOf('-')).trim();
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/portfolio/business/segment/${platformIndex}`).subscribe(data => {
      data.forEach(element => {
        this.businesSegmentDropdown.push({ 'value': element.bizSegmentName, 'display': element.bizSegmentName });
      });
    });

  }

  displayFn() {
    return this.staffName;
  }

  cnfmClbk(dialogRef) {
    dialogRef.close();
    this.dataService.setActiveTab(this.selectedTab);
    this.route.navigateByUrl('home/portfolio/createPortfolio/showPortfolio');
  }

  goback() {
    if (this.portfolioForm.touched) {
      const dialogRef = this.dialog.open(CommonDialogComponent, {
        data: {
          type: 'warning',
          contentTitle: 'Unsaved Changes',
          content: 'You are leaving with unsaved changes, any changes will be lost.\nAre you sure you want to leave this page?',
          confirmTxt: 'Proceed',
          cancelTxt: 'Cancel',
          confirmCallBack: this.cnfmClbk.bind(this)
        }
      });
    } else {
      this.dataService.setActiveTab(this.selectedTab);
      this.route.navigateByUrl('home/portfolio/createPortfolio/showPortfolio');
    }
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustom(date);
  }

  timeFormat(date?: Date) {
    const d = new Date(date);
    const time = d.getHours() + ':' + d.getMinutes();
    return this.formattime.transform(time);
  }

  checkWrkProfileForm() {
    if (this.portfolioForm.controls.portfolioName.invalid || this.portfolioForm.controls.initiationYear.invalid || this.portfolioForm.controls.primaryPlatformName.invalid
      || this.portfolioForm.controls.portfolioDesc.invalid || this.portfolioForm.controls.platformName.invalid || this.portfolioForm.controls.budgetStatus.invalid
      || this.portfolioForm.controls.budgetSystemOwner.invalid || this.portfolioForm.controls.thematic.invalid || this.portfolioForm.controls.horizon.invalid
      || this.portfolioForm.controls.agileWaterFall.invalid || this.portfolioForm.controls.reportingFlag.invalid) {
      return true;
    }
    return false;
  }

  savePortfolio() {
    const controls = this.portfolioForm.controls;
    let temp = Object.assign({}, this.headerInfo);
    temp.prevent_idx_update = true;

    for (const name in controls) {
      if (controls[name].invalid) {
        this.portfolioForm.controls[name].markAsTouched();
      }
    }
    if (this.portfolioForm.invalid) {
      this.portfolioForm.markAllAsTouched();
      let errTabs = [];
      if (this.portfolioForm.controls.workManagers.invalid) {
        errTabs.push('Work Managers');
      }

      if (this.checkWrkProfileForm()) {
        errTabs.push('Work Profile');
      }
      temp.err_tabs = errTabs;
      this.selectedTab = temp.err_tabs[0];
      this.commonService.updateTab.emit(this.selectedTab);
      this.commonService.recieveMessage(temp);

      this.commonService.showSnackBar({
        type: 'alert',
        message: 'Your changes can\'t be saved due to errors in some fields'
      });
    } else if (this.portfolioForm.valid) {
      this.commonService.recieveMessage(temp);
      this.portfolioId = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID);
      this.portfolioForm.controls.portSurrId.setValue(this.portfolioData.portSurrId);
      this.portfolioForm.controls.portfolioId.setValue(this.portfolioId);
      this.portfolioForm.controls.primaryPlatformName.setValue(this.portfolioData.primaryPlatformName);
      if (this.defaultWorkType === 'Initiative') {
        this.portfolioForm.controls.workType.setValue('I');
      }
      else {
        this.portfolioForm.controls.workType.setValue('E');
      }
      this.prepareData = this.portfolioForm.value;
      delete this.prepareData.workManagerName;
      this.prepareData = {
        portfolioEntity: {
          budgetStatus: this.portfolioForm.controls.budgetStatus.value,
          budgetSystemOwner: this.portfolioForm.controls.budgetSystemOwner.value,
          createdBy: this.portfolioForm.controls.createdBy.value,
          dateCreated: this.portfolioForm.controls.dateCreated.value,
          initiationYear: this.portfolioForm.controls.initiationYear.value,
          planningCycle: this.portfolioForm.controls.planningCycle.value,
          platformName: this.portfolioForm.controls.platformName.value,
          portSurrId: this.portfolioForm.controls.portSurrId.value,
          portfolioDesc: this.portfolioForm.controls.portfolioDesc.value,
          portfolioId: this.portfolioForm.controls.portfolioId.value,
          portfolioName: this.portfolioForm.controls.portfolioName.value,
          portfolioRefId: this.portfolioForm.controls.portfolioRefId.value,
          primaryPlatformName: this.portfolioForm.controls.primaryPlatformName.value,
          workType: this.portfolioForm.controls.workType.value,
          bizSegment: this.portfolioForm.controls.bizSegment.value,
          thematic: this.portfolioForm.controls.thematic.value,
          horizon: this.portfolioForm.controls.horizon.value,
          agileWaterFall: this.portfolioForm.controls.agileWaterFall.value,
          reportingFlag: this.portfolioForm.controls.reportingFlag.value
        },
        workManagers: this.portfolioForm.value.workManagers
      };
      this.restService.put(URL_PREFIX.PORTFOLIO + '/data/portfolio/edit/updateportfolio', this.prepareData).subscribe((data: any) => {
        this.portfolioData = data;
        sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME, this.prepareData.portfolioEntity.portfolioName);
        this.dataService.sendMessageItemChange(WORK_HIERARCHY_CONST.PORTFOLIO);
        this.commonService.showSnackBar({
          type: 'success',
          message: 'Portfolio Updated'
        });
        this.dataService.setActiveTab(this.selectedTab);
        this.route.navigateByUrl('home/portfolio/createPortfolio/showPortfolio');
      },
        error => {
          if (error.status !== null) {
          }
        }
      );

    }
  }

  get formData() {
    return this.portfolioForm.controls;
  }

  // enteredPortfolioName(e: { value: any; }) {
  //   this.selPortfolioName = e.value;
  // }

  budgetStatusSelected(e: { value: any; }) {
    this.budgetStatusSelectedToolTip = e.value;
  }

  planningCycleSelected(event: { value: any; }) {
    this.planningCycleSelectedTooltip = event.value;
  }

  budgetSystemOwnerSelected(event: { value: any; }) {
    this.budgetSystemOwnerSelectedToolTip = event.value;
  }

  enteredThematic(e: { value: any; }) {
    this.thematic = e.value;
  }

  enteredHorizon(e: { value: any; }) {
    this.selHorizon = e.value;
  }

  enteredbizSegment(e: { value: any; }) {
    this.bizSegment = e.value;
  }

  enteredAgileWaterFall(e: { value: any; }) {
    this.agileWaterFall = e.value;
  }

  enteredreportingFlag(e: { value: any; }) {
    this.reportingFlag = e.value;
  }
}
