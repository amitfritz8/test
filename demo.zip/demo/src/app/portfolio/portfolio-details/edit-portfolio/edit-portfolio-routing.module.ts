import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/common/module/shared.module';
import { EditPortfolioComponent } from './edit-portfolio.component';

const routes: Routes = [
    {path: '', component: EditPortfolioComponent}
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
  ],
  declarations: [
    EditPortfolioComponent
  ],
  exports: [],
  entryComponents: []
})

export class EditPortfolioRoutingModule {
}