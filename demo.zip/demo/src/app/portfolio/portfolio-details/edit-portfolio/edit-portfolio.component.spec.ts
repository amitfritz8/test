import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { CreatePortfolioComponent } from './create-portfolio.component';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DebugElement } from '@angular/core';
import { By, BrowserModule } from '@angular/platform-browser';
import { MaterialModule } from 'src/app/material.module';
import { SharedModule } from 'src/app/common/module/shared.module';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { TimeFormat } from 'src/app/common/pipes/timeFormater.pipe';
import { of } from 'rxjs';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { EditPortfolioComponent } from './edit-portfolio.component';

xdescribe('EditPortfolioComponent', () => {
  let component: EditPortfolioComponent;
  let fixture: ComponentFixture<EditPortfolioComponent>;
  let de: DebugElement;
  let el: HTMLElement;
  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EditPortfolioComponent],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        SharedModule,
        RouterTestingModule,
        HttpClientModule,
        BrowserAnimationsModule
      ],
      providers: [
        // tslint:disable-next-line: no-use-before-declare
        { provide: DateUtility, useClass: MockDateUtility },
        // tslint:disable-next-line: no-use-before-declare
        { provide: RestService, useClass: MockRestService },
        // tslint:disable-next-line: no-use-before-declare
        { provide: DataService, useClass: MockDataService },
        // tslint:disable-next-line: no-use-before-declare
        { provide: TimeFormat, useClass: MockTimeFormat },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPortfolioComponent);
    component = fixture.componentInstance;
    de = fixture.debugElement.query(By.css('.mainDiv'));
    el = de.nativeElement;
    fixture.detectChanges();
    component.portfolioForm = formBuilder.group({
      portfolioName: ['test', [Validators.required, Validators.maxLength(100)]],
      initiationYear: ['2019', [Validators.required]],
      workType: ['I', [Validators.required]],
      primaryPlatformName: ['01 - CBG Customer Mgt & Analytics', [Validators.required]],
      portfolioRefId: ['1234'],
      portfolioDesc: ['new data', [Validators.required]],
      platformName: ['01 - CBG Customer Mgt & Analytics', [Validators.required]],
      budgetStatus: ['new data', [Validators.required]],
      planningCycle: [''],
      budgetSystemOwner: ['new data', [Validators.required]],
      portSurrId: [''],
      portfolioId: [''],
      dateCreated: [''],
      createdBy: ['']
    });
    component.hiddenportfolioID = 'P19-20001-I';
    component.budgetStatusList = [{
      createdBy: 'yvonneyongsk',
      dateCreated: 1577533014000,
      modifiedBy: 'yvonneyongsk',
      dateModified: 1577533014000,
      id: 213,
      code: 10,
      value: 'A2020 Offcycle Approval',
      status: 'active',
    }];
    component.planningCycleList = [{
      createdBy: 'yvonneyongsk',
      dateCreated: 1577533469000,
      modifiedBy: 'yvonneyongsk',
      dateModified: 1577533469000,
      id: 214,
      code: 1152,
      value: 'B2021 New',
      status: 'active',
    }];
    component.budgetSystemOwnerList = [{
      createdBy: 'yvonneyongsk',
      dateCreated: 1577534047000,
      modifiedBy: 'yvonneyongsk',
      dateModified: 1577534047000,
      id: 226,
      code: 1153,
      value: 'Vickers',
      desc: null,
      status: 'active',
    }];
    component.portfolioForm.controls.portfolioName.setValue('new data');
    component.portfolioForm.controls.portfolioDesc.setValue('new data');
    component.portfolioForm.controls.portfolioRefId.setValue('1234');
    component.portfolioForm.controls.budgetStatus.setValue('new data');
    component.portfolioForm.controls.planningCycle.setValue('new data');
    component.portfolioForm.controls.budgetSystemOwner.setValue('new data');
    component.portfolioForm.controls.dateCreated.setValue('1578374332000');
    component.portfolioForm.controls.createdBy.setValue('saikrishnan');
    component.defaultWorkType = 'Initiative';
    component.selPortfolioName = 'test';
    component.budgetStatusSelectedToolTip = 'test';
    component.planningCycleSelectedTooltip = 'test';
    component.budgetSystemOwnerSelectedToolTip = 'test';
    component.portfolioData.portSurrId = '22';
    sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID, 'P19-20001-I');
    sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME, 'test33');
    component.budgetSystemOwnerList.forEach(e => {
      component.budgetSystemOwnerList.push();
    });

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call for getData', (done: DoneFn) => {
    component.getData();
    component.getDropDownLists();
    done();
  });

  it('should call for goback', (done: DoneFn) => {
    component.goback();
    // tslint:disable-next-line: no-use-before-declare
    const router: MockRouter = new MockRouter();
    spyOn(router, 'navigateByUrl');
    router.navigateByUrl('home/portfolio/createPortfolio/showPortfolio');
    expect(router.navigateByUrl).toHaveBeenCalled();
    done();
  });

  it('should call dateFormat', () => {
    const date = new Date();
    component.dateFormat(date);
    // tslint:disable-next-line: no-use-before-declare
    const c: MockDateUtility = new MockDateUtility();
    spyOn(c, 'dateFormatterCustom');
    c.dateFormatterCustom(date);
    expect(c.dateFormatterCustom).toHaveBeenCalled();
  });

  // it('should call enteredPortfolioName', (done: DoneFn) => {
  //   spyOn(component, 'enteredPortfolioName').and.callThrough();
  //   component.enteredPortfolioName({ value: 'test' });
  //   expect(component.enteredPortfolioName).toHaveBeenCalled();
  //   done();
  // });

  it('should call budgetStatusSelected', (done: DoneFn) => {
    spyOn(component, 'budgetStatusSelected').and.callThrough();
    component.budgetStatusSelected({ value: 'test' });
    expect(component.budgetStatusSelected).toHaveBeenCalled();
    done();
  });

  it('should call planningCycleSelected', (done: DoneFn) => {
    spyOn(component, 'planningCycleSelected').and.callThrough();
    component.planningCycleSelected({ value: 'test' });
    expect(component.planningCycleSelected).toHaveBeenCalled();
    done();
  });

  it('should call budgetSystemOwnerSelected', (done: DoneFn) => {
    spyOn(component, 'budgetSystemOwnerSelected').and.callThrough();
    component.budgetSystemOwnerSelected({ value: 'test' });
    expect(component.budgetSystemOwnerSelected).toHaveBeenCalled();
    done();
  });
  it('should call for savePortfolio', () => {

    component.portfolioId = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID);
    component.portfolioForm.controls.portSurrId.setValue('22');
    component.portfolioForm.controls.portfolioId.setValue('P19-20001-i');
    component.portfolioForm.controls.primaryPlatformName.setValue('01 - CBG Customer Mgt & Analytics');

    const mockRes = {
      createdBy: 'sivasankarg',
      dateCreated: 1578379265000,
      modifiedBy: 'sivasankarg',
      dateModified: 1578379536146,
      portSurrId: 1986,
      portfolioId: 'P01-14063-I',
      portfolioName: 'asdasd',
      portfolioDesc: 'asdasd',
      initiationYear: '2014',
      workType: 'Initiative',
      primaryPlatformIndex: '01',
      primaryPlatformName: '01 - CBG Customer Mgt & Analytics',
      platformName: 'CBG Customer Mgt & Analytics',
      requestor1bankId: null,
      requestorName: null,
      portfolioRefId: 'China',
      budgetStatus: 'A2020 Offcycle Approval',
      budgetSystemOwner: 'CBG',
      planningCycle: 'B2021 Inflight'
    };
    component.prepareData = component.portfolioForm.value;
    component.savePortfolio();
    component.portfolioData = mockRes;
    sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID, mockRes.portfolioId);
    sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME, mockRes.portfolioName);
    // tslint:disable-next-line: no-use-before-declare
    const service: MockDataService = new MockDataService();
    spyOn(service, 'sendMessageItemChange');
    service.sendMessageItemChange('test');
    expect(service.sendMessageItemChange).toHaveBeenCalled();
  });
});

class MockRouter {
  navigateByUrl(url: any) {
    return null;
  }
}

class MockDateUtility {
  dateFormatterCustom(date?: Date) {
    return '';
  }
}

class MockRestService {

  put(url: any, data: any) {
    return of({
      createdBy: 'sivasankarg',
      dateCreated: 1578379265000,
      modifiedBy: 'sivasankarg',
      dateModified: 1578379536146,
      portSurrId: 1986,
      portfolioId: 'P01-14063-I',
      portfolioName: 'asdasd',
      portfolioDesc: 'asdasd',
      initiationYear: '2014',
      workType: 'Initiative',
      primaryPlatformIndex: '01',
      primaryPlatformName: '01 - CBG Customer Mgt & Analytics',
      platformName: 'CBG Customer Mgt & Analytics',
      requestor1bankId: null,
      requestorName: null,
      portfolioRefId: 'China',
      budgetStatus: 'A2020 Offcycle Approval',
      budgetSystemOwner: 'CBG',
      planningCycle: 'B2021 Inflight'
    });
  }
  get() {
    return of({
      createdBy: 'saikrishnan',
      dateCreated: 1578374332000,
      modifiedBy: 'saikrishnan',
      dateModified: 1578374332000,
      portSurrId: 1975,
      portfolioId: 'P19-21006-I',
      portfolioName: 'data migration',
      portfolioDesc: null,
      initiationYear: '2021',
      workType: 'I',
      primaryPlatformIndex: '19',
      primaryPlatformName: '19 - Finance',
      platformName: 'Finance',
      requestor1bankId: null,
      requestorName: null,
      portfolioRefId: null,
      budgetStatus: null,
      budgetSystemOwner: null,
      planningCycle: null
    });
  }
  post(url: any, data: any) {
    return of({
      'Budget Status': [
        {
          createdBy: 'yvonneyongsk',
          dateCreated: 1577533014000,
          modifiedBy: 'yvonneyongsk',
          dateModified: 1577533014000,
          id: 213,
          code: 10,
          value: 'A2020 Offcycle Approval',
          status: 'active',
        },
      ],
      'Budget System Owner': [
        {
          createdBy: 'yvonneyongsk',
          dateCreated: 1577533928000,
          modifiedBy: 'yvonneyongsk',
          dateModified: 1577533928000,
          id: 216,
          code: 1153,
          value: 'CBG',
          desc: null,
          status: 'active',
        }
      ],
      'Planning Cycle': [
        {
          createdBy: 'yvonneyongsk',
          dateCreated: 1577533479000,
          modifiedBy: 'yvonneyongsk',
          dateModified: 1577533479000,
          id: 215,
          code: 1152,
          value: 'B2021 Inflight',
          desc: null,
          status: 'active',
        }
      ]
    });
  }
}
class MockDataService {
  sendMessage(test) {
    return null;
  }
  sendMessageItemChange(test) {
    return null;
  }
}
class MockTimeFormat {
  transform(date?: Date) {
    return '';
  }
}
