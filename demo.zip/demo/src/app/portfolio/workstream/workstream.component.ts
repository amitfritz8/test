import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { Router } from '@angular/router';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { MatDialog } from '@angular/material/dialog';
import { TimeFormat } from 'src/app/common/pipes/timeFormater.pipe';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { Subscription } from 'rxjs';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import * as _ from 'lodash';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ChangeDetectorRef } from '@angular/core';
import { CopyScenarioDialogComponent } from 'src/app/common/component/dialogues/copy-scenario-dialog/copy-scenario-dialog.component';
import { ApproverDialogComponent } from 'src/app/common/component/dialogues/approver-dialog/approver-dialog.component';
import { CommonDialogComponent } from 'src/app/common/component/dialogues/common-dialog/common-dialog-component';
import { WorkStreamService } from './workstream.service';
import { CopyScenarioModel } from './copyscenario.model';
import { CommonService } from 'src/app/common/service/common.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-workstream',
  templateUrl: './workstream.component.html',
  styleUrls: ['./workstream.component.scss', '../portfolio-details/view-portfolio/view-portfolio.component.scss'],
})
export class WorkstreamComponent implements OnInit, OnDestroy, AfterViewInit {
  portfolioID: any;
  portfolioNameFinal: any;
  hiddenWorkStreamID: any;
  showSideNavigation = false;
  action: string;
  workManagerWorkStreamId: any;
  WorkStreamApprovalId: any = null;
  subSubWorkStreamApprovalId: any;
  subWorkManagerSubWorkStreamId: any;
  SubWorkStreamApproversId: any;
  subworkStreamName: any;
  workStreamWorkMgr: any = [];
  subWorkstreamWorkMgr: any = [];
  workStreamApproval: any = [];
  subWorkstreamApprovers: any = [];
  WorkStreamMgrMap = new Map<string, any>();
  SubWorkStreamApprovalMap = new Map<string, any>();
  selectedTab: any;
  workstreamMgrExists: boolean;
  subworkstreamMgrExists: boolean;
  keyDatesNames: any;
  keyDatesTotal: any = [];
  subWorkstreamDates: any = [];
  subworkstreamDatesExists: boolean = false;
  workstreamApprovalExists: boolean;
  subworkstreamApproversExists: boolean;
  // copyto 
  copyTo: Array<string>;
  approverScenarios: object;

  headerInfo;
  tabObserver: Subscription;

  constructor(private http: HttpClient, private fb: FormBuilder, private dateUtility: DateUtility, private route: Router, private restService: RestService, private dataService: DataService, public dialog: MatDialog,
    public formattime: TimeFormat, private changeDetector: ChangeDetectorRef, private ws: WorkStreamService, private commonService: CommonService, private datepipe: DatePipe) {

    this.headerInfo = {
      title: sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME),
      show_filters: false,
      additional_info: sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID),
      tabs: ['Work Profile', 'Work Managers', 'Key Dates', 'Approvers', 'Financials', 'Others'],
      btns: {
        primary: {
          text: 'Edit Workstream',
          clbk: this.editClbk.bind(this)
        },
        addclbk: this.addSubWorkStream.bind(this),
        moreOptions: [
          {
            text: 'Copy Scenario to',
            clbk: this.copyScenario.bind(this),
            disabled: false
          },
          {
            text: 'Mark as Approved',
            clbk: this.approveScenario.bind(this),
            disabled: true,
          }
        ]
      }
    }
    this.headerInfo.prevent_idx_update = (this.dataService.getActiveTab() != '' && this.headerInfo.tabs.indexOf(this.dataService.getActiveTab()) >= 0);
    this.selectedTab = this.headerInfo.prevent_idx_update ? this.dataService.getActiveTab() : this.headerInfo.tabs[0];
    this.commonService.recieveMessage(this.headerInfo);
    sessionStorage.setItem('currentTab',this.selectedTab);
  }

  editClbk() {
    this.editWorkstream(this.workStreamData.portfolioId);
  }

  datavalues: any = [];
  workStreamData: any = [];
  isErrorExists = false;
  subscription: Subscription;
  scenarioDrop: any = [];
  approvalsWorkStream: any = [];
  workstreamID: any;
  workstreamWorkMgr: any = [];
  scenarioMap = new Map<string, any>();
  subWorkstreamDatesMap = new Map<string, any>();
  testMap = new Map<string, any>();
  workstreamOthers: any;
  workstreamOthersExist: boolean;
  workstreamOtherId: any;
  buildLepcCodeData: any = [];
  operateLepcCodeData: any = [];
  pcCodedata: any = [];

  ngOnInit() {
    this.getData();
    this.getOthersData();
    this.changeDetector.detectChanges();
    this.getWorkMangersData();
    this.getWorkStreamKeyDates();
    this.getApprovalsData();
    // get copy scenarios
    this.getCopyScenarios();
    this.getApprovers();

    this.tabObserver = this.commonService.selectedTab.subscribe(data => {
      this.selectedTab = data;
      sessionStorage.setItem('currentTab',this.selectedTab);
    });

    this.subscription = this.dataService.itemChange.subscribe(msg => {
      if (msg === WORK_HIERARCHY_CONST.WORKSTREAM) {
        this.headerInfo.prevent_idx_update = false;
        this.headerInfo.title = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME);
        this.headerInfo.additional_info= sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID);
        this.commonService.recieveMessage(this.headerInfo);
        this.selectedTab = this.headerInfo.tabs[0];
        this.getData();
        this.getCopyScenarios();
        this.getApprovers();
        this.getWorkMangersData();
        this.getWorkStreamKeyDates();
        this.getApprovalsData();
        this.getOthersData();
      }
    });
  }

  ngAfterViewInit() {
    if (this.dataService.getActiveTab() != '' && this.headerInfo.tabs.indexOf(this.dataService.getActiveTab()) >= 0) {
      this.commonService.updateTab.emit(this.selectedTab);
      this.dataService.setActiveTab('');
    }
  }

  getData() {
    this.hiddenWorkStreamID = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID);
    this.buildLepcCodeData = [];
    this.operateLepcCodeData = [];
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/portfolio/common/getportfoliodata/${this.hiddenWorkStreamID}/WorkStream/''?staffName=`).subscribe(data => {
      this.workStreamData = data;
      this.workStreamData.workstreamLePccodesEntities.forEach((element: { buildOperate: string; lePCCode: any; allocationPercent: any; }) => {
        if (element.buildOperate && element.buildOperate.toLowerCase() === "build") {
          this.buildLepcCodeData.push({ pcCode: element.lePCCode, pcCodeDesc: element.lePCCode, allocationPercent: element.allocationPercent });
        } else if (element.buildOperate && element.buildOperate.toLowerCase() === "operate") {
          this.operateLepcCodeData.push({ pcCode: element.lePCCode, pcCodeDesc: element.lePCCode, allocationPercent: element.allocationPercent });
        }
      });
    });
  }

  getCopyScenarios() {
    try {
      this.ws.getScenario({ requestType: 'WorkStream' }).subscribe(
        data => {
          this.copyTo = data;
        },
        err => {
          console.log(err);
        })
    } catch (e) {
      console.log(e);
    }
  }

  getApprovers() {
    try {
      this.ws.getApprovers({ requestType: 'WorkStream', id: sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID) }).subscribe(
        data => {
          this.approverScenarios = data;
          this.headerInfo.btns.moreOptions[1].disabled = data.length <= 0;
          this.commonService.recieveMessage(this.headerInfo);
        },
        err => {
          console.log(err);
        }
      )
    } catch (e) {
      console.log(e);
    }
  }

  goback() {
    this.route.navigateByUrl('home/portfolio');
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustom(date);
  }
  timeFormat(date?: Date) {
    const d = new Date(date);
    const time = d.getHours() + ':' + d.getMinutes();
    return this.formattime.transform(time);
  }
  addSubWorkStream() {
    this.route.navigate(['home/portfolio/createPortfolio/workstream/' + this.hiddenWorkStreamID + '/createSubworkstream']);
  }
  editWorkstream(workstreamID) {
    this.dataService.setAction('edit');
    this.route.navigateByUrl('home/portfolio/createPortfolio/workstream/' + this.hiddenWorkStreamID + '/editWorkstream');
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.tabObserver.unsubscribe();
  }

  getWorkMangersData() {
    this.WorkStreamMgrMap = new Map<string, any>();
    this.workstreamMgrExists = false;
    this.subworkstreamMgrExists = false;
    this.workStreamWorkMgr = [];
    this.subWorkstreamWorkMgr = [];
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/workstream/getworkmanagers/' + this.hiddenWorkStreamID).subscribe(data => {
      if (data[0] != null && data[0] !== '' && !_.isEmpty(data[0])) {
        this.workManagerWorkStreamId = Object.keys(data[0]);
        if (this.workManagerWorkStreamId != null && this.workManagerWorkStreamId !== '' && this.workManagerWorkStreamId !== 'undefined') {
          data[0][this.workManagerWorkStreamId].forEach((e: { values: any; }) => {
            this.workstreamMgrExists = true;
            this.workStreamWorkMgr.push(e);
          });
        }
      }
      if (data[1] != null && data[1] != null && !_.isEmpty(data[1])) {
        Object.keys(data[1]).forEach(subWkStrmId => {
          if (subWkStrmId != null && subWkStrmId !== '') {
            this.subWorkManagerSubWorkStreamId = subWkStrmId;
            data[1][this.subWorkManagerSubWorkStreamId].forEach((subWork: { values: any; }) => {
              this.subworkstreamMgrExists = true;
              this.subWorkstreamWorkMgr.push(subWork);
            });
            this.WorkStreamMgrMap.set(this.subWorkManagerSubWorkStreamId, this.subWorkstreamWorkMgr);
            this.subWorkstreamWorkMgr = [];
          }
        });
      }
    });
  }
  getApprovalsData() {
    this.SubWorkStreamApprovalMap = new Map<string, any>();
    this.workStreamApproval = [];
    this.workstreamApprovalExists = false;
    this.subworkstreamApproversExists = false;
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/workstream/approvers/' + this.hiddenWorkStreamID).subscribe(data => {
      if (data[0] !== null && data[0] !== "") {
        this.WorkStreamApprovalId = Object.keys(data[0]);
        if (!_.isEmpty(this.WorkStreamApprovalId) && this.WorkStreamApprovalId != null && this.WorkStreamApprovalId !== '' && this.WorkStreamApprovalId !== undefined) {
          if (!(data[0][this.WorkStreamApprovalId] == null
            || data[0][this.WorkStreamApprovalId] == '') && data[0][this.WorkStreamApprovalId] !== undefined) {
            data[0][this.WorkStreamApprovalId].forEach((e: { values: any; }) => {
              this.workstreamApprovalExists = true;
              this.workStreamApproval.push(e);
            });
          }
        }
      }
      if (data[1] != null && data[1] != null) {
        Object.keys(data[1]).forEach(subWkStrmId => {
          if (subWkStrmId != null && subWkStrmId !== '') {
            this.SubWorkStreamApproversId = subWkStrmId;
            data[1][this.SubWorkStreamApproversId].forEach((subWork: { values: any; }) => {
              this.subworkstreamApproversExists = true;
              this.subWorkstreamApprovers.push(subWork);
            });
            var isTrue = subWkStrmId.includes("WS0");
            if (isTrue) {
              this.SubWorkStreamApprovalMap.set(this.SubWorkStreamApproversId, this.subWorkstreamApprovers);
            }
            this.subWorkstreamApprovers = [];
          }
        });
      }

      if (data[1] != null && data[1] != null) {
        Object.keys(data[1]).forEach(subWkStrmId => {
          if (subWkStrmId != null && subWkStrmId !== '') {
            this.SubWorkStreamApproversId = subWkStrmId;
            data[1][this.SubWorkStreamApproversId].forEach((subWork: { values: any; }) => {
              this.subworkstreamApproversExists = true;
              this.subWorkstreamApprovers.push(subWork);
            });
            var isTrue = subWkStrmId.includes("WS0");
            if (!isTrue) {
              this.SubWorkStreamApprovalMap.set(this.SubWorkStreamApproversId, this.subWorkstreamApprovers);
            }
            this.subWorkstreamApprovers = [];
          }
        });
      }

    });
  }

  getWorkStreamKeyDates() {
    this.scenarioMap = new Map<string, any>();
    this.subworkstreamDatesExists = false;
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/workstream/listOfKeyDatesWorkstream/' + this.hiddenWorkStreamID).subscribe(data => {
      this.scenarioDrop = data;
      if (this.scenarioDrop[0] != null && this.scenarioDrop[0] != null) {
        Object.keys(this.scenarioDrop[0]).forEach(keyDateName => {
          if (keyDateName != null && keyDateName !== '') {
            this.keyDatesNames = keyDateName;
            this.scenarioDrop[0][this.keyDatesNames].forEach((datesName: { values: any; }) => {
              this.keyDatesTotal.push(datesName);
            });
            this.scenarioMap.set(this.keyDatesNames, this.keyDatesTotal);
            this.keyDatesTotal = [];
          }
        });
      }

      if (data[1] != null && data[1] != null) {
        this.subWorkstreamDatesMap = new Map<string, any>();
        Object.keys(data[1]).forEach(subWkStrmName => {
          if (subWkStrmName != null && subWkStrmName !== '') {
            this.subworkStreamName = subWkStrmName;
            data[1][this.subworkStreamName].forEach((subWork: { values: any; }) => {
              this.subworkstreamDatesExists = true;
              this.subWorkstreamDates.push(subWork);
            });
            this.subWorkstreamDatesMap.set(this.subworkStreamName, this.subWorkstreamDates);
            this.subWorkstreamDates = [];
          }
        });
      }

    });
  }
  
  navToSubWrkStream(data: any, activeTab: string) {
    sessionStorage.setItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID, data.value[0].subWorkStreamId);
    sessionStorage.setItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME, data.value[0].subWorkStreamName);
    this.dataService.sendMessageItemChange(WORK_HIERARCHY_CONST.SUB_WORKSTREAM);
    this.dataService.setActiveTab(activeTab);
    this.route.navigateByUrl('home/portfolio/createPortfolio/subworkstream/' + data.value[0].subWorkStreamId);
  }
  
  asIsOrder(a, b) {
    return 1;
  }

  getOthersData() {
    this.workstreamOthers = '';
    this.restService.get(URL_PREFIX.PORTFOLIO + '/file/workstream/others/' + this.hiddenWorkStreamID).subscribe(data => {
      if (data != null && data !== '') {
        this.workstreamOthersExist = true;
        this.workstreamOthers = data;
        this.changeDetector.detectChanges();
        this.changeDetector.markForCheck();
      }
    });
  }

  download(index: any, documentName: any) {
    window.location.href = URL_PREFIX.PORTFOLIO + "/file/download/" + index + "/" + documentName;
  }

  copyToCallback(postData: CopyScenarioModel) {
    try {
      this.ws.copyTo(postData).subscribe(data => {
        this.getApprovers();
        this.getWorkStreamKeyDates();
        this.dialog.open(CommonDialogComponent, {
          data: {
            type: 'success',
            contentTitle: "Your Data has been copied successfully",
            content: `All Data From the ${postData.scenarioFrom} Scenario has been copied to the ${postData.scenarioTo}.You may now preview the data in the relevant scenarios`,
            confirmTxt: "Done"
          }
        });
      },
        err => {
          console.log(err);
        })
    } catch (e) {
      console.log(e);
    }
  }

  copyScenario() {
    const dialogRef = this.dialog.open(CopyScenarioDialogComponent, {
      data: {
        header: 'Copy Scenario to',
        copyTo: this.copyTo,
        copyFrom: ['Forecast'],
        workStreamId: sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID),
        portFolioId: sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID),
        copyToCallback: this.copyToCallback.bind(this)
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      // this.getData();
    });
  }

  approverCallback(postData) {
    try {
      let fData = new FormData();
      fData.append('approvalDate', `${this.datepipe.transform(postData.approvalDate, 'yyyy-MM-dd')} ${this.datepipe.transform(new Date(), 'hh:mm:ss')}`);
      fData.append('createdBy', localStorage.getItem('userOneBankId'));
      fData.append('workStreamId', sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID));
      fData.append('workStreamName', sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME));
      fData.append('portfolioId', sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID));
      fData.append('scenarioTo', postData.scenarioTo);
      fData.append('description', null);
      _.forEach(postData.file, (file) => {
        fData.append('file', file);
      });
      this.ws.postApprovers(fData).subscribe(
        data => {
          this.getApprovers();
          this.dialog.open(CommonDialogComponent, {
            data: {
              type: 'success',
              contentTitle: "Your scenario has been marked as approved",
              content: `You will not able to make any further edits to the scenario data. Please contact your administrator if you need to make any changes`,
              confirmTxt: "Done"
            }
          });
        },
        err => {
          this.dialog.open(CommonDialogComponent, {
            data: {
              type: 'alert',
              contentTitle: "Unable to Approve",
              content: `Unable to approve`,
              confirmTxt: "ok"
            }
          });
        });
    } catch (e) {
      console.log(e);
    }
  }

  approveScenario() {
    const dialogRef = this.dialog.open(ApproverDialogComponent, {
      data: {
        header: 'Mark as Approved',
        approveTo: this.approverScenarios,
        callback: this.approverCallback.bind(this)
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      // this.getData();
    });
  }

}
