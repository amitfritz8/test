import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/common/module/shared.module';
import { WorkstreamComponent } from '../workstream/workstream.component';
import { WorkStreamService } from './workstream.service';

const routes: Routes = [
  { path: '', component: WorkstreamComponent },
  {
    path: 'editWorkstream',
    loadChildren: () => import('src/app/portfolio/workstream/edit-workstream/edit-workstream-routing.module').then(m => m.EditWorkStreamRoutingModule),
  },
  {
    path: 'createSubworkstream',
    loadChildren: () => import('src/app/portfolio/workstream/create-subworkstream/create-subworkstream-routing.module').then(m => m.CreateSubworkstreamRoutingModule),
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
  ],
  declarations: [
    WorkstreamComponent
  ],
  providers: [WorkStreamService],
  exports: [],
  entryComponents: []
})

export class WorkStreamRoutingModule {
}