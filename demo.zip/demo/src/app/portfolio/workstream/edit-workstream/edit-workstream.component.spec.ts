import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditWorkstreamComponent } from './edit-workstream.component';

xdescribe('EditWorkstreamComponent', () => {
  let component: EditWorkstreamComponent;
  let fixture: ComponentFixture<EditWorkstreamComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditWorkstreamComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditWorkstreamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
