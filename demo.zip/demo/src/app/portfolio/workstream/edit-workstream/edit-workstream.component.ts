import { Component, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, ValidatorFn, ValidationErrors, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { startWith, map, delay } from 'rxjs/operators';
import { Observable, Subscription } from 'rxjs';
import { Trie } from 'prefix-trie-ts';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import { OthersDialogComponent } from 'src/app/common/component/dialogues/others-dialog/others-dialog-component';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/toPromise';
import * as _ from 'lodash';
import { CommonService } from 'src/app/common/service/common.service';
import { CommonDialogComponent } from 'src/app/common/component/dialogues/common-dialog/common-dialog-component'

const HttpUploadOptions = {
  headers: new HttpHeaders({ 'content-type': 'multipart/form-data', 'Authorization': 'Bearer ' + localStorage.getItem('access_token') })
}

export class AppDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
    let monthList = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    if (displayFormat === 'input') {
      const day = date.getDate();
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      return `${day} ${monthList[month - 1]} ${year}`;
    } else {
      return date.toDateString();
    }
  }
}

export const APP_DATE_FORMATS =
{
  parse: {
    dateInput: { month: 'short', year: 'numeric', day: 'numeric' },
  },
  display: {
    dateInput: 'input',
    monthYearLabel: { year: 'numeric', month: 'numeric' },
    dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric' },
    monthYearA11yLabel: { year: 'numeric', month: 'long' },
  }
};


@Component({
  selector: 'app-edit-workstream',
  templateUrl: './edit-workstream.component.html',
  styleUrls: ['./edit-workstream.component.scss'],
  providers: [
    {
      provide: DateAdapter, useClass: AppDateAdapter
    },
    {
      provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
    }
  ],
})

export class EditWorkstreamComponent implements OnInit, OnDestroy {
  showWMinput: boolean = false;
  trie = new Trie([]);
  employeeMap = new Map<string, string>();
  workstreamForm: FormGroup;
  countryDropdown: any = [];
  overallRiskLevel: any = []
  scenarioDropdown: any = [];
  scenarioDropdownKyDt: any = ['Forecast'];
  scenarioDropdownApprover: any = ['Forecast'];
  action = 'add';
  workstreamID: any;
  workstreamName: any;
  portfolioId: any;
  portfolioName: any;
  resSuccess: boolean;
  workStreamData: any = [];
  workstreamLePccodesEntitiesData: any = [];
  isWorkStreamNameExist: boolean;
  showlepcpercentBuildErrorMessage: boolean;
  showlepcpercentOperateErrorMessage: boolean;
  showAddlepcpercentOperateButton: boolean;
  showAddlepcpercentBuildButton: boolean;
  showName: string;
  PlatformDropdownList: any = [];
  data: any;
  benefitTypeDropDownList: any = [];
  workPhaseDropDownList: any = [];
  thematicsDropdown: any = [];
  businesSegmentDropdown: any = [];
  horizonDropDownList: any = [];
  workStatusDropdown: any = [];
  agileOrWaterfallDropdown: any = [];
  pcCodeDropdownList: any = [];
  //pcCodeDropdownShowList: any =[];
  subPlatformDropdownList: any = [];
  workStreamSurrId: any;
  showSideNavigation = false;
  filteredEmployees: Observable<any>;
  filteredPcBuildCodes: Observable<string[]>[] = [];
  filteredPcOperateCodes: Observable<string[]>[] = [];
  filteredApproverNames: Observable<string[]>[] = [];
  employeeList = [];
  checkValidOptionForWorkManager: boolean;
  workstreamManagerData: any;
  keyDatesDataAry: any;
  keyDateDataVals = [];
  workManagerData = [];
  subWorkStremApprovals: any = [];
  workstreamManagerDataVals = [];
  prepareData: any;
  wkstrmID: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID);
  selScenario: any;
  keyDatesDisplayDates: any = [];
  selectedScenarioIndex: any;
  keyDates: any = [];
  lepcCodes: any = [];
  keyDatesData: any = [];
  @Output()
  dateChange: EventEmitter<MatDatepickerInputEvent<any>>;
  approversData: any = [];
  lepccodesBuildData: any = [];
  lepccodesOperateData: any = [];
  roleDropdown: any = [];
  employeeAsApprover: any = [];
  actionsForApprover: any = [];
  scenariosForApprover: any = [];
  platformIndex: string = '';
  hasDuplicateRecord: any = [];
  selectDisabled: any = [];
  subworkstreamApprovalExists: boolean = false;
  hasDuplicateRecordForStaffName: any = [];
  subworkstreamApproversExists: boolean;
  SubWorkStreamApprovalMap = new Map<string, any>();
  SubWorkStreamApproversId: any;
  othersData: any = [];
  workstreamOthersExist: boolean = false;
  workstreamOthers: any[];
  docTypesDropdown: any = [];
  restrictKeyDates: boolean = false;
  timer: any;

  approverPattern = {};
  duplicateApproverPattetn = {};
  duplicateWorkmanager = {};
  maxStartDate;
  maxEndDate;
  maxLiveDate;

  headerInfo;
  tabObserver: Subscription;
  selectedTab: string;
  workCategory: any = [];
  showSaveBtn: boolean = true;

  constructor(private http: HttpClient, private fb: FormBuilder, private router: Router, private restService: RestService, private dataService: DataService,
    private dateUtility: DateUtility, public dialog: MatDialog, private datePipe: DatePipe, private commonService: CommonService) {

    this.headerInfo = {
      title: sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME),
      show_filters: false,
      additional_info: sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID),
      tabs: ['Work Profile', 'Work Managers', 'Key Dates', 'Approvers', 'Others']
    }
    this.selectedTab = (_.includes(this.headerInfo.tabs, sessionStorage.getItem('currentTab'))) ? sessionStorage.getItem('currentTab') : this.headerInfo.tabs[0];
    this.headerInfo.prevent_idx_update = (this.selectedTab != '' && this.headerInfo.tabs.indexOf(this.selectedTab) >= 0);
    if (this.headerInfo.prevent_idx_update) {
      this.commonService.updateTab.emit(this.selectedTab);
    }
    this.commonService.recieveMessage(this.headerInfo);
  }

  private approverValidator(idx): ValidatorFn {
    return (group: FormGroup): ValidationErrors => {
      let role = group.controls['role'];
      let scenario = group.controls['scenario'];
      let oneBankId = group.controls['oneBankId'];
      if (oneBankId.value == '') {
        group.controls['staffName'].setErrors({ required: true });
      } else if (oneBankId.value != '' && scenario.value != '' && role.value != '' && !_.isEmpty(this.duplicateApproverPattetn)) {
        let str = `${role.value}-${oneBankId.value}-${scenario.value}`;
        if (this.duplicateApproverPattetn[idx] == str) {
          group.controls['staffName'].setErrors({ error: true });
          return;
        } else {
          group.controls['staffName'].setErrors(null);
          return;
        }
      } else {
        group.controls['staffName'].setErrors(null);
        return;
      }
    };
  }

  private dateValidator(minDate: Date, field: string): ValidatorFn {
    return (ctrl: FormControl): ValidationErrors => {
      if (minDate) {
        if (new Date(new Date(ctrl.value).toDateString()) > new Date(minDate.toDateString()) && field === 'startDate') {
          return { 'dateExceed': true };
        } else if (new Date(new Date(ctrl.value).toDateString()) < new Date(minDate.toDateString()) && field !== 'startDate') {
          return { 'datePreceed': true };
        }
      }
      return null;
    };
  }

  private wrkMngrValidator(idx): ValidatorFn {
    return (group: FormGroup): ValidationErrors => {
      let email = group.controls['emailAddress'];
      if (email.value != '' && !_.isEmpty(this.duplicateWorkmanager)) {
        if (this.duplicateWorkmanager[idx] == email.value) {
          group.controls['staffName'].setErrors({ duplicate: true });
          return;
        } else {
          group.controls['staffName'].setErrors(null);
          return;
        }
      } else {
        group.controls['staffName'].setErrors(null);
        return;
      }
    };
  }

  ngOnInit() {
    // tab observer
    this.tabObserver = this.commonService.selectedTab.subscribe(data => {
      this.selectedTab = data;
    });

    this.workstreamForm = this.fb.group({
      workStreamName: ['', [Validators.required]],
      workStreamDesc: ['', [Validators.required]],
      country: ['', [Validators.required]],
      valueBenefit: ['', []],
      bizSegment: ['',],
      workManagers: this.fb.array([]),
      workManagerName: ['', []],
      scenarios: this.fb.array([]),
      lepccodesBuild: this.fb.array([]),
      lepccodesOperate: this.fb.array([]),
      scenarioName: ['', []],
      subPlatFormName: ['',],
      workStatus: ['', [Validators.required]],
      workPhase: ['', [Validators.required]],
      category: [''],
      overallRiskLevel: [''],
      workStreamRef: ['',],
      //lepcbuild: ['', [Validators.required]],
      // lePCCodeOperate: ['',],
      workStreamSurrId: ['', [Validators.required]],
      workStreamId: ['', [Validators.required]],
      dateCreated: [''],
      createdBy: [''],
      approvers: this.fb.array([]),
      others: this.fb.array([]),
    });
    this.getData();
    this.getOthersData();
    this.getScenario();
    this.filteredEmployees = this.workstreamForm.controls.workManagerName.valueChanges
      .pipe(
        map(empName => empName.length > 1 ? this._filterEmployee(empName) : []),
        delay(500)
      );
  }

  ngOnDestroy() {
    this.tabObserver.unsubscribe();
    sessionStorage.removeItem('currentTab');
    clearTimeout(this.timer);
  }

  showExtensionDailogue() {
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'confirm',
        contentTitle: 'Unsaved Changes',
        content: 'You have been editing this for more than 30 minutes, would you like to continue?\n Otherwise you will lose Changes',
        confirmTxt: 'Continue',
        confirmCallBack: this.extendLock.bind(this)
      }
    });
  }

  showRefreshDailogue() {
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'confirm',
        contentTitle: 'Refresh page',
        content: 'You are no longer holding the lock to edit this Workstream.\n Please refresh to get latest changes.',
        confirmTxt: 'Refresh',
        confirmCallBack: this.refreshPage.bind(this)
      }
    });
  }

  refreshPage(dialogRef) {
    dialogRef.close();
    this.router.navigateByUrl(`home/portfolio/createPortfolio/workstream/${this.workstreamID}`);
  }

  extendLock(dialogRef) {
    dialogRef.close();
    let editLog = {
      portfolioId: this.workstreamID,
      portfolioType: 'Workstream',
      portfolioName: this.workstreamName,
      staffDisplayName: JSON.parse(localStorage.getItem('userinfo')).displayName
    };
    this.restService.options = { responseType: 'text' };
    this.restService.put(URL_PREFIX.PORTFOLIO + '/editlock/extend', editLog).subscribe(data => {
      if (data === 'Success') {
        this.timer = setTimeout(() => {
          this.showExtensionDailogue();
        }, 1800000);
      }
    },
      err => {
        if (err instanceof HttpErrorResponse) {
          if (err.status === 410) {
            this.showRefreshDailogue();
          }
        }
      }
    );
  }

  private _filterEmployee(data: any) {
    return this.trie.getPrefix(data);
  }

  getData() {
    this.action = this.dataService.getAction();
    const list = ['Country', 'Workstream Dates Config', 'Workstream Document Type', 'Work Category', 'Overall Risk Level'];
    this.restService.post(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues/', list).subscribe(data => {
      data.Country.forEach(element => {
        this.countryDropdown.push({ value: element.desc, display: element.value });
      });
      data['Work Category'].forEach(element => {
        this.workCategory.push({ value: element.value, display: element.value });
      });
      data['Overall Risk Level'].forEach(element => {
        this.overallRiskLevel.push({ value: element.value, display: element.value });
      });
      data['Workstream Document Type'].forEach(element => {
        this.docTypesDropdown.push({ value: element.value, display: element.desc });
      });
    });
    if (this.action === 'edit') {
      this.workstreamID = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID);
      this.workstreamName = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME);
      this.portfolioId = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID);
      this.editWorkstream(this.workstreamID, this.workstreamName);
    }
    // const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    // const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    // const locations = JSON.parse(sessionStorage.getItem('locations'));
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/portfolio/latestworkdayrecord').subscribe(data => {
      if (data != null) {
        data.forEach(val => {
          const str = val.emailAddress as string;
          if (str) {
            this.trie.addWord(str);
            this.employeeList.push(str);
            this.employeeMap.set(val.emailAddress, val.staffName);
          }
        });
        this.employeeList.sort();
        this.getWorkManagers();
      }
    });

    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/workstream/listOfKeyDatesWorkstream/' + this.wkstrmID).subscribe(data => {
      let keyDatesDataAry = data[0];
      let keyDateDataVals = Object.values(keyDatesDataAry);

      let stDate = [], enDate = [], liveDate = [];
      let dateExist = false;
      // check subworkstream key dates
      if (data[1] && data[1] != null) {
        _.map(data[1] as object, (val, key) => {
          _.forEach(val, (v: any) => {
            if (v.scenarioName == 'Forecast' && v.startDate && v.endDate && v.goLiveDate) {
              dateExist = true;
              stDate.push(new Date(v.startDate));
              enDate.push(new Date(v.endDate));
              liveDate.push(new Date(v.goLiveDate));
            }
          });
        });

        if (dateExist) {
          this.maxStartDate = _.min(stDate);
          this.maxEndDate = _.max(enDate);
          this.maxLiveDate = _.max(liveDate);
        }
      }

      if (keyDateDataVals[0] != null) {
        let keyDateDataValAry = keyDateDataVals[0] as Array<any>;
        this.keyDates = keyDateDataValAry;
        let tempAry = [];
        keyDateDataValAry.forEach(value => {
          tempAry.push({
            wsDateSurrId: value.wsDateSurrId,
            scenarioName: value.scenarioName,
            approvedDate: value.approvedDate,
            startDate: value.startDate,
            goLiveDate: value.goLiveDate,
            endDate: value.endDate,
            activeInd: value.activeInd
          });
          // this.createKeyDates(value);
        });
        data['keyDates'] = tempAry;
        this.keyDates = data['keyDates'];
        this.setScenarios();
      }

      //api call for add/edit of approvers
      //adding scenarios
      this.scenariosForApprover = [];
      this.restService.get(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues/category').subscribe(category => {
        if (category) {
          category.forEach(c => {
            const wrkStreamName = this.workstreamForm.controls.workStreamName.value;
            if (wrkStreamName && wrkStreamName.substring(0, 4) == 'WS0-' && (c.desc && c.desc.toLowerCase() == 'total')) {
              this.scenariosForApprover.push({ value: c.value });
            } else if (wrkStreamName && wrkStreamName.substring(0, 4) != 'WS0-' && (c.desc && c.desc.toLowerCase() == 'others')) {
              this.scenariosForApprover.push({ value: c.value });
            }
          });
        }
      });
      //adding actions list
      this.actionsForApprover = [];
      this.restService.get(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues/workflow action').subscribe(action => {
        if (action) {
          action.forEach(c => {
            this.actionsForApprover.push({ value: c.value });
          });
        }
      });
      //getting roles
      this.roleDropdown = [];
      this.platformIndex = this.portfolioId ? this.portfolioId.substring(1, 3) : '';
      this.restService.get(URL_PREFIX.PORTFOLIO + `/data/non-generic/stakeholders/role?platformIndex=${this.platformIndex}`).subscribe(roles => {
        if (roles) {
          roles.forEach(element => {
            this.roleDropdown.push({ value: element });
          });
        }
      });
      this.restService.get(URL_PREFIX.PORTFOLIO + '/data/workstream/approvers/' + this.workstreamID).subscribe(data => {
        const testData = Object.values(data[0]);
        this.approversData = [].concat.apply([], testData);
        // setting up list for staffName based upon roles.
        if (this.approversData) {
          this.approversData.forEach((data, index) => {
            this.restService.get(URL_PREFIX.PORTFOLIO + `/data/non-generic/stakeholders/staffnames?platformIndex=${this.platformIndex}&role=${data.role}`).subscribe(staffList => {
              let that = this;
              if (staffList) {
                this.employeeAsApprover[index] = [];
                Object.entries(staffList).forEach(function (obj) {
                  that.employeeAsApprover[index].push({ key: obj[0], value: obj[1] });
                });
              }
              this.selectDisabled[index] = false;
            });

            if (data.scenario == 'Forecast' || data.scenario == 'Financial Case') {
              let str = `${data.role}-${data.oneBankId}-${data.scenario}`;
              if (Object.values(this.approverPattern).indexOf(str) < 0) {
                this.approverPattern[index] = str;
                this.hasDuplicateRecordForStaffName[index] = false;
              } else {
                this.duplicateApproverPattetn[index] = str;
                this.hasDuplicateRecordForStaffName[index] = true;
              }
            }

            data['notifyInd'] = { value: '', disabled: true };
          });
        }
        this.setApprovers();

        this.SubWorkStreamApprovalMap = new Map<string, any>();
        if (data[1] != null && data[1] != null) {
          Object.keys(data[1]).forEach(subWkStrmId => {
            if (subWkStrmId != null && subWkStrmId !== '') {
              this.SubWorkStreamApproversId = subWkStrmId;
              data[1][this.SubWorkStreamApproversId].forEach((subWork: { values: any; }) => {
                this.subworkstreamApproversExists = true;
                this.subWorkStremApprovals.push(subWork);
              });
              var isTrue = subWkStrmId.includes('SWS0');
              if (isTrue) {
                this.SubWorkStreamApprovalMap.set(this.SubWorkStreamApproversId, this.subWorkStremApprovals);
              }
              this.subWorkStremApprovals = [];
            }
          });
        }

        if (data[1] != null && data[1] != null) {
          Object.keys(data[1]).forEach(subWkStrmId => {
            if (subWkStrmId != null && subWkStrmId !== '') {
              this.SubWorkStreamApproversId = subWkStrmId;
              data[1][this.SubWorkStreamApproversId].forEach((subWork: { values: any; }) => {
                this.subworkstreamApproversExists = true;
                this.subWorkStremApprovals.push(subWork);
              });
              var isTrue = subWkStrmId.includes('SWS0');
              if (!isTrue) {
                this.SubWorkStreamApprovalMap.set(this.SubWorkStreamApproversId, this.subWorkStremApprovals);
              }
              this.subWorkStremApprovals = [];
            }
          });
        }

      })
    });

  }

  getWorkManagers() {
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/workstream/getworkmanagers/' + this.wkstrmID).subscribe(data => {
      this.workManagers().clear();
      this.workstreamManagerData = data[0];
      this.workstreamManagerDataVals = Object.values(this.workstreamManagerData);
      this.workManagerData = data[1];
      let existingWrkMng = [];
      if (this.workstreamManagerDataVals[0] != null) {
        this.workstreamManagerDataVals[0].forEach((data, idx) => {
          existingWrkMng.indexOf(data.emailAddress) < 0 ? existingWrkMng.push(data.emailAddress) : this.duplicateWorkmanager[idx] = data.emailAddress;
          this.workManagers().push(this.createWorkManager(data));
        });
      }
    });
  }

  // to get scenario
  getScenario() {
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/non-generic/scenario').subscribe(
      data => {
        this.scenarioDropdown = data;
        // console.log(data);
      },
      err => {
        console.log(err);
      });
  }

  workManagers(): FormArray {
    return this.workstreamForm.get('workManagers') as FormArray;
  }

  changeToggle(event) {
  }

  changeCheckedBox(event) {
  }

  public displayProperty(value) {
    if (value) {
      return '';
    }
  }

  addWorkManagers(event): void {
    this.typeOption();
    this.showWMinput = false;
    if (!this.checkValidOptionForWorkManager) {
      const empData = this.workstreamForm.get('workManagerName').value;
      const empName = this.employeeMap.get(empData);
      const data = {
        wsMgrSurrId: '',
        delegateInd: [false, []],
        emailAddress: empData,
        oneBankId: empData.replace(/@.*$/, ''),
        staffName: empName,
        role: 'tech',
        workstreamID: this.workstreamID,
        activeInd: true,
      };
      this.workManagers().push(this.createWorkManager(data));
    } else {
      // this.checkValidOptionForWorkManager = false;
    }
  }

  deleteWorkManager(index) {
    this.workManagers().value[index].activeInd = false;
    const workManager = this.workManagers().controls[index] as FormArray;
    const ctrl = workManager.controls as any;
    if (Object.values(this.duplicateWorkmanager).indexOf(ctrl.emailAddress.value) >= 0) {
      delete this.duplicateWorkmanager[_.findKey(this.duplicateWorkmanager, function (o) {
        return o == ctrl.emailAddress.value
      })];
    } else {
      this.trie.addWord(ctrl.emailAddress.value);
    }
    ctrl.activeInd.value = false;
    if (this.workManagers().value[index].wsMgrSurrId === '') {
      this.workManagers().removeAt(index);
    } else {
      (this.workManagers().at(index) as FormGroup).controls['staffName'].setErrors(null);
    }
  }

  createWorkManager(empdata): FormGroup {
    this.trie.removeWord(empdata.emailAddress);
    return this.fb.group(
      {
        wsMgrSurrId: [empdata.wsMgrSurrId, []],
        workstreamID: [empdata.portfolioId, []],
        oneBankId: [empdata.oneBankId, []],
        staffName: [empdata.staffName, []],
        role: [empdata.role, []],
        delegateInd: [empdata.delegateInd == 'true', []],
        activeInd: [true, []],
        emailAddress: empdata.emailAddress
      }, { validator: this.wrkMngrValidator(this.workManagers().length) });
  }

  typeOption() {
    let ind = false;
    this.workstreamForm.value.workManagers.forEach(e => {

      if (!this.checkValidOptionForWorkManager && e.staffName === this.workstreamForm.controls.workManagerName.value.staffName) {
        this.checkValidOptionForWorkManager = true;
        ind = true;
      }
    });
    if (ind === false) {
      this.checkValidOptionForWorkManager = false;
    }
  }

  get f() {
    return this.workstreamForm.controls;
  }

  cnfmClbk(dialogRef) {
    dialogRef.close();
    this.dataService.setActiveTab(this.selectedTab);
    this.router.navigateByUrl(`home/portfolio/createPortfolio/workstream/${this.workstreamID}`);
  }

  goback() {
    if (this.workstreamForm.touched) {
      const dialogRef = this.dialog.open(CommonDialogComponent, {
        data: {
          type: 'warning',
          contentTitle: 'Unsaved Changes',
          content: 'You are leaving with unsaved changes, any changes will be lost.\nAre you sure you want to leave this page?',
          confirmTxt: 'Proceed',
          cancelTxt: 'Cancel',
          confirmCallBack: this.cnfmClbk.bind(this)
        }
      });
    } else {
      this.dataService.setActiveTab(this.selectedTab);
      this.router.navigateByUrl(`home/portfolio/createPortfolio/workstream/${this.workstreamID}`);
    }
  }

  checkWorkProfileForm() {
    if (this.workstreamForm.controls.workStreamName.invalid || this.workstreamForm.controls.workStreamDesc.invalid
      || this.workstreamForm.controls.workStatus.invalid
      || this.workstreamForm.controls.workPhase.invalid || this.workstreamForm.controls.lepccodesBuild.invalid || this.workstreamForm.controls.lepccodesOperate.invalid) {
      return true;
    }
    return false;
  }

  saveworkstream() {
    let temp = Object.assign({}, this.headerInfo);
    temp.prevent_idx_update = true;

    if (this.isWorkStreamNameExist) {
      this.workstreamForm.controls.workStreamName.setErrors({ incorrect: true });
    }

    this.validatelepcpercentBuildTotal();
    this.validatelepcpercentOperateTotal();

    const controls = this.workstreamForm.controls;
    this.workstreamForm.controls.workStreamSurrId.setValue(this.workStreamData.workStreamSurrId);
    for (const name in controls) {
      if (controls[name].invalid) {
        this.workstreamForm.controls[name].markAsTouched();
      }
    }
    if (this.workstreamForm.invalid || this.showlepcpercentBuildErrorMessage || this.showlepcpercentOperateErrorMessage) {
      let err_tabs = [];

      if (this.checkWorkProfileForm() || this.showlepcpercentBuildErrorMessage || this.showlepcpercentOperateErrorMessage) {
        err_tabs.push('Work Profile');
      }

      if (this.workstreamForm.controls.workManagers.invalid) {
        err_tabs.push('Work Managers');
      }

      if (this.workstreamForm.controls.scenarios.invalid) {
        err_tabs.push('Key Dates');
      }

      if (this.workstreamForm.controls.approvers.invalid) {
        err_tabs.push('Approvers');
      }

      temp.err_tabs = err_tabs;
      this.selectedTab = err_tabs[0];
      this.commonService.updateTab.emit(this.selectedTab);
      this.commonService.recieveMessage(temp);

      this.commonService.showSnackBar({
        type: 'alert',
        message: 'Your changes can\'t be saved due to errors in some fields'
      });

      this.workstreamForm.markAllAsTouched();
    } else if (this.workstreamForm.valid) {
      this.commonService.recieveMessage(temp);
      const list = this.workstreamForm.value;
      this.workstreamForm.controls.country.enable();

      this.portfolioId = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID);
      this.portfolioName = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME);
      this.workstreamForm.controls.workStreamSurrId.setValue(this.workStreamData.workStreamSurrId);
      this.workstreamForm.controls.workStreamId.setValue(this.workStreamData.workStreamId);
      this.prepareData = this.workstreamForm.value;
      delete this.prepareData.workManagerName;
      delete this.prepareData.scenarioName;
      let portFolioWorkStreamEntity = this.workstreamForm.value;
      delete portFolioWorkStreamEntity.scenarios;
      delete portFolioWorkStreamEntity.workManagers;
      delete portFolioWorkStreamEntity.approvers;
      delete portFolioWorkStreamEntity.lepccodesBuild;
      delete portFolioWorkStreamEntity.lepccodesOperate;
      let workStreamLepccodes = [];
      let workStreamScenarioNames = [];

      this.workstreamForm.controls.lepccodesBuild.value.forEach(element => {
        _.forIn(element, (v, k) => {
          if (k == 'lepcbuild') {
            element.lePCCode = element.lepcbuild;
            delete element.lepcbuild;
          }
          if (k == 'allocationPercentBuild') {
            element.allocationPercent = element.allocationPercentBuild;
            delete element.allocationPercentBuild;
          }
        })
        workStreamLepccodes.push(element);
      });

      this.workstreamForm.controls.lepccodesOperate.value.forEach(element => {
        _.forIn(element, (v, k) => {
          if (k == 'lePCCodeOperate') {
            element.lePCCode = element.lePCCodeOperate;
            delete element.lePCCodeOperate;
          }
          if (k == 'allocationPercentOperate') {
            element.allocationPercent = element.allocationPercentOperate;
            delete element.allocationPercentOperate;
          }
        })
        workStreamLepccodes.push(element);
      });
      this.workstreamForm.controls.scenarios.value.forEach(element => {
        if (element.scenarioName != '') {
          workStreamScenarioNames.push(element);
        }
      });
      this.prepareData = {
        portFolioWorkStreamEntity: this.workstreamForm.value,
        portfolioId: this.portfolioId,
        portfolioName: this.portfolioName,
        keyDates: workStreamScenarioNames,
        workManagers: this.workstreamForm.controls.workManagers.value,
        workStreamApprovers: this.workstreamForm.controls.approvers.value,
        workstreamLePccodesEntities: workStreamLepccodes
      };
      //console.log(this.prepareData);
      this.restService.post(URL_PREFIX.PORTFOLIO + '/data/workstream/edit/updateWorkstream', this.prepareData).subscribe(data => {
        if (data !== null && data.workStreamId !== null) {
          this.processFiles(this.workstreamForm.controls.others);

          this.workStreamData = data;
          sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME, this.prepareData.portFolioWorkStreamEntity.workStreamName);
          this.dataService.setActiveTab(this.selectedTab);
          this.resSuccess = true;
          this.commonService.showSnackBar({
            type: 'success',
            message: 'Workstream Updated'
          });
        }
      },
        error => {
          if (error.status !== null) {
            console.log(list.portfolioName + 'portfolioName');
          }
        }
      );

    }
  }

  async processFiles(othersObj) {
    for (var i = 0; i < othersObj.length; i++) {
      this.dataService.loaderHandler(true);
      if (othersObj.controls[i].controls.isEdited.value) {
        await this.uploadService(othersObj.controls[i]).toPromise();
      }
    }
    this.dataService.loaderHandler(false);
    this.dataService.setActiveTab(this.selectedTab);
    this.router.navigateByUrl(`home/portfolio/createPortfolio/workstream/${this.workstreamID}`);

  }

  uploadService(other) {
    let fileRequest: FormData = new FormData();
    const options = { headers: new HttpHeaders({ 'Authorization': 'Bearer ' + localStorage.getItem('access_token') }) };
    fileRequest.append('workStreamId', other.controls.othersEntity.controls.workStreamId.value);
    fileRequest.append('documentType', other.controls.othersEntity.controls.documentType.value);
    fileRequest.append('documentName', other.controls.othersEntity.controls.documentName.value);
    fileRequest.append('workstreamOthersSurrId', other.controls.othersEntity.controls.wsOthersSurrId.value);
    fileRequest.append('description', other.controls.othersEntity.controls.description.value);
    fileRequest.append('activeInd', other.controls.othersEntity.controls.activeInd.value);
    fileRequest.append('createdBy', other.controls.othersEntity.controls.createdBy.value);
    fileRequest.append('dateCreated', this.datePipe.transform(other.controls.othersEntity.controls.dateCreated.value, 'yyyy-MM-dd hh:mm:ss'));
    fileRequest.append('modifiedBy', other.controls.othersEntity.controls.modifiedBy.value);
    fileRequest.append('dateModified', this.datePipe.transform(other.controls.othersEntity.controls.dateModified.value, 'yyyy-MM-dd hh:mm:ss'));
    fileRequest.append('filePath', other.controls.othersEntity.controls.filePath.value);
    fileRequest.append('file', other.controls.file.value);
    fileRequest.append('workstreamName', other.controls.othersEntity.controls.workstreamName.value);
    return this.http.post(URL_PREFIX.PORTFOLIO + `/file/upload?portfolioId=${other.controls.othersEntity.controls.portfolioId.value}`
      , fileRequest, options);

  }


  createKeyDates(data) {
    data = data as Array<any>;
    data.forEach(element => {
      this.keyDatesData.push(
        {
          wsDateSurrId: element.wsDateSurrId,
          workStreamId: this.wkstrmID,
          portfolioId: this.portfolioId,
          scenarioName: element.scenarioName,
          approvedDate: element.approvedDate,
          goLiveDate: element.goLiveDate,
          endDate: element.endDate,
          startDate: element.startDate,
          activeInd: 'true'
        });
    });
    return this.keyDatesData;
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustom(date);
  }

  dateFormatISO(millisecondsDate?: any) {
    return this.dateUtility.dateFormatterISO(millisecondsDate);
  }

  checkWorkStreamExist(workStreamName: any) {
    const postData = {
      dataType: WORK_HIERARCHY_CONST.WORKSTREAM,
      dataName: workStreamName,
      workstreamID: sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID),
      streamId: sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID)
    };
    this.restService.post(URL_PREFIX.PORTFOLIO + '/data/portfolio/dataname', postData).subscribe(data => {
      this.isWorkStreamNameExist = data;
      this.showName = workStreamName;
      if (this.isWorkStreamNameExist && this.workstreamName === workStreamName) {
        this.isWorkStreamNameExist = false;
      }
    });
  }

  editWorkstream(workstreamID: any, workstreamName: any) {
    this.loadDropdowns();
    let staffName = JSON.parse(localStorage.getItem('userinfo')).displayName;
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/portfolio/common/getportfoliodata/${workstreamID}/WorkStream/${workstreamName}?staffName=${staffName}`).subscribe(data => {
      this.workStreamData = data;
      this.workstreamLePccodesEntitiesData = this.workStreamData.workstreamLePccodesEntities;
      this.setLepcBuild();
      this.setLepcOperate();
      this.validatelepcpercentBuildTotal();
      this.validatelepcpercentOperateTotal();
      this.workstreamForm.controls.workStreamName.setValue(data.workStreamName);
      this.workstreamForm.controls.workStreamDesc.setValue(data.workStreamDesc);
      this.workstreamForm.controls.country.setValue(data.country);
      this.workstreamForm.controls.valueBenefit.setValue(data.valueBenefit);
      this.workstreamForm.controls.bizSegment.setValue(data.bizSegment);
      this.workstreamForm.controls.subPlatFormName.setValue(data.subPlatFormName);

      this.workstreamForm.controls.workStatus.setValue(data.workStatus);
      this.workstreamForm.controls.category.setValue(data.category);
      this.workstreamForm.controls.overallRiskLevel.setValue(data.overallRiskLevel);
      this.workstreamForm.controls.workPhase.setValue(data.workPhase);
      this.workstreamForm.controls.workStreamRef.setValue(data.workStreamRef);
      this.workstreamForm.controls.workStreamSurrId.setValue(data.workStreamSurrId);
      this.workstreamForm.controls.workStreamId.setValue(data.workStreamId);
      this.workstreamForm.controls.dateCreated.setValue(data.dateCreated);
      this.workstreamForm.controls.createdBy.setValue(data.createdBy);

      if (data.editable === 'NO') {
        this.commonService.showSnackBar({ type: 'alert', message: 'This Worksteam is being edited by ' + data.staffName + ' \n Your changes will not be saved', duration: 5000 });
        this.showSaveBtn = false;
      } else {
        // Track and show dailogue for lock extension
        this.timer = setTimeout(() => {
          this.showExtensionDailogue();
        }, 1800000)
      }
      this.getLePcCodeData(data.country);

    });
  }

  loadDropdowns() {

    const list = ['Value/Benefit', 'Work Status', 'Country', 'Work Phase'];
    this.restService.post(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues/', list).subscribe(data => {
      data.Country.forEach(element => {
        this.countryDropdown.push({ value: element.desc, display: element.value });
      });
      data['Value/Benefit'].forEach(element => {
        this.benefitTypeDropDownList.push({ value: element.value, display: element.value });
      });
      data['Work Status'].forEach(element => {
        this.workStatusDropdown.push({ value: element.value, display: element.value });
      });
      data['Work Phase'].forEach(element => {
        this.workPhaseDropDownList.push({ value: element.value, display: element.value });
      });
    });
    this.restService.get(URL_PREFIX.PEOPLE + '/data/platforms/all').subscribe(data => {
      this.data = data;
      data.forEach(element => {
        this.PlatformDropdownList.push({ key: element.platformId, value: element.platformIndex + ' - ' + element.platform });
      });
    });
    var str = this.portfolioId;
    var res = str.substring(1, str.indexOf('-')).trim();


    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/non-generic/subplatform/' + res).subscribe(data => {
      this.data = data;
      data.forEach(element => {
        this.subPlatformDropdownList.push({ key: element.subPlatformName, value: element.subPlatformName });
      });
    });
  }

  getLePcCodeData(country: string) {
    this.restService.get(URL_PREFIX.PORTFOLIO + '/api/v1/pccodes/countryCode/' + country).subscribe(data => {
      data.forEach(element => {
        this.pcCodeDropdownList.push({ key: element, value: element, flag: true });
      });
    });
  }

  scenarios(): FormArray {
    return this.workstreamForm.get('scenarios') as FormArray;
  }

  lepccodesBuild(): FormArray {
    return this.workstreamForm.get('lepccodesBuild') as FormArray;
  }

  lepccodesOperate(): FormArray {
    return this.workstreamForm.get('lepccodesOperate') as FormArray;
  }

  approvers(): FormArray {
    return this.workstreamForm.get('approvers') as FormArray;
  }

  others(): FormArray {
    return this.workstreamForm.get('others') as FormArray;
  }

  // tslint:disable-next-line: variable-name
  addScenario(_event: any) {
    this.keyDatesDisplayDates.push({
      'showApprovalDate': true, 'showStartDate': true,
      'showEndDate': true, 'showGoLiveDate': true
    });
    const data = {
      wsDateSurrId: '',
      scenarioName: 'Forecast',
      approvedDate: '',
      startDate: new Date(),
      goLiveDate: '',
      endDate: '',
      activeInd: true,
    };
    this.scenarios().push(this.createScenario(data));
    this.keyDates = this.workstreamForm.controls.scenarios.value;
    this.restrictKeyDates = true;
  }

  deleteScenario(index: number) {
    this.scenarios().value[index].activeInd = false;
    const scenario = this.scenarios().controls[index] as FormArray;
    const ctrl = scenario.controls as any;
    ctrl.activeInd.value = false;
    if (this.scenarios().value[index].scenarioName == 'Forecast') {
      this.restrictKeyDates = false;
    }
    if (this.scenarios().value[index].wsDateSurrId === '') {
      this.scenarios().removeAt(index);
    }
  }

  createScenario(data: any): FormGroup {
    return this.fb.group(
      {
        wsDateSurrId: [data.wsDateSurrId, []],
        scenarioName: [data.scenarioName, [Validators.required]],
        approvedDate: [data.approvedDate, []],
        startDate: [data.startDate, [Validators.required, this.dateValidator(this.maxStartDate, 'startDate')]],
        goLiveDate: [data.goLiveDate, [Validators.required, this.dateValidator(this.maxLiveDate, 'liveDate')]],
        endDate: [data.endDate, [Validators.required, this.dateValidator(this.maxEndDate, 'endDate')]],
        activeInd: [data.activeInd, []],
      });
  }

  setScenarios() {
    let control = <FormArray>this.workstreamForm.controls.scenarios;
    if (this.keyDates) {
      this.keyDates.forEach(x => {
        if (x.scenarioName == 'Forecast') {
          control.push(this.fb.group({
            wsDateSurrId: [x.wsDateSurrId, []],
            scenarioName: [x.scenarioName, []],
            approvedDate: [this.dateFormatISO(x.approvedDate), []],
            startDate: [this.dateFormatISO(x.startDate), [Validators.required, this.dateValidator(this.maxStartDate, 'startDate')]],
            goLiveDate: [this.dateFormatISO(x.goLiveDate), [Validators.required, this.dateValidator(this.maxLiveDate, 'liveDate')]],
            endDate: [this.dateFormatISO(x.endDate), [Validators.required, this.dateValidator(this.maxEndDate, 'endDate')]],
            activeInd: [x.activeInd, []]
          }))
        } else {
          control.push(this.fb.group({
            wsDateSurrId: [x.wsDateSurrId],
            scenarioName: [x.scenarioName],
            approvedDate: [this.dateFormatISO(x.approvedDate)],
            startDate: [this.dateFormatISO(x.startDate)],
            goLiveDate: [this.dateFormatISO(x.goLiveDate)],
            endDate: [this.dateFormatISO(x.endDate)],
            activeInd: [x.activeInd]
          }))
        }
      });
      for (let i = 0; i < this.keyDates.length; i++) {
        if (this.keyDates[i].scenarioName == 'Forecast' && !this.restrictKeyDates) {
          this.restrictKeyDates = true;
        }

        this.keyDatesDisplayDates[i] = {
          'showApprovalDate': false, 'showStartDate': false,
          'showEndDate': false, 'showGoLiveDate': false
        };
        if (this.keyDates[i].approvedDate) {
          this.keyDatesDisplayDates[i].showApprovalDate = true;
        }
        if (this.keyDates[i].startDate) {
          this.keyDatesDisplayDates[i].showStartDate = true;
        }
        if (this.keyDates[i].goLiveDate) {
          this.keyDatesDisplayDates[i].showGoLiveDate = true;
        }
        if (this.keyDates[i].endDate) {
          this.keyDatesDisplayDates[i].showEndDate = true;
        }
      }
    }
  }

  setApprovers() {
    let control = <FormArray>this.workstreamForm.controls.approvers;
    if (this.approversData) {
      this.approversData.forEach(x => {
        if (x.scenario == 'Forecast' || x.scenario == 'Financial Case') {
          control.push(this.fb.group({
            wsApproverSurrId: x.wsApproverSurrId,
            workStreamId: this.wkstrmID,
            portfolioId: this.portfolioId,
            oneBankId: [x.oneBankId],
            role: [x.role, [Validators.required]],
            delegateInd: [x.delegateInd == 'true' ? true : false, []],
            staffName: [x.staffName, [Validators.required]],
            scenario: [x.scenario, [Validators.required]],
            action: [x.action, [Validators.required]],
            notifyInd: [x.notify, []],
            effectiveStartDate: x.effectiveStartDate,
            effectiveEndDate: x.effectiveEndDate,
            activeInd: x.activeInd
          }, { validator: this.approverValidator(control.length) }))
        } else {
          control.push(this.fb.group({
            wsApproverSurrId: x.wsApproverSurrId,
            workStreamId: this.wkstrmID,
            portfolioId: this.portfolioId,
            oneBankId: [x.oneBankId],
            role: [x.role],
            delegateInd: [x.delegateInd == 'true' ? true : false, []],
            staffName: [x.staffName],
            scenario: [x.scenario],
            action: [x.action],
            notifyInd: [x.notify],
            effectiveStartDate: x.effectiveStartDate,
            effectiveEndDate: x.effectiveEndDate,
            activeInd: x.activeInd
          }))
        }
      });
    }
  }

  deleteApprover(data, index) {
    this.approvers().value[index].activeInd = false;
    let approversList = this.approvers().controls[index] as FormArray;
    const control = approversList.controls as any;
    control.activeInd.value = false;
    if (this.approvers().value[index].wsApproverSurrId === '') {
      this.approvers().removeAt(index)
    } else {
      (this.approvers().at(index) as FormGroup).controls['staffName'].setErrors(null);
    }

    if (data.oneBankId != '' && data.scenario != '' && data.role != '') {
      let str = `${data.role}-${data.oneBankId}-${data.scenario}`;
      this.hasDuplicateRecordForStaffName.splice(index, 1);
      if (Object.values(this.duplicateApproverPattetn).indexOf(str) >= 0) {
        delete this.duplicateApproverPattetn[_.findKey(this.duplicateApproverPattetn, function (o) {
          return o == str
        })];
      } else {
        delete this.approverPattern[_.findKey(this.approverPattern, function (o) {
          return o == str
        })];
      }
    }
  }

  addApprover() {
    if (this.workstreamForm.controls.approvers.valid) {
      let control = <FormArray>this.workstreamForm.controls.approvers;
      this.approversData = control.value;
      control.push(
        this.fb.group({
          wsApproverSurrId: '',
          workStreamId: this.wkstrmID,
          portfolioId: this.portfolioId,
          role: ['', [Validators.required]],
          delegateInd: [false, []],
          oneBankId: '',
          staffName: ['', [Validators.required]],
          scenario: ['Forecast', [Validators.required]],
          action: ['', [Validators.required]],
          notifyInd: [{ value: '', disabled: true }, []],
          effectiveStartDate: '',
          effectiveEndDate: '',
          activeInd: 'true'
        }, { validator: this.approverValidator(control.length) })
      )
      this.approversData = control.value;
      this.selectDisabled[this.approversData.length - 1] = true;
      this.hasDuplicateRecordForStaffName[this.approversData.length - 1] = false;
    } else {
      let controls = this.approvers().controls;
      controls.forEach((element, index) => {
        for (const name in element['controls']) {
          if (element['controls'][name].invalid) {
            this.approvers().controls[index]['controls'][name].markAsTouched();
          }
        }
      });
    }
  }

  checkDuplicateApprover(str, index) {
    //check for duplicate approver
    if (Object.values(this.approverPattern).indexOf(str) < 0) {
      this.hasDuplicateRecordForStaffName[index] = false
      this.approverPattern[index] = str;
      this.duplicateApproverPattetn[index] && this.duplicateApproverPattetn[index] == str ? delete this.duplicateApproverPattetn[index] : '';
    } else {
      this.duplicateApproverPattetn[index] = str;
      this.hasDuplicateRecordForStaffName[index] = true;
      this.approverPattern[index] && this.approverPattern[index] == str ? delete this.approverPattern[index] : '';
    }
    this.approvers().at(index).updateValueAndValidity();
  }

  selectedRoleForApprover(e, data, index) {
    //check for duplicate approver
    if (data && data.oneBankId != '' && data.scenario != '') {
      this.hasDuplicateRecordForStaffName[index] = false;

      let str = `${data.role}-${data.oneBankId}-${data.scenario}`;
      this.checkDuplicateApprover(str, index);
    }

    let that = this;
    this.restService.get(URL_PREFIX.PORTFOLIO + `/data/non-generic/stakeholders/staffnames?platformIndex=${this.platformIndex}&role=${e.value}`).subscribe(staffList => {
      if (staffList) {
        that.employeeAsApprover[index] = [];
        Object.entries(staffList).forEach(function (obj) {
          that.employeeAsApprover[index].push({ key: obj[0], value: obj[1] });
        });
      }
      this.selectDisabled[index] = false;
    });
  }

  bindApproverNames(index) {
    var arrayControl = this.workstreamForm.get('approvers') as FormArray;
    this.filteredApproverNames[index] = arrayControl.at(index).get('staffName').valueChanges
      .pipe(
        startWith(''),
        map(value => this._filterApproverNames(value, index))
      );
  }

  private _filterApproverNames(value: any, index: number): any[] {
    return this.employeeAsApprover[index]
      .filter(option => option.value.toLowerCase().includes(value.toLowerCase()));
  }

  onSelectOfDelegate(i, e) {
  }

  onSelectApprover(e, data, index) {
    const empOneBankId = this.employeeAsApprover[index].filter(emp => e.option.value == emp.value);
    ((this.approvers()).at(index) as FormGroup).get('oneBankId').patchValue(empOneBankId[0].key);
    //check for duplicate approver
    if (data && data.role != '' && data.scenario != '') {
      let str = `${data.role}-${empOneBankId[0].key}-${data.scenario}`;
      this.checkDuplicateApprover(str, index);
    }
  }

  onSelectScenario(e, data, index) {
    //check for duplicate approver
    if (data && data.oneBankId && data.oneBankId != '' && data.role && data.role != '') {
      this.hasDuplicateRecordForStaffName[index] = false;

      let str = `${data.role}-${data.oneBankId}-${data.scenario}`;
      this.checkDuplicateApprover(str, index);
    }
  }

  asIsOrder(a, b) {
    return 1;
  }

  setOthers() {
    let control = <FormArray>this.workstreamForm.controls.others;

    if (this.othersData) {
      this.othersData.forEach(x => {
        control.push(this.fb.group({
          othersEntity: this.fb.group({
            wsOthersSurrId: x.wsOthersSurrId,
            workStreamId: x.workStreamId,
            portfolioId: this.portfolioId,
            documentName: x.documentName,
            documentType: x.documentType,
            description: x.description,
            filePath: x.filePath,
            modifiedBy: x.modifiedBy,
            dateModified: x.dateModified,
            createdBy: x.createdBy,
            dateCreated: x.dateCreated,
            activeInd: x.activeInd,
            workstreamName: x.workstreamName,
          }),
          file: new File([''], x.documentName),
          isEdited: false
        }))
      });
    }
  }

  onAddDocClick() {
    // this.isErrorExists = false;
    // this.isSuccessMsg = false;
    const dialogRef = this.dialog.open(OthersDialogComponent, {
      data: {
        other: this.fb.group({
          othersEntity: this.fb.group({
            wsOthersSurrId: 0,
            workStreamId: this.workstreamID,
            portfolioId: this.portfolioId,
            workstreamName: this.workstreamName,
            documentName: '',
            documentType: '',
            description: '',
            filePath: '',
            modifiedBy: '',
            dateModified: '',
            createdBy: '',
            dateCreated: '',
            activeInd: true
          }),
          file: null
        }),
        documentTypes: this.docTypesDropdown,
        header: 'Add Documents'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.addOthers(result.controls)
    });
  }


  editOther(index) {
    // this.others().value[index].activeInd = false;
    //  let othersList = this.others().controls[index] as FormArray;
    //  const control = othersList.controls as any;

    //  this.isErrorExists = false;
    //  this.isSuccessMsg = false;
    const dialogRef = this.dialog.open(OthersDialogComponent, {
      data: {
        other: this.others().controls[index],
        documentTypes: this.docTypesDropdown,
        header: 'Edit Documents'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.others().controls[index] = this.fb.group(result.controls);
    });
  }

  addOthers(othersUpload: any) {
    if (this.workstreamForm.controls.others.valid) {
      let control = <FormArray>this.workstreamForm.controls.others;
      this.othersData = control.value;
      control.push(
        this.fb.group(othersUpload)
      )
      this.othersData = control.value;
      this.selectDisabled[this.othersData.length - 1] = true;
      this.hasDuplicateRecord[this.othersData.length - 1] = false;

    } else {
      let controls = this.others().controls;
      controls.forEach((element, index) => {
        for (const name in element['controls']) {
          if (element['controls'][name].invalid) {
            this.others().controls[index]['controls'][name].markAsTouched();
          }
        }
      });
    }
  }

  deleteOther(index: any) {
    let othersList = this.others().controls[index] as FormArray;
    const control = othersList.controls as any;
    control.othersEntity.controls.activeInd.value = false;
    if (control.othersEntity.controls.wsOthersSurrId.value === 0) {
      this.others().removeAt(index)
    }
    control.isEdited.value = true;
  }

  getOthersData() {
    this.restService.get(URL_PREFIX.PORTFOLIO + '/file/workstream/others/' + this.workstreamID).subscribe(data => {
      const testData = Object.values(data);
      this.othersData = [].concat.apply([], testData);
      this.setOthers();
    })
  }


  addLepccodeBuildScenario() {
    // const data = {
    //   lepcbuild: '',
    //   allocationPercentBuild: '',

    // };
    // this.lepccodesBuild().push(this.createlepcBuild(data));
    if (this.workstreamForm.controls.lepccodesBuild.valid) {
      let control = <FormArray>this.workstreamForm.controls.lepccodesBuild;
      this.lepccodesBuildData = control.value;
      control.push(
        this.fb.group({
          workstreamPccodeSurrId: '',
          workStreamId: this.wkstrmID,
          portfolioId: this.portfolioId,
          lepcbuild: ['', [Validators.required]],
          allocationPercentBuild: ['', [Validators.required]],
          createdBy: this.workStreamData.createdBy,
          dateCreated: this.workStreamData.dateCreated,
          modifiedBy: this.workStreamData.modifiedBy,
          dateModified: [''],
          workStreamName: this.workStreamData.workStreamName,
          buildOperate: 'build',
          wsLepccodesRefId: this.workStreamData.workStreamSurrId,
          activeInd: 'true'
        })
      )
      this.lepccodesBuildData = control.value;
      this._manageLePcBuildCodesControl(control.length - 1);
      //this.selectDisabled[this.approversData.length-1] = true;
      //  this.hasDuplicateRecord[this.approversData.length-1] = false;
      // this.hasDuplicateRecordForStaffName[this.approversData.length-1] = false;

    }
  }

  private _manageLePcBuildCodesControl(index: number) {
    var arrayControl = this.workstreamForm.get('lepccodesBuild') as FormArray;
    this.filteredPcBuildCodes[index] = arrayControl.at(index).get('lepcbuild').valueChanges
      .pipe(
        startWith(''),
        map(value => this._filterLePcCodes(value))
      );
  }

  private _filterLePcCodes(value: any): any[] {
    return this.pcCodeDropdownList
      .filter(option => option.value?.toLowerCase().includes(value?.toLowerCase()));
  }

  addLepccodeOperateScenario() {
    // const data = {
    //   lePCCodeOperate: '',
    //   allocationPercentOperate: '',
    // };
    // this.lepccodesOperate().push(this.createlepcOperate(data));
    if (this.workstreamForm.controls.lepccodesOperate.valid) {
      let control = <FormArray>this.workstreamForm.controls.lepccodesOperate;
      this.lepccodesOperateData = control.value;
      control.push(
        this.fb.group({
          workstreamPccodeSurrId: '',
          workStreamId: this.wkstrmID,
          portfolioId: this.portfolioId,
          lePCCodeOperate: ['', [Validators.required]],
          allocationPercentOperate: ['', [Validators.required]],
          createdBy: this.workStreamData.createdBy,
          dateCreated: this.workStreamData.dateCreated,
          modifiedBy: this.workStreamData.modifiedBy,
          dateModified: [''],
          workStreamName: this.workStreamData.workStreamName,
          buildOperate: 'operate',
          wsLepccodesRefId: this.workStreamData.workStreamSurrId,
          activeInd: 'true'
        })
      )
      this.lepccodesOperateData = control.value;
      this._manageLePcOperateCodesControl(control.length - 1);
      //this.selectDisabled[this.approversData.length-1] = true;
      //  this.hasDuplicateRecord[this.approversData.length-1] = false;
      // this.hasDuplicateRecordForStaffName[this.approversData.length-1] = false;
    }
  }

  private _manageLePcOperateCodesControl(index: number) {
    var arrayControl = this.workstreamForm.get('lepccodesOperate') as FormArray;
    this.filteredPcOperateCodes[index] = arrayControl.at(index).get('lePCCodeOperate').valueChanges
      .pipe(
        startWith(''),
        map(value => this._filterLePcCodes(value))
      );
  }

  createlepcBuild(data: any): FormGroup {
    return this.fb.group(
      {
        lepcbuild: [data.lepcbuild, []],
        allocationPercentBuild: [data.allocationPercentBuild, []],
      });
  }

  createlepcOperate(data: any): FormGroup {
    return this.fb.group(
      {
        lePCCodeOperate: [data.lePCCodeOperate, []],
        allocationPercentOperate: [data.allocationPercentOperate, []],
      });
  }

  deleteLepccodeBuildScenario(index: number) {
    this.lepccodesBuild().value[index].activeInd = false;
    let lepccodesBuildList = this.lepccodesBuild().controls[index] as FormArray;
    const control = lepccodesBuildList.controls as any;
    control.activeInd.value = false;
    if (this.lepccodesBuild().value[index].workstreamPccodeSurrId === '') {
      this.lepccodesBuild().removeAt(index)
    }
    this.validatelepcpercentBuildTotal();

  }

  deleteLepccodeOperateScenario(index: number) {
    // const scenario = this.lepccodesOperate().controls[index] as FormArray;
    // const ctrl = scenario.controls as any;
    // this.lepccodesOperate().removeAt(index);
    this.lepccodesOperate().value[index].activeInd = false;
    let lepccodesOperateList = this.lepccodesOperate().controls[index] as FormArray;
    const control = lepccodesOperateList.controls as any;
    control.activeInd.value = false;
    if (this.lepccodesOperate().value[index].workstreamPccodeSurrId === '') {
      this.lepccodesOperate().removeAt(index)
    }
    this.validatelepcpercentOperateTotal();

  }

  setLepcBuild() {
    let control = <FormArray>this.workstreamForm.controls.lepccodesBuild;

    if (this.workstreamLePccodesEntitiesData) {
      this.workstreamLePccodesEntitiesData.forEach(x => {
        if (x.buildOperate == 'build') {
          control.push(this.fb.group({
            lepcbuild: [x.lePCCode, []],
            allocationPercentBuild: [x.allocationPercent, []],
            createdBy: [x.createdBy, []],
            dateCreated: [x.dateCreated, []],
            modifiedBy: [x.modifiedBy, []],
            dateModified: [x.dateModified, []],
            workstreamPccodeSurrId: [x.workstreamPccodeSurrId, []],
            portfolioId: [this.workStreamData.portfolioId, []],
            workStreamId: [this.workStreamData.workStreamId, []],
            workStreamName: [this.workStreamData.workStreamName, []],
            buildOperate: [x.buildOperate, []],
            wsLepccodesRefId: [this.workStreamData.workStreamSurrId, []],
            activeInd: x.activeInd

          }))
        }
      });
    }
    //this.workstreamForm.controls.lepccodesBuild.get('lepcbuild').patchValue("meow");
    //((this.workstreamForm.get('lepccodesBuild') as FormArray).get('lepcbuild')as FormArray.at(0) as FormGroup).patchValue("meow");
  }

  setLepcOperate() {
    let control = <FormArray>this.workstreamForm.controls.lepccodesOperate;

    if (this.workstreamLePccodesEntitiesData) {
      this.workstreamLePccodesEntitiesData.forEach(x => {
        if (x.buildOperate == 'operate') {
          control.push(this.fb.group({
            lePCCodeOperate: [x.lePCCode, []],
            allocationPercentOperate: [x.allocationPercent, []],
            createdBy: [x.createdBy, []],
            dateCreated: [x.dateCreated, []],
            modifiedBy: [x.modifiedBy, []],
            dateModified: [x.dateModified, []],
            workstreamPccodeSurrId: [x.workstreamPccodeSurrId, []],
            portfolioId: [this.workStreamData.portfolioId, []],
            workStreamId: [this.workStreamData.workStreamId, []],
            workStreamName: [this.workStreamData.workStreamName, []],
            buildOperate: [x.buildOperate, []],
            wsLepccodesRefId: [this.workStreamData.workStreamSurrId, []],
            activeInd: x.activeInd
          }))
        }
      });
    }
  }

  validatelepcpercentOperateTotal() {
    let sum = 0;
    let control = <FormArray>this.workstreamForm.controls.lepccodesOperate;
    control.value.forEach(element => {
      if (element['activeInd'] && element['activeInd'].toLowerCase() === 'true') {
        if (element['allocationPercentOperate'] != null) {
          sum = sum + Number(element['allocationPercentOperate']);
        }
      }
    });
    if (sum > 100 || sum < 100) {
      this.showlepcpercentOperateErrorMessage = true;
    } else {
      this.showlepcpercentOperateErrorMessage = false;
    }
    if (sum >= 100) {
      this.showAddlepcpercentOperateButton = true;
    } else {
      this.showAddlepcpercentOperateButton = false;
    }

    if (sum == 0) {
      this.showlepcpercentOperateErrorMessage = false;
    }

    if (sum == 0 && control.value.length > 0) {
      this.showlepcpercentOperateErrorMessage = true;
    }
  }

  getMinLiveDate(data) {
    if (this.maxLiveDate && this.maxLiveDate != '' && !isNaN(this.maxLiveDate.getTime())) {
      return this.maxLiveDate;
    } else if (data && data != '') {
      let date = new Date(data);
      date.setDate(date.getDate() + 1);
      console.log("min live date", date);
      return date;
    } else {
      return '';
    }
  }

  validatelepcpercentBuildTotal() {
    let sum = 0;
    let control = <FormArray>this.workstreamForm.controls.lepccodesBuild;
    control.value.forEach(element => {
      if (element['activeInd'] && element['activeInd'].toLowerCase() === 'true') {
        if (element['allocationPercentBuild'] != null) {
          sum = sum + Number(element['allocationPercentBuild']);
        }
      }
    });
    if (sum > 100 || sum < 100) {
      this.showlepcpercentBuildErrorMessage = true;
    } else {
      this.showlepcpercentBuildErrorMessage = false;
    }

    if (sum >= 100) {
      this.showAddlepcpercentBuildButton = true;
    } else {
      this.showAddlepcpercentBuildButton = false;
    }

    if (sum == 0) {
      this.showlepcpercentBuildErrorMessage = false;
    }

    if (sum == 0 && control.value.length > 0) {
      this.showlepcpercentBuildErrorMessage = true;
    }
  }
}
