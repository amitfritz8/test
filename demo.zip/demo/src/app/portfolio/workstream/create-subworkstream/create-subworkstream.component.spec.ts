import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateSubworkstreamComponent } from './create-subworkstream.component';
import { BrowserModule, By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule, Validators, FormBuilder } from '@angular/forms';
import { MaterialModule } from 'src/app/material.module';
import { SharedModule } from 'src/app/common/module/shared.module';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { RestService } from 'src/app/common/service/rest.service';
import { of } from 'rxjs';
import { DebugElement } from '@angular/core';
import { DataService } from 'src/app/common/service/data.service';
import { TimeFormat } from 'src/app/common/pipes/timeFormater.pipe';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';


xdescribe('CreateSubworkstreamComponent', () => {
  let component: CreateSubworkstreamComponent;
  let fixture: ComponentFixture<CreateSubworkstreamComponent>;
  let de: DebugElement;
  let el: HTMLElement;
  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CreateSubworkstreamComponent],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        SharedModule,
        RouterTestingModule,
        HttpClientModule,
        BrowserAnimationsModule
      ],
      providers: [
        // tslint:disable-next-line: no-use-before-declare
        { provide: DateUtility, useClass: MockDateUtility },
        // tslint:disable-next-line: no-use-before-declare
        { provide: RestService, useClass: MockRestService },
        // tslint:disable-next-line: no-use-before-declare
        { provide: DataService, useClass: MockDataService },
        // tslint:disable-next-line: no-use-before-declare
        { provide: TimeFormat, useClass: MockTimeFormat },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateSubworkstreamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.mainDiv'));
    el = de.nativeElement;
    component.subWorkStreamForm = formBuilder.group({
      subWorkStreamName: ['test ', [Validators.required, Validators.maxLength(100)]],
      deliveryPlatformUnit: ['01 - CBG Customer Mgt & Analytics', [Validators.required]]
    });
    sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID, 'P25-20001-I');
    sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME, 'test33');
    sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID, 'P25DAH2-24002-E0002');
    sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME, 'Test22');

    component.resSuccess = false;
    component.isDeliveryUnitExist = false;

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call for getData', (done: DoneFn) => {
    component.getData();
    done();
  });

  it('should call for goback', (done: DoneFn) => {
    component.goback();
    // tslint:disable-next-line: no-use-before-declare
    const router: MockRouter = new MockRouter();
    spyOn(router, 'navigateByUrl');
    router.navigateByUrl('/home/portfolio');
    expect(router.navigateByUrl).toHaveBeenCalled();
    done();
  });

  it('should call dateFormat', () => {
    const date = new Date();
    component.dateFormat(date);
    // tslint:disable-next-line: no-use-before-declare
    const c: MockDateUtility = new MockDateUtility();
    spyOn(c, 'dateFormatterCustom');
    c.dateFormatterCustom(date);
    expect(c.dateFormatterCustom).toHaveBeenCalled();
  });

  it('should call for saveSubWorkStream', () => {

    component.portfolioId = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID);
    component.portfolioName = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME);
    component.workStreamId = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID);
    component.workStreamName = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME);
    const mockRes = {
      createdBy: 'vamshikrishnag',
      dateCreated: 1577164352964,
      modifiedBy: 'vamshikrishnag',
      dateModified: 1577164352964,
      subWorkStreamSurrId: 0,
      subWorkStreamId: 'P24DAH2-24002-E0002-P25',
      workStreamId: 'P24DAH2-24002-E0002',
      subWorkStreamName: 'Test',
      subWorkStreamDesc: '',
      country: 'DAH2',
      platformUnit: '',
      subPlatformName: '',
      deliveryUnit: '25',
      category: '',
      appCode: '',
      appCodeDesc: '',
      subWorkStreamRef: ''

    };
    component.saveSubWorkStream();
    component.subWorkStreamId = mockRes.subWorkStreamId;
    component.subWorkStreamName = mockRes.subWorkStreamName;
    component.resSuccess = true;
    component.subWorkStreamData = mockRes;
    sessionStorage.setItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID, mockRes.subWorkStreamId);
    component.isDeliveryUnitExist = true;
  });

  it('should call checkSubWorkStreamExist', (done: DoneFn) => {
    const postData = {
      dataType: WORK_HIERARCHY_CONST.SUB_WORKSTREAM,
      dataName: 'test'
    };
    // expect(component.isSubWorkStreamNameExist).toHaveBeenCalled();
    // component.isSubWorkStreamNameExist = true;
    // component.showName = postData.dataName;
    done();
  });

  it('should call onDeliveryUnitChnage', () => {
    component.isDeliveryUnitExist = false;
    // expect(component.isDeliveryUnitExist).toHaveBeenCalled();
  });
});
class MockRouter {
  navigateByUrl(url: any) {
    return null;
  }
}

class MockDateUtility {
  dateFormatterCustom(date?: Date) {
    return '';
  }

}
class MockRestService {
  get() {
    return of([
      {
        platformId: '1',
        platformIndex: '01',
        platform: 'CBG Customer Mgt & Analytics'
      },
      {
        platformId: '2',
        platformIndex: '02',
        platform: 'CBG Digital'
      }
    ]);
  }
  post(url: any, data: any) {
    if (url !== 'people/data/portfolio/dataname') {
      return of({
        createdBy: 'vamshikrishnag',
        dateCreated: 1577164352964,
        modifiedBy: 'vamshikrishnag',
        dateModified: 1577164352964,
        subWorkStreamSurrId: 0,
        subWorkStreamId: 'P24DAH2-24002-E0002-P25',
        workStreamId: 'P24DAH2-24002-E0002',
        subWorkStreamName: 'Test',
        subWorkStreamDesc: '',
        country: 'DAH2',
        platformUnit: '',
        subPlatformName: '',
        deliveryUnit: '25',
        category: '',
        appCode: '',
        appCodeDesc: '',
        subWorkStreamRef: ''
      });
    } else  {
      return of(
        ['true']
      );
    }
  }
}
class MockTimeFormat {
  transform(date?: Date) {
    return '';
  }
}

class MockDataService {
  sendMessage(test) {
    return null;
  }
}


