import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/common/module/shared.module';
import { CreateSubworkstreamComponent } from './create-subworkstream.component';

const routes: Routes = [
    {path: '', component: CreateSubworkstreamComponent}
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
  ],
  declarations: [
    CreateSubworkstreamComponent
  ],
  exports: [],
  entryComponents: []
})

export class CreateSubworkstreamRoutingModule {
}