import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkstreamListingComponent } from './workstreamlisting.component';

xdescribe('WorkstreamListingComponent', () => {
  let component: WorkstreamListingComponent;
  let fixture: ComponentFixture<WorkstreamListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkstreamListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkstreamListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});