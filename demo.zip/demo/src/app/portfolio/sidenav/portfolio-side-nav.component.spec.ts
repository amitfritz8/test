import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PortfolioSideNavComponent } from './portfolio-side-nav.component';


xdescribe('PortfolioSideNavComponent', () => {
  let component: PortfolioSideNavComponent;
  let fixture: ComponentFixture<PortfolioSideNavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PortfolioSideNavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PortfolioSideNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
