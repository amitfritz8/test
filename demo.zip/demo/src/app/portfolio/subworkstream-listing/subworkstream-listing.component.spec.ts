import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubWorkstreamListingComponent } from './subworkstreamlisting.component';

xdescribe('SubWorkstreamListingComponent', () => {
  let component: SubWorkstreamListingComponent;
  let fixture: ComponentFixture<SubWorkstreamListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubWorkstreamListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubWorkstreamListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});