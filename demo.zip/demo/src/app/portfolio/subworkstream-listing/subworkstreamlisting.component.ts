import { Component, OnInit, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { MatDialog } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { DataTableService } from 'src/app/common/service/dataTable.service';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { CommonService } from 'src/app/common/service/common.service';
import { MatPaginator } from '@angular/material/paginator';
import { Subscription } from 'rxjs';
import * as _ from 'lodash';

@Component({
  selector: 'app-subworkstream-listing',
  templateUrl: './subworkstream-listing.component.html',
  styleUrls: ['./subworkstream-listing.component.scss']
})
export class SubWorkstreamListingComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  reportingFlag='';
  rprtDrpdown=[];
  displayedColumns: string[] = ['subWorkStreamName', 'workStreamName', 'portfolioName', 'platformName', 'workType',
    'appCode'];
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  workTypeFilter = new FormControl('');
  portFolioNameFilter = new FormControl('');
  subWorkStreamNameFilter = new FormControl('');
  workStreamNameFilter = new FormControl('');
  platformFilter = new FormControl('');
  appCodeFilter = new FormControl('');
  ytdActualsFilter = new FormControl('');
  filterValues = {
    subWorkStreamName: '',
    workStreamName: '',
    portfolioName: '',
    platformName: '',
    workTypeAB: '',
    appCode: '',
    subWorkStreamId: ''
  };
  showFilter = false;
  searchText = '';
  platformList = [];
  displayCount: any;
  dataLength: any;
  subWorkStreamTotal: number;
  aWorkTotal: any;
  bWorkTotal: any;
  refData = {
    'categoryList': []
  }
  scenario: any;
  pageSubscription: Subscription;
  uamsFilterSubscription : Subscription;


  constructor(private restService: RestService, public dialog: MatDialog, private router: Router,
    private readonly dataTableService: DataTableService, private dataService: DataService, private commonService: CommonService) {
    this.dataSource = new MatTableDataSource();
    this.commonService.recieveMessage({
      title: "Sub-Workstream Listing"
    });
    this.refData = {
      'categoryList': []
    }
  }

  ngOnInit() {
    this.reportingFlag = 'Yes,No';
    const dataList = ['PF_Reporting Flag_Listing'];
    this.restService.post(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues', dataList).subscribe(data => {
      data['PF_Reporting Flag_Listing'].forEach(element => {
        this.rprtDrpdown.push({ key: element.value, value: element.desc });
      });
    });
    this.scenario = 'Forecast';
    const list = ['scenario'];
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/non-generic/scenario').subscribe(data => {
      this.refData['categoryList'] = data
    });
    this.uamsFilterSubscription = this.commonService.broadCastMessage.subscribe(data => {
      this.getData();
      this.getDropdownListForFilter();
    });
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }
  applyFilter(filterValue: string) {
    if (this.showFilter) {
      this.showFilter = false;
    }
    for (var i in this.filterValues) {
      this.filterValues[i] = filterValue.trim().toLowerCase();
    }
    this.dataSource.filter = JSON.stringify(this.filterValues);
    this.dataSource.filterPredicate = this.dataTableService.tableFilterForSearch();
    this.dataLength = this.dataSource.filteredData.length;
    this.paginator.pageIndex = 0;
    this.updateDisplayCount();
  }

  toggleFilter(e) {
    this.searchText = '';
    this.showFilter = !this.showFilter;
    if (this.filterValues) {
      for (let field in this.filterValues) {
        this.filterValues[field] = '';
      }
      this.dataSource.filter = JSON.stringify(this.filterValues);
    }
    this.workTypeFilter.setValue('');
    this.portFolioNameFilter.setValue('');
    this.platformFilter.setValue('');
    this.appCodeFilter.setValue('');
    this.subWorkStreamNameFilter.setValue('');
    this.workStreamNameFilter.setValue('');

  }
  getDropdownListForFilter() {
    this.platformList =[];
    this.restService.get(URL_PREFIX.PEOPLE + '/data/platforms/all').subscribe(data => {
      data.forEach(element => {
          this.platformList.push({ key: element.platformIndex + ' - ' + element.platform, value: element.platformIndex + ' - ' + element.platform });     
      });
      this.platformList.unshift({ key: 'all', value: 'All' });
    });
  }
  // get table data
  getData() {
    this.dataService.loaderHandler(true);
    const platform = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    let idAndRoles =
      {oneBankId : localStorage.getItem('userOneBankId'),
        roles : Object.keys(JSON.parse(sessionStorage.getItem('roles'))),
        locations : locations,
        platform : platform,
        scenario : this.scenario,
        reportingFlag: this.reportingFlag ? this.reportingFlag.split(','): []}
    //this.restService.get(URL_PREFIX.PORTFOLIO + `/data/subworkstream/listing?scenario=${this.scenario}`).subscribe(data => {
    this.restService.post(URL_PREFIX.PORTFOLIO + `/data/subworkstream/listing`,idAndRoles).subscribe(data => {
      data.forEach(element => {
        element['workTypeAB'] = element.workType
      });
      this.dataService.loaderHandler(false);
      this.dataSource.data = data;
      this.dataSource.sort = this.sort;
      this.dataSource.sortingDataAccessor = (data, header) => {
        if (this.displayedColumns.includes(header)) {
          if (typeof (data[header]) != 'number' && data[header]) {
            return data[header].toString().toLowerCase();
          } else {
            return data[header];
          }
        }
      }
      this.dataSource.sort = this.sort;
      this.dataLength = this.dataSource.data.length;
      this.dataSource.paginator = this.paginator;
      this.updateDisplayCount();
      this.pageSubscription = this.paginator.page.subscribe(v => {
        this.updateDisplayCount();
      })
      this.checkForUpdatedCounts(this.dataSource.data);
    });
    this.filterChanges();
  }

  ngOnDestroy() {
    this.pageSubscription ? this.pageSubscription.unsubscribe() : '';
    this.uamsFilterSubscription.unsubscribe();
  }

  updateDisplayCount() {
    this.displayCount = (this.paginator.pageIndex + 1) * 20 > this.dataLength ? this.dataLength : (this.paginator.pageIndex + 1) * 20;
  }


  checkForUpdatedCounts(data: any[]) {
    this.countOfSubWorkStreams(data);
    this.aWorkTotalCount(data);
    this.bWorkTotalCount(data);
    this.updateDisplayCount();
  }
  aWorkTotalCount(data: any) {
    let countList = [];
    data.forEach(element => {
      if (element['workType'] && element['workType'].toLowerCase() == 'a-work') {
        countList.push(element);
      }
    });
    this.aWorkTotal = countList.length;
  }
  bWorkTotalCount(data: any) {
    let countList = [];
    data.forEach(element => {
      if (element['workType'] && element['workType'].toLowerCase() == 'b-work') {
        countList.push(element);
      }
    });
    this.bWorkTotal = countList.length;
  }

  countOfSubWorkStreams(data) {
    let countList = [];
    data.forEach(element => {
      if (element['subWorkStreamName'] && element['subWorkStreamName'].toLowerCase() == 'subWorkStreamName') {
        countList.push(element);
      }
    });
    this.subWorkStreamTotal = countList.length;
  }

  filterChanges() {

    this.subWorkStreamNameFilter.valueChanges.subscribe(data => {
      this.filterValues.subWorkStreamName = data;
      this.dataSource.filter = JSON.stringify(this.filterValues);
      this.dataSource.filterPredicate = this.dataTableService.tableFilter();
      this.dataLength = this.dataSource.filteredData.length;
      this.checkForUpdatedCounts(this.dataSource.filteredData);
    });

    this.workStreamNameFilter.valueChanges.subscribe(data => {
      this.filterValues.workStreamName = data;
      this.dataSource.filter = JSON.stringify(this.filterValues);
      this.dataSource.filterPredicate = this.dataTableService.tableFilter();
      this.dataLength = this.dataSource.filteredData.length;
      this.checkForUpdatedCounts(this.dataSource.filteredData);

    });



    this.portFolioNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.portfolioName = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
    this.platformFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.platformName = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )

    this.workTypeFilter.valueChanges.subscribe(data => {
      this.filterValues.workTypeAB = data;
      this.dataSource.filter = JSON.stringify(this.filterValues);
      this.dataSource.filterPredicate = this.dataTableService.tableFilter();
      this.dataLength = this.dataSource.filteredData.length;
      this.checkForUpdatedCounts(this.dataSource.filteredData);

    });

    this.appCodeFilter.valueChanges.subscribe(data => {
      this.filterValues.appCode = data;
      this.dataSource.filter = JSON.stringify(this.filterValues);
      this.dataSource.filterPredicate = this.dataTableService.tableFilter();
      this.dataLength = this.dataSource.filteredData.length;
      this.checkForUpdatedCounts(this.dataSource.filteredData);

    });



  }

  getMoreInfo(row) {
    sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID, row.portfolioId);
    sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME, row.portfolioName);
    sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID, row.workStreamId);
    sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME, row.workStreamName);
    sessionStorage.setItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID, row.subWorkStreamId);
    sessionStorage.setItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME, row.subWorkStreamName);
    this.dataService.setListingView(WORK_HIERARCHY_CONST.SUB_WORKSTREAM);
    this.dataService.sendMessageItemChange(WORK_HIERARCHY_CONST.SUB_WORKSTREAM);
    this.router.navigateByUrl('home/portfolio/createPortfolio/subworkstream/' + row.subWorkStreamId);

  }

  clear_search() {
    this.searchText = '';
    this.applyFilter(this.searchText);
  }
  scenarioSelected(event) {
    this.scenario = event.value.trim();
    this.getData();
  }
  reportingFlagSelected(event) {
    this.reportingFlag= event.value.trim();
    this.getData();
  }

}
