import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/common/module/shared.module';
import { PortfolioListingComponent } from './portfolio-listing/portfolio-listing.component';
import { PortfolioSideNavComponent } from './sidenav/portfolio-side-nav.component';
import { WorkstreamListingComponent } from './workstream-listing/workstreamlisting.component';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { SubWorkstreamListingComponent } from './subworkstream-listing/subworkstreamlisting.component';
import { PortfolioService } from './portfolio-details/portfolio.service';
import { CopyScenarioDialogComponent } from '../common/component/dialogues/copy-scenario-dialog/copy-scenario-dialog.component';
import { CreateSnapshotComponent } from '../common/component/dialogues/create-snapshot/create-snapshot.component';

const routes: Routes = [
  { path: 'portfoliolisting', component: PortfolioListingComponent },
  { path: 'workstream', component: WorkstreamListingComponent },
  { path: 'subworkstream', component: SubWorkstreamListingComponent },
  {
    path: 'createPortfolio', component: PortfolioSideNavComponent,
    children: [
      {
        path: 'showPortfolio',
        loadChildren: () => import('src/app/portfolio/portfolio-details/portfolio-details-routing.module').then(m => m.PortfolioDetailsRoutingModule)
      },
      { path: 'subworkstream/:subWorkstreamID',
      loadChildren:  () => import('src/app/portfolio/sub-workstream/sub-workstream-routing.module').then(m => m.SubWorkStreamRoutingModule)
      },
      {
        path: 'workstream/:workstreamID',
        loadChildren: () => import('src/app/portfolio/workstream/workstream-routing.module').then(m => m.WorkStreamRoutingModule),
      },
    ],
  },
  {
    path: '',
    redirectTo: 'portfoliolisting',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
  ],
  declarations: [
    PortfolioListingComponent,
    PortfolioSideNavComponent,
    WorkstreamListingComponent,
    SubWorkstreamListingComponent,
    CreateSnapshotComponent,
  ],
  providers: [DateUtility,PortfolioService],
  exports: [],
  entryComponents: []
})

export class PortfolioRoutingModule {
}
