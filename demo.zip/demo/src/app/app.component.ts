import { Component } from '@angular/core';
import { MatomoInjector } from 'ngx-matomo';
import { URL_PREFIX } from 'src/app/common/constants/urlprefix';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Gene';

  constructor(private matomoInjector: MatomoInjector){
    this.matomoInjector.init(URL_PREFIX.MATOMOURL, URL_PREFIX.MATOMOID );
  }
}
