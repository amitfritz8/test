import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/common/service/rest.service';
import { saveAs } from 'file-saver';
import * as moment from 'moment';
import { DataService } from 'src/app/common/service/data.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as Excel from 'exceljs/dist/exceljs.min.js';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { CommonService } from "src/app/common/service/common.service";

@Component({
  selector: 'app-workforce-report',
  templateUrl: './workforce-report.component.html',
  styleUrls: ['./workforce-report.component.scss']
})
export class WorkForceReportComponent implements OnInit {

  months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  YearList: any = [];
  monthList: any = [];
  peopleData: any = [];
  curYear: any;
  curMonth: any;
  bankId: any;
  sortedMonthList: any = [];
  selectedReqData: any;
  selectedYear: any;
  selectedMonth: any;
  selectedToYear: any;
  selectedToMonth: any;
  isarrayPrep: Boolean = false;
  isErrorExists: boolean = false;
  interSelToMonth: any;
  interSelFromMonth: any;
  dateErrorExists: boolean = false;
  respType: any = 'arraybuffer';
  data = [];
  reportsList: any = [];

  // to removed
  emailCtrl = new FormControl("support@dbs.com", Validators.email);

  headCountColumns = [
    'Platform Index',
    'Platform Name',
    'Platform Lead',
    'Tech Unit',
    'Platform Unit',
    'Staff Type',
    'Company Name',
    'Onshore/Offshore',
    'Reporting Location',
    'Work Location',
    'Type of Work 1',
    'Type of Work 2',
    'Budgeted',
    'Period',
    'HC Included',
    'Category',
    'Staff Status',
    'Budget Movt',
    'HC'
  ];

  schedularAuditColumns = [
    'Job Name',
    'Job Desc',
    'Start time',
    'End time',
    'Status',
    'Source count',
    'Target count',
    'Error Log'
  ];

  workdayErrorColumns = [
    '1Bank id',
    'Staff id',
    'As of Date',
    'First Name',
    'Last Name',
    'Staff name',
    'Citizenship',
    'Staff Type',
    'Rank',
    'Hr Role',
    'Staff End Date',
    'Staff Start Date',
    'Reporting Manager',
    'Reporting Manager 1Bank id',
    'Staff Le Pccode',
    'Country Code',
    'Company Name',
    'Gender',
    'Last Working Date',
    'Dept id',
    'Email Address',
    'Staff Status',
    'Work Location',
    'Biz Unit',
    'Dept Name',
    'Preferred Name',
    'Dept1 Division',
    'Location Desc',
    'Biz User Flag',
    'Created By',
    'Date Created',
    'Modified By',
    'Date Modified',
    'Job Function',
    'Rejoin Date',
    'Error',
    'Rank Code',
    'Office Address'
  ];
  employeeColumns = [

    'As Of Date',
    '1BankID',
    'Tech Unit',
    'Staff Last Name',
    'Staff Last Name',
    'Staff Name',
    'Staff Id',
    'Citizenship',
    'Staff Type',
    'Staff Status',
    'Movement Status',
    'Rank',
    'HR Role',
    'Transfer Out Date',
    'DBS Rejoin Date',
    'DBS Start Date',
    'Staff Start Date',
    'Staff End Date',
    'Reporting Manager 1BankID',
    'Reporting Manager Name',
    'Staff PCCode',
    'Billing Type',
    'Funding PCCode',
    'AR PCCode',
    'Individual Contributor',
    'Work Type1',
    'Work Type2',
    'On/Off shore',
    'Country Code',
    'Primary Seating',
    'Company Name',
    'Experience',
    'Gender',
    'Resigned Date',
    'Department ID',
    'Skill Set',
    'Project ID',
    'Application Code',
    'HC Included',
    'Email Address',
    'Platform Lead',
    'Platform Name',
    'Platform Unit',
    'Platform Index',
    'Sub Platform',
    'Reporting Period',
    'Work Location',
    'Seat Location',
    'Floor',
    'Remarks',
    'Department Description',
    'Job Function',
    'Business Unit',
    'Division',
    'Rank Code',
    'Office Address',
    'Needs immediate Action (past 7 days)',
    'No of days since Staff Start Date',
    'Update Expected to be Done By'
  ];
  tribeMasterColumns = ['As of Date',
  'Platform Index',
  'Platform Name',
  'Tribe ID',
  'Tribe Name',
  'Tribe Lead 1Bank ID',
  'Tribe Lead Name',
  'Tribe Lead Delegates 1Bank ID',
  'Tribe Lead Delegates Name',
  'Status',
  'Effective Start Date',
  'Effective End Date'];

  subPlatformMasterColumns = ['As of Date',
    'Platform Index',
    'Platform Name',
    'Sub-Platform ID',

    'Sub-Platform Name',
    'Business Sub-Platform Lead 1Bank ID',
    'Business Sub-Platform Lead Name',
    'Business Sub-Platform Lead Delegates 1Bank ID',

    'Business Sub-Platform Lead Delegates Name',
    'Technology Sub-Platform Lead 1Bank ID',
    'Technology Sub-Platform Lead Name',
    'Technology Sub-Platform Lead Delegates 1Bank ID',

    'Technology Sub-Platform Lead Delegates Name',
    'Status',
    'Effective Start Date',
    'Effective End Date'];

    teamMasterColumns = ['As of Date', 'Tech unit', 'Team Platform Index', 'Team Platform Name', 'Team Platform Leads', 'Team Sub-platform', 'Team Sub-platform ID', 'Team Sub-Platform Leads',
    'Team Tribe Name', 'Team Tribe ID', 'Team Tribe Leads', 'Team ID', 'Team Name', 'Team Type (PCFT/NPCFT)', 'Team Creation Date', 'Team Lead Name', 'Team Lead 1BankID',
    'Team Lead Delegates', 'Team Lead Delegates 1BankID', 'Product Owner', 'Product Owners 1Bank ID', 'Core Team Members', 'Core Team 100% Members',
    'Core Team FTE', 'Core Team Blended Cost', 'Core Team Notional Cost', 'Core Team Chargeable Cost', 'Augmented (IN) Members', 'Augmented (IN) Team 100% Members', 'Augmented (IN) Team  FTE',
    'Augmented (IN) Team Blended Cost', 'Augmented (IN) Team Notional Cost', 'Augmented (IN) Team Chargeable Cost', 'Total Team Planned FTE', 'Total Planned Team Blended Cost',
    'Total Team Members', 'Total Team 100% Members', 'Total Team FTE', 'Total Team Blended Cost', 'Total Team Notional Cost', 'Total Team Chargeable Cost','Status','Effective Start Date','Effective End Date'];

  teamICColumns = ['As Of Date', 'Staff 1BankID', 'Core/Augmented (Out)', 'Staff Tech unit',
    'Staff Name', 'Staff Platform Index', 'Staff Platform', 'Staff Platform Leads', 'Staff Sub-platform ID', 'Staff Sub-platform', 'HC included',
    'Staff LE-PC Code', 'Staff Type', 'Staff Type of Work 1', 'Staff Type of Work 2', 'Staff Work Location',
    'Staff Reporting Location', 'Notional/Chargeable (Staff)', 'Staff Rate Card (per day)', 'Staff Blended  Cost/Day', 'Team ID', 'Team Name',
    'Team Type(PCFT/NPCFT)', 'Capacity (100%)', 'Team Role', 'Team Lead 1BankID', 'Team Lead',
    'Team Lead Delegates 1BankID', 'Team Lead Delegate(s)', 'Product Owner', 'Product Owner 1Bank ID', 'Team Platform Index', 'Team Platform Name',
    'Team Tech Platform Leads', 'Team  Sub-Platform ID', 'Team  Sub-Platform Name', 'Team Tech Sub-Platform Leads',
    'Team Tribe ID', 'Team Tribe Name', 'Team Tribe Lead(s)', 'Effective Start Date', 'Effective End Date'];

  summary = [
    'Tech Unit',
    'Platform Index',
    'Platform Name',
    'Reporting Manager Name',
    'Reporting Manager One BankId',
    'Staff Name',
    'Staff Id',
    'Staff Start Date',
    'Reporting Period',
    'Missing Type of Work 1',
    'Missing Type Of Work 2',
    'Missing Sub Platform',
    'Needs immediate Action (past 7 days)',
    'No of days since Staff Start Date',
    'Update Expected to be Done By'

  ];

  form: FormGroup;
  private errorMessageForDate: any;


  constructor(private http: HttpClient, private restService: RestService,
    private dataService: DataService, private fb: FormBuilder,
    private dateUtility: DateUtility, private commonService: CommonService) {
    this.commonService.setDocumentTitle('WORKFORCE REPORTS');
    this.commonService.trackPageView();
  }

  ngOnInit() {
    this.form = this.fb.group({
      startingDate: [new Date(), [Validators.required]],
      endingDate: [new Date(), [Validators.required]],
    });
    this.curYear = moment(new Date()).format('YYYY');
    this.curMonth = moment(new Date()).format('MM');
    this.YearList = [];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    var reports = localStorage.getItem('roleListValues');
    if (reports !== null || reports !== '') {
      this.reportsList = reports.split(",");
      this.reportsList.forEach(report => {
        if (report === 'RPT_ALL_STAFF_LIST') {
          this.peopleData.push({ value: report, display: 'All Staff List' });
        } else if (report === 'RPT_TOTAL_HEADCOUNT') {
          this.peopleData.push({ value: report, display: 'Total Head Count' });
        } else if (report === 'RPT_TEAM_MEMBER_DETAILS') {
          this.peopleData.push({ value: report, display: 'All Team Member List' });
        } else if (report === 'RPT_HEAD_COUNT_FINANCE') {
          this.peopleData.push({ value: report, display: 'Total Headcount - Finance' });
        } else if (report === 'RPT_PEOPLE_MOVEMENTS') {
          this.peopleData.push({ value: report, display: 'Perm Staff Movement' });
        } else if (report === 'RPT_SCHEDULER_AUDIT_LOG') {
          this.peopleData.push({ value: report, display: 'Tech Support - Scheduler Audit Log' });
        } else if (report === 'RPT_WORKDAY_ERROR_LOG') {
          this.peopleData.push({ value: report, display: 'Tech Support - Workday Error log' });
        } else if (report === 'RPT_MISSING_DATA') {
          this.peopleData.push({ value: report, display: 'Incomplete Staff Data' });
        } else if (report === 'RPT_TRIBE_MASTER') {
          this.peopleData.push({ value: report, display: 'Tribe Master list' });
        } else if (report === 'RPT_SUB_PLATFORM_MASTER') {
          this.peopleData.push({ value: report, display: 'Sub-Platform list' });
        } else if (report === 'RPT_TEAM_MASTER') {
          this.peopleData.push({ value: report, display: 'All Team Master list' });
        }
        else if (report === 'RPT_TEAM_Team_IC_Mapping') {
          this.peopleData.push({ value: report, display: 'Team/IC Mapping list' });
        }
      });
      this.peopleData.sort((a, b) => {
        if (a['display'] > b['display']) return 1;
        if (a['display'] < b['display']) return -1;
        return 0;
      });
    }
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_ERR_DATECHK_FROM_TO`).subscribe(result => {
      this.errorMessageForDate = result['message'];
    });
    this.YearList = [{ key: '1', value: this.curYear }, { key: '2', value: this.curYear - 1 }];
    months.forEach((e, index) => {
      this.monthList.push({ key: index + 1, value: e });
    });
    this.selectedYear = this.curYear;
    this.selectedReqData = this.peopleData[0].value;
    this.selectedMonth = this.monthList[this.curMonth - 1].value;
    var i = 0;
    var j;
    for (j = this.curMonth - 1; j => 0; j--) {
      this.sortedMonthList[i] = this.monthList[j].value;
      i++;
      if (j === 0) {
        for (j = this.monthList.length - 1; j > this.curMonth - 1; j--) {
          this.sortedMonthList[i] = this.monthList[j].value;
          i++;
          if (i === this.monthList.length) {
            this.isarrayPrep = true;
            break;
          }
        }
        if (this.isarrayPrep === true || this.sortedMonthList.length === 12 || i >= 12) {
          break;
        }
      }

    }
  }

  downloadFile() {
    this.isErrorExists = false;
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    this.resetParams();
    this.bankId = JSON.parse(localStorage.getItem('userinfo')).username;
    this.commonService.trackEvent("DOWNLOAD WORKFORCE REPORT", "DOWNLOAD", this.selectedReqData, 1);
    if (this.selectedReqData === 'RPT_ALL_STAFF_LIST' || this.selectedReqData === 'RPT_TEAM_MEMBER_DETAILS'
      || this.selectedReqData === 'RPT_HEAD_COUNT_FINANCE' || this.selectedReqData === 'RPT_PEOPLE_MOVEMENTS') {
      this.dataService.loaderHandler(true);
      this.http.post(`/people/data/report/empdata?requestedData=${this.selectedReqData}&fromYear=${this.selectedYear}
      &fromMonth=${this.selectedMonth}&toYear=${this.selectedToYear}&toMonth=${this.selectedToMonth}&bankId=${this.bankId}`,
        { techUnits: lobts, platforms: platforms, location: locations }, {
        headers: new HttpHeaders({ 'Authorization': 'Bearer ' + localStorage.getItem('access_token') }),
        responseType: this.respType
      }).subscribe(res => {
        this.dataService.loaderHandler(false);
        if (!this.dateErrorExists) {
          if ((<any>res)._body !== '') {
            if ('RPT_HEAD_COUNT_FINANCE' === this.selectedReqData) {
              saveAs(new Blob([res], { type: '' }), 'Total Headcount - Finance' + '_' + this.selectedYear + '.xlsx');
            } else if ('RPT_TOTAL_HEADCOUNT' === this.selectedReqData || 'RPT_PEOPLE_MOVEMENTS' === this.selectedReqData) {
              saveAs(new Blob([res], { type: '' }), 'From' + this.selectedYear + this.selectedMonth + 'To' + this.selectedToYear + this.selectedToMonth + '_' + this.selectedReqData + '.xlsx');
            } else {
              saveAs(new Blob([res], { type: '' }), this.selectedYear + this.selectedMonth + '_' + this.selectedReqData + '.xlsx');
            }
            this.isErrorExists = true;
            this.commonService.showSnackBar({
              type: 'success',
              message: 'Data Exported Successfully'
            });
            this.dataService.getFlag('0');
          }
        } else {
          this.isErrorExists = true;
          this.commonService.showSnackBar({
            type: 'alert',
            message: res['message']
          });
          this.dataService.getFlag(res['errorFlag']);
        }
      });
    } else if (this.selectedReqData === 'RPT_WORKDAY_ERROR_LOG') {
      this.getErrorWorkdayData();
    } else if (this.selectedReqData === 'RPT_SCHEDULER_AUDIT_LOG') {
      this.getSchedularAuditData();
    } else if (this.selectedReqData === 'RPT_TOTAL_HEADCOUNT') {
      this.getTotalHeadCountData();
    } else if (this.selectedReqData === 'RPT_TEAM_Team_IC_Mapping') {
      this.getTeamICData();
    } else if (this.selectedReqData === 'RPT_MISSING_DATA') {
      if (!this.dateErrorExists) {
        this.getIncompleteData();
      } else {
        this.dataService.loaderHandler(false);
        this.isErrorExists = true;
        this.commonService.showSnackBar({
          type: 'alert',
          message: this.dataService.getCustomMessage(this.errorMessageForDate)
        });
        this.dataService.getFlag('1');
      }
    } else if (this.selectedReqData === 'RPT_TRIBE_MASTER') {
      if (!this.dateErrorExists) {
        this.getTribeMasterData();
      } else {
        this.dataService.loaderHandler(false);
        this.isErrorExists = true;
        this.commonService.showSnackBar({
          type: 'alert',
          message: this.dataService.getCustomMessage(this.errorMessageForDate)
        });
        this.dataService.getFlag('1');
      }
    } else if (this.selectedReqData === 'RPT_SUB_PLATFORM_MASTER') {
      if (!this.dateErrorExists) {
        this.getSubPlatformMasterData();
      } else {
        this.dataService.loaderHandler(false);
        this.isErrorExists = true;
        this.commonService.showSnackBar({
          type: 'alert',
          message: this.dataService.getCustomMessage(this.errorMessageForDate)
        });
        this.dataService.getFlag('1');
      }
    } else if (this.selectedReqData === 'RPT_TEAM_MASTER') {
      if (!this.dateErrorExists) {
        this.getTeamMasterData();
      } else {
        this.dataService.loaderHandler(false);
        this.isErrorExists = true;
        this.commonService.showSnackBar({
          type: 'alert',
          message: this.dataService.getCustomMessage(this.errorMessageForDate)
        });
        this.dataService.getFlag('1');
      }
    }
  }

  getTotalHeadCountData() {
    this.dataService.loaderHandler(true);
    this.isErrorExists = false;
    this.bankId = JSON.parse(localStorage.getItem('userinfo')).username;
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    this.resetParams();
    this.restService.post(`/people/data/report/empdata/headcountData?fromYear=${this.selectedYear}
    &fromMonth=${this.selectedMonth}&toYear=${this.selectedToYear}&toMonth=${this.selectedToMonth}
    &bankId=${this.bankId}`,
      { techUnits: lobts, platforms: platforms, location: locations }).subscribe(res => {
        let elementData = [];
        this.data = res;

        this.data.forEach((emp) => {
          elementData.push([
            emp.platformIndex,
            emp.platFormName,
            emp.platFormLead,
            emp.techUnit,
            emp.platFromUnit,
            emp.staffType,
            emp.companyName,
            emp.onOffshore,
            emp.countyCode,
            emp.workLocation,
            emp.workType1,
            emp.workType2,
            emp.budgetInd,
            emp.period,
            emp.tacoInd,
            emp.category,
            emp.staffStatus,
            emp.budgetMovt,
            emp.hcBudget]);
        });


        let EXCEL_EXTENSION = '.xlsx';
        let workbook = new Excel.Workbook();
        let worksheet = workbook.addWorksheet('Total HeadCount');
        let headerRow = worksheet.addRow(this.headCountColumns);

        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: 'FF0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        worksheet.getCell('A1').font = { size: 12, bold: true };
        worksheet.getCell('B1').font = { size: 12, bold: true };
        worksheet.getCell('C1').font = { size: 12, bold: true };
        worksheet.getCell('D1').font = { size: 12, bold: true };
        worksheet.getCell('E1').font = { size: 12, bold: true };
        worksheet.getCell('F1').font = { size: 12, bold: true };
        worksheet.getCell('G1').font = { size: 12, bold: true };
        worksheet.getCell('H1').font = { size: 12, bold: true };
        worksheet.getCell('I1').font = { size: 12, bold: true };
        worksheet.getCell('J1').font = { size: 12, bold: true };
        worksheet.getCell('K1').font = { size: 12, bold: true };
        worksheet.getCell('L1').font = { size: 12, bold: true };
        worksheet.getCell('M1').font = { size: 12, bold: true };
        worksheet.getCell('N1').font = { size: 12, bold: true };
        worksheet.getCell('O1').font = { size: 12, bold: true };
        worksheet.getCell('P1').font = { size: 12, bold: true };
        worksheet.getCell('Q1').font = { size: 12, bold: true };
        worksheet.getCell('R1').font = { size: 12, bold: true };
        worksheet.getCell('S1').font = { size: 12, bold: true };

        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'HeadCount Details' + EXCEL_EXTENSION);
        });
        this.dataService.loaderHandler(false);

      });
  }
  
  getTeamICData() {
    this.dataService.loaderHandler(true);
    this.isErrorExists = false;
    this.bankId = JSON.parse(localStorage.getItem('userinfo')).username;
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    this.resetParams();
    this.restService.post(`/people/data/report/empdata/teamICData?fromYear=${this.selectedYear}
    &fromMonth=${this.selectedMonth}&toYear=${this.selectedToYear}&toMonth=${this.selectedToMonth}&bankId=${this.bankId}`,
      { techUnits: lobts, platforms: platforms, location: locations }).subscribe(res => {
        let elementData = [];
        this.data = res;

        this.data.forEach((emp) => {
          elementData.push([
            this.dateUtility.dateToDateTimeString(emp.asOfDate),
            emp.oneBankId,
            emp.coreAugmented,
            emp.techUnit,
            emp.staffName,
            emp.platformIndex,
            emp.platformName,
            emp.platformLeadName,
            emp.subPlatformId,
            emp.subPlatformName,
            emp.hcIncluded,
            emp.staffLEPCCode,
            emp.staffType,
            emp.staffTypeOfWork1,
            emp.staffTypeOfWork2,
            emp.staffWorkLocation,
            emp.reportingLocation,
            "",
            emp.staffRate,
            emp.staffBlendedCost,
            emp.teamId,
            emp.teamName,
            emp.teamType,
            emp.allocationPercentage,
            emp.teamRole,
            emp.teamLeadOneBankId,
            emp.teamLeadName,
            emp.teamDelegateOneBankId,
            emp.teamDelegateName,
            emp.productOwner,
            emp.productOwnerOneBankId,
            emp.teamPlatformIndex,
            emp.teamPlatformName,
            emp.teamTechPlatformLead,
            emp.teamSubPlatformId,
            emp.teamSubPlatformName,
            emp.teamTechSubPlatformLead,
            emp.teamTribeId,
            emp.teamTribeName,
            emp.teamTribeLead,
            this.dateUtility.dateToDateTimeString(emp.effectiveStartDate),
            this.dateUtility.dateToDateTimeString(emp.effectiveEndDate)]);
        });


        let EXCEL_EXTENSION = '.xlsx';
        let workbook = new Excel.Workbook();
        let worksheet = workbook.addWorksheet('Team IC Details');
        let headerRow = worksheet.addRow(this.teamICColumns);

        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: 'FF0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        worksheet.getCell('A1').font = { size: 12, bold: true };
        worksheet.getCell('B1').font = { size: 12, bold: true };
        worksheet.getCell('C1').font = { size: 12, bold: true };
        worksheet.getCell('D1').font = { size: 12, bold: true };
        worksheet.getCell('E1').font = { size: 12, bold: true };
        worksheet.getCell('F1').font = { size: 12, bold: true };
        worksheet.getCell('G1').font = { size: 12, bold: true };
        worksheet.getCell('H1').font = { size: 12, bold: true };
        worksheet.getCell('I1').font = { size: 12, bold: true };
        worksheet.getCell('J1').font = { size: 12, bold: true };
        worksheet.getCell('K1').font = { size: 12, bold: true };
        worksheet.getCell('L1').font = { size: 12, bold: true };
        worksheet.getCell('M1').font = { size: 12, bold: true };
        worksheet.getCell('N1').font = { size: 12, bold: true };
        worksheet.getCell('O1').font = { size: 12, bold: true };
        worksheet.getCell('P1').font = { size: 12, bold: true };
        worksheet.getCell('Q1').font = { size: 12, bold: true };
        worksheet.getCell('R1').font = { size: 12, bold: true };
        worksheet.getCell('S1').font = { size: 12, bold: true };
		    worksheet.getCell('T1').font = { size: 12, bold: true };
		    worksheet.getCell('U1').font = { size: 12, bold: true };
		    worksheet.getCell('V1').font = { size: 12, bold: true };
		    worksheet.getCell('W1').font = { size: 12, bold: true };
		    worksheet.getCell('X1').font = { size: 12, bold: true };
		    worksheet.getCell('Y1').font = { size: 12, bold: true };
		    worksheet.getCell('Z1').font = { size: 12, bold: true };
		    worksheet.getCell('AA1').font = { size: 12, bold: true };
        worksheet.getCell('AB1').font = { size: 12, bold: true };
        worksheet.getCell('AC1').font = { size: 12, bold: true };
        worksheet.getCell('AD1').font = { size: 12, bold: true };
        worksheet.getCell('AE1').font = { size: 12, bold: true };
        worksheet.getCell('AF1').font = { size: 12, bold: true };
        worksheet.getCell('AG1').font = { size: 12, bold: true };
        worksheet.getCell('AH1').font = { size: 12, bold: true };
        worksheet.getCell('AI1').font = { size: 12, bold: true };
        worksheet.getCell('AJ1').font = { size: 12, bold: true };
		    worksheet.getCell('AK1').font = { size: 12, bold: true };
        worksheet.getCell('AL1').font = { size: 12, bold: true };
        worksheet.getCell('AM1').font = { size: 12, bold: true };
        worksheet.getCell('AN1').font = { size: 12, bold: true };
        worksheet.getCell('AO1').font = { size: 12, bold: true };
        worksheet.getCell('AP1').font = { size: 12, bold: true };

        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Team IC Details' + EXCEL_EXTENSION);
        });
        this.dataService.loaderHandler(false);

      });
  }

  ReqDataSelected(e) {
    this.selectedReqData = e.value;
    if (this.selectedReqData === 'RPT_TOTAL_HEADCOUNT' || this.selectedReqData === 'RPT_PEOPLE_MOVEMENTS' || this.selectedReqData === 'RPT_MISSING_DATA') {
      this.selectedToYear = (this.selectedToYear === undefined || this.selectedToYear === '') ? this.selectedYear : this.selectedToYear;
      this.selectedToMonth = (this.selectedToMonth === undefined || this.selectedToMonth === '') ? this.selectedMonth : this.selectedToMonth;
    }
  }

  YearSelected(e) {
    this.selectedYear = e.value;
  }

  MonthSelected(e) {
    this.selectedMonth = e.value;
  }

  toYearSelected(e) {
    this.selectedToYear = e.value;
  }

  toMonthSelected(e) {
    this.selectedToMonth = e.value;
  }

  isValidDate() {
    if (this.selectedReqData === 'RPT_TOTAL_HEADCOUNT' || this.selectedReqData === 'RPT_PEOPLE_MOVEMENTS' || this.selectedReqData === 'RPT_MISSING_DATA') {
      this.monthList.forEach(element => {
        if (element['value'] == this.selectedToMonth) {
          this.interSelToMonth = element['key'];
        }
        if (element['value'] == this.selectedMonth) {
          this.interSelFromMonth = element['key'];
        }
      });
      if (this.selectedYear <= this.selectedToYear) {
        if (this.selectedYear < this.selectedToYear) {
          this.dateErrorExists = false;
          this.respType = 'arraybuffer';
        } else if (this.interSelFromMonth <= this.interSelToMonth) {
          this.dateErrorExists = false;
          this.respType = 'arraybuffer';
        } else if (this.interSelFromMonth > this.interSelToMonth) {
          this.dateErrorExists = true;
          this.respType = '';
        }
      } else {
        this.dateErrorExists = true;
        this.respType = '';
      }
    } else if (this.selectedReqData === 'RPT_HEAD_COUNT_FINANCE' || this.selectedReqData === 'RPT_ALL_STAFF_LIST' || this.selectedReqData === 'RPT_TEAM_MEMBER_DETAILS') {
      this.respType = 'arraybuffer';
    }
  }

  resetParams() {
    if (this.selectedReqData === 'RPT_HEAD_COUNT_FINANCE') {
      this.selectedMonth = '';
      this.selectedToMonth = '';
      this.selectedToYear = '';
    } else if (this.selectedReqData === 'RPT_ALL_STAFF_LIST') {
      this.selectedToMonth = '';
      this.selectedToYear = '';
    } else if (this.selectedReqData === 'RPT_TEAM_MEMBER_DETAILS') {
      this.selectedToMonth = '';
      this.selectedToYear = '';
    }
  }

  getSchedularAuditData() {

    let startDate = this.dateUtility.datetoReportDateString(this.form.controls.startingDate.value);
    let endDate = this.dateUtility.datetoReportDateString(this.form.controls.endingDate.value);
    if (this.form.controls.endingDate.value < this.form.controls.startingDate.value) {
      this.dataService.loaderHandler(false);
      this.isErrorExists = true;
      this.commonService.showSnackBar({
        type: 'alert',
        message: this.dataService.getCustomMessage(this.errorMessageForDate)
      });
      this.dataService.getFlag('1');
    }
    else {
      this.restService.get(`/people/data/report/schedulerAuditReport?fromDate=${startDate}&toDate=${endDate}`).subscribe(data => {
        let elementData = [];
        data.forEach(ele => {
          elementData.push([
            ele.jobName,
            ele.jobDesc,
            this.dateUtility.dateToDateTimeString(ele.jobStartedTime),
            this.dateUtility.dateToDateTimeString(ele.jobEndedTime),
            ele.status,
            ele.sourceCount,
            ele.targetCount,
            ele.errorLog
          ]);
        });

        let EXCEL_EXTENSION = '.xlsx';
        let workbook = new Excel.Workbook();
        const worksheet = workbook.addWorksheet('Scheduler Audit Log');
        let headerRow = worksheet.addRow(this.schedularAuditColumns);

        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: 'FF0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        worksheet.getCell('A1').font = { size: 12, bold: true };
        worksheet.getCell('B1').font = { size: 12, bold: true };
        worksheet.getCell('C1').font = { size: 12, bold: true };
        worksheet.getCell('D1').font = { size: 12, bold: true };
        worksheet.getCell('E1').font = { size: 12, bold: true };
        worksheet.getCell('F1').font = { size: 12, bold: true };
        worksheet.getCell('G1').font = { size: 12, bold: true };
        worksheet.getCell('H1').font = { size: 12, bold: true };


        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Tech Support - Scheduler Audit Log' + EXCEL_EXTENSION);
        });
        this.dataService.loaderHandler(false);
      });
    }
  }

  getErrorWorkdayData() {

    let startDate = this.dateUtility.datetoReportDateString(this.form.controls.startingDate.value);
    let endDate = this.dateUtility.datetoReportDateString(this.form.controls.endingDate.value);
    if (this.form.controls.endingDate.value < this.form.controls.startingDate.value) {
      this.dataService.loaderHandler(false);
      this.isErrorExists = true;
      this.commonService.showSnackBar({
        type: 'alert',
        message: this.dataService.getCustomMessage(this.errorMessageForDate)
      });
      this.dataService.getFlag('1');
    }
    else {
      this.restService.get(`/people/data/report/workdayErrorReport?fromDate=${startDate}&toDate=${endDate}`).subscribe(data => {
        let elementData = [];
        data.forEach(ele => {
          elementData.push([
            ele.bankId,
            ele.staffId,
            this.dateUtility.dateToDateTimeString(ele.asOfDate),
            ele.firstName,
            ele.lastName,
            ele.staffName,
            ele.citizenship,
            ele.staffType,
            ele.rank,
            ele.hrRole,
            ele.staffEndDate,
            ele.staffStartDate,
            ele.rptMgr,
            ele.rptMgr1BankId,
            ele.staffLePccode,
            ele.countryCode,
            ele.companyName,
            ele.gender,
            ele.lastWorkingDate,
            ele.deptId,
            ele.emailAddress,
            ele.staffStatus,
            ele.workLocation,
            ele.bizUnit,
            ele.deptName,
            ele.preferredName,
            ele.dept1Division,
            ele.locationDesc,
            ele.bizUserFlag,
            ele.createdby,
            this.dateUtility.dateToDateTimeString(ele.dateCreated),
            ele.modifiedBy,
            this.dateUtility.dateToDateTimeString(ele.dateModified),
            ele.jobFunction,
            ele.rejoinDate,
            ele.error,
            ele.rankCode,
            ele.officeAddress
          ]);
        });

        let EXCEL_EXTENSION = '.xlsx';
        let workbook = new Excel.Workbook();
        const worksheet = workbook.addWorksheet('Workday Error log');
        let headerRow = worksheet.addRow(this.workdayErrorColumns);

        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: 'FF0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        worksheet.getCell('A1').font = { size: 12, bold: true };
        worksheet.getCell('B1').font = { size: 12, bold: true };
        worksheet.getCell('C1').font = { size: 12, bold: true };
        worksheet.getCell('D1').font = { size: 12, bold: true };
        worksheet.getCell('E1').font = { size: 12, bold: true };
        worksheet.getCell('F1').font = { size: 12, bold: true };
        worksheet.getCell('G1').font = { size: 12, bold: true };
        worksheet.getCell('H1').font = { size: 12, bold: true };
        worksheet.getCell('I1').font = { size: 12, bold: true };
        worksheet.getCell('J1').font = { size: 12, bold: true };
        worksheet.getCell('K1').font = { size: 12, bold: true };
        worksheet.getCell('L1').font = { size: 12, bold: true };
        worksheet.getCell('M1').font = { size: 12, bold: true };
        worksheet.getCell('N1').font = { size: 12, bold: true };
        worksheet.getCell('O1').font = { size: 12, bold: true };
        worksheet.getCell('P1').font = { size: 12, bold: true };
        worksheet.getCell('Q1').font = { size: 12, bold: true };
        worksheet.getCell('R1').font = { size: 12, bold: true };
        worksheet.getCell('S1').font = { size: 12, bold: true };
        worksheet.getCell('T1').font = { size: 12, bold: true };
        worksheet.getCell('U1').font = { size: 12, bold: true };
        worksheet.getCell('V1').font = { size: 12, bold: true };
        worksheet.getCell('W1').font = { size: 12, bold: true };
        worksheet.getCell('X1').font = { size: 12, bold: true };
        worksheet.getCell('Y1').font = { size: 12, bold: true };
        worksheet.getCell('Z1').font = { size: 12, bold: true };
        worksheet.getCell('AA1').font = { size: 12, bold: true };
        worksheet.getCell('AB1').font = { size: 12, bold: true };
        worksheet.getCell('AC1').font = { size: 12, bold: true };
        worksheet.getCell('AD1').font = { size: 12, bold: true };
        worksheet.getCell('AE1').font = { size: 12, bold: true };
        worksheet.getCell('AF1').font = { size: 12, bold: true };
        worksheet.getCell('AG1').font = { size: 12, bold: true };
        worksheet.getCell('AH1').font = { size: 12, bold: true };
        worksheet.getCell('AI1').font = { size: 12, bold: true };
        worksheet.getCell('AJ1').font = { size: 12, bold: true };
        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Tech Support - Workday Error log' + EXCEL_EXTENSION);
        });
        this.dataService.loaderHandler(false);
      });
    }
  }

  getIncompleteData() {
    this.dataService.loaderHandler(true);
    let userOneBankId = JSON.parse(localStorage.getItem('userinfo')).username;
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    let gracePeriod: any;
    let editWindowPeriod: any;
    let todayDate = new Date();
    let pcCode='';
    this.restService.get(`/people/data/dataValues/sys-config?msgKey=New Staff Grace Period (Days)`).subscribe(result => {
      gracePeriod = result['message'];
    });
    this.restService.get(`/people/data/dataValues/sys-config?msgKey=People Edit Window - Previous Month`).subscribe(result => {
     editWindowPeriod = result['message'];
    });
    this.restService.post(`/people/data/report/incompleteStaffData?fromYear=${this.selectedYear}
    &fromMonth=${this.selectedMonth}&toYear=${this.selectedToYear}&toMonth=${this.selectedToMonth}
    &bankId=${userOneBankId}`,
      { techUnits: lobts, platforms: platforms, location: locations }).subscribe(res => {
        let employee = [];
        let employeeSummary = [];
        if (res) {
          res.forEach(ele => {
            var afterAddingGracePeriod = new Date(ele['staffStartDate']);
            afterAddingGracePeriod.setDate(afterAddingGracePeriod.getDate() + parseInt(gracePeriod));
            ele.diff = Math.abs(moment(todayDate).diff(ele['staffStartDate'], 'days'));
            let rptPeriod = ele.reportPeriod.slice(0,4) + '-' + ele.reportPeriod.slice(-2) + '-' + editWindowPeriod;
            let dateForEditWindow=new Date(rptPeriod);
            dateForEditWindow.setMonth(dateForEditWindow.getMonth()+1);
            ele.lastdateToUpdate = moment(dateForEditWindow).format('YYYY-MM-DD');
            if (todayDate.getTime() > afterAddingGracePeriod.getTime()) {
              ele.immediate = 'Yes';
            }
            else {
              ele.immediate = 'No';
            }
            if (!ele.workType1)
              ele.workType1New = 'YES';
            else ele.workType1New = 'NO';
            if (!ele.workType2)
              ele.workType2New = 'YES';
            else ele.workType2New = 'NO';
            if (!ele.subPlatform)
              ele.subPlatformNew = 'YES';
            else ele.subPlatformNew = 'NO';
            if(ele.staffType == 'SEED')
            {
              pcCode=ele.seedSatffPccode;
            }
            else{
              pcCode=ele.staffPccode;
            }
            employee.push([
              ele.asOfDate,
              ele.oneBankId,
              ele.techUnit,
              ele.staffFirstName,
              ele.staffLastName,
              ele.staffName,
              ele.staffId,
              '',
              ele.staffType,
              ele.staffStatus,
              ele.movementStatus,
              ele.rank,
              ele.hrRole,
              ele.transferOutDate,
              ele.dbsRejoinDate,
              ele.dbsStartDate,
              ele.staffStartDate,
              ele.staffEndDate,
              ele.rptMgr1BankId,
              ele.rptMgrName,
              pcCode,
              ele.billingType,
              ele.fundingPccode,
              ele.arPccode,
              ele.indvContributor,
              ele.workType1,
              ele.workType2,
              ele.onOffshore,
              ele.countryCode,
              ele.primarySeating,
              ele.companyName,
              ele.experience,
              '',
              ele.resignedDate,
              ele.deptId,
              ele.skillset,
              ele.projectId,
              ele.appCode,
              ele.tacoInd,
              ele.emailAddress,
              ele.platformLead,
              ele.platformName,
              ele.platformUnit,
              ele.platformIndex,
              ele.subPlatform,
              ele.reportPeriod,
              ele.workLocation,
              ele.seatLocation,
              ele.floor,
              ele.remarks,
              ele.deptDesc,
              ele.jobFunc,
              ele.businessUnit,
              ele.divison,
              ele.rankCode,
              ele.officeAddress,
              ele.immediate,
              ele.diff,
              ele.lastdateToUpdate
            ]);
            employeeSummary.push([
              ele.techUnit,
              ele.platformName,
              ele.platformIndex,
              ele.rptMgrName,
              ele.rptMgr1BankId,
              ele.staffName,
              ele.staffId,
              ele.staffStartDate,
              ele.reportPeriod,
              ele.workType1New,
              ele.workType2New,
              ele.subPlatformNew,
              ele.immediate,
              ele.diff,
              ele.lastdateToUpdate
            ]);

          });
        }
        // index of immediate property is 55 in arrayList
        employee.sort((a, b) => {
          if (a['56'].toUpperCase() > b['56'].toUpperCase()) return -1;
          else if (a['56'].toUpperCase() < b['56'].toUpperCase()) return 1;
          if (a['2'].toUpperCase() > b['2'].toUpperCase()) return 1;
          else if (a['2'].toUpperCase() < b['2'].toUpperCase()) return -1;
          if (a['43'] > b['43']) return 1;
          else if (a['43'] < b['43']) return -1;
          if (a['18'] > b['18']) return 1;
          else if (a['18'] < b['18']) return -1;
          return 0;
        }
        );
        employeeSummary.sort((a, b) => {
          if (a['11'].toUpperCase() > b['11'].toUpperCase()) return -1;
          else if (a['11'].toUpperCase() < b['11'].toUpperCase()) return 1;
          if (a['0'].toUpperCase() > b['0'].toUpperCase()) return 1;
          else if (a['0'].toUpperCase() < b['0'].toUpperCase()) return -1;
          if (a['2'] > b['2']) return 1;
          else if (a['2'] < b['2']) return -1;
          if (a['4'] > b['4']) return 1;
          else if (a['4'] < b['4']) return -1;
          return 0;
        }
        );
        let EXCEL_EXTENSION = '.xlsx';
        let workbook = new Excel.Workbook();
      const worksheet1 = workbook.addWorksheet('Summary');
      const headerRow1 = worksheet1.addRow(this.summary);
      headerRow1.eachCell((cell, number) => {
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFFFFFFF' },
          bgColor: { argb: 'FF0000FF' }
        }
        cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
      });
      worksheet1.autoFilter = 'A1:O1';
      worksheet1.getCell('A1').font = { size: 12, bold: true };
      worksheet1.getCell('B1').font = { size: 12, bold: true };
      worksheet1.getCell('C1').font = { size: 12, bold: true };
      worksheet1.getCell('D1').font = { size: 12, bold: true };
      worksheet1.getCell('E1').font = { size: 12, bold: true };
      worksheet1.getCell('F1').font = { size: 12, bold: true };
      worksheet1.getCell('G1').font = { size: 12, bold: true };
      worksheet1.getCell('H1').font = { size: 12, bold: true };
      worksheet1.getCell('I1').font = { size: 12, bold: true };
      worksheet1.getCell('J1').font = { size: 12, bold: true };
      worksheet1.getCell('K1').font = { size: 12, bold: true };
      worksheet1.getCell('L1').font = { size: 12, bold: true };
      worksheet1.getCell('M1').font = { size: 12, bold: true };
      worksheet1.getCell('N1').font = { size: 12, bold: true };
      worksheet1.getCell('O1').font = { size: 12, bold: true };
      worksheet1.addRows(employeeSummary);
      worksheet1.eachRow(function (row, rowNumber) {
        row.eachCell(function (cell, colNumber) {
          if (cell.value && row.getCell(colNumber).col == 13 && cell.value == 'Yes') {
            cell.fill = {
              type: 'pattern',
              pattern: 'solid',
              bgColor: { argb: 'FF0000' },
              fgColor: { argb: 'FF0000' }
            };
            cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
          }
        });
      });
      worksheet1.columns = [
        { key: 'A', width: 15 }, { key: 'B', width: 15 }, { key: 'C', width: 15 }, { key: 'D', width: 15 }, { key: 'E', width: 15 }, { key: 'F', width: 15 },
        { key: 'G', width: 15 }, { key: 'H', width: 15 }, { key: 'I', width: 20 }, { key: 'J', width: 20 }, { key: 'K', width: 20 }, { key: 'L', width: 30 },
        { key: 'M', width: 30 }, { key: 'N', width: 30 },{ key: 'O', width: 30 }
      ];
        const worksheet = workbook.addWorksheet('Details');
        let headerRow = worksheet.addRow(this.employeeColumns);
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgColor: { argb: 'FF0000FF' }
          }
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        worksheet.autoFilter = 'A1:BG1';
        worksheet.getCell('A1').font = { size: 12, bold: true };
        worksheet.getCell('B1').font = { size: 12, bold: true };
        worksheet.getCell('C1').font = { size: 12, bold: true };
        worksheet.getCell('D1').font = { size: 12, bold: true };
        worksheet.getCell('E1').font = { size: 12, bold: true };
        worksheet.getCell('F1').font = { size: 12, bold: true };
        worksheet.getCell('G1').font = { size: 12, bold: true };
        worksheet.getCell('H1').font = { size: 12, bold: true };
        worksheet.getCell('I1').font = { size: 12, bold: true };
        worksheet.getCell('J1').font = { size: 12, bold: true };
        worksheet.getCell('K1').font = { size: 12, bold: true };
        worksheet.getCell('L1').font = { size: 12, bold: true };
        worksheet.getCell('M1').font = { size: 12, bold: true };
        worksheet.getCell('N1').font = { size: 12, bold: true };
        worksheet.getCell('O1').font = { size: 12, bold: true };
        worksheet.getCell('P1').font = { size: 12, bold: true };
        worksheet.getCell('Q1').font = { size: 12, bold: true };
        worksheet.getCell('R1').font = { size: 12, bold: true };
        worksheet.getCell('S1').font = { size: 12, bold: true };
        worksheet.getCell('T1').font = { size: 12, bold: true };
        worksheet.getCell('U1').font = { size: 12, bold: true };
        worksheet.getCell('V1').font = { size: 12, bold: true };
        worksheet.getCell('W1').font = { size: 12, bold: true };
        worksheet.getCell('X1').font = { size: 12, bold: true };
        worksheet.getCell('Y1').font = { size: 12, bold: true };
        worksheet.getCell('Z1').font = { size: 12, bold: true };
        worksheet.getCell('AA1').font = { size: 12, bold: true };
        worksheet.getCell('AB1').font = { size: 12, bold: true };
        worksheet.getCell('AC1').font = { size: 12, bold: true };
        worksheet.getCell('AD1').font = { size: 12, bold: true };
        worksheet.getCell('AE1').font = { size: 12, bold: true };
        worksheet.getCell('AF1').font = { size: 12, bold: true };
        worksheet.getCell('AG1').font = { size: 12, bold: true };
        worksheet.getCell('AH1').font = { size: 12, bold: true };
        worksheet.getCell('AI1').font = { size: 12, bold: true };
        worksheet.getCell('AJ1').font = { size: 12, bold: true };
        worksheet.getCell('AK1').font = { size: 12, bold: true };
        worksheet.getCell('AL1').font = { size: 12, bold: true };
        worksheet.getCell('AM1').font = { size: 12, bold: true };
        worksheet.getCell('AN1').font = { size: 12, bold: true };
        worksheet.getCell('AO1').font = { size: 12, bold: true };
        worksheet.getCell('AP1').font = { size: 12, bold: true };
        worksheet.getCell('AQ1').font = { size: 12, bold: true };
        worksheet.getCell('AR1').font = { size: 12, bold: true };
        worksheet.getCell('AS1').font = { size: 12, bold: true };
        worksheet.getCell('AT1').font = { size: 12, bold: true };
        worksheet.getCell('AU1').font = { size: 12, bold: true };
        worksheet.getCell('AV1').font = { size: 12, bold: true };
        worksheet.getCell('AW1').font = { size: 12, bold: true };
        worksheet.getCell('AX1').font = { size: 12, bold: true };
        worksheet.getCell('AY1').font = { size: 12, bold: true };
        worksheet.getCell('AZ1').font = { size: 12, bold: true };
        worksheet.getCell('BA1').font = { size: 12, bold: true };
        worksheet.getCell('BB1').font = { size: 12, bold: true };
        worksheet.getCell('BC1').font = { size: 12, bold: true };
        worksheet.getCell('BD1').font = { size: 12, bold: true };
        worksheet.getCell('BE1').font = { size: 12, bold: true };
        worksheet.getCell('BF1').font = { size: 12, bold: true };
        worksheet.getCell('BG1').font = { size: 12, bold: true };
        worksheet.addRows(employee);
        worksheet.eachRow(function (row, rowNumber) {
          row.eachCell(function (cell, colNumber) {
            if (cell.value && row.getCell(colNumber).col == 57 && cell.value == 'Yes') {
              cell.fill = {
                type: 'pattern',
                pattern: 'solid',
                bgColor: { argb: 'FF0000' },
                fgColor: { argb: 'FF0000' }
              };
              cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
            }
          });
        });
        worksheet.columns = [
          { key: 'A', width: 15 }, { key: 'B', width: 15 }, { key: 'C', width: 15 }, { key: 'D', width: 15 }, { key: 'E', width: 15 }, { key: 'F', width: 15 },
          { key: 'G', width: 15 }, { key: 'H', width: 15 }, { key: 'I', width: 15 }, { key: 'J', width: 15 }, { key: 'K', width: 15 }, { key: 'L', width: 15 },
          { key: 'M', width: 15 }, { key: 'N', width: 15 }, { key: 'O', width: 15 }, { key: 'P', width: 15 },
          { key: 'Q', width: 15 }, { key: 'R', width: 15 }, { key: 'S', width: 15 }, { key: 'T', width: 15 },
          { key: 'U', width: 15 }, { key: 'V', width: 15 }, { key: 'W', width: 15 }, { key: 'X', width: 15 },
          { key: 'Y', width: 15 }, { key: 'Z', width: 15 }, { key: 'AA', width: 15 }, { key: 'AB', width: 15 },
          { key: 'AC', width: 15 }, { key: 'AD', width: 15 }, { key: 'AE', width: 15 }, { key: 'AF', width: 15 },
          { key: 'AG', width: 15 }, { key: 'AH', width: 15 }, { key: 'AI', width: 15 }, { key: 'AJ', width: 15 },
          { key: 'AK', width: 15 }, { key: 'AL', width: 15 }, { key: 'AM', width: 15 }, { key: 'AN', width: 15 },
          { key: 'AO', width: 15 }, { key: 'AP', width: 15 }, { key: 'AQ', width: 15 }, { key: 'AR', width: 15 },
          { key: 'AS', width: 15 }, { key: 'AT', width: 15 }, { key: 'AU', width: 15 }, { key: 'AV', width: 15 },
          { key: 'AW', width: 15 }, { key: 'AX', width: 15 }, { key: 'AY', width: 15 }, { key: 'AZ', width: 15 },
          { key: 'BA', width: 15 }, { key: 'BB', width: 15 }, { key: 'BC', width: 15 }, { key: 'BD', width: 15 },
          { key: 'BE', width: 30 }, { key: 'BF', width: 30 }, { key: 'BG', width: 30 }
        ];


        this.dataService.loaderHandler(false);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Incomplete Staff Data ' + EXCEL_EXTENSION);
        });
      });
  }

  getTribeMasterData() {
    this.dataService.loaderHandler(true);
    let month: string = '0' + (this.months.indexOf(this.selectedMonth) + 1);
    // let year: string = this.selectedDate.substring(0, 4);
    const reportingPeriod = this.selectedYear + '' + month.slice(-2);
    this.isErrorExists = false;
    this.bankId = JSON.parse(localStorage.getItem('userinfo')).username;
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    this.resetParams();
    this.restService.post(`/people/data/report/tribeData?rptPeriod=${reportingPeriod}&bankId=${this.bankId}`,
      { techUnits: lobts, platforms: platforms, location: locations }).subscribe(res => {
        let elementData = [];
        this.data = res;

        this.data.forEach((emp) => {
          elementData.push([
            emp.asOfDate,
            emp.platformIndex,
            emp.platformName,
            emp.tribeId,

            emp.tribeName,
            emp.tribeLeadsBankId,
            emp.tribeLeadsName,
            emp.tribeLeadDelegatesBankId,

            emp.tribeLeadDelegatesName,
            emp.tribeStatus,
            emp.effectiveStartDate,
            emp.effectiveEndDate]);
        });
        let EXCEL_EXTENSION = '.xlsx';
        let workbook = new Excel.Workbook();
        let worksheet = workbook.addWorksheet('Tribe Master');
        let headerRow = worksheet.addRow(this.tribeMasterColumns);

        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: 'FF0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        worksheet.getCell('A1').font = { size: 12, bold: true };
        worksheet.getCell('B1').font = { size: 12, bold: true };
        worksheet.getCell('C1').font = { size: 12, bold: true };
        worksheet.getCell('D1').font = { size: 12, bold: true };
        worksheet.getCell('E1').font = { size: 12, bold: true };
        worksheet.getCell('F1').font = { size: 12, bold: true };
        worksheet.getCell('G1').font = { size: 12, bold: true };
        worksheet.getCell('H1').font = { size: 12, bold: true };
        worksheet.getCell('I1').font = { size: 12, bold: true };
        worksheet.getCell('J1').font = { size: 12, bold: true };
        worksheet.getCell('K1').font = { size: 12, bold: true };
        worksheet.getCell('L1').font = { size: 12, bold: true };
        worksheet.getCell('M1').font = { size: 12, bold: true };
        worksheet.getCell('N1').font = { size: 12, bold: true };
        worksheet.getCell('O1').font = { size: 12, bold: true };
        worksheet.getCell('P1').font = { size: 12, bold: true };
        worksheet.getCell('Q1').font = { size: 12, bold: true };
        worksheet.getCell('R1').font = { size: 12, bold: true };
        worksheet.getCell('S1').font = { size: 12, bold: true };

        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Tribe Details' + EXCEL_EXTENSION);
        });
        this.dataService.loaderHandler(false);

      });
  }

  getSubPlatformMasterData() {
    this.dataService.loaderHandler(true);
    let month: string = '0' + (this.months.indexOf(this.selectedMonth) + 1);
    // let year: string = this.selectedDate.substring(0, 4);
    const reportingPeriod = this.selectedYear + '' + month.slice(-2);
    this.isErrorExists = false;
    this.bankId = JSON.parse(localStorage.getItem('userinfo')).username;
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    this.resetParams();
    this.restService.post(`/people/data/report/subPlatformData?rptPeriod=${reportingPeriod}&bankId=${this.bankId}`,
      { techUnits: lobts, platforms: platforms, location: locations }).subscribe(res => {
        let elementData = [];
        this.data = res;

        this.data.forEach((emp) => {
          elementData.push([
            emp.asOfDate,
            emp.platformIndex,
            emp.platformName,
            emp.subPlatformId,

            emp.subPlatformName,
            emp.subPlatformBusinessLeadsBankId,
            emp.subPlatformBusinessLeadsName,
            emp.subPlatformBusinessLeadDelegatesBankId,

            emp.subPlatformBusinessLeadDelegatesName,
            emp.subPlatformTechnologyLeadsBankId,
            emp.subPlatformTechnologyLeadsName,
            emp.subPlatformTechnologyLeadDelegatesBankId,

            emp.subPlatformTechnologyLeadDelegatesName,
            emp.subPlatformStatus,
            emp.effectiveStartDate,
            emp.effectiveEndDate]);
        });
        let EXCEL_EXTENSION = '.xlsx';
        let workbook = new Excel.Workbook();
        let worksheet = workbook.addWorksheet('Sub-Platform Master');
        let headerRow = worksheet.addRow(this.subPlatformMasterColumns);

        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: 'FF0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        worksheet.getCell('A1').font = { size: 12, bold: true };
        worksheet.getCell('B1').font = { size: 12, bold: true };
        worksheet.getCell('C1').font = { size: 12, bold: true };
        worksheet.getCell('D1').font = { size: 12, bold: true };
        worksheet.getCell('E1').font = { size: 12, bold: true };
        worksheet.getCell('F1').font = { size: 12, bold: true };
        worksheet.getCell('G1').font = { size: 12, bold: true };
        worksheet.getCell('H1').font = { size: 12, bold: true };
        worksheet.getCell('I1').font = { size: 12, bold: true };
        worksheet.getCell('J1').font = { size: 12, bold: true };
        worksheet.getCell('K1').font = { size: 12, bold: true };
        worksheet.getCell('L1').font = { size: 12, bold: true };
        worksheet.getCell('M1').font = { size: 12, bold: true };
        worksheet.getCell('N1').font = { size: 12, bold: true };
        worksheet.getCell('O1').font = { size: 12, bold: true };
        worksheet.getCell('P1').font = { size: 12, bold: true };
        worksheet.getCell('Q1').font = { size: 12, bold: true };
        worksheet.getCell('R1').font = { size: 12, bold: true };
        worksheet.getCell('S1').font = { size: 12, bold: true };

        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Sub-Platform Details' + EXCEL_EXTENSION);
        });
        this.dataService.loaderHandler(false);

      });
  }

  getTeamMasterData() {
    this.dataService.loaderHandler(true);
    let month: string = '0' + (this.months.indexOf(this.selectedMonth) + 1);
    // let year: string = this.selectedDate.substring(0, 4);
    const reportingPeriod = this.selectedYear + '' + month.slice(-2);

    this.isErrorExists = false;
    this.bankId = JSON.parse(localStorage.getItem('userinfo')).username;
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    this.resetParams();
    this.restService.post(`/people/data/report/teamMasterData?rptPeriod=${reportingPeriod}&bankId=${this.bankId}`,
      { techUnits: lobts, platforms: platforms, location: locations }).subscribe(res => {
        let elementData = [];
        this.data = res;

        this.data.forEach((emp) => {
          elementData.push([
            emp.asOfDate,
            emp.techUnit,
            emp.teamPlatformIndex,
            emp.teamPlatformName,
            emp.teamPlatformLeads,
            emp.teamSubPlatform,
            emp.teamSubPlatformId,
            emp.teamSubPlatformLeads,
            emp.teamTribeName,
            emp.teamTribeId,
            emp.teamTribeLeads,
            emp.teamId,
            emp.teamName,
            emp.teamType,
            emp.creationDate,
            emp.teamLeadName,
            emp.teamLead1BankId,
            emp.teamLeadDelegates,
            emp.teamLeadDelegates1BankId,
            emp.productOwner,
            emp.productOwners1BankId,
            emp.coreTeamMemberCount,
            emp.coreTeamMembers100PerCount,
            emp.coreTeamFTE,
            emp.coreTeamBlendedCost,
            emp.coreTeamNotionalCost,
            emp.coreTeamChargeableCost,
            emp.augTeamMemberCount,
            emp.augTeamMembers100PerCount,
            emp.augTeamFTE,
            emp.augTeamBlendedCost,
            emp.augTeamNotionalCost,
            emp.augTeamChargeableCost,
            emp.totalPlannedFTE,
            emp.totalPlannedBlendedCost,
            emp.totalTeamMembers,
            emp.totalTeam100PerMembers,
            emp.totalTeamFTE,
            emp.totalTeamBlendedCost,
            emp.totalTeamNotionalCost,
            emp.totalTeamChargeableCost,
            emp.teamStatus,
            this.dateUtility.dateFormatterMoment(emp.effectiveStartDate),
            this.dateUtility.dateFormatterMoment(emp.effectiveEndDate)
          ]);
        });
        let EXCEL_EXTENSION = '.xlsx';
        let workbook = new Excel.Workbook();
        let worksheet = workbook.addWorksheet('Team Master list');
        let headerRow = worksheet.addRow(this.teamMasterColumns);

        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: 'FF0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'All Team Master list' + EXCEL_EXTENSION);
        });
        this.dataService.loaderHandler(false);

      });
  }
}
