import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RestService } from 'src/app/common/service/rest.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { DataService } from 'src/app/common/service/data.service';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import { DateUtility } from 'src/app/common/utility/date-utility';
import * as Excel from 'exceljs/dist/exceljs.min.js';
import { saveAs } from 'file-saver';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import * as _ from 'lodash';
import { CommonService } from "../../../common/service/common.service";
import * as moment from 'moment';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-portfolio-report',
  templateUrl: './portfolio-report.component.html',
  styleUrls: ['./portfolio-report.component.scss']
})
export class PortfolioReportComponent implements OnInit {
  reportNameDropDown: any = [];
  scenarioDropDown: any = [];
  workTypeDropDown: any = [];
  currencyDropDown: any = ['SGD'];
  ReportingLocationDropDown: any = [];
  portfolioDropDown: any = [];
  workstreamDropDown: any = [];
  subWorkstreamDropDown: any = [];
  dates: any = [];
  res: any = [];
  GlColumns = ['Reporting Flag','Scenario','GL Groups', 'GL Category', 'Cost Type','Cost Settings'];
  portfolioColumns = ['Portfolio ID', 'Portfolio Name', 'Portfolio Desc', 'Year of Initiation',
    'Work Type', 'Platform Unit', 'Primary Platform Name', 'Business Segment', 'Thematic', 'Horizon', 'Agile/Waterfall',
    'Portfolio Reference', 'Budget Status (Cur Year)', 'Planning Cycle', 'Budget System Owner', 'PF_Work Mgr (BU/SU)',
    'PF_Work Mgr (Technology)'];
  WSColumns = ['Workstream ID', 'Workstream Name', 'Workstream Desc', 'Reporting Location', 'Sub-Platform Name','Work Category',
    'Overall Risk Level','Work Status', 'Work Phase', 'Workstream Reference', 'LE-PC Code (Build)', 'LE-PC Code (Operate)',
    'WS_Work Mgr (BU/SU)', 'WS_Work Mgr (Technology)', 'WS_Approval Date', 'WS_Start Date',
    'WS_SW Eng Start Date', 'WS_Go-Live Date', 'WS_End Date'];
  // WSColumns = ['Workstream ID', 'Workstream Name', 'Workstream Desc', 'Reporting Location', 'Sub-Platform Name','Work Status', 'Work Phase', 'Workstream Reference', 'LE-PC Code (Build)', 'LE-PC Code (Operate)',
  // 'WS_Work Mgr (BU/SU)', 'WS_Work Mgr (Technology)', 'WS_Approval Date', 'WS_Start Date',
  // 'WS_SW Eng Start Date', 'WS_Go-Live Date', 'WS_End Date'];
  SWSColumns = ['Sub-Workstream ID', 'Sub-Workstream Name',
    'Sub-Workstream Desc', 'Delivery Platform Name','A/B Work', 'Sub-Workstream Reference', 'SWS_Work Mgr (BU/SU)',
    'SWS_Work Mgr (Technology)', 'SWS_Start Date', 'SWS_SW Eng Start Date', 'SWS_Go-Live Date'];
  // SWSColumns = ['Sub-Workstream ID', 'Sub-Workstream Name',
  // 'Sub-Workstream Desc', 'Delivery Platform Name','Sub-Workstream Reference', 'SWS_Work Mgr (BU/SU)',
  // 'SWS_Work Mgr (Technology)', 'SWS_Start Date', 'SWS_SW Eng Start Date', 'SWS_Go-Live Date'];
  // months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  portfolioReport: FormGroup;
  isErrorExists: boolean = false;
  bankId: any;
  data: any = [];
  currencyCodeType: string;

  isReviewDetailsShow: boolean = false;
  showDeliveryList : boolean = false;
  techUnits: any;
  countries: any;
  platformList: any = [];
  deliveryList: any = [];
  isAllPortfolioFields: boolean = false;
  isAllFieldsWS: boolean = false;
  isAllFieldsSWS: boolean = false;
  selectedMonth: any;
  selectedReportName: any;
  reportName: any;
  preparedData: any;
  showPortfolioList: boolean = false;
  showWSList: boolean = false;
  showSWSList: boolean = false;
  selectedPortfolios: any = [];
  selectedPlatforms: any = [];
  selectedWorkType: any = [];
  selectedScenarios: any = [];
  locationsformater: any = [];
  scenariosformater: any = [];
  workTypesformater: any = [];
  platformsformatter: any = [];
  dataList: any = [];
  selectedReportingLocations: any = [];
  platformNames: any = [];
  userOneBankId: any = localStorage.getItem('userOneBankId');
  portfoliosAll: any;
  portfolioSelected: boolean = false;
  showPortDropDown: boolean = false;

  elements: any[] = [];
  allSelected = false;
  currentDate:any;
  

  constructor(private http: HttpClient, private restService: RestService,
    private dataService: DataService, private dateUtility: DateUtility, private fb: FormBuilder,
    private commonService: CommonService,private datePipe: DatePipe) {
    this.commonService.setDocumentTitle('PORTFOLIO REPORTS');
    this.commonService.trackPageView();
  }

  ngOnInit() {
    this.portfolioReport = this.fb.group({
      reportName: ['', [Validators.required]],
      //reportingMonth: ['', [Validators.required]],
      currency: ['', [Validators.required]],
      scenario: ['', [Validators.required]],
      workType: ['', [Validators.required]],
      reportingLocation: ['', [Validators.required]],
      platformIndex: ['', [Validators.required]],
      platformName: [''],
      portfolios: ['0']
    });
    this.getCurrencyCodeData();
    this.getPlatformData();
    this.loadDropDowns();

    this.currentDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd hh:mm:ss')
  }
  loadDropDowns() {
    const list = ['PF_Report Name', 'scenario', 'work Type',];
    // this.restService.post(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues/', list).subscribe(data => {
    //   if (data && data['work Type']) {
    //
    //     data['work Type'].forEach(element => {
    //       this.workTypeDropDown.push({ value: element.value, display: element.value });
    //     });
    //   }
    // });

    // hardcoded value for worktype
    this.workTypeDropDown.push({ value: 'All WorkTypes' });
    this.workTypeDropDown.push({ value: 'Enhancement', display: 'Enhancement' });
    this.workTypeDropDown.push({ value: 'Initiative', display: 'Initiative' });
    this.workTypeDropDown.push({ value: 'Operate', display: 'Operate' });

    this.restService.get(URL_PREFIX.REPORTS + '/reports/portfolio/reportNames').subscribe(data => {
      if (data != null && data !== '') {
        this.reportNameDropDown = [];
        data.forEach(element => {
          this.reportNameDropDown.push({ value: element, display: element });
        });
      }
    });
    this.restService.get(URL_PREFIX.REPORTS + '/reports/portfolio/workLocations?bankId=' + this.userOneBankId).subscribe(data => {
      if (data != null && data !== '') {
        this.ReportingLocationDropDown.push({ value: 'All Locations' });
        data.forEach(element => {
          if (element !== '') {
            this.ReportingLocationDropDown.push({ value: element, display: element });
          }
        });
      }
    });


    const platform = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    const reportingPeriodDate = JSON.parse(sessionStorage.getItem('reportingPeriodDate'));
    if (reportingPeriodDate) {
    }
   
    this.currencyCodeType = sessionStorage.getItem(WORK_HIERARCHY_CONST.CURRENCY_CODE_TYPE);
  
  }
  getCurrencyCodeData() {
    let loggedInUserId = localStorage.getItem('userOneBankId');
    this.restService.get(URL_PREFIX.PORTFOLIO + `/financial/getCurrenciesBasedOnUam?loggedInUserId=${loggedInUserId}`).subscribe(data => {
    this.currencyDropDown = data;
    });
  }
  reviewDetails() {
    const controls = this.portfolioReport.controls;


    for (const name in controls) {
      if (controls[name].invalid) {
        this.portfolioReport.controls[name].markAsTouched();
      }
    }
    if (this.portfolioReport.invalid) {
      this.portfolioReport.markAllAsTouched();
    } else if (this.portfolioReport.valid) {
      this.dataList = [];
      this.selectedPortfolios = [];
      this.portfolioReport.controls.portfolios.setValue('');
      const preparedData = {
        reportName: this.portfolioReport.controls.reportName.value,
        reportingMonth: '',
        currency: this.portfolioReport.controls.currency.value,
        //scenario: this.portfolioReport.controls.scenario.value,
        scenarios: this.scenariosformater,
        workTypes: this.workTypesformater,
        platformIndices: this.platformsformatter,
        reportingLocations: this.locationsformater
      }
      if (this.showPortfolioList) {
        this.restService.post(URL_PREFIX.REPORTS + '/reports/portfolio/portfolios', preparedData).subscribe(data => {
          console.log('Data resposne', data);
          if (data !== null) {
            this.isReviewDetailsShow = true;
            this.portfolioDropDown = [];
            this.portfolioDropDown.push({ value: "All" });
            data.forEach(element => {
              this.portfolioDropDown.push({ value: element.portfolioId, display: element.portfolioName });
            });
          }
        },
          error => {
            if (error.status !== null) {

            }
          }
        );
      }
      else if (this.showWSList ) {
        this.restService.post(URL_PREFIX.REPORTS + '/reports/portfolio/workStreams', preparedData).subscribe(data => {
          console.log('Data resposne', data);
          if (data !== null) {
            this.workstreamDropDown = [];
            this.isReviewDetailsShow = true;
            this.workstreamDropDown.push({ value: "All" });
            data.forEach(element => {
              if (element.workStreamId) {
                this.workstreamDropDown.push({ value: element.workStreamId, display: element.workStreamName });
              }
            });
          }
        },
          error => {
            if (error.status !== null) {

            }
          }
        );
      }
       else if (this.showSWSList && !this.showDeliveryList) {
        this.restService.post(URL_PREFIX.REPORTS + '/reports/portfolio/subWorkStreams', preparedData).subscribe(data => {
          console.log('Data resposne', data);
          if (data !== null) {
            this.subWorkstreamDropDown = [];
            this.isReviewDetailsShow = true;
            this.subWorkstreamDropDown.push({ value: "All" });
            data.forEach(element => {
              if (element.subWorkStreamId) {
                this.subWorkstreamDropDown.push({ value: element.subWorkStreamId, display: element.subWorkStreamName });
              }
            });
          }
        },
          error => {
            if (error.status !== null) {

            }
          }
        );
      }
      else if (this.showDeliveryList) {
        const preparedData12a = {
          reportName: this.portfolioReport.controls.reportName.value,
          reportingMonth: '',
          currency: this.portfolioReport.controls.currency.value,
          //scenario: this.portfolioReport.controls.scenario.value,
          scenarios: this.scenariosformater,
          workTypes: this.workTypesformater,
          deliveryUnits: this.platformsformatter,
          reportingLocations: this.locationsformater,
          platformIndices:[],
          portfolios:[],
          workStreamIds:[]
        }
        this.restService.post(URL_PREFIX.REPORTS + '/reports/portfolio/subWorkStreamsForDeliveryUnits', preparedData12a).subscribe(data => {
          console.log('Data resposne', data);
          if (data !== null) {
            this.subWorkstreamDropDown = [];
            this.isReviewDetailsShow = true;
            this.subWorkstreamDropDown.push({ value: "All" });
            data.forEach(element => {
              if (element.subWorkStreamId) {
                this.subWorkstreamDropDown.push({ value: element.subWorkStreamId, display: element.subWorkStreamName });
              }
            });
          }
        },
          error => {
            if (error.status !== null) {

            }
          }
        );
      }
    }
  }

  export() {
    if (JSON.parse(localStorage.getItem('userinfo'))) {
      this.bankId = JSON.parse(localStorage.getItem('userinfo')).username;
    }
    this.preparedData = {
      reportName: this.portfolioReport.controls.reportName.value,
      reportingMonth: '',
      currency: this.portfolioReport.controls.currency.value,
      //scenario: this.portfolioReport.controls.scenario.value,
      scenarios: this.scenariosformater,
      workTypes: this.workTypesformater,
      platformIndices: this.platformsformatter,
      reportingLocations: this.locationsformater,
      portfolios: this.showPortfolioList ? this.dataList : [],
      workStreamIds: this.showWSList ? this.dataList : [],
      subWorkStreamIds: this.showSWSList ? this.dataList : [],
    }
    this.commonService.trackEvent("DOWNLOAD PORTFOLIO REPORT", "DOWNLOAD", this.preparedData.reportName, 1);
    if (this.selectedReportName === '7) Monthly - PF') {
      this.exportReport_7();
    }
    else if (this.selectedReportName === '8) Monthly - PF_WS') {
      this.exportReport_8();
    }
    else if (this.selectedReportName === '9) Monthly - PF_WS_SWS') {
      this.exportReport_9();
    }
    else if (this.selectedReportName === '10) Monthly - PF_SWS') {
      this.exportReport_10();
    }
    else if (this.selectedReportName === '11) Monthly - WS_SWS') {
      this.exportReport_11();
    }
    else if (this.selectedReportName === '12) Monthly - SWS') {
      this.exportReport_12();
    }
    else if (this.selectedReportName === '12a) Monthly - SWS_C-Work') {
      this.exportReport_12a();
    }
  }

  exportReport_7() {
    this.dataService.loaderHandler(true);
    this.isErrorExists = false;

    let columns_12 = [];
    let columns_11 = [];
    let columns_10 = [];
    let columns_9 = [];
    let reportingMonth = [];
    let currency = [];
    let workType = [];
    let location = [];
    let platformsData = [];
    let elementData = [];
    let date =['Download As Of Date',this.currentDate];
    this.restService.post(URL_PREFIX.REPORTS + `/reports/portfolio/downloadReportData`, this.preparedData).subscribe(data => {
      reportingMonth = ['Reporting Month',];
      currency = ['Currency',];
      workType = ['Work Type',];
      location = ['Reporting Location',];
      platformsData = ['Platform Index & Name',];
      for (let i = 0; i <= this.selectedWorkType.length; i++) {
        if (this.selectedWorkType[i] === 'All WorkTypes') {
          workType.push(this.selectedWorkType[i]);
          break;
        }
        else {
          workType.push(this.selectedWorkType[i]);
        }
      }

      for (let i = 0; i <= this.selectedReportingLocations.length; i++) {
        if (this.selectedReportingLocations[i] === 'All Locations') {
          location.push(this.selectedReportingLocations[i]);
          break;
        }
        else {
          location.push(this.selectedReportingLocations[i]);
        }
      }
      for (let i = 0; i <= this.selectedPlatforms.length; i++) {
        if (this.selectedPlatforms[i] === 'All Platforms') {
          platformsData.push(this.selectedPlatforms[i]);
          break;
        }
        else {
          this.platformList.forEach(element => {
            if (this.selectedPlatforms[i] === element.value) {
              platformsData.push(element.value + '-' + element.display);
            }
          });
        }
      }
      this.portfolioColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('PF');
        columns_12.push('');
        columns_9.push('Non-Financial');
      });
      this.GlColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('PF');
        columns_12.push('');
        columns_9.push('Financial');
      });

      let EXCEL_EXTENSION = '.xlsx';
      let workbook = new Excel.Workbook();
      let worksheet = workbook.addWorksheet('Report_7');

      worksheet.addRow(['Report 7', this.reportName]);
      worksheet.addRow(['']);
      //worksheet.addRow(['Scenario',  this.portfolioReport.controls.scenario.value]);
      // worksheet.addRow(['Reporting Month', '', this.selectedMonth]);
      worksheet.addRow(['Currency', this.portfolioReport.controls.currency.value]);
      worksheet.addRow(workType);
      worksheet.addRow(location);
      worksheet.addRow(platformsData);
      worksheet.addRow(date);
      worksheet.addRow(['']);

      if (data != "") {
        if (data[0].financialDatas) {
          data[0].financialDatas.forEach(element => {
            columns_11.push(element.fieldName);
            columns_12.push(element.dataType);
            columns_9.push('Financial');
            columns_10.push('PF');
          });
        }
        let i = 0;
        data.forEach(element => {
          elementData.push([element.portfolioId,
          element.portfolioName,
          element.portfolioDesc,
          element.initiationYear,
          element.workType,
          element.platformUnit,
          element.primaryPlatformName,
          element.bizSegment,
          element.thematic,
          element.horizon,
          element.agileWaterfall,
          element.portfolioReferenceId,
          element.budgetStatus,
          element.planningCycle,
          element.budgetSystemOwner,
          element.pfWorkManagerBu,
          element.pfWorkManagerTech,
          element.reportingFlag,
          element.scenario,

          element.glGroup,
          element.glCategory,
          element.costType,
          element.costSettings,
          ])
          element.financialDatas.forEach(element => {
            elementData[i].push(element.value);
          });
          i++;
        });

        //worksheet.addRow(columns_9);
        // worksheet.addRow(columns_10);
        let headerRow = worksheet.addRow(columns_11);
        //worksheet.addRow(columns_12);
        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: '0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        this.applyWorkSheetStyles(worksheet);

        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Portfolio Financial Report 7' + EXCEL_EXTENSION);
          this.commonService.showSnackBar({ type: 'success', message: "Report Downloaded Succesfully", duration: 3000 });
        });
      }
      else {
        let headerRow = worksheet.addRow(columns_11);
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: '0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        this.applyWorkSheetStyles(worksheet);

        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Portfolio Financial Report 7' + EXCEL_EXTENSION);
        });
        this.commonService.showSnackBar({ type: 'alert', message: "Data dosen't exist for the report", duration: 3000 });
      }
    });
    this.dataService.loaderHandler(false);
  }
  exportReport_8() {
    this.dataService.loaderHandler(true);
    this.isErrorExists = false;
    let date =['Download As Of Date',this.currentDate];
    let columns_12 = [];
    let columns_11 = [];
    let columns_10 = [];
    let columns_9 = [];
    let reportingMonth = [];
    let currency = [];
    let workType = [];
    let location = [];
    let platformsData = [];
    let elementData = [];
    this.restService.post(URL_PREFIX.REPORTS + `/reports/portfolio/downloadReportData`, this.preparedData).subscribe(data => {
      reportingMonth = ['Reporting Month',];
      currency = ['Currency',];
      workType = ['Work Type',];
      location = ['Reporting Location',];
      platformsData = ['Platform Index & Name',];

      for (let i = 0; i <= this.selectedWorkType.length; i++) {
        if (this.selectedWorkType[i] === 'All WorkTypes') {
          workType.push(this.selectedWorkType[i]);
          break;
        }
        else {
          workType.push(this.selectedWorkType[i]);
        }
      }

      for (let i = 0; i <= this.selectedReportingLocations.length; i++) {
        if (this.selectedReportingLocations[i] === 'All Locations') {
          location.push(this.selectedReportingLocations[i]);
          break;
        }
        else {
          location.push(this.selectedReportingLocations[i]);
        }
      }
      for (let i = 0; i <= this.selectedPlatforms.length; i++) {
        if (this.selectedPlatforms[i] === 'All Platforms') {
          platformsData.push(this.selectedPlatforms[i]);
          break;
        }
        else {
          this.platformList.forEach(element => {
            if (this.selectedPlatforms[i] === element.value) {
              platformsData.push(element.value + '-' + element.display);
            }
          });
        }
      }
      this.portfolioColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('PF');
        columns_12.push('');
        columns_9.push('Non-Financial');
      });
      this.WSColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('WS');
        columns_12.push('');
        columns_9.push('Non-Financial');
      });

      this.GlColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('WS');
        columns_12.push('');
        columns_9.push('Financial');
      });
      let EXCEL_EXTENSION = '.xlsx';
      let workbook = new Excel.Workbook();
      let worksheet = workbook.addWorksheet('Report_8');
      worksheet.addRow(['Report 8', this.reportName]);
      worksheet.addRow(['']);
     // worksheet.addRow(['Scenario', '', this.portfolioReport.controls.scenario.value]);
      // worksheet.addRow(['Reporting Month', '', this.selectedMonth]);
      worksheet.addRow(['Currency', this.portfolioReport.controls.currency.value]);
      worksheet.addRow(workType);
      worksheet.addRow(location);
      worksheet.addRow(platformsData);
      worksheet.addRow(date);
      worksheet.addRow(['']);
      if (data != "") {
        if (data[0].financialDatas) {
          data[0].financialDatas.forEach(element => {
            columns_11.push(element.fieldName);
            columns_12.push(element.dataType);
            columns_9.push('Financial');
            columns_10.push('WS');
          });
        }
        let i = 0;
        data.forEach(element => {
          elementData.push([element.portfolioId,
          element.portfolioName,
          element.portfolioDesc,
          element.initiationYear,
          element.workType,
          element.platformUnit,
          element.primaryPlatformName,
          element.bizSegment,
          element.thematic,
          element.horizon,
          element.agileWaterfall,
          element.portfolioReferenceId,
          element.budgetStatus,
          element.planningCycle,
          element.budgetSystemOwner,
          element.pfWorkManagerBu,
          element.pfWorkManagerTech,

          element.workStreamId,
          element.workStreamName,
          element.workStreamDesc,
          element.country,
          element.subPlatformName,
          element.category,
          element.overallRiskLevel,
          element.workStatus,
          element.workPhase,
          element.workStreamReference,
          element.lePcCodeBuild,
          element.lePcCodeOperate,
          element.wsWorkManagerBu,
          element.wsWorkManagerTech,
          element.wsApprovalDate,
          element.wsStartDate,
          element.wsSwEngStartDate,
          element.wsGoLiveDate,
          element.wsEndDate,
          element.reportingFlag,
          element.scenario,

          element.glGroup,
          element.glCategory,
          element.costType,
          element.costSettings,
          ])
          element.financialDatas.forEach(element => {
            elementData[i].push(element.value);
          });
          i++;
        });

       //worksheet.addRow(columns_9);
       // worksheet.addRow(columns_10);
        let headerRow = worksheet.addRow(columns_11);
        //worksheet.addRow(columns_12);
        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: '0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        this.applyWorkSheetStyles(worksheet);

        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Portfolio Financial Report 8' + EXCEL_EXTENSION);
          this.commonService.showSnackBar({ type: 'success', message: "Report Downloaded Succesfully", duration: 3000 });
        });
      }
      else {
        //worksheet.addRow(columns_9);
        //worksheet.addRow(columns_10);
        let headerRow = worksheet.addRow(columns_11);
        //worksheet.addRow(columns_12);
        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: '0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        this.applyWorkSheetStyles(worksheet);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Portfolio Financial Report 8' + EXCEL_EXTENSION);
          this.commonService.showSnackBar({ type: 'alert', message: "Data dosen't exist for the report", duration: 3000 });
        });
      }
    });
    this.dataService.loaderHandler(false);
  }
  exportReport_9() {
    this.dataService.loaderHandler(true);
    let date =['Download As Of Date',this.currentDate];
    this.isErrorExists = false;
    let columns_12 = [];
    let columns_11 = [];
    let columns_10 = [];
    let columns_9 = [];
    let reportingMonth = [];
    let currency = [];
    let workType = [];
    let location = [];
    let platformsData = [];
    let elementData = [];
    this.restService.post(URL_PREFIX.REPORTS + `/reports/portfolio/downloadReportData`, this.preparedData).subscribe(data => {
      reportingMonth = ['Reporting Month',];
      currency = ['Currency',];
      workType = ['Work Type',];
      location = ['Reporting Location',];
      platformsData = ['Platform Index & Name',];

      for (let i = 0; i <= this.selectedWorkType.length; i++) {
        if (this.selectedWorkType[i] === 'All WorkTypes') {
          workType.push(this.selectedWorkType[i]);
          break;
        }
        else {
          workType.push(this.selectedWorkType[i]);
        }
      }

      for (let i = 0; i <= this.selectedReportingLocations.length; i++) {
        if (this.selectedReportingLocations[i] === 'All Locations') {
          location.push(this.selectedReportingLocations[i]);
          break;
        }
        else {
          location.push(this.selectedReportingLocations[i]);
        }
      }
      for (let i = 0; i <= this.selectedPlatforms.length; i++) {
        if (this.selectedPlatforms[i] === 'All Platforms') {
          platformsData.push(this.selectedPlatforms[i]);
          break;
        }
        else {
          this.platformList.forEach(element => {
            if (this.selectedPlatforms[i] === element.value) {
              platformsData.push(element.value + '-' + element.display);
            }
          });
        }
      }
      this.portfolioColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('PF');
        columns_12.push('');
        columns_9.push('Non-Financial');
      });
      this.WSColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('WS');
        columns_12.push('');
        columns_9.push('Non-Financial');
      });
      this.SWSColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('SWS');
        columns_12.push('');
        columns_9.push('Non-Financial');
      });
      this.GlColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('SWS');
        columns_12.push('');
        columns_9.push('Financial');
      });

      let EXCEL_EXTENSION = '.xlsx';
      let workbook = new Excel.Workbook();
      let worksheet = workbook.addWorksheet('Report_9');
      worksheet.addRow(['Report 9', this.reportName]);
      worksheet.addRow(['']);
      worksheet.addRow(['Currency', this.portfolioReport.controls.currency.value]);
      worksheet.addRow(workType);
      worksheet.addRow(location);
      worksheet.addRow(platformsData);
      worksheet.addRow(date);
      worksheet.addRow(['']);
      if (data != "") {
        if (data[0].financialDatas) {
          data[0].financialDatas.forEach(element => {
            columns_11.push(element.fieldName);
            columns_12.push(element.dataType);
            columns_9.push('Financial');
            columns_10.push('SWS');
          });
        }
        let i = 0;
        data.forEach(element => {
          elementData.push([element.portfolioId,
          element.portfolioName,
          element.portfolioDesc,
          element.initiationYear,
          element.workType,
          element.platformUnit,
          element.primaryPlatformName,
          element.bizSegment,
          element.thematic,
          element.horizon,
          element.agileWaterfall,
          element.portfolioReferenceId,
          element.budgetStatus,
          element.planningCycle,
          element.budgetSystemOwner,
          element.pfWorkManagerBu,
          element.pfWorkManagerTech,

          element.workStreamId,
          element.workStreamName,
          element.workStreamDesc,
          element.country,
          element.subPlatformName,
          element.category,
          element.overallRiskLevel,
          element.workStatus,
          element.workPhase,
          element.workStreamReference,
          element.lePcCodeBuild,
          element.lePcCodeOperate,
          element.wsWorkManagerBu,
          element.wsWorkManagerTech,
          element.wsApprovalDate,
          element.wsStartDate,
          element.wsSwEngStartDate,
          element.wsGoLiveDate,
          element.wsEndDate,

          element.subWorkStreamId,
          element.subWorkStreamName,
          element.subWorkStreamDesc,
          element.deliveryPlatformName,
          element.abWork,
          element.subWorkStreamReference,
          element.swsWorkManagerBu,
          element.swsWorkManagerTech,
          element.swsStartDate,
          element.swsSwEngStartDate,
          element.swsGoLiveDate,
          element.reportingFlag,
          element.scenario,

          element.glGroup,
          element.glCategory,
          element.costType,
          element.costSettings,
          ])
          element.financialDatas.forEach(element => {
            elementData[i].push(element.value);
          });
          i++;
        });

       //worksheet.addRow(columns_9);
        //worksheet.addRow(columns_10);
        let headerRow = worksheet.addRow(columns_11);
        //worksheet.addRow(columns_12);
        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: '0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        this.applyWorkSheetStyles(worksheet);

        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Portfolio Financial Report 9' + EXCEL_EXTENSION);
          this.commonService.showSnackBar({ type: 'success', message: "Report Downloaded Succesfully", duration: 3000 });
        });
      }
      else {
        //worksheet.addRow(columns_9);
        //worksheet.addRow(columns_10);
        let headerRow = worksheet.addRow(columns_11);
        //worksheet.addRow(columns_12);
        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: '0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        this.applyWorkSheetStyles(worksheet);

        //worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Portfolio Financial Report 9' + EXCEL_EXTENSION);
          this.commonService.showSnackBar({ type: 'alert', message: "Data dosen't exist for the report", duration: 3000 });
        });
      }
    });
    this.dataService.loaderHandler(false);
  }
  exportReport_10() {
    this.dataService.loaderHandler(true);
    let date =['Download As Of Date',this.currentDate];
    this.isErrorExists = false;
    //this.bankId = JSON.parse(localStorage.getItem('userinfo')).username;
    let columns_12 = [];
    let columns_11 = [];
    let columns_10 = [];
    let columns_9 = [];
    let reportingMonth = [];
    let currency = [];
    let workType = [];
    let location = [];
    let platformsData = [];
    let elementData = [];
    this.restService.post(URL_PREFIX.REPORTS + `/reports/portfolio/downloadReportData`, this.preparedData).subscribe(data => {
      reportingMonth = ['Reporting Month',];
      currency = ['Currency',];
      workType = ['Work Type',];
      location = ['Reporting Location',];
      platformsData = ['Platform Index & Name',];
      for (let i = 0; i <= this.selectedWorkType.length; i++) {
        if (this.selectedWorkType[i] === 'All WorkTypes') {
          workType.push(this.selectedWorkType[i]);
          break;
        }
        else {
          workType.push(this.selectedWorkType[i]);
        }
      }

      for (let i = 0; i <= this.selectedReportingLocations.length; i++) {
        if (this.selectedReportingLocations[i] === 'All Locations') {
          location.push(this.selectedReportingLocations[i]);
          break;
        }
        else {
          location.push(this.selectedReportingLocations[i]);
        }
      }
      for (let i = 0; i <= this.selectedPlatforms.length; i++) {
        if (this.selectedPlatforms[i] === 'All Platforms') {
          platformsData.push(this.selectedPlatforms[i]);
          break;
        }
        else {
          this.platformList.forEach(element => {
            if (this.selectedPlatforms[i] === element.value) {
              platformsData.push(element.value + '-' + element.display);
            }
          });
        }
      }
      this.portfolioColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('PF');
        columns_12.push('');
        columns_9.push('Non-Financial');
      });
      this.SWSColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('SWS');
        columns_12.push('');
        columns_9.push('Non-Financial');
      });
      this.GlColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('SWS');
        columns_12.push('');
        columns_9.push('Financial');
      });

      let EXCEL_EXTENSION = '.xlsx';
      let workbook = new Excel.Workbook();
      let worksheet = workbook.addWorksheet('Report_10');
      worksheet.addRow(['Report 10', this.reportName]);
      worksheet.addRow(['']);
      //worksheet.addRow(['Scenario', '', this.portfolioReport.controls.scenario.value]);
      // worksheet.addRow(['Reporting Month', '', this.selectedMonth]);
      worksheet.addRow(['Currency', this.portfolioReport.controls.currency.value]);
      worksheet.addRow(workType);
      worksheet.addRow(location);
      worksheet.addRow(platformsData);
      worksheet.addRow(date);
      worksheet.addRow(['']);

      if (data != "") {
        if (data[0].financialDatas) {
          data[0].financialDatas.forEach(element => {
            columns_11.push(element.fieldName);
            columns_12.push(element.dataType);
            columns_9.push('Financial');
            columns_10.push('SWS');
          });
        }
        let i = 0;
        data.forEach(element => {
          elementData.push([element.portfolioId,
          element.portfolioName,
          element.portfolioDesc,
          element.initiationYear,
          element.workType,
          element.platformUnit,
          element.primaryPlatformName,
          element.bizSegment,
          element.thematic,
          element.horizon,
          element.agileWaterfall,
          element.portfolioReferenceId,
          element.budgetStatus,
          element.planningCycle,
          element.budgetSystemOwner,
          element.pfWorkManagerBu,
          element.pfWorkManagerTech,


          element.subWorkStreamId,
          element.subWorkStreamName,
          element.subWorkStreamDesc,
          element.deliveryPlatformName,
          element.abWork,
          element.subWorkStreamReference,
          element.swsWorkManagerBu,
          element.swsWorkManagerTech,
          element.swsStartDate,
          element.swsSwEngStartDate,
          element.swsGoLiveDate,
          element.reportingFlag,
          element.scenario,

          element.glGroup,
          element.glCategory,
          element.costType,
          element.costSettings,
          ])
          element.financialDatas.forEach(element => {
            elementData[i].push(element.value);
          });
          i++;
        });

        //worksheet.addRow(columns_9);
        //worksheet.addRow(columns_10);
        let headerRow = worksheet.addRow(columns_11);
        //worksheet.addRow(columns_12);
        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: '0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        this.applyWorkSheetStyles(worksheet);

        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Portfolio Financial Report 10' + EXCEL_EXTENSION);
          this.commonService.showSnackBar({ type: 'success', message: "Report Downloaded Succesfully", duration: 3000 });
        });
      }
      else {
       //worksheet.addRow(columns_9);
        //worksheet.addRow(columns_10);
        let headerRow = worksheet.addRow(columns_11);
        //worksheet.addRow(columns_12);
        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: '0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        this.applyWorkSheetStyles(worksheet);

        //worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Portfolio Financial Report 10' + EXCEL_EXTENSION);
          this.commonService.showSnackBar({ type: 'alert', message: "Data dosen't exist for the report", duration: 3000 });
        });
      }
    });
    this.dataService.loaderHandler(false);
  }
  exportReport_11() {
    this.dataService.loaderHandler(true);
    let date =['Download As Of Date',this.currentDate];
    this.isErrorExists = false;
    //this.bankId = JSON.parse(localStorage.getItem('userinfo')).username;
    let columns_12 = [];
    let columns_11 = [];
    let columns_10 = [];
    let columns_9 = [];
    let reportingMonth = [];
    let currency = [];
    let workType = [];
    let location = [];
    let platformsData = [];
    let elementData = [];
    this.restService.post(URL_PREFIX.REPORTS + `/reports/portfolio/downloadReportData`, this.preparedData).subscribe(data => {
      reportingMonth = ['Reporting Month',];
      currency = ['Currency',];
      workType = ['Work Type',];
      location = ['Reporting Location',];
      platformsData = ['Platform Index & Name',];
      for (let i = 0; i <= this.selectedWorkType.length; i++) {
        if (this.selectedWorkType[i] === 'All WorkTypes') {
          workType.push(this.selectedWorkType[i]);
          break;
        }
        else {
          workType.push(this.selectedWorkType[i]);
        }
      }
      for (let i = 0; i <= this.selectedReportingLocations.length; i++) {
        if (this.selectedReportingLocations[i] === 'All Locations') {
          location.push(this.selectedReportingLocations[i]);
          break;
        }
        else {
          location.push(this.selectedReportingLocations[i]);
        }
      }
      for (let i = 0; i <= this.selectedPlatforms.length; i++) {
        if (this.selectedPlatforms[i] === 'All Platforms') {
          platformsData.push(this.selectedPlatforms[i]);
          break;
        }
        else {
          this.platformList.forEach(element => {
            if (this.selectedPlatforms[i] === element.value) {
              platformsData.push(element.value + '-' + element.display);
            }
          });
        }
      }
      this.WSColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('WS');
        columns_12.push('');
        columns_9.push('Non-Financial');
      });
      this.SWSColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('SWS');
        columns_12.push('');
        columns_9.push('Non-Financial');
      });
      this.GlColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('SWS');
        columns_12.push('');
        columns_9.push('Financial');
      });

      let EXCEL_EXTENSION = '.xlsx';
      let workbook = new Excel.Workbook();
      let worksheet = workbook.addWorksheet('Report_11');
      worksheet.addRow(['Report 11', this.reportName]);
      worksheet.addRow(['']);
      //worksheet.addRow(['Scenario', '', this.portfolioReport.controls.scenario.value]);
      // worksheet.addRow(['Reporting Month', '', this.selectedMonth]);
      worksheet.addRow(['Currency', this.portfolioReport.controls.currency.value]);
      worksheet.addRow(workType);
      worksheet.addRow(location);
      worksheet.addRow(platformsData);
      worksheet.addRow(date);
      worksheet.addRow(['']);
      if (data != "") {
        if (data[0].financialDatas) {
          data[0].financialDatas.forEach(element => {
            columns_11.push(element.fieldName);
            columns_12.push(element.dataType);
            columns_9.push('Financial');
            columns_10.push('SWS');
          });
        }
        let i = 0;
        data.forEach(element => {
          elementData.push([
            element.workStreamId,
            element.workStreamName,
            element.workStreamDesc,
            element.country,
            element.subPlatformName,
            element.category,
            element.overallRiskLevel,
            element.workStatus,
            element.workPhase,
            element.workStreamReference,
            element.lePcCodeBuild,
            element.lePcCodeOperate,
            element.wsWorkManagerBu,
            element.wsWorkManagerTech,
            element.wsApprovalDate,
            element.wsStartDate,
            element.wsSwEngStartDate,
            element.wsGoLiveDate,
            element.wsEndDate,

            element.subWorkStreamId,
            element.subWorkStreamName,
            element.subWorkStreamDesc,
            element.deliveryPlatformName,
            element.abWork,
            element.subWorkStreamReference,
            element.swsWorkManagerBu,
            element.swsWorkManagerTech,
            element.swsStartDate,
            element.swsSwEngStartDate,
            element.swsGoLiveDate,
            element.reportingFlag,
            element.scenario,

            element.glGroup,
            element.glCategory,
            element.costType,
            element.costSettings,
          ])
          element.financialDatas.forEach(element => {
            elementData[i].push(element.value);
          });
          i++;
        });

        //worksheet.addRow(columns_9);
        //worksheet.addRow(columns_10);
        let headerRow = worksheet.addRow(columns_11);
        //worksheet.addRow(columns_12);
        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: '0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        this.applyWorkSheetStyles(worksheet);

        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Portfolio Financial Report 11' + EXCEL_EXTENSION);
          this.commonService.showSnackBar({ type: 'success', message: "Report Downloaded Succesfully", duration: 3000 });
        });
      }
      else {
       //worksheet.addRow(columns_9);
        //worksheet.addRow(columns_10);
        let headerRow = worksheet.addRow(columns_11);
        //worksheet.addRow(columns_12);
        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: '0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        this.applyWorkSheetStyles(worksheet);

        //worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Portfolio Financial Report 11' + EXCEL_EXTENSION);
          this.commonService.showSnackBar({ type: 'alert', message: "Data dosen't exist for the report", duration: 3000 });
        });
      }
    });
    this.dataService.loaderHandler(false);
  }
  exportReport_12() {
    this.dataService.loaderHandler(true);
    let date =['Download As Of Date',this.currentDate];
    this.isErrorExists = false;
    let columns_12 = [];
    let columns_11 = [];
    let columns_10 = [];
    let columns_9 = [];
    let reportingMonth = [];
    let currency = [];
    let workType = [];
    let location = [];
    let platformsData = [];
    let elementData = [];
    this.restService.post(URL_PREFIX.REPORTS + `/reports/portfolio/downloadReportData`, this.preparedData).subscribe(data => {
      reportingMonth = ['Reporting Month',];
      currency = ['Currency',];
      workType = ['Work Type',];
      location = ['Reporting Location',];
      platformsData = ['Platform Index & Name',];
      for (let i = 0; i <= this.selectedWorkType.length; i++) {
        if (this.selectedWorkType[i] === 'All WorkTypes') {
          workType.push(this.selectedWorkType[i]);
          break;
        }
        else {
          workType.push(this.selectedWorkType[i]);
        }
      }
      for (let i = 0; i <= this.selectedReportingLocations.length; i++) {
        if (this.selectedReportingLocations[i] === 'All Locations') {
          location.push(this.selectedReportingLocations[i]);
          break;
        }
        else {
          location.push(this.selectedReportingLocations[i]);
        }
      }
      for (let i = 0; i <= this.selectedPlatforms.length; i++) {
        if (this.selectedPlatforms[i] === 'All Platforms') {
          platformsData.push(this.selectedPlatforms[i]);
          break;
        }
        else {
          this.platformList.forEach(element => {
            if (this.selectedPlatforms[i] === element.value) {
              platformsData.push(element.value + '-' + element.display);
            }
          });
        }
      }
      this.SWSColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('SWS');
        columns_12.push('');
        columns_9.push('Non-Financial');
      });
      this.GlColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('SWS');
        columns_12.push('');
        columns_9.push('Financial');
      });
      let EXCEL_EXTENSION = '.xlsx';
      let workbook = new Excel.Workbook();
      let worksheet = workbook.addWorksheet('Report_12');
      worksheet.addRow(['Report 12', this.reportName]);
      worksheet.addRow(['']);
      //worksheet.addRow(['Scenario', '', this.portfolioReport.controls.scenario.value]);
      // worksheet.addRow(['Reporting Month', '', this.selectedMonth]);
      worksheet.addRow(['Currency',  this.portfolioReport.controls.currency.value]);
      worksheet.addRow(workType);
      worksheet.addRow(location);
      worksheet.addRow(platformsData);
      worksheet.addRow(date);
      worksheet.addRow(['']);

      if (data != "") {
        if (data[0].financialDatas) {
          data[0].financialDatas.forEach(element => {
            columns_11.push(element.fieldName);
            columns_12.push(element.dataType);
            columns_9.push('Financial');
            columns_10.push('SWS');
          });
        }
        let i = 0;
        data.forEach(element => {
          elementData.push([

            element.subWorkStreamId,
            element.subWorkStreamName,
            element.subWorkStreamDesc,
            element.deliveryPlatformName,
            element.abWork,
            element.subWorkStreamReference,
            element.swsWorkManagerBu,
            element.swsWorkManagerTech,
            element.swsStartDate,
            element.swsSwEngStartDate,
            element.swsGoLiveDate,
            element.reportingFlag,
            element.scenario,

            element.glGroup,
            element.glCategory,
            element.costType,
            element.costSettings,
          ])
          element.financialDatas.forEach(element => {
            elementData[i].push(element.value);
          });
          i++;
        });

       //worksheet.addRow(columns_9);
       // worksheet.addRow(columns_10);
        let headerRow = worksheet.addRow(columns_11);
        //worksheet.addRow(columns_12);
        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: '0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        this.applyWorkSheetStyles(worksheet);

        worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Portfolio Financial Report 12' + EXCEL_EXTENSION);
          this.commonService.showSnackBar({ type: 'success', message: "Report Downloaded Succesfully", duration: 3000 });
        });
      }
      else {
       //worksheet.addRow(columns_9);
        //worksheet.addRow(columns_10);
        let headerRow = worksheet.addRow(columns_11);
        //worksheet.addRow(columns_12);
        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFFFFFFF' },
            bgcolor: { argb: '0000FF' }
          };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });
        this.applyWorkSheetStyles(worksheet);

        // worksheet.addRows(elementData);
        workbook.xlsx.writeBuffer().then((data) => {
          let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Portfolio Financial Report 12' + EXCEL_EXTENSION);
          this.commonService.showSnackBar({ type: 'alert', message: "Data dosen't exist for the report", duration: 3000 });
        });
      }
    });
    this.dataService.loaderHandler(false);
  }
  exportReport_12a() {
    this.dataService.loaderHandler(true);
    let date =['Download As Of Date',this.currentDate];
    this.isErrorExists = false;
    let columns_12 = [];
    let columns_11 = [];
    let columns_10 = [];
    let columns_9 = [];
    let reportingMonth = [];
    let currency = [];
    let workType = [];
    let location = [];
    let platformsData = [];
    let elementData = [];

    const preparedData12a = {
      reportName: this.portfolioReport.controls.reportName.value,
      reportingMonth: '',
      currency: this.portfolioReport.controls.currency.value,
      //scenario: this.portfolioReport.controls.scenario.value,
      scenarios: this.scenariosformater,
      workTypes: this.workTypesformater,
      deliveryUnits: this.platformsformatter,
      platformIndices:[],
      reportingLocations: this.locationsformater,
      portfolios: this.showPortfolioList ? this.dataList : [],
      workStreamIds: this.showWSList ? this.dataList : [],
      subWorkStreamIds: this.showSWSList ? this.dataList : [],
    }
    this.restService.post(URL_PREFIX.REPORTS + `/reports/portfolio/downloadReportData`, preparedData12a).subscribe(data => {
      reportingMonth = ['Reporting Month',];
      currency = ['Currency', ];
      workType = ['Work Type', ];
      location = ['Reporting Location', ];
      platformsData = ['Platform Index & Name', ];
      for (let i = 0; i <= this.selectedWorkType.length; i++) {
        if (this.selectedWorkType[i] === 'All WorkTypes') {
          workType.push(this.selectedWorkType[i]);
          break;
        }
        else {
          workType.push(this.selectedWorkType[i]);
        }
      }
      for (let i = 0; i <= this.selectedReportingLocations.length; i++) {
        if (this.selectedReportingLocations[i] === 'All Locations') {
          location.push(this.selectedReportingLocations[i]);
          break;
        }
        else {
          location.push(this.selectedReportingLocations[i]);
        }
      }
      for (let i = 0; i <= this.selectedPlatforms.length; i++) {
        if (this.selectedPlatforms[i] === 'All Platforms') {
          platformsData.push(this.selectedPlatforms[i]);
          break;
        }
        else {
          this.platformList.forEach(element => {
            if (this.selectedPlatforms[i] === element.value) {
              platformsData.push(element.value + '-' + element.display);
            }
          });
        }
      }
      this.SWSColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('SWS');
        columns_12.push('');
        columns_9.push('Non-Financial');
      });
      this.GlColumns.forEach(element => {
        columns_11.push(element);
        columns_10.push('SWS');
        columns_12.push('');
        columns_9.push('Financial');
      });
      let EXCEL_EXTENSION = '.xlsx';
      let workbook = new Excel.Workbook();
      let worksheet = workbook.addWorksheet('Report_12a');
      worksheet.addRow(['Report 12a',  this.reportName]);
      worksheet.addRow(['']);
      //worksheet.addRow(['Scenario', '', this.portfolioReport.controls.scenario.value]);
      worksheet.addRow(['Currency', this.portfolioReport.controls.currency.value]);
      worksheet.addRow(workType);
      worksheet.addRow(location);
      worksheet.addRow(platformsData);
      worksheet.addRow(date);
      worksheet.addRow(['']);

      if(data !="")
      {
      if (data[0].financialDatas) {
        data[0].financialDatas.forEach(element => {
          columns_11.push(element.fieldName);
          columns_12.push(element.dataType);
          columns_9.push('Financial');
          columns_10.push('SWS');
        });
      }
      let i = 0;
      data.forEach(element => {
        elementData.push([

          element.subWorkStreamId,
          element.subWorkStreamName,
          element.subWorkStreamDesc,
          element.deliveryPlatformName,
          element.abWork,
          element.subWorkStreamReference,
          element.swsWorkManagerBu,
          element.swsWorkManagerTech,
          element.swsStartDate,
          element.swsSwEngStartDate,
          element.swsGoLiveDate,
          element.reportingFlag,
          element.scenario,

          element.glGroup,
          element.glCategory,
          element.costType,
          element.costSettings,
        ])
        element.financialDatas.forEach(element => {
          elementData[i].push(element.value);
        });
        i++;
      });
      
      //worksheet.addRow(columns_9);
      //worksheet.addRow(columns_10);
      let headerRow = worksheet.addRow(columns_11);
      //worksheet.addRow(columns_12);
      // Cell Style : Fill and Border
      headerRow.eachCell((cell, number) => {
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFFFFFFF' },
          bgcolor: { argb: '0000FF' }
        };
        cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
      });
      this.applyWorkSheetStyles(worksheet);

      worksheet.addRows(elementData);
      workbook.xlsx.writeBuffer().then((data) => {
        let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        saveAs(blob, 'Portfolio Financial Report 12a' + EXCEL_EXTENSION);
        this.commonService.showSnackBar({ type: 'success', message: "Report Downloaded Succesfully", duration: 3000 });
      });
    }
    else
    {
      //worksheet.addRow(columns_9);
      //worksheet.addRow(columns_10);
      let headerRow = worksheet.addRow(columns_11);
      //worksheet.addRow(columns_12);
      // Cell Style : Fill and Border
      headerRow.eachCell((cell, number) => {
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFFFFFFF' },
          bgcolor: { argb: '0000FF' }
        };
        cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
      });
      this.applyWorkSheetStyles(worksheet);

     // worksheet.addRows(elementData);
      workbook.xlsx.writeBuffer().then((data) => {
        let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        saveAs(blob, 'Portfolio Financial Report 12a' + EXCEL_EXTENSION);
        this.commonService.showSnackBar({ type: 'alert', message: "Data dosen't exist for the report", duration: 3000 });
      });
    }
    });
    this.dataService.loaderHandler(false);
  }
  getPlatformData() {
    this.restService.get(URL_PREFIX.REPORTS + '/reports/portfolio/platformDetailsForBankId?bankId=' + this.userOneBankId).subscribe(data => {
      if (data != null && data !== '') {
        this.platformList =[];
        this.platformList.push({ value: "All Platforms" });
        data.forEach(element => {
          this.platformList.push({ value: element.platformIndex, display: element.platformName });
        });
      }
    });
  }
  getDeliveryUnitData() {
    this.restService.get(URL_PREFIX.REPORTS + '/reports/portfolio/deliveryUnitsForBankId?bankId=' + this.userOneBankId).subscribe(data => {
      if (data != null && data !== '') {
        this.platformList =[];
        this.platformList.push({ value: "All Platforms" });
        data.forEach(element => {
          this.platformList.push({ value: element, display: element });
        });
      }
    });
  }
  onSelectReportName(name) {
    this.isReviewDetailsShow = false;
    this.selectedReportName = name.value;
    this.reportName = name.value.substring(name.value.indexOf(")") + 1, name.value.length)
    if (name.value === '7) Monthly - PF') {
      this.showPortfolioList = true;
      this.isAllPortfolioFields = true;
      this.isAllFieldsWS = false;
      this.isAllFieldsSWS = false;
    }
    else if (name.value === '8) Monthly - PF_WS') {
      this.showPortfolioList = true;
      this.isAllFieldsWS = true;
      this.isAllFieldsSWS = false;
      this.isAllPortfolioFields = true;
    }
    else if (name.value === '9) Monthly - PF_WS_SWS') {
      this.showPortfolioList = true;
      this.isAllFieldsWS = true;
      this.isAllFieldsSWS = true;
      this.isAllPortfolioFields = true;
    }
    else if (name.value === '10) Monthly - PF_SWS') {
      this.showPortfolioList = true;
      this.isAllPortfolioFields = true;
      this.isAllFieldsWS = false;
      this.isAllFieldsSWS = true;
    }
    else {
      this.showPortfolioList = false;
    }

    if (name.value === '11) Monthly - WS_SWS') {
      this.showWSList = true
      this.isAllFieldsWS = true;
      this.isAllFieldsSWS = true;
      this.isAllPortfolioFields = false;
    }
    else {
      this.showWSList = false;
    }
     if (name.value === '12) Monthly - SWS' || name.value === '12a) Monthly - SWS_C-Work') {
      // if (name.value === '12) Monthly - SWS') {
      this.showSWSList = true;
      this.isAllPortfolioFields = false;
      this.isAllFieldsWS = false;
      this.isAllFieldsSWS = true;
    }
    else {
      this.showSWSList = false;
    }
    if(name.value === '12a) Monthly - SWS_C-Work')
    {
      this.getDeliveryUnitData();
      this.showDeliveryList = true;
      this.selectedPlatforms=[];
      this.platformsformatter = [];
      this.portfolioReport.controls.platformIndex.setValue('');
    }
    else{
      this.platformsformatter = [];
      this.selectedPlatforms=[];
      this.showDeliveryList = false;
      this.portfolioReport.controls.platformIndex.setValue('');
      this.getPlatformData();
      //this.showSWSList = false;
    }
    const reportName = {
      reportName: this.selectedReportName,
    }
    // ScenarioDropdown
    this.restService.post(URL_PREFIX.REPORTS + '/reports/portfolio/scenariosForReportName', reportName).subscribe(data => {
      this.scenarioDropDown = [];
      if (data != null && data !== '') {
        this.scenarioDropDown.push({value: 'All Scenarios'});
        data.forEach(element => {
          this.scenarioDropDown.push({ value: element, display: element });
        });
      }
    });
  }
  // onSelectMonth(month) {
  //   this.selectedMonth = month.value;

  //   const reportingYear = month.value.substring(0, 4);
  //   let reportingMonth = month.value.substring(4, 6);
  //   if (reportingMonth && reportingMonth.charAt(0) === 0) {
  //     reportingMonth = reportingMonth.charAt(1);
  //   }
  //   this.selectedMonth = `${reportingYear} ${this.months[reportingMonth - 1]}`;
  // }

  applyWorkSheetStyles(worksheet) {
    worksheet.getCell('A1').font = { size: 16, bold: true };
    worksheet.getCell('B1').font = { size: 12, bold: true };
    worksheet.getCell('C1').font = { size: 16, bold: true };
    worksheet.getCell('D1').font = { size: 12, bold: true };
    worksheet.getCell('E1').font = { size: 12, bold: true };
    worksheet.getCell('F1').font = { size: 12, bold: true };
    worksheet.getCell('G1').font = { size: 12, bold: true };

    worksheet.getCell('A3').font = { size: 12, bold: true };

    worksheet.getCell('A4').font = { size: 12, bold: true };

    worksheet.getCell('A5').font = { size: 12, bold: true };

    worksheet.getCell('A6').font = { size: 12, bold: true };

    worksheet.getCell('A7').font = { size: 12, bold: true };

    worksheet.getCell('A8').font = { size: 12, bold: true };
  }

  allHandler(e, flag) {
    switch (flag) {
      case 'portfolioLst':
        if (e.source.value === "All") {
          if (e.checked == true) {
            this.selectedPortfolios = [];
            this.portfolioDropDown.forEach(element => {
              this.selectedPortfolios.push(element.value);
            });
          } else if (e.checked == false) {
            this.selectedPortfolios = [];
            this.portfolioReport.controls.portfolios.setValue('');
          }
        }
        else {
          if (e.checked == true) {
            this.portfolioSelected = true;
            this.selectedPortfolios.push(e.source.value);
          } else if (e.checked == false) {
            if (this.selectedPortfolios.indexOf(e.source.value) != -1) {
              this.selectedPortfolios.splice(this.selectedPortfolios.indexOf(e.source.value), 1);
            }
          }
          if (this.selectedPortfolios.length > 0) {
            this.selectedPortfolios.forEach(element => {
              this.portfolioReport.controls.portfolios.patchValue(element);
            });
          }
          else {
            this.portfolioReport.controls.portfolios.setValue('');
          }
        }
        break;
      case 'workstreamLst':
        if (e.source.value === "All") {
          if (e.checked == true) {
            this.selectedPortfolios = [];
            this.workstreamDropDown.forEach(element => {
              this.selectedPortfolios.push(element.value);
            });
          } else if (e.checked == false) {
            this.selectedPortfolios = [];
            this.portfolioReport.controls.portfolios.setValue('');
          }
        }
        else {
          if (e.checked == true) {
            this.portfolioSelected = true;
            this.selectedPortfolios.push(e.source.value);
          } else if (e.checked == false) {
            if (this.selectedPortfolios.indexOf(e.source.value) != -1) {
              this.selectedPortfolios.splice(this.selectedPortfolios.indexOf(e.source.value), 1);
            }
          }
          if (this.selectedPortfolios.length > 0) {
            this.selectedPortfolios.forEach(element => {
              this.portfolioReport.controls.portfolios.patchValue(element);
            });
          }
          else {
            this.portfolioReport.controls.portfolios.setValue('');
          }
        }
        break;
      case 'subWkstreamLst':
        if (e.source.value === "All") {
          if (e.checked == true) {
            this.selectedPortfolios = [];
            this.subWorkstreamDropDown.forEach(element => {
              this.selectedPortfolios.push(element.value);
            });
          } else if (e.checked == false) {
            this.selectedPortfolios = [];
            this.portfolioReport.controls.portfolios.setValue('');
          }
        }
        else {
          if (e.checked == true) {
            this.portfolioSelected = true;
            this.selectedPortfolios.push(e.source.value);
          } else if (e.checked == false) {
            if (this.selectedPortfolios.indexOf(e.source.value) != -1) {
              this.selectedPortfolios.splice(this.selectedPortfolios.indexOf(e.source.value), 1);
            }
          }
          if (this.selectedPortfolios.length > 0) {
            this.selectedPortfolios.forEach(element => {
              this.portfolioReport.controls.portfolios.patchValue(element);
            });
          }
          else {
            this.portfolioReport.controls.portfolios.setValue('');
          }
        }
        break;
      case 'platformList':
        if (e.source.value === "All Platforms") {
          if (e.checked == true) {
            this.selectedPlatforms = [];
            this.platformNames = [];
            this.platformList.forEach(element => {
              this.selectedPlatforms.push(element.value);
              this.platformNames.push(element.display);
            });
          } else if (e.checked == false) {
            this.selectedPlatforms = [];
            this.portfolioReport.controls.platformIndex.setValue('');
          }
        }
        else {
          if (e.checked == true) {
            this.selectedPlatforms.push(e.source.value);
          } else if (e.checked == false) {
            if (this.selectedPlatforms.indexOf(e.source.value) != -1) {
              this.selectedPlatforms.splice(this.selectedPlatforms.indexOf(e.source.value), 1);
            }
          }
          if (this.selectedPlatforms.length > 0) {
            this.platformNames = [];
            this.selectedPlatforms.forEach(element => {
              this.portfolioReport.controls.platformIndex.patchValue(element);
              this.platformList.forEach(pn => {
                if (element == pn.value) {
                  this.platformNames.push(pn.display);
                }
              });
            });
          }
          else {
            this.portfolioReport.controls.platformIndex.setValue('');
          }
        }
        if (this.selectedPlatforms.indexOf('All Platforms') != -1) {
          this.portfolioReport.controls.platformIndex.setValue('All Platforms');
        }
        this.platformsformatter = [];
        this.selectedPlatforms.forEach(element => {
          this.platformsformatter.push(element);
        });
        if (this.platformsformatter.indexOf('All Platforms') != -1) {
          this.platformsformatter.splice(this.platformsformatter.indexOf('All Platforms'), 1)
        }
        break;
      case 'locationList':
        if (e.source.value === "All Locations") {
          if (e.checked == true) {
            this.selectedReportingLocations = [];
            this.ReportingLocationDropDown.forEach(element => {
              this.selectedReportingLocations.push(element.value);
            });
          } else if (e.checked == false) {
            this.selectedReportingLocations = [];
            this.portfolioReport.controls.reportingLocation.setValue('');
          }
        }
        else {
          if (e.checked == true) {
            this.selectedReportingLocations.push(e.source.value);
          } else if (e.checked == false) {
            if (this.selectedReportingLocations.indexOf(e.source.value) != -1) {
              this.selectedReportingLocations.splice(this.selectedReportingLocations.indexOf(e.source.value), 1);
            }
          }
          if (this.selectedReportingLocations.length > 0) {
            this.selectedReportingLocations.forEach(element => {
              this.portfolioReport.controls.reportingLocation.patchValue(element);
            });
          }
          else {
            this.portfolioReport.controls.reportingLocation.setValue('');
          }
        }
        if (this.selectedReportingLocations.indexOf('All Locations') != -1) {
          this.portfolioReport.controls.reportingLocation.setValue('All Locations');
        }
        this.locationsformater = [];
        this.selectedReportingLocations.forEach(element => {
          this.locationsformater.push(element);
        });
        if (this.locationsformater.indexOf('All Locations') != -1) {
          this.locationsformater.splice(this.locationsformater.indexOf('All Locations'), 1)
        }
        break;
      case 'scenarioList':
        if (e.source.value === "All Scenarios") {
          if (e.checked == true) {
            this.selectedScenarios = [];
            this.scenarioDropDown.forEach(element => {
              this.selectedScenarios.push(element.value);
            });
          } else if (e.checked == false) {
            this.selectedScenarios = [];
            this.portfolioReport.controls.scenario.setValue('');
          }
        }
        else {
          if (e.checked == true) {
            this.selectedScenarios.push(e.source.value);
          } else if (e.checked == false) {
            if (this.selectedScenarios.indexOf(e.source.value) != -1) {
              this.selectedScenarios.splice(this.selectedScenarios.indexOf(e.source.value), 1);
            }
          }
          if (this.selectedScenarios.length > 0) {
            this.selectedScenarios.forEach(element => {
              this.portfolioReport.controls.scenario.patchValue(element);
            });
          }
          else {
            this.portfolioReport.controls.scenario.setValue('');
          }
        }
        if (this.selectedScenarios.indexOf('All Scenarios') != -1) {
          this.portfolioReport.controls.scenario.setValue('All Scenarios');
        }
        this.scenariosformater = [];
        this.selectedScenarios.forEach(element => {
          this.scenariosformater.push(element);
        });
        if (this.scenariosformater.indexOf('All Scenarios') != -1) {
          this.scenariosformater.splice(this.scenariosformater.indexOf('All Scenarios'), 1)
        }
        break;
        case 'workTypeList':
        if (e.source.value === "All WorkTypes") {
          if (e.checked == true) {
            this.selectedWorkType = [];
            this.workTypeDropDown.forEach(element => {
              this.selectedWorkType.push(element.value);
            });
          } else if (e.checked == false) {
            this.selectedWorkType = [];
            this.portfolioReport.controls.workType.setValue('');
          }
        }
        else {
          if (e.checked == true) {
            this.selectedWorkType.push(e.source.value);
          } else if (e.checked == false) {
            if (this.selectedWorkType.indexOf(e.source.value) != -1) {
              this.selectedWorkType.splice(this.selectedWorkType.indexOf(e.source.value), 1);
            }
          }
          if (this.selectedWorkType.length > 0) {
            this.selectedWorkType.forEach(element => {
              this.portfolioReport.controls.workType.patchValue(element);
            });
          }
          else {
            this.portfolioReport.controls.workType.setValue('');
          }
        }
        if (this.selectedWorkType.indexOf('All WorkTypes') != -1) {
          this.portfolioReport.controls.workType.setValue('All WorkTypes');
        }
        this.workTypesformater = [];
        this.selectedWorkType.forEach(element => {
          this.workTypesformater.push(element);
        });
        if (this.workTypesformater.indexOf('All WorkTypes') != -1) {
          this.workTypesformater.splice(this.workTypesformater.indexOf('All WorkTypes'), 1)
        }
        break;
    }
    if (this.selectedPortfolios.indexOf('All') != -1) {
      this.portfolioReport.controls.portfolios.setValue('All');
    }
    this.dataList = [];
    this.selectedPortfolios.forEach(element => {
      this.dataList.push(element);
    });
    if (this.dataList.indexOf('All') != -1) {
      this.dataList.splice(this.dataList.indexOf('All'), 1)
    }
  }
}
