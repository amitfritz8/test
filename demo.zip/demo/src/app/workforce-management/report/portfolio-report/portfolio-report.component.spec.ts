import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import * as Excel from 'exceljs/dist/exceljs.min.js';
import { PortfolioReportComponent } from './portfolio-report.component';
import { DataService } from 'src/app/common/service/data.service';
import { HttpClientModule } from '@angular/common/http';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {BrowserModule} from '@angular/platform-browser';
import { MaterialModule } from 'src/app/material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {configureTestSuite} from 'ng-bullet';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';
import { RestService } from 'src/app/common/service/rest.service';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { TimeFormat } from 'src/app/common/pipes/timeFormater.pipe';
import { ConfirmDialogComponent } from 'src/app/common/component/dialogues/confirm-dialog/confirm-dialog-component';

xdescribe('PortfolioReportComponent', () => {
  let component: PortfolioReportComponent;
  let fixture: ComponentFixture<PortfolioReportComponent>;


  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [PortfolioReportComponent],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [MaterialModule, FormsModule,ReactiveFormsModule, HttpClientTestingModule,
        RouterTestingModule,BrowserAnimationsModule],
      providers: [{provide: RestService, useClass: MockRestService},
        { provide: DateUtility, useClass: MockDateUtility },
        { provide: TimeFormat, useClass: MockTimeFormat },
        DataService]
    })
    fixture = TestBed.createComponent(PortfolioReportComponent);
    component = fixture.componentInstance;
  });

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ PortfolioReportComponent ],
//       schemas: [NO_ERRORS_SCHEMA],
//       imports: [BrowserAnimationsModule,
//         MaterialModule,
//         FormsModule,
//         ReactiveFormsModule,
//         BrowserModule, HttpClientModule],
//       providers: [
//         DataService]
//     })
//     .compileComponents();
//   }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PortfolioReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

    it('should create', () => {
    expect(component).toBeTruthy();
  });
  // it('should call for export', (done: DoneFn) => {
  //   spyOn(component, 'export').and.callThrough();
  //   component.export();
  //   expect(component.export).toHaveBeenCalled();
  //   done();
  // });
  // it('should call for reviewDetails', (done: DoneFn) => {
  //   spyOn(component, 'reviewDetails').and.callThrough();
  //   component.reviewDetails();
  //   expect(component.reviewDetails).toHaveBeenCalled();
  //   done();
  // });
  // it('should call for export', (done: DoneFn) => {
  //   component.selectedReportName = '7) Monthly - PF';
  //   spyOn(component, 'export').and.callThrough();
  //   component.export();
  //   expect(component.export).toHaveBeenCalled();
  //   done();
  // });
  // it('should call for export', (done: DoneFn) => {
  //   component.selectedReportName = '7) Monthly - PF';
  //   spyOn(component, 'export').and.callThrough();
  //   component.export();
  //   expect(component.export).toHaveBeenCalled();
  //   done();
  // });
  // it('should call for export', (done: DoneFn) => {
  //   component.selectedReportName = '7) Monthly - PF';
  //   spyOn(component, 'export').and.callThrough();
  //   component.export();
  //   expect(component.export).toHaveBeenCalled();
  //   done();
  // });
  // it('should call for export', (done: DoneFn) => {
  //   component.selectedReportName = '8) Monthly - PF + WS';
  //   spyOn(component, 'export').and.callThrough();
  //   component.export();
  //   expect(component.export).toHaveBeenCalled();
  //   done();
  // });
  // it('should call for export', (done: DoneFn) => {
  //   component.selectedReportName = '9) Monthly - PF + WS + SWS';
  //   spyOn(component, 'export').and.callThrough();
  //   component.export();
  //   expect(component.export).toHaveBeenCalled();
  //   done();
  // });
  // it('should call for export', (done: DoneFn) => {
  //   component.selectedReportName = '10) Monthly - PF + SWS';
  //   spyOn(component, 'export').and.callThrough();
  //   component.export();
  //   expect(component.export).toHaveBeenCalled();
  //   done();
  // });
  // it('should call for export', (done: DoneFn) => {
  //   component.selectedReportName = '11) Monthly - WS + SWS';
  //   spyOn(component, 'export').and.callThrough();
  //   component.export();
  //   expect(component.export).toHaveBeenCalled();
  //   done();
  // });
  // it('should call for export', (done: DoneFn) => {
  //   component.selectedReportName = '12) Monthly - SWS';
  //   spyOn(component, 'export').and.callThrough();
  //   component.export();
  //   expect(component.export).toHaveBeenCalled();
  //   done();
  // });
  it('should call for onSelectReportName', (done: DoneFn) => {
    const name = { 'value': '7) Monthly - PF'};
    component.selectedReportName = '7) Monthly - PF';
    spyOn(component, 'onSelectReportName').and.callThrough();
    component.onSelectReportName(name);
    expect(component.onSelectReportName).toHaveBeenCalled();
    done();
  });
  it('should call for applyWorkSheetStyles', (done: DoneFn) => {
    let workbook = new Excel.Workbook();
      let worksheet = workbook.addWorksheet('Report_7');
    spyOn(component, 'applyWorkSheetStyles').and.callThrough();
    component.applyWorkSheetStyles(worksheet);
    expect(component.applyWorkSheetStyles).toHaveBeenCalled();
    done();
  });
  it('should call for onSelectReportName', (done: DoneFn) => {
    const element =  {'value': '8) Monthly - PF + WS'};
    spyOn(component, 'onSelectReportName').and.callThrough();
    component.onSelectReportName(element);
    expect(component.onSelectReportName).toHaveBeenCalled();
    done();
  });
  it('should call for onSelectReportName', (done: DoneFn) => {
    const element = {'value': '9) Monthly - PF + WS + SWS'}
    spyOn(component, 'onSelectReportName').and.callThrough();
    component.onSelectReportName(element);
    expect(component.onSelectReportName).toHaveBeenCalled();
    done();
  });
  it('should call for onSelectReportName', (done: DoneFn) => {
    const element = {'value': '10) Monthly - PF + SWS'}
    spyOn(component, 'onSelectReportName').and.callThrough();
    component.onSelectReportName(element);
    expect(component.onSelectReportName).toHaveBeenCalled();
    done();
  });
  it('should call for onSelectReportName', (done: DoneFn) => {
    const element =  {'value': '11) Monthly - WS + SWS'}
    spyOn(component, 'onSelectReportName').and.callThrough();
    component.onSelectReportName(element);
    expect(component.onSelectReportName).toHaveBeenCalled();
    done();
  });
  it('should call for onSelectReportName', (done: DoneFn) => {
    const element =  {'value': '12) Monthly - SWS'}
    spyOn(component, 'onSelectReportName').and.callThrough();
    component.onSelectReportName(element);
    expect(component.onSelectReportName).toHaveBeenCalled();
    done();
  });



});
class MockRestService {
  get() {
    return of([{'platformId': '1', 'platformIndex': '01', 'platform': 'test platform'}]);
  }

  put() {
    return of({});
  }

  post() {
    return of([{}]);
  }
  track(pageName: string) {
    return null;
  }
}


class MockRouter {
  navigateByUrl(url: any) {
    return null;
  }
}

class MockDateUtility {
  dateFormatterCustom(date?: Date) {
    return '';
  }
}

class MockTimeFormat {
  transform(date?: Date) {
    return '';
  }
}

