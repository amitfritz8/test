import { NgModule } from "@angular/core";
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/common/module/shared.module';
import { PortfolioReportComponent } from "./portfolio-report/portfolio-report.component";
import { WorkForceReportComponent } from "./workforce-report/workforce-report.component";
import { ReportComponent } from "./report.component";

const routes: Routes = [
    {
        path: "",
        component: ReportComponent
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        SharedModule
    ],
    declarations:[
        ReportComponent,
        WorkForceReportComponent,
        PortfolioReportComponent
    ],
    exports: [
    ],
    entryComponents: []
})

export class ReportModule { }
