import {Component, OnInit, ViewChild, AfterContentInit} from '@angular/core';
import {Chart, ChartConfiguration} from 'chart.js';
import {ActivatedRoute, Router} from '@angular/router';
import {RadialGaugeComponent} from '@progress/kendo-angular-gauges';
import * as _ from 'lodash';
import {RestService} from '../../common/service/rest.service';
import { CommonService } from '../../common/service/common.service';
import * as moment from 'moment';

@Component({
    selector: 'app-people',
    templateUrl: './people-dashboard.component.html',
    styleUrls: ['./people-dashboard.component.scss']
})
export class PeopleComponent implements AfterContentInit, OnInit{

  canvas: any;
  ctx: any;

  @ViewChild('kendo', {static: false}) kendo: RadialGaugeComponent;

  pointerVariable = {
    value: 0
  };

  offsetHeight = 0;
  platforms: string[];
  lobts: string[];
  locations: string[];

  allList: AllList[] = [];
  parentList: AllList[] = [];
  childList: AllList[] = [];
  platformList: any[] = [];
  techUnitsPlatforms: any[] = [];
  platformNames: any[] = [];
  lobtNames: any[] = [];

  totalCount = 0;
  noOfPills = 20;
  maxLength = 0;
  maxVendor = 0;
  maxWorkLocation = 0;
  activeResourceCount = 0;
  totalBudget = 0;
  hiredResources = 0;
  resourceOnNotice = 0;
  balancetoHire = 0;
  resourceOthers = 0;
  seedResource = 0;
  attachmentResource = 0;
  countdbsResource = 0;
  sANonTacoResource = 0;
  mSNonTacoResource = 0;
  onShoreWorkLocationCount = 0;
  offShoreWorkLocationCount = 0;
  actualHCChart: ActualHCChart[] = [];
  actualWorkLocation: ActualWorkLocation[] = [];
  resourceDBS = 0;
  resourceMS = 0;
  resourceSA = 0;
  resourceOnshore = 0;
  resourceOffshore = 0;
  resourceDBSOnshore = 0;
  resourceMSOnshore = 0;
  resourceSAOnshore = 0;
  resourceDBSOffshore = 0;
  resourceMSOffshore = 0;
  resourceSAOffshore = 0;
  totalWorkLocation = 0;

  resourceScopeRun = 0;
  resourceScopeChange = 0;
  resourceScopeRunOnshore = 0;
  resourceScopeChangeOnshore = 0;
  resourceScopeRunOffshore = 0;
  resourceScopeChangeOffshore = 0;

  green = 0;
  yellow = 0;
  red = 0;

  myChartOnshoreOffshore: any;
  myChart: any;
  myStackedBar: any;
  pieResource: any;
  pieResourceOnOffShore: any;
  pieResourceOnShore: any;
  pieResourceOffShore: any;
  pieRun: any;
  pieRunOnOffShore: any;
  pieRunOffShore: any;
  pieRunOnShore: any;
  barGraph: any;
  workLocationGraph: any;
  totalDBSResource: number;
  totalRun: number;
  buttonText: string;

  canvasWidth = 300;
  public needleValue: any;
  centralLabel = '';
  name = 'Actual HC against Approved Capacity';
  bottomLabel: any;
  arcColor: any = '#94BED8';
  response: any[];
  vendorList: any;
  workLocationList: any = [];
  displayLocationList: any = [];
  isAdmin = false;
  selectedPlatforms: any = [];
  approvedCapacity: any = [];
  vendorInfo: any = [];
  workLocationInfo = [];
  headCountSnapshotResources: IHeadCount[] = [];

  selectedDate: string;
  dates: any;
  months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  high = false;
  maxSpeedometer = 120;
  reportingPeriod: string;
  previousYear: string;
  lobtLength = [];
  platformCountBasedOnLOBT = [];
  densityData = null;
  bd11Msg = '';

  constructor(private restService: RestService, private route: ActivatedRoute, private router: Router,
              private commonService: CommonService) {
    this.commonService.setDocumentTitle('DASHBOARD');
    this.commonService.trackPageView();
    this.restService.track('DASHBOARD');
  }

  ngAfterContentInit(){
     this.offsetHeight = document.getElementById("header").offsetHeight + document.getElementById("stickyChips").offsetHeight;
  }


  ngOnInit() {
    this.commonService.recieveMessage({
      title:"People Dashboard"
    });
    this.commonService.broadCastMessage.subscribe(data => {
      this.handleReportingPeriod();
    });
    this.high = false;
    this.maxSpeedometer = 120;
    this.handleReportingPeriod();
    this.showMore();
  }

  showMore() {
    if (this.parentList.length === 0) {
      this.buttonText = '';
    } else if (this.parentList.length <= this.noOfPills) {
      this.parentList = this.allList;
      this.buttonText = 'See less';
    } else {
      this.parentList = this.childList;
      this.buttonText = 'See all';
    }
  }

  getData() {
    this.lobtLength = [];
    this.techUnitsPlatforms = JSON.parse(sessionStorage.getItem('techUnitsAndPlatforms'));
    const platformArrays = this.techUnitsPlatforms ? Object.values(this.techUnitsPlatforms) : [];

    if (platformArrays) {
      platformArrays.forEach(element => {
        if (element[0] && element[0].techUnit) {
          this.lobtLength.push({techUnit: element[0].techUnit, length: element.length});
        }
      });
    }
    // api call for platform names
   // this.restService.get(`/people/data/platforms`).subscribe(data => {
    this.restService.get('assets/json/mock/platforms.json').subscribe(data => {
      this.response = data;
      this.platformList = this.response;

      this.platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
      this.lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
      this.locations = JSON.parse(sessionStorage.getItem('locations'));
      if (this.selectedDate) {
        let month: string = '0' + (this.months.indexOf(this.selectedDate.substring(5, this.selectedDate.length)) + 1);
        let year: string = this.selectedDate.substring(0, 4);
        this.reportingPeriod = year + '' + month.slice(-2);
      }

      // saving the platformNames into the List
      this.savePlatformsNamesList();

      //parent list for the displaying pills
      this.parentListForDisplayingPills();

      // api call for data
      if (this.platforms && this.lobts && this.locations) {
        //this.restService.post(`/people/team/dashboard/head-count`, {
        this.restService.get('assets/json/mock/head-count.json', {
          techUnits: this.lobts,
          platforms: this.platforms,
          location: this.locations,
          rptPeriod: this.reportingPeriod
        }).subscribe(data => {

          //Call to get the Vendor info
          this.getVendorInfo(data);

          // Call for Headcount forecastGraph data
          this.getHeadCountForecastInfo();
          this.getWorkLocationInfo(data);
        });
      }
    });
  }

  getHeadCountForecastInfo() {
    this.previousYear = (parseInt(this.reportingPeriod.substr(0, 4)) - 1).toString();
    //this.restService.post(`/people/team/dashboard/head-count-budget`, {
    this.restService.get('assets/json/mock/head-count-budget.json', {
      techUnits: this.lobts,
      platforms: this.platforms,
      location: this.locations,
      rptPeriod: this.reportingPeriod
    }).subscribe(data => {
      this.headCountSnapshotResources = data;
     // this.restService.post(`/people/team/dashboard/head-count-budget/approved`, {
      this.restService.get('assets/json/mock/approved.json', {
        techUnits: this.lobts,
        platforms: this.platforms,
        location: this.locations,
        rptPeriod: this.reportingPeriod
      }).subscribe(data => {
        this.approvedCapacity = data;
        this.stackedBarChart();
      });
    });
  }

  getVendorInfo(data) {
    this.response = data;
    // this.headCountSnapshotResources = data.headCountSnapshotResources;
    this.response.forEach((a) => {
      a['checked'] = true;
    });
    this.selectedPlatforms = this.response;
    //this.restService.post(`/people/team/dashboard/top-vendor-count`, {
    this.restService.get('assets/json/mock/top-vendor-count.json', {
      techUnits: this.lobts,
      platforms: this.platforms,
      location: this.locations,
      rptPeriod: this.reportingPeriod
    }).subscribe(data => {
      this.vendorInfo = data;
      this.getVendorGraphForSelectedPlatform();
    });

    this.intialSetup();
  }

  savePlatformsNamesList() {
    this.platformNames = [];
    this.platformList.forEach(plList => {
      if (this.platforms) {
        this.platforms.forEach(pl => {
          if (plList.platformIndex === pl) {
            this.platformNames.push({platformName: plList.platformName, techUnit: plList.techunitCode, length: 0});
          }
        });
      }
    });

    this.lobtLength.forEach(plList => {
      this.platformNames.forEach(pl => {
        if (plList.techUnit === pl.techUnit) {
          pl.length = plList.length;
        }
      });
    });

    this.lobtNames = [];
    this.lobtLength.forEach(plList => {
      this.lobts.forEach(pl => {
        if (plList.techUnit === pl) {
          this.lobtNames.push({techUnit: plList.techUnit, length: plList.length});
        }
      });
    });

    this.platformCountBasedOnLOBT = this.lobtLength;
    this.platformCountBasedOnLOBT.forEach(lobt => {
      lobt.length = 0;
    });
    this.platformNames.forEach(pl => {
      this.platformCountBasedOnLOBT.forEach(plcount => {
        if (plcount.techUnit === pl.techUnit) {
          plcount.length = plcount.length + 1;
        }
      });
    });
  }

  parentListForDisplayingPills() {
    this.allList = [];

    let count = 0;
    let isLength = false;

    if (this.platformNames && this.platformNames.length > 0) {
      this.platformNames.sort((a, b) => (a.platformName > b.platformName) ? 1 : ((b.platformName > a.platformName) ? -1 : 0));
    }
    if (this.locations && this.locations.length > 0) {
      this.locations.sort((a, b) => (a > b) ? 1 : ((b > a) ? -1 : 0));
    }
    if (this.lobts && this.lobts.length > 0) {
      this.lobtNames.sort((a, b) => (a.techUnit > b.techUnit) ? 1 : ((b.techUnit > a.techUnit) ? -1 : 0));
    }

    if (this.locations) {
      this.locations.forEach(element => {
        this.allList.push({type: 'location', value: element, bgColor: 'rgb(209, 223, 229)', isLobt: false, allPlatForms: false, isPlatForm: false});
      });
    }

    if (this.lobtNames) {
      count = 0;
      this.lobtNames.forEach(element => {
        isLength = false;
        this.platformCountBasedOnLOBT.forEach(plcount => {
          if (element.techUnit === plcount.techUnit && element.length === plcount.length) {
            isLength = true;
          }
        });
        this.allList.push({type: 'lobt', value: element.techUnit, bgColor: 'rgb(208, 224, 210)', isLobt: true, allPlatForms: isLength, isPlatForm: false});
      });
    }

    if (this.platformNames) {
      this.platformNames.forEach(element => {
        isLength = false;
        this.platformCountBasedOnLOBT.forEach(plcount => {
          if (element.techUnit === plcount.techUnit && element.length === plcount.length) {
            isLength = true;
          }
        });
        this.allList.push({type: 'platform', value: element.platformName, bgColor: '#e7e7e7', isLobt: false, allPlatForms: false, isPlatForm: isLength});
      });
    }

    this.childList = [];
    this.totalCount = 0;
    this.allList.forEach(list => {
      if (!list.isPlatForm) {
        this.totalCount = this.totalCount + 1;
      }
    });
    count = 0;
    if (this.allList) {
      this.allList.forEach(list => {
        if (count < this.noOfPills && !list.isPlatForm) {
          this.childList.push(list);
          count = count + 1;
        }
      });
      this.parentList = this.childList;
      this.buttonText = 'See all';
    } else {
      this.allList.push({type: 'nullCheck', value: 'Nothing is selected...', bgColor: '#ffffff', isLobt: false, allPlatForms: false, isPlatForm: true});
    }
  }

  onReportingPeriodChnage() {
    sessionStorage.setItem('reportingPeriodDate', JSON.stringify(this.selectedDate));
    this.checkForBD();
    this.getData();
  }

  checkForBD() {
    const currentMonth = Number(moment(new Date()).format('MM'));
    const currentYear = Number(moment(new Date()).format('YYYY'));
    const currentDay = Number(moment(new Date()).format('DD'));
    let month: string;
    let year: string;
    if (this.selectedDate) {
      month = '0' + (this.months.indexOf(this.selectedDate.substring(5, this.selectedDate.length)) + 1);
      year = this.selectedDate.substring(0, 4);
      this.reportingPeriod = year + '' + month.slice(-2);
    }
    if (Number(year) == currentYear) {
      if (currentDay <= 15 && Number(month) == (currentMonth - 1)) {
        this.restService.get(`people/data/employee/messagepeopledata`).subscribe(data => {
          this.bd11Msg = data;
        })
      } else {
        this.bd11Msg = '';
      }
    } else if (Number(year) == (currentYear - 1) && currentMonth == 1) {
      if (currentDay <= 15 && month == '012') {
        this.restService.get(`people/data/employee/messagepeopledata`).subscribe(data => {
          this.bd11Msg = data;
        })
      } else {
        this.bd11Msg = '';
      }
    } else {
      this.bd11Msg = '';
    }
  }

  handleReportingPeriod() {
    const platform = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    const reportingPeriodDate = JSON.parse(sessionStorage.getItem('reportingPeriodDate'));
    if (reportingPeriodDate) {
      this.selectedDate = reportingPeriodDate;
    }
    if (lobts && platform && locations) {
     // this.restService.post(`people/data/employee/getreportmonthyear`, {
      this.restService.get('assets/json/mock/getreportmonthyear.json', {
        techUnits: lobts,
        platforms: platform,
        location: locations
      }).subscribe(data => {
        if (data) {
          this.dates = [];
          data.forEach(ele => {
            const reportingYear = ele.substring(0, 4);
            let reportingMonth = ele.substring(4, 6);
            // Taking reporting month without 0.
            if (reportingMonth && reportingMonth.charAt(0) === 0) {
              reportingMonth = reportingMonth.charAt(1);
            }
            this.dates.push(`${reportingYear} ${this.months[reportingMonth - 1]}`);
          });
        }
        const currentMonth = Number(moment(new Date()).format('MM'));
        const currentYear = moment(new Date()).format('YYYY');
        const currentDay = Number(moment(new Date()).format('DD'));
        if (!reportingPeriodDate) {
          if (currentDay >= 15) {
            this.selectedDate = currentYear + ' ' + this.months[currentMonth - 2];
          } else {
            this.selectedDate = currentYear + ' ' + this.months[currentMonth - 3];
          }
          const selectedDatePresent = this.dates.includes(this.selectedDate);
          if (!selectedDatePresent) {
            this.selectedDate = this.dates[0];
          }
          sessionStorage.setItem('reportingPeriodDate', JSON.stringify(this.selectedDate));
        }
        this.getData();
      });
      this.checkForBD();
    }
    // Adding this for UAT only.
    // this.selectedDate = '2019 August';
  }

  getVendorGraphForSelectedPlatform() {
    this.vendorList = [];
    let tempVendorList = [];
    for (let pltfrm in this.vendorInfo) {
      this.selectedPlatforms.find(platform => {
        if ((platform['platformIndex'].toLowerCase() === pltfrm.toLowerCase()) && platform['checked']) {
          this.vendorInfo[pltfrm].forEach(element => {
            tempVendorList.push({vendor: element['vendor'], count: element['activeCount']});
          });
        }
      })
    }

    let test = _.groupBy(tempVendorList, 'vendor');
    for (var v in test) {
      test[v]['count'] = 0;
      test[v].forEach(element => {
        test[v]['count'] = test[v]['count'] + element['count'];
      })
      this.vendorList.push({vendor: v, count: test[v]['count']});
    }
    this.vendorList.sort((c, n) => n.count - c.count);

    if (this.vendorList && this.vendorList.length > 0) {
      let remainder = this.vendorList[0].count;
      let ranger;
      ranger = remainder / 100;
      if (ranger === 0) {
        this.maxVendor = 500;
      } else {
        this.maxVendor = (ranger + 5 + (10 - ranger % 10)) * 100;
      }
    }
    this.barGraphGraph();
  }

  intialSetup() {
    this.getActiveResourceCount();
    let range;
    const remainderOn = Number(this.resourceDBSOnshore) + Number(this.resourceMSOnshore) + Number(this.resourceSAOnshore);
    const remainderOff = Number(this.resourceDBSOffshore) + Number(this.resourceMSOffshore) + Number(this.resourceSAOffshore);
    if (remainderOn <= remainderOff) {
      range = remainderOff / 10;
      this.maxLength = (range + 5 + (10 - range % 10)) * 10;
    } else {
      range = remainderOn / 10;
      this.maxLength = (range + 5 + (10 - range % 10)) * 10;
    }
    this.intializeGraphs();
  }

  intialCount() {
    this.activeResourceCount = 0;
    this.resourceDBS = 0;
    this.resourceSA = 0;
    this.resourceMS = 0;
    this.resourceScopeRun = 0;
    this.resourceScopeChange = 0;
    this.resourceDBSOffshore = 0;
    this.resourceSAOffshore = 0;
    this.resourceMSOffshore = 0;
    this.resourceScopeRunOffshore = 0;
    this.resourceScopeChangeOffshore = 0;

    this.resourceDBSOnshore = 0;
    this.resourceSAOnshore = 0;
    this.resourceMSOnshore = 0;
    this.resourceScopeRunOnshore = 0;
    this.resourceScopeChangeOnshore = 0;

    this.resourceOnshore = 0;
    this.resourceOffshore = 0;
    this.balancetoHire = 0;
    this.totalBudget = 0;
    this.hiredResources = 0;
    this.resourceOnNotice = 0;
    this.resourceOthers = 0;
    this.seedResource = 0;
    this.attachmentResource = 0;
    this.sANonTacoResource = 0;
    this.mSNonTacoResource = 0;
    this.countdbsResource = 0;
    this.totalWorkLocation = 0;
  }

  getActiveResourceCount() {
    this.intialCount();
    this.selectedPlatforms.forEach(ele => {
      if (ele['checked']) {
        // offshore resource type
        this.resourceDBSOffshore = this.resourceDBSOffshore + ele['offshoreDbsActive'];
        this.resourceSAOffshore = this.resourceSAOffshore + ele['offshoreSaActive'];
        this.resourceMSOffshore = this.resourceMSOffshore + ele['offshoreMsActive'];
        // onshore resource type
        this.resourceDBSOnshore = this.resourceDBSOnshore + ele['onshoreDbsActive'];
        this.resourceSAOnshore = this.resourceSAOnshore + ele['onshoreSaActive'];
        this.resourceMSOnshore = this.resourceMSOnshore + ele['onshoreMsActive'];
        // Offshore resource scope
        this.resourceScopeRunOffshore = this.resourceScopeRunOffshore + ele['offshoreBuildScpActive'];
        this.resourceScopeChangeOffshore = this.resourceScopeChangeOffshore + ele['offshoreOperateScpActive'];
        // Onshore resource scope
        this.resourceScopeRunOnshore = this.resourceScopeRunOnshore + ele['onshoreBuildScpActive'];
        this.resourceScopeChangeOnshore = this.resourceScopeChangeOnshore + ele['onshoreOperateScpActive'];
        // total budget
        this.totalBudget = this.totalBudget + ele['totalBudget'];
        // active resources
        this.activeResourceCount = this.activeResourceCount + ele['activeResources'];
        // committed to hire
        this.hiredResources = this.hiredResources + ele['committedHiring'];
        // balance to hire
        this.balancetoHire = this.balancetoHire + ele['balanceToHire'];
        // Others (SEED, Attachment, Vendor MS non-taco and vendor SA non-taco,DBS)
        this.resourceOthers = this.resourceOthers + ele['activeOtherSeedResources']
          + ele['activeOtherAttachmentResources'] + ele['activeOtherNonTacoVendorSA']
          + ele['activeOtherNonTacoVendorMS'] + ele['activeOtherDBSResources'];
        // SEED resource
        this.seedResource = this.seedResource + ele['activeOtherSeedResources'];
        //Attachment resource
        this.attachmentResource = this.attachmentResource + ele['activeOtherAttachmentResources'];
        //Vendor SA Non-TACO resource
        this.sANonTacoResource = this.sANonTacoResource + ele['activeOtherNonTacoVendorSA'];
        //Vendor SA Non-TACO resource
        this.mSNonTacoResource = this.mSNonTacoResource + ele['activeOtherNonTacoVendorMS'];
        // dbs resource
        this.countdbsResource = this.countdbsResource + ele['activeOtherDBSResources']
        // notice staff
        this.resourceOnNotice = this.resourceOnNotice + ele['onNotice'];
        // On shore resource
        this.resourceOnshore = this.resourceOnshore + ele['onshoreActive'];
        // Off shore resource
        this.resourceOffshore = this.resourceOffshore + ele['offshoreActive'];
        // resource type
        this.resourceDBS = this.resourceDBS + ele['resourcesDbs'];
        this.resourceSA = this.resourceSA + ele['resourcesSA'];
        this.resourceMS = this.resourceMS + ele['resourcesMS'];
        // resource scope
        this.resourceScopeRun = this.resourceScopeRun + ele['resourcesScpBuild'];
        this.resourceScopeChange = this.resourceScopeChange + ele['resourcesScpOperate'];
      }
    });
    this.balancetoHire = this.balancetoHire + this.resourceOnNotice;
    // code for gauge chart.
    this.high = false;
    this.maxSpeedometer = 120;
    let s: number = ((this.activeResourceCount / this.totalBudget) * 100);
    // if (s > 120) {
    //   s = 120;
    // } else
    if (!s) {
      s = 0;
    }
    this.needleValue = s.toFixed(2);

    if (this.needleValue > 120) {
      //this.maxSpeedometer=Math.round(this.needleValue / 10) * 10
      this.maxSpeedometer = Math.ceil(this.needleValue / 10) * 10;

      this.high = true;
    }
    this.pointerVariable = {value: this.needleValue};
    this.bottomLabel = this.needleValue + '%';
  }

  gettheValue(): number {
    return this.needleValue;
  }

  intializeGraphs() {
    const totalR = Number(this.resourceDBS) + Number(this.resourceMS) + Number(this.resourceSA);
    if (totalR === 0) {
      this.totalDBSResource = 0;
    } else {
      this.totalDBSResource = Math.round(Number(this.resourceDBS) / totalR * 100);
    }
    const totalS = Number(this.resourceScopeRun) + Number(this.resourceScopeChange);
    if (totalS === 0) {
      this.totalRun = 0;
    } else {
      this.totalRun = Math.round(Number(this.resourceScopeRun) / totalS * 100);
    }
    this.doughnutChartResource();
    this.doughnutChartRun();

  }

  doughnutChartOnshoreOffshore() {
    this.canvas = document.getElementById('myChartOnshoreOffshore');
    if (this.canvas) {
      this.ctx = this.canvas.getContext('2d');
    }
    const options: ChartConfiguration = {
      type: 'pie',
      data: {
        datasets: [{
          label: '# of Votes',
          data: [
            this.resourceOffshore,
            this.resourceOnshore
          ],
          backgroundColor: [
            '#94BED8', '#3D708F'
          ],
          borderWidth: 1
        }],
        labels: [
          'Offshore',
          'Onshore',
        ]
      },
      options: {
        legend: {
          onClick: null,
          reverse: true
        },
        cutoutPercentage: 50,
        animation: {
          duration: 500,
          onComplete() {
            const ctx = this.chart.ctx;
            //Chart.defaults.global.defaultFontSize = 14;
            // ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontFamily);
            ctx.font = '12px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset) {
              for (let i = 0; i < dataset.data.length; i++) {
                const model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                  total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                  mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                  start_angle = model.startAngle,
                  end_angle = model.endAngle,
                  mid_angle = start_angle + (end_angle - start_angle) / 2;

                const x = mid_radius * Math.cos(mid_angle);
                const y = mid_radius * Math.sin(mid_angle);

                ctx.fillStyle = '#000';
                if (i === 3) { // Darker text color for lighter background
                  ctx.fillStyle = '#444';
                }

                const val = dataset.data[i];
                let percent: string;
                if (total === 0) {
                  percent = 'NA';
                }
                else {
                  percent = String(Math.round(val / total * 100)) + '%';
                }
                if (val !== 0) {
                  ctx.fillText(dataset.data[i], model.x + x, model.y + y + 1);
                  // Display percent in another line, line break doesn't work for fillText
                  ctx.fillText(percent, model.x + x + 1, model.y + y + 14);
                }
              }
            });
          }
        },
        tooltips: {
          enabled: true,
          backgroundColor: '#000000'
        }
      }
    };
    if (!this.myChartOnshoreOffshore) {
      this.myChartOnshoreOffshore = new Chart(this.ctx, options);
    } else {
      this.myChartOnshoreOffshore.data = options.data;
      this.myChartOnshoreOffshore.update();
    }
  }

  stackedBarChart() {
    // Headcount Actual
    let checker = true;
    this.actualHCChart = [];
    let i = 0;
    while (checker) {
      i = i + 1;
      this.actualHCChart.push({count: 0});
      if (i === 14) {
        checker = false;
      }
    }
    this.canvas = document.getElementById('myStackedBar');
    if (this.canvas) {
      this.ctx = this.canvas.getContext('2d');
    }
    i = 0;
    if (this.headCountSnapshotResources && this.headCountSnapshotResources.length >= 0) {
      for (i = 0; i < this.headCountSnapshotResources.length; i++) {
        this.actualHCChart[this.headCountSnapshotResources[i].currentMonth].count = this.headCountSnapshotResources[i].headCount;
        if (this.headCountSnapshotResources[i].category === 'Forecast') {
          this.actualHCChart[this.headCountSnapshotResources[i].currentMonth].color = '#E8647C';
        } else {
          this.actualHCChart[this.headCountSnapshotResources[i].currentMonth].color = '#3D708F';
        }
      }
    }
    const options: ChartConfiguration = {
      type: 'bar',
      data: {
        labels: [
          this.previousYear,
          'Jan',
          'Feb',
          'Mar',
          'Apr',
          'May',
          'Jun',
          'Jul',
          'Aug',
          'Sep',
          'Oct',
          'Nov',
          'Dec'],
        datasets: [{
          type: 'line',
          label: 'Approved Capacity',
          fill: false,
          borderWidth: 3,
          backgroundColor: 'black',
          borderColor: 'black',
          pointBackgroundColor: 'grey',
          pointBorderColor: 'grey',
          pointBorderWidth: 1,
          pointHoverRadius: 5,
          pointHoverBorderWidth: 2,
          pointRadius: 5,
          pointHitRadius: 5,
          data: [
            this.approvedCapacity[0] ? this.approvedCapacity[0].headCount : 0,
            this.approvedCapacity[1] ? this.approvedCapacity[1].headCount : 0,
            this.approvedCapacity[2] ? this.approvedCapacity[2].headCount : 0,
            this.approvedCapacity[3] ? this.approvedCapacity[3].headCount : 0,
            this.approvedCapacity[4] ? this.approvedCapacity[4].headCount : 0,
            this.approvedCapacity[5] ? this.approvedCapacity[5].headCount : 0,
            this.approvedCapacity[6] ? this.approvedCapacity[6].headCount : 0,
            this.approvedCapacity[7] ? this.approvedCapacity[7].headCount : 0,
            this.approvedCapacity[8] ? this.approvedCapacity[8].headCount : 0,
            this.approvedCapacity[9] ? this.approvedCapacity[9].headCount : 0,
            this.approvedCapacity[10] ? this.approvedCapacity[10].headCount : 0,
            this.approvedCapacity[11] ? this.approvedCapacity[11].headCount : 0,
            this.approvedCapacity[12] ? this.approvedCapacity[12].headCount : 0
          ]
        },
          {
            label: 'Actual',
            data: [
              this.actualHCChart[0].count,
              this.actualHCChart[1].count,
              this.actualHCChart[2].count,
              this.actualHCChart[3].count,
              this.actualHCChart[4].count,
              this.actualHCChart[5].count,
              this.actualHCChart[6].count,
              this.actualHCChart[7].count,
              this.actualHCChart[8].count,
              this.actualHCChart[9].count,
              this.actualHCChart[10].count,
              this.actualHCChart[11].count,
              this.actualHCChart[12].count
            ],
            backgroundColor: [
              '#3D708F',
              this.actualHCChart[1].color,
              this.actualHCChart[2].color,
              this.actualHCChart[3].color,
              this.actualHCChart[4].color,
              this.actualHCChart[5].color,
              this.actualHCChart[6].color,
              this.actualHCChart[7].color,
              this.actualHCChart[8].color,
              this.actualHCChart[9].color,
              this.actualHCChart[10].color,
              this.actualHCChart[11].color,
              this.actualHCChart[12].color
            ]
          },
          {
            label: 'Forecast',
            backgroundColor: [
              '#E8647C'
            ]
          },
        ]
      },
      options: {
        legend: {
          onClick: null,
          reverse: false,
          display: true,
          position: 'top',
          labels: {
            fontSize: 18,
            padding: 1,
          }
        },
        scales: {
          yAxes: [{
            ticks: {
              fontSize: 18,
              beginAtZero: true
            },
            stacked: true

          }],
          xAxes: [{

            ticks: {
              fontSize: 18,
              beginAtZero: true
            },
            stacked: true
          }]
        },
        animation: {
          duration: 500,
          easing: 'easeOutQuart',

          onComplete() {
            const chartInstance = this.chart,
              ctx = chartInstance.ctx;
            //Chart.defaults.global.defaultFontSize = 10;
            // ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
            ctx.font = '15px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';
            ctx.fillStyle = '#000000';
            this.data.datasets.forEach(function (dataset, i) {
              ctx.fillStyle = '#004c6d';
              const meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                const data = dataset.data[index];
                if (data !== 0) {
                  ctx.fillText(data, bar._model.x, bar._model.y - 5);
                }
              });
            });
          }
        },
        tooltips: {
          enabled: true,
          titleFontSize: 15,
          bodyFontSize: 15,
          backgroundColor: '#000000'
        }
      }
    };
    if (!this.myStackedBar) {

      this.myStackedBar = new Chart(this.ctx, options);
    } else {

      this.myStackedBar.data = options.data;
      this.myStackedBar.update();
    }
  }

  doughnutChartResource() {
    this.canvas = document.getElementById('pieResource');
    if (this.canvas) {
      this.ctx = this.canvas.getContext('2d');
    }
    const options: ChartConfiguration = {
      type: 'pie',
      data: {
        datasets: [{
          label: '# of Votes',
          data: [
            this.resourceDBS,
            this.resourceSA,
            this.resourceMS
          ],
          backgroundColor: [
            '#3D708F', '#94BED8', 'rgb(209, 223, 229)'
          ],
          borderWidth: 1
        }],
        labels: [
          'DBS',
          'Vendor-SA',
          'Vendor-MS']
      },
      options: {
        legend: {
          onClick: null,
          reverse: false,
          display: true,
          position: 'bottom',
          labels: {
            fontSize: 30,
            boxWidth: 18,
            padding: 10
          }
        },
        cutoutPercentage: 50,
        animation: {
          duration: 500,
          onComplete() {
            const ctx = this.chart.ctx;
            // ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
            ctx.font = '32px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset) {

              for (let i = 0; i < dataset.data.length; i++) {
                const model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                  total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                  mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                  start_angle = model.startAngle,
                  end_angle = model.endAngle,
                  mid_angle = start_angle + (end_angle - start_angle) / 2;

                const x = mid_radius * Math.cos(mid_angle);
                const y = mid_radius * Math.sin(mid_angle);

                ctx.fillStyle = '#000';
                if (i === 3) { // Darker text color for lighter background
                  ctx.fillStyle = '#444';
                }

                let percent: string;
                const val = dataset.data[i];
                if (total === 0) {
                  percent = 'NA';
                }
                else {
                  percent = String(Math.round(val / total * 100)) + '%';
                }

                if (val !== 0) {
                  ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                  // Display percent in another line, line break doesn't work for fillText
                  ctx.fillText(percent, model.x + x, model.y + y + 30);
                }
              }
            });
          }
        },
        tooltips: {
          enabled: true,
          titleFontSize: 35,
          bodyFontSize: 35,
          position: 'average',
          backgroundColor: '#000000'
        }
      }
    };
    if (!this.pieResource) {
      this.pieResource = new Chart(this.ctx, options);
    } else {
      this.pieResource.data = options.data;
      this.pieResource.update();
    }
  }

  doughnutChartRun() {
    this.canvas = document.getElementById('pieRun');
    if (this.canvas) {
      this.ctx = this.canvas.getContext('2d');
    }
    const options: ChartConfiguration = {
      type: 'pie',
      data: {
        datasets: [{
          label: '# of Votes',
          data: [
            this.resourceScopeRun,
            this.resourceScopeChange
          ],
          backgroundColor: [
            '#3D708F', '#94BED8'
          ],
          borderWidth: 1
        }],
        labels: [
          'Build',
          'Operate',
        ]
      },
      options: {
        legend: {
          onClick: null,
          reverse: false,
          display: true,
          position: 'bottom',
          labels: {
            fontSize: 30,
            boxWidth: 20,
            padding: 15
          }
        },
        cutoutPercentage: 50,
        animation: {
          duration: 500,
          onComplete() {
            const ctx = this.chart.ctx;
            // ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
            ctx.font = '32px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset) {

              for (let i = 0; i < dataset.data.length; i++) {
                const model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                  total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                  mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                  start_angle = model.startAngle,
                  end_angle = model.endAngle,
                  mid_angle = start_angle + (end_angle - start_angle) / 2;

                const x = mid_radius * Math.cos(mid_angle);
                const y = mid_radius * Math.sin(mid_angle);

                ctx.fillStyle = '#000';
                if (i === 3) { // Darker text color for lighter background
                  ctx.fillStyle = '#444';
                }

                const val = dataset.data[i];
                let percent: string;
                if (total === 0) {
                  percent = 'NA';
                }
                else {
                  percent = String(Math.round(val / total * 100)) + '%';
                }

                if (val !== 0) {
                  ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                  // Display percent in another line, line break doesn't work for fillText
                  ctx.fillText(percent, model.x + x, model.y + y + 30);
                }
              }
            });
          }
        },
        tooltips: {
          enabled: true,
          titleFontSize: 35,
          bodyFontSize: 35,
          position: 'average',
          backgroundColor: '#000000'
        }
      }
    };
    if (!this.pieRun) {
      this.pieRun = new Chart(this.ctx, options);
    } else {
      this.pieRun.data = options.data;
      this.pieRun.update();
    }
  }


  barGraphGraph() {
    this.canvas = document.getElementById('barGraph');
    if (this.canvas) {
      this.ctx = this.canvas.getContext('2d');
    }
    this.densityData = this.getDensityData();
    const options: ChartConfiguration = this.getChartConfigurationData();
    if (!this.barGraph) {
      this.barGraph = new Chart(this.ctx, options);
    } else {
      this.barGraph.data = options.data;
      this.barGraph.update();
    }
  }

  getChartConfigurationData(): ChartConfiguration {
    return {
      type: 'horizontalBar',
      data: {
        labels: [
          this.vendorList[0] ? this.vendorList[0].vendor : '',
          this.vendorList[1] ? this.vendorList[1].vendor : '',
          this.vendorList[2] ? this.vendorList[2].vendor : '',
          this.vendorList[3] ? this.vendorList[3].vendor : '',
          this.vendorList[4] ? this.vendorList[4].vendor : '',
          this.vendorList[5] ? this.vendorList[5].vendor : '',
          this.vendorList[6] ? this.vendorList[6].vendor : '',
          this.vendorList[7] ? this.vendorList[7].vendor : '',
          this.vendorList[8] ? this.vendorList[8].vendor : '',
          this.vendorList[9] ? this.vendorList[9].vendor : ''],
        datasets: [this.densityData]
      },
      options: {
        legend: {
          display: false
        },
        layout: {
          padding: {
            right: 70
          }
        },
        scales: {
          yAxes: [{
            ticks: {
              fontSize: 15
            }
          }],
          xAxes: [{
            ticks: {
              fontSize: 15,
              beginAtZero: true
            }
          }]
        },
        elements: {
          rectangle: {
            borderSkipped: 'left',
          }
        },
        animation: {
          duration: 500,
          easing: 'easeOutQuart',
          onComplete() {
            const chartInstance = this.chart,
              ctx = chartInstance.ctx;
            ctx.font = '16px Arial';
            ctx.padding = '5px';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset, i) {
              ctx.fillStyle = '#004c6d';
              const meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                const data = dataset.data[index];
                if (data !== 0) {
                  ctx.fillText(data, bar._model.x + 20, bar._model.y + 10);
                }
              });
            });
          }
        },
        tooltips: {
          enabled: true,
          titleFontSize: 15,
          bodyFontSize: 15,
          backgroundColor: '#000000'
        }
      }
    };
  }

  getDensityData() {
    return {
      label: 'Count',
      data: [
        this.vendorList[0] ? this.vendorList[0].count : 0,
        this.vendorList[1] ? this.vendorList[1].count : 0,
        this.vendorList[2] ? this.vendorList[2].count : 0,
        this.vendorList[3] ? this.vendorList[3].count : 0,
        this.vendorList[4] ? this.vendorList[4].count : 0,
        this.vendorList[5] ? this.vendorList[5].count : 0,
        this.vendorList[6] ? this.vendorList[6].count : 0,
        this.vendorList[7] ? this.vendorList[7].count : 0,
        this.vendorList[8] ? this.vendorList[8].count : 0,
        this.vendorList[9] ? this.vendorList[9].count : 0
      ],
      backgroundColor: [
        '#004C6D', '#255F7E', '#3D708F', '#5383A1', '#6996B3', '#7FAAC6', '#94BED8', '#ABD2EC', '#C1E7FF', '#d1e0e5'
      ],
      borderColor: [
        '#004C6D', '#255F7E', '#3D708F', '#5383A1', '#6996B3', '#7FAAC6', '#94BED8', '#ABD2EC', '#C1E7FF', '#d1e0e5'
      ],
      borderWidth: 2,
      hoverBorderWidth: 0,
    };
  }

  getWorkLocationInfo(data) {
    this.response = data;
    // this.headCountSnapshotResources = data.headCountSnapshotResources;
    this.response.forEach((a) => {
      a['checked'] = true;
    });
    this.selectedPlatforms = this.response;
   // this.restService.post(`/people/team/dashboard/top-work-location`, {
    this.restService.get('assets/json/mock/top-work-location.json', {
      techUnits: this.lobts,
      platforms: this.platforms,
      rptPeriod: this.reportingPeriod,
      location: this.locations
    }).subscribe(data => {
      this.workLocationInfo = data;
      this.getWorkLocationGraphForSelectedPlatform();
    });
    this.intialSetup();
  }

  getWorkLocationGraphForSelectedPlatform() {
    this.workLocationList = [];
    this.displayLocationList = [];
    let tempworkLocationList = [];
    for (let pltfrm in this.workLocationInfo) {
      this.selectedPlatforms.find(platform => {
        if ((platform['platformIndex'].toLowerCase() === pltfrm.toLowerCase()) && platform['checked']) {
          this.workLocationInfo[pltfrm].forEach(element => {
            tempworkLocationList.push({workLocation: element['workLocation'], count: element['activeCount'], onShoreOffShore: element['onShoreOffShore']});
          });
        }
      })
    }

    let test = _.groupBy(tempworkLocationList, 'workLocation');
    for (var v in test) {

      if (v !== 'undefined') {
        test[v]['count'] = 0;
        test[v]['onShore'] = 0;
        test[v]['offShore'] = 0;
        test[v].forEach(element => {
          test[v]['count'] = test[v]['count'] + element['count'];

          if (element['onShoreOffShore'] && element['onShoreOffShore'].toLowerCase() === 'onshore') {
            test[v]['onShore'] = test[v]['onShore'] + element['count'];
            test[v]['offShore'] = test[v]['offShore'];
          } else {
            test[v]['offShore'] = test[v]['offShore'] + element['count'];
            test[v]['onShore'] = test[v]['onShore'];
          }

        })
        this.workLocationList.push({
          workLocation: v, count: test[v]['count'],
          onShoreWorkLocationCount: test[v]['onShore'], offShoreWorkLocationCount: test[v]['offShore']
        });
      }
    }
    this.workLocationList.sort((c, n) => n.count - c.count);

    let index = 0;
    let index1 = 0;
    let count1: number = 0;
    let offCount = 0;
    let onCount = 0;
    this.workLocationList.forEach(location => {
      if (index >= 9) {
        count1 = count1 + this.workLocationList[index].count;
        offCount = offCount + this.workLocationList[index].offShoreWorkLocationCount;
        onCount = onCount + this.workLocationList[index].onShoreWorkLocationCount;
        if (index === this.workLocationList.length - 1) {
          this.displayLocationList[index1] = {workLocation: 'Others', count: count1, onShoreWorkLocationCount: onCount, offShoreWorkLocationCount: offCount};
        }
      }
      else {
        this.displayLocationList[index1++] = this.workLocationList[index];
      }
      index = index + 1;
    });
    this.workLocationBarGraph();
  }

  workLocationBarGraph() {
    this.canvas = document.getElementById('workLocationGraph');
    if (this.canvas) {
      this.ctx = this.canvas.getContext('2d');
    }
    const options: ChartConfiguration = this.getworkLocationChartConfigurationData();
    if (!this.workLocationGraph) {
      this.workLocationGraph = new Chart(this.ctx, options);
    } else {
      this.workLocationGraph.data = options.data;
      this.workLocationGraph.update();
    }
  }

  getworkLocationChartConfigurationData(): ChartConfiguration {
    return {
      type: 'horizontalBar',
      data: {
        labels: [
          this.displayLocationList[0] ? this.displayLocationList[0].workLocation : '',
          this.displayLocationList[1] ? this.displayLocationList[1].workLocation : '',
          this.displayLocationList[2] ? this.displayLocationList[2].workLocation : '',
          this.displayLocationList[3] ? this.displayLocationList[3].workLocation : '',
          this.displayLocationList[4] ? this.displayLocationList[4].workLocation : '',
          this.displayLocationList[5] ? this.displayLocationList[5].workLocation : '',
          this.displayLocationList[6] ? this.displayLocationList[6].workLocation : '',
          this.displayLocationList[7] ? this.displayLocationList[7].workLocation : '',
          this.displayLocationList[8] ? this.displayLocationList[8].workLocation : '',
          this.displayLocationList[9] ? this.displayLocationList[9].workLocation : '',
        ],
        datasets: [{
          label: 'Count',
          data: [
            this.displayLocationList[0] ? this.displayLocationList[0].count : '',
            this.displayLocationList[1] ? this.displayLocationList[1].count : '',
            this.displayLocationList[2] ? this.displayLocationList[2].count : '',
            this.displayLocationList[3] ? this.displayLocationList[3].count : '',
            this.displayLocationList[4] ? this.displayLocationList[4].count : '',
            this.displayLocationList[5] ? this.displayLocationList[5].count : '',
            this.displayLocationList[6] ? this.displayLocationList[6].count : '',
            this.displayLocationList[7] ? this.displayLocationList[7].count : '',
            this.displayLocationList[8] ? this.displayLocationList[8].count : '',
            this.displayLocationList[9] ? this.displayLocationList[9].count : '',
          ],
          backgroundColor: [
            '#3D708F', '#3D708F', '#3D708F', '#3D708F', '#3D708F', '#3D708F', '#3D708F', '#3D708F', '#3D708F', '#3D708F'
          ],
          borderColor: [
            '#3D708F', '#3D708F', '#3D708F', '#3D708F', '#3D708F', '#3D708F', '#3D708F', '#3D708F', '#3D708F', '#3D708F'
          ],
        }
        ]
      },
      options: {
        legend: {
          onClick: null,
          reverse: false,
          display: false,
          position: 'top',
          labels: {
            fontSize: 15,
            padding: 10,
          }
        },
        layout: {
          padding: {
            right: 70
          }
        },
        scales: {
          yAxes: [{
            stacked: true,
            ticks: {
              fontSize: 13
            }
          }],
          xAxes: [{
            ticks: {
              beginAtZero: true,
              fontSize: 13
            },
            stacked: true,
          }]
        },
        elements: {
          rectangle: {
            borderSkipped: 'left',
          }
        },
        animation: {
          duration: 500,
          easing: 'easeOutQuart',
          onComplete() {
            const chartInstance = this.chart,
              ctx = chartInstance.ctx;
            ctx.font = '15px Arial';
            ctx.padding = '5px';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';
            this.data.datasets.forEach(function (dataset, i) {
              ctx.fillStyle = '#004c6d';
              const meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                const data = dataset.data[index];
                if (data !== 0) {
                  ctx.fillText(data, bar._model.x + 20, bar._model.y + 10);
                }
              });
            });
          }
        },
        tooltips: {
          enabled: true,
          titleFontSize: 15,
          bodyFontSize: 15,
          backgroundColor: '#000000'
        }
      }
    };
  }
}

export interface IPlatform {
  name?: string;
  checked?: boolean;
}

export interface IHeadCount {
  country?: string;
  currentMonth?: number;
  headCount?: number;
  category?: string;
}

export interface ActualHCChart {
  label?: string;
  count?: number;
  color?: string;
}

export interface ActualWorkLocation {
  label?: string;
  onshorecount?: number;
  offshorecount?: number;
  onshoreColor?: string;
  offshoreColor?: string;
}

export interface AllList {
  type?: string;
  value?: string;
  bgColor?: string;
  isLobt?: boolean;
  allPlatForms?: boolean;
  isPlatForm?: boolean;
}
