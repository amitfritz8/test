import { NgModule } from "@angular/core"
import { Routes, RouterModule } from "@angular/router"
import { MaterialModule } from "src/app/material.module";
import { SharedModule } from "src/app/common/module/shared.module";

import { PeopleComponent } from "./people-dashboard.component";
import { ArcGaugeModule, RadialGaugeModule } from '@progress/kendo-angular-gauges';

const routes: Routes = [
  {path: '', component: PeopleComponent}
];


@NgModule({
    imports: [
        RouterModule.forChild(routes),
        ArcGaugeModule,
        RadialGaugeModule,
        MaterialModule,
        SharedModule
    ],
    declarations:[PeopleComponent],
})
export class PeopleModule{}
