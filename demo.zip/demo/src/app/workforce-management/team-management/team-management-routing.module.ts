import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TeamManagementComponent } from './team-management.component';
import { CreateTeamComponent } from './create-team/create-team.component';
import { ViewTeamDetailsComponent } from './view-team-details/view-team-details.component';
import { AddRoleComponent } from 'src/app/common/component/dialogues/add-role/add-role.component';
import { TeamManagementResolver } from "./team-management.resolver";

const routes: Routes = [
  {
    path: '', component: TeamManagementComponent
  },
  { path: 'viewTeamDetails', component: ViewTeamDetailsComponent, resolve: { teamData: TeamManagementResolver } },
  { path: 'createteam', component: CreateTeamComponent },
  { path: 'AddRoleComponent', component: AddRoleComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})

export class TeamManagementRoutingModule {
}
