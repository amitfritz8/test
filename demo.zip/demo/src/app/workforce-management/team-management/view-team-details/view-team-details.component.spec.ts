// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ViewTeamDetailsComponent } from './view-team-details.component';

// describe('ViewTeamDetailsComponent', () => {
//   let component: ViewTeamDetailsComponent;
//   let fixture: ComponentFixture<ViewTeamDetailsComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ViewTeamDetailsComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ViewTeamDetailsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
