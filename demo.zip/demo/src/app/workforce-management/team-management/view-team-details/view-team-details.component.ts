import { MatDialog} from '@angular/material/dialog';
import { MatSelect } from '@angular/material/select'
import { Component, OnInit, AfterViewInit, Input, Output, EventEmitter, Attribute, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, FormArray, Validators, FormControl } from '@angular/forms';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { TimeFormat } from 'src/app/common/pipes/timeFormater.pipe';
import {ReplaySubject, Subject, Subscription} from 'rxjs';
import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import { CommonService } from "src/app/common/service/common.service";
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from "@angular/material/table";
import { MatPaginator } from '@angular/material/paginator';
import { animate, state, style, transition, trigger } from '@angular/animations';
import * as _ from "lodash";
import {HttpParams} from '@angular/common/http';
import {ConfirmDialogComponent} from 'src/app/common/component/dialogues/confirm-dialog/confirm-dialog-component';
import {RxwebValidators} from '@rxweb/reactive-form-validators';
import {take, takeUntil} from 'rxjs/operators';
import * as moment from 'moment';
import {CommonDialogComponent} from "../../../common/component/dialogues/common-dialog/common-dialog-component";
import {DeleteTeamDialogComponent} from '../../../common/component/dialogues/delete-team-dialog/delete-team-dialog.component';
import {DeactivateTeamDialogComponent} from '../../../common/component/dialogues/deactivate-team-dialog/deactivate-team-dialog.component';

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'view-team-details',
  templateUrl: 'view-team-details.component.html',
  styleUrls: ['view-team-details.component.scss']
})

export class ViewTeamDetailsComponent implements OnInit {

  subscription: Subscription;
  isTeamNameExist = false;
  goToMemebers = true;
  empData: any = {};
  teamName: string;
  status: string;
  platformName: string;
  dataSummary: any;
  productForm: FormGroup;
  isCountExceded = false;
  showDeactivateTeam: boolean = false;
  totalFTEMembers: number = 0;
  showAdd = true;
  displayedColumns: string[];
  planTeamColumns: string[];
  teamMembersData: any = {};
  todoEmployees = [];
  todoEmployees1 = [];
  roleType: any;
  showFilter:any;
  genUser: boolean = false;
  superiorUser: boolean = false;
  list = [];
  data = [];
  action = '';
  isErrorExists: boolean = false;
  isEdit: boolean = false;
  isEditRow: boolean=false;
  indexEdit;
  deletePlanList: number[] = [];
  // plan sample data
  totalFte = 0;
  totalCost = 0;
  totalCostString='0';
  totalCostMonth=0;
  totalCostMonthString='0';
  planTeamData = {
    "cost": "",
    "currency": "SGD",
    "daysInMonth": 18,
    "teamPlanCapacityResourceList": [
      {
        "plannedTeamSurrId": "",
        "teamName":"",
        "reportingPeriod":"",
        "teamRole": "Developer",
        "workLocation": "SG",
        "staffType": "DBS",
        "vendorName": "DBS",
        "rateSource": "TACO",
        "skillLevel": "level 1",
        "effectiveEndDate":"",
        "fte": 2.0,
        "blendedCost": 0,
        "localCcyCode":"",
        "ccyCode":"",
        "groupCcyCode":"",
        "blendedCostGcy":0,
        "blendedCostLcy":0
      }
    ]
  }
  teamRoles=[];
  workLocations=[];
  staffType=[];
  vendors=[];
  rateSources=[];
  levels=[];
  fte = new FormControl();
  planTeam: FormGroup;

  displayedColumnsForMembers = ['staffName', 'oneBankId', 'allocationPercentage', 'staffType', 'teamRole',
    'platformName', 'subPlatformName', 'countryCode', 'workLocation', 'chargeType', 'staffRate', 'effectiveStartDate', 'remove'];

  displayedColumnsForDeletedMembers = ['staffName', 'oneBankId', 'allocationPercentage', 'staffType', 'teamRole',
    'platformName', 'subPlatformName', 'countryCode', 'workLocation', 'chargeType', 'staffRate', 'effectiveEndDate'];


  @ViewChild('multiSelect', {static: true}) multiSelect: MatSelect;
  @ViewChild('singleSelect', {static: true}) singleSelect: MatSelect;
  protected _onDestroy = new Subject<void>();

  public LeadSearchControl: FormControl = new FormControl();
  public filteredLeadData: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public leadFormControl: FormControl = new FormControl();

  public LeadDelegateSearchControl: FormControl = new FormControl();
  public filteredLeadDelegateData: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public leadDelegateFormControl: FormControl = new FormControl();

  public BizProductOwnerSeachControl: FormControl = new FormControl();
  public filteredBizProductOwnerData: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public BizProductOwnerFormControl: FormControl = new FormControl();
  selectedPlatformIndex: any;
  public memberSearchControl: FormControl = new FormControl();
  public filteredMemberData: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public memberFormControl: FormControl = new FormControl();
  public roleFormControl: FormControl = new FormControl();
  public loggedInUserId;
  memberForm: FormGroup;
  memberFormForNonSummary: FormGroup;
  membersCount = 0;
  public platformGroups: { name: string; platform: any[] }[];
  public dateListForMembersStartDate: any = [];
  public setDate: any;
  public membersList: any;
  public dataSourceForSummary: MatTableDataSource<any> = new MatTableDataSource();
  public dataSourceForNonSummary: MatTableDataSource<any> = new MatTableDataSource();
  public dataSourceForDeletedList: MatTableDataSource<any> = new MatTableDataSource();
  public selectedEmployee: any;
  public roleSelected: any;
  public selectedStaffList: any = [];
  public checkAddButtonFlag: boolean;
  public expansion: any;
  tribeNameList: any = [];
  subPlatformList = [];
  public coreMemberCumulatives =
    {
      members : 0,
      fte : 0,
      overallTeamCostPerDay : 0,
      overallTeamCostPerMonth : 0,
      overallTeamCostPerDayNotional : 0,
      notionalTeamCostPerMonth : 0,
      overallTeamCostPerDayChargeable : 0,
      chargeableTeamCostPerMonth : 0
    }
  ;
  public augmentedMemberCumulatives =
    {
      members : 0,
      fte : 0,
      overallTeamCostPerDay : 0,
      overallTeamCostPerMonth : 0,
      overallTeamCostPerDayNotional : 0,
      notionalTeamCostPerMonth : 0,
      overallTeamCostPerDayChargeable : 0,
      chargeableTeamCostPerMonth : 0
    }
  ;
  public fteForMember: number=0;
  chargeableFlag: boolean;
  notionalFlag: boolean;
  blendedRate: number;
  private bizEmployeeList: any;
  employeeList = [];
  manDaysPerMonth=18;
  rolesList = [];
  platformList = [];

  private rptPeriod: any;

  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('virtualScroller', { static: false }) virtualScroller: CdkVirtualScrollViewport;
  @Output() back: EventEmitter<boolean> = new EventEmitter();
  private currentTeamRole: any;
  private currentWorkLocation: any;
  private currentStaffType: any;
  private currentVendor: any;
  private currentRateSource: any;
  private currentLevel: any;
  private rate: any;
  private localCurrency: string='SGD';
  private baseCurrency='SGD';
  private exchangeRate: any;
  private cost: any;
  public memberFormForDeleteList: FormGroup;
  tabObserver: Subscription;
  //Commenting Plan team tab for release mvp2_r1, uncomment after release
  //DONT DELETE
  //tabs = ["Overview", "Plan Team", "Manage Members"];
  tabs = ["Overview", "Manage Members"]
  curTab: string;
  headerInfo: any = {
    show_filters: false,
    nav_bk_url: "team-management",
    nav_bk_info: "Team Management",
    avatar: true,
    tabs: this.tabs
  }
  fteExcessMessage: string='';
  costExcessMessage: string = '';
  fteAndCostExcessMessage: string='';
  private deleteMessage: any;
  public teamExistsMessage: any;
  public showEditButton: boolean;
  private deletedStaffList: any=[];
  private fteFlag: boolean;
  costFlag: boolean;
  private ccyCode: string;
  private editTeamCancelMessage: any;
  private editTeamAbortMessage: any;

  constructor(private fb: FormBuilder, private router: Router, private restService: RestService, private dataService: DataService,
    private dateUtility: DateUtility, public formattime: TimeFormat, private route: ActivatedRoute, public dialog: MatDialog, private commonService: CommonService,  private changeDef: ChangeDetectorRef) {
    this.dataSource = new MatTableDataSource();
    this.planTeam = this.fb.group({
      teamRoles: this.fb.array([])
    });
    this.platformSetup();
  }

  updateHeaderInfo(empData) {
    this.headerInfo.title = `${empData.teamName} | ${empData.teamCode ? empData.teamCode: ''}`;
    this.headerInfo.additional_info = `Created by ${empData.createdBy ? empData.createdBy: ''} on
          ${ empData.createdDate ? this.dateFormat(empData.createdDate) :"-"}
          ${ empData.createdDate ? this.timeFormat(empData.createdDate) :"-"} |
          Last edited by ${empData.modifiedBy ? empData.modifiedBy: ''} on
          ${ empData.modifiedDate ? this.dateFormat(empData.modifiedDate) :"-"}
          ${ empData.modifiedDate ? this.timeFormat(empData.modifiedDate) :"-"}`

    this.commonService.recieveMessage(this.headerInfo);
  }


  ngOnInit(): void {
    this.curTab = this.tabs[0];
    this.loggedInUserId = localStorage.getItem('userOneBankId');
    this.rptPeriod = sessionStorage.getItem('rptPeriod');
    this.restService.get(`/people/data/dataValues/sys-config?msgKey=Mandays per Month`).subscribe(result => {
      this.manDaysPerMonth = parseInt(result['message']);
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_TEAM_PLANACTDIFF_1`).subscribe(result => {
      this.fteExcessMessage = result['message'];
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_TEAM_PLANACTDIFF_2`).subscribe(result => {
      this.costExcessMessage = result['message']
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_TEAM_PLANACTDIFF_3`).subscribe(result => {
      this.fteAndCostExcessMessage = result['message']
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_TEAM_DELETETEMPMEMBER`).subscribe(result => {
      this.deleteMessage = result['message']
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=ERR_TEAM_TEAMNAMEDUP`).subscribe(result => {
      this.teamExistsMessage = result['message']
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_TEAM_EDITTEAMCANCEL`).subscribe(result => {
      this.editTeamCancelMessage = result['message']
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_TEAM_EDITTEAMABORT`).subscribe(result => {
      this.editTeamAbortMessage = result['message']
    });
    this.isEdit = false;
    this.dataService.clearMessages();
    this.route.data.subscribe(data => {
      // this.getData(data.teamData);
    })
    const prevUrl = sessionStorage.getItem('previousUrl');
    if (prevUrl == '/home/workforce/team-management/createteam') {
      this.isErrorExists = true;
    } else {
      this.isErrorExists = false;
    }

    this.conditionForDeactivateTeam();
    this.tabObserver = this.commonService.selectedTab.subscribe(data => {
      this.curTab = data;
    });
    // this.commonService.recieveMessage(this.headerInfo);
    this.getData();
    this.getPlanTeam();
    this.getTeamRoles();
    this.getWorkLocations();
    this.leadFormControl.disable();
    this.leadDelegateFormControl.disable();
    this.memberFormControl.disable();
    this.roleFormControl.disable();
  }
  setPlatformDropdownForMembers() {
    this.platformGroups = [
      {
        name: 'Core',
        platform: []
      },
      {
        name: 'Augumented',
        platform: []
      }
    ];
    this.platformList.forEach(e => {
      if (e.platformIndex === this.selectedPlatformIndex) {
        this.platformGroups[0].platform.push({ value: e });
      } else {
        this.platformGroups[1].platform.push({ value: e });
      }
    });
  }

  setMemberForm(data) {
    this.memberForm = this.fb.group({
      memberArray: this.fb.array([])
    });
    const control = this.memberForm.controls.memberArray as FormArray;
    let todayDate = new Date();
    data.forEach(element=>{
      if(new Date(moment.utc(element.effectiveStartDate).format('YYYY-MM-DD')).getTime() <= todayDate.getTime()){
        control.push(this.fb.group({
          teamSurrId:element.teamSurrId,
          staffName: [element.staffName],
          oneBankId: [element.oneBankId],
          fte:  [element.allocationPercentage? element.allocationPercentage : 0],
          staffType: [element.staffType],
          teamRole: [element.teamRole],
          platform: [element.platformName],
          staffPlatformIndex: [element.staffPlatformIndex],
          subPlatform: [element.subPlatformName],
          countryCode: [element.countryCode],
          workLocation: [element.workLocation],
          chargeType  :  [element.chargeType],
          blendedRate: [element.blendedCost && element.allocationPercentage ? (element.blendedCost/(element.allocationPercentage)).toFixed(2) : 0],
          effectiveStartDate: [moment.utc(element.effectiveStartDate).format('DD MMMM,YYYY')],
          effectiveEndDate:'',
          teamPlatformIndex : [element.teamPlatformIndex],
          reportingPeriod:'202004',
          augmentedInd: element.augmentedInd == 'core' ? 'Core' : 'Augmented',
          reasonForRemoval:'',
          additonalInfo:'',
          ccyCode: [element.ccyCode]
        }));
      }
    });
    this.dataSourceForSummary.data=control.value;
    this.dataSourceForSummary.data.forEach(element=>{
      this.selectedStaffList.push({
        oneBankId: element.oneBankId,
        fte: element.fte
      });
      this.setCumulativeDataForSummary(element,element.blendedRate,element.fte,moment(element.effectiveStartDate).format('DD MMMM,YYYY').toString(),element.chargeType)
    })
  }
  setMemberFormForNonSummary(data) {
    this.memberFormForNonSummary = this.fb.group({
      memberArray: this.fb.array([])
    });
    const control = this.memberFormForNonSummary.controls.memberArray as FormArray;
    let todayDate = new Date();
    data.forEach(element=>{
      if((element.effectiveEndDate == '' || element.effectiveEndDate == null ) && new Date(moment.utc(element.effectiveStartDate).format('YYYY-MM-DD')).getTime() > todayDate.getTime()){
        control.push(this.fb.group({
          teamSurrId:element.teamSurrId,
          staffName: [element.staffName],
          oneBankId: [element.oneBankId],
          fte: [element.allocationPercentage? element.allocationPercentage : 0],
          staffType: [element.staffType],
          teamRole: [element.teamRole],
          platform: [element.platformName],
          staffPlatformIndex: [element.staffPlatformIndex],
          subPlatform: [element.subPlatformName],
          countryCode: [element.countryCode],
          workLocation: [element.workLocation],
          chargeType  :  [element.chargeType],
          blendedRate: [element.blendedCost && element.allocationPercentage ? (element.blendedCost/(element.allocationPercentage)).toFixed(2) : 0],
          effectiveStartDate: [moment.utc(element.effectiveStartDate).format('DD MMMM,YYYY')],
          effectiveEndDate:'',
          teamPlatformIndex : [element.teamPlatformIndex],
          reportingPeriod:'202004',
          augmentedInd: element.augmentedInd == 'core' ? 'Core' : 'Augmented',
          reasonForRemoval:'',
          additonalInfo:'',
          ccyCode: [element.ccyCode]
        }));
      }
    });
    this.dataSourceForNonSummary.data = control.value;
    this.dataSourceForNonSummary.data.forEach(element=> {
      this.selectedStaffList.push({
        oneBankId: element.oneBankId,
        fte: element.fte
      });
    });
  }

  setMemberFormForDeletedList(data){
    this.memberFormForDeleteList = this.fb.group({
      memberArray: this.fb.array([])
    });

    const control = this.memberFormForDeleteList.controls.memberArray as FormArray;
    let todayDate = new Date();
    data.forEach(element=>{
      if(new Date(moment.utc(element.effectiveEndDate).format('YYYY-MM-DD')).getTime() > todayDate.getTime()){
        control.push(this.fb.group({
          teamSurrId:element.teamSurrId,
          staffName: [element.staffName],
          oneBankId: [element.oneBankId],
          fte:  [element.allocationPercentage? element.allocationPercentage : 0],
          staffType: [element.staffType],
          teamRole: [element.teamRole],
          platform: [element.platformName],
          staffPlatformIndex: [element.staffPlatformIndex],
          subPlatform: [element.subPlatformName],
          countryCode: [element.countryCode],
          workLocation: [element.workLocation],
          chargeType  :  [element.chargeType],
          blendedRate: [element.blendedCost && element.allocationPercentage ? (element.blendedCost/(element.allocationPercentage)).toFixed(2) : 0],
          effectiveStartDate: [moment.utc(element.effectiveStartDate).format('DD MMMM,YYYY')],
          effectiveEndDate:[moment.utc(element.effectiveEndDate).format('DD MMMM,YYYY')],
          teamPlatformIndex : [element.teamPlatformIndex],
          reportingPeriod:'202004',
          augmentedInd: element.augmentedInd == 'core' ? 'Core' : 'Augmented',
          reasonForRemoval:[element.reasonsForRemoval],
          additonalInfo:[element.additionalInfo],
          ccyCode: [element.ccyCode]
        }));
      }
    });
    this.dataSourceForDeletedList.data = control.value;
    this.dataSourceForDeletedList.data.forEach(element=>{
      this.selectedStaffList.push({
        oneBankId: element.oneBankId,
        fte: element.fte
      });
      this.setCumulativeDataForSummary(element,element.blendedRate,element.fte,moment(element.effectiveStartDate).format('DD MMMM,YYYY').toString(),element.chargeType)
    })
  }
  protected setInitialValue() {
    this.filteredLeadData
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        this.singleSelect.compareWith = (a: any, b: any) => a && b && (a.oneBankId === b.oneBankId || a.empName === b.empName);
      });

    this.filteredLeadDelegateData
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        this.multiSelect.compareWith = (a: any, b: any) => a && b && (a === b);
      });

    this.filteredBizProductOwnerData
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        this.multiSelect.compareWith = (a: any, b: any) => a && b && (a === b);
      });

    this.filteredMemberData
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        this.singleSelect.compareWith = (a: any, b: any) => a && b && (a.oneBankId === b.oneBankId || a.empName === b.empName);
      });
  }

  conditoinForEditButoon(){
    this.restService.get(`/people/team/teammanagement/getAccessForEditTeam?oneBankId=${this.loggedInUserId}&teamName=${this.teamName}&platformIndex=${this.selectedPlatformIndex}`).subscribe(result => {
      //DISABLED EDIT TEAM BuTTON
      result['message'] === 'Yes' ? this.showEditButton = false : this.showEditButton = false;
    });

    //Disabling Edit team button for this release mvp2_r1
    //DO NOT DELETE
    this.showEditButton = false;
  }


   platformSetup(){
     const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
     this.restService.get(`/people/data/platforms`).subscribe(data => {
       this.platformList = data.filter(val => {
         return platforms.includes(val.platformIndex);
       });
       this.platformList.sort((a, b) => (a.platformIndex > b.platformIndex) ? 1 : -1);
       if (this.platformList && this.platformList.length == 1) {
         this.productForm.patchValue({
           platformName: this.platformList[0].platformIndex
         });
       }

       this.setPlatformDropdownForMembers();
     });
   }

   ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  getData() {
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    this.roleType = JSON.parse(sessionStorage.getItem('roles'));
    const platformIndex = this.dataService.getAction();
    let reportingPeriod = this.dataService.getReportingPeriod();
    this.status = this.dataService.getTeamStatus();
    for (var role in this.roleType) {
      this.rolePrecidenceValidator(role);
    }

      //if (this.superiorUser) {
    this.displayedColumns = ['staffName', 'oneBankId', 'allocationPercentage', 'staffType', 'teamRole',
      'platformName', 'subPlatformName', 'countryCode', 'workLocation', 'chargeType', 'staffRate', 'effectiveStartDate'];
    //}

    this.planTeamColumns = ['teamRole', 'workLocation', 'staffType', 'vendorName', 'rateSource', 'skillLevel', 'fte', 'costPerDay', 'edit', 'remove'];
    this.teamName = JSON.parse(sessionStorage.getItem('teamName'));
    this.selectedPlatformIndex = JSON.parse(sessionStorage.getItem('platformIndex'));
    this.restService.post(`/people/team/teammanagement/getindividualteaminfo`, {
      rptPeriod: reportingPeriod,
      teamName: this.teamName,
      platformIndex: platformIndex,
      locations:locations,
      status: this.status
    }).subscribe(res => {
      this.empData = res;
      this.updateHeaderInfo(this.empData);
      this.productForm = this.fb.group({
        teamSurrId : [this.empData.teamSurrId],
        platformName: [this.empData.platformName, [Validators.required]],
        subPlatformName: [ this.empData.subPlatformName, [Validators.required]],
        percentageFlag: [this.empData.teamType, [Validators.required]],
        teamName: [this.empData.teamName, [Validators.required, Validators.maxLength(100)]],
        tribeName: [this.empData.tribeName],
        teamLeadName : [this.empData.teamLead,[Validators.required]],
        productOwners: [this.empData.productOwner],
        teamLeadDelegates: [this.empData.teamLeadDelegate]
      });
    });

    this.conditoinForEditButoon();
    this.restService.post(`/people/team/teammanagement/teamManagementmembers`, {
      rptPeriod: reportingPeriod,
      teamName: this.teamName,
      platformIndex: platformIndex,
      locations:locations
    }).subscribe(res => {
      if(res){
        this.teamMembersData = res;
        this.totalFTEMembers = 0;
        this.teamMembersData.forEach(member => {
          this.totalFTEMembers = +this.totalFTEMembers + +member.allocationPercentage;
        });
        this.membersCount = this.teamMembersData.length;
        this.dataSource.data = res;
        this.dataSource.sortingDataAccessor = (data, header) => {
          if (this.displayedColumns.includes(header)) {
            if (typeof (data[header]) != 'number' && data[header]) {
              return data[header].toString().toLowerCase();
            } else {
              return data[header];
            }
          }
        }
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.setMemberForm(this.teamMembersData);
        this.setMemberFormForDeletedList(this.teamMembersData);
        this.setMemberFormForNonSummary(this.teamMembersData);
      }
    });
  }

  getPlanTeam() {
    this.totalFte=0;
    this.totalCost=0;
    let reportingPeriod = this.dataService.getReportingPeriod();
    try {
      this.restService.get(`/people/team/teammanagement/getPlanDetailsForTeam?teamName=${this.teamName}&reportingPeriod=${this.rptPeriod}`).subscribe(data => {

        this.planTeamData = data;


        let ctrl = this.planTeam.get('teamRoles') as FormArray;
        _.forIn(this.planTeamData.teamPlanCapacityResourceList, (v: any, k) => {
          this.totalFte += v.fte;
          this.totalCost += v.blendedCost;
          ctrl.push(this.setPlanTeamFormArray(v));
        });
        this.totalCost=Number(parseFloat(String(this.totalCost)).toFixed(2));
        this.totalCostString=this.totalCost.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        this.totalFte=Number(parseFloat(String(this.totalFte)).toFixed(2));
        this.totalCostMonth=(+this.totalCost)*(+this.planTeamData.daysInMonth);
        this.totalCostMonth=Number(parseFloat(String(this.totalCostMonth)).toFixed(2));
        this.totalCostMonthString=this.totalCostMonth.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      });
    }
      catch (e) {
      console.log(e);
    }

  }

  // add plan team
  addPlan(){
    let data = {
      "plannedTeamSurrId":"",
      "teamName":"",
      "reportingPeriod":"",
      "teamRole": "",
      "workLocation": "",
      "staffType": "",
      "vendorName": "",
      "rateSource": "",
      "skillLevel": "",
      "effectiveEndDate":"",
      "fte": 0,
      "blendedCost": 0,
      "localCcyCode":"",
      "ccyCode":"",
      "groupCcyCode":"",
      "blendedCostGcy":0,
      "blendedCostLcy":0
    };
    this.planTeamData.teamPlanCapacityResourceList.push(data);
    let ctrl = this.planTeam.get('teamRoles') as FormArray;
    ctrl.push(this.setPlanTeamFormArray(data));
    this.enableEditRow(ctrl,(ctrl.length-1));
    this.planTeamData.teamPlanCapacityResourceList=ctrl.value;

  }

  setPlanTeamFormArray(data) {
    return this.fb.group({
      plannedTeamSurrId: [data.plannedTeamSurrId],
      teamName: [data.teamName],
      reportingPeriod: [data.reportingPeriod],
      teamRole: [data.teamRole,[Validators.required]],
      workLocation: [data.workLocation,[Validators.required]],
      staffType: [data.staffType,[Validators.required]],
      vendorName: [data.vendorName,[Validators.required]],
      rateSource: [data.rateSource,[Validators.required]],
      skillLevel: [data.skillLevel,[Validators.required]],
      effectiveEndDate: [data.effectiveEndDate],
      fte: [data.fte,[Validators.required]],
      blendedCost: [data.blendedCost],
      localCcyCode: [data.localCcyCode],
      ccyCode: [data.ccyCode],
      groupCcyCode: [data.groupCcyCode],
      blendedCostGcy: [data.blendedCostGcy],
      blendedCostLcy: [data.blendedCostLcy]
    });
  }

  percentCalculate(key) {
    let total = 0;
    Object.values(this.dataSource[key]).forEach(function (obj) {
      total += obj['allocationPercentage'];
    });
    total = total / 100;
    return total;
  }

  rolePrecidenceValidator(role) {
    if (role === 'GENE_DBS_ADMIN' || role === 'GENE_DBS_CENTRALFUNCTION' || role === 'GENE_DBS_FINANCE' || role === 'GENE_DBS_CENTRALFUNCTION' ||
      role === 'GENE_DBS_MGT' || role === 'GENE_DBS_PLATFORMLEAD' ||
      role === 'GENE_DBS_TEAMLEAD' || role === 'GENE_DBS_MGT') {
      this.superiorUser = true;
    }
    else if (role === 'GENE_DBS_USER' || role === 'GENE_DBS_WORKMGR') {
      this.genUser = true;
      this.showDeactivateTeam=false;
    }
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustom(date);
  }

  timeFormat(date?: Date) {
    const d = new Date(date);
    const time = d.getHours() + ':' + d.getMinutes();
    return this.formattime.transform(time);
  }

  goback() {
    this.router.navigateByUrl('home/workforce/team-management');
  }

  get productOwner() {
    return this.productForm.get('prodOwnr_points') as FormArray;
  }
  get planTeamControl() {
    return this.planTeam.get('teamRoles') as FormArray;
  }

  add(index) {

    if (index < 9) {
      this.productOwner.push(this.fb.group({ point: '' }));
      //this.showAdd = true;
      this.showAdd = false;
    }
    if (index === 9) {
      this.isCountExceded = true;
    }
  }

  delete(index) {
    this.productOwner.removeAt(index);
  }

  // Team formation Members Drag and Drop

  filter(event) {
    if (event.target.value === '') {
      this.list = this.data;
    } else {
      this.list = this.data.filter(d => d.staffName.toLowerCase().includes(event.target.value.toLowerCase()));
    }
  }

  storeRole(role){
    this.currentTeamRole=role;
  }
  getTeamRoles(){
    this.restService.get(`/people/team/teammanagement/teamdropdown/role`).subscribe(data => {
      this.teamRoles =data;
    });
  }
  getWorkLocations(){
    this.restService.get(`/people/team/teammanagement/teamdropdown/workLocation`).subscribe(data => {
      this.workLocations =data;
    });
  }
  getStaffType(workLocation){
    this.currentWorkLocation=workLocation;
    this.restService.get(`/people/team/teammanagement/teamdropdown/staffType?workLocation=${workLocation}`).subscribe(data => {
      this.staffType =data;
    });
  }

  getVendor(staffType){
    this.currentStaffType = staffType;
    this.restService.get(`/people/team/teammanagement/teamdropdown/vendor?workLocation=${this.currentWorkLocation}&staffType=${staffType}`).subscribe(data => {
      this.vendors =data;
    });
  }
  getRateSource(vendor){
    this.currentVendor = vendor;
    this.restService.get(`/people/team/teammanagement/teamdropdown/rateSource?workLocation=${this.currentWorkLocation}&staffType=${this.currentStaffType}&vendor=${vendor}`).subscribe(data => {
      this.rateSources =data;
    });
  }
  getLevel(rateSource){
    this.currentRateSource = rateSource;
    this.restService.get(`/people/team/teammanagement/teamdropdown/level?workLocation=${this.currentWorkLocation}&staffType=${this.currentStaffType}&vendor=${this.currentVendor}&rateSource=${rateSource}`).subscribe(data => {
      this.levels =data;
    });
  }

  getRate(level){
    this.currentLevel = level;
    _.forIn(this.planTeamData.teamPlanCapacityResourceList, (v: any, k) => {
      if((v.teamRole==this.currentTeamRole)&&(v.workLocation==this.currentWorkLocation)&&(v.staffType==this.currentStaffType)&&(v.vendorName==this.currentVendor)&&(v.rateSource==this.currentRateSource)&&(v.level==this.currentLevel)){
        this.commonService.showSnackBar({
          type: 'alert',
          message: "This combination already exists. Please edit the existing record"
        });
      }
    });

    this.restService.get(`/people/team/teammanagement/teamdropdown/rate?workLocation=${this.currentWorkLocation}&staffType=${this.currentStaffType}&vendor=${this.currentVendor}&rateSource=${this.currentRateSource}&level=${level}`).subscribe(data => {
      this.rate =data;
    });
    this.restService.get(`/people/team/teammanagement/teamdropdown/currency?workLocation=${this.currentWorkLocation}&staffType=${this.currentStaffType}&vendor=${this.currentVendor}&rateSource=${this.currentRateSource}&level=${level}`).subscribe(data => {
      this.localCurrency =data;
    });
    this.fetchExchangeRates();
  }

  fetchExchangeRates(){
    this.restService.get(`/people/team/teammanagement/getExchangeRates?ccyFrom=${this.localCurrency}&ccyTo=${this.baseCurrency}&reportingPeriod=${this.rptPeriod}`).subscribe(data => {
      this.exchangeRate =data;
    });
  }
  countDecimals(value){
    if (Math.floor(value) !== value)
      return value.toString().split('.')[1].length || 0;
    return 0;
  }

  getCost(index,fte) {
    if(fte.indexOf(".") == -1){
      if (fte < 0.2) {
        this.commonService.showSnackBar({
          type: 'alert',
          message: "Member can't be added. Available FTE is lower than 0.2"
        });
      } else {
        this.changeFte(index);
        let control = this.planTeam.get('teamRoles') as FormArray;
        this.cost = (+this.rate) * (+fte);
        this.cost=Number(parseFloat(String(this.cost)).toFixed(2));
        let blendedLocal = (+this.cost) / (+this.exchangeRate);
        ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('blendedCost').patchValue(this.cost);
        ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('localCcyCode').patchValue(this.localCurrency);
        ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('ccyCode').patchValue(this.localCurrency);
        ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('groupCcyCode').patchValue(this.baseCurrency);
        ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('blendedCostGcy').patchValue(this.cost);
        ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('blendedCostLcy').patchValue(blendedLocal);
        this.changeCost(index, this.cost);
        this.planTeamData.teamPlanCapacityResourceList = control.value;
      }
    }
    else {
      if (this.countDecimals(fte) > 2) {
        this.commonService.showSnackBar({
          type: 'alert',
          message: "Fte should be upto 2 decimal places"
        });
      }
      else {
        if (fte < 0.2) {
          this.commonService.showSnackBar({
            type: 'alert',
            message: "Member can't be added. Available FTE is lower than 0.2"
          });
        } else {
          this.changeFte(index);
          let control = this.planTeam.get('teamRoles') as FormArray;
          this.cost = (+this.rate) * (+fte);
          this.cost = Number(parseFloat(String(this.cost)).toFixed(2));
          let blendedLocal = (+this.cost) / (+this.exchangeRate);
          ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('blendedCost').patchValue(this.cost);
          ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('localCcyCode').patchValue(this.localCurrency);
          ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('ccyCode').patchValue(this.localCurrency);
          ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('groupCcyCode').patchValue(this.baseCurrency);
          ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('blendedCostGcy').patchValue(this.cost);
          ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('blendedCostLcy').patchValue(blendedLocal);
          this.changeCost(index, this.cost);
          this.planTeamData.teamPlanCapacityResourceList = control.value;
        }
      }
    }
  }

  enableEditRow(e,index){
    this.indexEdit=index;

  }
  onDeleteRow(ele,index){
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'warning',
        contentTitle: "Delete Role?",
        content: `Please confirm you will remove this role from team planned cost and capacity. Do you want to proceed?`,
        cancelTxt: 'Cancel',
        confirmTxt: "OK"

      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        let control = this.planTeam.get('teamRoles') as FormArray;
        let plannedTeamSurrId= ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('plannedTeamSurrId').value;
        if(plannedTeamSurrId==null || plannedTeamSurrId==''){
          control.removeAt(index);
          this.planTeamData.teamPlanCapacityResourceList = control.value;
        }
        else {
          this.deletePlanList.push(plannedTeamSurrId);
          control.removeAt(index);
          this.planTeamData.teamPlanCapacityResourceList = control.value;
        }
      }
    });

  }
  goBackFromEdit(){
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'warning',
        contentTitle: "Confirmation",
        content: this.editTeamCancelMessage,
        cancelTxt: 'Cancel',
        confirmTxt: "OK"
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.isEdit = !this.isEdit;
        this.commonService.showSnackBar({
          type: 'warning',
          message: this.editTeamAbortMessage
        });
        this.settingForView();
      }
    });
  }

  settingForView(){
    this.getPlanTeam();
  }

  onSave() {
    const controls = this.productForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        this.productForm.controls[name].markAsTouched();
      }
    }
    if (this.productForm.invalid) {
      this.productForm.markAllAsTouched();
    } else if (this.productForm.valid ) {
      let control1 = _.clone(this.memberForm.controls.memberArray as FormArray);
      let control2 = _.clone(this.memberFormForNonSummary.controls.memberArray as FormArray);
      let control3 = _.clone(this.memberFormForDeleteList.controls.memberArray as FormArray);
      let teamPlanControl = _.clone(this.planTeam.controls.teamRoles as FormArray);
      let teamManageMembersList = _.clone(control1.value);
      control2.value.forEach(e => {
        teamManageMembersList.push(e);
      });
      control3.value.forEach(e => {
        teamManageMembersList.push(e);
      });
      this.deletedStaffList.forEach(e=>{
        teamManageMembersList.push(e);
      })

      teamManageMembersList.forEach(e => {
        e.teamPlatformIndex = this.selectedPlatformIndex;
        this.selectedPlatformIndex !== e.staffPlatformIndex ? e.augmentedInd = 'Y' : e.augmentedInd = 'N'
        e.allocationPercentage = +e.fte * 100;
        e.effectiveStartDate = new Date(e.effectiveStartDate);
        e.effectiveEndDate ?  e.effectiveEndDate = new Date(e.effectiveEndDate) : '';
        e.blendedCost = +e.fte * +e.blendedRate;
        delete e.fte;
      });
      let dataObj = {
        "teamSurrId" : this.productForm.controls.teamSurrId.value,
        "platformIndex": this.selectedPlatformIndex,
        "platformName": this.platformGroups[0].platform[0].value.platformName,
        "subPlatformName": this.productForm.controls.subPlatformName.value,
        "teamName": this.productForm.controls.teamName.value,
        "tribeName": this.productForm.controls.tribeName.value,
        "teamType": this.productForm.controls.percentageFlag.value,
        "teamLead": this.leadFormControl.value,
        "productOwner": this.BizProductOwnerFormControl.value.length > 0 ? this.BizProductOwnerFormControl.value : [],
        "teamLeadDelegate": this.leadDelegateFormControl.value.length > 0 ? this.leadDelegateFormControl.value : [],
        "totalFte": this.coreMemberCumulatives.fte + this.augmentedMemberCumulatives.fte,
        "totalMembers": this.coreMemberCumulatives.members + this.augmentedMemberCumulatives.members,
        "notionalCostTotal": this.coreMemberCumulatives.notionalTeamCostPerMonth + this.augmentedMemberCumulatives.notionalTeamCostPerMonth,
        "blendedCostTotal": this.coreMemberCumulatives.chargeableTeamCostPerMonth + this.augmentedMemberCumulatives.chargeableTeamCostPerMonth,
        "notionalCurrencyCode": "SGD",
        "chargeableCurrencyCode": "SGD",
        "overallCostPerDay": this.coreMemberCumulatives.overallTeamCostPerDay + this.augmentedMemberCumulatives.overallTeamCostPerDay,
        "overallCostPerMonth": this.coreMemberCumulatives.overallTeamCostPerMonth + this.augmentedMemberCumulatives.overallTeamCostPerMonth,
        "overallCurrencyCode": "SGD",
        "teamPlannedCapacityResource":
          {
            "teamName": this.productForm.controls.teamName.value,
            "daysInMonth": this.manDaysPerMonth,
            "currency": "SGD",
            "cost": this.totalCost,
            "teamPlanCapacityResourceList": teamPlanControl.value
          },
        "teamMembersList": teamManageMembersList
      };
      this.restService.post(`/people/team/teammanagement/updateTeamWithPlanAndMembers?reportingPeriod=${this.rptPeriod}&oneBankId=${this.loggedInUserId}&plannedIndicator=Y`, dataObj).subscribe(data => {

        if (data['errorFlag'] == 1) {
          this.commonService.showSnackBar({
            type: 'alert',
            message: data.message
          });
        }
        else {
          this.commonService.showSnackBar({
            type: 'success',
            message: data.message
          });

          sessionStorage.setItem('teamName', JSON.stringify(this.productForm.controls.teamName.value));
          sessionStorage.setItem('platformIndex', JSON.stringify(this.selectedPlatformIndex));
          this.ngOnInit();
        }
      });
    }

   // let ctrl = this.planTeam.get('teamRoles') as FormArray;
    this.teamName = JSON.parse(sessionStorage.getItem('teamName'));
    this.restService.post(`/people/team/teammanagement/deletePlanTeam?teamName=${this.teamName}&reportingPeriod=${this.rptPeriod}`,this.deletePlanList).subscribe(data => {
      });
    /*this.restService.put(`/people/team/teammanagement/updatePlanTeamCapacityAndCost?teamName=${this.teamName}&reportingPeriod=${this.rptPeriod}`, ctrl.getRawValue()).subscribe(data =>{
      });*/

  }
  changeFte(index){
    let oldFte=0;
    _.forIn(this.planTeamData.teamPlanCapacityResourceList, (v: any, k) => {
      if(v.plannedTeamSurrId == ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('plannedTeamSurrId').value){
        oldFte=v.fte;
      }
    });

    let newFte= ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('fte').value;
    this.totalFte=(+this.totalFte)+(+newFte)-(+oldFte);
    this.totalFte=Number(parseFloat(String(this.totalFte)).toFixed(2));
  }
  changeCost(index,newCost){
    let oldCost=0;
    _.forIn(this.planTeamData.teamPlanCapacityResourceList, (v: any, k) => {
      if(v.plannedTeamSurrId == ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('plannedTeamSurrId').value){
        oldCost=v.blendedCost;
      }
    });
    this.totalCost=(+this.totalCost)+(+newCost)-(+oldCost);
    this.totalCost=Number(parseFloat(String(this.totalCost)).toFixed(2));
    this.totalCostMonth=(+this.totalCost)*(+this.planTeamData.daysInMonth);
    this.totalCostMonth=Number(parseFloat(String(this.totalCostMonth)).toFixed(2));
    this.totalCostString=this.totalCost.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    this.totalCostMonthString=this.totalCostMonth.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');


  }

  get teamLeadName() {
    return this.productForm.get('teamLeadName') as FormArray;
  }

  get memberForActive(){
    return this.memberForm.get('memberArray') as FormArray;
  }

  get memberControlForNonSummary(){
    return this.memberFormForNonSummary.get('memberArray') as FormArray;
  }

  get memberControlDeleted(){
    return this.memberFormForDeleteList.get('memberArray') as FormArray;
  }
  checkTeamNameExist(teamName) {
    this.isTeamNameExist = false;
    const params = new HttpParams()
      .set('platform', this.selectedPlatformIndex)
      .set('teamName', teamName);
    if(teamName.toLowerCase() !== this.empData.teamName.toLowerCase())
    this.restService.get(`people/team/teammanagement/name?${params}`).subscribe(data => this.isTeamNameExist = data);
  }

  onEditClick() {
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    this.goToMemebers = false;
    this.isErrorExists = false;
    this.isEdit = true;
    this.datefetch();
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    this.productForm.controls.teamName.enable();
    this.leadFormControl.enable();
    this.leadDelegateFormControl.enable();
    this.leadFormControl.patchValue(this.empData.teamLead);
    let productOwnerList =[];
    if(this.empData.productOwner){
      let temp =  this.empData.productOwner.split(',');
      temp.forEach(element =>{
        productOwnerList.push(element);
      })
    }
    let teamLeadDelegateList =[];
    if(this.empData.teamLeadDelegate){
      let temp =  this.empData.teamLeadDelegate.split(',');
      temp.forEach(element =>{
        teamLeadDelegateList.push(element);
      })
    }
    this.leadDelegateFormControl.patchValue(teamLeadDelegateList);
    this.BizProductOwnerFormControl.patchValue(productOwnerList);
    this.restService.post(`/people/data/employee/byPlatform`, {techUnits: lobts, platforms: [this.selectedPlatformIndex], location: locations, rptPeriod: ''}).subscribe(data => {
      this.employeeList = data;
      this.membersList = data;
      this.setMemberData(this.membersList);
      this.setLeadData(this.employeeList);
      this.setLeadDelegateData(this.employeeList);
    });
    let list = this.BizProductOwnerFormControl.value.length > 0 ? this.BizProductOwnerFormControl.value : [''];
    this.restService.post(`/people/team/teammanagement/getTechAndBusinessResourceName?platformIndex=${this.selectedPlatformIndex}&searchString=''`,list).subscribe(data=>{
      this.bizEmployeeList = data;
      this.setBizProductOwnerData(this.bizEmployeeList);
      this.filterBizStaff();
    });
  }


  setLeadData(employeeList) {
    this.filteredLeadData.next(this.employeeList.slice());
    this.LeadSearchControl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterTeamLead();
      });
  }

  setLeadDelegateData(employeeList) {
    this.filteredLeadDelegateData.next(this.employeeList.slice());
    this.LeadDelegateSearchControl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterTeamLeadDelegateData();
      });
  }

  setBizProductOwnerData(employeeList) {
    let productOwnerList =[];
    if(this.empData.productOwner){
      let temp =  this.empData.productOwner.split(',');
      temp.forEach(element =>{
        productOwnerList.push(element);
      })
    }
    this.filteredBizProductOwnerData.next(this.bizEmployeeList.slice());
    this.BizProductOwnerSeachControl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterBizProductOwnerData();
      });
  }

  setMemberData(memberList) {
    this.filteredMemberData.next(this.membersList.slice());
    this.memberSearchControl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterMember();
      });
  }


  datefetch() {
    const today = new Date();
    const nextMonday = new Date();
    this.dateListForMembersStartDate = [];
    // Can change 1 To get Mon-1, Tue-2... Sun-7
    nextMonday.setDate((today.getDate() + (1 + 7 - today.getDay()) % 7));
    if (today.getTime() == nextMonday.getTime()) {
      this.setDate = moment(nextMonday).format('DD MMMM,YYYY').toString();
      this.memberFormControl.enable();
    } else {
      this.setDate = '';
    }
    this.dateListForMembersStartDate.push(moment(nextMonday).format('DD MMMM,YYYY').toString());
    for (let i = 0; i < 3; i++) {
      today.setTime(nextMonday.getTime() + (7*24*60*60*1000));
      this.dateListForMembersStartDate.push(moment(today).format('DD MMMM,YYYY').toString());
      nextMonday.setTime(today.getTime() + (7*24*60*60*1000));
    }
  }

  // convenience getters for easy access to form fields
  get f() {
    return this.productForm.controls;
  }
  get ftt() {
    return this.planTeam.controls;
  }
  get fttw() {
    return this.planTeam.controls.workLocation as FormArray;
  }

  get t() {
    return this.productForm.controls.teamLeadDelegates as FormArray;
  }



  toggleSelectForLead(selectValue: boolean) {
    this.filteredLeadData.pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(val => {
        if (selectValue) {
          this.leadFormControl.patchValue(val);
        } else {
          this.leadFormControl.patchValue([]);
        }
      });
  }

  toggleSelectForLeadDelegate(selectValue: boolean) {
    this.filteredLeadDelegateData.pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(val => {
        if (selectValue) {
          this.leadDelegateFormControl.patchValue(val);
        } else {
          this.leadDelegateFormControl.patchValue([]);
        }
      });
  }


  toggleSelectForBizProductOwner(selectValue: boolean) {
    this.filteredBizProductOwnerData.pipe()
      .subscribe(val => {
        if (selectValue) {
          this.BizProductOwnerFormControl.patchValue(val);
        } else {
          this.BizProductOwnerFormControl.patchValue([]);
        }
      });
  }

  toggleSelectForMember(selectValue: boolean) {
    this.filteredMemberData.pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(val => {
        if (selectValue) {
          this.memberFormControl.patchValue(val);
        } else {
          this.memberFormControl.patchValue([]);
        }
      });
  }

  private filterTeamLead() {
    if (!this.employeeList) {
      return;
    }
    // get the search keyword
    let search = this.LeadSearchControl.value;
    if (!search) {
      this.filteredLeadData.next(this.employeeList.slice());
      return;
    } else {
      search = search.toLowerCase().trim();
    }
    // filter the banks
    const a = [].concat.apply([], [this.leadFormControl.value, this.leadDelegateFormControl.value, this.BizProductOwnerFormControl.value]);
    this.filteredLeadData.next(
      this.employeeList.filter(bank => bank.oneBankId.toLowerCase().indexOf(search) > -1 && !a.includes(bank.oneBankId))
    );
  }

  private filterTeamLeadDelegateData() {
    if (!this.employeeList) {
      return;
    }
    // get the search keyword
    let search = this.LeadDelegateSearchControl.value;
    if (!search) {
      this.filteredLeadDelegateData.next(this.employeeList.slice());
      return;
    } else {
      search = search.toLowerCase().trim();
    }
    // filter the banks
    const listOfId = [].concat.apply([], [this.leadFormControl.value, this.BizProductOwnerFormControl.value]);

    this.filteredLeadDelegateData.next(
      this.employeeList.filter(bank => bank.oneBankId.toLowerCase().indexOf(search) > -1 && !listOfId.includes(bank.oneBankId))
    );
  }

  private filterBizProductOwnerData() {
    if (!this.bizEmployeeList) {
      return;
    }
    // get the search keyword
    let search = this.BizProductOwnerSeachControl.value;
    if (!search) {
      this.filteredBizProductOwnerData.next(this.bizEmployeeList.slice());
      return;
    } else {
      search = search.toLowerCase().trim();
    }
    const listOfId = [].concat.apply([], [this.leadFormControl.value, this.leadDelegateFormControl.value]);
    // filter the banks
    this.filteredBizProductOwnerData.next(
      this.bizEmployeeList.filter(bank => bank.oneBankId.toLowerCase().indexOf(search) > -1 && !listOfId.includes(bank.oneBankId))
    );
  }

  private filterMember() {
    if (!this.membersList) {
      return;
    }
    // get the search keyword
    let search = this.memberSearchControl.value;
    if (!search) {
      this.filteredMemberData.next(this.membersList.slice());
      return;
    } else {
      search = search.toLowerCase().trim();
    }
    // filter the banks
    const listOfId: any = [];
    this.selectedStaffList.forEach(e => {
      listOfId.push(e.oneBankId);
    });
    this.deletedStaffList.forEach(e => {
      listOfId.push(e.oneBankId);
    })
    this.filteredMemberData.next(
      this.membersList.filter(bank => (bank.oneBankId.toLowerCase().indexOf(search) > -1 || bank.empName.toLowerCase().indexOf(search) > -1) && listOfId.indexOf(bank.oneBankId) < 0 )
    );
  }

  uniqueSetOfData() {
    return [].concat.apply([], [this.leadFormControl.value, this.leadDelegateFormControl.value]).filter(function(elem, index, self) {
      return self.indexOf(elem) === index && elem != null;
    });
  }

  platformOnChangeEventForMembersTab(platformIndex) {
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    this.resetCondtions();
    this.datefetch();
    this.dataService.loaderHandler(false);
    this.restService.post(`/people/data/employee/byPlatform`, {techUnits: lobts, platforms: [platformIndex], location: locations, rptPeriod: ''}).subscribe(data => {
      this.membersList = data;
      this.setMemberData(this.membersList);
    });
  }
  memberStaffSelection(staff) {
    // need to send oneBankId,StaffDate to fetch fte, blended rate
    this.isErrorExists=false;
    this.fteForMember = 0;
    this.roleFormControl.patchValue('');
    this.roleSelected = '';
    this.roleFormControl.disable();
    this.selectedEmployee = this.membersList.filter(e => e.oneBankId == staff);
    const date = moment(new Date(this.setDate)).format('DD-MM-YYYY');
    this.restService.get(`people/team/teammanagement/getAvailabilityAndCostForTeamMember?oneBankId=${this.selectedEmployee[0].oneBankId}&effectiveStartDate=${date}`).subscribe(data => {
      if(data) {
        this.fteForMember = data['availableFte'] ? data.availableFte / 100 : 0;
        this.chargeableFlag = data.chargeableCost;
        this.notionalFlag = data.notionalCost;
        this.blendedRate = data.staffRate;
        this.ccyCode = data.ccyCode;
        if(this.fteForMember  < 0.2){
          this.isErrorExists = true;
          this.commonService.showSnackBar({
            type: 'alert',
            message: "Member can't be added. Available FTE is lower than 0.2"
          });
        }
      }else{
        this.commonService.showSnackBar({
          type: 'alert',
          message: "Unable to fetch FTE"
        });
      }
    });
    this.roleFormControl.enable();
    this.checkAddButtonFlag=false;
    this.roleSelection(this.roleSelected);
  }
  roleSelection(role) {
    this.roleSelected = role;
    if(this.fteForMember >= 0.2)
      this.checkAddButtonFlag = true;
  }
  enablingStaffToSelect(effectiveStartDate) {
    this.memberFormControl.enable();
    this.memberFormControl.patchValue('');
    this.checkAddButtonFlag = false;
    this.fteForMember = 0;
    this.roleFormControl.patchValue('');
    this.roleFormControl.disable();
    this.setDate = effectiveStartDate;
  }

  addMember() {
    let charge;
    this.chargeableFlag ? charge = 'Chargeable' : this.notionalFlag ? charge = 'Notional' : charge = 'None';
    const today = new Date();
    const nextMonday = new Date();
    nextMonday.setDate((today.getDate() + (1 + 7 - today.getDay()) % 7));
    if (today.getTime() == nextMonday.getTime() && this.setDate.toString() === this.dateListForMembersStartDate[0]) {
      const control = this.memberForm.controls.memberArray as FormArray;
      control.push(this.fb.group({
        teamSurrId:'',
        staffName: [this.selectedEmployee[0].empName],
        oneBankId: [this.selectedEmployee[0].oneBankId],
        fte: [this.fteForMember],
        staffType: [this.selectedEmployee[0].empType],
        teamRole: [this.roleSelected],
        platform: [this.selectedEmployee[0].platform],
        staffPlatformIndex: [this.selectedEmployee[0].platformIndex],
        subPlatform: [this.selectedEmployee[0].subPlatform],
        countryCode: [this.selectedEmployee[0].countryCode],
        workLocation: [this.selectedEmployee[0].workLocation],
        chargeType  :  [charge],
        blendedRate: [this.blendedRate],
        effectiveStartDate: [this.setDate],
        effectiveEndDate:'',
        teamPlatformIndex : [this.selectedPlatformIndex],
        reportingPeriod:'202004',
        augmentedInd:'N',
        reasonForRemoval:'',
        additonalInfo:'',
        ccyCode: this.ccyCode
      }));
      this.dataSourceForSummary = new MatTableDataSource();
      this.dataSourceForSummary.data = control.value;
      this.setCumulativeDataForSummary(this.selectedEmployee[0], this.blendedRate, this.fteForMember, Object.assign(this.setDate), charge);
    } else {
      const control = this.memberFormForNonSummary.controls.memberArray as FormArray;
      control.push(this.fb.group({
        teamSurrId:'',
        staffName: [this.selectedEmployee[0].empName],
        oneBankId: [this.selectedEmployee[0].oneBankId],
        fte: [this.fteForMember],
        staffType: [this.selectedEmployee[0].empType],
        teamRole: [this.roleSelected],
        platform: [this.selectedEmployee[0].platform],
        staffPlatformIndex: [this.selectedEmployee[0].platformIndex],
        subPlatform: [this.selectedEmployee[0].subPlatform],
        countryCode: [this.selectedEmployee[0].countryCode],
        workLocation: [this.selectedEmployee[0].workLocation],
        chargeType  :  [charge],
        blendedRate: [this.blendedRate],
        effectiveStartDate: [this.setDate],
        effectiveEndDate:'',
        teamPlatformIndex : [this.selectedPlatformIndex],
        reportingPeriod:this.rptPeriod,
        augmentedInd:'N',
        reasonForRemoval:'',
        additonalInfo:'',
        ccyCode: this.ccyCode
      }));
      this.dataSourceForNonSummary = new MatTableDataSource();
      this.dataSourceForNonSummary.data = control.value;
    }

    this.selectedStaffList.push({
      oneBankId: this.selectedEmployee[0].oneBankId,
      fte: this.fteForMember
    });
    this.setWarningMessage();
    this.resetCondtions();
    this.datefetch();
  }
  setWarningMessage(){
    this.fteFlag = false;
    this.costFlag = false;
    let message = '';
    this.augmentedMemberCumulatives.fte + this.coreMemberCumulatives.fte > this.totalFte ? this.fteFlag = true : this.fteFlag = false;
    this.augmentedMemberCumulatives.overallTeamCostPerDay + this.coreMemberCumulatives.overallTeamCostPerDay > this.totalCost ? this.costFlag = true : this.costFlag = false;
    if(this.fteFlag && this.costFlag){
      message = this.fteAndCostExcessMessage;
    }else if(this.fteFlag){
      message = this.fteExcessMessage;
    } else if(this.costFlag){
      message = this.costExcessMessage;
    }
    if(this.costFlag || this.fteFlag) {
      this.commonService.showSnackBar({
        type: 'warning',
        message: message
      });
    }
  }
  resetCondtions() {
    this.memberFormControl.disable();
    this.memberFormControl.patchValue('');
    this.roleFormControl.disable();
    this.roleFormControl.patchValue('');
    this.checkAddButtonFlag = false;
    this.fteForMember = 0;
    this.chargeableFlag = false;
    this.notionalFlag = false;
    this.blendedRate = 0.0;
    this.roleSelected = '';
  }

  selectedTab(selected) {
    this.isErrorExists = false;
    if (selected.index == 2) {
      this.dataService.loaderHandler(true);
      let ctrl = this.planTeam.get('teamRoles') as FormArray;
      this.totalFte = 0;
      this.totalCost = 0;
      this.datefetch()
      ctrl.value.forEach(element => {
        this.totalFte = +this.totalFte + (+element.fte);
        this.totalCost = this.totalCost + element.blendedCost;
      })
      this.datefetch();
      this.platformOnChangeEventForMembersTab(this.selectedPlatformIndex);
    }
    // if (this.selectedPlatformIndex !== undefined) {
    //   this.goToMemebers = false;
    //   else {
    //     // this.showIfMembers = false;
    //   }
    // } else {
    //   this.goToMemebers = true;
    //   this.isErrorExists = true;
    //   this.dataService.getCustomMessage('Platform must be selected');
    //   this.dataService.getFlag('1');
    // }
  }

  checkFTE(employee, fteValue, index) {
    fteValue = parseFloat(fteValue).toFixed(2);
    const control = this.memberForm.controls.memberArray as FormArray;
    const defaultEmployee = this.selectedStaffList.filter(e => e.oneBankId === employee.oneBankId);
    if (fteValue < 0.2 || fteValue > defaultEmployee[0].fte) {
      ((this.memberForm.get('memberArray') as FormArray).at(index) as FormGroup).get('fte').patchValue(parseFloat(defaultEmployee[0].fte).toFixed(2));
    } else {
      this.updateCumulativeDataForSummary(control.value[index], control.value[index].blendedRate, fteValue, Object.assign(control.value[index].effectiveStartDate), control.value[index].chargeType, this.dataSourceForSummary.data[index].fte);
      ((this.memberForm.get('memberArray') as FormArray).at(index) as FormGroup).get('fte').patchValue(fteValue);
    }
    this.dataSourceForSummary.data = control.value;
  }
  checkFTEForDeleteList(employee, fteValue, index) {
    fteValue = parseFloat(fteValue).toFixed(2);
    const control = this.memberFormForDeleteList.controls.memberArray as FormArray;
    const defaultEmployee = this.selectedStaffList.filter(e => e.oneBankId === employee.oneBankId);
    if (fteValue < 0.2 || fteValue > defaultEmployee[0].fte) {
      ((this.memberFormForDeleteList.get('memberArray') as FormArray).at(index) as FormGroup).get('fte').patchValue(parseFloat(defaultEmployee[0].fte).toFixed(2));
    } else {
      this.updateCumulativeDataForSummary(control.value[index], control.value[index].blendedRate, fteValue, Object.assign(control.value[index].effectiveStartDate), control.value[index].chargeType, this.dataSourceForDeletedList.data[index].fte);
      ((this.memberFormForDeleteList.get('memberArray') as FormArray).at(index) as FormGroup).get('fte').patchValue(fteValue);
    }
    this.dataSourceForDeletedList.data = control.value;
  }

  checkFTEForNonSummary(employee, fteValue, index) {
    fteValue = parseFloat(fteValue).toFixed(2);
    const control = this.memberFormForNonSummary.controls.memberArray as FormArray;
    const defaultEmployee = this.selectedStaffList.filter(e => e.oneBankId === employee.oneBankId);
    if (fteValue < 0.2 || fteValue > defaultEmployee[0].fte) {
      ((this.memberFormForNonSummary.get('memberArray') as FormArray).at(index) as FormGroup).get('fte').patchValue(parseFloat(defaultEmployee[0].fte).toFixed(2));
    } else {
      ((this.memberFormForNonSummary.get('memberArray') as FormArray).at(index) as FormGroup).get('fte').patchValue(fteValue);
    }
    this.dataSourceForNonSummary.data = control.value;
  }

  summaryDetailView() {
    this.expansion ? this.expansion = false : this.expansion = true;
  }
  setCumulativeDataForSummary(employee, blendedRate, fte, assignedDate, chargeType) {
      if (employee.platform == this.platformGroups[0].platform[0].value.platformName) {
        this.coreMemberCumulatives.members =  this.coreMemberCumulatives.members + 1;
        this.coreMemberCumulatives.fte = this.coreMemberCumulatives.fte + fte;
        this.coreMemberCumulatives.overallTeamCostPerDay = +(this.coreMemberCumulatives.overallTeamCostPerDay + (blendedRate * fte)).toFixed(2);
        this.coreMemberCumulatives.overallTeamCostPerMonth =  +(this.coreMemberCumulatives.overallTeamCostPerDay * this.manDaysPerMonth).toFixed(2);
        if (chargeType == 'Notional') {
          this.coreMemberCumulatives.overallTeamCostPerDayNotional = +(this.coreMemberCumulatives.overallTeamCostPerDayNotional + (blendedRate * fte)).toFixed(2);
          this.coreMemberCumulatives.notionalTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDayNotional * this.manDaysPerMonth).toFixed(2);
        } else if (chargeType == 'Chargeable') {
          this.coreMemberCumulatives.overallTeamCostPerDayChargeable =  +(this.coreMemberCumulatives.overallTeamCostPerDayChargeable + (blendedRate * fte)).toFixed(2);
          this.coreMemberCumulatives.chargeableTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDayChargeable * this.manDaysPerMonth).toFixed(2);
        }
      } else {
        this.augmentedMemberCumulatives.members =  this.augmentedMemberCumulatives.members + 1;
        this.augmentedMemberCumulatives.fte = this.augmentedMemberCumulatives.fte + fte;
        this.augmentedMemberCumulatives.overallTeamCostPerDay = +(this.augmentedMemberCumulatives.overallTeamCostPerDay + (blendedRate * fte)).toFixed(2);
        this.augmentedMemberCumulatives.overallTeamCostPerMonth =  +(this.augmentedMemberCumulatives.overallTeamCostPerDay * this.manDaysPerMonth).toFixed(2);
        if (chargeType == 'Notional') {
          this.augmentedMemberCumulatives.overallTeamCostPerDayNotional =  +(this.augmentedMemberCumulatives.overallTeamCostPerDayNotional + (blendedRate * fte)).toFixed(2);
          this.augmentedMemberCumulatives.notionalTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDayNotional * this.manDaysPerMonth).toFixed(2);
        } else if (chargeType == 'Chargeable') {
          this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable =  +(this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable + (blendedRate * fte)).toFixed(2);
          this.augmentedMemberCumulatives.chargeableTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable * this.manDaysPerMonth).toFixed(2);
        }
      }

  }
  filterMemberStaff() {
    const listOfId = [];
    this.selectedStaffList.forEach(e => {
      listOfId.push(e.oneBankId);
    });
    this.filteredMemberData.next(
      this.membersList.filter(bank =>  listOfId.indexOf(bank.oneBankId) < 0 )
    );
  }
  filterTechLeadDelegateStaff() {
    const listOfId = [].concat.apply([], [this.leadFormControl.value,this.BizProductOwnerFormControl.value]);
    this.filteredLeadDelegateData.next(
      this.employeeList.filter(bank =>  !listOfId.includes(bank.oneBankId))
    );
  }
  filterTechLeadStaff() {
    const listOfId = [].concat.apply([], [this.leadFormControl.value, this.leadDelegateFormControl.value, this.BizProductOwnerFormControl.value]);
    this.filteredLeadData.next(
      this.employeeList.filter(bank =>  !listOfId.includes(bank.oneBankId))
    );
  }

  filterBizStaff() {
    // this.fetchBizPeople();
    const listOfId = [].concat.apply([], [this.leadFormControl.value, this.leadDelegateFormControl.value]);
    this.filteredBizProductOwnerData.next(
      this.bizEmployeeList.filter(bank =>  !listOfId.includes(bank.oneBankId))
    );
  }
  updateCumulativeDataForSummary(employee, blendedRate, newFte, assignedDate, chargeType, oldFte) {
      if (employee.platform == this.platformGroups[0].platform[0].value.platformName) {
        this.coreMemberCumulatives.fte = +this.coreMemberCumulatives.fte - (+oldFte) + (+newFte);
        this.coreMemberCumulatives.overallTeamCostPerDay =  +(this.coreMemberCumulatives.overallTeamCostPerDay - (+(blendedRate * oldFte).toFixed(2)) + (+(blendedRate * newFte).toFixed(2))).toFixed(2);
        this.coreMemberCumulatives.overallTeamCostPerMonth =  +(this.coreMemberCumulatives.overallTeamCostPerDay * this.manDaysPerMonth).toFixed(2);
        if (chargeType == 'Notional') {
          this.coreMemberCumulatives.overallTeamCostPerDayNotional = +(this.coreMemberCumulatives.overallTeamCostPerDayNotional - (+(blendedRate * oldFte).toFixed(2)) + (+(blendedRate * newFte).toFixed(2))).toFixed(2);
          this.coreMemberCumulatives.notionalTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDayNotional * this.manDaysPerMonth).toFixed(2);
        } else if (chargeType == 'Chargeable') {
          this.coreMemberCumulatives.overallTeamCostPerDayChargeable = +(this.coreMemberCumulatives.overallTeamCostPerDayChargeable - (+(blendedRate * oldFte).toFixed(2)) + (+(blendedRate * newFte).toFixed(2))).toFixed(2);
          this.coreMemberCumulatives.chargeableTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDayChargeable * this.manDaysPerMonth).toFixed(2);
        }
      } else {
        this.augmentedMemberCumulatives.fte = +this.augmentedMemberCumulatives.fte - (+oldFte) + (+newFte);
        this.augmentedMemberCumulatives.overallTeamCostPerDay = +(this.augmentedMemberCumulatives.overallTeamCostPerDay - (+(blendedRate * oldFte).toFixed(2)) + (+(blendedRate * newFte).toFixed(2))).toFixed(2);
        this.augmentedMemberCumulatives.overallTeamCostPerMonth =  +(this.augmentedMemberCumulatives.overallTeamCostPerDay * this.manDaysPerMonth).toFixed(2);
        if (chargeType == 'Notional') {
          this.augmentedMemberCumulatives.overallTeamCostPerDayNotional =  +(this.augmentedMemberCumulatives.overallTeamCostPerDayNotional - (+(blendedRate * oldFte).toFixed(2)) + (+(blendedRate * newFte).toFixed(2))).toFixed(2);
          this.augmentedMemberCumulatives.notionalTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDayNotional * this.manDaysPerMonth).toFixed(2);
        } else if (chargeType == 'Chargeable') {
          this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable =  +(this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable - (+(blendedRate * oldFte).toFixed(2)) + (+(blendedRate * newFte).toFixed(2))).toFixed(2);
          this.augmentedMemberCumulatives.chargeableTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable * this.manDaysPerMonth).toFixed(2);
        }
      }
  }

  fetchBizPeople(){
    let list = this.BizProductOwnerFormControl.value.length > 0 ? this.BizProductOwnerFormControl.value : [''];
    this.restService.post(`/people/team/teammanagement/getTechAndBusinessResourceName?platformIndex=${this.selectedPlatformIndex}&searchString=${this.BizProductOwnerSeachControl.value}`,list).subscribe(data => {
      this.bizEmployeeList = data;
      this.filterBizProductOwnerData();
    });
  }

  deleteStaffForSummary(index, employee) {
    if (employee.teamSurrId !== '') {
      const dialogRef = this.dialog.open(DeleteTeamDialogComponent, {});
      dialogRef.afterClosed().subscribe(response => {
        if (response.result == 'Yes') {
          const control = this.memberForm.controls.memberArray as FormArray;
          const controlFordelete = this.memberFormForDeleteList.controls.memberArray as FormArray;
          let staff = _.clone(control.value[index])
          staff.effectiveEndDate = response.endDate;
          staff.reasonForRemoval = response.removalReason;
          staff.additonalInfo = response.additionalInfo;
          controlFordelete.push(this.fb.group(staff));
          control.removeAt(index);
          this.dataSourceForSummary.data = control.value;
          this.dataSourceForDeletedList.data = controlFordelete.value;
        }
      });
    }else{
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        data: {
          header: 'Remove Member?',
          body: 'Are you sure you would like to remove this member?',
          note: '',
          button1: 'Cancel',
          button2: 'OK'
        }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result === 'yes') {
          const control = this.memberForm.controls.memberArray as FormArray;
          this.updateCumulativeDataForSummaryAfterDelete(employee, control.value[index].blendedRate, control.value[index].fte, Object.assign(control.value[index].effectiveStartDate), control.value[index].chargeType);
          control.removeAt(index);
          this.dataSourceForSummary.data = control.value;
          this.selectedStaffList.splice(index);
        }
      });
    }
  }

  deleteStaffForNonSummary(index, employee){
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Remove Member?',
        body: 'Are you sure you would like to remove this member?',
        note: '',
        button1: 'Cancel',
        button2: 'OK'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        const control = this.memberFormForNonSummary.controls.memberArray as FormArray;
        if(control.value[index].teamSurrId !== '') {
          let staff = _.clone(control.value[index]);
          staff.effectiveEndDate = new Date();
          this.deletedStaffList.push(staff);
        }
        control.removeAt(index)
        this.selectedStaffList.splice(index);
        this.dataSourceForNonSummary.data = control.value;
      }
    });

  }

  updateCumulativeDataForSummaryAfterDelete(employee, blendedRate, fte, assignedDate, chargeType) {
      if (employee.platform == this.platformGroups[0].platform[0].value.platformName) {
        this.coreMemberCumulatives.members = +this.coreMemberCumulatives.members - 1;
        this.coreMemberCumulatives.fte = +this.coreMemberCumulatives.fte - (+fte);
        this.coreMemberCumulatives.overallTeamCostPerDay =  +(this.coreMemberCumulatives.overallTeamCostPerDay - (+(blendedRate * fte).toFixed(2))).toFixed(2);
        this.coreMemberCumulatives.overallTeamCostPerMonth =  +(this.coreMemberCumulatives.overallTeamCostPerDay * this.manDaysPerMonth).toFixed(2);
        if (chargeType == 'Notional') {
          this.coreMemberCumulatives.overallTeamCostPerDayNotional = +(this.coreMemberCumulatives.overallTeamCostPerDayNotional - (+(blendedRate * fte).toFixed(2))).toFixed(2);
          this.coreMemberCumulatives.notionalTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDayNotional * this.manDaysPerMonth).toFixed(2);
        } else if (chargeType == 'Chargeable') {
          this.coreMemberCumulatives.overallTeamCostPerDayChargeable = +(this.coreMemberCumulatives.overallTeamCostPerDayChargeable - (+(blendedRate * fte).toFixed(2))).toFixed(2);
          this.coreMemberCumulatives.chargeableTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDayChargeable * this.manDaysPerMonth).toFixed(2);
        }
      } else {
        this.augmentedMemberCumulatives.members = +this.augmentedMemberCumulatives.members - 1;
        this.augmentedMemberCumulatives.fte = +this.augmentedMemberCumulatives.fte - (+fte);
        this.augmentedMemberCumulatives.overallTeamCostPerDay = +(this.augmentedMemberCumulatives.overallTeamCostPerDay - (+(blendedRate * fte).toFixed(2))).toFixed(2);
        this.augmentedMemberCumulatives.overallTeamCostPerMonth =  +(this.augmentedMemberCumulatives.overallTeamCostPerDay * this.manDaysPerMonth).toFixed(2);
        if (chargeType == 'Notional') {
          this.augmentedMemberCumulatives.overallTeamCostPerDayNotional =  +(this.augmentedMemberCumulatives.overallTeamCostPerDayNotional - (+(blendedRate * fte).toFixed(2))).toFixed(2);
          this.augmentedMemberCumulatives.notionalTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDayNotional * this.manDaysPerMonth).toFixed(2);
        } else if (chargeType == 'Chargeable') {
          this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable =  +(this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable - (+(blendedRate * fte).toFixed(2))).toFixed(2);
          this.augmentedMemberCumulatives.chargeableTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable * this.manDaysPerMonth).toFixed(2);
        }
      }

  }


  deactivateTeam() {
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'alert',
        contentTitle: "Confirmation",
        content: 'Team would be removed from business case selection or work and all members would removed from team upon deactivation',
        cancelTxt: 'Cancel',
        confirmTxt: "OK"
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        const dialogRef = this.dialog.open(DeactivateTeamDialogComponent, {});
        dialogRef.afterClosed().subscribe(response => {
          if (response.result === 'yes') {
            this.restService.get(`/people/team/teammanagement/deactivateTeam?teamSurrId=${this.empData.teamSurrId}&teamName=${this.empData.teamName}&effectiveEndDateStr=${response.endDate}&reason=${response.removalReason}&message=${response.additionalInfo}`).subscribe(data=>{
            });
            const currentDate= new Date();
            if(response.endDate == currentDate) {
              this.commonService.showSnackBar({
                type: 'success',
                message: 'Team has been deactivated'
              });
            }
            else{
              this.commonService.showSnackBar({
                type: 'success',
                message: 'Team will be deactivated'
              });
            }
          }
        });
    }
      else if (result==='no'){
        this.commonService.showSnackBar({
          type: 'warning',
          message: 'Team de-activation is cancelled as requested by you'
        });
      }
    });

  }
  conditionForDeactivateTeam() {
    const roles = JSON.parse(sessionStorage.getItem('roles'));
      for (var role in roles) {
        if (role == 'GENE_DBS_TEAMLEAD' || role == 'GENE_DBS_PLATFORMLEAD') {
          this.restService.get(`/people/team/teammanagement/getAccessForTeamCreation?oneBankId=${this.loggedInUserId}`).subscribe(result => {
            result['message'] === 'Yes' ? this.showDeactivateTeam = true : this.showDeactivateTeam = false;
          });
        }
      }
  }
}
