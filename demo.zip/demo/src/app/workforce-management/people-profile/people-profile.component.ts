import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { Component, OnInit, AfterViewInit, ViewChild, OnDestroy } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { RestService } from '../../common/service/rest.service';
import { FormControl } from '@angular/forms';
import { DataTableService } from '../../common/service/dataTable.service';
import { CommonService } from '../../common/service/common.service';
import { Router } from '@angular/router';
import { DataService } from '../../common/service/data.service';
import { ImportDialogComponent } from 'src/app/common/component/dialogues/import-dialog/import-dialog-component';
import * as moment from 'moment';
import { SelectionModel } from '@angular/cdk/collections';
import { UpdateProfileComponent } from 'src/app/common/component/dialogues/update-profile/update-profile-component';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { Subscription } from 'rxjs';
import { IcRangeComponent } from 'src/app/common/component/dialogues/ic-range/ic-range.component';
import { PcftRangeComponent } from 'src/app/common/component/dialogues/pcft-range/pcft-range.component';
import { NonPcftRangeComponent } from 'src/app/common/component/dialogues/non-pcft-range/non-pcft-range.component';
import { AugPcftRangeComponent } from 'src/app/common/component/dialogues/aug-pcft-range/aug-pcft-range.component';
import { AugNonPcftRangeComponent } from 'src/app/common/component/dialogues/aug-non-pcft-range/aug-non-pcft-range.component';
import { CommonDialogComponent } from 'src/app/common/component/dialogues/common-dialog/common-dialog-component';

// people model
import {PeopleProfileModel } from './people.model';
import { PeopleService } from './people.service';


@Component({
  selector: 'people-profile',
  templateUrl: './people-profile.component.html',
  styleUrls: ['./people-profile.component.scss'],
  providers: [PeopleService]
})
export class PeopleProfileComponent implements OnInit, AfterViewInit, OnDestroy {

  sample: PeopleProfileModel;


  // fix: columns name must be exact as text otherwise sorting will not work
  displayedColumns: string[] = ['empName', 'oneBankId', 'empType', 'empStatus', 'platform', 'subPlatform',
    'reportingMgr', 'staffPccode', 'workLocation', 'countryCode', 'tacoInd'];

  displayedColumnsForChapters: string[] = ['empName', 'oneBankId', 'empType', 'empStatus', 'platform',
    'subPlatform', 'chapterName', 'chapterLead', 'workLocation', 'tacoInd'];

  displayedColumnsForNewJoiners: string[] = ['select', 'empName', 'empType', 'dateCreated', 'reportingMgr', 'platform',
    'subPlatform', 'typeOfWork1', 'typeOfWork2', 'chapterName'];

  displayedColumnsForTeamIC: string[] = ['staffName', 'oneBankId', 'platForm', 'subPlatform', 'icFTE', 'pcftFTE',
    'nPcftFTE', 'aoPcftFTE', 'aoNpcftFTE', 'pcftMembership', 'nonPCFTMembership', 'augPCFTMembership', 'augNonPCFTMembership'];

  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  dataSourceChapter: MatTableDataSource<any> = new MatTableDataSource();
  dataSourceNewJoiners: MatTableDataSource<any> = new MatTableDataSource();
  dataSourceTeamIC: MatTableDataSource<any>;

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  empNameFilter = new FormControl('');
  oneBankIdFilter = new FormControl('');
  empTypeFilter = new FormControl('');
  empStatusFilter = new FormControl('');
  platformFilter = new FormControl('');
  reportingMgrFilter = new FormControl('');
  staffPccodeFilter = new FormControl('');
  countryCodeFilter = new FormControl('');
  workLocationFilter = new FormControl('');
  tacoIndicatorFilter = new FormControl('');
  subPlatformFilter = new FormControl('');
  chapterNameFilter = new FormControl('');
  chapterLeadFilter = new FormControl('');
  dateCreatedFilter = new FormControl('');
  //onOffshoreFilter = new FormControl('');
  typeOfWork1Filter = new FormControl('');
  typeOfWork2Filter = new FormControl('');

  staffNameICFilter = new FormControl('');
  oneBankIdICFilter = new FormControl('');
  platformICFilter = new FormControl('');
  subPlatformICFilter = new FormControl('');
  pcftMembershipFilter = new FormControl('');
  nonPCFTMembershipFilter = new FormControl('');
  augPCFTMembershipFilter = new FormControl('');
  augNonPCFTMembershipFilter = new FormControl('');

  defaultStaffStatus: string = 'Active'

  showFilter: boolean = false;
  currentMonthStatus: boolean = false;
  displayAdditionalInf: boolean = false;
  isErrorExists: boolean = false;
  isSuccessMsg: boolean = false;
  searchText: string = '';
  roles: string[] = [];
  filterValues = {
    empName: '',
    oneBankId: '',
    empType: '',
    empStatus: '',
    platform: '',
    reportingMgr: '',
    staffPccode: '',
    subPlatform: '',
    countryCode: '',
    workLocation: '',
    tacoInd: ''
  };
  filterValuesForChapter = {
    empName: '',
    oneBankId: '',
    empType: '',
    empStatus: '',
    platform: '',
    subPlatform: '',
    chapterName: '',
    chapterLead: '',
    workLocation: '',
    tacoInd: ''
  };
  filterValuesForNewJoinee = {
    empName: '',
    oneBankId: '',
    empType: '',
    dateCreated: '',
    reportingMgr: '',
    platform: '',
    subPlatform: '',
    typeOfWork1: '',
    typeOfWork2: '',
    //onOffshore: '',
    chapterName: ''
  };
  filterValuesForICTeam = {
    staffName: '',
    oneBankId: '',
    platForm: '',
    subPlatform: '',
    pcftMembership: '',
    nonPCFTMembership: '',
    augPCFTMembership: '',
    augNonPCFTMembership: ''
  };
  reportingPeriod: string;
  statusList = [];
  tacoIndicator = [{ key: 'all', value: 'All' }, { key: 'yes', value: 'Yes' }, { key: 'no', value: 'No' }]
  errorData: any;
  oneBankId: any;
  selectedDate: string;
  selectedPeopleData: string;
  dates: any;
  months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  bd11Msg = '';
  peopleDataList = ['Staff List', 'People By Chapters', 'New Staff Update', 'Teams & IC Assignment'];
  peopleDataListWithoutNewjoiner = ['Staff List', 'People By Chapters', 'Teams & IC Assignment'];
  previousUrl: string;
  chapterNameList = [];
  selection = new SelectionModel<any>(true, []);
  newJoinersData = [];
  selectedPlatforms = [];
  newJoinersAccess = false;
  modulesMapping: any;
  platformLeadCheck = false;
  userAccessCheckValue = false;
  private loggedOneBankId: string | null;
  icFteTooltip: any;
  pcftTooltip: any;
  nonPcftTooltip: any;
  augPcftTooltip: any;
  augNonPcftTooltip: any;
  pcftTooltipMembership: any;
  nonPcftTooltipMembership: any;
  augPcftTooltipMembership: any;
  augNonPcftTooltipMembership: any;
  private editWindowPeriod: any;
  headerInfo: any = {
    title: "People Profile"
  }

  // observers
  tabObeserver: Subscription;
  ReportPrdObserver: Subscription;

  displayCount: number = 0;
  dataLength: number = 0;
  pageSize: number = 20;
  pageSubscription: Subscription;

  constructor(private restService: RestService, private router: Router, private dataService: DataService,
    private readonly dataTableService: DataTableService, public dialog: MatDialog, private peopleService: PeopleService,
    private commonService: CommonService, private dateUtility: DateUtility) {
    this.restService.track('PEOPLE PROFILE');
    this.oneBankId = dataService.getPassingOneBankId();
    this.reportingPeriod = dataService.getReportingPeriod();
    this.commonService.setUserId(this.oneBankId);
    this.commonService.setDocumentTitle('PEOPLE PROFILE');
    this.commonService.trackPageView();
    this.dataSource = new MatTableDataSource();
    this.dataSourceChapter = new MatTableDataSource();
    this.dataSourceNewJoiners = new MatTableDataSource();
    this.dataSourceTeamIC = new MatTableDataSource();
    this.updateHeaderInfo();
    this.statusList = [];
    this.chapterNameList = [];
    this.getStatusList();
    this.getChapterNameList();
    this.previousUrl = sessionStorage.getItem('previousUrl');
    if (this.previousUrl == '/home/peopleprofile/additionalInfo') {
      this.selectedPeopleData = sessionStorage.getItem('listView');
      // this.commonService.msg2Tab(this.peopleDataList.indexOf(this.selectedPeopleData));
    } else {
      this.selectedPeopleData = 'Staff List';
      sessionStorage.setItem('listView', this.selectedPeopleData);
    }
  }

  updateDisplayCount(){
    this.displayCount = (this.paginator.pageIndex + 1) * this.pageSize > this.dataLength ? this.dataLength : (this.paginator.pageIndex + 1) * this.pageSize;
  }

  getPaginationClass(dataSource: any): string{
    if(!dataSource || dataSource.data.length === 0){
      return 'hide';
    }
    return 'visible';
  }

  updateHeaderInfo() {
    this.headerInfo.tabs = this.peopleDataList;
    this.commonService.recieveMessage(this.headerInfo);
  }

  ngOnInit() {
    this.loggedOneBankId = localStorage.getItem('userOneBankId');
    this.restService.get(`/people/data/dataValues/sys-config?msgKey=People Edit Window - Previous Month`).subscribe(result => {
      this.editWindowPeriod = result['message'];
      this.userAccessCheck();
    },
    error => {
      this.showErrorMessage(error);
      this.userAccessCheck();
    });

    this.ReportPrdObserver = this.commonService.broadCastMessage.subscribe(data => {
      this.handleReportingPeriod();
    });

    // for updating tabs
    this.tabObeserver = this.commonService.selectedTab.subscribe(data => {
      this.searchText = "";
      this.onPeopleDataChange(data);
    })

    //this.handleReportingPeriod();
    this.roles = JSON.parse(sessionStorage.getItem('roles'));
    this.getDropDownValues();
    this.modulesMapping = JSON.parse(sessionStorage.getItem('modulesMapping'));
    let roleField = [];
    roleField = Object.keys(JSON.parse(sessionStorage.getItem('roles')));
    if (this.modulesMapping && this.modulesMapping['WORK_MGT'] && this.modulesMapping['WORK_MGT'].length > 0) {
      this.modulesMapping['WORK_MGT'].forEach(module => {
        if (module.subModule === 'PEOPLE_PROFILE') {
          if(roleField.includes('GENE_DBS_CENTRAL_FUNCTION') || roleField.includes('GENE_DBS_ADMIN')) {
            this.newJoinersAccess = true;
          }
          else{
            this.newJoinersAccess = false;
          }
          }
      });
    }
  }

  showErrorMessage(errorResponse: any){
    this.commonService.showSnackBar({ type: 'alert', message: errorResponse.statusText + ': ' + errorResponse.error.path + ' \n' + errorResponse.error.message, duration: 3000 });
  }

  ngOnDestroy() {
    // release used resource
    this.tabObeserver.unsubscribe();
    this.ReportPrdObserver.unsubscribe();
    if(this.pageSubscription){
      this.pageSubscription.unsubscribe();
     }
  }

  getStatusClass(status: string):string{
    if(status.toLowerCase()==='active'){
      return 'completed'
    } else if(status.toLowerCase()==='inactive'){
      return 'inactive';
    } else {
      return 'pending';
    }
  }

  userAccessCheck() {
    const currentDate = new Date().getDate();
    const pastMonth = new Date().getMonth();
    this.currentMonthStatus = this.dataService.getcurrentMonthStatus();
    this.restService.get(`/people/data/employee/userAccess?loggedInUserBankId=${this.loggedOneBankId}&rptPeriod=${this.reportingPeriod}`).subscribe(data => {
        if (data) {
          this.userAccessCheckValue = true;
        }
        this.handleTabsDisplay(this.selectedDate);
        this.updatePeopleProfileTabs();
      });


  }

  //getting empolyee status from db for statusList
  getStatusList() {
    this.restService.get(`/people/data/employee/staffstatuslist`).subscribe(data => {
      if (data) {
        data.forEach(e => {
          this.statusList.push({ key: e, value: e });
        });
        this.statusList.unshift({ key: 'all', value: 'All' });
      }
    });
  }

  getChapterNameList() {
    this.restService.get(`/people/data/employee/chapters`).subscribe(data => {
      if (data) {
        data = data.sort();
        data.forEach(e => {
          this.chapterNameList.push({ key: e, value: e });
        });
        this.chapterNameList.unshift({ key: 'all', value: 'All' });
      }
    });
  }

  forceNavigateToTab(tab: string){
    let tempHeader = Object.assign({}, this.headerInfo);
    tempHeader.prevent_idx_update = true;
    this.commonService.updateTab.emit(tab);
    this.commonService.recieveMessage(tempHeader);
  }

  handleTabsDisplay(dateValue: string){
    const currentDate = new Date().getDate();
    const pastMonth = new Date().getMonth();
    if (dateValue.includes('Current')) {
      this.currentMonthStatus = true;
      if (this.newJoinersAccess || this.userAccessCheckValue) {
        this.peopleDataList = ['Staff List', 'People By Chapters', 'New Staff Update', 'Teams & IC Assignment'];
      } else {
        this.peopleDataList = this.peopleDataListWithoutNewjoiner;
      }
      this.dataService.setcurrentMonthStatus(true);
    } else {
      this.selectedPeopleData = 'Staff List';
      this.currentMonthStatus = false;
      this.dataService.setcurrentMonthStatus(false);
      sessionStorage.setItem('reportingPeriodDate', JSON.stringify(this.selectedDate));
    }
    let currentMonth = Number(moment(new Date()).format('MM'));
    let currentYear = moment(new Date()).format('YYYY');
    if (this.currentMonthStatus) {
      this.reportingPeriod = currentYear + ('0' + currentMonth).slice(-2);
      this.selectedDate = this.dates[0];
    } else {
      if (this.selectedDate) {
        const month: string = '0' + (this.months.indexOf(this.selectedDate.substring(5, this.selectedDate.length)) + 1);
        const year: string = this.selectedDate.substring(0, 4);
        this.reportingPeriod = year + '' + month.slice(-2);
        if ((+this.reportingPeriod.slice(-2) === pastMonth && currentDate <= parseInt(this.editWindowPeriod))&& (this.newJoinersAccess || this.userAccessCheckValue)) {
          this.peopleDataList = ['Staff List', 'People By Chapters', 'New Staff Update', 'Teams & IC Assignment'];
        } else {
          this.peopleDataList = this.peopleDataListWithoutNewjoiner;
        }
      }
    }
  }

  onReportingPeriodChnage(e) {
    this.handleTabsDisplay(e.value);
    this.dataService.setRptPeriodObs(this.reportingPeriod);
    this.handleReportingPeriod();
    this.updatePeopleProfileTabs();
    this.userAccessCheck();
  }

  updatePeopleProfileTabs(){
    if(this.peopleDataList.includes(this.selectedPeopleData)){
      this.updateHeaderInfo();
    } else {
      this.forceNavigateToTab(this.peopleDataList[0]);
    }
  }

  onPeopleDataChange(data) {
    // if(data == '' || data == null || this.peopleDataList.indexOf(data) < 0){
    //   this.commonService.updateTab(this.selectedPeopleData);
    //   return;
    // }
    sessionStorage.setItem('listView', data);
    this.selectedPeopleData = data;
    this.showFilter = false;
    this.searchText = '';
    this.resetPageCount();
    if (this.selectedPeopleData === 'People By Chapters') {
      this.getDataForChapterView();
    } else if (this.selectedPeopleData === 'New Staff Update') {
      this.getDataForProfileUpdate();
    } else if (this.selectedPeopleData === 'Teams & IC Assignment') {
      this.getDataForTeamICAssignment();
    } else {
      this.getData();
    }

  }

  resetPageCount(){
    this.displayCount = 0;
    this.dataLength = 0;
  }

  checkForBD() {
    const currentMonth = Number(moment(new Date()).format('MM'));
    const currentYear = Number(moment(new Date()).format('YYYY'));
    const currentDay = Number(moment(new Date()).format('DD'));
    let month: string;
    let year: string;
    if (this.selectedDate) {
      month = '0' + (this.months.indexOf(this.selectedDate.substring(5, this.selectedDate.length)) + 1);
      year = this.selectedDate.substring(0, 4);
      this.reportingPeriod = year + '' + month.slice(-2);
    }
    if (Number(year) == currentYear) {
      if (currentDay <= 15 && Number(month) == (currentMonth - 1)) {
        this.restService.get(`people/data/employee/messagepeopledata`).subscribe(data => {
          this.bd11Msg = data['message'];
        })
      } else {
        this.bd11Msg = '';
      }
    } else if (Number(year) == (currentYear - 1) && currentMonth == 1) {
      if (currentDay <= 15 && month == '012') {
        this.restService.get(`people/data/employee/messagepeopledata`).subscribe(data => {
          this.bd11Msg = data['message'];
        })
      } else {
        this.bd11Msg = '';
      }
    } else {
      this.bd11Msg = '';
    }
  }

  getData() {
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    let currentMonth = Number(moment(new Date()).format('MM'));
    let currentYear = moment(new Date()).format('YYYY');
    const currentDate = new Date().getDate();
    const pastMonth = new Date().getMonth();
    this.currentMonthStatus = this.dataService.getcurrentMonthStatus();
    if (this.currentMonthStatus) {
      this.reportingPeriod = currentYear + ('0' + currentMonth).slice(-2);
      this.selectedDate = this.dates[0];
    } else {
      if (this.selectedDate) {
        let month: string = '0' + (this.months.indexOf(this.selectedDate.substring(5, this.selectedDate.length)) + 1);
        let year: string = this.selectedDate.substring(0, 4);
        this.reportingPeriod = year + '' + month.slice(-2);
        if ((+this.reportingPeriod.slice(-2) === pastMonth && currentDate <= parseInt(this.editWindowPeriod))) {
          this.peopleDataList = ['Staff List', 'People By Chapters', 'New Staff Update', 'Teams & IC Assignment'];
        } else {
          this.peopleDataList = this.peopleDataListWithoutNewjoiner;
        }
      }
    }
    sessionStorage.setItem('rptPeriod', this.reportingPeriod);

    this.peopleService.getPeopleProfile(lobts,platforms,locations,this.reportingPeriod).subscribe(data => {
      this.dataSource.data = data;
      this.dataSource.sort = this.sort;
      this.dataSource.sortingDataAccessor = (data, header) => {
        if (this.displayedColumns.includes(header)) {
          if (typeof (data[header]) != 'number' && data[header]) {
            return data[header].toString().toLowerCase();
          } else {
            return data[header];
          }
        }
      }
      
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      this.dataLength = this.dataSource.data.length;
      this.paginator.pageIndex = 0;
      this.updateDisplayCount();
      this.pageSubscription = this.paginator.page.subscribe(pageObj => {
        this.pageSize = pageObj.pageSize;
        this.updateDisplayCount();
      });
      this.filterDataForStaffList();
    });
    this.filterChanges();
  }

  getDataForChapterView() {
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    let currentMonth = Number(moment(new Date()).format('MM'));
    let currentYear = moment(new Date()).format('YYYY');
    if (this.currentMonthStatus) {
      this.reportingPeriod = currentYear + ('0' + currentMonth).slice(-2);
      this.selectedDate = this.dates[0];
    } else {
      if (this.selectedDate) {
        let month: string = '0' + (this.months.indexOf(this.selectedDate.substring(5, this.selectedDate.length)) + 1);
        let year: string = this.selectedDate.substring(0, 4);
        this.reportingPeriod = year + '' + month.slice(-2);
      }
    }

    this.restService.post(`/people/data/employee/all/chapters`, { techUnits: lobts, platforms: platforms, location: locations, rptPeriod: this.reportingPeriod }).subscribe(data => {
      this.dataSourceChapter.data = data;
      this.dataSourceChapter.sort = this.sort;
      this.dataSourceChapter.sortingDataAccessor = (data, header) => {
        if (this.displayedColumnsForChapters.includes(header)) {
          if (typeof (data[header]) != 'number' && data[header]) {
            return data[header].toString().toLowerCase();
          } else {
            return data[header];
          }
        }
      }
      this.dataSourceChapter.sort = this.sort;
      this.dataSourceChapter.paginator = this.paginator;
      this.dataLength = this.dataSourceChapter.data.length;
      this.paginator.pageIndex = 0;
      this.updateDisplayCount();
      this.pageSubscription = this.paginator.page.subscribe(pageObj => {
        this.pageSize = pageObj.pageSize;
        this.updateDisplayCount();
      });
      this.filterDataForPeopleByChapters();
    });
    this.filterChangesForChapter();
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustomForPeople(date);
  }

  getDataForProfileUpdate() {
    const platform = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    const currentMonth = Number(moment(new Date()).format('MM'));
    const currentYear = moment(new Date()).format('YYYY');
    if (this.currentMonthStatus) {
      this.reportingPeriod = currentYear + ('0' + currentMonth).slice(-2);
      this.selectedDate = this.dates[0];
    } else {
      if (this.selectedDate) {
        const month: string = '0' + (this.months.indexOf(this.selectedDate.substring(5, this.selectedDate.length)) + 1);
        const year: string = this.selectedDate.substring(0, 4);
        this.reportingPeriod = year + '' + month.slice(-2);
      }
    }
    if(this.newJoinersAccess) {
      this.restService.post('/people/data/employee/all/newjoiners', {techUnits: lobts, platforms: platform, location: locations, rptPeriod: this.reportingPeriod}).subscribe(data => {
        this.newJoinersData = data;
        this.newJoinersData.forEach(ele => {
          ele['dateCreated'] = this.dateFormat(ele['dateCreated'])
        })
        this.dataSourceNewJoiners = new MatTableDataSource<any>();
        this.dataSourceNewJoiners.data = this.newJoinersData;
        this.dataSourceNewJoiners.sort = this.sort;
        this.dataSourceNewJoiners.paginator = this.paginator;
        this.dataSourceNewJoiners.sortingDataAccessor = (data, header) => {
          if (this.displayedColumnsForNewJoiners.includes(header)) {
            if (typeof (data[header]) !== 'number' && data[header]) {
              return data[header].toString().toLowerCase();
            } else {
              return data[header];
            }
          }
        }
        this.dataSourceNewJoiners.sort = this.sort;
        this.dataSourceNewJoiners.paginator = this.paginator;
        this.dataLength = this.dataSourceNewJoiners.data.length;
        this.paginator.pageIndex = 0;
        this.pageSubscription = this.paginator.page.subscribe(pageObj => {
          this.pageSize = pageObj.pageSize;
          this.updateDisplayCount();
        });
        this.updateDisplayCount();
        this.selection.clear();
        this.filterDataForNewStaffChapter();
      });
    }
    else if (this.newJoinersAccess==false && this.userAccessCheckValue){
      this.restService.post('/people/data/employee/all/newjoiners/reportingmanager', {techUnits: lobts, platforms: platform, location: locations, rptPeriod: this.reportingPeriod,loggedOnebankId: this.loggedOneBankId}).subscribe(data => {
        this.newJoinersData = data;
        this.newJoinersData.forEach(ele => {
          ele['dateCreated'] = this.dateFormat(ele['dateCreated'])
        })
        this.dataSourceNewJoiners = new MatTableDataSource<any>();
        this.dataSourceNewJoiners.data = this.newJoinersData;
        this.dataSourceNewJoiners.sort = this.sort;
        this.dataSourceNewJoiners.paginator = this.paginator;
        this.dataSourceNewJoiners.sortingDataAccessor = (data, header) => {
          if (this.displayedColumnsForNewJoiners.includes(header)) {
            if (typeof (data[header]) !== 'number' && data[header]) {
              return data[header].toString().toLowerCase();
            } else {
              return data[header];
            }
          }
        }
        this.dataLength = this.dataSourceNewJoiners.data.length;
        this.paginator.pageIndex = 0;
        this.pageSubscription = this.paginator.page.subscribe(pageObj => {
          this.pageSize = pageObj.pageSize;
          this.updateDisplayCount();
        });
        this.updateDisplayCount();
        this.selection.clear();
        this.filterDataForNewStaffChapter();
      });
    }
    this.filterChangesForNewJoinee();

  }
  icHighValue: number = 1;
  icValue: number = 0;

  getDataForTeamICAssignment() {
    var platform = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    var lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    var locations = JSON.parse(sessionStorage.getItem('locations'));

    this.restService.post(`/people/data/employee/deliveryTeams?reportPeriod=${this.reportingPeriod}
      &icfteRangeLow=${this.icValue}&icfteRangeHigh=${this.icHighValue}&pcftFTERangeLow=${this.pcftValue}
      &pcFTERangeHigh=${this.pcftHighValue}&nonPcftFTERangeLow=${this.nonPcftValue}
      &nonPcftFTERangeHigh=${this.nonPcftHighValue}&augPcftFTERangeLow=${this.augPcftValue}
      &augPcftFTERangeHigh=${this.augPcftHighValue}&augNonPcftFTERangeLow=${this.augNonPcftValue}
      &augNonPcftFTERangeHigh=${this.augNonPcftHighValue}`,
      { techUnits: lobts, platforms: platform, location: locations }).subscribe(data => {
    
        this.dataSourceTeamIC.data = data;
        this.dataSourceTeamIC.paginator = this.paginator;
        this.dataSourceTeamIC.sort = this.sort;
        this.dataSourceTeamIC.sortingDataAccessor = (data, header) => {
          if (this.displayedColumnsForTeamIC.includes(header)) {
            if (typeof (data[header]) !== 'number' && data[header]) {
              return data[header].toString().toLowerCase();
            } else {
              return data[header];
            }
          }
        }
        this.dataLength = this.dataSourceTeamIC.data.length;
        this.paginator.pageIndex = 0;
        this.pageSubscription = this.paginator.page.subscribe(pageObj => {
          this.pageSize = pageObj.pageSize;
          this.updateDisplayCount();
        });
        this.updateDisplayCount();
        this.filterDataForTeamsICAndAssignment();
      }, error => {
        this.showErrorMessage(error);
        this.dataSourceTeamIC.data = [];
        this.paginator.pageIndex = 0;
        this.dataLength = this.dataSourceTeamIC.data.length;
        this.pageSubscription = this.paginator.page.subscribe(pageObj => {
          this.pageSize = pageObj.pageSize;
          this.updateDisplayCount();
        });
        this.updateDisplayCount();
      });
      this.filterChangesForICTeam();

    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=TEAMS-ICFTE-tooltip`).subscribe(result => {
      this.icFteTooltip = result.message;
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=TEAMS-PCFT-tooltip`).subscribe(result => {
      this.pcftTooltip = result.message;
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=TEAMS-NON-PCFT-tooltip`).subscribe(result => {
      this.nonPcftTooltip = result.message;
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=TEAMS-AUG-PCFT-tooltip`).subscribe(result => {
      this.augPcftTooltip = result.message;
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=TEAMS-AUG-NON-PCFT-tooltip`).subscribe(result => {
      this.augNonPcftTooltip = result.message;
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=TEAMS-PCFT-MEMBERSHIP-tooltip`).subscribe(result => {
      this.pcftTooltipMembership = result.message;
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=TEAMS-NON-PCFT-MEMBERSHIP-tooltip`).subscribe(result => {
      this.nonPcftTooltipMembership = result.message;
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=TEAMS-AUG-PCFT-MEMBERSHIP-tooltip`).subscribe(result => {
      this.augPcftTooltipMembership = result.message;
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=TEAMS-AUG-NON-PCFT-MEMBERSHIP-tooltip`).subscribe(result => {
      this.augNonPcftTooltipMembership = result.message;
    });
  }

  getToolTipDataICTeam(type: string) {
    let str = '';
    if (type === 'IC-FTE') {
      str = str + 'IC-FTE \n' + this.icFteTooltip;
    }
    if (type === 'PCFT FTE') {
      str = str + 'PCFT FTE \n' + this.pcftTooltip;
    }
    if (type === 'NPCFT FTE') {
      str = str + 'NPCFT FTE \n' + this.nonPcftTooltip;
    }
    if (type === 'AO-PCFT FTE') {
      str = str + 'AO-PCFT FTE \n' + this.augPcftTooltip;
    }
    if (type === 'AO-NPCFT FTE') {
      str = str + 'AO-NPCFT FTE \n' + this.augNonPcftTooltip;
    }
    if (type === 'PCFT Membership') {
      str = str + 'PCFT Membership \n' + this.pcftTooltipMembership;
    }
    if (type === 'NPCFT Membership') {
      str = str + 'NPCFT Membership \n' + this.nonPcftTooltipMembership;
    }
    if (type === 'AO-PCFT Membership') {
      str = str + 'AO-PCFT Membership \n' + this.augPcftTooltipMembership;
    }
    if (type === 'AO-NPCFT Membership') {
      str = str + 'AO-NPCFT Membership \n' + this.augNonPcftTooltipMembership;
    }
    return this.getStringFromHtml(str);
  }
  onICRangeClick(event) {
    const dialogRef = this.dialog.open(IcRangeComponent, {
      data: {
      }, position: { top: '10%', left: '45%' }
    }).afterClosed()
      .subscribe(data => {
        this.icHighValue = data["data"].icHighValue;
        this.icValue = data["data"].icValue;
        this.getDataForTeamICAssignment();
      });
  }
  pcftHighValue: number = 1;
  pcftValue: number = 0;
  onPCFTRangeClick(event) {
    const dialogRef = this.dialog.open(PcftRangeComponent, {
      data: {
      }, position: { top: '10%', left: '50%' }
    }).afterClosed()
      .subscribe(data => {
        this.pcftHighValue = data["data"].pcftHighValue;
        this.pcftValue = data["data"].pcftValue;
        this.getDataForTeamICAssignment();
      });
  }
  nonPcftHighValue: number = 1;
  nonPcftValue: number = 0;
  onNonPCFTRangeClick(event) {
    const dialogRef = this.dialog.open(NonPcftRangeComponent, {
      data: {
      }, position: { top: '10%', left: '55%' }
    }).afterClosed()
      .subscribe(data => {
        this.nonPcftHighValue = data["data"].nonPcftHighValue;
        this.nonPcftValue = data["data"].nonPcftValue;
        this.getDataForTeamICAssignment();
      });
  }
  augPcftHighValue: number = 1;
  augPcftValue: number = 0;
  onAugPCFTRangeClick(event) {
    const dialogRef = this.dialog.open(AugPcftRangeComponent, {
      data: {
      }, position: { top: '10%', left: '60%' }
    }).afterClosed()
      .subscribe(data => {
        this.augPcftHighValue = data["data"].augPcftHighValue;
        this.augPcftValue = data["data"].augPcftValue;
        this.getDataForTeamICAssignment();
      });
  }
  augNonPcftHighValue: number = 1;
  augNonPcftValue: number = 0;
  onAugNonPCFTRangeClick(event) {
    const dialogRef = this.dialog.open(AugNonPcftRangeComponent, {
      data: {
      }, position: { top: '10%', left: '65%' }
    }).afterClosed()
      .subscribe(data => {
        this.augNonPcftHighValue = data["data"].augNonPcftHighValue;
        this.augNonPcftValue = data["data"].augNonPcftValue;
        this.getDataForTeamICAssignment();
      });
  }

  handleReportingPeriod() {
    const platform = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    const reportingPeriodDate = JSON.parse(sessionStorage.getItem('reportingPeriodDate'));
    if (reportingPeriodDate) {
      this.selectedDate = reportingPeriodDate;
    }
    //Getting List for Reporting Period.
    if (lobts && platform && locations) {
      this.restService.post(`people/data/employee/getreportmonthyear`, { techUnits: lobts, platforms: platform, location: locations }).subscribe(data => {
        if (data) {
          this.dates = [];
          this.dates.push('Current View')
          data.forEach(ele => {
            const reportingYear = ele.substring(0, 4);
            let reportingMonth = ele.substring(4, 6);
            // Taking reporting month without 0.
            if (reportingMonth && reportingMonth.charAt(0) === 0) {
              reportingMonth = reportingMonth.charAt(1);
            }
            this.dates.push(reportingYear + ' ' + this.months[reportingMonth - 1]);
          });
          // if (reportingPeriodDate != this.dates[0] ) {
          //   this.peopleDataList = this.peopleDataListWithoutNewjoiner;
          // }
        }
        //Commenting this code for UAT.Need to add this PROD.
        const currentMonth = Number(moment(new Date()).format('MM'));
        const currentYear = moment(new Date()).format('YYYY');
        const currentDay = Number(moment(new Date()).format('DD'));
        if (!reportingPeriodDate) {
          if (currentDay >= 15) {
            this.selectedDate = currentYear + ' ' + this.months[currentMonth - 2];
          } else {
            this.selectedDate = currentYear + ' ' + this.months[currentMonth - 3];
          }
          const selectedDatePresent = this.dates.includes(this.selectedDate);
          if (!selectedDatePresent) {
            this.selectedDate = this.dates[1];
          }
          sessionStorage.setItem('reportingPeriodDate', JSON.stringify(this.selectedDate));
        }
        this.resetPageCount();
        this.checkForBD();
        if (this.selectedPeopleData === 'People By Chapters') {
          this.getDataForChapterView();
        } else if (this.selectedPeopleData === 'New Staff Update') {
          this.getDataForProfileUpdate();
        } else if (this.selectedPeopleData === 'Teams & IC Assignment') {
          this.getDataForTeamICAssignment();
        } else {
          this.getData();
        }

      });
    }
  }

  showSuccessDialog(title: string, message: string){
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      data: {
      type: 'success',
      contentTitle: title,
      content: message,
      confirmTxt: "Ok"
      }
    });

    return dialogRef;
  }

  onImportClick() {
    const dialogRef = this.dialog.open(ImportDialogComponent, {
      data: {
        header: 'Import People Data',
        refType: 'PEOPLE',
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.errorData = result;
      if (result && result['errorFlag'] === '0') {
        const successDialogRef = this.showSuccessDialog('Import Submitted', 'Your data import has been submitted.\nYou will be notified via email on the status.');
      } else if(result && result['errorFlag'] === '1'){
        console.warn('error >> ', result);
      }
    });
  }

  importButtonHideCheck() {
    if (this.roles && (this.roles['GENE_DBS_ADMIN'] || this.roles['GENE_DBS_CENTRALFUNCTION'])
      && (this.selectedPeopleData === 'Staff List')) {
      return true;
    }
    return false;
  }

  applyFilter(filterValue: string) {
    if (this.showFilter) {
      this.showFilter = false;
    }
    if (this.selectedPeopleData === 'Staff List') {
      for (var i in this.filterValues) {
        this.filterValues[i] = filterValue.trim().toLowerCase();
      }
      this.dataSource.filter = JSON.stringify(this.filterValues);
      this.dataSource.filterPredicate = this.dataTableService.tableFilterForSearch();
      this.dataLength = this.dataSource.filteredData.length;
    } else if (this.selectedPeopleData === 'People By Chapters') {
      for (var i in this.filterValuesForChapter) {
        this.filterValuesForChapter[i] = filterValue.trim().toLowerCase();
      }
      this.dataSourceChapter.filter = JSON.stringify(this.filterValuesForChapter);
      this.dataSourceChapter.filterPredicate = this.dataTableService.tableFilterForSearch();
      this.dataLength = this.dataSourceChapter.filteredData.length;
    }
    else if (this.selectedPeopleData === 'New Staff Update') {
      for (var i in this.filterValuesForNewJoinee) {
        this.filterValuesForNewJoinee[i] = filterValue.trim().toLowerCase();
      }
      this.dataSourceNewJoiners.filter = JSON.stringify(this.filterValuesForNewJoinee);
      this.dataSourceNewJoiners.filterPredicate = this.dataTableService.tableFilterForSearch();
      this.dataLength = this.dataSourceNewJoiners.filteredData.length;
    }
    else if (this.selectedPeopleData === 'Teams & IC Assignment') {
      for (var i in this.filterValuesForICTeam) {
        this.filterValuesForICTeam[i] = filterValue.trim().toLowerCase();
      }
      this.dataSourceTeamIC.filter = JSON.stringify(this.filterValuesForICTeam);
      this.dataSourceTeamIC.filterPredicate = this.dataTableService.tableFilterForSearch();
      this.dataLength = this.dataSourceTeamIC.filteredData.length;
    }

    this.updateDisplayCount();
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.dataSourceChapter.sort = this.sort;
    this.dataSourceChapter.paginator = this.paginator;
  }

  filterDataForStaffList(){
    if (this.filterValues) {
      for (let field in this.filterValues) {
        this.filterValues[field] = '';
      }
      this.dataSource.filter = JSON.stringify(this.filterValues);
    }
    this.empNameFilter.setValue('');
    this.oneBankIdFilter.setValue('');
    this.empTypeFilter.setValue('');
    this.empStatusFilter.setValue(this.defaultStaffStatus, {onlySelf: true});
    this.platformFilter.setValue('');
    this.reportingMgrFilter.setValue('');
    this.staffPccodeFilter.setValue('');
    this.subPlatformFilter.setValue('');
    this.countryCodeFilter.setValue('');
    this.workLocationFilter.setValue('');
    this.tacoIndicatorFilter.setValue('');
  }

  filterDataForPeopleByChapters(){
    if (this.filterValuesForChapter) {
      for (let field in this.filterValuesForChapter) {
        this.filterValuesForChapter[field] = '';
      }
      this.dataSourceChapter.filter = JSON.stringify(this.filterValuesForChapter);
    }
    this.empNameFilter.setValue('');
    this.oneBankIdFilter.setValue('');
    this.empTypeFilter.setValue('');
    this.empStatusFilter.setValue(this.defaultStaffStatus, {onlySelf: true});
    this.platformFilter.setValue('');
    this.subPlatformFilter.setValue('');
    this.chapterLeadFilter.setValue('');
    this.chapterNameFilter.setValue('');
    this.workLocationFilter.setValue('');
    this.tacoIndicatorFilter.setValue('');
  }

  filterDataForNewStaffChapter(){
    if (this.filterValuesForNewJoinee) {
      for (let field in this.filterValuesForNewJoinee) {
        this.filterValuesForNewJoinee[field] = '';
      }
      this.dataSourceNewJoiners.filter = JSON.stringify(this.filterValuesForNewJoinee);
    }
    this.empNameFilter.setValue('');
    this.oneBankIdFilter.setValue('');
    this.empTypeFilter.setValue('');
    this.dateCreatedFilter.setValue('');
    this.reportingMgrFilter.setValue('');
    this.platformFilter.setValue('');
    this.subPlatformFilter.setValue('');
    this.chapterNameFilter.setValue('');
    //this.onOffshoreFilter.setValue('');
    this.typeOfWork1Filter.setValue('');
    this.typeOfWork2Filter.setValue('');
  }

  filterDataForTeamsICAndAssignment(){
    if (this.filterValuesForICTeam) {
      for (let field in this.filterValuesForICTeam) {
        this.filterValuesForICTeam[field] = '';
      }
      this.dataSourceTeamIC.filter = JSON.stringify(this.filterValuesForICTeam);
    }
    this.staffNameICFilter.setValue('');
    this.oneBankIdICFilter.setValue('');
    this.platformICFilter.setValue('');
    this.subPlatformICFilter.setValue('');

    this.pcftMembershipFilter.setValue('');
    this.nonPCFTMembershipFilter.setValue('');
    this.augPCFTMembershipFilter.setValue('');
    this.augNonPCFTMembershipFilter.setValue('');
    this.icValue = 0;
    this.icHighValue = 1;
    this.pcftValue = 0;
    this.pcftHighValue = 1;
    this.nonPcftValue = 0;
    this.nonPcftHighValue = 1;
    this.augPcftValue = 0;
    this.augPcftHighValue = 1;
    this.augNonPcftValue = 0;
    this.augNonPcftHighValue = 1;
  }

  toggleFilter($event) {
    this.searchText = '';
    this.showFilter = !this.showFilter;
    if (this.selectedPeopleData === 'Staff List') {
      this.filterDataForStaffList();
    } else if (this.selectedPeopleData === 'People By Chapters') {
      this.filterDataForPeopleByChapters();
    } else if (this.selectedPeopleData === 'New Staff Update') {
      this.filterDataForNewStaffChapter();
    } else if (this.selectedPeopleData === 'Teams & IC Assignment') {
      this.filterDataForTeamsICAndAssignment();
    }
  }

  filterDisplay(filterValues: any){
    this.dataSource.filter = JSON.stringify(filterValues);
    this.dataSource.filterPredicate = this.dataTableService.tableFilter();
    this.dataLength = this.dataSource.filteredData.length;
    this.updateDisplayCount();
  }

  filterDisplayForChapter(filterValues: any){
    this.dataSourceChapter.filter = JSON.stringify(filterValues);
    this.dataSourceChapter.filterPredicate = this.dataTableService.tableFilter();
    this.dataLength = this.dataSourceChapter.filteredData.length;
    this.updateDisplayCount();
  }

  filterDisplayForNewJoiners(filterValues: any){
    this.dataSourceNewJoiners.filter = JSON.stringify(filterValues);
    this.dataSourceNewJoiners.filterPredicate = this.dataTableService.tableFilter();
    this.dataLength = this.dataSourceNewJoiners.filteredData.length;
    this.updateDisplayCount();
  }

  filterDisplayForICTTeam(filterValues: any){
    this.dataSourceTeamIC.filter = JSON.stringify(filterValues);
    this.dataSourceTeamIC.filterPredicate = this.dataTableService.tableFilter();
    this.dataLength = this.dataSourceTeamIC.filteredData.length;
    this.updateDisplayCount();
  }

  filterChanges() {
    this.empNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.empName = data;
          this.filterDisplay(this.filterValues);
        }
      )
    this.oneBankIdFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.oneBankId = data;
          this.filterDisplay(this.filterValues);
        }
      )
    this.empStatusFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.empStatus = data;
          this.filterDisplay(this.filterValues);
        }
      )
    this.empTypeFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.empType = data;
          this.filterDisplay(this.filterValues);
        }
      )
    this.platformFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.platform = data;
          this.filterDisplay(this.filterValues);
        }
      )
    this.reportingMgrFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.reportingMgr = data;
          this.filterDisplay(this.filterValues);
        }
      )
    this.staffPccodeFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.staffPccode = data;
          this.filterDisplay(this.filterValues);
        }
      )
    this.subPlatformFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.subPlatform = data;
          this.filterDisplay(this.filterValues);
        }
      )
    this.workLocationFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.workLocation = data;
          this.filterDisplay(this.filterValues);
        }
      )
    this.countryCodeFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.countryCode = data;
          this.filterDisplay(this.filterValues);
        }
      )
    this.tacoIndicatorFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.tacoInd = data;
          this.filterDisplay(this.filterValues);
        }
      )
  }

  filterChangesForChapter() {
    this.empNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForChapter.empName = data;
          this.filterDisplayForChapter(this.filterValuesForChapter);
        }
      )
    this.oneBankIdFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForChapter.oneBankId = data;
          this.filterDisplayForChapter(this.filterValuesForChapter);
        }
      )
    this.empStatusFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForChapter.empStatus = data;
          this.filterDisplayForChapter(this.filterValuesForChapter);
        }
      )
    this.empTypeFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForChapter.empType = data;
          this.filterDisplayForChapter(this.filterValuesForChapter);
        }
      )
    this.platformFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForChapter.platform = data;
          this.filterDisplayForChapter(this.filterValuesForChapter);
        }
      )
    this.subPlatformFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForChapter.subPlatform = data;
          this.filterDisplayForChapter(this.filterValuesForChapter);
        }
      )
    this.chapterLeadFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForChapter.chapterLead = data;
          this.filterDisplayForChapter(this.filterValuesForChapter);
        }
      )
    this.chapterNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForChapter.chapterName = data;
          this.filterDisplayForChapter(this.filterValuesForChapter);
        }
      )
    this.workLocationFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForChapter.workLocation = data;
          this.filterDisplayForChapter(this.filterValuesForChapter);
        }
      )
    this.tacoIndicatorFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForChapter.tacoInd = data;
          this.filterDisplayForChapter(this.filterValuesForChapter);
        }
      )
  }

  filterChangesForNewJoinee() {
    this.empNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForNewJoinee.empName = data;
          this.filterDisplayForNewJoiners(this.filterValuesForNewJoinee);
        }
      )
    this.oneBankIdFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForNewJoinee.oneBankId = data;
          this.filterDisplayForNewJoiners(this.filterValuesForNewJoinee);
        }
      )
    this.empTypeFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForNewJoinee.empType = data;
          this.filterDisplayForNewJoiners(this.filterValuesForNewJoinee);
        }
      )
    this.dateCreatedFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForNewJoinee.dateCreated = data;
          this.filterDisplayForNewJoiners(this.filterValuesForNewJoinee);
        }
      )
    this.reportingMgrFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForNewJoinee.reportingMgr = data;
          this.filterDisplayForNewJoiners(this.filterValuesForNewJoinee);
        }
      )
    this.platformFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForNewJoinee.platform = data;
          this.filterDisplayForNewJoiners(this.filterValuesForNewJoinee);
        }
      )
    this.subPlatformFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForNewJoinee.subPlatform = data;
          this.filterDisplayForNewJoiners(this.filterValuesForNewJoinee);
        }
      )


    this.typeOfWork1Filter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForNewJoinee.typeOfWork1 = data;
          this.filterDisplayForNewJoiners(this.filterValuesForNewJoinee);
        }
      )
    this.typeOfWork2Filter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForNewJoinee.typeOfWork2 = data;
          this.filterDisplayForNewJoiners(this.filterValuesForNewJoinee);
        }
      )
    // this.onOffshoreFilter.valueChanges
    //   .subscribe(
    //     data => {
    //       this.filterValuesForNewJoinee.onOffshore = data;
    //       this.dataSourceNewJoiners.filter = JSON.stringify(this.filterValuesForNewJoinee);
    //       this.dataSourceNewJoiners.filterPredicate = this.dataTableService.tableFilter();
    //     }
    //   )
    this.chapterNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForNewJoinee.chapterName = data;
          this.filterDisplayForNewJoiners(this.filterValuesForNewJoinee);
        }
      )
  }
  filterChangesForICTeam() {
    this.staffNameICFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForICTeam.staffName = data;
          this.filterDisplayForICTTeam(this.filterValuesForICTeam);
        }
      )
    this.oneBankIdICFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForICTeam.oneBankId = data;
          this.filterDisplayForICTTeam(this.filterValuesForICTeam);
        }
      )
    this.platformICFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForICTeam.platForm = data;
          this.filterDisplayForICTTeam(this.filterValuesForICTeam);
        }
      )
    this.subPlatformICFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForICTeam.subPlatform = data;
          this.filterDisplayForICTTeam(this.filterValuesForICTeam);
        }
      )
    this.pcftMembershipFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForICTeam.pcftMembership = data;
          this.filterDisplayForICTTeam(this.filterValuesForICTeam);
        }
      )
    this.nonPCFTMembershipFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForICTeam.nonPCFTMembership = data;
          this.filterDisplayForICTTeam(this.filterValuesForICTeam);
        }
      )
    this.augPCFTMembershipFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForICTeam.augPCFTMembership = data;
          this.filterDisplayForICTTeam(this.filterValuesForICTeam);
        }
      )
    this.augNonPCFTMembershipFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesForICTeam.augNonPCFTMembership = data;
          this.filterDisplayForICTTeam(this.filterValuesForICTeam);
        }
      )
  }
  getMoreInfo(event, element) {
    this.dataService.setPassingOneBankId(element['oneBankId']);
    this.dataService.setReportingPeriod(this.reportingPeriod);
    this.dataService.setSurrId(element['surrId']);
    this.commonService.trackEvent('PEOPLE PROFILE', 'click', 'People selection', element.empName);
    if (this.currentMonthStatus) {
      this.dataService.setcurrentMonthStatus(true);
    }
    this.router.navigateByUrl('home/workforce/people-profile/additionalInfo');
    window.scroll(0, 0);
  }

  getDropDownValues() {
    let request = ['Onshore/Offshore', 'Billing Type', 'Type of Work 1', 'Type of Work 2'];
    this.restService.post(`/people/data/dataSummary/dataValues`, request).subscribe(res => {
      sessionStorage.setItem('dataValues', JSON.stringify(res));

    });
  }

  updateProfile($event) {

    const dialogRef = this.dialog.open(UpdateProfileComponent, {
      data: {
        selectedValues: this.selection.selected
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.errorData = result;
        if (result['errorFlag'] === '0') {
          this.isSuccessMsg = true;
          this.dataService.getCustomMessage(result['message']);
          this.dataService.getFlag(result['errorFlag']);
        }
        this.getDataForProfileUpdate();
      }
    });

  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSourceNewJoiners.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
    } else {
      this.dataSourceNewJoiners.data.forEach(row => this.selection.select(row));
    }
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: any): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.id + 1}`;
  }

  handleChapterName(name: string) {
    if (name) {
      let chaptersName = name.split(',');
      if (chaptersName.length === 1) {
        return chaptersName[0];
      } else {
        return '<span style="color:blue">' + chaptersName.length + '</span>';
      }
    }
  }

  getToolTipData(chapterName: string) {
    if (chapterName) {
      let chaptersName = chapterName.split(',');
      if (chaptersName.length > 1) {
        let str = 'Chapters \n';
        let i = 1;
        chaptersName.forEach(ch => {
          str = str + i + '. \n' + ch + ' ';
          i = i + 1;
        });
        str.replace('\n', '<br>');
        return this.getStringFromHtml(str);
      }
    }

  }

  getStringFromHtml(text) {
    const html = text;
    const div = document.createElement('div');
    div.innerHTML = html;
    return div.textContent || div.innerText || '';
  }

  clear_search() {
    this.searchText = '';
    this.applyFilter('');
  }
}

export interface DeliveryTeamData {
  staffName: string;
  oneBankId: string;
  platForm: string;
  subPlatform: string;
  icFTE: number;
  pcftFTE: number;
  nonPCFTFTE: number;
  augPCFTFTE: number;
  augNonPCFTFTE: number;
  pcftMembership: number;
  nonPCFTMembership: number;
  augPCFTMembership: number;
  augNonPCFTMembership: number;
}
