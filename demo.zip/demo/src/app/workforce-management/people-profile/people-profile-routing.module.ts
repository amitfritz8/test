import { NgModule } from "@angular/core";
import { Routes, RouterModule } from '@angular/router';
import { PeopleProfileComponent } from './people-profile.component';
import { PeopleAdditionalInfoComponent } from "./people-additional-info/people-additional-info.component";
import { PeopleResolver } from "./people.resolver";

const routes: Routes = [
  { path: '', component: PeopleProfileComponent },
  { path: 'additionalInfo', component:  PeopleAdditionalInfoComponent, runGuardsAndResolvers: 'always', resolve: { peopleData: PeopleResolver }}
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})

export class PeopleProfileRoutingModule {}
