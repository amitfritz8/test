// import {async, ComponentFixture, TestBed, fakeAsync, inject} from '@angular/core/testing';
// import {PeopleAdditionalInfoComponent} from './people-additional-info.component';
// import {FormsModule, ReactiveFormsModule} from '@angular/forms';
// import {DateUtility} from '../../../../common/date-utility';
// import {DataService} from '../../../../shared/services/data.service';
// import {RestService} from '../../../../shared/http/rest-service';
// import {TimeFormat} from '../../../../common/timeFormater.pipe';
// import {HttpClientModule} from '@angular/common/http';
// import {MaterialModule} from '../../../../material.module';
// import {DropDownsModule} from '@progress/kendo-angular-dropdowns';
// import {GridModule} from '@progress/kendo-angular-grid';
// import {GaugesModule} from '@progress/kendo-angular-gauges';
// import {CurrencyMaskModule} from 'ng2-currency-mask';
// import {AppRoutingModule} from '../../../../app-routing.module';
// import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// import {RxReactiveFormsModule} from '@rxweb/reactive-form-validators';
// import {InputsModule} from '@progress/kendo-angular-inputs';
// import {BrowserModule, By} from '@angular/platform-browser';
// import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
// import {RichLoginComponent} from '../../../../login/rich-login.component';
// import {of} from 'rxjs';
// import {Router, RouterEvent} from '@angular/router';
// import {RouterTestingModule} from '@angular/router/testing';
// import {PeopleProfileComponent} from '../people-profile.component';
// import {DebugElement} from '@angular/core';
// import {configureTestSuite} from 'ng-bullet';

// describe('PeopleAdditionalInfoComponent', () => {
//   let component: PeopleAdditionalInfoComponent;
//   let fixture: ComponentFixture<PeopleAdditionalInfoComponent>;
//   let de: DebugElement;
//   let el: HTMLElement;

//   configureTestSuite(() => {
//     TestBed.configureTestingModule({
//       imports: [
//         BrowserModule,
//         AppRoutingModule,
//         FormsModule,
//         ReactiveFormsModule,
//         HttpClientModule,
//         MaterialModule,
//         BrowserAnimationsModule,
//         CurrencyMaskModule,
//         GridModule,
//         GaugesModule,
//         NgbModule,
//         RxReactiveFormsModule,
//         DropDownsModule,
//         InputsModule
//       ],
//       declarations: [
//         PeopleAdditionalInfoComponent,
//         RichLoginComponent
//       ],
//       providers: [
//         {provide: DataService, useClass: MockDataService},
//         {provide: RestService, useClass: MockRestService},
//         {provide: DateUtility, useClass: MockDateUtility},
//         {provide: TimeFormat, useClass: MockTimeFormat},
//         {provide: Router, useClass: MockRouter}
//       ]
//     })
//     fixture = TestBed.createComponent(PeopleAdditionalInfoComponent);
//     component = fixture.componentInstance;
//     component.oneBankId = 'marissa';
//     component.action = 'view';
//     // component.element = null;
//     component.platform = null;
//     component.contractemp = true;
//     fixture.detectChanges();
//     de = fixture.debugElement.query(By.css('.mainDiv'));
//     el = de.nativeElement;
//   });


//   it('should create component', () => {
//     expect(component).toBeTruthy();
//   });

//   describe('dateFormat', () => {
//     it('should call date format', () => {
//       const date = new Date();
//       component.dateFormat(new Date());
//       let c: MockDateUtility = new MockDateUtility();
//       spyOn(c, 'dateFormatterCustom');
//       c.dateFormatterCustom(date);
//       expect(c.dateFormatterCustom).toHaveBeenCalled();
//     });
//   });

//   describe('timeFormat', () => {
//     it('should call time format', () => {
//       let date = new Date();
//       component.timeFormat(new Date());
//       let c: MockTimeFormat = new MockTimeFormat();
//       spyOn(c, 'transform');
//       c.transform(date);
//       expect(c.transform).toHaveBeenCalled();
//     });
//   });

//   describe('goback', () => {
//     it('should call go back', () => {
//       component.goback();
//       let router: MockRouter = new MockRouter();
//       spyOn(router, 'navigateByUrl');
//       router.navigateByUrl('home/peopleprofile');
//       expect(router.navigateByUrl).toHaveBeenCalled();
//     });
//   });

//   afterAll(() => {
//     TestBed.resetTestingModule();
//   });

// });

// class MockRouter {
//   navigateByUrl(url: any) {
//     return null;
//   }
// }

// class MockDateUtility {
//   dateFormatterCustom(date?: Date) {
//     return '';
//   }
// }

// class MockTimeFormat {
//   transform(date?: Date) {
//     return '';
//   }
// }

// class MockDataService {
//   getPassingOneBankId() {
//     return 'marissa';
//   }

//   getReportingPeriod() {
//     return '201908';
//   }
// }

// class MockRestService {
//   get() {
//     return of({
//       employee: {
//         staffType: 'DBS',
//         platform: 'MOT',
//       },
//       employeeContracts: [
//         {
//           vendor: '',
//           contractstartdate: '',
//           contractenddate: '',
//           mcrnumber: '',
//           contractid: '',
//           ponumber: '',
//           status: ''
//         }
//       ],
//       teamFormations: [
//         {
//           tribe: '',
//           team: '',
//           pcft: false,
//           allocation: '',
//           teamlead: '',
//           role: ''
//         }
//       ],
//       employeeChapters: [
//         {
//           vendor: '',
//           contractstartdate: '',
//           contractenddate: '',
//           mcrnumber: '',
//           contractid: '',
//           ponumber: '',
//           status: ''
//         }
//       ],
//       employeeAssets: [
//         {
//           type: '',
//           id: '',
//           details: ''
//         }
//       ]
//     });
//   }
// }
