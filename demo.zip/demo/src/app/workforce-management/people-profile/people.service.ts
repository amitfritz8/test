import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import { PeopleProfileModel } from './people.model'; 

@Injectable()
export class PeopleService{

    constructor(private httpClient: HttpClient){}


    getPeopleProfile(lobts, platforms, locations, reportingPeriod): Observable<Array<PeopleProfileModel>>{
        return this.httpClient.post<Array<PeopleProfileModel>>(`/people/data/employee/all`, { techUnits: lobts, platforms: platforms, location: locations, rptPeriod: reportingPeriod });
    }
}