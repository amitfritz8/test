import { NgModule } from "@angular/core";
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../common/module/shared.module';

const routes: Routes = [
    {
        path: "people-dashboard",
        loadChildren: () => import('src/app/workforce-management/people-dashboard/people-dashboard.module').then(m => m.PeopleModule)
    },
    {
        path: "people-profile",
        loadChildren: () => import('src/app/workforce-management/people-profile/people-profile.module').then(m => m.PeopleModule)
    },
    {
        path: "team-management",
        loadChildren: () => import('src/app/workforce-management/team-management/team-management.module').then(m => m.TeamManagementModule)
    },
    {
        path: '',
        redirectTo: 'people-dashboard',
        pathMatch: 'full'
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        SharedModule
    ],
    declarations: [

    ],
    exports: [
    ],
    entryComponents: []
})

export class WorkforceRoutingModule { }
