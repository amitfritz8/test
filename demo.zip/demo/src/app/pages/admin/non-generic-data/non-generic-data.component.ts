import {Component, OnInit, AfterViewInit, ViewChild, EventEmitter, Output} from '@angular/core';
import {MatDialog, MatTableDataSource} from '@angular/material';
import {MatSort} from '@angular/material/sort';
import {RestService} from '../../../shared/http/rest-service';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import {ConfirmDialogComponent} from 'src/app/components/dialogues/confirm-dialog/confirm-dialog-component';
import {DataService} from 'src/app/shared/services/data.service';
import {Subscription} from 'rxjs';
import {ImportDialogComponent} from '../../../components/dialogues/import-dialog/import-dialog-component';
import * as moment from 'moment';

@Component({
  selector: 'app-non-generic-data',
  templateUrl: './non-generic-data.component.html',
  styleUrls: ['./non-generic-data.component.scss'],

})
export class NonGenericDataComponent implements OnInit, AfterViewInit {

  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  detailsview: boolean = false;
  action: string = '';
  element: any;
  errorData: any;
  refDataList: any = [];
  stakeList: any = [];
  nonRefData: any = [];
  isRefDataSelected: boolean = false;
  refdataOption: string = '';
  selected = 'platformSetup';
  selectedPlatform = null;
  form: FormGroup;
  staff: FormControl;
  dataSummary: any;
  add: string = '';
  data: any = [];
  stakedata: any = [];
  selectedValue = null;
  stakeHolders: any = [];
  checked = true;
  unchecked = false;
  status: any;
  nonGenRefData: any = [];
  editcountry: any = [];
  editplatformRole: any = [];
  editBizTech: any = [];
  editStakeName: any = [];
  temp: any = [];
  newstake: any = [];
  staffName: string;
  StakeHoldersdisplayedColumns = ['bizTechInd', 'countryCode', 'platformRole', 'leadDelegateInd', 'empName', 'oneBankId', 'remove'];
  refEmailTempList: any = [];
  selectedTemplate = null;
  showAddBtnForTemplate: boolean = false;
  cancelCliked: boolean = false;
  saveCliked: boolean = false;
  isErrorExists: boolean = false;
  subscription: Subscription;
  @Output() back: EventEmitter<boolean> = new EventEmitter();
  editCliked: boolean = false;
  errorInAdd: boolean = false;
  nonGen = 'nonGen';
  isSuccessMsg: boolean = false;
  reportingPeriod: string;
  reportingPeriodDate: string


  constructor(private fb: FormBuilder, private restService: RestService,
              public dialog: MatDialog, private dataService: DataService) {
    this.dataSource = new MatTableDataSource();
    this.subscription = this.dataService.getMessage().subscribe(message => {
      this.goback();
    });
  }

  ngOnInit() {
    this.action = 'view';
    this.getData();
    this.add = 'false';
    this.cancelCliked = false;
    this.saveCliked = false;
    console.log(sessionStorage.getItem('reportingPeriodDate'));
    if (sessionStorage.getItem('rptPeriod')) {
      this.reportingPeriodDate = sessionStorage.getItem('rptPeriod');
    }
    //this.reportingPeriod = JSON.parse(sessionStorage.getItem('reportingPeriodDate'));
    console.log(this.reportingPeriod);
    this.form = this.fb.group({
      platformName: ['', [Validators.required, Validators.maxLength(35)]],
      empName: [''],
      oneBankId: ['']
    });
    this.handleReportingPeriod();
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }

  goback() {
    this.back.emit(true);
  }

  addAttr() {
    let deemo = {
      'bizTechInd': this.editBizTech[0].value,
      'countryCode': this.editcountry[0].value,
      'platformRole': this.editplatformRole[0].value,
      'leadDelegateInd': 'Lead',
      'empName': '',
      'createdBy': null,
      'dateCreated': null,
      'dateModified': null,
      'modifiedBy': null,
      'platformIndex': this.selectedValue.platformIndex,
      'oneBankId': '',
      'uniqueKey': Math.random()
    }
    this.add = 'true';
    this.stakeHolders.push(deemo);
    this.dataSource = new MatTableDataSource();

    this.dataSource.data = this.stakeHolders;
    this.updateForm();
  }

  getData() {
    this.nonRefData.push({
      'key': 'platformSetup',
      'Value': 'Platform Set-up'
    });
    this.nonGenRefData = [];
    this.restService.get(`/people/data/nonGeneric/all/${this.nonGen}`).subscribe(nonGen => {
        this.temp = [];
        this.temp = nonGen;
        this.temp.forEach(element => {
          this.nonGenRefData.push({'value': element.dataTable, 'display': element.dataTableDescription});
        });
        this.nonGenRefData.push({'value': 'Team PlannedCapacity', 'display':'Planned Capacity'});
      }
    );
    this.refDataList = [];
    this.restService.get(`/people/data/platforms/all`).subscribe(data => {
      this.data = data;
      data.forEach(element => {
        this.refDataList.push({'key': element.platformId, 'value': element.platformIndex + ' - ' + element.platform});
      });

    });
    this.refEmailTempList = [];
    this.restService.get(`/people/email/templates`).subscribe(data => {
      this.data = data;
      data.forEach(element => {
        this.refEmailTempList.push({'key': element.emailSurrId, 'value': element.emailTemplateName});
      });

    });
  }

  // applyFilter(filterValue: string) {
  //   this.dataSource.filter = filterValue.trim().toLowerCase();
  // }


  onPlatformSelection(e) {
    this.action = 'view';
    this.isErrorExists = false;
    this.cancelCliked = false;
    this.stakeHolders = [];
    this.stakedata = [];
    this.restService.get(`/people/data/platforms/values/${e.value}`).subscribe(res => {
      this.stakedata = res;
      this.selectedValue = res.platform;
      this.stakeHolders = this.stakedata.stakeHolders;
      this.dataSource = new MatTableDataSource();
      this.dataSource.data = this.stakeHolders;

      this.dataSource.sortingDataAccessor = (data, header) => {

        if (data[header] && typeof (data[header]) != 'number') {
          return data[header].toString().toLowerCase();
        } else {
          return data[header];
        }
      }


      this.dataSource.filter = '';

    });
    this.restService.get(`/people/data/dataSummary/dataValues/country`).subscribe(country => {
      this.editcountry = [];

      this.temp = country;
      this.temp.forEach(element => {
        this.editcountry.push({'value': element.value, 'display': element.value});
      });
    });
    this.restService.get(`/people/data/dataSummary/dataValues/stakeHolder`).subscribe(biz => {
      this.editBizTech = [];
      this.temp = biz;
      this.temp.forEach(element => {
        this.editBizTech.push({'value': element.value, 'display': element.value});
      });
    });
    this.restService.get(`/people/data/dataSummary/dataValues/Platform Role`).subscribe(ptform => {
      this.temp = [];
      this.editplatformRole = [];
      this.temp = ptform;
      this.temp.forEach(element => {
        this.editplatformRole.push({'value': element.value, 'display': element.value});
      });
    });
    this.restService.get(`/people/data/employee/byPlatform?id=${e.value}`).subscribe(stname => {
      this.temp = [];

      this.temp = stname;
      this.editStakeName = [];

      this.temp.forEach(element => {
        this.editStakeName.push({'value': element.empName, 'display': element.oneBankId});
      });
    });
  }

  requestRaise() {
    this.stakeHolders = [];
    this.stakedata = [];
    this.restService.get(`/people/data/platforms/values/${this.selectedValue.platformId}`).subscribe(res => {
      this.stakedata = res;
      this.stakeHolders = this.stakedata.stakeHolders;

      this.dataSource = new MatTableDataSource();
      this.dataSource.data = this.stakedata.stakeHolders;
    });
    this.restService.get(`/people/data/employee/byPlatform?id=${this.selectedValue.platformId}`).subscribe(stname => {
      this.temp = [];

      this.temp = stname;
      this.editStakeName = [];

      this.temp.forEach(element => {
        this.editStakeName.push({'value': element.empName, 'display': element.oneBankId});
      });
    });
    this.updateForm();
  }

  updateForm() {

    this.form.controls['platformName'].setValue(this.selectedValue.platformName);
  }

  onRefDataSelection(e) {
    this.isRefDataSelected = true;
    this.refdataOption = e.value;
    this.action = 'view';
    this.selectedValue = null;
    this.selectedTemplate = null;
    this.selectedPlatform = '';
    this.showAddBtnForTemplate = true;
    this.isErrorExists = false;
  }

  onEditClick() {
    this.action = 'edit';
    this.saveCliked = false;
    this.cancelCliked = false;
    this.isErrorExists = false;
    if (this.refdataOption == 'xref_platform_master') {
      this.requestRaise();
    } else if (this.refdataOption == 'xref_email_template') {
      this.editCliked = true;
    }
  }

  handleFilter(value) {
    this.newstake = this.editStakeName.filter((s) => s.toLowerCase().indexOf(value.toLowerCase()) !== -1);
  }


  deleteAttr(index, ele) {

    if (ele.psId && ele.psId > 0) {
      let i = this.dataSource.data.findIndex(temp => temp.psId === ele.psId);
      this.dataSource.data.splice(i, 1);
      this.stakeList = this.dataSource.data;
      this.stakeHolders = this.dataSource.data;
    } else {
      let i = this.dataSource.data.findIndex(temp => temp.uniqueKey === ele.uniqueKey);
      this.dataSource.data.splice(i, 1);
      this.stakeList = this.dataSource.data;
      this.stakeHolders = this.dataSource.data;
    }
    this.dataSource = new MatTableDataSource();
    this.dataSource.data = this.stakeList;
  }

  onCancelClick() {
    if (this.refdataOption == 'xref_platform_master') {
      this.updateForm();
      this.requestRaise();
      this.add = 'false';
      this.action = 'view';
    } else if (this.refdataOption == 'xref_email_template') {
      this.cancelCliked = true;
    }
  }

  get f() {
    return this.form.controls;
  }

  OnchangeLead(e, event) {

    if (event.checked == false) {
      if (e.psId && e.psId > 0) {
        let i = this.dataSource.data.findIndex(temp => temp.psId === e.psId);
        this.dataSource.data[i].leadDelegateInd = 'Lead';
        this.stakeList = this.dataSource.data
      } else {
        let i = this.dataSource.data.findIndex(temp => temp.uniqueKey === e.uniqueKey);
        this.dataSource.data[i].leadDelegateInd = 'Lead';
        this.stakeList = this.dataSource.data
      }
    }
    else {
      if (e.psId && e.psId > 0) {
        let i = this.dataSource.data.findIndex(temp => temp.psId === e.psId);
        this.dataSource.data[i].leadDelegateInd = 'Delegate';
        this.stakeList = this.dataSource.data
      } else {
        let i = this.dataSource.data.findIndex(temp => temp.uniqueKey === e.uniqueKey);
        this.dataSource.data[i].leadDelegateInd = 'Delegate';
        this.stakeList = this.dataSource.data
      }
    }

  }

  onchange(e, ele) {


    for (let one of this.editStakeName) {


      if (one.value == e.value) {
        if (ele.psId && ele.psId > 0) {
          let i = this.dataSource.data.findIndex(temp => temp.psId === ele.psId);
          this.dataSource.data[i].oneBankId = one.display;
          this.stakeHolders = this.dataSource.data;
        }
        else {
          let i = this.dataSource.data.findIndex(temp => temp.uniqueKey === ele.uniqueKey);
          this.dataSource.data[i].oneBankId = one.display;
          this.stakeHolders = this.dataSource.data;
        }
      }

    }

  }

  save() {
    if (this.refdataOption == 'xref_platform_master') {
      const controls = this.form.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          this.form.controls[name].markAsTouched();
        }
      }
      if (this.form.invalid) {
        this.form.markAllAsTouched();
      } else if (this.form.valid) {
        for (var i in this.selectedValue) {
          if (this.form.controls.hasOwnProperty(i)) {
            this.selectedValue[i] = this.form.controls[i].value;
          }
        }
        this.stakeHolders.forEach(temp => {
          if (temp.uniqueKey) {
            delete temp.uniqueKey;
          }
        });

        this.selectedValue.platformName = this.form.controls.platformName.value;

        this.updateForm();


        this.stakedata.platform = this.selectedValue;
        this.stakedata.stakeHolders = this.stakeHolders;
        this.restService.put(`/people/data/platforms/values/${this.selectedValue.platformId}`, this.stakedata).subscribe(result => {
          this.getData();
          this.requestRaise();
        });
        this.add = 'false';

        this.updateForm();
        this.action = 'view';
      }
    } else if (this.refdataOption == 'xref_email_template') {
      this.saveCliked = true;
    }
    this.updatePlatformLeads();
  }

  updatePlatformLeads(){
    this.restService.post(`/people/data/platforms/platformLeadNames`, null).subscribe(result => {
    });
  }
  sortData(event): void {
    this.dataSource.sortingDataAccessor = (data, header) => {
      if (this.StakeHoldersdisplayedColumns.includes(header)) {
        if (typeof (data[header]) != 'number' && data[header]) {
          return data[header].toString().toLowerCase();
        } else {
          return data[header];
        }
      }
    }
    this.dataSource.sort = this.sort;
  }

  onEmailTemplateSelection() {
    this.action = 'view';
    this.showAddBtnForTemplate = false;
    this.cancelCliked = false;
    this.isErrorExists = false;
    this.errorInAdd = false;
  }

  onAddNewTemplate() {
    this.action = 'add';
    this.selectedTemplate = 'dummy';
    this.cancelCliked = false;
    this.editCliked = false;
    this.saveCliked = false;
    this.errorInAdd = false;
  }

  getFormCheck(e) {
    if (e) {
      this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_WARN_EDITMODE_INTERRUPTION`).subscribe(result => {
        const dialogRef = this.dialog.open(ConfirmDialogComponent, {
          data: {
            header: 'Discard Changes?',
            body: result,
            note: 'Do you want to proceed?',
            button1: 'No',
            button2: 'Yes'
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result === 'yes') {
            if (this.action !== 'add') {
              this.action = 'view';
              this.cancelCliked = false;
            } else {
              this.action = 'view';
              this.cancelCliked = false;
              this.selectedTemplate = null;
              this.showAddBtnForTemplate = true;
              this.isErrorExists = false;
            }
          } else {
            this.cancelCliked = false;
          }
        });
      });
    } else {
      setTimeout(() => {
        if (this.action !== 'add') {
          this.action = 'view';
          this.cancelCliked = false;
        } else {
          this.action = 'view';
          this.cancelCliked = false;
          this.selectedTemplate = null;
          this.showAddBtnForTemplate = true;
        }
      }, 200);
    }

  }

  saveActionDone(e) {
    if (e == 'invalid form') {
      setTimeout(() => {
        this.saveCliked = false;
      });
    } else if (e['errorFlag'] !== null) {
      this.isErrorExists = true;
      this.dataService.getCustomMessage(e['message']);
      this.dataService.getFlag(e['errorFlag']);
      if (e['errorFlag'] == 1 && this.action == 'add') {
        this.errorInAdd = true;
        this.cancelCliked = false;
        this.editCliked = false;
        this.saveCliked = false;
        this.showAddBtnForTemplate = false;
      } else {
        setTimeout(() => {
          this.saveCliked = false;
          this.refEmailTempList = [];
          this.restService.get(`/people/email/templates`).subscribe(data => {
            this.data = data;
            data.forEach(element => {
              this.refEmailTempList.push({'key': element.emailSurrId, 'value': element.emailTemplateName});
            });
          });
          if (this.action !== 'add') {
            this.action = 'view';
            this.cancelCliked = false;
            this.editCliked = false;
          } else {
            this.action = 'view';
            this.cancelCliked = false;
            this.editCliked = false;
            this.selectedTemplate = null;
            this.showAddBtnForTemplate = true;
          }
        });
      }
    }
  }

  onImportClick() {
    this.isErrorExists = false;
    this.isSuccessMsg = false;
    const dialogRef = this.dialog.open(ImportDialogComponent, {
      data: {
        refType:'PCCODE',
        header: 'Import Pccode Data'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.errorData = result;
      if (result['errorFlag'] === '0') {
        this.isSuccessMsg = true;
        this.dataService.getCustomMessage(result['message']);
        this.dataService.getFlag(result['errorFlag']);
      }
    });
  }
  onGL_Account_Tree_ImportClick() {
    this.isErrorExists = false;
    this.isSuccessMsg = false;
    const dialogRef = this.dialog.open(ImportDialogComponent, {
      data: {
        refType:'GLAccountTree',
        header: 'Import GL Account Tree Data'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.errorData = result;
      if (result['errorFlag'] === '0') {
        this.isSuccessMsg = true;
        this.dataService.getCustomMessage(result['message']);
        this.dataService.getFlag(result['errorFlag']);
      }
    });
  }
  onAppCodeMaster_ImportClick() {//xref_app_code_master
    this.isErrorExists = false;
    this.isSuccessMsg = false;
    const dialogRef = this.dialog.open(ImportDialogComponent, {
      data: {
        refType:'xref_app_code_master',
        header: 'App Code Master'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.errorData = result;
      if (result['errorFlag'] === '0') {
        this.isSuccessMsg = true;
        this.dataService.getCustomMessage(result['message']);
        this.dataService.getFlag(result['errorFlag']);
      }
    });
  }
  onItcCode_ImportClick() {//itc_rate
    this.isErrorExists = false;
    this.isSuccessMsg = false;
    const dialogRef = this.dialog.open(ImportDialogComponent, {
      data: {
        refType:'itc_rate',
        header: 'ITC Rate'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.errorData = result;
      if (result['errorFlag'] === '0') {
        this.isSuccessMsg = true;
        this.dataService.getCustomMessage(result['message']);
        this.dataService.getFlag(result['errorFlag']);
      }
    });
  }
  onExchangesRate_ImportClick() {//exchange_rates
    this.isErrorExists = false;
    this.isSuccessMsg = false;
    const dialogRef = this.dialog.open(ImportDialogComponent, {
      data: {
        refType:'exchange_rates',
        header: 'Exchange Rate'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.errorData = result;
      if (result['errorFlag'] === '0') {
        this.isSuccessMsg = true;
        this.dataService.getCustomMessage(result['message']);
        this.dataService.getFlag(result['errorFlag']);
      }
    });
  }
  mapGlSetIdToHypleId_ImportClick() {//exchange_rates
    this.isErrorExists = false;
    this.isSuccessMsg = false;
    const dialogRef = this.dialog.open(ImportDialogComponent, {
      data: {
        refType:'map_glsetid_to_hypleid',
        header: 'Upload PSGL to Hyperion Mapper'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.errorData = result;
      if (result['errorFlag'] === '0') {
        this.isSuccessMsg = true;
        this.dataService.getCustomMessage(result['message']);
        this.dataService.getFlag(result['errorFlag']);
      }
    });
  }
  
  months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  
  onPlannedCapcityButtonClick() {
    //plannedTeamCapacityTriger
   
    let selectedDate: string = this.selectedDate;
    //sessionStorage.getItem('reportingPeriodDate');
    
    if (selectedDate) {
      ///Need to uncomment if selectedDate value is changed
       let month: string = '0' + (this.months.indexOf(selectedDate.substring(5, selectedDate.length)) + 1);
       let year: string = selectedDate.substring(0, 4);
       this.reportingPeriod = year + '' + month.slice(-2);
      // let month: string = '0' + (this.months.indexOf(selectedDate.substring(6, selectedDate.length - 1)) + 1);
      // let year: string = selectedDate.substring(1, 5);
      // this.reportingPeriod = year + '' + month.slice(-2);
      
      if(this.reportingPeriod){
        this.dataService.loaderHandler(true);
        this.restService.post(`/people/team/teammanagement/planTeamCapacity?rptPeriod=${this.reportingPeriodDate}`, null)
      .subscribe(result => {
        this.dataService.loaderHandler(false);
      });
      }
    }
  }
  selectedDate: string;
  dates: any;
  onReportingPeriodChnage() {
    sessionStorage.setItem('reportingPeriodDate', JSON.stringify(this.selectedDate));
    if (this.selectedDate) {
      const month: string = '0' + (this.months.indexOf(this.selectedDate.substring(5, this.selectedDate.length)) + 1);
      const year: string = this.selectedDate.substring(0, 4);
      this.reportingPeriod = year + '' + month.slice(-2);
      console.log('onReportingPeriodChnage dahsboard');
      this.dataService.setRptPeriodObs(this.reportingPeriod);
      // this.checkForBD();
      // this.getData();
    }
  }
  handleReportingPeriod() {
    const platform = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    const reportingPeriodDate = JSON.parse(sessionStorage.getItem('reportingPeriodDate'));
    if (reportingPeriodDate) {
      this.selectedDate = reportingPeriodDate;
    }
    if (lobts && platform && locations) {
      this.restService.post(`people/data/employee/getreportmonthyear`, {
        techUnits: lobts,
        platforms: platform,
        location: locations
      }).subscribe(data => {
        if (data) {
          this.dates = [];
          data.forEach(ele => {
            const reportingYear = ele.substring(0, 4);
            let reportingMonth = ele.substring(4, 6);
            // Taking reporting month without 0.
            if (reportingMonth && reportingMonth.charAt(0) === 0) {
              reportingMonth = reportingMonth.charAt(1);
            }
            this.dates.push(`${reportingYear} ${this.months[reportingMonth - 1]}`);
          });
        }
        const currentMonth = Number(moment(new Date()).format('MM'));
        const currentYear = moment(new Date()).format('YYYY');
        const currentDay = Number(moment(new Date()).format('DD'));
        if (!reportingPeriodDate) {
          if (currentDay >= 15) {
            this.selectedDate = currentYear + ' ' + this.months[currentMonth - 2];
          } else {
            this.selectedDate = currentYear + ' ' + this.months[currentMonth - 3];
          }
          const selectedDatePresent = this.dates.includes(this.selectedDate);
          if (!selectedDatePresent) {
            this.selectedDate = this.dates[0];
          }
          sessionStorage.setItem('reportingPeriodDate', JSON.stringify(this.selectedDate));
        }
        const month: string = '0' + (this.months.indexOf(this.selectedDate.substring(5, this.selectedDate.length)) + 1);
        const year: string = this.selectedDate.substring(0, 4);
        this.reportingPeriod = year + '' + month.slice(-2);
      });
     
    }
    // Adding this for UAT only.
    // this.selectedDate = '2019 August';
  }
}
