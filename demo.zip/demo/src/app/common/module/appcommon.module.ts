import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../../material.module';
import { SharedModule } from './shared.module';

// components
import { CommonComponent } from '../component/appcommon.component';
import { HeaderComponent } from '../component/header.component';
import { SecondaryNavbarComponent } from '../component/secondary-navbar.component';
import { SideNavCompnent } from '../component/sidenav.component';
import { TabComponent } from '../component/tab.component';

// pipe
import {TimeFormat} from '../pipes/timeFormater.pipe';

// Router Module
import { CommonRouterModule } from '../routing/common-routing.module';

// service
import { RestService } from '../service/rest.service';
import { DataService } from '../service/data.service';
import { DataTableService } from '../service/dataTable.service';



const directives = [
  CommonComponent,
  HeaderComponent,
  SideNavCompnent,
  TabComponent,
  SecondaryNavbarComponent,
  TimeFormat
];

@NgModule({
  declarations: directives,
  imports: [CommonRouterModule, CommonModule, SharedModule, MaterialModule],
  providers: [RestService, DataService, DataTableService, TimeFormat]
})
export class AppCommonModule {}
