import { NgModule } from '@angular/core';
import { MaterialModule } from '../../material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';

import { CommonDialogComponent } from 'src/app/common/component/dialogues/common-dialog/common-dialog-component';
import { ConfirmDialogComponent } from 'src/app/common/component/dialogues/confirm-dialog/confirm-dialog-component';
import { ImportDialogComponent } from 'src/app/common/component/dialogues/import-dialog/import-dialog-component';
import { ErrorsNotificationComponent } from 'src/app/common/component/errors-notification/errors-notification.component';
import { DragDropDirective } from 'src/app/common/directive/drag-drop.directive';
import { GenePaginatorDirective } from 'src/app/common/directive/gene-paginator.directive';
import { GeneSnackBarComponent } from 'src/app/common/component/gene-snackbar/gene-snackbar.component';
import { UpdateProfileComponent } from 'src/app/common/component/dialogues/update-profile/update-profile-component';
import { PortfolioDialogComponent } from 'src/app/common/component/dialogues/portfolio-dialog/portfolio-dialog.component';
import { PortfolioConfirmComponent } from 'src/app/common/component/dialogues/portfolio-confirm/portfolio-confirm.component';
import { OthersDialogComponent } from 'src/app/common/component/dialogues/others-dialog/others-dialog-component';
import { TeamReportingDialogComponent } from 'src/app/common/component/dialogues/team-reporting-dialog/team-reporting-dialog.component';
import { DeleteTeamDialogComponent } from '../component/dialogues/delete-team-dialog/delete-team-dialog.component';
import { TooltipComponent } from 'src/app/common/component/tooltip/tooltip.component';
import { TooltipDirective } from 'src/app/common/component/tooltip/tooltip.directive';

import { FinancialSummaryComponent } from 'src/app/portfolio/sub-workstream/financial-summary/financial-summary.component';
import { Ng5SliderModule } from 'ng5-slider';
import { IcRangeComponent } from 'src/app/common/component/dialogues/ic-range/ic-range.component';
import { PcftRangeComponent } from 'src/app/common/component/dialogues/pcft-range/pcft-range.component';
import { NonPcftRangeComponent } from 'src/app/common/component/dialogues/non-pcft-range/non-pcft-range.component';
import { AugPcftRangeComponent } from 'src/app/common/component/dialogues/aug-pcft-range/aug-pcft-range.component';
import { AugNonPcftRangeComponent } from 'src/app/common/component/dialogues/aug-non-pcft-range/aug-non-pcft-range.component';
import { ApproverDialogComponent } from 'src/app/common/component/dialogues/approver-dialog/approver-dialog.component';
import { CopyScenarioDialogComponent } from "src/app/common/component/dialogues/copy-scenario-dialog/copy-scenario-dialog.component";

import { from } from 'rxjs';
import {DeactivateTeamDialogComponent} from '../component/dialogues/deactivate-team-dialog/deactivate-team-dialog.component';

@NgModule({
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    CommonModule,
    RouterModule.forChild([]),
    NgxMatSelectSearchModule,
    Ng5SliderModule
  ],
  declarations: [
    CommonDialogComponent,
    ConfirmDialogComponent,
    ImportDialogComponent,
    OthersDialogComponent,
    UpdateProfileComponent,
    PortfolioDialogComponent,
    ErrorsNotificationComponent,
    DragDropDirective,
    GenePaginatorDirective,
    GeneSnackBarComponent,
    PortfolioConfirmComponent,
    TeamReportingDialogComponent,
    IcRangeComponent,
    PcftRangeComponent,
    NonPcftRangeComponent,
    AugPcftRangeComponent,
    AugNonPcftRangeComponent,
    ApproverDialogComponent,
    FinancialSummaryComponent,
    CopyScenarioDialogComponent,
    DeleteTeamDialogComponent,
    DeactivateTeamDialogComponent,
    TooltipComponent, 
    TooltipDirective
  ],
  exports: [
    MaterialModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgxMatSelectSearchModule,
    CommonDialogComponent,
    ConfirmDialogComponent,
    ImportDialogComponent,
    OthersDialogComponent,
    UpdateProfileComponent,
    PortfolioDialogComponent,
    ErrorsNotificationComponent,
    DragDropDirective,
    GenePaginatorDirective,
    GeneSnackBarComponent,
    PortfolioConfirmComponent,
    TeamReportingDialogComponent,
    IcRangeComponent,
    PcftRangeComponent,
    NonPcftRangeComponent,
    AugPcftRangeComponent,
    AugNonPcftRangeComponent,
    ApproverDialogComponent,
    FinancialSummaryComponent,
    CopyScenarioDialogComponent,
    DeleteTeamDialogComponent,
    DeactivateTeamDialogComponent,
    TooltipComponent,
    TooltipDirective
  ],
  entryComponents: [
    CommonDialogComponent,
    ConfirmDialogComponent,
    ImportDialogComponent,
    UpdateProfileComponent,
    ErrorsNotificationComponent,
    PortfolioDialogComponent,
    PortfolioConfirmComponent,
    OthersDialogComponent,
    TeamReportingDialogComponent,
    IcRangeComponent,
    PcftRangeComponent,
    NonPcftRangeComponent,
    AugPcftRangeComponent,
    AugNonPcftRangeComponent,
    ApproverDialogComponent,
    CopyScenarioDialogComponent,
    DeleteTeamDialogComponent,
    DeactivateTeamDialogComponent,
    TooltipComponent
  ]
})
export class SharedModule {
}
