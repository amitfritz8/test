import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable()
export class PreLoggedinGuard implements CanActivate {
  constructor(private router: Router) { /**/
  }

  public canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean
    | Observable<boolean>
    | Promise<boolean> {
    if (localStorage.getItem("access_token") == null) {
      return true;
    } else {
      this.router.navigate(['/home']);
      return false;
    }
  }
}
