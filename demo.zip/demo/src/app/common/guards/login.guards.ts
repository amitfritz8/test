import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable()
export class LoggedinGuard implements CanActivate {
  constructor(private router: Router) { /**/
  }

  public canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean
    | Observable<boolean>
    | Promise<boolean> {
    if (localStorage.getItem("access_token")) {
      let userInfo = JSON.parse(localStorage.getItem('userinfo'));
      sessionStorage.setItem('currentUserRole', JSON.stringify(userInfo.securityGroup));
      sessionStorage.setItem('currentUserId', JSON.stringify(userInfo.userName));
      sessionStorage.setItem('lobts', JSON.stringify(userInfo['mapping'].techUnits));
      sessionStorage.setItem('loggedInUserTechUnit', JSON.stringify(userInfo.techUnit));
      sessionStorage.setItem('techUnitsAndPlatforms', JSON.stringify(userInfo['mapping'].techUnitsAndPlatforms));
      sessionStorage.setItem('modulesMapping', JSON.stringify(userInfo['mapping'].modules));
      sessionStorage.setItem('roles', JSON.stringify(userInfo['mapping'].roles));
      return true;
    } else {
      this.router.navigate(['/'],
        {
          queryParams: { 'returnUrl': state.url }, skipLocationChange: true
        });
      return false;
    }
  }
}

export function FOR_ROOT(router: Router) {
  return new LoggedinGuard(router);
}

export const LOGIN_GUARD_PROVIDER = {
  provide: LoggedinGuard,
  useFactory: FOR_ROOT,
  deps: [Router]
};
