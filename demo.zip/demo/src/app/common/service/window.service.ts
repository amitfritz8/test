import { Injectable } from '@angular/core';

@Injectable()
export class CstWindow {
  get nativeWindow(): any {
    return window;
  }
  get nativeLocation(): any {
    return window.location;
  }
}
