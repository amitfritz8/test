import { Injectable } from "@angular/core";
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import {MatomoTracker} from "ngx-matomo";

@Injectable()
export class RestService {

    options: any = {};

    constructor(private http: HttpClient, private matomoTracker: MatomoTracker) {

    }

    get(url: string, options: any = {}): Observable<any> {
        return this.http.get(url, options);
    }

    put(url: string, body: any): Observable<any> {
        return this.http.put(url, body, this.options);
    }

    post(url: string, body: any): Observable<any> {
        return this.http.post(url, body, this.options);
    }

    delete(url: string): Observable<any> {
        return this.http.delete(url, this.options);
    }

    track(pageName: string): void {
        let userName = JSON.parse(localStorage.getItem('userinfo')).displayName;
        this.matomoTracker.setDocumentTitle(pageName);
        this.matomoTracker.setUserId(`${localStorage.getItem('userOneBankId')}`);
        this.matomoTracker.trackPageView();
        this.http.put(`/gateway/track/req?pageName=${pageName}&userId=${localStorage.getItem('userOneBankId')}&userName=${userName}`, null).subscribe();
    }

}
