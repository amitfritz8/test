import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Observable, Subject} from 'rxjs';

@Injectable()
export class DataService {

  private passingOneBankId: string;
  private reportingPeriod: string;
  private action: string;
  private activeTab: any;
  private listingView: any;
  private subject = new Subject<any>();
  private passingTeamName: string;
  private currentMonthStatus: boolean;
  private surrId: number;
  private navItemChange = new Subject<string>();
  private dataSource = new BehaviorSubject(false);
  data = this.dataSource.asObservable();
  itemChange = this.navItemChange.asObservable();
  private startDate: any;
  private goLiveDate: any;
  private endDate: any;
  private scenario: any;
  private swEngStartDate: any;
  private status: any;

  private msgFlag = new BehaviorSubject('default message');
  messageFlag = this.msgFlag.asObservable();

  private message = new BehaviorSubject('default message');
  error = this.message.asObservable();

  private rptPeriodObs = new BehaviorSubject('default message');
  rptPeriod = this.rptPeriodObs.asObservable();

  constructor() {
  }

  loaderHandler(data: any) {
    this.dataSource.next(data);
  }

  getPassingOneBankId(): string {
    return this.passingOneBankId;
  }

  getcurrentMonthStatus(): boolean {
    return this.currentMonthStatus;
  }

  getPassingTeamName(): string {
    return this.passingTeamName;
  }

  setSurrId(value: number) {
    this.surrId = value;
  }

  getSurrId(): number {
    return this.surrId;
  }

  setcurrentMonthStatus(value: boolean) {
    this.currentMonthStatus = value;
  }

  setPassingOneBankId(value: string) {
    this.passingOneBankId = value;
  }

  setPassingTeamName(value: string) {
    this.passingTeamName = value;
  }

  getReportingPeriod(): string {
    return this.reportingPeriod;
  }

  setReportingPeriod(value: string) {
    this.reportingPeriod = value;
  }

  sendMessage(message: any) {
    this.subject.next({text: message});
  }

  sendMessageItemChange(message: string) {
    this.navItemChange.next(message);
  }

  clearMessages() {
    this.subject.next();
  }

  getMessage(): Observable<any> {
    return this.subject.asObservable();
  }

  getCustomMessage(message: string) {
    this.msgFlag.next(message);
  }

  getFlag(message: string) {
    this.message.next(message);
  }

  getAction(): string {
    return this.action;
  }

  setAction(value: string) {
    this.action = value;
  }

  getActiveTab(): string {
    return this.activeTab;
  }

  setActiveTab(value: string) {
    this.activeTab = value;
  }

  getListingView(): string {
    return this.listingView;
  }

  setListingView(value: string) {
    this.listingView = value;
  }

  getStartDate(): any {
    return this.startDate;
  }

  setScenario(value: any) {
    this.scenario = value;
  }
  getScenario(): any {
    return this.scenario;
  }

  setStartDate(value: any) {
    this.startDate = value;
  }

  getSwEngStartDate(): any {
    return this.swEngStartDate;
  }

  setSwEngStartDate(value: any) {
    this.swEngStartDate = value;
  }
  getGoLiveDate(): any {
    return this.goLiveDate;
  }

  setGoLiveDate(value: any) {
    this.goLiveDate = value;
  }

  setEndDate(value: any) {
    this.endDate = value;
  }

  getEndDate() {
    return this.endDate;
  }

  setRptPeriodObs(message: string) {
    this.rptPeriodObs.next(message);
  }

  getRptPeriodObs(): Observable<string> {
    return this.rptPeriodObs.asObservable();
  }

  getTeamStatus(): string {
    return this.status;
  }

  setTeamStatus(value: string) {
    this.status = value;
  }
}
