import { Injectable, Output, EventEmitter } from "@angular/core";
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { AppConfigService } from "./app-config.service";
import { CstWindow } from "./window.service";
import { MatSnackBar } from "@angular/material/snack-bar";
import { GeneSnackBarComponent } from "src/app/common/component/gene-snackbar/gene-snackbar.component";
import { MatomoTracker } from 'ngx-matomo';

@Injectable()
export class CommonService {

  @Output() secNavEvent = new EventEmitter<object>();
  @Output() selectedTab = new EventEmitter<string>();
  @Output() updateTab = new EventEmitter<string>();
  @Output() loaderEvent = new EventEmitter<boolean>();
  @Output() expandEvent = new EventEmitter<string>();
  @Output() pageResetEvent = new EventEmitter<boolean>();

  protected portalInfo: any;
  private logoutUrl;
  private authApi;
  private oauthApi;
  private broadCastSource = new BehaviorSubject<any>("");
  private captureSource = new BehaviorSubject<any>("");

  broadCastMessage = this.broadCastSource.asObservable();
  captureMessage = this.captureSource.asObservable();
  // tabMessage = this.tabSource.asObservable();
  // tabCaptureMessage = this.tabCaptureSource.asObservable();

  constructor(private cstWindow: CstWindow, private appConfigService: AppConfigService, private snackBar: MatSnackBar,
    private matomoTracker: MatomoTracker) { }

  broadcastMessage(message: any) {
    this.broadCastSource.next(message);
  }

  recieveMessage(message: any) {
    this.captureSource.next(message);
  }

  getProtalInfo() {
    return this.portalInfo;
  }

  setPortalInfo(data: any) {
    this.portalInfo = data;
  }

  public logout() {
    this.setLogoutUrl();
    this.cstWindow.nativeLocation.href = this.logoutUrl;
  }

  public showSnackBar(data){
    if(data.duration){
      this.snackBar.openFromComponent(GeneSnackBarComponent, { data: data, duration: data.duration });
    } else {
      this.snackBar.openFromComponent(GeneSnackBarComponent, { data: data });
    }
  }

  /**
  * setLogoutUrl: to return current url, so that user will navigate to current url after logout
  */
  private setLogoutUrl() {
    this.oauthApi = this.appConfigService.urls.api_oauth;
    const origin = this.cstWindow.nativeLocation.origin;
    this.logoutUrl = this.oauthApi ? `${this.oauthApi}logout?next=${encodeURIComponent(origin)}` : `/login`;
  }

  public setDocumentTitle(title: string){
    this.matomoTracker.setDocumentTitle(title);
  }

  public trackEvent(category, action, name, val ){
    this.matomoTracker.trackEvent(category,action,name,val);
  }

  public setUserId(userId: string){
    this.matomoTracker.setUserId(userId);
  }

  public trackPageView(){
    this.matomoTracker.trackPageView();
    this.matomoTracker.trackAllContentImpressions();
  }
}
