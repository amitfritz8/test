import { Component, Input, AfterContentInit, Output } from '@angular/core';
import { CommonService } from '../service/common.service';
import { EventEmitter } from 'protractor';

@Component({
  selector: 'app-tab',
  templateUrl: '../views/tab.component.html',
  styleUrls: ['../css/header.component.scss']
})
export class TabComponent implements AfterContentInit {

  _tabs: Array<string> = [];
  selectedIdx: string = '';
  curTab: string;
  err_tabs: Array<string> = [];

  constructor(private commonService: CommonService) {
    this.commonService.updateTab.subscribe(data => {
      this.selectedIdx = data;
    });
  }

  @Input()
  set tabs(info) {
    this._tabs = info.tabs;
    this.err_tabs = info.err_tabs == '' ? [] : info.err_tabs;
    this.curTab = this._tabs[this.selectedIdx];
    if (!info.prevent_idx_update) {
      this.selectedIdx = this._tabs[0];
    }
  }

  ngAfterContentInit() {
    // this.updateIdx(this.selectedIdx, this._tabs[0]);
  }

  updateIdx(tab) {
    this.selectedIdx = tab;
    this.curTab = tab;
    // this.commonService.updateTab(this.curTab);
    this.commonService.selectedTab.emit(this.curTab)
  }
}
