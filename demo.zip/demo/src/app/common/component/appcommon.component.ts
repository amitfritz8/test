import { Component, OnInit, OnDestroy } from '@angular/core';
import * as _ from 'lodash';
import { MatomoTracker } from 'ngx-matomo';
import { CommonService } from '../service/common.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-common',
    templateUrl: '../views/appcommon.component.html'
})
export class CommonComponent implements OnInit, OnDestroy {

    userInfo: any;
    hideNav: boolean = false;
    editMode: boolean = false;
    footerData: object = {};

    expandSubscription: Subscription;
    editModeSubscription: Subscription;

    constructor(private commonService: CommonService, private matomoTracker: MatomoTracker) {
        this.userInfo = JSON.parse(localStorage.getItem('userinfo'));
    }

    ngOnInit() {
        this.commonService.setPortalInfo(this.userInfo);
        this.matomoTracker.setUserId(localStorage.getItem('userOneBankId'));

        this.expandSubscription = this.commonService.expandEvent.subscribe(data => {
            if (data == 'costSetting') {
                this.hideNav = true;
            } else if (data == 'costSettingExt') {
                this.hideNav = false;
            } else if (data != '') {
                this.hideNav = !this.hideNav;
            }
        });
    }

    ngOnDestroy() {
        this.expandSubscription.unsubscribe();
    }
}
