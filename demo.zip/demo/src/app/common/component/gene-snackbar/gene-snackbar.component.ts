import {Component, Inject, Host} from "@angular/core";
import {MAT_SNACK_BAR_DATA, MatSnackBar} from "@angular/material/snack-bar";

@Component({
    templateUrl: "./gene-snackbar.component.html",
    styleUrls:['./gene-snackbar.component.scss']
})
export class GeneSnackBarComponent{

    // fetch data from the source
    constructor(@Inject(MAT_SNACK_BAR_DATA) public data: any, private sb: MatSnackBar) { }

    dismiss(){
        this.sb.dismiss();
    }
}