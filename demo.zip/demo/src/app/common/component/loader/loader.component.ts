import { Component, OnDestroy, AfterViewInit } from '@angular/core';

import { CommonService } from 'src/app/common/service/common.service';

@Component({
    selector: 'app-loader',
    templateUrl: 'loader.component.html',
    styleUrls: ['loader.component.scss']
})

export class LoaderComponent implements AfterViewInit, OnDestroy {

    intervalObs;

    constructor( private commonService: CommonService) { }

    ngAfterViewInit() {
        // this.intervalObs = setInterval(()=>{
        //     let elm = document.getElementById('loader-img');
        //     if(elm.classList.contains('rotate-360')){
        //         elm.classList.remove('rotate-360');
        //         elm.classList.add('rotate-90');
        //     }else if(elm.classList.contains('rotate-90')){
        //         elm.classList.remove('rotate-90');
        //         elm.classList.add('rotate-180');
        //     }else if(elm.classList.contains('rotate-180')){
        //         elm.classList.remove('rotate-180');
        //         elm.classList.add('rotate-270');
        //     }else if(elm.classList.contains('rotate-270')){
        //         elm.classList.remove('rotate-270');
        //         elm.classList.add('rotate-360');
        //     }else{
        //         elm.classList.add('rotate-90');
        //     }
        // }, 400)

        this.intervalObs = this.commonService.loaderEvent.subscribe(data => {
            if(data){
                if(!document.getElementById('loader').classList.contains('show')){
                    document.getElementById('loader').classList.add('show');
                }
            }else{
                document.getElementById('loader').classList.contains('show') ? document.getElementById('loader').classList.remove('show') : '';
            }
        })
    }

    ngOnDestroy(){
        this.intervalObs = null;
    }
}