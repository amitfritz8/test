import { Component, OnInit, AfterViewInit, Input } from "@angular/core";
import { CommonService } from "../service/common.service";
import { RestService } from "../service/rest.service";
import { Router, NavigationEnd } from '@angular/router';
import * as _ from "lodash";
import { url } from 'inspector';

// for jquery
declare var $: any

@Component({
  selector: "app-sidenav",
  templateUrl: "../views/sidenav.component.html",
  styleUrls: ["../css/sidenav.component.scss"]
})
export class SideNavCompnent implements OnInit, AfterViewInit {

  @Input() hideNav: boolean;

  minimizePan: boolean = true;
  portalInfo: any = {
    mapping: {
      modules: {}
    }
  };
  previousVisitedMenu: string;
  menuList: Object = {};

  constructor(private commonService: CommonService, private restService: RestService, public router: Router) {

  }

  accordingHanlder(id) {
    if (!this.previousVisitedMenu) {
      this.previousVisitedMenu = id;
      this.toggleSubmenu(id);
    } else if (this.previousVisitedMenu != '' && id == this.previousVisitedMenu) {
      this.toggleSubmenu(this.previousVisitedMenu);
    } else {
      (document.getElementById(`${this.previousVisitedMenu}-submenu`) && document.getElementById(`${this.previousVisitedMenu}-submenu`).classList.contains('show')) ?
        this.toggleSubmenu(this.previousVisitedMenu) : '';
      this.previousVisitedMenu = id;
      this.toggleSubmenu(this.previousVisitedMenu);
    }
  }

  toggleSubmenu(plc) {
    if (document.getElementById(`${plc}-submenu`)) {
      (!document.getElementById(`${plc}-submenu`).classList.contains('show'))
        ? document.getElementById(`${plc}-submenu`).classList.add('show')
        : document.getElementById(`${plc}-submenu`).classList.remove('show');
      this.toggleCaret();
    }
  }

  reset() {
    document.getElementById(`${this.previousVisitedMenu}`).classList.remove('show');
  }

  ngOnInit() {
    this.portalInfo = this.commonService.getProtalInfo();

    _.forEach(this.portalInfo.mapping.modules, (value)=>{
      _.forEach(value, (v)=>{
        Object.keys(this.menuList).indexOf(v.module) < 0 ? this.menuList[v.module] = [] : '';
        this.menuList[v.module].indexOf(v.subModule) < 0 ? this.menuList[v.module].push(v.subModule) : '';
      })
    })

  }

  ngAfterViewInit() {
    this.accordingHanlder(this.router.url.split("/")[2]);
  }

  menuClosure(id) {
    this.accordingHanlder(id);
  }

  toggleCaret() {
    if (!this.minimizePan) {
      let elm = document.getElementById(this.previousVisitedMenu).firstElementChild.lastElementChild;
      if (elm.classList.contains('rotate-180')) {
        elm.classList.remove('rotate-180');
      } else {
        (document.getElementById(`${this.previousVisitedMenu}-submenu`) && document.getElementById(`${this.previousVisitedMenu}-submenu`).classList.contains('show'))
          ? elm.classList.add('rotate-180') : '';
      }
    }
  }

  transitionEnd(e) {
    e.preventDefault();
    if ($('#sidebar').is(":hover") && this.minimizePan) {
      this.minimizePan = !this.minimizePan;
    }
  }

  logout() {
    this.restService.put(`/auth/logout?userId=${this.portalInfo.username}`, null).subscribe(data => { });
    this.commonService.logout();
    window.localStorage.clear();
  }

  start() {
    setTimeout(() => {
      this.toggleCaret();
    }, 230);
  }

  checkPermission(key: string) {
    return Object.keys(this.portalInfo.mapping.modules).indexOf(key) >= 0;
  }

  checkSubMenu(parent: string, child: string) {
    return this.menuList[parent].indexOf(child) >= 0;
  }

  end(e) {
    e.preventDefault();
    document.getElementsByClassName('logout-menu').length > 0 ? document.getElementsByClassName('logout-menu')[0].classList.remove('show') : "";
    this.minimizePan = true;
  }
}
