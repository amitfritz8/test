import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcRangeComponent } from './ic-range.component';

xdescribe('IcRangeComponent', () => {
  let component: IcRangeComponent;
  let fixture: ComponentFixture<IcRangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcRangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcRangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
