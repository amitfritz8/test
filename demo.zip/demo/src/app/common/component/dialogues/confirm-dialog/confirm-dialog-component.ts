import {Component, Inject, OnInit, Output} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'confirm-dialog',
  templateUrl: './confirm-dialog-component.html',
  styleUrls: ['./confirm-dialog-component.scss']
})
export class ConfirmDialogComponent implements OnInit {
  body = '';
  button1 = '';
  button2 = '';
  header = '';
  note = '';

  constructor(public dialogRef: MatDialogRef<ConfirmDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
    this.dialogRef.updateSize('53%', '53%');
    this.header = this.data.header;
    this.body = this.data.body;
    this.note = this.data.note;
    this.button1 = this.data.button1;
    this.button2 = this.data.button2;
  }

  onYesClick(): void {
    this.dialogRef.close('yes');
  }

  onNoClick(): void {
    this.dialogRef.close('no');
  }

}
