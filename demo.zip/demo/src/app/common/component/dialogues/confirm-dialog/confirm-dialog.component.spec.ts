// import {async, ComponentFixture, TestBed} from '@angular/core/testing';
// import {ConfirmDialogComponent} from './confirm-dialog-component';
// import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
// import {DebugElement} from '@angular/core';
// import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// import {MaterialModule} from 'src/app/material.module';
// import {BrowserModule, By} from '@angular/platform-browser';
// import {configureTestSuite} from 'ng-bullet';


// describe('ConfirmDialogComponent', () => {
//   let component: ConfirmDialogComponent;
//   let fixture: ComponentFixture<ConfirmDialogComponent>;
//   let de: DebugElement;
//   let el: HTMLElement;


//   configureTestSuite(() => {
//     TestBed.configureTestingModule({
//       declarations: [ConfirmDialogComponent],
//       imports: [BrowserAnimationsModule, MaterialModule, BrowserModule],
//       providers: [
//         {provide: MatDialogRef, useClass: MockMatDialogRef},
//         {provide: MAT_DIALOG_DATA, useClass: MockMAT_DIALOG_DATA}
//       ]
//     })
//     fixture = TestBed.createComponent(ConfirmDialogComponent);
//     component = fixture.componentInstance;
//     component.ngOnInit();
//     fixture.detectChanges();
//     de = fixture.debugElement.query(By.css('.mainDiv'));
//     el = de.nativeElement;
//   });


//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   describe('onYesClick', () => {
//     it('should call onYesClick', () => {
//       component.onYesClick();
//       let s: MockMatDialogRef = new MockMatDialogRef();
//       spyOn(s, 'close');
//       s.close('yes');
//       expect(s.close).toHaveBeenCalled();
//     });
//   });
//   describe('onNoClick', () => {
//     it('should call onNoClick', () => {
//       component.onNoClick();
//       let s: MockMatDialogRef = new MockMatDialogRef();
//       spyOn(s, 'close');
//       s.close('no');
//       expect(s.close).toHaveBeenCalled();
//     });
//   });

// });

// class MockMatDialogRef {
//   updateSize(a, b) {
//     return a * b;
//   }

//   close(test) {
//     return null;
//   }
// }

// class MockMAT_DIALOG_DATA {

// }
