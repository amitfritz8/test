// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import {TeamReportingDialogComponent} from './team-reporting-dialog.component';

// xdescribe('WeekOnWeekDialogComponent', () => {
//   let component: TeamReportingDialogComponent;
//   let fixture: ComponentFixture<TeamReportingDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ TeamReportingDialogComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(TeamReportingDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
