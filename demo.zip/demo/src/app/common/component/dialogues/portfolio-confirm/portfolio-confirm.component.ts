import { Component, OnInit } from '@angular/core';
import { MatDialogRef,  MatDialog } from '@angular/material/dialog';
import { FormGroup, Validators, FormBuilder,FormArray, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-portfolio-confirm',
  templateUrl: './portfolio-confirm.component.html',
  styleUrls: ['./portfolio-confirm.component.scss']
})
export class PortfolioConfirmComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<PortfolioConfirmComponent>,  private fb: FormBuilder, private router: Router, public dialog: MatDialog, ) {
  }

  ngOnInit() {
    this.dialogRef.updateSize('80%', '95%');
  }

  onCreatePortfolioClick(){
    this.dialogRef.close('yes');
    this.router.navigateByUrl('home/portfolio/createPortfolio');
  }
  close(){
    this.dialogRef.close('yes');
  }
}
