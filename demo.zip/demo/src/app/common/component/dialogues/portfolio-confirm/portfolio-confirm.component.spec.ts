import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PortfolioConfirmComponent } from './portfolio-confirm.component';

xdescribe('PortfolioConfirmComponent', () => {
  let component: PortfolioConfirmComponent;
  let fixture: ComponentFixture<PortfolioConfirmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PortfolioConfirmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PortfolioConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
