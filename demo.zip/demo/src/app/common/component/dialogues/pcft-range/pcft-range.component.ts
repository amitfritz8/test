import { Component,Inject, OnInit  } from '@angular/core';
import { Options } from 'ng5-slider';
import {RestService} from 'src/app/common/service/rest.service';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-pcft-range',
  templateUrl: './pcft-range.component.html',
  styleUrls: ['./pcft-range.component.scss']
})
export class PcftRangeComponent implements OnInit {
  reportingPeriod:any;
  pcftHighValue: number = 1;
  pcftValue: number = 0;

  constructor(private restService: RestService,public dialogRef: MatDialogRef<PcftRangeComponent>, @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this.dialogRef.updateSize('7%', '40%');
    this.reportingPeriod=this.data.reportingPeriod;
  }
  
  options: Options = {
    //showTicksValues: true,
    vertical: true,
    stepsArray: [
      {value: 0},
      {value: 0.1},
      {value: 0.2},
      {value: 0.3},
      {value: 0.4},
      {value: 0.5},
      {value: 0.6},
      {value: 0.7},
      {value: 0.8},
      {value: 0.9},
      {value: 1}
    ]
  };
  close(){
    this.dialogRef.close( {data: {
      pcftHighValue:this.pcftHighValue,
      pcftValue:this.pcftValue
    }
  });
  }
}
