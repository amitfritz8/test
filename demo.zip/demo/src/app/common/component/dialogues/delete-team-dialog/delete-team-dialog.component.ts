import {Component, Inject, OnInit} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {MatTableDataSource} from '@angular/material/table';
import {RestService} from '../../../service/rest.service';
import * as moment from 'moment';

@Component({
  selector: 'app-delete-team-dialog',
  templateUrl: './delete-team-dialog.component.html',
  styleUrls: ['./delete-team-dialog.component.scss']
})
export class DeleteTeamDialogComponent implements OnInit {

  endDate: string ='';
  removalReason: string ='';
  reasonsForRemoval=[];
  enableText: boolean;
  allowSubmit:boolean;
  dateListForMembersStartDate = [];
  additionalInfo: string='';

  constructor(public dialogRef: MatDialogRef<DeleteTeamDialogComponent>, public restService : RestService) {
  }

  ngOnInit() {
    this.datefetch();
    this.restService.get(`/people/team/teammanagement/getReasonsForRemoval`).subscribe(result => {
     result ? this.reasonsForRemoval =result : '';
    });
  }
  check(){
    if(this.endDate !== '' && this.removalReason !== ''){
      this.allowSubmit = true;
      this.enableText = true;
    }
  }

  datefetch() {
    const today = new Date();
    const nextSunday = new Date();
    this.dateListForMembersStartDate = [];
    // Can change 1 To get Mon-1, Tue-2... Sun-7
    nextSunday.setDate((today.getDate() + (7 + 7 - today.getDay()) % 7));
    this.dateListForMembersStartDate.push(moment(nextSunday).format('DD MMMM,YYYY').toString());
    for (let i = 0; i < 3; i++) {
      today.setTime(nextSunday.getTime() + (7*24*60*60*1000));
      this.dateListForMembersStartDate.push(moment(today).format('DD MMMM,YYYY').toString());
      nextSunday.setTime(today.getTime() + (7*24*60*60*1000));
    }
  }
  onSubmit() {
    let response={
      result: 'Yes',
      endDate: this.endDate,
      removalReason: this.removalReason,
      additionalInfo: this.additionalInfo
    }
    this.dialogRef.close(response);
  }
  onCancel() {
    let response={
      result: 'No',
      endDate: this.endDate,
      removalReason: this.removalReason,
      additionalInfo: this.additionalInfo
    }
    this.dialogRef.close(response);
  }
}
