import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { DataService } from 'src/app/common/service/data.service';

@Component({
  selector: 'common-dialog',
  templateUrl: './common-dialog-component.html',
  styleUrls: ['./common-dialog-component.scss'],
})
export class CommonDialogComponent implements OnInit {

  constructor(private http: HttpClient, public dialogRef: MatDialogRef<CommonDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: any, private dataService: DataService) {
  }

  ngOnInit() {
  }

  getDialogButtonClass():string{
    if(this.dialogData.type === 'success' || this.dialogData.type === 'confirm'){
      return 'g-btn-primary';
    } else {
      return 'g-btn-destructive';
    }
  }

  onYesClick(): void {
    if(this.dialogData.confirmCallBack){
      this.dialogData.confirmCallBack(this.dialogRef)
    }else{
      this.dialogRef.close('yes'); 
    }
  }

  onNoClick(): void {
    if(this.dialogData.cancelCallBack){
      this.dialogData.cancelCallBack(this.dialogRef)
    }else{
      this.dialogRef.close('no'); 
    }
  }

  onCancelClick(): void{
    this.dialogRef.close('cancel');
  }
}
