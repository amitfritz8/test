import {Component, Inject, OnInit} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA, MatDialog} from '@angular/material/dialog';
import {RestService} from 'src/app/common/service/rest.service';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import {DataService} from 'src/app/common/service/data.service';
import {ConfirmDialogComponent} from '../confirm-dialog/confirm-dialog-component';
import {ActivatedRoute, Router} from '@angular/router';


@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.scss']
})
export class AddRoleComponent implements OnInit {
  body = '';
  header = '';
  note = '';
  rolesList = [];
  rolesAdded = [];
  value = 1169;
  response: any = [];
  noData: any;
  //addButton : any;
  selectedValue = '';
  FTEValue = 1;
  plannedCapacity = '';
  isValid = false;
  isDecimalValid = false;
  isSelectRoleValid = false;
  addRoleForm: FormGroup;
  roleResul: any = [];
  roleData: any = {
    selectedRole: '',
    inputPlannedCapacity: ''

  };

  constructor(private fb: FormBuilder, public dialogRef: MatDialogRef<AddRoleComponent>, public dialogPromptWindow: MatDialogRef<AddRoleComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any, private dataService: DataService, private restService: RestService,
              private router: Router, public dialog: MatDialog) {
  }

  ngOnInit() {
    this.dialogRef.updateSize('52%', '51%');
    this.dialogPromptWindow.updateSize('52%', '51%');
    this.header = this.data.header;
    this.body = this.data.body;
    this.note = this.data.note;
    this.getRoles();
    this.addRoleForm = this.fb.group({
      selectedRole: [{value: this.roleData.selectedRole}, [Validators.required]],
      inputPlannedCapacity: [{value: this.roleData.inputPlannedCapacity}, [Validators.required]]
    });
    //this.addButton = true;
  }

  /*function for getting different roles in the team in drop-down*/
  getRoles() {
    this.rolesList = JSON.parse(localStorage.getItem("roles"));
    this.rolesAdded = JSON.parse(localStorage.getItem("addedRoles"));
  }

  /* ON clicking cancel button */

  onNoClick() {
    if (this.selectedValue !== '') {
      const dialogPrompt = this.dialog.open(ConfirmDialogComponent, {
        data: {
          header: 'Confirmation',
          body: 'You are adding team roles, if you navigate away from this page without Adding, your changes will be lost.',
          note: 'Do you want to proceed?',
          button1: 'Cancel',
          button2: 'OK'
        }
      });
      dialogPrompt.afterClosed().subscribe(result => {
        if (result === 'yes') {
          //this.dialogPromptWindow.close('cancel');
          if (this.rolesAdded) {
            this.dialogPromptWindow.close('cancel');
          }
          else {
            this.dialogPromptWindow.close('cancel');
           // this.router.navigateByUrl('home/teammanagement');
          }
        }
        else{
          //this.dialogPromptWindow.close('cancel');
        }
      });
    } else {
      this.dialogPromptWindow.close('cancel');
    }
  }

  /* On change event for drop down */
  getSelectedRoleOnChangeEvent(selectedValue) {
    this.selectedValue = selectedValue;
    if (selectedValue) {
      this.isSelectRoleValid = false;
    }
  }

  /* On change event for input field FTE Capacity */
  onValueChange(value) {
    this.FTEValue = value;
    this.isValid = false;
    //this.isDecimalValid=false;
    if (value < 1) {
      this.isValid = true;
    }
    else if (value.indexOf('.') > -1 && value.substring(value.indexOf('.')).length >= 4) {
      this.isValid = true;
    }
  }

  /* On clicking add button in dialoge box*/
  onAddClick() {
    const values = this.addRoleForm.controls;
    for (const value in values) {
      if (values[value].invalid) {
        this.addRoleForm.controls[name].markAsTouched();
      } else if (this.addRoleForm.valid) {

        for (const val in this.roleData) {
          if (this.addRoleForm.controls.hasOwnProperty(val)) {
            this.roleData[val] = this.addRoleForm.controls[val].value;
            }
        }
      }
    }
    if (this.roleData.selectedRole.value === null || this.roleData.selectedRole.value === "") {
      this.isSelectRoleValid = true;
    }
    else {
      this.isSelectRoleValid = false;
      var index = this.rolesList.findIndex(role => role.value === this.roleData.selectedRole);
      this.rolesList.splice(index, 1);
      localStorage.setItem("roles", JSON.stringify(this.rolesList));
      this.dialogRef.close(this.roleData);
    }
  }
}
