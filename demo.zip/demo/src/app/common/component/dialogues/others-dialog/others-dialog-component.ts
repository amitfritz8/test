import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DataService } from 'src/app/common/service/data.service';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { DateUtility } from 'src/app/common/utility/date-utility';

const HttpUploadOptions = {
  headers: new HttpHeaders({ 'content-type': 'multipart/form-data', 'Authorization': 'Bearer ' + localStorage.getItem('access_token') })
}

@Component({
  selector: 'others-dialog',
  templateUrl: './others-dialog-component.html',
  styleUrls: ['./others-dialog-component.scss'],
})
export class OthersDialogComponent implements OnInit {
  body = '';
  header = '';
  //selectedDocumentType: string;
  documentTypes: any = [];
  //description: string;

  // techUnit: string = null;
  validFileExtensions = ['.xlsx','.xls','.pdf','.text'];
  fileValid = false;
  files: any = [];
  uploadResult: any = [];
  isErrorExists: boolean = false;
  //othersEntity: any;
  //othersData: any;
  //sysdate: any;
  other: any;
  isDescriptionEmpty : boolean = false;
  isDocumentTypeEmpty: boolean = false;
  constructor(private dateUtility: DateUtility,private fb: FormBuilder,private http: HttpClient, public dialogRef: MatDialogRef<OthersDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any, private dataService: DataService,private datePipe: DatePipe) {
  }

  ngOnInit() {
    this.documentTypes = this.data.documentTypes;
    // this.techUnit = JSON.parse(sessionStorage.getItem('loggedInUserTechUnit'));
    // this.dialogRef.updateSize('60%', '75%');
    this.header = '';
    this.body = this.data.body;
    this.other = this.data.other;
    if( this.other.controls.othersEntity.controls.documentName.value === ''){
      this.other.controls.othersEntity.controls.dateModified.value = this.datePipe.transform(new Date(), 'yyyy-MM-dd hh:mm:ss');
      this.other.controls.othersEntity.controls.modifiedBy.value = localStorage.getItem('userOneBankId');
      this.other.controls.othersEntity.controls.dateCreated.value = this.datePipe.transform(new Date(), 'yyyy-MM-dd hh:mm:ss');
      this.other.controls.othersEntity.controls.createdBy.value = localStorage.getItem('userOneBankId');
    }else{
      this.other.controls.othersEntity.controls.dateModified.value = this.datePipe.transform(new Date(), 'yyyy-MM-dd hh:mm:ss');
      this.other.controls.othersEntity.controls.dateCreated.value = this.datePipe.transform(this.other.controls.othersEntity.controls.dateCreated.value, 'yyyy-MM-dd hh:mm:ss');
      this.other.controls.othersEntity.controls.modifiedBy.value = localStorage.getItem('userOneBankId');
      this.files.push(this.other.controls.file.value);
      this.fileValid=true;
    }

  }

  dateFormatISO(millisecondsDate?: any) {
    return this.dateUtility.dateFormatterISO(millisecondsDate);
  }

  onYesClick(): void {

    if (this.other.controls.othersEntity.controls.documentType.value == '' || this.other.controls.othersEntity.controls.description.value == '') {
      this.isDocumentTypeEmpty = this.other.controls.othersEntity.controls.documentType.value == '';
      this.isDescriptionEmpty = this.other.controls.othersEntity.controls.description.value == '';
      return ;
    }

    if (this.fileValid) {
      //this.setOthers();
      this.other.controls.file= this.files[0];
      this.other.controls.othersEntity.controls.documentName.value = this.files[0].name;
      this.other.controls.isEdited = true;
      this.dataService.loaderHandler(false);
      this.dialogRef.close(this.other);
      this.dialogRef.updateSize('60%', '75%');
    }

  }

  onNoClick(): void {
    this.dialogRef.close('no');
  }

  uploadFile(event) {
    this.fileValid = false;
    if (this.validate(event[0].name)) {
      for (let index = 0; index < event.length; index++) {
        const element = event[index];
        this.files.push(element);
        this.dialogRef.updateSize('60%', '75%');
      }
    }
  }

  deleteAttachment(index) {
    this.isErrorExists = false;
    this.files.splice(index, 1);
    this.dialogRef.updateSize('60%', '75%');
  }


  validate(fileName) {
    let sFileName = fileName;
    if (sFileName.length > 0) {
      this.fileValid = true;
      this.isErrorExists = false;
      return true;
    }
    return false;
  }

  checkFileValid() {
    if (!this.fileValid) {
      this.isErrorExists = true;
      this.uploadResult.message = 'Data import was unsuccessful. Please use a valid template format to import the data.';
      this.uploadResult.errorFlag = '1';
      this.dataService.getCustomMessage('Data import was unsuccessful. Please use a valid template format to import the data.');
      this.dataService.getFlag('1');
      return false;
    } else {
      return
    }
  }

  /* setOthers() {
    this.othersEntity = this.fb.group({
          wsOthersSurrId: 0,
          workStreamId: this.data.workstreamId,
          portfolioId: this.data.portfolioId,
          documentName : this.files[0].name,
          documentType : this.selectedDocumentType,
          description : this.description,
          modifiedBy : this.userId,
          dateModified : this.sysdate,
          createdBy : this.userId,
          dateCreated : this.sysdate
        })
     this.othersData = this.fb.group({
       othersEntity: this.othersEntity,
       file : this.files[0]
     })
  }*/

  textAreaData(event: any) {
    if (event.value != '') {
      this.isDescriptionEmpty = false
    } else {
      this.isDescriptionEmpty = true;
    }

  }


}
