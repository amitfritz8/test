import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CopyScenarioDialogComponent } from './copy-scenario-dialog.component';

xdescribe('CopyScenarioDialogComponent', () => {
  let component: CopyScenarioDialogComponent;
  let fixture: ComponentFixture<CopyScenarioDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CopyScenarioDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CopyScenarioDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
