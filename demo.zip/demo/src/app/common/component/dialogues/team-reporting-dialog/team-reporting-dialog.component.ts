import {Component, Inject, OnInit} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-team-reporting-dialog',
  templateUrl: './team-reporting-dialog.component.html',
  styleUrls: ['./team-reporting-dialog.component.scss']
})
export class TeamReportingDialogComponent implements OnInit {

  body = '';
  button1 = '';
  button2 = '';
  header = '';
  note = '';
  element: any;
  pctValues: any;
  week1: string = '-';
  teamName: string='';
 displayedColumns = ['teamName', 'members', 'FTECapacity', 'blendedTeamCost', 'membersAug', 'FTECapacityAug', 'blendedTeamCostAug'];
  dataSource: MatTableDataSource<any> = new MatTableDataSource();

  constructor(public dialogRef: MatDialogRef<TeamReportingDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
    this.dataSource = new MatTableDataSource();
    let total=[];
    total.push(this.data.current);
    total.push(this.data.total);
    this.teamName=this.data.current.teamName;
    this.dataSource.data=total;
  }

  close() {
    this.dialogRef.close('yes');
  }

}
