import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CostSettingsSaveComponent } from './cost-settings-save.component';

xdescribe('CostSettingsSaveComponent', () => {
  let component: CostSettingsSaveComponent;
  let fixture: ComponentFixture<CostSettingsSaveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CostSettingsSaveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CostSettingsSaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
