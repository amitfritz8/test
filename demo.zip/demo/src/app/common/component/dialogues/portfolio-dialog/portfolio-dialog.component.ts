import {Component, OnInit, Inject, Input} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA, MatDialog} from '@angular/material/dialog';
import {FormGroup, Validators, FormBuilder, FormArray, FormControl} from '@angular/forms';
import {Router} from '@angular/router';
import {RestService} from 'src/app/common/service/rest.service';
import {DataService} from 'src/app/common/service/data.service';
import {WORK_HIERARCHY_CONST} from 'src/app/common/constants/workHierarchy';
import {CommonDialogComponent} from './../common-dialog/common-dialog-component';
import {URL_PREFIX} from 'src/app/common/constants/urlprefix';
import {RxwebValidators} from '@rxweb/reactive-form-validators';

@Component({
  selector: 'app-portfolio-dialog',
  templateUrl: './portfolio-dialog.component.html',
  styleUrls: ['./portfolio-dialog.component.scss']
})
export class PortfolioDialogComponent implements OnInit {
  portfolioform: FormGroup;
  action = 'add';
  deliveryUnit = '';
  portfolioId: any;
  portfolioName: any;
  SelPortfolioName: any;
  selWorkstreamName: any;
  selSubWorkstreamName: any;
  hasDuplicateSWSPlatformIndex = false;
  hasDuplicateSWSName: any = [];
  duplicateSWSNameExists = false;
  DropDownList: any;
  yearDropDownList: any = [];
  workTypeDropdown: any = [];
  countryDropdown: any = [];
  PlatformDropdownList: any = [];
  subDeliveryPlatform: any = [];
  prepareData: any;
  workstreams = [];
  subWorkstreams = [];
  subWorkstreamName = '';
  workStreamName = '';
  @Input() element: any;
  deliveryPlatformUnit = '';
  subWorkstreamData = {
    subWorkStreamName: '',
    deliveryPlatformUnit: this.deliveryPlatformUnit
  };
  public dropdownListForDeliveryPlatform: any[];

  constructor(public dialogRef: MatDialogRef<PortfolioDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any, private fb: FormBuilder,
              private router: Router, private restService: RestService,
              private dataService: DataService, public dialog: MatDialog,) {
  }

  get f() {
    return this.portfolioform.controls;
  }

  get t() {
    return this.f.subWorkstreamList as FormArray;
  }

  ngOnInit() {
    this.dialogRef.updateSize('70%', '80%');

    this.portfolioform = this.fb.group({
      portfolioName: ['', [Validators.required]],
      initiationYear: ['', [Validators.required]],
      workType: ['I',],
      primaryPlatformName: ['', [Validators.required]],
      workStreamName: [this.workStreamName, []],
      country: ['', [Validators.required]],
      deliveryPlatformUnit: ['',],
      subWorkstreamList: this.fb.array([this.createSubWorkstream(this.subWorkstreamData)]),
      subDeliveryPlatform: ['',]
    });
    this.getData();
    this.getDropdownAsPerUAMS();
  }

  getData() {

    this.PlatformDropdownList = [];

    const list = ['Year of Initiation', 'Country', 'WorkType'];
    this.restService.post(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues/', list).subscribe(data => {

      data['Year of Initiation'].forEach(element => {
        this.yearDropDownList.push({value: element.value, display: element.value});
      });

      data.WorkType.forEach(element => {
        this.workTypeDropdown.push({value: element.value, display: element.value});
      });
    });
  }

  getDropdownAsPerUAMS() {
    let locations = JSON.parse(sessionStorage.getItem('locationsAsPerUAMS'));
    locations.forEach(element => {
      this.countryDropdown.push({value: element, display: element});
    });

    this.PlatformDropdownList = [];
    let selecetdPlatforms = JSON.parse(sessionStorage.getItem('selectedPIwithNames'));
    selecetdPlatforms.forEach(element => {
      this.PlatformDropdownList.push({key: element.platformIndex + ' - ' + element.platform, value: element.platformIndex + ' - ' + element.platform});
    });
    this.dropdownListForDeliveryPlatform = [];
    this.restService.get(URL_PREFIX.PEOPLE + '/data/platforms/all').subscribe(data => {
      data.forEach((element: { platformId: any; platformIndex: string; platform: string; }) => {
        this.dropdownListForDeliveryPlatform.push({key: element.platformId, value: element.platformIndex + ' - ' + element.platform});
      });
    });

  }

  // Save Action
  save() {
    if (!this.duplicateSWSNameExists) {
      const controls = this.portfolioform.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          this.portfolioform.controls[name].markAsTouched();
        }
      }
      if (this.portfolioform.invalid) {
        this.portfolioform.markAllAsTouched();
      } else if (this.portfolioform.valid) {
        const list = this.portfolioform.value;

        this.prepareData = {
          portfolioName: this.portfolioform.controls.portfolioName.value,
          initiationYear: this.portfolioform.controls.initiationYear.value,
          workType: this.portfolioform.controls.workType.value,
          primaryPlatformName: this.portfolioform.controls.primaryPlatformName.value,
          workStreams: [{
            workStreamName: this.portfolioform.controls.workStreamName.value,
            country: this.portfolioform.controls.country.value,
            subWorkStreams: this.portfolioform.controls.subWorkstreamList.value
          }]
        };

        if (this.action === 'add') {
          let userId = localStorage.getItem('userOneBankId');
          this.restService.post(URL_PREFIX.PORTFOLIO + `/data/portfolio/generate/default/portfoliogeneration?userId=${userId}`, this.prepareData).subscribe(data => {
              if (data[0] !== null && data[0].portfolioId !== null) {
                this.portfolioId = data[0].portfolioId;
                this.portfolioName = data[0].portfolioName;
                sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID, this.portfolioId);
                sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME, this.portfolioName);
                this.dialogRef.close('yes');
                this.onCreatePortfolioClick();
                // this.router.navigateByUrl('home/portfolio/createPortfolio');
              }
            },
            error => {
              if (error.status !== null) {
                console.log(list.portfolioName + 'portfolioName');
                this.dialogRef.close('yes');
                this.router.navigateByUrl('home/portfolio/portfolioView');
                this.dataService.loaderHandler(false);
                this.dataService.getCustomMessage('An unexpected error has occurred.' +
                  ' Reference data needed to display appropriate error message cannot be found.' +
                  ' Please contact the System Administrator.');
                this.dataService.getFlag('1');
              }
            }
          );
        }
      }
    }
  }

  onCreatePortfolioClick() {

    const dialogRef = this.dialog.open(CommonDialogComponent, {
      data: {
        contentTitle: 'Your Portfolio has been created successfully',
        type: 'success',
        content: 'The Portfolio ID, Workstream ID and Sub-Workstream ID have been generated automatically.',
        content1: (this.portfolioId.substr(this.portfolioId.length - 1, this.portfolioId.length) === 'I') ?
          'Project ID creation request sent to FinSys, please look out for FinSys email for confirmation.' : null,
        confirmTxt: 'View Portfolio',
        cancelTxt: 'Cancel',
        confirmCallBack: this.cnfmClbk.bind(this)
      }
    });
  }

  cnfmClbk(dialogRef) {
    dialogRef.close();
    this.router.navigateByUrl('home/portfolio/createPortfolio');
  }

  addSubWorkstreamList() {
    if (!this.duplicateSWSNameExists && !this.portfolioform.controls.subWorkstreamList.invalid) {
      this.subWorkstreamList().push(this.createSubWorkstreamList());
    } else {
      this.portfolioform.controls.subWorkstreamList.markAllAsTouched();
    }
  }

  subWorkstreamList(): FormArray {
    return this.portfolioform.get('subWorkstreamList') as FormArray;
  }

  createSubWorkstreamList(): FormGroup {
    return this.fb.group(
      {
        subWorkStreamName: ['', [Validators.required, RxwebValidators.unique()]],
        deliveryPlatformUnit: ['', [Validators.required]]
      });

  }

  createSubWorkstream(data): FormGroup {
    return this.fb.group(
      {
        subWorkStreamName: [data.subWorkStreamName, []],
        deliveryPlatformUnit: [data.deliveryPlatformUnit, []]
      });
  }

  deleteSubWorkStreamList(index: number) {
    this.subWorkstreamList().removeAt(index);
    this.hasDuplicateSWSName[index] = false;
    this.duplicateSWSNameExists = false;
  }

  goback() {
    this.dialogRef.close('no');
  }

  platformSelected(e) {
    this.deliveryUnit = e.value;
    this.portfolioform.controls.subWorkstreamList.value[0].subWorkStreamName = this.subWorkstreamName;
    this.portfolioform.controls.subWorkstreamList.value[0].deliveryPlatformUnit = e.value;
  }

  subPlatformSelected(e) {
    this.subDeliveryPlatform = e.value;
  }

  enteredPortfolioName(e) {
    this.SelPortfolioName = e.value;
  }

  onPortFolioChange(portfolioNameValue: string): void {
    this.subWorkstreamName = 'SWS0-' + portfolioNameValue;
    this.workStreamName = 'WS0-' + portfolioNameValue;
    this.portfolioform.controls.workStreamName.setValue(this.workStreamName);
    this.portfolioform.controls.subWorkstreamList.value[0].subWorkStreamName = this.subWorkstreamName;
  }

  enteredWorkstreamName(e) {
    this.selWorkstreamName = e.value;
  }


  checkDuplicateSWSName(index: number) {
    let temp = false;
    this.hasDuplicateSWSName[index] = false;
    const control = this.portfolioform.controls.subWorkstreamList as FormArray;
    this.element = control.value;
    // let newFormulalist =  this.element.filter((v,i) => this.element.findIndex(item => item.value == v.value) === i);
    this.element.map(v => v.subWorkStreamName).sort().sort((a, b) => {
      if (a.toUpperCase() === b.toUpperCase()) {
        this.hasDuplicateSWSName[index] = true;
        this.duplicateSWSNameExists = true;
        temp = true;
      } else {
        // this.hasDuplicateSWSName[index] = false;
      }
    });
    if (!temp) {
      this.duplicateSWSNameExists = false;
    }
  }

  findDuplicate(index: number) {

    let temp = false;
    this.hasDuplicateSWSName[index] = false;
    const control = this.portfolioform.controls.subWorkstreamList as FormArray;
    this.element = control.value;
    const names = this.element.map(v => v.subWorkStreamName.toUpperCase().trim());
    const hasDuplicate = names.some((name, index) => names.indexOf(name, index + 1) != -1
    );
    if (hasDuplicate) {
      this.hasDuplicateSWSName[index] = true;
      this.hasDuplicateSWSName.forEach((x: any) => {
        if (x) {
        }
      });
      this.duplicateSWSNameExists = true;
      temp = true;
    } else {
      this.hasDuplicateSWSName[index] = false;
    }
    if (!temp) {
      this.duplicateSWSNameExists = false;
    }
  }

}
