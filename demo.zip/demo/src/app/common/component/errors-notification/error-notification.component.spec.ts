import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {ErrorsNotificationComponent} from './errors-notification.component';
import {DebugElement} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MaterialModule} from 'src/app/material.module';
import {BrowserModule, By} from '@angular/platform-browser';
import {DataService} from 'src/app/common/service/data.service';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {Subject} from 'rxjs';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {configureTestSuite} from 'ng-bullet';

describe('ErrorsNotificationComponent', () => {
  let component: ErrorsNotificationComponent;
  let fixture: ComponentFixture<ErrorsNotificationComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [ErrorsNotificationComponent],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [
        BrowserAnimationsModule,
        MaterialModule,
        BrowserModule],
      providers: [
        {provide: DataService, useClass: MockDataService}
      ]
    })
    fixture = TestBed.createComponent(ErrorsNotificationComponent);
    component = fixture.componentInstance;
    component.message = '';
    component.msgFlag = '';
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.mainDiv'));
    el = de.nativeElement;
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

class MockDataService {
  private subject = new Subject<any>();

  private msgFlag = new BehaviorSubject('default message');
  messageFlag = this.msgFlag.asObservable();

  private message = new BehaviorSubject('default message');
  error = this.message.asObservable();
}
