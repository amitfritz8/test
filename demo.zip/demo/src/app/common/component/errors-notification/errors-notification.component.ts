import { Component, OnInit, Input } from '@angular/core';
import { DataService } from 'src/app/common/service/data.service';

@Component({
  selector: 'app-errors-notification',
  templateUrl: './errors-notification.component.html',
  styleUrls: ['./errors-notification.component.scss']
})
export class ErrorsNotificationComponent implements OnInit {
  message: string;
  msgFlag: string;

  constructor(private dataService : DataService) {
    this.dataService.messageFlag.subscribe(data =>{
      this.message= data;
      });
      this.dataService.error.subscribe(data =>{
        this.msgFlag= data;
        });
   }
  ngOnInit() {
  }

}
