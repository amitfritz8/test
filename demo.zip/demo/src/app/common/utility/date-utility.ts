import {Injectable} from '@angular/core';

@Injectable()
export class DateUtility {
  months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  dateformatter(date: any): Date {
    if (date instanceof Date) {
      return date;
    }
    return new Date(date.replace(/\s/g, 'T'));
  }

  dateFormatterMoment(date: Date): string {
    if (date) {
      const d = new Date(date);
      return d.getDate() + '-' + this.months[d.getMonth()] + '-' + d.getFullYear().toString().slice(-2);
    }
    return '-';
  }

  dateFormatterCustom(date: Date): string {
    if (date) {
      const d = new Date(date);
      return ('0' + d.getDate()).slice(-2) + ' ' + this.months[d.getMonth()] + ' ' + d.getFullYear().toString().slice(-2);
    }
    return '-';
  }
  dateFormatterCustomForPeople(date: Date): string {
    if (date) {
      const d = new Date(date);
      return ('0' + d.getDate()).slice(-2) + ' ' + this.months[d.getMonth()] + ' ' + d.getFullYear().toString().slice(-2);
    }
    return '-';
  }

  datetoString(date: Date): string {
    if (date) {
      const d = new Date(date);
      return d.getDate() + ' ' + this.months[d.getMonth()] + ' ' + d.getFullYear();
    }
    return '-';
  }

  dateFormatterISO(millisecondsDate: any): string {
    if (millisecondsDate) {
      var date = new Date(millisecondsDate);
      return date.toISOString();
    }
    return '';
  }

  dateToDateTimeString(date: Date): string {
    if (date) {
      const d = new Date(date);
      return d.getFullYear() + '-' + ("0" + (d.getMonth() + 1)).slice(-2) + '-' + ("0" + d.getDate()).slice(-2) + ' ' + ("0" + d.getHours()).slice(-2) + ':' + ("0" + d.getMinutes()).slice(-2) + ':' + ("0" + d.getSeconds()).slice(-2);
    }
    return '-';
  }
  datetoReportDateString(date: Date): string {
    if (date) {
      const d = new Date(date);
      return ("0" + d.getDate()).slice(-2) + ' ' + this.months[d.getMonth()] + ' ' + d.getFullYear();
    }
    return '-';
  }

}
