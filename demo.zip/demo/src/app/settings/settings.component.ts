import {Component, OnInit, AfterViewInit, ViewChild} from '@angular/core';
import {RestService} from 'src/app/common/service/rest.service';
import {ViewTribeComponent} from './view-tribe/view-tribe.component';
import {DataService} from 'src/app/common/service/data.service';
import {ViewSubPlatformComponent} from './view-subplatform/view-subplatform.component';
import {ChapterSetupComponent} from './chapter-setup/chapter-setup.component';
import {PlatformSetupComponent} from './platform-setup/platform-setup.component';
import {CommonService} from "src/app/common/service/common.service";

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit, AfterViewInit {
  nonGenRefData: any = [];
  refdataOption: any = '';
  platformList: any = [];
  temp: any;
  msg: any;
  @ViewChild(ViewTribeComponent, {static: false}) view: ViewTribeComponent;
  @ViewChild(ViewSubPlatformComponent, {static: false}) viewSubPlatform: ViewSubPlatformComponent;
  @ViewChild(ChapterSetupComponent, {static: false}) chapter: ChapterSetupComponent;
  @ViewChild(PlatformSetupComponent, {static: false}) viewPlatform: PlatformSetupComponent;
  platformSelected = false;
  selectedPlatform: string = '';
  passing = 'settings';
  editAction: any = false;
  selectedForEdit = [];
  action = 'view';
  isErrorExists = false;
  refDataSelected = false;
  platform: any;
  techUnit: any;
  create: string;
  techUnitList: any;
  selectedTechUnit: string = '';
  techUnitSelected = false;
  readAccess = [];
  writeAccess = [];
  buttonEnable = false;

  constructor(private restService: RestService, private dataservice: DataService, private commonService: CommonService) {
    this.restService.track('SETTINGS');
    this.commonService.recieveMessage({
      title: 'Settings'
    });
  }

  ngAfterViewInit() {
  }

  ngOnInit() {
    this.readAccess = JSON.parse(localStorage.getItem('readAccess'));
    this.writeAccess = JSON.parse(localStorage.getItem('writeAccess'));
    this.nonGenRefData = [];
    //This is added temp as backend is not ready, need to modify this API based upon flag for settings or admin options
    this.restService.get(`/people/data/nonGeneric/all/${this.passing}`).subscribe(nonGen => {
      this.temp = [];
      this.temp = nonGen;
      this.temp.forEach(element => {

        if (this.readAccess.findIndex(rAccess => rAccess === element.dataTableDescription) >= 0) {
          this.nonGenRefData.push({'value': element.dataTable, 'display': element.dataTableDescription});
        }

      });
    });
    if (this.nonGenRefData && this.nonGenRefData.length == 1) {
      this.refdataOption = this.nonGenRefData[0].value;
    }
    this.getPlatformData();
    this.platformSelected = false;
    this.buttonEnable = false;
  }

  getPlatformData() {
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    //this.restService.get(`/people/data/platforms`).subscribe(data => {
    this.restService.get('assets/json/mock/platforms.json').subscribe(data => {
      this.platformList = data.filter(val => {
        return platforms.includes(val.platformIndex);
      });
      this.platformList.sort((a, b) => (a.platformIndex > b.platformIndex) ? 1 : -1);
    });

  }

  onEditClickEvent(e) {
    if (e && e.platformIndex) {
      this.action = 'view';
      this.platform = e.platformIndex
      this.selectedPlatform = e.platformIndex;
      this.platformSelected = true;
      this.refdataOption = 'xref_tribe_leads';
      this.isErrorExists = this.view.isErrorExists;
    } else {
      this.action = e;
      this.isErrorExists = false;
    }
  }

  onEditClickEventForSubPlatform(e) {
    if (e && e.platformIndex) {
      this.action = 'view';
      this.platform = e.platformIndex
      this.selectedPlatform = e.platformIndex;
      this.platformSelected = true;
      this.refdataOption = 'xref_sub_platform_master';
      this.isErrorExists = this.viewSubPlatform.isErrorExists;
    } else {
      this.action = e;
      this.isErrorExists = false;
    }
  }

  onEditClickEventForChapter(e) {
    if (e && e.chapterMaster) {
      this.action = 'view';
      this.techUnit = e.chapterMaster.techunitCode;
      this.selectedTechUnit = e.chapterMaster.techunitCode;
      this.techUnitSelected = true;
      this.refdataOption = 'xref_chapter_master';
      this.isErrorExists = this.chapter.isErrorExists;
    } else {
      this.action = e;
      this.isErrorExists = false;
    }
  }

  onRefDataSelection(e) {
    this.buttonEnable = false;
    var selectedValue;
    this.nonGenRefData.forEach(res => {
      if (e.value === res.value) {
        selectedValue = res.display;
      }
    })
    for (var i = 0; i < this.writeAccess.length; i++) {
      if (selectedValue === this.writeAccess[i]) {
        this.buttonEnable = true;
      }
    }

    this.refDataSelected = true;
    this.techUnit = '';
    this.selectedTechUnit = '';
    if (e.value === 'xref_chapter_master') {
      this.getTechUnitList();
    }
    this.techUnitSelected = false;
    this.isErrorExists = false;
  }

  getTechUnitList() {
    this.techUnitList = JSON.parse(sessionStorage.getItem('selectedLobts'));
  }

  onPlatformSelection(e) {
    this.selectedPlatform = e.value;
    this.isErrorExists = false;
    this.platformSelected = true;
  }

  onTechUnitSelection(e) {
    this.selectedTechUnit = e.value;
    this.techUnitSelected = true;
    this.isErrorExists = false;
  }

  clickCreateNewTribe() {
    this.isErrorExists = false;
    this.action = 'create';
  }

  clickCreateNewChapter() {
    this.isErrorExists = false;
    this.action = 'create';
  }

  clickCreateNewSubPlatform() {
    this.action = 'create';
  }

  saveMessage(e) {
    this.isErrorExists = this.viewPlatform.isErrorExists;
  }
}
