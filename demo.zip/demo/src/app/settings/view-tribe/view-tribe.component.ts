import { Component, OnInit, Input, OnChanges, ViewChild, AfterViewInit, Output, EventEmitter, ElementRef } from '@angular/core';
import { RestService } from 'src/app/common/service/rest.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatInput } from '@angular/material/input';
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from '@angular/material/sort';
import { DataService } from 'src/app/common/service/data.service';
import { HttpParams } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators, FormArray, AbstractControl } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { RxwebValidators } from '@rxweb/reactive-form-validators';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from 'src/app/common/component/dialogues/confirm-dialog/confirm-dialog-component';

@Component({
  selector: 'app-view-tribe',
  templateUrl: './view-tribe.component.html',
  styleUrls: ['./view-tribe.component.scss']
})


export class ViewTribeComponent implements OnInit, OnChanges, AfterViewInit {
  @Input() selectedPlatform;
  @Input() createTribe;
  actualData: any;
  @Output() editTribe: EventEmitter<any> = new EventEmitter();
  displayedColumns: string[] = ['tribeName', 'tribeCode', 'status', 'leads', 'delegates',
    'action'];
  displayedColumnsForEdit: string[] = ['bizTechInd', 'leadDelegateInd', 'empName', 'oneBankId', 'remove'];
  editAction = false;
  dropDownData = ['Active', 'Inactive'];
  selectedForEdit: any;
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  dataSource1: MatTableDataSource<any> = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatPaginator, { static: false }) editpaginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  tribeForm: FormGroup;
  newList: any;
  wData: any;
  editBizTech: any[];
  temp: any;
  count: boolean = false;
  filteredEmployeeList: Observable<any>;
  employeeList: any;
  totalCount: number;
  isTeamNameExist: boolean = false;
  editable: boolean;
  changedName: any;
  deletedStaff: any = [];
  deleteTemp: any;
  originalData: any;
  hasDuplicateAttr: boolean;
  employeeBusinessList: any;
  hasDuplicateAttr1: boolean = false;
  createAction: boolean = false;
  whitespace: boolean = false;
  originalStatus: any;
  isErrorExists: boolean=false;
  label: string;
  dropdownStaffList: any;
  buttonEnable=false;



  constructor(private restService: RestService, private dataservice: DataService, private fb: FormBuilder, public dialog: MatDialog) {
    this.dataSource = new MatTableDataSource();
    this.dataSource1 = new MatTableDataSource();
    this.restService.track('TRIBE_MANAGEMENT');
  }

  get teamStaffList() {
    return this.tribeForm.get('stakeHolders') as FormArray;
  }

  get t() {
    return this.tribeForm.controls.stakeHolders as FormArray;
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.dataSource1.paginator = this.editpaginator;
  }
  createNewTribe() {
    this.label = 'Create New ';
    this.isErrorExists = false;
    let params1 = new HttpParams()
      .set('platform', this.selectedPlatform)
      .set('staffName', 'a');
    this.restService.get(`/people/data/tribe-masters/employeelist?${params1}`).subscribe(data => {
      this.employeeList = data;
      this.dropdownStaffList = data;
    });

  this.restService.get(`/people/data/tribe-masters/employeebusinesslist?${params1}`).subscribe(data => {
    this.employeeBusinessList = data;
    this.dropdownStaffList=data;
    this.employeeBusinessList.forEach(element => {
      element.oneBankId = element._1BankId;
      delete element._1BankId;
      this.dropdownStaffList=this.employeeBusinessList;
    });
  });
    this.totalCount = 0;
    this.count = false;
    this.editAction = true;
    this.createAction = true;
    this.selectedForEdit = [];
    this.selectedForEdit.platformIndex = this.selectedPlatform;
    this.selectedForEdit.tribeName = '';
    this.selectedForEdit.tribeCode = '';
    this.hasDuplicateAttr = false;
    this.hasDuplicateAttr1 = false;
    this.changedName = this.selectedForEdit.tribeName;
    this.tribeForm = this.fb.group({
      tribeName: [this.selectedForEdit.tribeName, [Validators.required, Validators.maxLength(100)]],
      platformIndex: [{ value: this.selectedForEdit.platformIndex, disabled: true }],
      stakeHolders: this.fb.array([])
    });
    this.actualData = [];
    // this.setStakeholderConfig();
    // this.t.controls.forEach(element => {
    //   const formGroupControl = element as FormGroup;
    //   this.filteredEmployeeList = formGroupControl.controls.staffName.valueChanges.pipe(
    //      startWith(''),
    //     map(staffName => staffName ? this._filterEmployee(staffName) : this.employeeList.slice())
    //   );
    // });
  }

  onEditClickEvent(e) {
    this.dropdownStaffList = [];
    this.label = 'Edit ';
    this.isErrorExists = false;
    let params1 = new HttpParams()
      .set('platform', this.selectedPlatform)
      .set('staffName', 'a');
    this.restService.get(`/people/data/tribe-masters/employeelist?${params1}`).subscribe(data => {
      this.employeeList = data;
    });

    this.restService.get(`/people/data/tribe-masters/employeebusinesslist?${params1}`).subscribe(data => {
      this.employeeBusinessList = data;
      this.employeeBusinessList.forEach(element => {
        element.oneBankId = element._1BankId;
        delete element._1BankId;
      });
    });
    this.createTribe = '';
    this.totalCount = 0;
    this.count = false;
    this.editAction = true;
    this.selectedForEdit = e;
    this.originalStatus = e.status;
    this.hasDuplicateAttr = false;
    this.hasDuplicateAttr1 = false;
    this.changedName = this.selectedForEdit.tribeName;
    this.editTribe.emit('edit');
    this.dataservice.sendMessage(this.editAction);
    let params = new HttpParams()
      .set('platform', this.selectedForEdit.platformIndex)
      .set('tribeName', this.selectedForEdit.tribeName);
    this.restService.get(`/people/data/tribe-masters/by_individual_platform_index?${params}`).subscribe(data => {
      this.originalData = data;
      this.actualData = data;
      // this.dataSource1=new MatTableDataSource();
      // this.dataSource1.data = this.actualData;
      // this.dataSource1.sort = this.sort;
      // this.dataSource1.paginator = this.editpaginator;
      this.tribeForm = this.fb.group({
        tribeName: [this.selectedForEdit.tribeName, [Validators.required, Validators.maxLength(100)]],
        platformIndex: [{ value: this.selectedForEdit.platformIndex, disabled: true }],
        stakeHolders: this.fb.array([])
      });
      this.setStakeholderConfig();
      // this.t.controls.forEach(element => {
      //   const formGroupControl = element as FormGroup;
      //   this.filteredEmployeeList = formGroupControl.controls.staffName.valueChanges.pipe(
      //      startWith(''),
      //     map(staffName => staffName ? this._filterEmployee(staffName) : this.employeeList.slice())
      //   );
      // });


    });

  }

  setStakeholderConfig() {
    let control = <FormArray>this.tribeForm.controls.stakeHolders;
    if (this.selectedForEdit) {
      this.actualData.forEach(x => {
        control.push(this.fb.group({
          disableChecker:['N'],
          createdBy: [x['createdBy']],
          dateCreated: [x['dateCreated']],
          dateModified: [x['dateModified']],
          effectiveEndDate: [x['effectiveEndDate']],
          effectiveStartDate: [x['effectiveStartDate']],
          modifiedBy: [x['modifiedBy']],
          platformIndex: [x['platformIndex']],
          tribeRole: [x['tribeRole'], [Validators.required]],
          count: [this.totalCount],
          tribeLeadId: [x['tribeLeadId']],
          bizTechInd: [x['bizTechInd'], [Validators.required]],
          leadDelegateInd: [x['leadDelegateInd'], [Validators.required]],
          staffName: [x['empName'], [Validators.required, RxwebValidators.unique()]],
          oneBankId: [x['oneBankId'], [Validators.required, , RxwebValidators.unique()]]
        }));
        this.totalCount = this.totalCount + 1;
      });
    }
    this.dataSource1=new MatTableDataSource();
    this.dataSource1.data = control.value;
    this.dataSource1.paginator=this.editpaginator;
  }

  checkBox(element, e, index1) {

    let control = <FormArray>this.tribeForm.controls.stakeHolders;
    if (e.checked == true) {
      let index = this.dataSource1.data.findIndex(temp => temp.count === element.count);
      if (index != -1) {
        this.dataSource1.data[index].leadDelegateInd = 'Y';
        this.dataSource1.data[index].tribeRole = 'Lead Delegate';
        ((this.tribeForm.get('stakeHolders') as FormArray).at(index1) as FormGroup).get('leadDelegateInd').patchValue('Y');
        ((this.tribeForm.get('stakeHolders') as FormArray).at(index1) as FormGroup).get('tribeRole').patchValue('Lead Delegate');
        this.actualData = this.dataSource1.data;
      }
    } else {
      let index = this.dataSource1.data.findIndex(temp => temp.count === element.count);
      if (index != -1) {
        this.dataSource1.data[index].leadDelegateInd = 'N';
        this.dataSource1.data[index].tribeRole = 'Lead';
        ((this.tribeForm.get('stakeHolders') as FormArray).at(index1) as FormGroup).get('leadDelegateInd').patchValue('N');
        ((this.tribeForm.get('stakeHolders') as FormArray).at(index1) as FormGroup).get('tribeRole').patchValue('Lead');
        this.actualData = this.dataSource1.data;
      }
    }
    if (control.value[index1].createdBy !== 'NEW') {
      let i = this.originalData.findIndex(ele => ele.oneBankId === control.value[index1].oneBankId);
      if (i != -1) {
        this.originalData[i].leadDelegateInd = control.value[index1].leadDelegateInd;
        this.originalData[i].tribeRole = control.value[index1].tribeRole;
      }
    }
  }

  checkTeamNameExist(tribeName) {
    this.isTeamNameExist = false;
    if (tribeName === this.selectedForEdit.tribeName) {
      this.isTeamNameExist = false;
    } else {
      let params = new HttpParams()
        .set('platform', this.selectedForEdit.platformIndex)
        .set('tribeName', tribeName);
      this.restService.get(`people/data/tribe-masters/name?${params}`).subscribe(data => {
        this.isTeamNameExist = data;
        if (!data) {
          this.changedName = tribeName;
        }
      });
    }
  }

  deleteStaff(index, ele) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Delete Lead/Delegate?',
        body: 'Do you want to proceed with deletion of selected Lead/Delegate?',
        note: 'Do you want to proceed?',
        button1: 'Cancel',
        button2: 'OK'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        let bank = ele.oneBankId;
        if (ele.tribeLeadId !== '') {
          let i = this.originalData.findIndex(temp => temp.oneBankId === bank);
          if (i != -1) {
            this.originalData[i].effectiveEndDate = new Date();
          }
        }
        let control = <FormArray> this.tribeForm.controls.stakeHolders;
        if (control) {
          ((this.tribeForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('effectiveEndDate').patchValue(new Date());
          this.actualData = control.value;
          if (index < control.value.length - 1) {
            for (var ind = index; ind < control.value.length - 1; ind++) {
              ((this.tribeForm.get('stakeHolders') as FormArray).at(ind + 1) as FormGroup).get('count').patchValue(ind);
            }
          }
          control.removeAt(index);
        }
        this.totalCount = control.value.length;
        this.actualData = this.tribeForm.controls.stakeHolders.value;
        this.dataSource1.data = this.actualData;
        this.dataSource1.paginator = this.editpaginator;
      }
    });
  }

  Onclick(element, index, event) {
    let a = event.target.value;
    if (event.target.value == '') {
      a = 'a';
    }
    let params1 = new HttpParams()
      .set('platform', this.selectedPlatform)
      .set('staffName', a);
    this.restService.get(`/people/data/tribe-masters/employeelist?${params1}`).subscribe(data => {
      this.employeeList = data;
    });
    this.restService.get(`/people/data/tribe-masters/employeebusinesslist?${params1}`).subscribe(data => {
      this.employeeBusinessList = data;
      this.employeeBusinessList.forEach(element => {
        element.oneBankId = element._1BankId;
        delete element._1BankId;
      });
    });
    if (element.bizTechInd == 'Technology') {
      this.filteredEmployeeList = ((this.tribeForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('staffName').valueChanges.pipe(
        startWith(''),
        map(staffName => staffName ? this._filterEmployee(staffName) : this.employeeList.slice())
      );
    } else if (element.bizTechInd == 'Business') {
      this.filteredEmployeeList = ((this.tribeForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('staffName').valueChanges.pipe(
        startWith(''),
        map(staffName => staffName ? this._filterBusinessEmployee(staffName) : this.employeeBusinessList.slice())
      );

    }


  }

  addStaff() {

    let control = <FormArray> this.tribeForm.controls.stakeHolders;
    control.push(this.fb.group({
      disableChecker: ['N'],
      count: [this.totalCount],
      createdBy: ['NEW'],
      dateCreated: [''],
      dateModified: [''],
      effectiveEndDate: [''],
      effectiveStartDate: [''],
      modifiedBy: [''],
      platformIndex: [this.selectedForEdit.platformIndex],
      tribeRole: ['Lead', [Validators.required]],
      tribeLeadId: [''],
      bizTechInd: [this.editBizTech[0].value, [Validators.required]],
      leadDelegateInd: ['N', [Validators.required]],
      staffName: ['', [Validators.required, RxwebValidators.unique()]],
      oneBankId: ['', [Validators.required, RxwebValidators.unique()]]
    }));

    this.totalCount = this.totalCount + 1;
    this.actualData = control.value;
    this.dataSource1.data = this.actualData;
    this.dataSource1.paginator = this.editpaginator;

    let params1 = new HttpParams()
      .set('platform', this.selectedPlatform)
      .set('staffName', 'a');
    this.restService.get(`/people/data/tribe-masters/employeebusinesslist?${params1}`).subscribe(data => {
      this.employeeBusinessList = data;
      this.dropdownStaffList = data;
      this.employeeBusinessList.forEach(element => {
        element.oneBankId = element._1BankId;
        delete element._1BankId;
        this.dropdownStaffList = this.employeeBusinessList;
      });
    });

  }

  goback() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Confirmation',
        body: 'You are in edit mode of this page, if you navigate away from this page without saving changes, your changes will be lost.',
        note: 'Do you want to proceed?',
        button1: 'Cancel',
        button2: 'OK'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.settingForView();
      }
    });
  }

  ngOnInit() {
    this.editAction = false;
    this.restService.get(`/people/data/dataSummary/dataValues/stakeHolder`).subscribe(biz => {
      this.editBizTech = [];
      this.temp = biz;
      this.temp.forEach(element => {
        this.editBizTech.push({'value': element.value, 'display': element.value});
      });
    });

  }

  checkDuplicateAttrName() {
    this.hasDuplicateAttr = false;
    if (this.tribeForm) {
      let control = this.tribeForm.controls.stakeHolders as FormArray;
      this.actualData = control.value;
      this.actualData.map(v => v.staffName).sort().sort((a, b) => {
        if (a.toLowerCase() === b.toLowerCase()) {
          this.hasDuplicateAttr = true;
        }
      });
    }
  }

  // Added to reflect changes when parent changes.
  ngOnChanges(): void {
    this.buttonEnable = false;
    this.editAction = false;
    if (this.createTribe != 'create') {
      this.restService.get(`/people/data/tribe-masters/by_platform_index?platform=${this.selectedPlatform}`).subscribe(data => {
        this.wData = data;
        this.dataSource.data = data;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      });
    }
    if (this.createTribe == 'create') {
      this.editAction = true;
      this.count = false;
      this.createAction = true;
      this.createNewTribe();
    }
    let writeAccess = JSON.parse(localStorage.getItem('writeAccess'));
    for (var i = 0; i < writeAccess.length; i++) {
      if ('Tribe Setup' === writeAccess[i]) {
        this.buttonEnable = true;
      }
    }
    // this.dataSource.data = [{}]
  }

  selected(event, index) {
    this.hasDuplicateAttr1 = false;
    this.checkDuplicateAttrName();
    let tempList;
    const control = <FormArray> this.tribeForm.controls.stakeHolders;
    if (control.value[index].bizTechInd == 'Technology') {
      tempList = this.employeeList;
    } else {
      tempList = this.employeeBusinessList;
    }
    for (let one of tempList) {
      if (one.staffName === event.option.value) {
        this.dataSource1.data[index].oneBankId = one.oneBankId;
        ((this.tribeForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('oneBankId').patchValue(one.oneBankId);
        ((this.tribeForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('disableChecker').patchValue('Y');
        this.actualData = control.value;
        this.dataSource1.data = this.actualData;
        break;
      }
    }

    if (this.originalData && this.originalData.length > 0 && !this.hasDuplicateAttr && control.value[index].createdBy === 'NEW') {
      let i = this.originalData.findIndex(ele => ele.oneBankId === control.value[index].oneBankId);
      if (i != -1 && this.originalData[i].effectiveEndDate != null) {
        this.originalData[i].effectiveEndDate = null;
        this.originalData[i].bizTechInd = control.value[index].bizTechInd;
        this.originalData[i].leadDelegateInd = control.value[index].leadDelegateInd;
        this.originalData[i].tribeRole = control.value[index].tribeRole;
        ((this.tribeForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('createdBy').patchValue('');
        console.log('dsdfsd');
        this.actualData = control.value;
      }
    }
  }

  staffNametypeOption(event, element) {
    this.checkDuplicateAttrName();
    let a = event.target.value;
    if (event.target.value == '') {
      a = 'a';
    }
    let params1 = new HttpParams()
      .set('platform', this.selectedPlatform)
      .set('staffName', a);
    if (element.bizTechInd == 'Technology') {
      this.restService.get(`/people/data/tribe-masters/employeelist?${params1}`).subscribe(data => {
        this.employeeList = data;
        this.dropdownStaffList = data;
      });
    } else {
      this.restService.get(`/people/data/tribe-masters/employeebusinesslist?${params1}`).subscribe(data => {
        this.employeeBusinessList = data;
        this.dropdownStaffList = this.employeeBusinessList;
        this.employeeBusinessList.forEach(element => {
          element.oneBankId = element._1BankId;
          delete element._1BankId;
          this.dropdownStaffList = this.employeeBusinessList;
        });
      });
    }

    this.hasDuplicateAttr1 = false;
    if ((element.bizTechInd === 'Technology') && (-1 == this.employeeList.findIndex(ele => ele.staffName === event.target.value))) {
      this.hasDuplicateAttr1 = true;
    } else if (element.bizTechInd === 'Business' && element.createdBy !== 'NEW') {
      let i = this.originalData.findIndex(ele => ele.tribeLeadId === element.tribeLeadId);
      if (i != -1) {
        this.originalData[i].empName = event.target.value;
      }
    }
  }

  oneBankIdtypeOption(event, element) {
    this.whitespace = false;
    if (/\s/.test(event.target.value)) {
      this.whitespace = true;
    } else if (element.bizTechInd === 'Business' && element.createdBy !== 'NEW') {
      let i = this.originalData.findIndex(ele => ele.tribeLeadId === element.tribeLeadId);
      if (i != -1) {
        this.originalData[i].oneBankId = event.target.value;
      }
    }
  }

  onchange(e, index) {
    let control = <FormArray> this.tribeForm.controls.stakeHolders;
    if (e.value === 'Business') {
      this.dataSource1.data[index].bizTechInd = 'Business';
      this.editable = true;
      // ((this.tribeForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('staffName').patchValue("");
      // ((this.tribeForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('oneBankId').patchValue("");
      // this.dataSource1.data=control.value;
    } else {
      this.dataSource1.data[index].bizTechInd = 'Technology';
      this.editable = false;
    }
    this.actualData = control.value;
    if (control.value[index].createdBy !== 'NEW') {
      let i = this.originalData.findIndex(ele => ele.oneBankId === control.value[index].oneBankId);
      if (i != -1) {
        this.originalData[i].bizTechInd = control.value[index].bizTechInd;
      }
    }

    this.dataSource1._updateChangeSubscription();

  }

  save() {
    let temp = this.selectedForEdit.tribeName;
    this.selectedForEdit.tribeName = this.changedName;
    this.tribeForm.get('tribeName').patchValue(this.changedName);
    const controls = this.tribeForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        this.tribeForm.controls[name].markAsTouched();
      }
    }
    if (this.tribeForm.invalid) {
      this.tribeForm.markAllAsTouched();
    } else if (this.tribeForm.valid) {
      const controlAttr = <FormArray> this.tribeForm.controls.stakeHolders;
      this.actualData = controlAttr.value;
      this.actualData = this.actualData.filter(element => element.createdBy === 'NEW');
      this.actualData.forEach(temp => {
        if (temp.count) {
          delete temp.count;
        }
        temp.empName = temp.staffName;
        delete temp.staffName;
      });

      if (this.createAction) {
        let dataObject = {
          'newList': this.actualData,
          'tribeName': this.changedName,
          'platformIndex': this.selectedPlatform
        };
        this.dataservice.loaderHandler(true);
        this.restService.post(`/people/data/tribe-masters/tribes`, dataObject).subscribe(data => {
          this.isErrorExists = true;
          this.dataservice.getCustomMessage(data['message']);
          this.dataservice.getFlag(data['errorFlag']);
          this.settingForView();
        });
      } else if (this.selectedForEdit.status == 'Inactive' && this.originalStatus == 'Active') {

        const dialogRef = this.dialog.open(ConfirmDialogComponent, {
          data: {
            header: 'Set to Inactive?',
            body: 'Your request to set selected Tribe to "Inactive" will result in associated Tribe to be no longer Active.',
            note: 'Do you want to proceed?',
            button1: 'Cancel',
            button2: 'Set Inactive'
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result === 'yes') {
            let dataObject = {
              'tribeMaster': this.selectedForEdit,
              'updatedList': this.originalData,
              'newList': this.actualData,
              'tribeName': temp
            };
            this.dataservice.loaderHandler(true);
            this.restService.put(`/people/data/tribe-masters/tribe/${this.selectedForEdit.tribeCode}`, dataObject).subscribe(data => {
              this.isErrorExists = true;
              this.dataservice.getCustomMessage(data['message']);
              this.dataservice.getFlag(data['errorFlag']);
              this.settingForView();
            });
          }
        });
      } else {
        let dataObject = {
          'tribeMaster': this.selectedForEdit,
          'updatedList': this.originalData,
          'newList': this.actualData,
          'tribeName': temp
        };
        this.dataservice.loaderHandler(true);
        this.restService.put(`/people/data/tribe-masters/tribe/${this.selectedForEdit.tribeCode}`, dataObject).subscribe(data => {
          this.isErrorExists = true;
          this.dataservice.getCustomMessage(data['message']);
          this.dataservice.getFlag(data['errorFlag']);
          this.settingForView();
        });
      }
    }
  }

  validateoneBankId(control: AbstractControl) {
    let validEmail: boolean = false;
    this.whitespace = false;
    if (/\s/.test(control.value.oneBankId)) {
      this.whitespace = true;
    }
    if (this.whitespace) {
      return ({'validateoneBankId': this.whitespace});
    } else {
      return ({'validateoneBankId': false});
    }
  }

  checkForReadStatus(e) {
    return e.tribeLeadId > 0 ? true : false;
  }

  private settingForView() {
    this.count = true;
    if ((this.editAction || this.createAction) && this.count) {
      this.restService.get(`/people/data/tribe-masters/by_platform_index?platform=${this.selectedPlatform}`).subscribe(data => {

        this.dataSource.data = data;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.editAction = false;
        this.createAction = false;
        this.createTribe = '';

        this.dataservice.loaderHandler(false);
      });
      this.editAction = false;
      this.createAction = false;
    }
    this.editTribe.emit(this.selectedForEdit);
  }

  private _filterEmployee(value: string) {
    const filterValue = value.toLowerCase();
    return this.employeeList.filter(employee => employee.staffName.toLowerCase().indexOf(filterValue) === 0);
  }

  private _filterBusinessEmployee(value: string) {
    const filterValue = value.toLowerCase();
    return this.employeeBusinessList.filter(employee => employee.staffName.toLowerCase().indexOf(filterValue) === 0);
  }

}
