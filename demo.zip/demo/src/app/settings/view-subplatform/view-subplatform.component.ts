import { Component, OnInit, Input, OnChanges, ViewChild, AfterViewInit, Output, EventEmitter, ElementRef } from '@angular/core';
import { RestService } from 'src/app/common/service/rest.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from '@angular/material/sort';
import { DataService } from 'src/app/common/service/data.service';
import { HttpParams } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators, FormArray, AbstractControl } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { RxwebValidators } from '@rxweb/reactive-form-validators';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from 'src/app/common/component/dialogues/confirm-dialog/confirm-dialog-component';

@Component({
  selector: 'app-view-subplatform',
  templateUrl: './view-subplatform.component.html',
  styleUrls: ['./view-subplatform.component.scss']
})

export class ViewSubPlatformComponent implements OnInit, OnChanges, AfterViewInit {
  @Input() selectedPlatform;
  @Input() createSubPlatform;
  actualData: any;
  @Output() editSubPlatform: EventEmitter<any> = new EventEmitter();
  displayedColumns: string[] = ['subPlatformName', 'subPlatformCode', 'status', 'leads', 'delegates',
    'action'];
  displayedColumnsForEdit: string[] = ['bizTechInd', 'leadDelegateInd', 'empName', 'oneBankId', 'remove']
  editAction = false;
  dropDownData = ['Active', 'Inactive']
  selectedForEdit: any;
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  dataSource1: MatTableDataSource<any> = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatPaginator, { static: false }) editpaginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  subPlatformForm: FormGroup;
  newList: any;
  wData: any;
  editBizTech: any[];
  temp: any;
  count: boolean = false;
  filteredEmployeeList: Observable<any>;
  employeeList: any;
  totalCount: number;
  isTeamNameExist: boolean = false;
  editable: boolean;
  changedName: any;
  deletedStaff: any = [];
  deleteTemp: any;
  originalData: any;
  hasDuplicateAttr: boolean;
  employeeBusinessList: any;
  hasDuplicateAttr1: boolean = false;
  createAction: boolean = false;
  whitespace: boolean = false;
  originalStatus: any;
  isErrorExists: boolean = false;
  label: string;
  dropdownStaffList: any;
  buttonEnable=false;

  constructor(private restService: RestService, private dataservice: DataService, private fb: FormBuilder, public dialog: MatDialog) {
    this.dataSource = new MatTableDataSource();
    this.dataSource1 = new MatTableDataSource();
    this.restService.track('SUB_PLATFORM_MANAGEMENT');
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.dataSource1.paginator = this.editpaginator;
  }

  createNewSubPlatform() {
    this.label = 'Create New '
    this.isErrorExists = false;
    let params1 = new HttpParams()
      .set('platform', this.selectedPlatform)
      .set('staffName', "a");
    this.restService.get(`/people/data/subPlatforms/employeelist?${params1}`).subscribe(data => {
      this.employeeList = data;
      this.dropdownStaffList = data;
    });

    this.restService.get(`/people/data/subPlatforms/employeebusinesslist?${params1}`).subscribe(data => {
      this.employeeBusinessList = data;
      this.dropdownStaffList = data;
      this.employeeBusinessList.forEach(element => {
        element.oneBankId = element._1BankId;
        delete element._1BankId;
        this.dropdownStaffList = this.employeeBusinessList;
      });
    });
    this.totalCount = 0;
    this.count = false;
    this.editAction = true;
    this.createAction = true
    this.selectedForEdit = [];
    this.selectedForEdit.platformIndex = this.selectedPlatform;
    this.selectedForEdit.subPlatformName = '';
    this.selectedForEdit.subPlatformCode = '';
    this.hasDuplicateAttr = false;
    this.hasDuplicateAttr1 = false;
    this.changedName = this.selectedForEdit.subPlatformName;
    this.subPlatformForm = this.fb.group({
      subPlatformName: [this.selectedForEdit.subPlatformName, [Validators.required, Validators.maxLength(100)]],
      platformIndex: [{ value: this.selectedForEdit.platformIndex, disabled: true }],
      stakeHolders: this.fb.array([])
    });
    this.actualData = [];
    // this.setStakeholderConfig();
    // this.t.controls.forEach(element => {
    //   const formGroupControl = element as FormGroup;
    //   this.filteredEmployeeList = formGroupControl.controls.staffName.valueChanges.pipe(
    //      startWith(''),
    //     map(staffName => staffName ? this._filterEmployee(staffName) : this.employeeList.slice())
    //   );
    // });
  }

  onEditClickEvent(e) {
    this.dropdownStaffList = [];
    this.label = 'Edit '
    this.isErrorExists = false;
    let params1 = new HttpParams()
      .set('platform', this.selectedPlatform)
      .set('staffName', "a");
    this.restService.get(`/people/data/subPlatforms/employeelist?${params1}`).subscribe(data => {
      this.employeeList = data
    });

    this.restService.get(`/people/data/subPlatforms/employeebusinesslist?${params1}`).subscribe(data => {
      this.employeeBusinessList = data
      this.employeeBusinessList.forEach(element => {
        element.oneBankId = element._1BankId;
        delete element._1BankId;
      });
    });
    this.createSubPlatform = ''
    this.totalCount = 0;
    this.count = false;
    this.editAction = true;
    this.selectedForEdit = e;
    this.originalStatus = e.status;
    this.hasDuplicateAttr = false;
    this.hasDuplicateAttr1 = false
    this.changedName = this.selectedForEdit.subPlatformName;
    this.editSubPlatform.emit("edit");
    this.dataservice.sendMessage(this.editAction);
    let params = new HttpParams()
      .set('platform', this.selectedForEdit.platformIndex)
      .set('subPlatformName', this.selectedForEdit.subPlatformName);
    this.restService.get(`/people/data/subPlatforms/by_individual_platform_index?${params}`).subscribe(data => {
      this.originalData = data;
      this.actualData = data;
      // this.dataSource1=new MatTableDataSource();
      // this.dataSource1.data = this.actualData;
      // this.dataSource1.sort = this.sort;
      // this.dataSource1.paginator = this.editpaginator;
      this.subPlatformForm = this.fb.group({
        subPlatformName: [this.selectedForEdit.subPlatformName, [Validators.required, Validators.maxLength(100)]],
        platformIndex: [{ value: this.selectedForEdit.platformIndex, disabled: true }],
        stakeHolders: this.fb.array([])
      });
      this.setStakeholderConfig();
      // this.t.controls.forEach(element => {
      //   const formGroupControl = element as FormGroup;
      //   this.filteredEmployeeList = formGroupControl.controls.staffName.valueChanges.pipe(
      //      startWith(''),
      //     map(staffName => staffName ? this._filterEmployee(staffName) : this.employeeList.slice())
      //   );
      // });
    });
  }
  setStakeholderConfig() {
    let control = <FormArray>this.subPlatformForm.controls.stakeHolders;
    if (this.selectedForEdit) {
      this.actualData.forEach(x => {
        control.push(this.fb.group({
          disableChecker: ['N'],
          createdBy: [x['createdBy']],
          dateCreated: [x['dateCreated']],
          dateModified: [x['dateModified']],
          effectiveEndDate: [x['effectiveEndDate']],
          effectiveStartDate: [x['effectiveStartDate']],
          modifiedBy: [x['modifiedBy']],
          platformIndex: [x['platformIndex']],
          subPlatformRole: [x['subPlatformRole'], [Validators.required]],
          count: [this.totalCount],
          subPlatformLeadId: [x['subPlatformLeadId']],
          bizTechInd: [x['bizTechInd'], [Validators.required]],
          leadDelegateInd: [x['leadDelegateInd'], [Validators.required]],
          staffName: [x['empName'], [Validators.required, RxwebValidators.unique()]],
          oneBankId: [x['oneBankId'], [Validators.required, , RxwebValidators.unique()]]
        }));
        this.totalCount = this.totalCount + 1;
      })
    }
    this.dataSource1 = new MatTableDataSource();
    this.dataSource1.data = control.value;
    this.dataSource1.paginator = this.editpaginator;
  }

  checkBox(element, e, index1) {
    let control = <FormArray>this.subPlatformForm.controls.stakeHolders;
    if (e.checked == true) {
      let index = this.dataSource1.data.findIndex(temp => temp.count === element.count);
      if (index != -1) {
        this.dataSource1.data[index].leadDelegateInd = 'Y';
        this.dataSource1.data[index].subPlatformRole = 'Lead Delegate';
        ((this.subPlatformForm.get('stakeHolders') as FormArray).at(index1) as FormGroup).get('leadDelegateInd').patchValue('Y');
        ((this.subPlatformForm.get('stakeHolders') as FormArray).at(index1) as FormGroup).get('subPlatformRole').patchValue('Lead Delegate');
        this.actualData = this.dataSource1.data;
      }
    }
    else {
      let index = this.dataSource1.data.findIndex(temp => temp.count === element.count);
      if (index != -1) {
        this.dataSource1.data[index].leadDelegateInd = 'N';
        this.dataSource1.data[index].subPlatformRole = 'Lead';
        ((this.subPlatformForm.get('stakeHolders') as FormArray).at(index1) as FormGroup).get('leadDelegateInd').patchValue('N');
        ((this.subPlatformForm.get('stakeHolders') as FormArray).at(index1) as FormGroup).get('subPlatformRole').patchValue('Lead');
        this.actualData = this.dataSource1.data;
      }
    }
    if (control.value[index1].createdBy !== 'NEW') {
      let i = this.originalData.findIndex(ele => ele.oneBankId === control.value[index1].oneBankId)
      if (i != -1) {
        this.originalData[i].leadDelegateInd = control.value[index1].leadDelegateInd;
        this.originalData[i].subPlatformRole = control.value[index1].subPlatformRole;
      }
    }
  }
  get teamStaffList() {
    return this.subPlatformForm.get('stakeHolders') as FormArray;
  }
  checkTeamNameExist(subPlatformName) {
    this.isTeamNameExist = false;
    if (subPlatformName === this.selectedForEdit.subPlatformName) {
      this.isTeamNameExist = false;
    } else {
      let params = new HttpParams()
        .set('platform', this.selectedForEdit.platformIndex)
        .set('subPlatformName', subPlatformName);
      this.restService.get(`people/data/subPlatforms/name?${params}`).subscribe(data => {
        this.isTeamNameExist = data;
        if (!data)
          this.changedName = subPlatformName;
      });
    }
  }
  deleteStaff(index, ele) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Delete Lead/Delegate?',
        body: 'Do you want to proceed with deletion of selected Lead/Delegate?',
        note: 'Do you want to proceed?',
        button1: 'Cancel',
        button2: 'OK'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        let bank = ele.oneBankId
        if (ele.subPlatformLeadId !== '') {
          let i = this.originalData.findIndex(temp => temp.oneBankId === bank)
          if (i != -1) {
            this.originalData[i].effectiveEndDate = new Date();
          }
        }
        let control = <FormArray>this.subPlatformForm.controls.stakeHolders;
        if (control) {
          ((this.subPlatformForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('effectiveEndDate').patchValue(new Date())
          this.actualData = control.value;
          if (index < control.value.length - 1) {
            for (var ind = index; ind < control.value.length - 1; ind++) {
              ((this.subPlatformForm.get('stakeHolders') as FormArray).at(ind + 1) as FormGroup).get('count').patchValue(ind);
            }
          }
          control.removeAt(index)
        }
        this.totalCount = control.value.length;
        this.actualData = this.subPlatformForm.controls.stakeHolders.value;
        this.dataSource1.data = this.actualData;
        this.dataSource1.paginator = this.editpaginator;
      }
    });
  }
  Onclick(element, index, event) {
    let a = event.target.value;
    if (event.target.value == '') {
      a = "a"
    }
    let params1 = new HttpParams()
      .set('platform', this.selectedPlatform)
      .set('staffName', a);
    this.restService.get(`/people/data/subPlatforms/employeelist?${params1}`).subscribe(data => {
      this.employeeList = data;
    });
    this.restService.get(`/people/data/subPlatforms/employeebusinesslist?${params1}`).subscribe(data => {
      this.employeeBusinessList = data
      this.employeeBusinessList.forEach(element => {
        element.oneBankId = element._1BankId;
        delete element._1BankId;
      });
    });
    if (element.bizTechInd == 'Technology') {
      this.filteredEmployeeList = ((this.subPlatformForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('staffName').valueChanges.pipe(
        startWith(''),
        map(staffName => staffName ? this._filterEmployee(staffName) : this.employeeList.slice())
      );
    }
    else if (element.bizTechInd == 'Business') {
      this.filteredEmployeeList = ((this.subPlatformForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('staffName').valueChanges.pipe(
        startWith(''),
        map(staffName => staffName ? this._filterBusinessEmployee(staffName) : this.employeeBusinessList.slice())
      );

    }


  }

  addStaff() {

    let control = <FormArray>this.subPlatformForm.controls.stakeHolders;
    control.push(this.fb.group({
      disableChecker: ['N'],
      count: [this.totalCount],
      createdBy: ['NEW'],
      dateCreated: [''],
      dateModified: [''],
      effectiveEndDate: [''],
      effectiveStartDate: [''],
      modifiedBy: [''],
      platformIndex: [this.selectedForEdit.platformIndex],
      subPlatformRole: ['Lead', [Validators.required]],
      subPlatformLeadId: [''],
      bizTechInd: [this.editBizTech[0].value, [Validators.required]],
      leadDelegateInd: ['N', [Validators.required]],
      staffName: ['', [Validators.required, RxwebValidators.unique()]],
      oneBankId: ['', [Validators.required, RxwebValidators.unique()]]
    }))

    this.totalCount = this.totalCount + 1;
    this.actualData = control.value;
    this.dataSource1.data = this.actualData;
    this.dataSource1.paginator = this.editpaginator;

    let params1 = new HttpParams()
      .set('platform', this.selectedPlatform)
      .set('staffName', "a");
    this.restService.get(`/people/data/subPlatforms/employeebusinesslist?${params1}`).subscribe(data => {
      this.employeeBusinessList = data
      this.dropdownStaffList = data;
      this.employeeBusinessList.forEach(element => {
        element.oneBankId = element._1BankId;
        delete element._1BankId;
        this.dropdownStaffList = this.employeeBusinessList;
      });
    });

  }

  goback() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Confirmation',
        body: 'You are in edit mode of this page, if you navigate away from this page without saving changes, your changes will be lost.',
        note: 'Do you want to proceed?',
        button1: 'Cancel',
        button2: 'OK'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.settingForView();
      }
    });
  }
  private settingForView() {
    this.count = true
    if ((this.editAction || this.createAction) && this.count) {
      this.restService.get(`/people/data/subPlatforms/by_platform_index?platform=${this.selectedPlatform}`).subscribe(data => {
        this.dataSource.data = data;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.editAction = false;
        this.createAction = false;
        this.createSubPlatform = '';

        this.dataservice.loaderHandler(false)
      });
      this.editAction = false;
      this.createAction = false;
    }
    this.editSubPlatform.emit(this.selectedForEdit);
  }


  ngOnInit() {
    this.editAction = false;
    this.restService.get(`/people/data/dataSummary/dataValues/stakeHolder`).subscribe(biz => {
      this.editBizTech = [];
      this.temp = biz;
      this.temp.forEach(element => {
        this.editBizTech.push({ 'value': element.value, 'display': element.value });
      });
    });
}
  private _filterEmployee(value: string) {
    const filterValue = value.toLowerCase();
    return this.employeeList.filter(employee => employee.staffName.toLowerCase().indexOf(filterValue) === 0);
  }
  private _filterBusinessEmployee(value: string) {
    const filterValue = value.toLowerCase();
    return this.employeeBusinessList.filter(employee => employee.staffName.toLowerCase().indexOf(filterValue) === 0);
  }
  get t() {
    return this.subPlatformForm.controls.stakeHolders as FormArray;
  }

  checkDuplicateAttrName() {
    this.hasDuplicateAttr = false;
    if (this.subPlatformForm) {
      let control = this.subPlatformForm.controls.stakeHolders as FormArray;
      this.actualData = control.value;
      this.actualData.map(v => v.staffName).sort().sort((a, b) => {
        if (a.toLowerCase() === b.toLowerCase()) {
          this.hasDuplicateAttr = true;
        }
      })
    }
  }

  // Added to reflect changes when parent changes.
  ngOnChanges(): void {
    this.buttonEnable=false;
    this.editAction = false;
    if (this.createSubPlatform != 'create') {
      this.restService.get(`/people/data/subPlatforms/by_platform_index?platform=${this.selectedPlatform}`).subscribe(data => {
        this.wData = data
        this.dataSource.data = data;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      });
    }
    if (this.createSubPlatform == 'create') {
      this.editAction = true
      this.count = false;
      this.createAction = true
      this.createNewSubPlatform();
    }
    let writeAccess = JSON.parse(localStorage.getItem('writeAccess'));
    for(var i=0;i<writeAccess.length;i++){
      if("Sub-Platform Setup" === writeAccess[i]){
        this.buttonEnable=true;
      }
    }
    // this.dataSource.data = [{}]
  }

  selected(event, index) {
    this.hasDuplicateAttr1 = false;
    this.checkDuplicateAttrName();
    let tempList;
    const control = <FormArray>this.subPlatformForm.controls.stakeHolders;
    if (control.value[index].bizTechInd == 'Technology') {
      tempList = this.employeeList;
    }
    else {
      tempList = this.employeeBusinessList;
    }
    for (let one of tempList) {
      if (one.staffName === event.option.value) {
        this.dataSource1.data[index].oneBankId = one.oneBankId;
        ((this.subPlatformForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('oneBankId').patchValue(one.oneBankId);
        ((this.subPlatformForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('disableChecker').patchValue('Y');
        this.actualData = control.value;
        this.dataSource1.data = this.actualData;
        break;
      }
    }

    if (this.originalData && this.originalData.length > 0 && !this.hasDuplicateAttr && control.value[index].createdBy === 'NEW') {
      let i = this.originalData.findIndex(ele => ele.oneBankId === control.value[index].oneBankId)
      if (i != -1 && this.originalData[i].effectiveEndDate != null) {
        this.originalData[i].effectiveEndDate = null;
        this.originalData[i].bizTechInd = control.value[index].bizTechInd;
        this.originalData[i].leadDelegateInd = control.value[index].leadDelegateInd;
        this.originalData[i].subPlatformRole = control.value[index].subPlatformRole;
        ((this.subPlatformForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('createdBy').patchValue('');
        this.actualData = control.value;
      }
    }
  }
  staffNametypeOption(event, element) {
    this.checkDuplicateAttrName();
    let a = event.target.value
    if (event.target.value == '') {
      a = "a"
    }
    let params1 = new HttpParams()
      .set('platform', this.selectedPlatform)
      .set('staffName', a);
    if (element.bizTechInd == 'Technology') {
      this.restService.get(`/people/data/subPlatforms/employeelist?${params1}`).subscribe(data => {
        this.employeeList = data;
        this.dropdownStaffList = data;
      });
    } else {
      this.restService.get(`/people/data/subPlatforms/employeebusinesslist?${params1}`).subscribe(data => {
        this.employeeBusinessList = data
        this.dropdownStaffList = this.employeeBusinessList;
        this.employeeBusinessList.forEach(element => {
          element.oneBankId = element._1BankId;
          delete element._1BankId;
          this.dropdownStaffList = this.employeeBusinessList;
        });
      });
    }

    this.hasDuplicateAttr1 = false;
    if ((element.bizTechInd === 'Technology') && (-1 == this.employeeList.findIndex(ele => ele.staffName === event.target.value))) {
      this.hasDuplicateAttr1 = true
    }
    else if (element.bizTechInd === 'Business' && element.createdBy !== 'NEW') {
      let i = this.originalData.findIndex(ele => ele.subPlatformLeadId === element.subPlatformLeadId)
      if (i != -1) {
        this.originalData[i].empName = event.target.value;
      }
    }
  }
  oneBankIdtypeOption(event, element) {
    this.whitespace = false;
    if (/\s/.test(event.target.value)) {
      this.whitespace = true;
    }

    else if (element.bizTechInd === 'Business' && element.createdBy !== 'NEW') {
      let i = this.originalData.findIndex(ele => ele.subPlatformLeadId === element.subPlatformLeadId)
      if (i != -1) {
        this.originalData[i].oneBankId = event.target.value;
      }
    }
  }
  onchange(e, index) {
    let control = <FormArray>this.subPlatformForm.controls.stakeHolders;
    if (e.value === 'Business') {
      this.dataSource1.data[index].bizTechInd = 'Business'
      this.editable = true;
      // ((this.subPlatformForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('staffName').patchValue("");
      // ((this.subPlatformForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('oneBankId').patchValue("");
      // this.dataSource1.data=control.value;
    }
    else {
      this.dataSource1.data[index].bizTechInd = 'Technology'
      this.editable = false;
    }
    this.actualData = control.value;
    if (control.value[index].createdBy !== 'NEW') {
      let i = this.originalData.findIndex(ele => ele.oneBankId === control.value[index].oneBankId)
      if (i != -1) {
        this.originalData[i].bizTechInd = control.value[index].bizTechInd;
      }
    }

    this.dataSource1._updateChangeSubscription();

  }
  save() {
    let temp = this.selectedForEdit.subPlatformName;
    this.selectedForEdit.subPlatformName = this.changedName;
    this.subPlatformForm.get('subPlatformName').patchValue(this.changedName);
    const controls = this.subPlatformForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        this.subPlatformForm.controls[name].markAsTouched();
      }
    }
    if (this.subPlatformForm.invalid) {
      this.subPlatformForm.markAllAsTouched();
    } else
      if (this.subPlatformForm.valid) {
        const controlAttr = <FormArray>this.subPlatformForm.controls.stakeHolders;
        this.actualData = controlAttr.value;
        this.actualData = this.actualData.filter(element => element.createdBy === "NEW");
        this.actualData.forEach(temp => {
          if (temp.count) {
            delete temp.count;
          }
          temp.empName = temp.staffName;
          delete temp.staffName;
        });

        if (this.createAction) {
          let dataObject = {
            'newList': this.actualData,
            'subPlatformName': this.changedName,
            'platformIndex': this.selectedPlatform
          };
          this.dataservice.loaderHandler(true);
          this.restService.post(`/people/data/subPlatforms/subplatforms`, dataObject).subscribe(data => {
            this.isErrorExists = true;
            this.dataservice.getCustomMessage(data['message']);
            this.dataservice.getFlag(data['errorFlag']);
            this.settingForView();
          });
        }
        // if (this.action === 'edit') {
        //   if (this.templateData['status'] === 'inactive' && this.initialData['status'] === 'active') {
        //     const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        //       data: {
        //         header: 'Set to Inactive?',
        //         body: 'Your request to set Email Template to "Inactive" will result in associated Email Trigger Events to be no longer valid.',
        //         note: 'Do you want to proceed?',
        //         button1: 'Cancel',
        //         button2: 'Set Inactive'
        //       }
        //     });
        //     dialogRef.afterClosed().subscribe(result => {
        //       if (result === 'yes') {
        //         this.restService.put(`/mcs/email/template/${this.templateData.emailSurrId}`, dataObject).subscribe(data => {
        //           this.back.emit(true);
        //           this.saveAction.emit(data);
        //         });
        //       }
        //     });
        //   }
        else if (this.selectedForEdit.status == 'Inactive' && (this.originalStatus == 'Active' || this.originalStatus == undefined)) {

          const dialogRef = this.dialog.open(ConfirmDialogComponent, {
            data: {
              header: 'Set to Inactive?',
              body: 'Your request to set selected Sub-Platform to "Inactive" will result in associated Sub-Platform to be no longer Active.',
              note: 'Do you want to proceed?',
              button1: 'Cancel',
              button2: 'Set Inactive'
            }
          });
          dialogRef.afterClosed().subscribe(result => {
            if (result === 'yes') {
              let dataObject = {
                'subPlatformMaster': this.selectedForEdit,
                'updatedList': this.originalData,
                'newList': this.actualData,
                'subPlatformName': temp
              };
              this.dataservice.loaderHandler(true);
              this.restService.put(`/people/data/subPlatforms/subplatform/${this.selectedForEdit.subPlatformCode}`, dataObject).subscribe(data => {
                this.isErrorExists = true;
                this.dataservice.getCustomMessage(data['message']);
                this.dataservice.getFlag(data['errorFlag']);
                this.settingForView();
              });
            }
          });
        }
        else {
          let dataObject = {
            'subPlatformMaster': this.selectedForEdit,
            'updatedList': this.originalData,
            'newList': this.actualData,
            'subPlatformName': temp
          };
          this.dataservice.loaderHandler(true);
          this.restService.put(`/people/data/subPlatforms/subplatform/${this.selectedForEdit.subPlatformCode}`, dataObject).subscribe(data => {
            this.isErrorExists = true;
            this.dataservice.getCustomMessage(data['message']);
            this.dataservice.getFlag(data['errorFlag']);
            this.settingForView();
          });
        }

      }
    // else if (this.action === 'add') {
    //   if (this.templateData['status'] === 'inactive' && this.emailForm.controls.status.touched && this.emailForm.controls.status.dirty) {
    //     const dialogRef = this.dialog.open(ConfirmDialogComponent, {
    //       data: {
    //         header: 'Set to Inactive?',
    //         body: 'Your request to set Email Template to "Inactive" will result in associated Email Trigger Events to be no longer valid.',
    //         note: 'Do you want to proceed?',
    //         button1: 'Cancel',
    //         button2: 'Set Inactive'
    //       }
    //     });
    //     dialogRef.afterClosed().subscribe(result => {
    //       if (result === 'yes') {
    //         this.restService.post(`/mcs/email/template`, dataObject).subscribe(data => {
    //           this.back.emit(true);
    //           this.saveAction.emit(data);
    //         });
    //       }
    //     });
    //   }
    //   else {
    //     this.restService.post(`/mcs/email/template`, dataObject).subscribe(data => {
    //       this.saveAction.emit(data);
    //     });
    //   }
    // }

  }
  validateoneBankId(control: AbstractControl) {
    let validEmail: boolean = false;
    this.whitespace = false;
    if (/\s/.test(control.value.oneBankId)) {
      this.whitespace = true;
    }
    if (this.whitespace) {
      return ({ 'validateoneBankId': this.whitespace });
    } else {
      return ({ 'validateoneBankId': false });
    }
  }

}
