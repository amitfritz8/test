import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {SharedModule} from 'src/app/common/module/shared.module';
import {SettingsComponent} from './settings.component';
import {ViewTribeComponent} from './view-tribe/view-tribe.component';
import {ViewSubPlatformComponent} from './view-subplatform/view-subplatform.component';
import {ChapterSetupComponent} from './chapter-setup/chapter-setup.component';
import {PlatformSetupComponent} from './platform-setup/platform-setup.component';

const routes: Routes = [
  {path: '', component: SettingsComponent},
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
  ],
  declarations: [SettingsComponent, ViewTribeComponent, ChapterSetupComponent, ViewSubPlatformComponent, PlatformSetupComponent],
  exports: [],
  entryComponents: []
})

export class SettingsModule {
}
