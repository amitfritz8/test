// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { NonGenericDataComponent } from './non-generic-data.component';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { MaterialModule } from '../../../material.module';
// import { RestService } from '../../../shared/http/rest-service';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { DebugElement, Component } from '@angular/core';
// import { BrowserModule, By } from '@angular/platform-browser';
// import { MatTableDataSource } from '@angular/material';
// import { MatSort } from '@angular/material/sort';
// import { configureTestSuite } from 'ng-bullet';
// import { EmailTemplateComponent } from './email-template/email-template.component';
// import { DataService } from 'src/app/shared/services/data.service';
// import { of, Subscription, Observable, Subject } from 'rxjs';
// import { ErrorsNotificationComponent } from 'src/app/components/errors-notification/errors-notification.component';
// import { MatDialogRef } from '@angular/material';
// import { RichTextEditorAllModule } from '@syncfusion/ej2-angular-richtexteditor';
// // import { ConfirmDialogComponent } from 'src/app/components/dialogues/confirm-dialog/confirm-dialog-component';

// describe('NonGenericDataComponent', () => {
//     let component: NonGenericDataComponent;
//     let fixture: ComponentFixture<NonGenericDataComponent>;
//     let de: DebugElement;
//     let el: HTMLElement;

//     configureTestSuite(() => {
//         TestBed.configureTestingModule({
//             declarations: [NonGenericDataComponent, EmailTemplateComponent, ErrorsNotificationComponent],
//             imports: [BrowserAnimationsModule,
//                 MaterialModule,
//                 FormsModule,
//                 ReactiveFormsModule,
//                 BrowserModule,
//                 RichTextEditorAllModule],
//             providers: [
//                 { provide: RestService, useClass: MockRestService },
//                 { provide: DataService, useClass: MockDataService },
//                 { provide: Subscription },
//                 { provide: MatDialogRef, useClass: MockMatDialogRef }
//             ]
//         })
//     });

//     beforeEach(() => {
//         fixture = TestBed.createComponent(NonGenericDataComponent);
//         component = fixture.componentInstance;
//         component.isRefDataSelected = false;
//         component.refdataOption = 'xref_platform_master';
//         component.action = 'view';
//         component.stakeHolders = [];
//         component.stakedata = [];
//         component.dataSource = new MatTableDataSource();
//         component.dataSource.sort = new MatSort();
//         component.add = 'false';
//         component.selectedValue = {};
//         fixture.detectChanges();
//         de = fixture.debugElement.query(By.css('.mainDiv'));
//         el = de.nativeElement;
//     });

//     it('should create', () => {
//         expect(component).toBeTruthy();
//     });

//     it(`should have as text ' Non-Generic Ref Data'`, async () => {
//         const fixture = TestBed.createComponent(NonGenericDataComponent);
//         const comp = fixture.debugElement.query(By.css('.headingtext')).nativeElement;
//         expect(comp.innerHTML).toEqual(' Non-Generic Ref Data ');
//     });

//     it(`should have as text ' Ref Data'`, async () => {
//         const fixture = TestBed.createComponent(NonGenericDataComponent);
//         const comp = fixture.debugElement.query(By.css('#refData')).nativeElement;
//         expect(comp.innerHTML).toEqual('Ref Data');
//     });

//     it('should emit new ref data on change event', async(() => {
//         let select = fixture.debugElement.query(By.css('#refDataType')).nativeElement;
//         component.isRefDataSelected = true;
//         select.value = 'platformSetup';
//         component.refdataOption = 'xref_platform_master';
//         fixture.detectChanges();
//         select.dispatchEvent(new Event('change'));
//         fixture.detectChanges();
//         expect(component.refdataOption).toEqual('xref_platform_master');
//     }));

//     it('should emit new platform on change event', async(() => {
//         component.refdataOption = '4';
//         let select = fixture.debugElement.query(By.css('#refDataPlatform')).nativeElement;
//         fixture.detectChanges();
//         select.dispatchEvent(new Event('change'));
//         fixture.detectChanges();
//         component.action = 'view';
//         component.stakedata = [];
//         component.stakeHolders = [{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 335,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA'
//         }, {
//             'createdBy': 'venkateshsoma',
//             'dateCreated': 1572953209000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 353,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Hong Kong',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhigyapranshu',
//             'empName': 'Abhigya PRANSHU'
//         }];
//         component.dataSource.data = component.stakeHolders;
//         component.selectedValue = {
//             'createdBy': null,
//             'dateCreated': null,
//             'modifiedBy': null,
//             'dateModified': null,
//             'platformId': '1',
//             'platformIndex': '01',
//             'platformName': 'CBG Customer Mgt & Analytics',
//             'techunitCode': 'CBGT',
//             'techUnitName': 'Consumer Banking Group Technology',
//             'platformGroup': 'Business Platform',
//             'platformUnit': 'CBG Business Platform',
//             'platformType': 'Platform',
//             'techMd': 'Siew Choo'
//         };
//         expect(component.dataSource.data).toEqual([{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 335,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA'
//         }, {
//             'createdBy': 'venkateshsoma',
//             'dateCreated': 1572953209000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 353,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Hong Kong',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhigyapranshu',
//             'empName': 'Abhigya PRANSHU'
//         }]);
//     }));

//     it('should call the onEditClick method', async(() => {
//         fixture.detectChanges();
//         spyOn(component, 'onEditClick');
//         el = fixture.debugElement.query(By.css('#editBtn')).nativeElement;
//         el.click();
//         component.action = 'edit';
//         expect(component.onEditClick).toHaveBeenCalledTimes(1);
//     }));
//     it('should call the onEditClick method for email template', async(() => {
//         fixture.detectChanges();
//         component.action = 'edit';
//         component.refdataOption = 'xref_email_template';
//         component.onEditClick();
//         expect(component.editCliked).toBe(true);
//     }));

//     it('should call the onPlatformSelection method on click', async(() => {
//         fixture.detectChanges();
//         spyOn(component, 'onPlatformSelection');
//         fixture.debugElement.query(By.css('#refDataPlatform')).triggerEventHandler('selectionChange', { value: { 'platformIndex': '01' } })
//         fixture.detectChanges();
//         component.action = 'edit';
//         component.selectedValue = {
//             'createdBy': null,
//             'dateCreated': null,
//             'modifiedBy': null,
//             'dateModified': null,
//             'platformId': '1',
//             'platformIndex': '01',
//             'platformName': 'CBG Customer Mgt & Analytics',
//             'techunitCode': 'CBGT',
//             'techUnitName': 'Consumer Banking Group Technology',
//             'platformGroup': 'Business Platform',
//             'platformUnit': 'CBG Business Platform',
//             'platformType': 'Platform',
//             'techMd': 'Siew Choo'
//         };
//         expect(component.onPlatformSelection).toHaveBeenCalledTimes(1);
//     }));

//     it('should call the onPlatformSelection method as function', async(() => {
//         let select = fixture.debugElement.query(By.css('#refDataPlatform')).nativeElement;
//         select.value = { 'platformIndex': '01' };
//         select.dispatchEvent(new Event('change'));
//         fixture.detectChanges();
//         fixture.componentInstance.onPlatformSelection({ value: '2' });
//         component.stakeHolders = [{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 335,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA'
//         }, {
//             'createdBy': 'venkateshsoma',
//             'dateCreated': 1572953209000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 353,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Hong Kong',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhigyapranshu',
//             'empName': 'Abhigya PRANSHU'
//         }];
//         component.dataSource.data = component.stakeHolders;
//         expect(select.value).toEqual({ 'platformIndex': '01' });
//     }));

//     it('should call the onRefDataSelection method as function', async(() => {
//         let select = fixture.debugElement.query(By.css('#refData')).nativeElement;
//         select.dispatchEvent(new Event('change'));
//         fixture.detectChanges();
//         fixture.componentInstance.onRefDataSelection({ value: '2' });
//         component.action = 'view';
//         expect(component.action).toEqual('view');
//     }));

//     it('should call the onEditClick method as function', async(() => {
//         let btn = fixture.debugElement.query(By.css('#editBtn')).nativeElement;
//         btn.dispatchEvent(new Event('click'));
//         fixture.detectChanges();
//         fixture.componentInstance.onEditClick();
//         component.action = 'edit';
//         expect(component.action).toEqual('edit');
//     }));

//     it('should call the addAttr method as function', async(() => {
//         component.action = 'edit';
//         fixture.detectChanges();
//         let btn = fixture.debugElement.query(By.css('#addAttrBtn')).nativeElement;
//         btn.dispatchEvent(new Event('click'));
//         fixture.detectChanges();
//         component.editBizTech[0] = { value: '' };
//         component.editcountry[0] = { value: '' };
//         component.editplatformRole[0] = { value: '' };
//         component.selectedValue = { platformIndex: '' };
//         fixture.componentInstance.addAttr();
//         component.add = 'true';
//         expect(component.add).toEqual('true');
//     }));

//     it('should call the onCancelClick method as function', async(() => {
//         component.action = 'edit';
//         fixture.detectChanges();
//         let btn = fixture.debugElement.query(By.css('#cancel')).nativeElement;
//         btn.dispatchEvent(new Event('click'));
//         fixture.detectChanges();
//         fixture.componentInstance.onCancelClick();
//         component.add = 'false';
//         component.action = 'view';
//         expect(component.add).toEqual('false');
//     }));
//     it('should call the onCancelClick method for email template', async(() => {
//         fixture.detectChanges();
//         component.refdataOption = 'xref_email_template';
//         component.onCancelClick();
//         expect(component.cancelCliked).toEqual(true);
//     }));
//     it('should call the save method as function with "" value for platformName', async(() => {
//         component.action = 'edit';
//         fixture.detectChanges();
//         let btn = fixture.debugElement.query(By.css('#saveBtn')).nativeElement;
//         btn.dispatchEvent(new Event('click'));
//         fixture.detectChanges();
//         component.form.controls['platformName'].setValue('');
//         fixture.componentInstance.save();
//         component.add = 'false';
//         component.action = 'view';
//         expect(component.add).toEqual('false');
//     }));

//     it('should call the save method as function for email template', async(() => {
//         component.refdataOption = 'xref_email_template';
//         component.save();
//         expect(component.saveCliked).toEqual(true);
//     }));
//     it('should call the save method as function with valid value of platformName', async(() => {
//         component.action = 'edit';
//         fixture.detectChanges();
//         let btn = fixture.debugElement.query(By.css('#saveBtn')).nativeElement;
//         btn.dispatchEvent(new Event('click'));
//         fixture.detectChanges();
//         component.form.controls['platformName'].setValue('test');
//         fixture.componentInstance.save();
//         component.add = 'false';
//         component.action = 'view';
//         expect(component.add).toEqual('false');
//     }));

//     it('should call the deleteAttr method as function when psId > 0', async(() => {
//         component.action = 'edit';
//         component.stakeHolders = [{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 335,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA',
//             'remove': ''
//         }];
//         component.dataSource.data = component.stakeHolders;
//         fixture.detectChanges();
//         let tableRows = fixture.debugElement.query(By.css('.material-icons')).nativeElement;
//         tableRows.dispatchEvent(new Event('click'));
//         fixture.detectChanges();
//         fixture.componentInstance.deleteAttr(1, { psId: '01' });
//         component.add = 'false';
//         expect(component.add).toEqual('false');
//     }));

//     it('should call the deleteAttr method as function when psId < 0', async(() => {
//         component.action = 'edit';
//         component.stakeHolders = [{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 335,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA',
//             'remove': ''
//         }];
//         component.dataSource.data = component.stakeHolders;
//         fixture.detectChanges();
//         let tableRows = fixture.debugElement.query(By.css('.material-icons')).nativeElement;
//         tableRows.dispatchEvent(new Event('click'));
//         fixture.detectChanges();
//         fixture.componentInstance.deleteAttr(1, { psId: '-1' });
//         component.add = 'false';
//         expect(component.add).toEqual('false');
//     }));

//     it('should call the handleFilter method as function', async(() => {
//         component.action = 'edit';
//         component.stakeHolders = [{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 335,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA'
//         }, {
//             'createdBy': 'venkateshsoma',
//             'dateCreated': 1572953209000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 353,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Hong Kong',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhigyapranshu',
//             'empName': 'Abhigya PRANSHU'
//         }];
//         component.dataSource.data = component.stakeHolders;
//         fixture.detectChanges();
//         fixture.componentInstance.handleFilter('');
//         component.add = 'false';
//         expect(component.add).toEqual('false');
//     }));

//     it('should call the filter method as function', async(() => {
//         component.action = 'edit';
//         component.stakeHolders = [{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 335,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA'
//         }, {
//             'createdBy': 'venkateshsoma',
//             'dateCreated': 1572953209000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 353,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Hong Kong',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhigyapranshu',
//             'empName': 'Abhigya PRANSHU'
//         }];
//         component.dataSource.data = component.stakeHolders;
//         fixture.detectChanges();
//         fixture.componentInstance.sortData('');
//         component.add = 'false';
//         expect(component.add).toEqual('false');
//     }));
//     it('should call the saveActionDone for invalid form', async(() => {
//         component.action = 'edit';
//         component.saveActionDone('invalid form');
//         expect(component.saveCliked).toEqual(false);
//     }));

//     it('should call the saveActionDone for success msg', async(() => {
//         component.action = 'edit';
//         component.saveActionDone({ errorFlag: 0, message: 'test' });
//         expect(component.saveCliked).toEqual(false);
//     }));
//     it('should call the saveActionDone for success msg for add', async(() => {
//         component.action = 'add';
//         component.saveActionDone({ errorFlag: 0, message: 'test' });
//         expect(component.cancelCliked).toEqual(false);
//     }));

//     it('should call the saveActionDone for error msg', async(() => {
//         component.action = 'add';
//         component.saveActionDone({ errorFlag: 1, message: 'test' });
//         expect(component.saveCliked).toEqual(false);
//     }));
//     it('should call the saveActionDone for null response', (done: DoneFn) => {
//         component.action = 'add';
//         component.saveActionDone({ errorFlag: null, message: 'test' });
//         done();
//     });
//     it('should call the onEmailTemplateSelection', async(() => {
//         component.action = 'view';
//         component.onEmailTemplateSelection();
//         expect(component.errorInAdd).toEqual(false);
//     }));
//     it('should call the onAddNewTemplate', async(() => {
//         component.action = 'add';
//         component.onAddNewTemplate();
//         expect(component.errorInAdd).toEqual(false);
//     }));
//     it('should call the OnchangeLead for lead', async(() => {
//         component.dataSource.data = [{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 335,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA'
//         }];
//         component.OnchangeLead({ 'psId': 335, 'uniqueKey': 335 }, { checked: false });
//         expect(component.dataSource.data[0].leadDelegateInd).toEqual('Lead');
//     }));
//     it('should call the OnchangeLead for lead pSId<0', async(() => {
//         component.dataSource.data = [{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 0,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA',
//             'uniqueKey': 335
//         }];
//         component.OnchangeLead({ 'psId': 0, 'uniqueKey': 335 }, { checked: false });
//         expect(component.dataSource.data[0].leadDelegateInd).toEqual('Lead');
//     }));
//     it('should call the OnchangeLead for Delegate ,checked true', async(() => {
//         component.dataSource.data = [{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 335,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA'
//         }];
//         component.OnchangeLead({ 'psId': 335, 'uniqueKey': 335 }, { checked: true });
//         expect(component.dataSource.data[0].leadDelegateInd).toEqual('Delegate');
//     }));
//     it('should call the OnchangeLead for Delegate where psId <0,checked true', async(() => {
//         component.dataSource.data = [{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 0,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA',
//             'uniqueKey': 335
//         }];
//         component.OnchangeLead({ 'psId': 0, 'uniqueKey': 335 }, { checked: true });
//         expect(component.dataSource.data[0].leadDelegateInd).toEqual('Delegate');
//     }));
//     it('should call the onchange', async(() => {
//         component.editStakeName = [{ value: 'test' }]
//         component.dataSource.data = [{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 335,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA',
//             'uniqueKey': 335
//         }];
//         component.onchange({ value: 'test', display: 'abhishek2gupta' }, { 'psId': 335, 'uniqueKey': 335 });
//         expect(component.stakeHolders).toEqual(component.dataSource.data);
//     }));
//     it('should call the onchange for psId<0', async(() => {
//         component.editStakeName = [{ value: 'test' }]
//         component.dataSource.data = [{
//             'createdBy': 'karunakaran',
//             'dateCreated': 1570804544000,
//             'modifiedBy': 'venkateshsoma',
//             'dateModified': 1572953209000,
//             'psId': 0,
//             'platformIndex': '01',
//             'bizTechInd': 'Business',
//             'countryCode': 'Taiwan',
//             'platformRole': 'Department Lead',
//             'leadDelegateInd': 'Lead',
//             'oneBankId': 'abhishek2gupta',
//             'empName': 'Abhishek2 GUPTA',
//             'uniqueKey': 335
//         }];
//         component.onchange({ value: 'test', display: 'abhishek2gupta' }, { 'psId': 0, 'uniqueKey': 335 });
//         expect(component.stakeHolders).toEqual(component.dataSource.data);
//     }));
//     it('should call the getFormCheck', async(() => {
//         component.getFormCheck(null);
//         expect(component.cancelCliked).toEqual(false);
//     }));
// });

// class MockRestService {
//     get() {
//         return of([{ 'platformId': '1', 'platformIndex': '01', 'platform': 'test platform' }]);
//     }

//     put() {
//         return of({});
//     }

//     // post(){
//     //   return of({});
//     // }

//     // delete() {
//     //   return of({});
//     // }
// }
// class MockMatDialogRef {
//     afterClosed() {
//         return of({});
//     }
// }
// class MockDataService {
//     subject: Subject<any>;

//     getCustomMessage() {
//         return 'marissa';
//     }

//     getFlag() {
//         return '201908';
//     }

//     getMessage(): Observable<any> {
//         return new Observable;
//     }
// }