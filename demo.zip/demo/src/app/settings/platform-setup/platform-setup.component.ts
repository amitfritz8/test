import {Component, OnInit, AfterViewInit, ViewChild, EventEmitter, Output, Input, OnChanges} from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import {MatDialog} from '@angular/material/dialog';
import {MatSort} from '@angular/material/sort';
import {RestService} from 'src/app/common/service/rest.service';
import {FormBuilder, FormGroup, Validators, FormControl, FormArray} from '@angular/forms';
import {ConfirmDialogComponent} from 'src/app/common/component/dialogues/confirm-dialog/confirm-dialog-component';
import {DataService} from 'src/app/common/service/data.service';
import {Subscription} from 'rxjs';
import {ImportDialogComponent} from 'src/app/common/component/dialogues/import-dialog/import-dialog-component';
import {map, startWith} from 'rxjs/operators';
import {HttpParams} from '@angular/common/http';
import * as moment from 'moment';
import {DataTableService} from 'src/app/common/service/dataTable.service';

@Component({
  selector: 'app-platform-setup',
  templateUrl: './platform-setup.component.html',
  styleUrls: ['./platform-setup.component.scss'],

})
export class PlatformSetupComponent implements OnInit, OnChanges, AfterViewInit {

  @Input() selectedPlatform1;
  @Output() platformMessage: EventEmitter<any> = new EventEmitter();
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  action: string = '';
  element: any;
  showFilter: boolean = false;
  stakeList: any = [];
  isRefDataSelected: boolean = false;
  refdataOption: string = '';
  selected = 'platformSetup';
  selectedPlatform = null;
  form: FormGroup;
  staff: FormControl;
  dataSummary: any;
  add: string = '';
  data: any = [];
  stakedata: any = [];
  selectedValue = null;
  stakeHolders: any = [];
  checked = true;
  unchecked = false;
  status: any;
  editcountry: any = [];
  editplatformRole: any = [];
  editBizTech: any = [];
  editStakeName: any = [];
  temp: any = [];
  staffName: string;
  StakeHoldersdisplayedColumns = ['bizTechInd', 'countryCode', 'platformRole', 'leadDelegateInd', 'empName', 'oneBankId', 'remove'];
  selectedTemplate = null;
  showAddBtnForTemplate: boolean = false;
  cancelCliked: boolean = false;
  saveCliked: boolean = false;
  isErrorExists: boolean = false;
  subscription: Subscription;
  @Output() back: EventEmitter<boolean> = new EventEmitter();
  isSuccessMsg: boolean = false;
  private deletedList: any = [];
  oneBankIdFilter = new FormControl('');
  empNameFilter = new FormControl('');
  leadDelegateFilter = new FormControl('');
  platformRoleFilter = new FormControl('');
  reportingCountryFilter = new FormControl('');
  bizTechIndFilter = new FormControl('');
  filterValues = {
    bizTechInd: '',
    countryCode: '',
    platformRole: '',
    leadDelegateInd: '',
    empName: '',
    oneBankId: ''
  }
  editable = false;
  private leadDelegate: any = [];
  private filterBizTech: any = [];
  private filterCountry: any = [];
  private filterPlatform: any = [];
  private hasDuplicateAttr: boolean = false;
  buttonEnable: boolean = false;

  constructor(private fb: FormBuilder, private restService: RestService,
              public dialog: MatDialog, private dataService: DataService, private readonly dataTableService: DataTableService) {
    this.restService.track('PLATFORM_SETUP');
    this.dataSource = new MatTableDataSource();
    this.subscription = this.dataService.getMessage().subscribe(message => {
      this.goback();
    });
  }

  ngOnInit() {
    this.action = 'view';
    this.getData();
    this.add = 'false';
    this.cancelCliked = false;
    this.saveCliked = false;

    this.form = this.fb.group({
      platformName: ['', [Validators.required, Validators.maxLength(35)]],
      empName: [''],
      oneBankId: ['']
    });
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }

  goback() {
    this.back.emit(true);
  }

  addAttr() {
    let deemo = {
      'bizTechInd': this.editBizTech[0].value,
      'countryCode': this.editcountry[0].value,
      'platformRole': this.editplatformRole[0].value,
      'leadDelegateInd': 'Lead',
      'empName': '',
      'createdBy': 'new',
      'dateCreated': null,
      'dateModified': null,
      'modifiedBy': null,
      'platformIndex': this.selectedValue.platformIndex,
      'oneBankId': '',
      'psId': '',
      'autoCompleteInd': 'N',
      'uniqueKey': Math.random()
    }
    this.add = 'true';
    this.stakeHolders.push(deemo);
    this.dataSource = new MatTableDataSource();

    this.dataSource.data = this.stakeHolders;
  }

  selected1(event, element) {

  }

  Onclick(element, index, event) {
    this.checkDuplicateAttrName();
    let a = event.target.value;
    if (event.target.value == '') {
      a = 'a'
    }
    let params1 = new HttpParams()
      .set('platform', this.selectedPlatform1)
      .set('staffName', a);
    if (element.bizTechInd == 'Technology') {
      this.restService.get(`/people/data/tribe-masters/employeelist?${params1}`).subscribe(data => {
        this.editStakeName = data;
      });
    }
    else {
      this.restService.get(`/people/data/tribe-masters/employeebusinesslist?${params1}`).subscribe(data => {
        this.editStakeName = data
        this.editStakeName.forEach(element => {
          element.oneBankId = element._1BankId;
          delete element._1BankId;
        });
      });
    }
  }

  staffNametypeOption(event, element) {

    let a = event.target.value
    if (event.target.value == '') {
      a = 'a'
    }

    let params1 = new HttpParams()
      .set('platform', this.selectedPlatform1)
      .set('staffName', a);
    if (element.bizTechInd == 'Technology') {
      this.restService.get(`/people/data/tribe-masters/employeelist?${params1}`).subscribe(data => {
        this.editStakeName = data;
      });
    } else {
      element.empName = event.target.value;
      this.restService.get(`/people/data/tribe-masters/employeebusinesslist?${params1}`).subscribe(data => {
        this.editStakeName = data
        this.editStakeName.forEach(element => {
          element.oneBankId = element._1BankId;
          delete element._1BankId;
        });
      });
      element.autoCompleteInd = 'N';
    }
    this.checkDuplicateAttrName();
  }

  getData() {
    this.filterChanges();
  }


  ngOnChanges(): void {
    let writeAccess = JSON.parse(localStorage.getItem('writeAccess'));
    for (var i = 0; i < writeAccess.length; i++) {
      if ('Platform Setup' === writeAccess[i]) {
        this.buttonEnable = true;
        break;
      }
    }
    this.isRefDataSelected = true;
    this.action = 'view';
    this.showFilter = false;
    this.selectedValue = null;
    this.selectedTemplate = null;
    this.showAddBtnForTemplate = true;
    this.isErrorExists = false;
    this.action = 'view';
    this.isErrorExists = false;
    this.cancelCliked = false;
    this.stakeHolders = [];
    this.stakedata = [];
    this.refdataOption = 'xref_platform_master';
    this.restService.get(`/people/data/platforms/getplatform/${this.selectedPlatform1}`).subscribe(res => {
      this.stakedata = res;
      this.selectedValue = res.platform;
      this.stakeHolders = this.stakedata.stakeHolders;
      this.dataSource = new MatTableDataSource();
      this.dataSource.data = this.stakeHolders;

      this.dataSource.sortingDataAccessor = (data, header) => {

        if (data[header] && typeof (data[header]) != 'number') {
          return data[header].toString().toLowerCase();
        } else {
          return data[header];
        }
      }
      this.dataSource.filter = '';

    });
    this.leadDelegate = [];
    this.leadDelegate.push({'value': 'all', 'display': 'All'});
    this.leadDelegate.push({'value': 'Lead', 'display': 'Lead'});
    this.leadDelegate.push({'value': 'Delegate', 'display': 'Delegate'});
    this.restService.get(`/people/data/dataSummary/dataValues/country`).subscribe(country => {
      this.editcountry = [];
      this.temp = country;
      this.temp.forEach(element => {
        this.editcountry.push({'value': element.value, 'display': element.value});
      });
      this.filterCountry = Object.assign([], this.editcountry)
      this.filterCountry.unshift({'value': 'all', 'display': 'All'});
    });
    this.restService.get(`/people/data/dataSummary/dataValues/stakeHolder`).subscribe(biz => {
      this.editBizTech = [];
      this.temp = biz;
      this.temp.forEach(element => {
        this.editBizTech.push({'value': element.value, 'display': element.value});
      });
      this.filterBizTech = Object.assign([], this.editBizTech);
      this.filterBizTech.unshift({'value': 'all', 'display': 'All'});
    });
    this.restService.get(`/people/data/dataSummary/dataValues/Platform Role`).subscribe(ptform => {
      this.temp = [];
      this.editplatformRole = [];
      this.temp = ptform;
      this.temp.forEach(element => {
        this.editplatformRole.push({'value': element.value, 'display': element.value});
      });
      this.filterPlatform = Object.assign([], this.editplatformRole);
      this.filterPlatform.unshift({'value': 'all', 'display': 'All'});
    });
  }

  requestRaise() {
    this.stakeHolders = [];
    this.stakedata = [];
    this.restService.get(`/people/data/platforms/getplatform/${this.selectedPlatform1}`).subscribe(res => {
      this.stakedata = res;
      this.stakeHolders = this.stakedata.stakeHolders;

      this.dataSource = new MatTableDataSource();
      this.dataSource.data = this.stakedata.stakeHolders;
    });

  }

  // updateForm() {
  //
  //   this.form.controls['platformName'].setValue(this.selectedValue.platformName);
  // }

  onRefDataSelection(e) {
    this.isRefDataSelected = true;
    this.refdataOption = e.value;
    this.action = 'view';
    this.selectedValue = null;
    this.selectedTemplate = null;
    this.selectedPlatform = '';
    this.showAddBtnForTemplate = true;
    this.isErrorExists = false;
  }

  onEditClick() {
    this.showFilter = false;
    this.action = 'edit';
    this.saveCliked = false;
    this.cancelCliked = false;
    this.isErrorExists = false;
    this.platformMessage.emit('edit')
    this.requestRaise();

  }


  deleteAttr(index, ele) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Delete Lead/Delegate?',
        body: 'Do you want to proceed with deletion of selected Lead/Delegate?',
        note: 'Do you want to proceed?',
        button1: 'Cancel',
        button2: 'OK'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        if (ele.psId && ele.psId > 0) {
          let i = this.dataSource.data.findIndex(temp => temp.psId === ele.psId);
          this.deletedList.push(this.dataSource.data.splice(i, 1)[0]);
          this.stakeList = this.dataSource.data;
          this.stakeHolders = this.dataSource.data;
        } else {
          let i = this.dataSource.data.findIndex(temp => temp.uniqueKey === ele.uniqueKey);
          this.dataSource.data.splice(i, 1);
          this.stakeList = this.dataSource.data;
          this.stakeHolders = this.dataSource.data;
        }
        this.dataSource = new MatTableDataSource();
        this.dataSource.data = this.stakeList;
        this.checkDuplicateAttrName();
      }
    });
  }

  onCancelClick() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Confirmation',
        body: 'You are in edit mode of this page, if you navigate away from this page without saving changes, your changes will be lost.',
        note: 'Do you want to proceed?',
        button1: 'Cancel',
        button2: 'OK'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.requestRaise();
        this.add = 'false';
        this.action = 'view';
      }
    });
  }

  get f() {
    return this.form.controls;
  }

  OnchangeLead(e, event) {

    if (event.checked == false) {
      if (e.psId && e.psId > 0) {
        let i = this.dataSource.data.findIndex(temp => temp.psId === e.psId);
        this.dataSource.data[i].leadDelegateInd = 'Lead';
        this.stakeList = this.dataSource.data
      } else {
        let i = this.dataSource.data.findIndex(temp => temp.uniqueKey === e.uniqueKey);
        this.dataSource.data[i].leadDelegateInd = 'Lead';
        this.stakeList = this.dataSource.data
      }
    }
    else {
      if (e.psId && e.psId > 0) {
        let i = this.dataSource.data.findIndex(temp => temp.psId === e.psId);
        this.dataSource.data[i].leadDelegateInd = 'Delegate';
        this.stakeList = this.dataSource.data
      } else {
        let i = this.dataSource.data.findIndex(temp => temp.uniqueKey === e.uniqueKey);
        this.dataSource.data[i].leadDelegateInd = 'Delegate';
        this.stakeList = this.dataSource.data
      }
    }

  }

  onchange(e, ele) {
    for (let one of this.editStakeName) {
      if (one.staffName.trim() == e.option.viewValue) {
        if (ele.psId && ele.psId > 0) {
          let i = this.dataSource.data.findIndex(temp => temp.psId === ele.psId);
          this.dataSource.data[i].oneBankId = one.oneBankId;
          this.dataSource.data[i].empName = one.staffName;
          this.stakeHolders = this.dataSource.data;
        }
        else {
          let i = this.dataSource.data.findIndex(temp => temp.uniqueKey === ele.uniqueKey);
          this.dataSource.data[i].oneBankId = one.oneBankId;
          this.dataSource.data[i].empName = one.staffName;
          this.stakeHolders = this.dataSource.data;
        }
        this.checkDuplicateAttrName();
        ele.autoCompleteInd = 'Y';
        this.editable = false;
      }

    }

  }

  save() {
    if (this.refdataOption == 'xref_platform_master') {

      this.add = 'false';
      this.action = 'view';
      this.stakeHolders.forEach(temp => {
        if (temp.uniqueKey) {
          delete temp.uniqueKey;
          delete temp.autoCompleteInd;
        }
      });
      this.stakedata.platform = this.selectedValue;
      this.stakedata.stakeHolders = this.stakeHolders;

      this.deletedList.forEach(e => {
        e.effectiveEndDate = moment(new Date()).format('YYYY-MM-DD');
      })
      this.stakedata['deletedList'] = this.deletedList;
      this.restService.put(`/people/data/platforms/saveplatform/${this.selectedPlatform1}`, this.stakedata).subscribe(data => {
        this.isErrorExists = true;
        this.platformMessage.emit('save');
        this.dataService.getCustomMessage(data['message']);
        this.dataService.getFlag(data['errorFlag']);
        this.getData();
        this.requestRaise();
        this.deletedList = [];
      });
    }
  }

  sortData(event): void {
    this.dataSource.sortingDataAccessor = (data, header) => {
      if (this.StakeHoldersdisplayedColumns.includes(header)) {
        if (typeof (data[header]) != 'number' && data[header]) {
          return data[header].toString().toLowerCase();
        } else {
          return data[header];
        }
      }
    }
    this.dataSource.sort = this.sort;
  }


  filterChanges() {
    this.oneBankIdFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.oneBankId = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
        }
      );
    this.empNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.empName = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
        }
      );
    this.leadDelegateFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.leadDelegateInd = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
        }
      );
    this.platformRoleFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.platformRole = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
        }
      );
    this.bizTechIndFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.bizTechInd = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
        }
      );
    this.reportingCountryFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.countryCode = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
        }
      );

  }

  toggleFilter() {
    let searchText = '';
    this.showFilter = !this.showFilter;
    if (this.filterValues) {
      for (let field in this.filterValues) {
        this.filterValues[field] = '';
      }
      this.dataSource.filter = JSON.stringify(this.filterValues);
    }

    this.empNameFilter.setValue('');
    this.oneBankIdFilter.setValue('');
    this.leadDelegateFilter.setValue('');
    this.platformRoleFilter.setValue('');
    this.reportingCountryFilter.setValue('');
    this.bizTechIndFilter.setValue('');
  }

  checkDuplicateAttrName() {
    this.hasDuplicateAttr = false;
    if (this.stakeHolders) {
      this.stakeHolders.map(v => v.empName).sort().sort((a, b) => {
        if (a.toLowerCase() === b.toLowerCase()) {
          this.hasDuplicateAttr = true;
        }
      });
    }
  }

  oneBankIdAccessCheck(element) {
    if (this.stakeHolders.slice(0, this.stakeHolders.length - 1).filter(ele => ele.bizTechInd === 'Business').findIndex(e => e.empName === element.empName) < 0) {
      this.editable = true;
    }
    else {
      this.editable = false;
    }
  }

  oneBankIdSave(element, event) {
    element.oneBankId = event.target.value;
  }

  staffNameAccess(element) {
    if (element.psId > 0)
      return true;
    else
      return false;

  }
}
