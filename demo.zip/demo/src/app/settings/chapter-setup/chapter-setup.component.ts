import {Component, OnInit, Input, OnChanges, ViewChild, AfterViewInit, Output, EventEmitter, ElementRef} from '@angular/core';
import {RestService} from 'src/app/common/service/rest.service';
import {MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {DataService} from 'src/app/common/service/data.service';
import {HttpParams} from '@angular/common/http';
import {FormBuilder, FormGroup, Validators, FormArray, AbstractControl} from '@angular/forms';
import {startWith, map} from 'rxjs/operators';
import {Observable} from 'rxjs';
import {RxwebValidators} from '@rxweb/reactive-form-validators';
import {MatDialog} from '@angular/material/dialog';
import {ConfirmDialogComponent} from 'src/app/common/component/dialogues/confirm-dialog/confirm-dialog-component';
import * as moment from 'moment';

@Component({
  selector: 'app-chapter-setup',
  templateUrl: './chapter-setup.component.html',
  styleUrls: ['./chapter-setup.component.scss']
})


export class ChapterSetupComponent implements OnInit, OnChanges, AfterViewInit {
  @Input() selectedTechUnit;
  @Input() createChapter;
  actualData: any;
  @Output() editChapter: EventEmitter<any> = new EventEmitter();
  displayedColumns: string[] = ['chapterName', 'chapterCode', 'status', 'leads', 'delegates',
    'action'];
  displayedColumnsForEdit: string[] = ['leadDelegateInd', 'empName', 'oneBankId', 'remove']
  editAction = false;
  dropDownData = ['Active', 'Inactive']
  selectedForEdit: any;
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  dataSource1: MatTableDataSource<any> = new MatTableDataSource();
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  @ViewChild(MatPaginator, {static: false}) editpaginator: MatPaginator;
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  chapterForm: FormGroup;
  newList: any;
  wData: any;
  editBizTech: any[];

  temp: any;
  count: boolean = false;
  filteredEmployeeList: Observable<any>;
  employeeList: any;
  totalCount: number;
  isTeamNameExist: boolean = false;
  editable: boolean;
  changedName: any;
  deletedStaff: any = [];
  deleteTemp: any;
  originalData: any;
  hasDuplicateAttr: boolean;
  employeeBusinessList: any;
  hasDuplicateAttr1: boolean = false;
  createAction: boolean = false;
  whitespace: boolean = false;
  originalStatus: any;
  isErrorExists: boolean = false;
  label: string;
  dropdownStaffList: any;
  private deletedList=[];
  buttonEnable=false;


  constructor(private restService: RestService, private dataservice: DataService, private fb: FormBuilder, public dialog: MatDialog) {
    this.dataSource = new MatTableDataSource();
    this.dataSource1 = new MatTableDataSource();
    this.restService.track('CHAPTER_SETUP');
  }
  ngOnInit() {
    this.editAction = false;
    let techUnit = this.selectedTechUnit;
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.dataSource1.paginator = this.editpaginator;
  }

  createNewChapter() {
    this.label = 'Create New '
    this.isErrorExists = false;
    let params1 = new HttpParams()
      .set('techUnit', this.selectedTechUnit)
      .set('staffName', 'a');
    this.restService.get(`/people/data/chapters/employeelist?${params1}`).subscribe(data => {
      this.employeeList = data;
      this.dropdownStaffList = data;
    });
    this.totalCount = 0;
    this.count = false;
    this.createAction = true;
    this.selectedForEdit = [];
    this.selectedForEdit.chapterMaster=[];
    this.selectedForEdit.chapterMaster.chapterName='';
    this.hasDuplicateAttr = false;
    this.hasDuplicateAttr1 = false;
    this.changedName = this.selectedForEdit.chapterName;
    this.chapterForm = this.fb.group({
      chapterName: ['', [Validators.required, Validators.maxLength(100)]],
      chapterCode: [''],
      chapterSurrId: [''],
      dateCreated: [null],
      dateModified: [null],
      modifiedBy: [''],
      platformIndex: [''],
      status: ['Active'],
      techunitCode: [this.selectedTechUnit],
      createdBy: ['NEW'],
      stakeHolders: this.fb.array([])
    });
    this.actualData = [];

  }

  onEditClickEvent(e) {
    this.dropdownStaffList = [];
    this.editChapter.emit('edit');
    this.label = 'Edit '
    this.isErrorExists = false;
    let params1 = new HttpParams()
      .set('techUnit', this.selectedTechUnit)
      .set('staffName', 'a');
    this.restService.get(`/people/data/chapters/employeelist?${params1}`).subscribe(data => {
      this.employeeList = data
    });
    this.createChapter = ''
    this.totalCount = 0;
    this.deletedList=[];
    this.count = false;
    this.editAction = true;
    this.selectedForEdit = e;
    this.originalStatus = this.selectedForEdit.status;
    this.hasDuplicateAttr = false;
    this.hasDuplicateAttr1 = false
    this.changedName = this.selectedForEdit.chapterName;
    this.editChapter.emit('edit');
    let params = new HttpParams()
      .set('techUnit', this.selectedTechUnit)
      .set('chapterName', this.selectedForEdit.chapterName);
      this.chapterForm = this.fb.group({
        chapterName: [this.selectedForEdit.chapterMaster.chapterName, [Validators.required, Validators.maxLength(100)]],
        chapterCode: [this.selectedForEdit.chapterMaster.chapterCode],
        chapterSurrId: [this.selectedForEdit.chapterMaster.chapterSurrId],
        dateCreated: [this.selectedForEdit.chapterMaster.dateCreated],
        dateModified: [this.selectedForEdit.chapterMaster.dateModified],
        modifiedBy: [this.selectedForEdit.chapterMaster.modifiedBy],
        platformIndex: [this.selectedForEdit.chapterMaster.platformIndex],
        status: [this.selectedForEdit.chapterMaster.status],
        techunitCode: [this.selectedForEdit.chapterMaster.techunitCode],
        createdBy: [this.selectedForEdit.chapterMaster.createdBy],
        stakeHolders: this.fb.array([])
      });
      this.setStakeholderConfig();
  }

  setStakeholderConfig() {
    let control = <FormArray>this.chapterForm.controls.stakeHolders;
    if (this.selectedForEdit) {
      this.selectedForEdit.chapterLeads.forEach(x => {
        control.push(this.fb.group({
          chapterLeadsId:[x['chapterLeadsId']],
          createdBy: [x['createdBy']],
          dateCreated: [x['dateCreated']],
          dateModified: [x['dateModified']],
          effectiveEndDate: [x['effectiveEndDate']],
          effectiveStartDate: [x['effectiveStartDate']],
          modifiedBy: [x['modifiedBy']],
          platformIndex: [x['platformIndex']],
          chapterRole: [x['chapterRole'], [Validators.required]],
          chapterLead: [x['chapterLead']],
          count: [this.totalCount],
          chapterLeadOnebankId: [x['chapterLeadOnebankId']],
          techUnit: [x['techUnit']],
          leadDelegateInd: [x['leadDelegateInd'], [Validators.required]],
          profileEditAccess:[x['profileEditAccess']],
          chapterName:[x['chapterName']]
        }));
        this.totalCount = this.totalCount + 1;
      })
    }
    this.dataSource1.data = control.value.filter(ele=> (ele.effectiveEndDate==null || ele.effectiveEndDate==''));
    setTimeout(() => this.dataSource1.paginator = this.editpaginator);
  }

  checkBox(element, e, index1) {

    let control = <FormArray>this.chapterForm.controls.stakeHolders;
    if (e.checked == true) {
      let index = this.dataSource1.data.findIndex(temp => temp.count === element.count);
      if (index != -1) {
        this.dataSource1.data[index].leadDelegateInd = 'Y';
        this.dataSource1.data[index].chapterRole = 'Lead Delegate';
        ((this.chapterForm.get('stakeHolders') as FormArray).at(index1) as FormGroup).get('leadDelegateInd').patchValue('Y');
        ((this.chapterForm.get('stakeHolders') as FormArray).at(index1) as FormGroup).get('chapterRole').patchValue('Lead Delegate');
      }
    }
    else {
      let index = this.dataSource1.data.findIndex(temp => temp.count === element.count);
      if (index != -1) {
        this.dataSource1.data[index].leadDelegateInd = 'N';
        this.dataSource1.data[index].chapterRole = 'Lead';
        ((this.chapterForm.get('stakeHolders') as FormArray).at(index1) as FormGroup).get('leadDelegateInd').patchValue('N');
        ((this.chapterForm.get('stakeHolders') as FormArray).at(index1) as FormGroup).get('chapterRole').patchValue('Lead');
      }
    }
    if (control.value[index1].createdBy !== 'NEW') {
      let i = this.selectedForEdit.chapterLeads.findIndex(ele => ele.oneBankId === control.value[index1].oneBankId)
      if (i != -1) {
        this.selectedForEdit.chapterLeads[i].leadDelegateInd = control.value[index1].leadDelegateInd;
        this.selectedForEdit.chapterLeads[i].chapterRole = control.value[index1].chapterRole;
      }
    }
  }

  get teamStaffList() {
    return this.chapterForm.get('stakeHolders') as FormArray;
  }



  deleteStaff(index, ele) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Delete Lead/Delegate?',
        body: 'Do you want to proceed with deletion of selected Lead/Delegate?',
        note: 'Do you want to proceed?',
        button1: 'Cancel',
        button2: 'OK'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {

        // let bank = ele.oneBankId
        // if (ele.chapterLeadsId !== '') {
        //   let i = this.originalData.findIndex(temp => temp.oneBankId === bank)
        //   if (i != -1) {
        //     this.originalData[i].effectiveEndDate = new Date();
        //   }
        // }
        const control = <FormArray>this.chapterForm.controls.stakeHolders;
        if (control ) {
          ((this.chapterForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('effectiveEndDate').patchValue(moment(new Date()).format('YYYY-MM-DD'))
          if (index < control.value.length - 1) {
            for (var ind = index; ind < control.value.length - 1; ind++) {
              ((this.chapterForm.get('stakeHolders') as FormArray).at(ind + 1) as FormGroup).get('count').patchValue(ind);
            }
          }
          if( ele.createdBy == 'NEW' ) {
            control.removeAt(index);
          }
          else{
            this.deletedList.push(control.value[index])
            control.removeAt(index);
          }
        }
        this.totalCount = control.value.length;
        this.dataSource1=new MatTableDataSource<any>();
        this.dataSource1.data = control.value.filter(ele=> (ele.effectiveEndDate==null || ele.effectiveEndDate==''));
        this.dataSource1.paginator = this.editpaginator;
      }
    });
  }

  Onclick(element, index, event) {
    let a = event.target.value;
    if (event.target.value == '') {
      a = 'a'
    }
    let params1 = new HttpParams()
      .set('techUnit', this.selectedTechUnit)
      .set('staffName', 'a');
    this.restService.get(`/people/data/chapters/employeelist?${params1}`).subscribe(data => {
      this.employeeList = data;
    });
  }

  addStaff() {

    let control = <FormArray>this.chapterForm.controls.stakeHolders;
    control.push(this.fb.group({
      count: [this.totalCount],
      chapterName:[this.selectedForEdit.chapterMaster.chapterName],
      chapterLeadsId:[''],
      createdBy: ['NEW'],
      dateCreated: [null],
      dateModified: [null],
      effectiveEndDate: [null],
      effectiveStartDate: [null],
      modifiedBy: [''],
      platformIndex: [this.selectedForEdit.chapterMaster.platformIndex],
      chapterRole: ['Lead', [Validators.required]],
      chapterLead: ['',[Validators.required,RxwebValidators.unique()]],
      chapterLeadOnebankId: ['', [Validators.required,Validators.required]],
      techUnit: [this.selectedTechUnit, [Validators.required]],
      leadDelegateInd: ['N', [Validators.required]],
      profileEditAccess: ['']
    }));
    this.totalCount = this.totalCount + 1;
    this.dataSource1.data = control.value.filter(ele=> (ele.effectiveEndDate==null || ele.effectiveEndDate==''));
    this.dataSource1.paginator = this.editpaginator;
  }
  checkForReadStatus(e) {
    if ( e.chapterLeadsId > 0 ) {
      return true;
    } else {
      return false;
    }
  }

  goback() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Confirmation',
        body: 'You are in edit mode of this page, if you navigate away from this page without saving changes, your changes will be lost.',
        note: 'Do you want to proceed?',
        button1: 'Cancel',
        button2: 'OK'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.settingForView();
      }
    });
  }

  private settingForView() {
    if ((this.editAction || this.createAction)) {
      this.restService.get(`/people/data/chapters/chapterData/${this.selectedTechUnit}`).subscribe(data => {
        this.dataSource.data = data;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.editAction = false;
        this.createAction = false;
        this.createChapter = '';
        this.dataservice.loaderHandler(false);
      });
      this.editAction = false;
      this.createAction = false;
    }
    this.selectedForEdit.chapterMaster.techunitCode=this.selectedTechUnit;
    this.editChapter.emit(this.selectedForEdit);
  }




  private _filterEmployee(value: string) {
    const filterValue = value.toLowerCase();
    return this.employeeList.filter(employee => employee.staffName.toLowerCase().indexOf(filterValue) === 0);
  }

  private _filterBusinessEmployee(value: string) {
    const filterValue = value.toLowerCase();
    return this.employeeBusinessList.filter(employee => employee.staffName.toLowerCase().indexOf(filterValue) === 0);
  }

  get t() {
    return this.chapterForm.controls.stakeHolders as FormArray;
  }

  checkDuplicateAttrName() {
    this.hasDuplicateAttr = false;
    if (this.chapterForm) {
      let control = this.chapterForm.controls.stakeHolders as FormArray;
      this.actualData = control.value;
      this.actualData.map(v => v.chapterLead).sort().sort((a, b) => {
        if (a.toLowerCase() === b.toLowerCase()) {
          this.hasDuplicateAttr = true;
        }
      })
    }
  }

  // Added to reflect changes when parent changes.
  ngOnChanges(): void {
    this.buttonEnable=false;
    this.editAction = false;
    if (this.createChapter != 'create') {
      let techUnit = this.selectedTechUnit;
      this.restService.get(`/people/data/chapters/chapterData/${techUnit}`).subscribe(data => {
        this.wData = data
        this.dataSource.data = data;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      });
    }
    if (this.createChapter == 'create') {
      this.editAction = true
      this.count = false;
      this.createAction = true
      this.createNewChapter();
    }


    let writeAccess = JSON.parse(localStorage.getItem('writeAccess'));
    for(var i=0;i<writeAccess.length;i++){
      if("Chapter Setup" === writeAccess[i]){
        this.buttonEnable=true;
      }
    }

    // this.dataSource.data = [{}]
  }

  selected(event, index) {
    this.hasDuplicateAttr1 = false;
    this.checkDuplicateAttrName();
    let tempList;
    const control = <FormArray>this.chapterForm.controls.stakeHolders;
      tempList = this.employeeList;

    for (let one of tempList) {
      if (one.staffName === event.option.value) {
        ((this.chapterForm.get('stakeHolders') as FormArray).at(index) as FormGroup).get('chapterLeadOnebankId').patchValue(one.oneBankId);
        this.dataSource1.data = control.value.filter(ele=> (ele.effectiveEndDate==null || ele.effectiveEndDate==''));
        break;
      }
    }
  }

  checkChapterNameExist(chapterName){
    this.isTeamNameExist = false;
    if (this.selectedForEdit.chapterMaster.chapterName === chapterName){
  this.isTeamNameExist = false;
} else {
  let params = new HttpParams()
    .set('techUnit', this.selectedTechUnit)
    .set('chapterName', chapterName);
  this.restService.get(`/people/data/chapters/findchaptername?${params}`).subscribe(data => {
    this.isTeamNameExist = data;
    if (!data)
      this.changedName = chapterName;
  });
}
  }
  staffNametypeOption(event, element) {
    this.checkDuplicateAttrName();
    let a = event.target.value
    if (event.target.value == '') {
      a = 'a'
    }
    let params1 = new HttpParams()
      .set('techUnit', this.selectedTechUnit)
      .set('staffName', a);

    this.restService.get(`/people/data/chapters/employeelist?${params1}`).subscribe(data => {
        this.employeeList = data;
        this.dropdownStaffList = data;
      });
  }

  save() {
    let control = <FormArray>this.chapterForm.controls.stakeHolders;
    let temp = this.selectedForEdit.chapterName;
    this.selectedForEdit.chapterName = this.changedName;
    this.chapterForm.get('chapterName').patchValue(this.changedName);
    const controls = this.chapterForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        this.chapterForm.controls[name].markAsTouched();
      }
    }
    if (this.chapterForm.invalid) {
      this.chapterForm.markAllAsTouched();
    } else if (this.chapterForm.valid) {
      if (this.editAction) {
      this.chapterForm.get('status').patchValue(this.selectedForEdit.status)
      }
      const controlAttr = <FormArray>this.chapterForm.controls.stakeHolders;
      // this.actualData = controlAttr.value;
      // this.actualData = this.actualData.filter(element => element.createdBy === 'NEW');

      let chapterMaster=this.chapterForm.value;
      if(chapterMaster.stakeHolders){
        delete chapterMaster.stakeHolders;
      }
      let chapterLeads=controlAttr.value;
      chapterLeads.forEach(temp => {
          temp.chapterName=chapterMaster.chapterName;
          delete temp.count;
      });
      if (this.createAction) {
        let dataObject = {
          'chapterMaster': chapterMaster,
          'chapterLeads': chapterLeads
        };
        this.dataservice.loaderHandler(true);
        this.restService.post(`/people/data/chapters/newchapter`, dataObject).subscribe(data => {
          this.isErrorExists = true;
          this.dataservice.getCustomMessage(data['message']);
          this.dataservice.getFlag(data['errorFlag']);
          this.settingForView();
        });
      }
      else if (this.selectedForEdit.status == 'Inactive' && this.originalStatus == 'Active') {

        const dialogRef = this.dialog.open(ConfirmDialogComponent, {
          data: {
            header: 'Set to Inactive?',
            body: 'Your request to set selected Chapter to "Inactive" will result in associated Chapter to be no longer Active.',
            note: 'Do you want to proceed?',
            button1: 'Cancel',
            button2: 'Set Inactive'
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result === 'yes') {
            let dataObject = {
              'chapterMaster': chapterMaster,
              'chapterLeads': chapterLeads,
              'deletedList':this.deletedList
            };
            this.dataservice.loaderHandler(true);
            this.restService.put(`/people/data/chapters/update`, dataObject).subscribe(data => {
              this.isErrorExists = true;
              this.dataservice.getCustomMessage(data['message']);
              this.dataservice.getFlag(data['errorFlag']);
              this.settingForView();
            });
          }
        });
      }
      else {
        let dataObject = {
          'chapterMaster': chapterMaster,
          'chapterLeads': chapterLeads,
          'deletedList':this.deletedList
        };
        this.dataservice.loaderHandler(true);
        this.restService.put(`/people/data/chapters/update`, dataObject).subscribe(data => {
          this.isErrorExists = true;
          this.dataservice.getCustomMessage(data['message']);
          this.dataservice.getFlag(data['errorFlag']);
          this.settingForView();
        });
      }

    }

  }

  validateoneBankId(control: AbstractControl) {
    let validEmail: boolean = false;
    this.whitespace = false;
    if (/\s/.test(control.value.oneBankId)) {
      this.whitespace = true;
    }
    if (this.whitespace) {
      return ({'validateoneBankId': this.whitespace});
    } else {
      return ({'validateoneBankId': false});
    }
  }

}
