import { NgModule } from "@angular/core"
import { MaterialModule } from "src/app/material.module";
import { SharedModule } from "src/app/common/module/shared.module";

// Routing
import { TeamManagementRoutingModule } from "./team-management-routing.module";

import { TeamManagementComponent } from './team-management.component';
import { CreateTeamComponent } from './create-team/create-team.component';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ViewTeamDetailsComponent } from './view-team-details/view-team-details.component';
import { AddRoleComponent } from 'src/app/common/component/dialogues/add-role/add-role.component';

import { TeamManagementResolver } from "./team-management.resolver";

@NgModule({
  imports: [
    TeamManagementRoutingModule,
    MaterialModule,
    SharedModule,
    ScrollingModule
  ],
  providers: [TeamManagementResolver],
  declarations: [TeamManagementComponent, CreateTeamComponent, ViewTeamDetailsComponent, AddRoleComponent],
})
export class TeamManagementModule { }
