import { Injectable } from "@angular/core";
import {
  Router,
  Resolve,
  RouterStateSnapshot,
  ActivatedRouteSnapshot
} from "@angular/router";
import { Observable } from "rxjs";
import { RestService } from "src/app/common/service/rest.service";
import { DataService } from "src/app/common/service/data.service";

@Injectable()
export class TeamManagementResolver implements Resolve<any> {
  constructor(private restService: RestService, private dataService: DataService) {}

  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> | Promise<any> {
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    const platformIndex=this.dataService.getAction();
    const reportingPeriod = this.dataService.getReportingPeriod();
    const teamName = JSON.parse(sessionStorage.getItem('teamName'));
    return  this.restService.post(`/people/team/teammanagement/getindividualteaminfo?teamName=${teamName}`, {techUnits: lobts,platformIndex: platformIndex, location: locations,rptPeriod:reportingPeriod})
  }
}
