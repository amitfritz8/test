import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { Component, OnInit, AfterViewInit, ViewChild, Output, Input, EventEmitter, OnDestroy } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { RestService } from 'src/app/common/service/rest.service';
import { FormControl } from '@angular/forms';
import { DataTableService } from 'src/app/common/service/dataTable.service';
import { CommonService } from 'src/app/common/service/common.service'
import { Router } from '@angular/router';
import { DataService } from 'src/app/common/service/data.service';
import { ActivatedRoute } from '@angular/router';
import { HttpClient, HttpParams } from '@angular/common/http';
import { saveAs } from 'file-saver';
import * as Excel from 'exceljs/dist/exceljs.min.js';
import * as moment from 'moment';
import { ChangeDetectorRef } from '@angular/core';
import { TeamReportingDialogComponent } from 'src/app/common/component/dialogues/team-reporting-dialog/team-reporting-dialog.component';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ObjectUnsubscribedError, Subscription } from 'rxjs';
import * as _ from 'lodash';

@Component({
  selector: 'team-management',
  templateUrl: './team-management.component.html',
  styleUrls: ['./team-management.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed, void', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
      transition('expanded <=> void', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'))
    ]),
  ],
})

export class TeamManagementComponent implements OnInit, AfterViewInit, OnDestroy {

  augmentedObject = {
    'augCount': null,
    'augActualFTECapacity': null,
    'augPlannedFTECapacity': null,
    'augBlendedCostTotal': null
  };
  nonAugmentedObject = {
    'coreCount': null,
    'coreActualFTECapacity': null,
    'corePlannedFTECapacity': null,
    'coreBlendedCostTotal': null
  };
  totalAug = [];
  @Input() element: any;
  @Input() selectedValue: any;
  @Output() back: EventEmitter<boolean> = new EventEmitter();
  displayedColumns: string[];
  genUser: boolean = false;
  superiorUser: boolean = false;
  queryParam: string = 'No';
  action: string = 'add';
  selectedDate: string;
  selectedView: string;
  reportingPeriod: string;
  dates: any;
  views: any;
  viewInd: boolean = true;
  hideExportButton: boolean=true;
  expandedElement: any;
  displayedColumnsIndividual: string[];
  bd11Msg: string = '';
  months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  filterValues = {
    platformName: '',
    subPlatformName: '',
    teamName: '',
    tribeName: '',
    teamType: '',
    // members: '',
    // FTECapacity:'',
    // blendedTeamCost:'',
    workLocation: '',
    teamLead: '',
    status: '',
    countryCode: ''
  };
  items = [];
  filterValuesIndividual = {
    empName: '',
    oneBankId: '',
    empType: '',
    empStatus: '',
    platform: '',
    subPlatform: '',
    reportingMgr: '',
    staffPccode: '',
    role: '',
    workLocation: '',
    maxWeekPercentage: ''
  };

  headerForSuperiorUser = ['Platform Name',
    'Sub-Platform Name',
    'Team Name',
    'Team Id',
    'Team Type',
    'Tribe Name',
    'Tribe Id',
    'Team Lead',
    'status',
    'Members',
    'Current Capacity',
    'Planned Capacity',
    'Chargeable Capacity',
    'Blended Team Cost/Day-Total (SGD)',
    'Blended Team Cost/Day-Chargeable (SGD)',
    'Augmented',
    'Work Location'];

  headerForGenUser = ['Platform Name',
    'Sub-Platform Name',
    'Team Name',
    'Team Id',
    'Team Type',
    'Tribe Name',
    'Tribe Id',
    'Team Lead',
    'status',
    'Members',
    'Work Location'];

  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  dataSourceIndividualContributor: MatTableDataSource<any> = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  // @ViewChild(MatPaginator, { static: false }) paginatorInd: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  // @ViewChild(MatSort, { static: false }) sortInd: MatSort;
  platformFilter = new FormControl('');
  subPlatformFilter = new FormControl('');
  teamNameFilter = new FormControl('');
  tribeNameFilter = new FormControl('');
  teamTypeFilter = new FormControl('');
  teamLeadFilter = new FormControl('');
  statusFilter = new FormControl('');
  membersFilter = new FormControl('');
  FTECapacityFilter = new FormControl('');
  blendedTeamCostFilter = new FormControl('');
  countryFilter = new FormControl('');
  showFilter: boolean = false;
  displayAdditionalInf: boolean = false;
  isSuccessMsg: boolean = false;
  searchText: string = '';
  roles: string[] = [];
  showCreateNewTeam: boolean = false;
  currentMonthStatus: boolean = false;
  empNameFilter = new FormControl('');
  oneBankIdFilter = new FormControl('');
  empTypeFilter = new FormControl('');
  staffStatusFilter = new FormControl('');
  platformIndivFilter = new FormControl('');
  subPlatformIndivFilter = new FormControl('');
  reportingMgrIndFilter = new FormControl('');
  staffPCCIndFilter = new FormControl('');
  roleIndFilter = new FormControl('');
  workLocationFilter = new FormControl('');
  maxWeekPercentageFilter = new FormControl('');
  tabObserver: Subscription;
  dataObserver: Subscription;

  // statusList = [{ key: '', value: 'All' }, { key: 'a', value: 'Active' }, { key: 'in', value: 'Inactive' }];
  statusList : any;
  statusIndividualList: any;
  teamTypeOpt = [{ key: '', value: 'All' }, { key: 'PCFT', value: 'PCFT' }, { key: 'NPCFT', value: 'NPCFT' }];
  roleMapping: any;
  platformNameList: string[];
  private blendcostTooltip: any;
  private fteCapacityTooltip: any;
  private membersTooltip: any;
  private teamData: any;
  headerInfo: any = {
    title: "Team Management"
  }
  private loggedInUserId: string | null;

  displayCount: number = 0;
  dataLength: number = 0;
  pageSubscription: Subscription;
  pageSize:number = 20;
  selectedTab: string;

  constructor(private restService: RestService, private router: Router, private dataService: DataService,
    private dataTableService: DataTableService, private route: ActivatedRoute, public dialog: MatDialog,
    private commonService: CommonService, private http: HttpClient, private cdr: ChangeDetectorRef) {
    this.restService.track('TEAM_MANAGEMENT');
    this.dataSource = new MatTableDataSource();
    this.views = ['Teams', 'Individual Contribution'];
    this.selectedTab = 'Teams';
    this.updateHeaderInfo();
    this.dataSourceIndividualContributor = new MatTableDataSource();
    this.items.push(
      { 'name': 'venky', 'value': 'venky1' });
    this.items.push(
      { 'name': 'venky2', 'value': 'venky3' });
    this.statusList = [];
    this.statusIndividualList = [];
    this.getStatusList();
    this.getIndividualStatusList();
  }

  getStatusList() {
    this.restService.get(`/people/team/teammanagement/statuslist`).subscribe(data => {
      if (data) {
        data.forEach(e => {
          this.statusList.push({key: e, value: e});
        });
        this.statusList.unshift({key: 'all', value: 'All'});
      }
    });
  }

  getIndividualStatusList() {
    this.restService.get(`/people/data/employee/staffstatuslist`).subscribe(data => {
      if (data) {
        data.forEach(e => {
          this.statusIndividualList.push({key: e, value: e});
        });
        this.statusIndividualList.unshift({key: 'all', value: 'All'});
      }
    });
  }

  updateHeaderInfo() {
    this.headerInfo.tabs = this.views;
    this.commonService.recieveMessage(this.headerInfo);
  }

  getStatusClass(status: string):string{
    if(status.toLowerCase()==='active'){
      return 'completed'
    } else if(status.toLowerCase()==='inactive'){
      return 'inactive';
    } else if(status.toLowerCase()==='planned'){
      return 'pending';
    }
  }

  ngOnInit() {
    // for updating tabs
    this.tabObserver = this.commonService.selectedTab.subscribe(data => {
      this.searchText = "";
      this.selectedTab = data;
      this.onselectViewChange(data);
    })
    this.loggedInUserId = localStorage.getItem('userOneBankId');
    this.commonService.setUserId(this.loggedInUserId);
    this.commonService.setDocumentTitle('TEAM MANAGEMENT');
    this.commonService.trackPageView();
    this.platformNameList = ['CBGT', 'IBGT', 'CBGT', 'IBGT', 'CBGT', 'IBGT', 'CBGT', 'IBGT', 'CBGT', 'IBGT', 'CBGT', 'IBGT', 'CBGT', 'IBGT'];
    this.selectedView = this.views[0];
    this.dataObserver = this.commonService.broadCastMessage.subscribe(data => {
      this.resetPageCount();
      this.handleReportingPeriod();
      if(this.selectedTab !== 'Teams'){
        this.getIndividualContributorList();
      } 
    });
    this.conditionForCreateTeam();
  }

  ngOnDestroy(){
     this.tabObserver.unsubscribe();
     this.dataObserver.unsubscribe();
     if(this.pageSubscription){
      this.pageSubscription.unsubscribe();
     }
  }

  getData() {
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    const roles = JSON.parse(sessionStorage.getItem('roles'));
    let currentMonth = Number(moment(new Date()).format('MM'));
    let currentYear = moment(new Date()).format('YYYY');
    this.currentMonthStatus = this.dataService.getcurrentMonthStatus();
    if (this.currentMonthStatus) {
      this.reportingPeriod = currentYear + ('0' + currentMonth).slice(-2);
      this.selectedDate = this.dates[0];
    } else {
      if (this.selectedDate) {
        let month: string = '0' + (this.months.indexOf(this.selectedDate.substring(5, this.selectedDate.length)) + 1);
        let year: string = this.selectedDate.substring(0, 4);
        this.reportingPeriod = year + '' + month.slice(-2);
      }
    }

    sessionStorage.setItem('rptPeriod', this.reportingPeriod);
    for (var role in roles) {

      this.rolePrecidenceValidator(role);
    }
    if (this.superiorUser) {
      this.displayedColumns = ['platformName', 'subPlatformName', 'tribeName', 'teamName', 'teamType',
        'teamLead', 'status', 'membersCount', 'FTECapacity', 'blendedTeamCost', 'countryCode', 'augmentedInd', 'TeamTotals'];
    } else if (this.genUser) {
      this.showCreateNewTeam = false;
      this.displayedColumns = ['platformName', 'subPlatformName', 'tribeName', 'teamName', 'teamType',
        'teamLead', 'status', 'membersCount', 'countryCode'];
    }

    this.displayedColumnsIndividual = ['empName', 'oneBankId', 'empType', 'empStatus',
      'platform','subPlatform', 'reportingMgr', 'staffPccode', 'role', 'workLocation', 'currentICCapacity'];
    this.dataService.loaderHandler(true);

    let teamManangementParams = {
      techUnits: lobts,
      platforms: platforms,
      location: locations,
      userRoles: this.roleMapping,
      rptPeriod: this.reportingPeriod
    };
    this.restService.post(`/people/team/teammanagement/all`, teamManangementParams).subscribe(data => {
      // To avoid data.slice() error which is internal function in MatTableDataSource
      this.dataService.loaderHandler(false);

      if (data['errorFlag'] !== '1') {
        let i = 0;
        data.forEach(element => {
          element.index = i;
          i = i + 1;
          if (element.workLocation != null) {
            const work = element.workLocation.replace(/,/g, ', ');
            element.workLocation = work;
          }
        });
        this.teamData = data;
        this.dataSource.data = data;
        this.dataSource.sort = this.sort;
        this.dataSource.sortingDataAccessor = (data, header) => {
          if (this.displayedColumns.includes(header)) {
            if (typeof (data[header]) != 'number' && data[header]) {
              return data[header].toString().toLowerCase();
            } else {
              return data[header];
            }
          }
        }
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.dataLength = this.dataSource.data.length;
        this.paginator.pageIndex = 0;
        this.pageSubscription = this.paginator.page.subscribe(pageObj => {
          this.pageSize = pageObj.pageSize;
          this.updateDisplayCountForSelectedTab();
        });
        this.filterDataForSelectedTab();
        this.updateDisplayCountForSelectedTab();
      }
      if (data['errorFlag'] === '1') {
        this.dataSource.data = [];
        this.dataLength = this.dataSource.data.length;
        this.updateDisplayCountForSelectedTab();
      }
    });
    this.filterChanges();
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=TEAMS-TEAMCOST-tooltip`).subscribe(result => {
      this.blendcostTooltip = result.message;
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=TEAMS-FTECAPACITY-tooltip`).subscribe(result => {
      this.fteCapacityTooltip = result.message;
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=TEAMS-Members-tooltip`).subscribe(result => {
      this.membersTooltip = result.message;
    });
  }


  handleReportingPeriod() {
    const platform = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    const reportingPeriodDate = JSON.parse(sessionStorage.getItem('reportingPeriodDate'));
    if (reportingPeriodDate) {
      this.selectedDate = reportingPeriodDate;
    }
    // Getting List for Reporting Period.
    if (lobts && platform && locations) {
      this.restService.post(`people/data/employee/getreportmonthyear`, { techUnits: lobts, platforms: platform, location: locations }).subscribe(data => {
        if (data) {
          this.dates = [];
          this.dates.push('Current View')
          data.forEach(ele => {
            const reportingYear = ele.substring(0, 4);
            let reportingMonth = ele.substring(4, 6);
            // Taking reporting month without 0.
            if (reportingMonth && reportingMonth.charAt(0) === 0) {
              reportingMonth = reportingMonth.charAt(1);
            }
            this.dates.push(reportingYear + ' ' + this.months[reportingMonth - 1]);
          });

        }
        // Commenting this code for UAT.Need to add this PROD.
        const currentMonth = Number(moment(new Date()).format('MM'));
        const currentYear = moment(new Date()).format('YYYY');
        const currentDay = Number(moment(new Date()).format('DD'));
        if (!reportingPeriodDate) {
          if (currentDay >= 15) {
            this.selectedDate = currentYear + ' ' + this.months[currentMonth - 2];
          } else {
            this.selectedDate = currentYear + ' ' + this.months[currentMonth - 3];
          }
          const selectedDatePresent = this.dates.includes(this.selectedDate);
          if (!selectedDatePresent) {
            this.selectedDate = this.dates[1];
          }
          sessionStorage.setItem('reportingPeriodDate', JSON.stringify(this.selectedDate));
        }
        this.checkForBD();
        this.getData();
      });
    }
  }

  getIndividualContributorList() {
    const platform = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));

    if (lobts && platform && locations) {
      let params = { 
        techUnits: lobts, 
        platforms: platform, 
        location: locations, 
        rptPeriod: this.reportingPeriod 
      };
      this.restService.post(`/people/data/employee/individualContributor`, params).subscribe(data => {

        this.dataSourceIndividualContributor.data = data;
        this.dataSourceIndividualContributor.sort = this.sort;
        this.dataSourceIndividualContributor.sortingDataAccessor = (data, header) => {
          if (this.displayedColumnsIndividual.includes(header)) {
            if (typeof (data[header]) != 'number' && data[header]) {
              return data[header].toString().toLowerCase();
            } else {
              return data[header];
            }
          }
        }
        this.dataSourceIndividualContributor.sort = this.sort;
        this.dataSourceIndividualContributor.paginator = this.paginator;
        this.dataLength = this.dataSourceIndividualContributor.data.length;
        this.paginator.pageIndex = 0;
        this.pageSubscription = this.paginator.page.subscribe(pageObj => {
          this.pageSize = pageObj.pageSize;
          this.updateDisplayCountForSelectedTab();
        });
        this.filterDataForSelectedTab();
        this.updateDisplayCountForSelectedTab();
        this.dataService.loaderHandler(false);
      });
    }
    this.filterChangesIndividual();
  }

  onReportingPeriodChnage(e) {
    if (e.value.includes('Current')) {
      this.currentMonthStatus = true;
      this.dataService.setcurrentMonthStatus(true);
    } else {
      this.currentMonthStatus = false;
      this.dataService.setcurrentMonthStatus(false);
      sessionStorage.setItem('reportingPeriodDate', JSON.stringify(this.selectedDate));
    }
    this.resetPageCount();
    this.checkForBD();
    if(this.selectedTab === 'Teams'){
      this.getData();
    } else {
      this.getIndividualContributorList();
    }
    this.conditionForCreateTeam();
  }

  onselectViewChange(e) {
    this.selectedTab = e.value;
    this.resetPageCount();
    if (e == 'Teams'){
      this.viewInd = true;
      this.getData();
    } else {
      this.viewInd = false;
      this.getIndividualContributorList();
    }
  }

  checkForBD() {
    const currentMonth = Number(moment(new Date()).format('MM'));
    const currentYear = Number(moment(new Date()).format('YYYY'));
    const currentDay = Number(moment(new Date()).format('DD'));
    let month: string;
    let year: string;
    if (this.selectedDate) {
      month = '0' + (this.months.indexOf(this.selectedDate.substring(5, this.selectedDate.length)) + 1);
      year = this.selectedDate.substring(0, 4);
      this.reportingPeriod = year + '' + month.slice(-2);
    }
    if (Number(year) == currentYear) {
      if (currentDay <= 15 && Number(month) == (currentMonth - 1)) {
        this.restService.get(`people/data/employee/messagepeopledata`).subscribe(data => {
          this.bd11Msg = data['message'];
        })
      } else {
        this.bd11Msg = '';
      }
    } else if (Number(year) == (currentYear - 1) && currentMonth == 1) {
      if (currentDay <= 15 && month == '012') {
        this.restService.get(`people/data/employee/messagepeopledata`).subscribe(data => {
          this.bd11Msg = data['message'];
        })
      } else {
        this.bd11Msg = '';
      }
    } else {
      this.bd11Msg = '';
    }
  }

  resetPageCount(){
    this.displayCount = 0;
    this.dataLength = 0;
  }

  applyFilter(filterValue: string) {
    if (this.showFilter) {
      this.showFilter = false;
    }
    for (var i in this.filterValues) {
      this.filterValues[i] = filterValue.trim().toLowerCase();
    }
    this.dataSource.filter = JSON.stringify(this.filterValues);
    this.dataSource.filterPredicate = this.dataTableService.tableFilterForSearch();
    this.dataLength = this.dataSource.filteredData.length;
    this.updateDisplayCount();
  }

  applyFilterIndividual(filterValue: string) {
    // if (this.showFilter) {
    // this.showFilter = false;
    // }
    for (var i in this.filterValuesIndividual) {
      this.filterValuesIndividual[i] = filterValue.trim().toLowerCase();
    }
    this.dataSourceIndividualContributor.filter = JSON.stringify(this.filterValuesIndividual);
    this.dataSourceIndividualContributor.filterPredicate = this.dataTableService.tableFilterForSearch();
    this.dataLength = this.dataSourceIndividualContributor.filteredData.length;
    this.updateDisplayCount();
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.dataSourceIndividualContributor.sort = this.sort;
    this.dataSourceIndividualContributor.paginator = this.paginator;
  }

  filterDataForSelectedTab(){
    if (this.filterValues) {
      for (let field in this.filterValues) {
        this.filterValues[field] = '';
      }
      if(this.selectedTab === 'Teams'){
        this.dataSource.filter = JSON.stringify(this.filterValues);
      } else {
        this.dataSourceIndividualContributor.filter = JSON.stringify(this.filterValues);
      }
    }
    this.platformFilter.setValue('');
    this.subPlatformFilter.setValue('');
    this.teamNameFilter.setValue('');
    this.teamTypeFilter.setValue('');
    this.tribeNameFilter.setValue('');
    this.teamLeadFilter.setValue('');
    this.statusFilter.setValue('Active');
    this.membersFilter.setValue('');
    this.FTECapacityFilter.setValue('');
    this.blendedTeamCostFilter.setValue('');
    this.countryFilter.setValue('');
    this.empNameFilter.setValue('');
    this.oneBankIdFilter.setValue('');
    this.empTypeFilter.setValue('');
    this.staffStatusFilter.setValue('Active');
    this.platformIndivFilter.setValue('');
    this.subPlatformIndivFilter.setValue('');
    this.reportingMgrIndFilter.setValue('');
    this.staffPCCIndFilter.setValue('');
    this.roleIndFilter.setValue('');
    this.workLocationFilter.setValue('');
    this.maxWeekPercentageFilter.setValue('');
  }

  updateDisplayCountForSelectedTab(){
    if(this.selectedTab === 'Teams'){
      this.dataLength = this.dataSource.filteredData.length;
    } else {
      this.dataLength = this.dataSourceIndividualContributor.filteredData.length;
    }
    this.updateDisplayCount();
  }

  toggleFilter(e) {
    this.searchText = '';
    this.showFilter = !this.showFilter;
    this.filterDataForSelectedTab();
    this.updateDisplayCountForSelectedTab();
  }

  filterChangesForTeams(){
    this.dataSource.filter = JSON.stringify(this.filterValues);
    this.dataSource.filterPredicate = this.dataTableService.tableFilter();
    this.dataLength = this.dataSource.filteredData.length;
    this.updateDisplayCount();
  }

  filterChanges() {
    this.platformFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.platformName = data.trim().toLowerCase();
          this.filterChangesForTeams();
        }
      )
    this.subPlatformFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.subPlatformName = data.trim().toLowerCase();
          this.filterChangesForTeams();
        }
      )
    this.teamNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.teamName = data.trim().toLowerCase();
          this.filterChangesForTeams();
        }
      )
    this.teamTypeFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.teamType = data;
          this.filterChangesForTeams();
        }
      )
    this.tribeNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.tribeName = data.trim().toLowerCase();
          this.filterChangesForTeams();
        }
      )
    this.teamLeadFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.teamLead = data.trim().toLowerCase();
          this.filterChangesForTeams();
        }
      )
    this.statusFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.status = data.trim().toLowerCase();
          this.filterChangesForTeams();
        }
      )
    // this.membersFilter.valueChanges
    //   .subscribe(
    //     data => {
    //       this.filterValues.members = data;
    //       this.dataSource.filter = JSON.stringify(this.filterValues);
    //       this.dataSource.filterPredicate = this.dataTableService.tableFilter();
    //     }
    //   )
    this.workLocationFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.workLocation = data.trim().toLowerCase();
          this.filterChangesForTeams();
        }
      )
    this.countryFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.countryCode = data.trim().toLowerCase();
          this.filterChangesForTeams();
        }
      )
  }

  filterChangesIndividual() {
    this.empNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesIndividual.empName = data.trim().toLowerCase();
          this.filterDisplayForIndividual();
        }
      )
    this.oneBankIdFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesIndividual.oneBankId = data.trim().toLowerCase();
          this.filterDisplayForIndividual();
        }
      )
    this.empTypeFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesIndividual.empType = data.trim().toLowerCase();
          this.filterDisplayForIndividual();
        }
      )
    this.staffStatusFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesIndividual.empStatus = data.trim().toLowerCase();
          this.filterDisplayForIndividual();
        }
      )
    this.platformIndivFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesIndividual.platform = data.trim().toLowerCase();
          this.filterDisplayForIndividual();
        }
      )
    this.subPlatformIndivFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesIndividual.subPlatform = data.trim().toLowerCase();
          this.filterDisplayForIndividual();
        }
      )
    this.reportingMgrIndFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesIndividual.reportingMgr = data.trim().toLowerCase();
          this.filterDisplayForIndividual();
        }
      )
    this.staffPCCIndFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesIndividual.staffPccode = data.trim().toLowerCase();
          this.filterDisplayForIndividual();
        }
      )
    this.roleIndFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesIndividual.role = data.trim().toLowerCase();
          this.filterDisplayForIndividual();
        }
      )
    this.workLocationFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesIndividual.workLocation = data.trim().toLowerCase();
          this.filterDisplayForIndividual();
        }
      )
    this.maxWeekPercentageFilter.valueChanges
      .subscribe(
        data => {
          this.filterValuesIndividual.maxWeekPercentage = data.trim().toLowerCase();
          this.filterDisplayForIndividual();
        }
      )
  }

  filterDisplayForIndividual(){
    this.dataSourceIndividualContributor.filter = JSON.stringify(this.filterValuesIndividual);
    this.dataSourceIndividualContributor.filterPredicate = this.dataTableService.tableFilter();
    this.dataLength = this.dataSourceIndividualContributor.filteredData.length;
    this.updateDisplayCount();
  }

  gotoTeamDetails(event, element) {
    sessionStorage.setItem('teamName', JSON.stringify(element['teamName']));
    sessionStorage.setItem('platformIndex', JSON.stringify(element['platformIndex']));
    this.dataService.setReportingPeriod(this.reportingPeriod);
    this.dataService.setAction(element.platformIndex);
    this.dataService.setTeamStatus(element.status);
    if (this.currentMonthStatus) {
      this.dataService.setcurrentMonthStatus(true);
    }
    this.router.navigateByUrl('home/workforce/team-management/viewTeamDetails');
  }

  createNewTeam(action) {
    this.dataService.setReportingPeriod(this.reportingPeriod);
    if (this.currentMonthStatus) {
      this.dataService.setcurrentMonthStatus(true);
    }
    this.router.navigateByUrl('home/workforce/team-management/createteam');
  }

  rolePrecidenceValidator(role) {
    if (role === 'GENE_DBS_ADMIN' || role === 'GENE_DBS_CENTRALFUNCTION' || role === 'GENE_DBS_FINANCE' || role === 'GENE_DBS_CENTRALFUNCTION' ||
      role === 'GENE_DBS_MGT' || role === 'GENE_DBS_PLATFORMLEAD' ||
      role === 'GENE_DBS_TEAMLEAD' || role === 'GENE_DBS_MGT') {
      this.superiorUser = true;
    } else if (role === 'GENE_DBS_USER' || role === 'GENE_DBS_WORKMGR') {
      this.genUser = true;
    }
  }
  conditionForCreateTeam() {
    const roles = JSON.parse(sessionStorage.getItem('roles'));
    if (this.dataService.getcurrentMonthStatus()) {
      for (var role in roles) {
        if (role == 'GENE_DBS_TEAMLEAD' || role == 'GENE_DBS_PLATFORMLEAD') {
          this.restService.get(`/people/team/teammanagement/getAccessForTeamCreation?oneBankId=${this.loggedInUserId}`).subscribe(result => {
            //DO NOT DELETE , adding this for diabling create team for mvp2_r1 release
            result['message'] === 'Yes' ? this.showCreateNewTeam = false : this.showCreateNewTeam = false;
          });
        }
      }
    }else{
      this.showCreateNewTeam=false;
    }

  }

  onExportClicked() {
    this.isSuccessMsg = false;
    this.dataService.loaderHandler(true);
    let elementData = [];
    var excelFileName = '';
    if (this.superiorUser === true) {
      excelFileName = 'Team details - EXPORT file';
    } else if (this.genUser) {
      excelFileName = 'Team details - EXPORT file (no capacity & cost)';

    }

    if (this.superiorUser === true && this.dataSource.filteredData.length > 0) {
      this.dataSource.filteredData.forEach((emp) => {
        elementData.push([emp.platformName,
        emp.subPlatformName,
        emp.teamName,
        emp.teamCode,
        emp.percentageFlag,
        emp.tribeName,
        emp.tribeCode,
        emp.members,
        emp.actualFTECapacity,
        emp.plannedFTECapacity,
        emp.chargeableFTECapacity,
        emp.blendedCostTotal,
        emp.blendedCostChargeable,
        emp.countryCode]);
      });

    } else if (this.genUser && this.dataSource.filteredData.length > 0) {
      this.dataSource.filteredData.forEach((emp) => {
        elementData.push([emp.platformName,
        emp.subPlatformName,
        emp.teamName,
        emp.teamCode,
        emp.percentageFlag,
        emp.tribeName,
        emp.tribeCode,
        emp.members,
        emp.countryCode]);
      });

    }

    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    let workbook = new Excel.Workbook();
    let worksheet = workbook.addWorksheet('Team Management Details');
    let headerRow;
    if (this.superiorUser) {
      headerRow = worksheet.addRow(this.headerForSuperiorUser);
    } else {
      headerRow = worksheet.addRow(this.headerForGenUser);
    }

    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFFFFFFF' },
        bgcolor: { argb: 'FF0000FF' }
      }
      cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
    })

    worksheet.getCell('A1').font = { size: 12, bold: true };
    worksheet.getCell('B1').font = { size: 12, bold: true };
    worksheet.getCell('C1').font = { size: 12, bold: true };
    worksheet.getCell('D1').font = { size: 12, bold: true };
    worksheet.getCell('E1').font = { size: 12, bold: true };
    worksheet.getCell('F1').font = { size: 12, bold: true };
    worksheet.getCell('G1').font = { size: 12, bold: true };
    worksheet.getCell('H1').font = { size: 12, bold: true };
    worksheet.getCell('I1').font = { size: 12, bold: true };
    worksheet.getCell('J1').font = { size: 12, bold: true };
    worksheet.getCell('K1').font = { size: 12, bold: true };
    worksheet.getCell('L1').font = { size: 12, bold: true };
    worksheet.getCell('M1').font = { size: 12, bold: true };
    worksheet.getCell('N1').font = { size: 12, bold: true };

    worksheet.addRows(elementData);
    worksheet.columns = [{ key: 'A', width: 40 }, { key: 'B', width: 30 },
    { key: 'C', width: 45 }, { key: 'D', width: 10 }, { key: 'E', width: 8 }, { key: 'F', width: 15 },
    { key: 'G', width: 10 }, { key: 'H', width: 10 }, { key: 'I', width: 18 }, { key: 'J', width: 18 }, { key: 'K', width: 20 }, { key: 'L', width: 33 },
    { key: 'M', width: 40 }, { key: 'N', width: 15 }];

    workbook.xlsx.writeBuffer().then((data) => {
      let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      saveAs(blob, excelFileName + EXCEL_EXTENSION);
    })
    this.dataService.loaderHandler(false);
    this.isSuccessMsg = true;
    this.dataService.getCustomMessage('Data Exported Successfully');
    this.dataService.getFlag('0');
    this.commonService.showSnackBar({
      type: 'success',
      message: "Data Exported Successfully"
    });
  }

  teamTotals(e) {
    let params = new HttpParams()
      .set('platformIndex', e.platformIndex)
      .set('teamName', e.teamName)
      .set('reportingPeriod', this.reportingPeriod);

    this.restService.get(`/people/team/teammanagement/teamtotals?${params}`).subscribe(data => {
      let total = data[0];
      const dialogRef = this.dialog.open(TeamReportingDialogComponent, {
        data: {
          current: e,
          total: total
        }
      });
    });
  }

  getToolTipData(type: string) {
    let str = '';
    if (type === 'membersCount') {
      str = str + 'Members \n' + this.membersTooltip;

    } else if (type === 'fteCapacity') {
      str = str + 'FTE Capacity Current/Planned \n' + this.fteCapacityTooltip;
    } else if (type === 'blendedCost') {
      str = str + 'Blended Team Cost/Day \n' + this.blendcostTooltip;
    }
    //str.replace('\n', '<br></hr>');
    return this.getStringFromHtml(str);
  }

  getPaginationClass(dataSource: any): string{
    if(!dataSource || dataSource.data.length === 0){
      return 'hide';
    }
    return 'visible';
  }

  updateDisplayCount(){
    this.displayCount = (this.paginator.pageIndex + 1) *  this.pageSize > this.dataLength ? this.dataLength : (this.paginator.pageIndex + 1) * this.pageSize;
  }

  getStringFromHtml(text) {
    const html = text;
    const div = document.createElement('div');
    div.innerHTML = html;
    return div.textContent || div.innerText || '';
  }

  setCollapseOrExpandState(e, timeout: any){
    if(timeout == 0){
      this.teamData.forEach(element => {
        if (element.augmentedInd == 'No' && element.index != e.index) {
          element.augmentedInd = 'Yes';
        }
      });
      if (this.teamData[e.index].augmentedInd == 'Yes' && this.teamData[e.index].index == e.index) {
        this.teamData[e.index].augmentedInd = 'No';
      } else if (this.teamData[e.index].augmentedInd == 'No' && this.teamData[e.index].index == e.index) {
        this.teamData[e.index].augmentedInd = 'Yes';
      }
    } else {
      setTimeout(() => {
        this.teamData.forEach(element => {
          if (element.augmentedInd == 'No' && element.index != e.index) {
            element.augmentedInd = 'Yes';
          }
        });
        if (this.teamData[e.index].augmentedInd == 'Yes' && this.teamData[e.index].index == e.index) {
          this.teamData[e.index].augmentedInd = 'No';
        } else if (this.teamData[e.index].augmentedInd == 'No' && this.teamData[e.index].index == e.index) {
          this.teamData[e.index].augmentedInd = 'Yes';
        }
      }, timeout);
    }
  }

  onAugInClick(e, i) {
    let isExpand = e.augmentedInd === 'Yes';
    if(isExpand){
      this.dataSource.data = this.teamData;
      let augCount = 0;
      let coreCount = 0;
      let coreActualFTECapacity = 0;
      let corePlannedFTECapacity = 0;
      let coreBlendedCostTotal = 0;
      let augActualFTECapacity = 0;
      let augPlannedFTECapacity = 0;
      let augBlendedCostTotal = 0;
      this.augmentedObject.augCount = 0;
      this.augmentedObject.augActualFTECapacity = 0;
      this.augmentedObject.augPlannedFTECapacity = 0;
      this.augmentedObject.augBlendedCostTotal = 0;
      this.nonAugmentedObject.coreCount = coreCount;
      this.nonAugmentedObject.coreActualFTECapacity = coreActualFTECapacity;
      this.nonAugmentedObject.corePlannedFTECapacity = corePlannedFTECapacity;
      this.nonAugmentedObject.coreBlendedCostTotal = coreBlendedCostTotal;
      let params = new HttpParams()
        .set('platformIndex', e.platformIndex)
        .set('teamName', e.teamName)
        .set('reportingPeriod', this.reportingPeriod);
      this.totalAug = [];
      
      const locations = JSON.parse(sessionStorage.getItem('locations'));
      this.restService.post(`/people/team/teammanagement/teamCoreMemberDetails`, {
        rptPeriod: this.reportingPeriod,
        teamName: e.teamName,
        platformIndex: e.platformIndex,
        locations: locations
      }).subscribe(data => {

        const augArray = _.groupBy(data, function (aug) {
          return aug.platformName;
        });
        let keyStr: string = '';
        Object.keys(augArray).map(function (key) {
          if (augArray[key][0] && (augArray[key][0]).augmentedInd !== 'Yes') {
            keyStr = key;
          }
        });
        delete augArray[keyStr];


        Object.keys(augArray).map(key => {
          const members = augArray[key];
          const actualFTECapacity = members
            .map(item => item.actualFTECapacity)
            .reduce((prev, curr) => prev + curr, 0);

          this.totalAug.push({ platformName: key, actualFTECapacity: actualFTECapacity, plannedFTECapacity: '0', blendedCostTotal: '0', totalMembers: members.length });
        });

        data.forEach(element => {

          if (element.augmentedInd === 'Yes') {
            augCount = augCount + 1;
            augActualFTECapacity = element.actualFTECapacity + augActualFTECapacity;
            augPlannedFTECapacity = element.plannedFTECapacity + augPlannedFTECapacity;
            augBlendedCostTotal = element.blendedCostTotal + augBlendedCostTotal;

            /*this.totalAug.forEach(e => {
              if (e.platformName === element.platformName) {
                element.actualFTECapacity = element.actualFTECapacity + 100;
                toPush = false;
              }
            });
            if (toPush) {
              this.totalAug.push(element);
            }*/
            this.augmentedObject.augCount = augCount;
            this.augmentedObject.augActualFTECapacity = augActualFTECapacity;
            this.augmentedObject.augPlannedFTECapacity = augPlannedFTECapacity;
            this.augmentedObject.augBlendedCostTotal = augBlendedCostTotal;
          } else {
            coreCount = coreCount + 1;
            coreActualFTECapacity = element.actualFTECapacity + coreActualFTECapacity;
            corePlannedFTECapacity = element.plannedFTECapacity + corePlannedFTECapacity;
            coreBlendedCostTotal = element.blendedCostTotal + coreBlendedCostTotal;
            this.nonAugmentedObject.coreCount = coreCount;
            this.nonAugmentedObject.coreActualFTECapacity = coreActualFTECapacity;
            this.nonAugmentedObject.corePlannedFTECapacity = corePlannedFTECapacity;
            this.nonAugmentedObject.coreBlendedCostTotal = coreBlendedCostTotal;
          }
        });
        this.setCollapseOrExpandState(e, 300);
      });
    } else{
      this.setCollapseOrExpandState(e, 0);
    }
  }

}
