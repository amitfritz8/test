import { Component, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormArray, Validators, FormControl } from '@angular/forms';
import { RestService } from 'src/app/common/service/rest.service';
import { ConfirmDialogComponent } from 'src/app/common/component/dialogues/confirm-dialog/confirm-dialog-component';
import { MatDialog } from '@angular/material/dialog';
import { DataService } from 'src/app/common/service/data.service';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { TimeFormat } from 'src/app/common/pipes/timeFormater.pipe';
import { Subscription, Observable, Subject, ReplaySubject } from 'rxjs';
import {map, startWith, take, takeUntil} from 'rxjs/operators';
import { CommonService } from 'src/app/common/service/common.service';
import { HttpParams } from '@angular/common/http';
import * as moment from 'moment';
import * as _ from 'lodash';

import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import {CommonDialogComponent} from '../../../common/component/dialogues/common-dialog/common-dialog-component';


@Component({
  selector: 'create-team',
  templateUrl: 'create-team.component.html',
  styleUrls: ['create-team.component.scss']
})

export class CreateTeamComponent implements OnInit {
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  rolesList = [];
  rolesAdded = [];
  value: any;
  teamRole = 'Team Role';
  addRoleClick = 0;
  response: any = [];
  todoEmployees: any = [];
  noData: any;
  rolesListLength = 0;
  addRolesListLength = 0;
  selectedPlatformIndex: any;
  filteredEmployeeList: Observable<any>;
  filteredTLDelegateList: Observable<any>;
  count = 0;
  countTLDelegate = 0;
  hasDuplicateProdOwner: boolean;
  hasDuplicateTLDelegate: boolean;
  isTeamNameExist = false;
  goToMemebers = true;
  subscription: Subscription;
  empData: any = {};
  teamData: any = {
    platformName: '',
    platformIndex: '',
    subPlatformName: '',
    percentageFlag: 'PCFT',
    teamName: '',
    tribeName: ''
  };
  superiorUser = true;
  errorData: any;
  isSuccessMsg: any;
  productForm: FormGroup;
  isCountForProdOwnerExceeded = false;
  isCountForTLDelegateExceeded = false;
  checkValidOptionForTeamDelegate = false;
  showAdd = true;
  teamEmpData: any = {};
  tribeNameList: any = [];
  platformList = [];
  platforms = [];
  subPlatformList = [];
  employeeList = [];
  list = [];
  data = [];
  teamLD = [];
  productOwnersData: any = [];
  teamLeadDelegatesData: any = [];
  statusFlag: any;
  checkValidOptionForTeamLead = false;
  leadDelegateList = [];
  roundButton: any;
  showIfMembers = false;
  develpoer = false;
  showStepper = true;
  minWidthValue = false;
  resultList = [];
  employeePoolList = [];
  headerInfo: any = {
    show_filters: false,
    nav_bk_url: "team-management",
    nav_bk_info: "Team Management",
    title: 'Create New Team'
  }
  // selectedTab = '1';
  displayedColumns = ['staffName', 'oneBankId', 'allocationPercentage', 'staffType', 'teamRole',
    'platformName', 'subPlatformName', 'countryCode', 'workLocation', 'chargeType', 'staffRate', 'effectiveStartDate', 'remove'];

  @ViewChild('multiSelect', { static: true }) multiSelect: MatSelect;
  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  protected _onDestroy = new Subject<void>();

  public LeadSearchControl: FormControl = new FormControl();
  public filteredLeadData: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public leadFormControl: FormControl = new FormControl(null,[Validators.required]);

  public LeadDelegateSearchControl: FormControl = new FormControl();
  public filteredLeadDelegateData: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public leadDelegateFormControl: FormControl = new FormControl();

  public BizProductOwnerSeachControl: FormControl = new FormControl();
  public filteredBizProductOwnerData: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public BizProductOwnerFormControl: FormControl = new FormControl();

  public memberSearchControl: FormControl = new FormControl();
  public filteredMemberData: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public memberFormControl: FormControl = new FormControl();
  public roleFormControl: FormControl = new FormControl();
  public loggedInUserId;
  memberForm: FormGroup;
  memberFormForNonSummary: FormGroup;



  @Output() back: EventEmitter<boolean> = new EventEmitter();
  isErrorExists: boolean = false;
  membersCount = 0;
  public platformGroups: { name: string; platform: any[] }[];
  public dateListForMembersStartDate: any = [];
  public setDate: any;
  public membersList: any;
  public dataSourceForSummary: MatTableDataSource<any> = new MatTableDataSource();
  public dataSourceForNonSummary: MatTableDataSource<any> = new MatTableDataSource();
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  public selectedEmployee: any;
  public roleSelected: any;
  public selectedStaffList: any = [];
  public checkAddButtonFlag: boolean;
  public expansion: any;
  public coreMemberCumulatives =
    {
      members: 0,
      fte: 0,
      overallTeamCostPerDay: 0,
      overallTeamCostPerMonth: 0,
      overallTeamCostPerDayNotional: 0,
      notionalTeamCostPerMonth: 0,
      overallTeamCostPerDayChargeable: 0,
      chargeableTeamCostPerMonth: 0
    }
    ;
  public augmentedMemberCumulatives =
    {
      members: 0,
      fte: 0,
      overallTeamCostPerDay: 0,
      overallTeamCostPerMonth: 0,
      overallTeamCostPerDayNotional: 0,
      notionalTeamCostPerMonth: 0,
      overallTeamCostPerDayChargeable: 0,
      chargeableTeamCostPerMonth: 0
    }
    ;
  public fteForMember: number = 0;
  chargeableFlag: boolean;
  notionalFlag: boolean;
  blendedRate: number;
  private bizEmployeeList: any;
  manDaysPerMonth = 18;

  planTeamColumns: string[];
  indexEdit;
  // plan sample data
  totalFte = 0;
  totalCost = 0;
  totalCostString ='0';
  totalCostMonth=0;
  totalCostMonthString='0';
  planTeamData = {
    "cost": "",
    "currency": "SGD",
    "daysInMonth": 18,
    "teamPlanCapacityResourceList": [
      {
        "plannedTeamSurrId": "",
        "teamName":"",
        "reportingPeriod":"",
        "teamRole": "Developer",
        "workLocation": "SG",
        "staffType": "DBS",
        "vendorName": "DBS",
        "rateSource": "TACO",
        "skillLevel": "level 1",
        "effectiveEndDate":"",
        "fte": 2.0,
        "blendedCost": 0,
        "localCcyCode":"",
        "ccyCode":"",
        "groupCcyCode":"",
        "blendedCostGcy":0,
        "blendedCostLcy":0
      }
    ]
  }
  teamRoles = [];
  workLocations = [];
  staffType = [];
  vendors = [];
  rateSources = [];
  levels = [];
  fte = new FormControl();
  deletePlanList: number[] = [];
  planTeam: FormGroup;
  private currentWorkLocation: any;
  private currentStaffType: any;
  private currentVendor: any;
  private currentRateSource: any;
  private currentLevel: any;
  private rate: any;
  private cost: any;
  private rptPeriod: any;
  private fteFlag: boolean;
  private costFlag: boolean;
  fteExcessMessage: string='';
  costExcessMessage: string = '';
  fteAndCostExcessMessage: string='';
  private deleteMessage: any;
  public teamExistsMessage: any;
  private teamName: any;
  private ccyCode: string;
  public localCurrency: any = 'SGD';
  private exchangeRate: any;
  private currentTeamRole: any;
  public baseCurrency: string = 'SGD';
  private teamAbortMessage: any;

  constructor(private fb: FormBuilder, private commonService: CommonService, private router: Router, private restService: RestService, private dataService: DataService,
    private dateUtility: DateUtility, public formattime: TimeFormat, public dialog: MatDialog) {
    this.commonService.recieveMessage(this.headerInfo);
    this.planTeam = this.fb.group({
      teamRoles: this.fb.array([])
    });
  }

  ngOnInit(): void {
    this.loggedInUserId = localStorage.getItem('userOneBankId');
    this.commonService.broadCastMessage.subscribe(data => {
      const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
      this.restService.get(`/people/data/platforms`).subscribe(data => {
        this.platformList = data.filter(val => {
          return platforms.includes(val.platformIndex);
        });
        this.platformList.sort((a, b) => (a.platformIndex > b.platformIndex) ? 1 : -1);
        if (this.platformList && this.platformList.length == 1) {
          this.productForm.patchValue({
            platformName: this.platformList[0].platformIndex
          });
        }
      });
    });
    this.rptPeriod = sessionStorage.getItem('rptPeriod');
    this.restService.get(`/people/data/dataValues/sys-config?msgKey=Mandays per Month`).subscribe(result => {
      this.manDaysPerMonth = +result['message'];
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_TEAM_PLANACTDIFF_1`).subscribe(result => {
      this.fteExcessMessage = result['message'];
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_TEAM_PLANACTDIFF_2`).subscribe(result => {
      this.costExcessMessage = result['message']
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_TEAM_PLANACTDIFF_3`).subscribe(result => {
      this.fteAndCostExcessMessage = result['message']
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_TEAM_DELETETEMPMEMBER`).subscribe(result => {
      this.deleteMessage = result['message']
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=ERR_TEAM_TEAMNAMEDUP`).subscribe(result => {
      this.teamExistsMessage = result['message']
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_TEAM_CREATETEAMABORT`).subscribe(result => {
      this.teamAbortMessage = result['message']
    });

    this.getData();
    this.getTeamRoles();
    this.getWorkLocations();
    this.productForm = this.fb.group({
      platformName: [this.teamData.platformName, [Validators.required]],
      subPlatformName: [this.teamData.subPlatformName, [Validators.required]],
      percentageFlag: [this.teamData.percentageFlag, [Validators.required]],
      teamName: [this.teamData.teamName, [Validators.required, Validators.maxLength(100)]],
      tribeName: [this.teamData.tribeName, []],
      teamLeadName: [''],
      productOwners: this.fb.array([this.fb.group({ productOwner: '' })]),
      teamLeadDelegates: this.fb.array([this.fb.group({ teamLeadDelegate: '' })])
    });
    this.productForm.controls.teamName.disable();
    this.productForm.controls.subPlatformName.disable();
    this.productForm.controls.tribeName.disable();
    this.leadFormControl.disable();
    this.leadDelegateFormControl.disable();
    this.memberFormControl.disable();
    this.roleFormControl.disable();
    this.setMemberForm();
    this.setMemberFormForNonSummary();
  }
  setMemberForm() {
    this.memberForm = this.fb.group({
      memberArray: this.fb.array([])
    });
  }
  setMemberFormForNonSummary() {
    this.memberFormForNonSummary = this.fb.group({
      memberArray: this.fb.array([])
    });

  }
  protected setInitialValue() {
    this.filteredLeadData
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        this.singleSelect.compareWith = (a: any, b: any) => a && b && (a.oneBankId === b.oneBankId || a.empName === b.empName);
      });

    this.filteredLeadDelegateData
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        this.multiSelect.compareWith = (a: any, b: any) => a && b && (a === b);
      });

    this.filteredBizProductOwnerData
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        this.multiSelect.compareWith = (a: any, b: any) => a && b && (a === b);
      });

    this.filteredMemberData
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        this.singleSelect.compareWith = (a: any, b: any) => a && b && (a.oneBankId === b.oneBankId || a.empName === b.empName);
      });
  }


  getData() {
    this.planTeamColumns = ['teamRole', 'workLocation', 'staffType1', 'vendorName', 'rateSource', 'skillLevel', 'fte', 'costPerDay', 'edit', 'remove'];
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    this.restService.get(`/people/data/platforms`).subscribe(data => {
      this.platformList = data.filter(val => {
        return platforms.includes(val.platformIndex);
      });
      this.platformList.sort((a, b) => (a.platformIndex > b.platformIndex) ? 1 : -1);
      if (this.platformList && this.platformList.length == 1) {
        this.productForm.patchValue({
          platformName: this.platformList[0].platformIndex
        });
      }
    });
  }



  // add plan team
  addPlan() {
    let data = {
      "plannedTeamSurrId":"",
      "teamName":"",
      "reportingPeriod":"",
      "teamRole": "",
      "workLocation": "",
      "staffType": "",
      "vendorName": "",
      "rateSource": "",
      "skillLevel": "",
      "effectiveEndDate":"",
      "fte": 0,
      "blendedCost": 0,
      "localCcyCode":"",
      "ccyCode":"",
      "groupCcyCode":"",
      "blendedCostGcy":0,
      "blendedCostLcy":0
    };
    this.planTeamData.teamPlanCapacityResourceList.push(data);
    let ctrl = this.planTeam.get('teamRoles') as FormArray;
    ctrl.push(this.setPlanTeamFormArray(data));
    this.enableEditRow(ctrl,(ctrl.length-1));
    this.planTeamData.teamPlanCapacityResourceList=ctrl.value;
  }
  setPlanTeamFormArray(data) {
    return this.fb.group({
      plannedTeamSurrId: [data.plannedTeamSurrId],
      teamName: [data.teamName],
      reportingPeriod: [data.reportingPeriod],
      teamRole: [data.teamRole,[Validators.required]],
      workLocation: [data.workLocation,[Validators.required]],
      staffType: [data.staffType,[Validators.required]],
      vendorName: [data.vendorName,[Validators.required]],
      rateSource: [data.rateSource,[Validators.required]],
      skillLevel: [data.skillLevel,[Validators.required]],
      effectiveEndDate: [data.effectiveEndDate],
      fte: [data.fte,[Validators.required]],
      blendedCost: [data.blendedCost],
      localCcyCode: [data.localCcyCode],
      ccyCode: [data.ccyCode],
      groupCcyCode: [data.groupCcyCode],
      blendedCostGcy: [data.blendedCostGcy],
      blendedCostLcy: [data.blendedCostLcy]
    });
  }

  getTeamRoles() {
    this.restService.get(`/people/team/teammanagement/teamdropdown/role`).subscribe(data => {
      this.teamRoles = data;
    });
  }
  getWorkLocations() {
    this.restService.get(`/people/team/teammanagement/teamdropdown/workLocation`).subscribe(data => {
      this.workLocations = data;
    });
  }
  getStaffType(workLocation) {
    this.currentWorkLocation = workLocation;
    this.restService.get(`/people/team/teammanagement/teamdropdown/staffType?workLocation=${workLocation}`).subscribe(data => {
      this.staffType = data;
    });
  }
  storeRole(role){
    this.currentTeamRole=role;
  }
  getVendor(staffType) {
    this.currentStaffType = staffType;
    this.restService.get(`/people/team/teammanagement/teamdropdown/vendor?workLocation=${this.currentWorkLocation}&staffType=${staffType}`).subscribe(data => {
      this.vendors = data;
    });
  }
  getRateSource(vendor) {
    this.currentVendor = vendor;
    this.restService.get(`/people/team/teammanagement/teamdropdown/rateSource?workLocation=${this.currentWorkLocation}&staffType=${this.currentStaffType}&vendor=${vendor}`).subscribe(data => {
      this.rateSources = data;
    });
  }
  getLevel(rateSource) {
    this.currentRateSource = rateSource;
    this.restService.get(`/people/team/teammanagement/teamdropdown/level?workLocation=${this.currentWorkLocation}&staffType=${this.currentStaffType}&vendor=${this.currentVendor}&rateSource=${rateSource}`).subscribe(data => {
      this.levels = data;
    });
  }

  getRate(level){
    this.currentLevel = level;
    _.forIn(this.planTeamData.teamPlanCapacityResourceList, (v: any, k) => {
      if((v.teamRole==this.currentTeamRole)&&(v.workLocation==this.currentWorkLocation)&&(v.staffType==this.currentStaffType)&&(v.vendorName==this.currentVendor)&&(v.rateSource==this.currentRateSource)&&(v.level==this.currentLevel)){
        this.commonService.showSnackBar({
          type: 'alert',
          message: "This combination already exists. Please edit the existing record"
        });
      }
    });

    this.restService.get(`/people/team/teammanagement/teamdropdown/rate?workLocation=${this.currentWorkLocation}&staffType=${this.currentStaffType}&vendor=${this.currentVendor}&rateSource=${this.currentRateSource}&level=${level}`).subscribe(data => {
      this.rate =data;
    });
    this.restService.get(`/people/team/teammanagement/teamdropdown/currency?workLocation=${this.currentWorkLocation}&staffType=${this.currentStaffType}&vendor=${this.currentVendor}&rateSource=${this.currentRateSource}&level=${level}`).subscribe(data => {
      this.localCurrency =data;
    });
    this.fetchExchangeRates();
  }

  fetchExchangeRates(){
    let reportingPeriod = this.dataService.getReportingPeriod();
    this.restService.get(`/people/team/teammanagement/getExchangeRates?ccyFrom=${this.localCurrency}&ccyTo=${this.baseCurrency}&reportingPeriod=${this.rptPeriod}`).subscribe(data => {
      this.exchangeRate =data;
    });
  }
  countDecimals(value){
    if (Math.floor(value) !== value)
      return value.toString().split('.')[1].length || 0;
    return 0;
  }

  getCost(index,fte) {
    if(fte.indexOf(".") == -1){
      if (fte < 0.2) {
        this.commonService.showSnackBar({
          type: 'alert',
          message: "Member can't be added. Available FTE is lower than 0.2"
        });
      } else {
        this.changeFte(index);
        let control = this.planTeam.get('teamRoles') as FormArray;
        this.cost = (+this.rate) * (+fte);
        this.cost=Number(parseFloat(String(this.cost)).toFixed(2));
        let blendedLocal = (+this.cost) / (+this.exchangeRate);
        ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('blendedCost').patchValue(this.cost);
        ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('localCcyCode').patchValue(this.localCurrency);
        ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('ccyCode').patchValue(this.localCurrency);
        ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('groupCcyCode').patchValue(this.baseCurrency);
        ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('blendedCostGcy').patchValue(this.cost);
        ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('blendedCostLcy').patchValue(blendedLocal);
        this.changeCost(index, this.cost);
        this.planTeamData.teamPlanCapacityResourceList = control.value;
      }
    }
    else {
      if (this.countDecimals(fte) > 2) {
        this.commonService.showSnackBar({
          type: 'alert',
          message: "Fte should be upto 2 decimal places"
        });
      }
      else {
        if (fte < 0.2) {
          this.commonService.showSnackBar({
            type: 'alert',
            message: "Member can't be added. Available FTE is lower than 0.2"
          });
        } else {
          this.changeFte(index);
          let control = this.planTeam.get('teamRoles') as FormArray;
          this.cost = (+this.rate) * (+fte);
          this.cost = Number(parseFloat(String(this.cost)).toFixed(2));
          let blendedLocal = (+this.cost) / (+this.exchangeRate);
          ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('blendedCost').patchValue(this.cost);
          ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('localCcyCode').patchValue(this.localCurrency);
          ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('ccyCode').patchValue(this.localCurrency);
          ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('groupCcyCode').patchValue(this.baseCurrency);
          ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('blendedCostGcy').patchValue(this.cost);
          ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('blendedCostLcy').patchValue(blendedLocal);
          this.changeCost(index, this.cost);
          this.planTeamData.teamPlanCapacityResourceList = control.value;
        }
      }
    }
  }

  enableEditRow(e, index) {
    this.indexEdit = index;
  }
  changeFte(index){
    let oldFte=0;
    _.forIn(this.planTeamData.teamPlanCapacityResourceList, (v: any, k) => {
      if(v.plannedTeamSurrId == ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('plannedTeamSurrId').value){
        oldFte=v.fte;
      }
    });

    let newFte= ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('fte').value;
    this.totalFte=(+this.totalFte)+(+newFte)-(+oldFte);
    this.totalFte=Number(parseFloat(String(this.totalFte)).toFixed(2));
  }
  changeCost(index,newCost){
    let oldCost=0;
    _.forIn(this.planTeamData.teamPlanCapacityResourceList, (v: any, k) => {
      if(v.plannedTeamSurrId == ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('plannedTeamSurrId').value){
        oldCost=v.blendedCost;
      }
    });
    this.totalCost=(+this.totalCost)+(+newCost)-(+oldCost);
    this.totalCost=Number(parseFloat(String(this.totalCost)).toFixed(2));
    this.totalCostString = this.totalCost.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    this.totalCostMonth=(+this.totalCost)*(+this.planTeamData.daysInMonth);
    this.totalCostMonth=Number(parseFloat(String(this.totalCostMonth)).toFixed(2));
    this.totalCostMonthString=this.totalCost.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }

  onDeleteRow(ele,index){
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'warning',
        contentTitle: "Delete Role?",
        content: `Please confirm you will remove this role from team planned cost and capacity. Do you want to proceed?`,
        cancelTxt: 'Cancel',
        confirmTxt: "OK"

      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        let control = this.planTeam.get('teamRoles') as FormArray;
        let plannedTeamSurrId= ((this.planTeam.get('teamRoles') as FormArray).at(index) as FormGroup).get('plannedTeamSurrId').value;
        if(plannedTeamSurrId==null || plannedTeamSurrId==''){
          control.removeAt(index);
          this.planTeamData.teamPlanCapacityResourceList = control.value;
        }
        else {
          this.deletePlanList.push(plannedTeamSurrId);
          control.removeAt(index);
          this.planTeamData.teamPlanCapacityResourceList = control.value;

        }
      }
    });

  }
  goBackFromEdit() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Confirmation',
        body: 'You are in edit mode of this page, if you navigate away from this page without saving changes, your changes will be lost.',
        note: 'Do you want to proceed?',
        button1: 'Cancel',
        button2: 'OK'
      }
    });
    /*dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.settingForView();
      }
    });*/
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustom(date);
  }

  timeFormat(date?: Date) {
    const d = new Date(date);
    const time = d.getHours() + ':' + d.getMinutes();
    return this.formattime.transform(time);
  }

  saveForm() {
    const controls = this.productForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        this.productForm.controls[name].markAsTouched();
      }
    }
    if (this.productForm.invalid) {
      this.productForm.markAllAsTouched();
    } else if (this.productForm.valid && this.totalFte >= 4) {
      let control1 = _.clone(this.memberForm.controls.memberArray as FormArray);
      let control2 =_.clone(this.memberFormForNonSummary.controls.memberArray as FormArray);
      let teamPlanControl = _.clone(this.planTeam.controls.teamRoles as FormArray);
      let teamManageMembersList = _.clone(control1.value);
      control2.value.forEach(e => {
        teamManageMembersList.push(e);
      })
      teamManageMembersList.forEach(e => {
        e.teamPlatformIndex = this.selectedPlatformIndex;
        this.selectedPlatformIndex !== e.staffPlatformIndex ? e.augmentedInd = 'Y' : e.augmentedInd = 'N'
        e.allocationPercentage = +e.fte * 100;
        e.effectiveStartDate = new Date(e.effectiveStartDate);
        e.blendedCost = +e.fte * +e.blendedRate;
        delete e.fte;
      });

      let dataObj = {
        "platformIndex": this.selectedPlatformIndex,
        "platformName" : this.platformGroups[0].platform[0].value.platformName,
        "subPlatformName": this.productForm.controls.subPlatformName.value,
        "teamName": this.productForm.controls.teamName.value,
        "tribeName": this.productForm.controls.tribeName.value,
        "teamType": this.productForm.controls.percentageFlag.value,
        "teamLead": this.leadFormControl.value,
        "productOwner": this.BizProductOwnerFormControl.value.length > 0 ? this.BizProductOwnerFormControl.value : [],
        "teamLeadDelegate": this.leadDelegateFormControl.value.length > 0 ? this.leadDelegateFormControl.value : [],
        "totalFte": this.coreMemberCumulatives.fte + this.augmentedMemberCumulatives.fte,
        "totalMembers": this.coreMemberCumulatives.members + this.augmentedMemberCumulatives.members,
        "notionalCostTotal": this.coreMemberCumulatives.notionalTeamCostPerMonth + this.augmentedMemberCumulatives.notionalTeamCostPerMonth,
        "blendedCostTotal": this.coreMemberCumulatives.chargeableTeamCostPerMonth + this.augmentedMemberCumulatives.chargeableTeamCostPerMonth,
        "notionalCurrencyCode": "SGD",
        "chargeableCurrencyCode": "SGD",
        "overallCostPerDay": this.coreMemberCumulatives.overallTeamCostPerDay + this.augmentedMemberCumulatives.overallTeamCostPerDay,
        "overallCostPerMonth": this.coreMemberCumulatives.overallTeamCostPerMonth + this.augmentedMemberCumulatives.overallTeamCostPerMonth,
        "overallCurrencyCode": "SGD",
        "teamPlannedCapacityResource":
        {
          "teamName": this.productForm.controls.teamName.value,
          "daysInMonth": this.manDaysPerMonth,
          "currency":"SGD",
          "cost": this.totalCost,
          "teamPlanCapacityResourceList": teamPlanControl.value
        },
        "teamMembersList": teamManageMembersList
      };
      this.restService.post(`/people/team/teammanagement/createTeamWithPlanAndMembers?reportingPeriod=${this.rptPeriod}&oneBankId=${this.loggedInUserId}&plannedIndicator=Y`, dataObj).subscribe(data => {

        if (data['errorFlag'] == 1) {
          this.commonService.showSnackBar({
            type: 'alert',
            message: data.message
          });
        }
        else {
          let message = data.message;
          message = message.replace("<Team Name>",this.productForm.controls.teamName.value)
          this.commonService.showSnackBar({
            type: 'success',
            message: message
          });

          sessionStorage.setItem('teamName', JSON.stringify(this.productForm.controls.teamName.value));
          sessionStorage.setItem('platformIndex', JSON.stringify(this.selectedPlatformIndex));
          this.router.navigateByUrl('home/workforce/team-management/viewTeamDetails');
        }
      });
    }

  }

  goback() {
      this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_TEAM_CREATETEAMCANCEL`).subscribe(result => {
        const dialogRef = this.dialog.open(ConfirmDialogComponent, {
          data: {
            header: 'Discard Changes?',
            body: result.message,
            note: '',
            button1: 'Cancel',
            button2: 'Ok'
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result === 'yes') {
            this.commonService.showSnackBar({
              type: 'warning',
              message: this.teamAbortMessage
            });
            this.router.navigateByUrl('home/workforce/team-management');
          }
        });
      });
  }

  get productOwners() {
    return this.productForm.get('productOwners') as FormArray;
  }

  get teamLeadDelegates() {
    return this.productForm.get('teamLeadDelegates') as FormArray;
  }
  get teamLeadName() {
    return this.productForm.get('teamLeadName') as FormArray;
  }

  get memberForActive() {
    return this.memberForm.get('memberArray') as FormArray;
  }

  get memberControlForNonSummary() {
    return this.memberFormForNonSummary.get('memberArray') as FormArray;
  }


  checkTeamNameExist(teamName) {
    this.isTeamNameExist = false;
    const params = new HttpParams()
      .set('platform', this.selectedPlatformIndex)
      .set('teamName', teamName);
    this.restService.get(`people/team/teammanagement/name?${params}`).subscribe(data => this.isTeamNameExist = data);
  }

  platformOnChangeEvent(platformIndex) {
    this.goToMemebers = false;
    this.isErrorExists = false;
    this.selectedPlatformIndex = platformIndex;
    this.leadDelegateFormControl.patchValue('');
    this.BizProductOwnerFormControl.patchValue('');
    this.setPlatformDropdownForMembers(this.selectedPlatformIndex);
    const platforms = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    this.restService.get(`/people/data/subPlatforms/list/${platformIndex}`).subscribe(data => {
      this.subPlatformList = data;
      this.productForm.controls.subPlatformName.enable();
      this.productForm.controls.tribeName.enable();
      this.subPlatformList.length === 1 ? this.productForm.controls.subPlatformName.patchValue(this.subPlatformList[0].subPlatformName) : this.productForm.controls.subPlatformName.patchValue('');;
      this.productForm.controls.tribeName.enable();
      this.productForm.controls.teamName.enable();
      this.productForm.controls.teamName.patchValue('');
      this.leadFormControl.enable();
      this.leadDelegateFormControl.enable();

    });
    this.restService.post(`/people/data/employee/byPlatform`, { techUnits: lobts, platforms: [platformIndex], location: locations, rptPeriod: '' }).subscribe(data => {
      this.employeeList = data;
      this.membersList = data;
      this.leadFormControl.patchValue('');
      this.employeeList.forEach(e=>{
        e.oneBankId === this.loggedInUserId ? this.leadFormControl.patchValue(this.loggedInUserId) : '';
      })

      this.setMemberData(this.membersList);
      this.setLeadData(this.employeeList);
      this.setLeadDelegateData(this.employeeList);
    });
    let list = [''];
    this.restService.post(`/people/team/teammanagement/getTechAndBusinessResourceName?platformIndex=${this.selectedPlatformIndex}&searchString=a`,list).subscribe(data => {
      this.bizEmployeeList = data;
      this.setBizProductOwnerData(this.bizEmployeeList);
    });
    this.restService.get(`/people/data/tribe-masters/by-platform?platform=${platformIndex}`).subscribe(res => {
      this.tribeNameList = res;
      this.tribeNameList.length === 1 ? this.productForm.controls.tribeName.patchValue(this.tribeNameList[0].tribeName) : this.productForm.controls.subPlatformName.patchValue('');
    });
  }

  setPlatformDropdownForMembers(platform) {
    this.platformGroups = [
      {
        name: 'Core',
        platform: [

        ]
      },
      {
        name: 'Augumented',
        platform: [
        ]
      }
    ];
    this.platformList.forEach(e => {
      if (e.platformIndex === platform) {
        this.platformGroups[0].platform.push({ value: e });
      } else {
        this.platformGroups[1].platform.push({ value: e });
      }
    });
  }
  setLeadData(employeeList) {
    this.filteredLeadData.next(this.employeeList.slice());
    this.LeadSearchControl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterTeamLead();
      });
  }

  setLeadDelegateData(employeeList) {
    this.filteredLeadDelegateData.next(this.employeeList.slice());
    this.LeadDelegateSearchControl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterTeamLeadDelegateData();
      });
  }

  setBizProductOwnerData(employeeList) {
    this.filteredBizProductOwnerData.next(this.bizEmployeeList.slice());
    this.BizProductOwnerSeachControl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterBizProductOwnerData();
      });
  }

  setMemberData(memberList) {
    this.filteredMemberData.next(this.membersList.slice());
    this.memberSearchControl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterMember();
      });
  }


  datefetch() {
    const today = new Date();
    const nextMonday = new Date();
    this.dateListForMembersStartDate = [];
    // Can change 1 To get Mon-1, Tue-2... Sun-7
    nextMonday.setDate((today.getDate() + (1 + 7 - today.getDay()) % 7));
    if (today.getTime() == nextMonday.getTime()) {
      this.setDate = moment(nextMonday).format('DD MMMM,YYYY').toString();
      this.memberFormControl.enable();
    } else {
      this.setDate = '';
    }
    this.dateListForMembersStartDate.push(moment(nextMonday).format('DD MMMM,YYYY').toString());
    for (let i = 0; i < 3; i++) {
      today.setTime(nextMonday.getTime() + (7 * 24 * 60 * 60 * 1000));
      this.dateListForMembersStartDate.push(moment(today).format('DD MMMM,YYYY').toString());
      nextMonday.setTime(today.getTime() + (7 * 24 * 60 * 60 * 1000));
    }
  }

  // convenience getters for easy access to form fields
  get f() {
    return this.productForm.controls;
  }

  get t() {
    return this.productForm.controls.teamLeadDelegates as FormArray;
  }

  get planTeamControl() {
    return this.planTeam.get('teamRoles') as FormArray;
  }



  /*function for member tab view when dialoge box closed*/
  membersTabView() {
    this.showStepper = false;
    this.showIfMembers = true;
    this.minWidthValue = true;
  }

  /* setting view when members tab is selcted*/
  selectedTab(selected) {

    this.isErrorExists = false;
    if (this.selectedPlatformIndex !== undefined) {
      this.goToMemebers = false;
      if (selected.index == 2) {
        this.dataService.loaderHandler(true);
        this.minWidthValue = true;
        this.showIfMembers = true;
        let ctrl = this.planTeam.get('teamRoles') as FormArray;
        this.totalFte = 0;
        this.totalCost = 0;
        ctrl.value.forEach(element => {
          this.totalFte = +this.totalFte + (+element.fte);
          this.totalCost = this.totalCost + element.blendedCost;
        });
        this.datefetch();
        this.platformOnChangeEventForMembersTab(this.selectedPlatformIndex);
      } else {
        this.showIfMembers = false;
        this.minWidthValue = false;
        // document.getElementById("staffpool").style.display = "none";
      }
    } else {
      this.goToMemebers = true;
      this.commonService.showSnackBar({
        type: 'alert',
        message: 'Platform must be selected'
      });
    }
  }



  toggleSelectForLead(selectValue: boolean) {
    this.filteredLeadData.pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(val => {
        if (selectValue) {
          this.leadFormControl.patchValue(val);
        } else {
          this.leadFormControl.patchValue([]);
        }
      });
  }

  toggleSelectForLeadDelegate(selectValue: boolean) {
    this.filteredLeadDelegateData.pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(val => {
        if (selectValue) {
          this.leadDelegateFormControl.patchValue(val);
        } else {
          this.leadDelegateFormControl.patchValue([]);
        }
      });
  }


  toggleSelectForBizProductOwner(selectValue: boolean) {
    this.filteredBizProductOwnerData.pipe()
      .subscribe(val => {
        if (selectValue) {
          this.BizProductOwnerFormControl.patchValue(val);
        } else {
          this.BizProductOwnerFormControl.patchValue([]);
        }
      });
  }

  toggleSelectForMember(selectValue: boolean) {
    this.filteredMemberData.pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(val => {
        if (selectValue) {
          this.memberFormControl.patchValue(val);
        } else {
          this.memberFormControl.patchValue([]);
        }
      });
  }

  private filterTeamLead() {
    if (!this.employeeList) {
      return;
    }
    // get the search keyword
    let search = this.LeadSearchControl.value;
    if (!search) {
      this.filteredLeadData.next(this.employeeList.slice());
      return;
    } else {
      search = search.toLowerCase().trim();
    }
    // filter the banks
    const a = [].concat.apply([], [this.leadFormControl.value, this.leadDelegateFormControl.value, this.BizProductOwnerFormControl.value]);
    this.filteredLeadData.next(
      this.employeeList.filter(bank => bank.oneBankId.toLowerCase().indexOf(search) > -1 && !a.includes(bank.oneBankId))
    );
  }

  private filterTeamLeadDelegateData() {
    if (!this.employeeList) {
      return;
    }
    // get the search keyword
    let search = this.LeadDelegateSearchControl.value;
    if (!search) {
      this.filteredLeadDelegateData.next(this.employeeList.slice());
      return;
    } else {
      search = search.toLowerCase().trim();
    }
    // filter the banks
    const listOfId = [].concat.apply([], [this.leadFormControl.value, this.BizProductOwnerFormControl.value]);

    this.filteredLeadDelegateData.next(
      this.employeeList.filter(bank => bank.oneBankId.toLowerCase().indexOf(search) > -1 && !listOfId.includes(bank.oneBankId))
    );
  }


  private filterBizProductOwnerData() {
    if (!this.bizEmployeeList) {
      return;
    }
    // get the search keyword
    let search = this.BizProductOwnerSeachControl.value;
    if (!search) {
      this.filteredBizProductOwnerData.next(this.bizEmployeeList.slice());
      return;
    } else {
      search = search.toLowerCase().trim();
    }
    const listOfId = [].concat.apply([], [this.leadFormControl.value, this.leadDelegateFormControl.value]);
    // filter the banks
    this.filteredBizProductOwnerData.next(
      this.bizEmployeeList.filter(bank => bank.oneBankId.toLowerCase().indexOf(search) > -1 && !listOfId.includes(bank.oneBankId))
    );
  }

  private filterMember() {
    if (!this.membersList) {
      return;
    }
    // get the search keyword
    let search = this.memberSearchControl.value;
    if (!search) {
      this.filteredMemberData.next(this.membersList.slice());
      return;
    } else {
      search = search.toLowerCase().trim();
    }
    // filter the banks
    const listOfId: any = [];
    this.selectedStaffList.forEach(e => {
      listOfId.push(e.oneBankId);
    });
    this.filteredMemberData.next(
      this.membersList.filter(bank => (bank.oneBankId.toLowerCase().indexOf(search) > -1 || bank.empName.toLowerCase().indexOf(search) > -1) && listOfId.indexOf(bank.oneBankId) < 0)
    );
  }

  uniqueSetOfData() {
    return [].concat.apply([], [this.leadFormControl.value, this.leadDelegateFormControl.value]).filter(function (elem, index, self) {
      return self.indexOf(elem) === index && elem != null;
    });
  }

  platformOnChangeEventForMembersTab(platformIndex) {
    const lobts = JSON.parse(sessionStorage.getItem('selectedLobts'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    this.resetConditions();
    this.datefetch();
    this.dataService.loaderHandler(false);
    this.restService.post(`/people/data/employee/byPlatform`, { techUnits: lobts, platforms: [platformIndex], location: locations, rptPeriod: '' }).subscribe(data => {
      this.membersList = data;
      this.setMemberData(this.membersList);
    });
  }
  memberStaffSelection(staff) {
    // need to send oneBankId,StaffDate to fetch fte, blended rate
    this.isErrorExists = false;
    this.fteForMember = 0;
    this.roleFormControl.patchValue('');
    this.roleSelected = '';
    this.roleFormControl.disable();
    this.selectedEmployee = this.membersList.filter(e => e.oneBankId == staff);
    const date = moment(new Date(this.setDate)).format('DD-MM-YYYY');
    this.restService.get(`people/team/teammanagement/getAvailabilityAndCostForTeamMember?oneBankId=${this.selectedEmployee[0].oneBankId}&effectiveStartDate=${date}`).subscribe(data => {
      if (data) {
        this.fteForMember = data['availableFte'] ? data.availableFte / 100 : 0;
        this.chargeableFlag = data.chargeableCost;
        this.notionalFlag = data.notionalCost;
        this.blendedRate = data.staffRate;
        this.ccyCode = data.ccyCode;
        if (this.fteForMember < 0.2) {
          this.commonService.showSnackBar({
            type: 'alert',
            message: "Member can't be added. Available FTE is lower than 0.2"
          });
        }
      } else {
        this.commonService.showSnackBar({
          type: 'alert',
          message: "Unable to fetch FTE"
        });
      }
    });
    this.roleFormControl.enable();
    this.checkAddButtonFlag = false;
    this.roleSelection(this.roleSelected);
  }
  roleSelection(role) {
    this.roleSelected = role;
    if (this.fteForMember >= 0.2)
      this.checkAddButtonFlag = true;
  }
  enablingStaffToSelect(effectiveStartDate) {
    this.memberFormControl.enable();
    this.memberFormControl.patchValue('');
    this.checkAddButtonFlag = false;
    this.fteForMember = 0;
    this.roleFormControl.patchValue('');
    this.roleFormControl.disable();
    this.setDate = effectiveStartDate;
  }

  addMember() {
    let charge;
    this.chargeableFlag ? charge = 'Chargeable' : this.notionalFlag ? charge = 'Notional' : charge = 'None';
    const today = new Date();
    const nextMonday = new Date();
    nextMonday.setDate((today.getDate() + (1 + 7 - today.getDay()) % 7));
    if (today.getTime() == nextMonday.getTime() && this.setDate.toString() === this.dateListForMembersStartDate[0]) {
      const control = this.memberForm.controls.memberArray as FormArray;
      control.push(this.fb.group({
        staffName: [this.selectedEmployee[0].empName],
        oneBankId: [this.selectedEmployee[0].oneBankId],
        fte: [this.fteForMember],
        staffType: [this.selectedEmployee[0].empType],
        teamRole: [this.roleSelected],
        platform: [this.selectedEmployee[0].platform],
        staffPlatformIndex: [this.selectedEmployee[0].platformIndex],
        subPlatform: [this.selectedEmployee[0].subPlatform],
        countryCode: [this.selectedEmployee[0].countryCode],
        workLocation: [this.selectedEmployee[0].workLocation],
        chargeType: [charge],
        blendedRate: [this.blendedRate],
        effectiveStartDate: [this.setDate],
        effectiveEndDate: '',
        teamPlatformIndex: [this.selectedPlatformIndex],
        reportingPeriod: '202004',
        augmentedInd: this.selectedPlatformIndex !== this.selectedEmployee[0].platformIndex ? 'Core' : 'Augmented',
        ccyCode: this.ccyCode
      }));
      this.dataSourceForSummary = new MatTableDataSource();
      this.dataSourceForSummary.data = control.value;
      this.setCumulativeDataForSummary(this.selectedEmployee[0], this.blendedRate, this.fteForMember, Object.assign(this.setDate), charge);
    } else {
      const control = this.memberFormForNonSummary.controls.memberArray as FormArray;
      control.push(this.fb.group({
        staffName: [this.selectedEmployee[0].empName],
        oneBankId: [this.selectedEmployee[0].oneBankId],
        fte: [this.fteForMember],
        staffType: [this.selectedEmployee[0].empType],
        teamRole: [this.roleSelected],
        platform: [this.selectedEmployee[0].platform],
        staffPlatformIndex: [this.selectedEmployee[0].platformIndex],
        subPlatform: [this.selectedEmployee[0].subPlatform],
        countryCode: [this.selectedEmployee[0].countryCode],
        workLocation: [this.selectedEmployee[0].workLocation],
        chargeType: [charge],
        blendedRate: [this.blendedRate],
        effectiveStartDate: [this.setDate],
        effectiveEndDate: '',
        teamPlatformIndex: [this.selectedPlatformIndex],
        reportingPeriod: this.rptPeriod,
        augmentedInd: this.selectedPlatformIndex !== this.selectedEmployee[0].platformIndex ? 'Core' : 'Augmented',
        ccyCode:this.ccyCode
      }));
      this.dataSourceForNonSummary = new MatTableDataSource();
      this.dataSourceForNonSummary.data = control.value;
    }
    this.setWarningMessage();
    this.selectedStaffList.push({
      oneBankId: this.selectedEmployee[0].oneBankId,
      fte: this.fteForMember
    });
    this.resetConditions();
    this.datefetch();
  }
  setWarningMessage(){
    this.isErrorExists=false;
    this.fteFlag = false;
    this.costFlag = false;
    let message = '';
    this.augmentedMemberCumulatives.fte + this.coreMemberCumulatives.fte > this.totalFte ? this.fteFlag = true : this.fteFlag = false;
    this.augmentedMemberCumulatives.overallTeamCostPerDay + this.coreMemberCumulatives.overallTeamCostPerDay > this.totalCost ? this.costFlag = true : this.costFlag = false;
    if(this.fteFlag && this.costFlag){
      message = this.fteAndCostExcessMessage;
      this.isErrorExists = true;
    }else if(this.fteFlag){
      message = this.fteExcessMessage;
      this.isErrorExists = true;
    } else if(this.costFlag){
      message = this.costExcessMessage;
      this.isErrorExists = true;
    }
    if(this.costFlag || this.fteFlag) {
      this.commonService.showSnackBar({
        type: 'warning',
        message: message
      });
    }
  }
  resetConditions() {
    this.memberFormControl.disable();
    this.memberFormControl.patchValue('');
    this.roleFormControl.disable();
    this.roleFormControl.patchValue('');
    this.checkAddButtonFlag = false;
    this.fteForMember = 0;
    this.chargeableFlag = false;
    this.notionalFlag = false;
    this.blendedRate = 0.0;
    this.roleSelected = '';
  }

  checkFTE(employee, fteValue, index) {
    fteValue = parseFloat(fteValue).toFixed(2);
    const control = this.memberForm.controls.memberArray as FormArray;
    const defaultEmployee = this.selectedStaffList.filter(e => e.oneBankId === employee.oneBankId);
    if (fteValue < 0.2 || fteValue > defaultEmployee[0].fte || fteValue > 1) {
      ((this.memberForm.get('memberArray') as FormArray).at(index) as FormGroup).get('fte').patchValue(parseFloat(defaultEmployee[0].fte).toFixed(2));
    } else {
      this.updateCumulativeDataForSummary(control.value[index], control.value[index].blendedRate, fteValue, Object.assign(control.value[index].effectiveStartDate), control.value[index].chargeType, this.dataSourceForSummary.data[index].fte);
      ((this.memberForm.get('memberArray') as FormArray).at(index) as FormGroup).get('fte').patchValue(fteValue);
    }
    this.setWarningMessage();
    this.dataSourceForSummary.data = control.value;
  }
  checkFTEForNonSummary(employee, fteValue, index) {
    fteValue = parseFloat(fteValue).toFixed(2);
    const control = this.memberFormForNonSummary.controls.memberArray as FormArray;
    const defaultEmployee = this.selectedStaffList.filter(e => e.oneBankId === employee.oneBankId);
    if (fteValue < 0.2 || fteValue > defaultEmployee[0].fte || fteValue > 1) {
      ((this.memberFormForNonSummary.get('memberArray') as FormArray).at(index) as FormGroup).get('fte').patchValue(parseFloat(defaultEmployee[0].fte).toFixed(2));
    } else {
      ((this.memberFormForNonSummary.get('memberArray') as FormArray).at(index) as FormGroup).get('fte').patchValue(fteValue);
    }
    this.dataSourceForNonSummary.data = control.value;
  }

  summaryDetailView() {
    this.expansion ? this.expansion = false : this.expansion = true;
  }
  setCumulativeDataForSummary(employee, blendedRate, fte, assignedDate, chargeType) {
    if (assignedDate.toString() === this.dateListForMembersStartDate[0]) {
      if (employee.platform == this.platformGroups[0].platform[0].value.platformName) {
        this.coreMemberCumulatives.members = this.coreMemberCumulatives.members + 1;
        this.coreMemberCumulatives.fte = +(+this.coreMemberCumulatives.fte + (+fte)).toFixed(2);
        this.coreMemberCumulatives.overallTeamCostPerDay = +(this.coreMemberCumulatives.overallTeamCostPerDay + (blendedRate * fte)).toFixed(2);
        this.coreMemberCumulatives.overallTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDay * this.manDaysPerMonth).toFixed(2);
        if (chargeType == 'Notional') {
          this.coreMemberCumulatives.overallTeamCostPerDayNotional = +(this.coreMemberCumulatives.overallTeamCostPerDayNotional + (blendedRate * fte)).toFixed(2);
          this.coreMemberCumulatives.notionalTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDayNotional * this.manDaysPerMonth).toFixed(2);
        } else if (chargeType == 'Chargeable') {
          this.coreMemberCumulatives.overallTeamCostPerDayChargeable = +(this.coreMemberCumulatives.overallTeamCostPerDayChargeable + (blendedRate * fte)).toFixed(2);
          this.coreMemberCumulatives.chargeableTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDayChargeable * this.manDaysPerMonth).toFixed(2);
        }
      } else {
        this.augmentedMemberCumulatives.members = this.augmentedMemberCumulatives.members + 1;
        this.augmentedMemberCumulatives.fte = +(+this.augmentedMemberCumulatives.fte + (+fte)).toFixed(2)
        this.augmentedMemberCumulatives.overallTeamCostPerDay = +(this.augmentedMemberCumulatives.overallTeamCostPerDay + (blendedRate * fte)).toFixed(2);
        this.augmentedMemberCumulatives.overallTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDay * this.manDaysPerMonth).toFixed(2);
        if (chargeType == 'Notional') {
          this.augmentedMemberCumulatives.overallTeamCostPerDayNotional = +(this.augmentedMemberCumulatives.overallTeamCostPerDayNotional + (blendedRate * fte)).toFixed(2);
          this.augmentedMemberCumulatives.notionalTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDayNotional * this.manDaysPerMonth).toFixed(2);
        } else if (chargeType == 'Chargeable') {
          this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable = +(this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable + (blendedRate * fte)).toFixed(2);
          this.augmentedMemberCumulatives.chargeableTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable * this.manDaysPerMonth).toFixed(2);
        }
      }
    }
  }
  filterMemberStaff() {
    const listOfId = [];
    this.selectedStaffList.forEach(e => {
      listOfId.push(e.oneBankId);
    });
    this.filteredMemberData.next(
      this.membersList.filter(bank => listOfId.indexOf(bank.oneBankId) < 0)
    );
  }
  filterTechLeadDelegateStaff() {
    const listOfId = [].concat.apply([], [this.leadFormControl.value, this.BizProductOwnerFormControl.value]);
    this.filteredLeadDelegateData.next(
      this.employeeList.filter(bank => !listOfId.includes(bank.oneBankId))
    );
  }
  filterTechLeadStaff() {
    const listOfId = [].concat.apply([], [this.leadFormControl.value, this.leadDelegateFormControl.value, this.BizProductOwnerFormControl.value]);
    this.filteredLeadData.next(
      this.employeeList.filter(bank => !listOfId.includes(bank.oneBankId))
    );
  }

  filterBizStaff() {
    // this.fetchBizPeople();
    const listOfId = [].concat.apply([], [this.leadFormControl.value, this.leadDelegateFormControl.value]);
    this.filteredBizProductOwnerData.next(
      this.bizEmployeeList.filter(bank => !listOfId.includes(bank.oneBankId))
    );
  }
  updateCumulativeDataForSummary(employee, blendedRate, newFte, assignedDate, chargeType, oldFte) {
    if (assignedDate.toString() === this.dateListForMembersStartDate[0]) {
      if (employee.platform == this.platformGroups[0].platform[0].value.platformName) {
        this.coreMemberCumulatives.fte = +(+this.coreMemberCumulatives.fte - (+oldFte) + (+newFte)).toFixed(2);
        this.coreMemberCumulatives.overallTeamCostPerDay = +(this.coreMemberCumulatives.overallTeamCostPerDay - (+(blendedRate * oldFte).toFixed(2)) + (+(blendedRate * newFte).toFixed(2))).toFixed(2);
        this.coreMemberCumulatives.overallTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDay * this.manDaysPerMonth).toFixed(2);
        if (chargeType === 'Notional') {
          this.coreMemberCumulatives.overallTeamCostPerDayNotional = +(this.coreMemberCumulatives.overallTeamCostPerDayNotional - (+(blendedRate * oldFte).toFixed(2)) + (+(blendedRate * newFte).toFixed(2))).toFixed(2);
          this.coreMemberCumulatives.notionalTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDayNotional * this.manDaysPerMonth).toFixed(2);
        } else if (chargeType === 'Chargeable') {
          this.coreMemberCumulatives.overallTeamCostPerDayChargeable = +(this.coreMemberCumulatives.overallTeamCostPerDayChargeable - (+(blendedRate * oldFte).toFixed(2)) + (+(blendedRate * newFte).toFixed(2))).toFixed(2);
          this.coreMemberCumulatives.chargeableTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDayChargeable * this.manDaysPerMonth).toFixed(2);
        }
      } else {
        this.augmentedMemberCumulatives.fte = +(+this.augmentedMemberCumulatives.fte - (+oldFte) + (+newFte)).toFixed(2);
        this.augmentedMemberCumulatives.overallTeamCostPerDay = +(this.augmentedMemberCumulatives.overallTeamCostPerDay - (+(blendedRate * oldFte).toFixed(2)) + (+(blendedRate * newFte).toFixed(2))).toFixed(2);
        this.augmentedMemberCumulatives.overallTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDay * this.manDaysPerMonth).toFixed(2);
        if (chargeType == 'Notional') {
          this.augmentedMemberCumulatives.overallTeamCostPerDayNotional = +(this.augmentedMemberCumulatives.overallTeamCostPerDayNotional - (+(blendedRate * oldFte).toFixed(2)) + (+(blendedRate * newFte).toFixed(2))).toFixed(2);
          this.augmentedMemberCumulatives.notionalTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDayNotional * this.manDaysPerMonth).toFixed(2);
        } else if (chargeType == 'Chargeable') {
          this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable = +(this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable - (+(blendedRate * oldFte).toFixed(2)) + (+(blendedRate * newFte).toFixed(2))).toFixed(2);
          this.augmentedMemberCumulatives.chargeableTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable * this.manDaysPerMonth).toFixed(2);
        }
      }
    }
  }

  fetchBizPeople() {
    let list = this.BizProductOwnerFormControl.value.length > 0 ? this.BizProductOwnerFormControl.value : [''];
    this.restService.post(`/people/team/teammanagement/getTechAndBusinessResourceName?platformIndex=${this.selectedPlatformIndex}&searchString=${this.BizProductOwnerSeachControl.value}`,list).subscribe(data => {
      this.bizEmployeeList = data;
      this.filterBizProductOwnerData();
    });
  }

  deleteStaffForSummary(index, employee) {
    let message = this.deleteMessage;
    message = message.replace("<Staff Name>",employee.staffName)
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Remove Member?',
        body: message,
        note: '',
        button1: 'Cancel',
        button2: 'OK'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        const control = this.memberForm.controls.memberArray as FormArray;
        this.updateCumulativeDataForSummaryAfterDelete(employee, control.value[index].blendedRate, control.value[index].fte, Object.assign(control.value[index].effectiveStartDate), control.value[index].chargeType);
        control.removeAt(index);
        this.setWarningMessage();
        this.selectedStaffList.splice(index);
        this.dataSourceForSummary.data = control.value;
      }
    });


  }

  deleteStaffForNonSummary(index, employee) {
    let message = this.deleteMessage;
    message = message.replace("<Staff Name>",employee.staffName)
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Remove Member?',
        body: message,
        note: '',
        button1: 'Cancel',
        button2: 'OK'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        const control = this.memberFormForNonSummary.controls.memberArray as FormArray;
        control.removeAt(index);
        this.selectedStaffList.splice(index);
        this.dataSourceForNonSummary.data = control.value;
      }
    });
  }

  updateCumulativeDataForSummaryAfterDelete(employee, blendedRate, fte, assignedDate, chargeType) {
    if (assignedDate.toString() === this.dateListForMembersStartDate[0]) {
      if (employee.platform == this.platformGroups[0].platform[0].value.platformName) {
        this.coreMemberCumulatives.members = +this.coreMemberCumulatives.members - 1;
        this.coreMemberCumulatives.fte = +(+this.coreMemberCumulatives.fte - (+fte)).toFixed(2);
        this.coreMemberCumulatives.overallTeamCostPerDay = +(this.coreMemberCumulatives.overallTeamCostPerDay - (+(blendedRate * fte).toFixed(2))).toFixed(2);
        this.coreMemberCumulatives.overallTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDay * this.manDaysPerMonth).toFixed(2);
        if (chargeType == 'Notional') {
          this.coreMemberCumulatives.overallTeamCostPerDayNotional = +(this.coreMemberCumulatives.overallTeamCostPerDayNotional - (+(blendedRate * fte).toFixed(2))).toFixed(2);
          this.coreMemberCumulatives.notionalTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDayNotional * this.manDaysPerMonth).toFixed(2);
        } else if (chargeType == 'Chargeable') {
          this.coreMemberCumulatives.overallTeamCostPerDayChargeable = +(this.coreMemberCumulatives.overallTeamCostPerDayChargeable - (+(blendedRate * fte).toFixed(2))).toFixed(2);
          this.coreMemberCumulatives.chargeableTeamCostPerMonth = +(this.coreMemberCumulatives.overallTeamCostPerDayChargeable * this.manDaysPerMonth).toFixed(2);
        }
      } else {
        this.augmentedMemberCumulatives.members = +this.augmentedMemberCumulatives.members - 1;
        this.augmentedMemberCumulatives.fte = +(+this.augmentedMemberCumulatives.fte - (+fte)).toFixed(2);
        this.augmentedMemberCumulatives.overallTeamCostPerDay = +(this.augmentedMemberCumulatives.overallTeamCostPerDay - (+(blendedRate * fte).toFixed(2))).toFixed(2);
        this.augmentedMemberCumulatives.overallTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDay * this.manDaysPerMonth).toFixed(2);
        if (chargeType == 'Notional') {
          this.augmentedMemberCumulatives.overallTeamCostPerDayNotional = +(this.augmentedMemberCumulatives.overallTeamCostPerDayNotional - (+(blendedRate * fte).toFixed(2))).toFixed(2);
          this.augmentedMemberCumulatives.notionalTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDayNotional * this.manDaysPerMonth).toFixed(2);
        } else if (chargeType == 'Chargeable') {
          this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable = +(this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable - (+(blendedRate * fte).toFixed(2))).toFixed(2);
          this.augmentedMemberCumulatives.chargeableTeamCostPerMonth = +(this.augmentedMemberCumulatives.overallTeamCostPerDayChargeable * this.manDaysPerMonth).toFixed(2);
        }
      }
    }
  }


}
