import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonService } from "src/app/common/service/common.service";
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-report',
    templateUrl: 'report.component.html',
    styleUrls: ['report.component.scss']
})

export class ReportComponent implements OnInit {

    tabObeserver: Subscription;
    curTab: string;

    headerInfo = {
        title: "Reports",
        tabs: ['Workforce Management', 'Portfolio Management']
    }

    constructor(private commonService: CommonService) {
        this.commonService.recieveMessage(this.headerInfo);
        this.curTab = this.headerInfo.tabs[0];
        this.commonService.setDocumentTitle('REPORTS');
        this.commonService.trackPageView();
    }

    ngOnInit() {

        // for updating tabs
        this.tabObeserver = this.commonService.selectedTab.subscribe(data => {
            this.curTab = data;
        })
    }

    ngOnDestroy() {
        this.tabObeserver.unsubscribe();
    }
}
