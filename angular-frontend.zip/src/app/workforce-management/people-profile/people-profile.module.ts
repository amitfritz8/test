import { NgModule } from "@angular/core"
import { Routes, RouterModule } from "@angular/router"
import { MaterialModule } from "src/app/material.module";
import { SharedModule } from "src/app/common/module/shared.module";

import { PeopleProfileComponent } from "./people-profile.component";
import { PeopleAdditionalInfoComponent } from "./people-additional-info/people-additional-info.component";
import { PeopleProfileRoutingModule } from "./people-profile-routing.module";
import { PeopleResolver } from "./people.resolver";

@NgModule({
    imports: [
        PeopleProfileRoutingModule,
        MaterialModule,
        SharedModule
    ],
    declarations:[PeopleProfileComponent, PeopleAdditionalInfoComponent],
    providers: [PeopleResolver]
})
export class PeopleModule{}
