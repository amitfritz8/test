import { Component, OnInit, OnDestroy, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { RestService } from 'src/app/common/service/rest.service';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table'
import { DateUtility } from 'src/app/common/utility/date-utility';
import { DataService } from 'src/app/common/service/data.service';
import { TimeFormat } from 'src/app/common/pipes/timeFormater.pipe';
import { CommonDialogComponent } from 'src/app/common/component/dialogues/common-dialog/common-dialog-component';
import { map, startWith } from 'rxjs/operators';
import { Observable, Subscription } from 'rxjs';
import * as moment from 'moment';
import {controllers} from 'chart.js';
import { CommonService } from "src/app/common/service/common.service";
import {RxwebValidators} from '@rxweb/reactive-form-validators';
import * as _ from 'lodash';

@Component({
  selector: 'app-people-additional-info',
  templateUrl: './people-additional-info.component.html',
  styleUrls: ['./people-additional-info.component.scss'],
})
export class PeopleAdditionalInfoComponent implements OnInit, OnDestroy {
  sort: any;
  tabs = ["Overview", "Teams & Individual Contribution", "Chapter"];
  contractDisplayedColumns = ['Company Name', 'Contract Start Date', 'Contract End Date', 'MCR Number', 'PO Number', 'Contract Status'];

  teamsDisplayedColumns = ['Team Type', 'Name', 'Details', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  ChaptersDisplayedColumns = ['chapterName', 'status', 'chapterLead', 'chapterLeadOnebankId'];
  paginator: any;
  work2: boolean;
  checked = true;
  arrowNotClicked = true;
  monthArray = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  selectedMonth = 0;

  contractemp = false;
  oneBankId: any;
  surrId: any;
  reportingPeriod: any;
  dates = ['2019', '2020'];
  selectedDate: string; // year for selection
  teamsDataSource: MatTableDataSource<Team>;
  contractDataSource: MatTableDataSource<Contract>;
  chapterDataSource: MatTableDataSource<any>;
  individualAndTeamDataSource: MatTableDataSource<Team>;
  individualTeamResponseObjArray: any;
  reportingMonth: string;

  platform: any;

  peopleForm: FormGroup;
  chapterForm: FormGroup;

  dropDownData: any = {};
  refDataForDropDown: any;
  isErrorExists = false;
  message: any;
  showWorkType2 = false;
  chaptersData: any;
  initialChapterData: any;
  dropDownChapterList: any;
  filterDropdown: any;
  chapterNames: any;
  private currentMonthStatus: boolean = false;
  private updatePreviousMonth: boolean = false;
  private updateNextMonth: boolean = false;
  private updateBoth: boolean = false;
  headerInfo: any;
  selectedTab: string;

  action = 'view';
  summaryForm: FormGroup;
  submitted = false;
  dataSummary: any;
  detailsview = false;
  roleType: any;
  modulesMapping: any;
  editAccess = false;
  reportingPeriodDate = '';
  subPlatformData: any;
  filteredSubPlatformData: Observable<any>;
  userAccessCheckValue = false;
  editWindowPeriod = '';
  nextMonthUpdateConfirmationMessage = '';
  previousMonthUpdateConfirmationMessage = '';

  private loggedInUserBankId: string | null;
  private noData: boolean = false;
  techUnit: any;
  peopleSubscription: any;
  peopleData: any;

  changeInForm: boolean = false;

  // observers
  tabObserver: Subscription;

  constructor(private activatedRoute: ActivatedRoute, private fb: FormBuilder, private dateUtility: DateUtility, private dataService: DataService, private router: Router,
    private restService: RestService, public dialog: MatDialog, public formattime: TimeFormat, private commonService: CommonService,
    private route: ActivatedRoute, private el: ElementRef) {
    this.oneBankId = dataService.getPassingOneBankId();
    this.reportingPeriod = dataService.getReportingPeriod();
    this.surrId = dataService.getSurrId();
    this.teamsDataSource = new MatTableDataSource();
    this.contractDataSource = new MatTableDataSource();
    this.chapterDataSource = new MatTableDataSource();
    this.individualAndTeamDataSource = new MatTableDataSource();

    this.headerInfo = {
      show_filters: false,
      nav_bk_url: "people-profile",
      nav_bk_info: "People Profile",
      avatar: true,
      tabs: this.tabs,
      btns: {}
    }

    this.selectedTab = this.tabs[0];

    // for updating tabs
    this.tabObserver = this.commonService.selectedTab.subscribe(data => {
      // navigating other tabs in edit mode
      if(this.action === 'edit'){
        const dialogRef = this.openWarningDialog();
        dialogRef.afterClosed().subscribe(result => {
          if (result === 'yes') {
            if(this.selectedTab == 'Chapter'){
              this.resetChapterForm();
            }
            this.selectedTab = data;
            this.updateHeaderButtons();
            this.action = 'view';
          } else {
            this.forceNavigateToTab(this.selectedTab);
          }
        });
      } else {
        this.selectedTab = data;
        this.updateHeaderButtons();
      }
    })

    // reload page after submit, without refresh
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  loadUrlData(){
    return this.restService.get(`/people/data/employee/profile?id=${this.dataService.getPassingOneBankId()}
    &reportingPeriod=${this.dataService.getReportingPeriod()}&surrId=${this.dataService.getSurrId()}`);
  }

  forceNavigateToTab(tab: string){
    let tempHeader = Object.assign({}, this.headerInfo);
    tempHeader.prevent_idx_update = true;
    this.commonService.updateTab.emit(tab);
    this.commonService.recieveMessage(tempHeader);
  }

  reloadPage(){
    this.router.navigated = false;
    this.router.navigateByUrl('home/workforce/people-profile/additionalInfo');
  }

  updateHeaderInfo() {
    this.headerInfo.title = this.dataSummary.staffName;
    this.headerInfo.additional_info = `${this.dataSummary.modifiedBy ? 'Last edited by ' + this.dataSummary.modifiedBy + ' on ' : ''}
          ${this.dataSummary.dateModified ? this.dateFormat(this.dataSummary.dateModified) + "," : ""}
          ${this.dataSummary.dateModified ? this.timeFormat(this.dataSummary.dateModified) + " | " : ""}
          Data below captured as of ${this.dataSummary.asOfDate ? this.dateFormat(this.dataSummary.asOfDate) : ""}`

    this.updateHeaderButtons();
  }

  updateHeaderButtons(){
    this.headerInfo.btns = {};
    if(this.selectedTab === 'Chapter'){
      this.headerInfo.btns.primary = {
        text: 'Add Chapter',
        clbk: this.addChapter.bind(this)
      };
    }
    if(this.editAccessCheck() && this.selectedTab === 'Overview') {
      this.headerInfo.btns.editclbk = this.editProfile.bind(this)
    }
    this.headerInfo.prevent_idx_update = this.selectedTab === 'Overview' ? false : true;
    this.commonService.recieveMessage(this.headerInfo);
  }

  initDropDownData(){
    this.dropDownData['Type of Work 1'] = this.refDataForDropDown['Type of Work 1'];
    this.dropDownData['Type of Work 2'] = this.refDataForDropDown['Type of Work 2'];
  }

  ngOnInit() {
    this.refDataForDropDown = JSON.parse(sessionStorage.getItem('dataValues'));
    // change intiative to intiatives
    this.dropDownData['Type of Work 1'] = this.refDataForDropDown['Type of Work 1'];
    this.dropDownData['Type of Work 2'] = this.refDataForDropDown['Type of Work 2'];
    let dropdownObj = this.dropDownData['Type of Work 2'].find(obj=>obj.value === 'Initiative');
    if(dropdownObj){
      dropdownObj.value = 'Initiatives';
    }
    this.work2 = this.dropDownData['Type of Work 1'].value != 'Operate' && this.dropDownData['Type of Work 1'].value != 'Build';
    if (this.reportingPeriod) {
      this.selectedDate = this.reportingPeriod
      this.selectedDate = this.selectedDate.substring(0, 4);
    }
    this.loggedInUserBankId = localStorage.getItem('userOneBankId');
    this.createForm();
    this.loadDataValues();
    this.peopleSubscription = this.route.data.subscribe(
      res => {
        // console.warn('log people data >> ', res);
        this.getData(res.peopleData);
      },
      err => {
        console.error(err);
      });

    this.roleType = JSON.parse(sessionStorage.getItem('roles'));
    let roleField = [];
    roleField = Object.keys(JSON.parse(sessionStorage.getItem('roles')))
    this.modulesMapping = JSON.parse(sessionStorage.getItem('modulesMapping'));
    if (this.modulesMapping && this.modulesMapping['WORK_MGT'] && this.modulesMapping['WORK_MGT'].length > 0) {
      this.modulesMapping['WORK_MGT'].forEach(module => {
        if (module.subModule === 'PEOPLE_PROFILE') {
          if(roleField.includes('GENE_DBS_CENTRALFUNCTION') || roleField.includes('GENE_DBS_ADMIN')) {
            this.editAccess = true;
          }
          else {
            this.editAccess = false;
          }
        }
      });
    }
    if (sessionStorage.getItem('rptPeriod')) {
      this.reportingPeriodDate = sessionStorage.getItem('rptPeriod').slice(-2);
    }
    this.action = 'view';
  }

  ngOnDestroy(){
    // release used Resource
    this.tabObserver.unsubscribe();
    if(this.peopleSubscription){
      this.peopleSubscription.unsubscribe();
    }
  }

  populateWeekDetailsArray(month: number, isWeek5: boolean) : string[] {
    let monthIndex = month-1;
    let monthLoopValue = isWeek5 ? 5 : 4;
    let resultArray = [];

    if(monthIndex >= 0 && monthIndex < this.monthArray.length){
      let monthString = this.monthArray[monthIndex];
      for(let i=1; i<=monthLoopValue; i++){
        resultArray.push(monthString + "Week" + i);
      }
    }
    return resultArray;
  }

  setWeekDisplay(month: number){
    let weekArray = [];
    for (let i = 0; i < this.individualTeamResponseObjArray.length; i++) {
      let individualTeamResponseObj = this.individualTeamResponseObjArray[i];
      switch(month){
        case 1:// jan only 4 weeks
          weekArray = this.populateWeekDetailsArray(month, false);
          break;
        case 2:
            weekArray = this.populateWeekDetailsArray(month, individualTeamResponseObj.noOfWeeksFebruary > 4);
          break;
        case 3:
            weekArray = this.populateWeekDetailsArray(month, individualTeamResponseObj.noOfWeeksMarch > 4);
          break;
        case 4:
            weekArray = this.populateWeekDetailsArray(month, individualTeamResponseObj.noOfWeeksApril > 4);
          break;
        case 5:
            weekArray = this.populateWeekDetailsArray(month, individualTeamResponseObj.noOfWeeksMay > 4);
          break;
        case 6:
            weekArray = this.populateWeekDetailsArray(month, individualTeamResponseObj.noOfWeeksJune > 4);
          break;
        case 7:
            weekArray = this.populateWeekDetailsArray(month, individualTeamResponseObj.noOfWeeksJuly > 4);
          break;
        case 8:
            weekArray = this.populateWeekDetailsArray(month, individualTeamResponseObj.noOfWeeksAugust > 4);
          break;
        case 9:
            weekArray = this.populateWeekDetailsArray(month, individualTeamResponseObj.noOfWeeksSeptember > 4);
            break;
        case 10:
          weekArray = this.populateWeekDetailsArray(month, individualTeamResponseObj.noOfWeeksOctober > 4);
          break;
        case 11:
            weekArray = this.populateWeekDetailsArray(month, individualTeamResponseObj.noOfWeeksNovember > 4);
          break;
        case 12:
            weekArray = this.populateWeekDetailsArray(month, individualTeamResponseObj.noOfWeeksDecember > 4);
            break;
      }
    }

    this.teamsDisplayedColumns = ['Team Type', 'Name', 'Details'];
    this.teamsDisplayedColumns.push(...this.monthArray);
    let indexToInsert = this.teamsDisplayedColumns.indexOf(this.monthArray[month-1]) + 1;
    this.teamsDisplayedColumns.splice(indexToInsert, 0, ...weekArray);
  }

  setMonthAndWeekDisplay(month: number){
    if(this.selectedMonth !== month){
      this.setWeekDisplay(month);
      this.arrowNotClicked = false;
      this.selectedMonth = month;
    } else {
      this.teamsDisplayedColumns = ['Team Type', 'Name', 'Details', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      this.arrowNotClicked = true;
      this.selectedMonth = -1;
    }
  }

  janWeekDisplay() {
    this.setMonthAndWeekDisplay(1);
  }

  febWeekDisplay() {
    this.setMonthAndWeekDisplay(2);
  }

  marchWeekDisplay() {
    this.setMonthAndWeekDisplay(3);
  }

  aprilWeekDisplay() {
    this.setMonthAndWeekDisplay(4);
  }

  mayWeekDisplay() {
    this.setMonthAndWeekDisplay(5);
  }

  juneWeekDisplay() {
    this.setMonthAndWeekDisplay(6);
  }

  julyWeekDisplay() {
    this.setMonthAndWeekDisplay(7);
  }

  augustWeekDisplay() {
    this.setMonthAndWeekDisplay(8);
  }

  septemberWeekDisplay() {
    this.setMonthAndWeekDisplay(9);
  }

  octoberWeekDisplay() {
    this.setMonthAndWeekDisplay(10);
  }

  novemberWeekDisplay() {
    this.setMonthAndWeekDisplay(11);
  }

  decemberWeekDisplay() {
    this.setMonthAndWeekDisplay(12);
  }

  userAccessCheck() {
    this.restService.get(`/people/data/employee/userAccessCheck?oneBankId=${this.oneBankId}&loggedInUserBankId=${this.loggedInUserBankId}&rptPeriod=${this.reportingPeriod}`).subscribe(data => {
      if (data) {
        this.userAccessCheckValue = true;
      }
      this.updateHeaderInfo();
    },error=>{
      this.updateHeaderInfo();
      console.error('user access error > ' + error.message);
    });
  }

  compare(a: any, b: any){
    let comparision = 0;
    if(a.subPlatformName > b.subPlatformName) {
      comparision = 1;
    }
    else if(a.subPlatformName < b.subPlatformName) {
      comparision = -1;
    }
    return comparision;
  }

  getUniqueSubPlatformList(subPlatformList : any){
    let list = [];
    if(subPlatformList){
      subPlatformList.forEach(function(platform){
        let isUnique = true;
        list.forEach(function(item){
          if(item.subPlatformName === platform.subPlatformName){
            isUnique = false;
          }
        });
        if(isUnique){
          list.push(platform);
        }
      });
    }
    return list;
  }

  getSubplatformsByPlatformIndex(platformIndex: string) {
    this.restService.get(`/people/data/subPlatforms/list/${platformIndex}`).subscribe(data => {
      this.subPlatformData = this.getUniqueSubPlatformList(data);
      if(!this.subPlatformData.find(element => element.subPlatformName === "Not Applicable")){
        this.subPlatformData.push({subPlatformName: "Not Applicable"});
      }
      this.subPlatformData.sort(this.compare);
      this.filteredSubPlatformData = this.peopleForm.controls.subPlatform.valueChanges
        .pipe(
          startWith(''),
          map(subPlatform => subPlatform ? this._filterEmployee(subPlatform) : this.subPlatformData.slice())
        );
      this.peopleForm.controls.subPlatform.setErrors(null);
    });
  }

  private _filterEmployee(value: string) {
    if (!this.subPlatformData) {
      return;
    }
    let filteredData = this.subPlatformData.filter(employee => employee.subPlatformName.toLowerCase().indexOf(value.toLowerCase()) === 0);
    if(!this.subPlatformData.find(element => element.subPlatformName === value)){
      this.peopleForm.controls.subPlatform.setErrors({'incorrect': true});
    } else {
      this.peopleForm.controls.subPlatform.setErrors(null);
    }
    return filteredData;
  }

  getData(data) {
    this.updatePreviousMonth = false;
    this.updateBoth = false;
    this.updateNextMonth = false;
    this.dataSummary = data['employee'];

    this.chaptersData = this.getUniqueChapterList(data['chaptersData']);
    this.initialChapterData = this.chaptersData;
    this.message = data['message'];
    this.techUnit = this.dataSummary.techUnit;
    const startdate = moment(this.dataSummary.staffStartDate);
    const currentDate = moment(new Date());
    if (this.dataSummary['staffType'] !== 'DBS' && this.dataSummary['staffType'] !== 'SEED') {
      this.contractemp = true;
      this.headerInfo.tabs = ["Overview", "Contract", "Teams & Individual Contribution", "Chapter"];
      this.commonService.recieveMessage(this.headerInfo);
    }
    if (this.dataSummary.workType1 === 'Build') {
      this.dropDownData['Type of Work 2'] = [];
      this.refDataForDropDown['Type of Work 2'].forEach(option => {
        if (option['desc'] && option['desc'].toLowerCase() == 'build') {
          this.dropDownData['Type of Work 2'].push({ value: option['value'] })
        }
      });
      // this.dropDownData['Type of Work 2'] = [{ value: 'Enhancement' }, { value: 'Initiative' }]
    }
    else if (this.dataSummary.workType1 === 'Operate') {
      this.dropDownData['Type of Work 2'] = [];
      this.refDataForDropDown['Type of Work 2'].forEach(option => {
        if (option['desc'] && option['desc'].toLowerCase() == 'operate') {
          this.dropDownData['Type of Work 2'].push({ value: option['value'] })
        }
      });
      // this.dropDownData['Type of Work 2'] = [{ value: 'Operate' }]
    }
    if (this.dataSummary.indvContributor == '' || this.dataSummary.indvContributor == null) {
      this.dataSummary.indvContributor = 'No';
    }
    if (this.dataSummary.workType1) {
      this.showWorkType2 = true;
    } else {
      this.showWorkType2 = false;
    }
    this.platform = this.dataSummary.platformIndex;
    this.contractDataSource = data['employeeContracts'];
    this.teamsDataSource = data['teamFormations'];
    this.chapterDataSource = this.getUniqueChapterList(data['chaptersData']) as any;

    this.setChapterFormArray();
    this.setIntialData();
    this.getSubplatformsByPlatformIndex(this.platform);
    this.getChapters();
    this.getIndividualAndTeamCapacity();
  }

  getUniqueChapterList(chapterList : any){
    let list = [];
    if(chapterList){
      chapterList.forEach(function(chapter){
        let isUnique = true;
        list.forEach(function(item){
          if(item.chapterName === chapter.chapterName){
            isUnique = false;
          }
        });
        if(isUnique){
          list.push(chapter);
        }
      });
    }
    return list;
  }

  onYearChange() {
    this.getIndividualAndTeamCapacity();
  }

  tabClick() {
    this.getIndividualAndTeamCapacity();
  }

  showErrorDialog(errorResponse: any){
    this.commonService.showSnackBar({ type: 'alert', message: errorResponse.statusText + ': ' + errorResponse.error.path + ' \n' + errorResponse.error.message, duration: 3000 });
  }

  isEmpty(dataSource: any){
    if(dataSource){
      if(dataSource.data){
        return dataSource.data.length == 0;
      } else if(dataSource.length){
        return dataSource.length == 0;
      }
    }
    return true;
  }

  getIndividualAndTeamCapacity() {
    this.restService.get(`/people/data/employee/getIndividualAndTeamCapacity?id=${this.oneBankId}&reportingPeriod=${this.reportingPeriod}&surrId=${this.surrId}&selectedDate=${this.selectedDate}`).subscribe(data => {
      this.individualAndTeamDataSource = data['teamCapacityData'] ? data['teamCapacityData'] : [];
      this.individualTeamResponseObjArray = data['teamCapacityData'];
      for (let i = 0; i < this.individualTeamResponseObjArray.length; i++) {
        let individualTeamResponseObj = this.individualTeamResponseObjArray[i];
        this.reportingMonth = individualTeamResponseObj.reportingMonth;
      }
    },error=>{
      this.showErrorDialog(error);
    });
  }

  getAllChapterNameList() {
    this.restService.get(`/people/data/employee/chapters`).subscribe(data => {
      if (data) {
        data = data.sort();
        this.dropDownChapterList = data.filter(x => x); // filter not null
      }
    });
  }

  getChapters() {
    this.restService.get(`/people/data/chapters/chaptersbytechUnit/${this.techUnit}`).subscribe(data => {
      this.dropDownChapterList = [...new Set(data)] // unique comparison
      // console.warn('get chapters>>>', data);
    },error=>{
      this.showErrorDialog(error);
    });
  }

  onClick() {
    this.filterDropdown = this.getAvailableChaptersToAdd();
  }

  checkForEdit(element) {
    if (element.chapter_surr_id !== '') {
      return true;
    }
    else
      return false;
  }

  isInvalidChapter(index){
    return (this.peopleForm.get('chapterForm') as FormArray).at(index).invalid;
  }

  selected(event, index) {
    let control = <FormArray>this.peopleForm.controls.chapterForm;
    this.chapterNames = this.getChapterListInForms();

    this.restService.get(`/people/data/chapters/leadsbychapter/${event.option.value}`).subscribe(data => {
      ((this.peopleForm.get('chapterForm') as FormArray).at(index) as FormGroup).get('chapterLeads').patchValue(data);
      this.chapterDataSource = control.value;
      this.filterDropdown = this.dropDownChapterList.filter(x => !this.chapterNames.includes(x));
    });
  }

  getChapterListInForms(){
    let control = <FormArray>this.peopleForm.controls.chapterForm;
    this.chapterNames = [];
    control.value.forEach(element => {
      if (element.chapterName !== '' && this.chapterNames.indexOf(element.chapterName) === -1) {
        this.chapterNames.push(element.chapterName);
      }
    });
    return this.chapterNames;
  }

  filterChapter(name) {
    this.chapterNames = this.getChapterListInForms();
    this.filterDropdown = [];
    this.filterDropdown = this.dropDownChapterList.filter(chapterName => !this.chapterNames.includes(chapterName) && chapterName.toLowerCase().indexOf(name.toLowerCase()) === 0)
  }

  typeOfWork(e) {
    if (e.value === 'Build') {
      // this.dropDownData['Type of Work 2'] = [{ value: 'Enhancement' }, { value: 'Initiative' }];
      this.dropDownData['Type of Work 2'] = [];
      this.refDataForDropDown['Type of Work 2'].forEach(option => {
        if (option['desc'] && option['desc'].toLowerCase() == 'build') {
          this.dropDownData['Type of Work 2'].push({value: option['value']})
        }
      });
      this.work2 = true;
      this.showWorkType2 = true;
      this.peopleForm.patchValue({
        workType2: ''
      })
    } else if (e.value === 'Operate') {
      // this.dropDownData['Type of Work 2'] = [{ value: 'Operate' }];
      this.dropDownData['Type of Work 2'] = [];
      this.refDataForDropDown['Type of Work 2'].forEach(option => {
        if (option['desc'] && option['desc'].toLowerCase() == 'operate') {
          this.dropDownData['Type of Work 2'].push({value: option['value']})
        }
      });
      this.work2 = true;
      this.showWorkType2 = true;
      this.peopleForm.patchValue({
        workType2: 'Operate'
      });
    }
  }

  editAccessCheck(): boolean {
    const currentMonth = new Date().getMonth();
    const currentDate = new Date().getDate();
    console.log('editaccess: ' + this.editAccess + 'user access: ' + this.userAccessCheckValue);
    if (this.dataSummary && (this.dataSummary.staffType === 'DBS' || this.dataSummary.staffType === 'SEED') && this.dataSummary.staffStatus === 'Active'
      && (this.editAccess || this.userAccessCheckValue)
      && ((+this.reportingPeriodDate === currentMonth && currentDate <= parseInt(this.editWindowPeriod)) || currentMonth + 1 === +this.reportingPeriodDate)) {
      return true;
    }
    return false;
  }



  createForm() {
    this.peopleForm = this.fb.group({
      //onOffShore: ['', [Validators.required]],
      floor: ['', [Validators.maxLength(50)]],
      seatLocation: [''],
      billingType: [''],
      fundingPccode: [''],
      arPccode: [''],
      subPlatform: ['', [Validators.required]],
      indvContributor: ['', [Validators.required]],
      workType1: ['', [Validators.required]],
      workType2: ['', [Validators.required]],
      projectId: [''],
      appCode: [''],
      remarks: [''],
      chapterForm: this.fb.array([])
    });
  }

  resetChapterForm(){
    let chapterControls = <FormArray>this.peopleForm.controls.chapterForm;
    while(chapterControls.length > 0){
      chapterControls.removeAt(0);
    }
    this.chaptersData = this.initialChapterData;
    this.chapterDataSource = this.initialChapterData;
    this.setChapterFormArray();
  }

  getAvailableChaptersToAdd(){
    let control = <FormArray>this.peopleForm.controls.chapterForm;
    this.chapterNames = [];
    control.value.forEach(element => {
      if (element.chapterName !== '' && this.chapterNames.indexOf(element.chapterName) === -1) {
        this.chapterNames.push(element.chapterName);
      }
    });
    return this.dropDownChapterList.filter(x => !this.chapterNames.includes(x));
  }

  addChapter() {
    if(this.getAvailableChaptersToAdd().length === 0){
      this.commonService.showSnackBar({ type: 'alert', message: 'No more chapters available to add for tech unit ('+this.techUnit+')', duration: 3000 });
    } else {
      this.changeInForm = true;
      this.action = 'edit';
      let control = <FormArray>this.peopleForm.controls.chapterForm;
      control.push(this.fb.group({
        chapter_surr_id: [''],
        chapterName: ['', [Validators.required, RxwebValidators.unique()]],
        status: ['Active', [Validators.required]],
        chapterLeads: []
      }));
      this.chapterDataSource = control.value;
      control.value.forEach(element => {
        if (element.chapterName !== '' && this.chapterNames.indexOf(element.chapterName) === -1 ) {
          this.chapterNames.push(element.chapterName);
        }
      });
      this.filterDropdown = [];
      this.filterDropdown = this.dropDownChapterList.filter(name => !this.chapterNames.includes(name));
    }
  }

  setChapterFormArray() {
    let control = <FormArray>this.peopleForm.controls.chapterForm;
    this.chapterNames = [];
    this.chaptersData.forEach(element => {
      if(this.chapterNames.indexOf(element['chapterName']) === -1){
        this.chapterNames.push(element['chapterName']),
        control.push(this.fb.group({
          chapter_surr_id: [element['chapter_surr_id']],
          chapterName: [element['chapterName'], [Validators.required,RxwebValidators.unique()]],
          status: [element['status'], Validators.required],
          chapterLeads: [element['chapterLeads']]
        }));
      }
    });
  }

  deleteChapter(index, element) {
    let control = <FormArray>this.peopleForm.controls.chapterForm;
    control.removeAt(index);
    this.chapterDataSource = control.value;
  }

  setIntialData() {
    // console.warn('initial data >> ', this.dataSummary);
    //this.peopleForm.controls['onOffShore'].setValue(this.dataSummary.onOffshore);
    this.peopleForm.controls['floor'].setValue(this.dataSummary.floor);
    this.peopleForm.controls['seatLocation'].setValue(this.dataSummary.seatLocation);
    this.peopleForm.controls['billingType'].setValue(this.dataSummary.billingType);
    this.peopleForm.controls['fundingPccode'].setValue(this.dataSummary.fundingPccode);
    this.peopleForm.controls['arPccode'].setValue(this.dataSummary.arPccode);
    this.peopleForm.controls['subPlatform'].setValue(this.dataSummary.subPlatform);
    this.peopleForm.controls['indvContributor'].setValue(this.dataSummary.indvContributor);
    this.peopleForm.controls['workType1'].setValue(this.dataSummary.workType1);
    this.peopleForm.controls['workType2'].setValue(this.dataSummary.workType2);
    this.peopleForm.controls['projectId'].setValue(this.dataSummary.projectId);
    this.peopleForm.controls['appCode'].setValue(this.dataSummary.appCode);
    this.peopleForm.controls['remarks'].setValue(this.dataSummary.remarks);
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustomForPeople(date);
  }

  timeFormat(date?: Date) {
    const d = new Date(date);
    let time = d.getHours() + ':' + d.getMinutes();
    return this.formattime.transform(time);
  }

  goback() {
    this.router.navigateByUrl('home/workforce/people-profile');
  }

  editProfile() {
    this.action = 'edit';
    this.isErrorExists = false;
    this.updateNextMonth=false;
    this.updatePreviousMonth=false;
    this.updateBoth=false;
    this.headerInfo.btns = '';
    this.commonService.recieveMessage(this.headerInfo);
  }

  openWarningDialog(){
    return this.dialog.open(CommonDialogComponent, {
      data: {
      type: 'warning',
      contentTitle: 'Unsaved changes',
      content: `You are leaving with unsaved changes, any changes will be lost.\nAre you sure you want to leave this page?`,
      cancelTxt: 'Stay on Page',
      confirmTxt: "Leave Page"
      }
    });
  }

  onCancelClick() {
    const dialogRef = this.openWarningDialog();
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.action = 'view';
        this.updateHeaderButtons();
        this.changeInForm = false;

        if(this.selectedTab == 'Chapter'){
          this.resetChapterForm();
        }
      }
    });
  }

  deleteAttr(index, ele) {

  }

  get f() {
    return this.peopleForm.controls;
  }

  scrollTo(el: Element): void {
    if(el) {
     el.scrollIntoView({ behavior: 'smooth' });
    }
  }
  scrollToError(): void {
      const firstElementWithError = _.find(document.querySelectorAll('.ng-invalid'), function(item){
        return item.tagName.toLowerCase() !== 'form';
      });

      this.scrollTo(firstElementWithError);
  }

  saveData() {
    let controls = this.peopleForm.controls;
    let isInvalid = false;
    for (const name in controls) {
      if(this.selectedTab === 'Chapter' && name !== 'chapterForm'){
        controls[name].setErrors({ 'invalid': false});
        continue;
      } else if(this.selectedTab === 'Overview' && name === 'chapterForm'){
        controls[name].setErrors({ 'invalid': false});
        continue;
      }
      if (controls[name].invalid) {
        isInvalid = true;
        this.peopleForm.controls[name].markAsTouched();
      }
    }

    if (isInvalid) {
      this.peopleForm.markAllAsTouched();
      this.scrollToError();
    } else if (!isInvalid) {
      const currentDate = new Date().getDate();
      if (currentDate <= parseInt(this.editWindowPeriod)) {
        this.currentMonthStatus = this.dataService.getcurrentMonthStatus();
        if (this.currentMonthStatus) {
          this.restService.get(`/people/data/employee/individualProfile?id=${this.oneBankId}&currentMonthFlag=Y`)
          .subscribe(data => {
            data ? this.checkForUpdation(data, this.currentMonthStatus) : this.apiCall();
          },error => {
            this.showErrorDialog(error);
          });
        } else {
          this.restService.get(`/people/data/employee/individualProfile?id=${this.oneBankId}&currentMonthFlag=N`).subscribe(data => {
            data ? this.checkForUpdation(data, this.currentMonthStatus) : this.apiCall();
          },error => {
            this.showErrorDialog(error);
          });
        }
      } else {
        this.apiCall();
      }
    }
  }

  checkForUpdation(data, currentMonthStatus) {
    if (!(data['workType2'] === '' || data['workType1'] === '' || data['subPlatform'] === '') &&
      (this.dataSummary.workType1 === '' || this.dataSummary.workType2 === '' || this.dataSummary.subPlatform === '')) {
      this.dialogBox(currentMonthStatus);
    }
    if ((data['workType2'] === '' || data['workType1'] === '' || data['subPlatform'] === '') &&
      !(this.dataSummary.workType1 === '' || this.dataSummary.workType2 === '' || this.dataSummary.subPlatform === '')) {
      this.dialogBox(currentMonthStatus);
    }
    else if (!(data['workType2'] === '' || data['workType1'] === '' || data['subPlatform'] === '') &&
      !(this.dataSummary.workType1 === '' || this.dataSummary.workType2 === '' || this.dataSummary.subPlatform === '')) {
      this.dialogBox(currentMonthStatus);
    }
    else if ((data['workType2'] === '' || data['workType1'] === '' || data['subPlatform'] === '') &&
      (this.dataSummary.workType1 === '' || this.dataSummary.workType2 === '' || this.dataSummary.subPlatform === '')) {
      currentMonthStatus ? this.updatePreviousMonth = true : this.updateNextMonth = true;
      this.apiCall();
    }
  }

  apiCall() {
    this.currentMonthStatus = this.dataService.getcurrentMonthStatus();
    this.dataSummary.floor = this.peopleForm.controls.floor.value;
    this.dataSummary.seatLocation = this.peopleForm.controls.seatLocation.value;
    this.dataSummary.billingType = this.peopleForm.controls.billingType.value;
    this.dataSummary.fundingPccode = this.peopleForm.controls.fundingPccode.value;
    this.dataSummary.arPccode = this.peopleForm.controls.arPccode.value;
    this.dataSummary.subPlatform = this.peopleForm.controls.subPlatform.value;
    this.dataSummary.indvContributor = this.peopleForm.controls.indvContributor.value;
    this.dataSummary.workType1 = this.peopleForm.controls.workType1.value;
    this.dataSummary.projectId = this.peopleForm.controls.projectId.value;
    this.dataSummary.workType2 = this.peopleForm.controls.workType2.value;
    this.dataSummary.appCode = this.peopleForm.controls.appCode.value;
    this.dataSummary.remarks = this.peopleForm.controls.remarks.value;
    this.dataSummary.modifiedBy = JSON.parse(localStorage.getItem('userinfo')).username;
    let dataObject = {
      'employee': this.dataSummary,
      'updatePreviousMonth': this.updatePreviousMonth,
      'updateNextMonth': this.updateNextMonth,
      'chaptersData': this.peopleForm.controls.chapterForm.value
    };
    this.restService.post(`/people/data/employee/update`, dataObject).subscribe(data => {
      if (data['errorFlag'] !== null) {
        this.isErrorExists = true;
        this.dataService.getCustomMessage(data['message']);
        this.dataService.getFlag(data['errorFlag']);

        if (data['errorFlag'] == 1) {
          this.commonService.showSnackBar({ type: 'alert', message: data.message, duration: 3000 });
        }
        else {
          this.commonService.showSnackBar({ type: 'success', message: data.message, duration: 3000 });
        }

        this.reloadPage();
      }
    },error => {
      this.showErrorDialog(error);
    });
  }

  loadDataValues() {
    this.restService.get(`/people/data/dataValues/sys-config?msgKey=People Edit Window - Previous Month`).subscribe(result => {
      this.editWindowPeriod = result['message'];
      this.userAccessCheck();
    },error => {
      this.userAccessCheck();
      console.error('loadDataValues(): ', error);
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_PEOPLE_EDIT_NXTMONTH_CONFIRMATION`).subscribe(result => {
      this.nextMonthUpdateConfirmationMessage = result['message'];
    },error => {
      console.error('loadDataValues(): ', error);
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_PEOPLE_EDIT_PREVMONTH_CONFIRMATION`).subscribe(result => {
      this.previousMonthUpdateConfirmationMessage = result['message'];
    },error => {
      console.error('loadDataValues(): ', error);
    });
  }

  openConfirmationDialog(title: string, message: string, noButtonText: string, yesButtonText: string, closeIcon: boolean){
    return this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'confirm',
        contentTitle: title,
        content: message,
        cancelTxt: noButtonText,
        confirmTxt: yesButtonText,
        showCloseIcon: closeIcon
      }
    });
  }

  dialogBox(currentMonthStatus: boolean) {
    let bodyText = currentMonthStatus ? this.previousMonthUpdateConfirmationMessage : this.nextMonthUpdateConfirmationMessage;
    let yesButtonText = '';
    let noButtonText = 'Update Current Month';
    if(bodyText.indexOf('?') != -1){
      let line1 = bodyText.substring(0, bodyText.indexOf('?')+1);
      let line2 = bodyText.substring(bodyText.indexOf('?')+1);
      bodyText = line1 + '\n' + line2;
    }
    this.updateNextMonth = false;
    this.updatePreviousMonth = false;
    yesButtonText = currentMonthStatus ? 'Update Current and Previous Month' : 'Update Current and Next Month';
    const dialogRef = this.openConfirmationDialog('Update Details', bodyText, noButtonText, yesButtonText, true);
    dialogRef.afterClosed().subscribe(result => {
      if(result === 'yes'){
        currentMonthStatus ? this.updatePreviousMonth = true : this.updateNextMonth = true;
        this.apiCall();
      } else if(result === 'no'){
        this.apiCall();
      }
    });
  }

  change(e){
    this.changeInForm = true;
  }

  disableCheck() {
    let control = <FormArray>this.peopleForm.controls.chapterForm;
      if (this.dataSummary.billingType !== this.peopleForm.controls.billingType.value) {
        this.changeInForm = true;
      }
      if (this.dataSummary.fundingPccode !== this.peopleForm.controls.fundingPccode.value) {
        this.changeInForm = true;
      }
      if (this.dataSummary.arPccode !== this.peopleForm.controls.arPccode.value) {
        this.changeInForm = true;
      }
      if (this.dataSummary.subPlatform !== this.peopleForm.controls.subPlatform.value) {
        this.changeInForm = true;
      }
      if (this.dataSummary.indvContributor !== this.peopleForm.controls.indvContributor.value) {
        this.changeInForm = true;
      }
      if (this.dataSummary.workType1 !== this.peopleForm.controls.workType1.value) {
        this.changeInForm = true;
      }
      if (this.dataSummary.workType2 !== this.peopleForm.controls.workType2.value) {
        this.changeInForm = true;
      }
      if (this.dataSummary.projectId !== this.peopleForm.controls.projectId.value) {
        this.changeInForm = true;
      }
      if (this.dataSummary.appCode !== this.peopleForm.controls.appCode.value) {
        this.changeInForm = true;
      }
      if (this.dataSummary.remarks !== this.peopleForm.controls.remarks.value) {
        this.changeInForm = true;
      }
      return !this.changeInForm;
   }
}

export interface Assets {
  type: string;
  id: string;
  details: string;
}

export interface Team {
  tribe: string;
  team: string;
  pcft: boolean;
  allocation: string;
  teamlead: string;
  role: string;
}

export interface Contract {
  vendor: string;
  contractstartdate: string;
  contractenddate: string;
  mcrnumber: string;
  contractid: string;
  ponumber: string;
  status: string;
}
