import { Injectable } from "@angular/core";
import {
  Router,
  Resolve,
  RouterStateSnapshot,
  ActivatedRouteSnapshot
} from "@angular/router";
import { Observable } from "rxjs";
import { RestService } from "src/app/common/service/rest.service";
import { DataService } from "src/app/common/service/data.service";

@Injectable()
export class PeopleResolver implements Resolve<any> {
  constructor(private restService: RestService, private dataService: DataService) {}

  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> | Promise<any> {
    return this.restService.get(`/people/data/employee/profile?id=${this.dataService.getPassingOneBankId()}
    &reportingPeriod=${this.dataService.getReportingPeriod()}&surrId=${this.dataService.getSurrId()}`);
  }
}
