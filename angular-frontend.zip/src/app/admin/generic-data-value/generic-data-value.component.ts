import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { RestService } from '../../common/service/rest.service';
import { DataTableService } from '../../common/service/dataTable.service';
import { Subscription } from 'rxjs';
import { DataService } from '../../common/service/data.service';
import { CommonService } from '../../common/service/common.service';

@Component({
  selector: 'app-generic-data-value',
  templateUrl: './generic-data-value.component.html',
  styleUrls: ['./generic-data-value.component.scss']
})
export class GenericDataValueComponent implements OnInit, AfterViewInit {

  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  detailsview = false;
  action = '';
  element: any;
  refDataList: any = [];
  isRefDataSelected = false;
  selectedValue: any;
  selectedValueLabel: any;
  displayedColumns: any = [];
  data: any = [];
  response: any = [];
  noData = false;
  filterValues: any = {};
  subscription: Subscription;

  constructor(private restService: RestService, private dataTableService: DataTableService,
    private dataService: DataService, private commonService: CommonService) {
    this.restService.track('GENERIC DATA VALUE');
    this.commonService.recieveMessage({
      title: "Generic Ref Data Value"
    })
    this.dataSource = new MatTableDataSource();
    this.dataService.sendMessage(this.detailsview);
    this.subscription = this.dataService.getMessage().subscribe(message => {
      if (this.detailsview === true) {
        this.onBackClicked('back clicked');
      }
    });
  }

  ngOnInit() {
    this.getDataForDataType();
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  // get dropdown data for ref data type
  getDataForDataType() {
    this.refDataList = [];
    this.restService.get(`/people/data/dataSummary/genericData`).subscribe(data => {
      data.forEach(element => {
        if (element['name'] !== null && element['code'] !== null) {
          this.refDataList.push({ 'key': element['code'], 'value': element['name'] });
        }
      });
    });
  }

  getTableData() {
    this.restService.get(`/people/data/dataValues/values/${this.selectedValue}`).subscribe(data => {
      this.response = data;
      this.data = [];
      data.forEach(element => {
        this.data.push(element['dataValues'])
      });
      this.data.forEach(e => {
        if (e['Status']) {
          e['Status'] = e['Status'].toUpperCase();
        }
        if (!e['id']) {
          this.noData = true;
        } else {
          this.noData = false;
        }
      });
      this.getDisplayColumns();
      this.dataSource.data = this.data;
      this.dataSource.paginator = this.paginator;
      this.dataSource.filter = '';
    });
  }

  // on selection of ref data type
  onRefDataSelection(e) {
    this.isRefDataSelected = true;
    this.selectedValue = e.value;
    //adding label of data type for summary view
    this.refDataList.forEach(element => {
      if (element['key'] == this.selectedValue) {
        this.selectedValueLabel = element['value'];
      }
    });
    this.getTableData();
  }

  // dynamically create displayColumns for datatable.
  getDisplayColumns() {
    this.displayedColumns = [];
    if (this.data) {
      for (let prop in this.data[0]) {
        if (this.displayedColumns.length <= 3 && prop != 'id' && prop != 'code') {
          this.displayedColumns.push(prop);
        }
      }
    }
    //this.displayedColumns.push('actions');
    this.displayedColumns.push('seeMore');
    this.displayedColumns.push('edit');

  }

  gotoDetails(element, action) {
    if (action !== 'add') {
      if (element['Status']) {
        element['Status'] = element['Status'].toLowerCase();
      }
      this.detailsview = true;
      this.action = action;
      this.element = element;
    } else {
      this.detailsview = true;
      this.action = action;
      let dummydata = this.data[0];
      for (var prop in dummydata) {
        if (prop != 'id' && prop != 'code') {
          dummydata[prop] = '';
        } else if (prop === 'code') {
          dummydata['code'] = this.selectedValue.toString();
        }
        if (prop == 'id' && !dummydata['id']) {
          dummydata['id'] = 'dummy';
        }
      }
      this.element = dummydata;
    }
  }

  onBackClicked(e) {
    this.detailsview = false;
    this.getTableData();
  }

  applyFilter(filterValue: string) {
    this.getFilterValues(filterValue);
    this.dataSource.filter = JSON.stringify(this.filterValues);
    this.dataSource.filterPredicate = this.dataTableService.tableFilterForSearch();
  }

  getFilterValues(filterValue) {
    if (this.data) {
      for (let prop in this.data[0]) {
        if (prop != 'id' && prop != 'code' && this.displayedColumns.includes(prop)) {
          this.filterValues[prop] = filterValue.trim().toLowerCase();
        }
      }
    }
  }

  sortData(event): void {
    this.dataSource.sortingDataAccessor = (data, header) => {
      if (this.displayedColumns.includes(header)) {
        if (typeof (data[header]) != 'number' && data[header]) {
          return data[header].toString().toLowerCase();
        } else {
          return data[header];
        }
      }
    }
    this.dataSource.sort = this.sort;
  }
  getStatusClass(status: string):string{
    if(status.toLowerCase()==='active'){
      return 'completed'
    } else if(status.toLowerCase()==='inactive'){
      return 'inactive';
    } else if(status.toLowerCase()==='planned'){
      return 'pending';
    }
  }
}
