import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {SharedModule} from '../../common/module/shared.module';
import {NonGenericDataComponent} from './non-generic-data.component';
import {EmailTemplateComponent} from './email-template/email-template.component';
import { RichTextEditorAllModule } from '@syncfusion/ej2-angular-richtexteditor';

const routes: Routes = [
  {path: '', component: NonGenericDataComponent},
  {path: 'emailTemplate', component: EmailTemplateComponent}
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
    RichTextEditorAllModule
  ],
  declarations: [NonGenericDataComponent, EmailTemplateComponent]
})

export class NonGenericDataRoutingModule {}
