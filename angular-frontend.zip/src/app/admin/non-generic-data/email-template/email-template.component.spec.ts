// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { FormBuilder, FormGroup, Validators, FormArray, AbstractControl  } from '@angular/forms';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import {MaterialModule} from 'src/app/material.module';
// import { RestService } from '../../../common/service/rest.service';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { DebugElement } from '@angular/core';
// import { BrowserModule, By } from '@angular/platform-browser';
// import { MatTableDataSource } from '@angular/material/table';
// import { MatSort } from '@angular/material/sort';
// import { configureTestSuite } from 'ng-bullet';
// import { EmailTemplateComponent } from './email-template.component';
// import { ToolbarService, LinkService, ImageService, HtmlEditorService, TableService } from '@syncfusion/ej2-angular-richtexteditor';
// import { RichTextEditorAllModule } from '@syncfusion/ej2-angular-richtexteditor';
// import 'rxjs/add/operator/map';
// import { MatDialogRef } from '@angular/material/dialog';
// import { DataService } from 'src/app/common/service/data.service';
// import { of, Subscription, Observable, Subject } from 'rxjs';

// describe('EmailTemplateComponent', () => {
//   let component: EmailTemplateComponent;
//   let fixture: ComponentFixture<EmailTemplateComponent>;
//   let de: DebugElement;
//   let el: HTMLElement;
//   const fb: FormBuilder = new FormBuilder();

//   configureTestSuite(() => {
//     TestBed.configureTestingModule({
//       declarations: [EmailTemplateComponent],
//       imports: [BrowserAnimationsModule,
//         MaterialModule,
//         FormsModule,
//         ReactiveFormsModule,
//         BrowserModule,
//         RichTextEditorAllModule],
//       providers: [
//         { provide: RestService, useClass: MockRestService },
//         { provide: FormBuilder, useValue: fb },
//         { provide: MatDialogRef, useClass: MockMatDialogRef },
//         { provide: DataService, useClass: MockDataService },
//         ToolbarService
//       ]
//     })
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EmailTemplateComponent);
//     component = fixture.componentInstance;
//     component.action = 'view';
//     component.selectedTemplate = 'xref_email_template'
//     component.cancelCliked = false;
//     component.saveCliked = false;
//     component.errorInAdd = false;
//     component.dirtyFormCheck;
//     component.saveAction;
//     component.data = {};
//     component.templateData = { "createdBy": null, "dateCreated": null, "modifiedBy": null, "dateModified": null, "emailSurrId": "", "emailTemplateName": "", "emailTemplateDesc": "", "emailSubjectHeader": "", "emailHtmlTemplate": "", "status": "" };
//     component.data['emailConfig'] = [{}];
//     component.data['emailTemplate'] = { "createdBy": null, "dateCreated": null, "modifiedBy": null, "dateModified": null, "emailSurrId": "", "emailTemplateName": "", "emailTemplateDesc": "", "emailSubjectHeader": "", "emailHtmlTemplate": "", "status": "" };
//     component.hasDuplicateAttr = false;
//     component.dataSource = new MatTableDataSource();
//     component.dataSource.sort = new MatSort();
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
//   it('should call on ngonChanges for add/edit', (done: DoneFn) => {
//     component.action = 'add';
//     component.saveCliked = false;
//     component.templateData = { "createdBy": null, "dateCreated": null, "modifiedBy": null, "dateModified": null, "emailSurrId": "", "emailTemplateName": "", "emailTemplateDesc": "", "emailSubjectHeader": "", "emailHtmlTemplate": "", "status": "" };
//     component.ngOnChanges();
//     done();
//   });
//   it('should call on ngonChanges for view', (done: DoneFn) => {
//     component.action = 'view';
//     component.saveCliked = false;
//     component.templateData = { "createdBy": null, "dateCreated": null, "modifiedBy": null, "dateModified": null, "emailSurrId": "", "emailTemplateName": "", "emailTemplateDesc": "", "emailSubjectHeader": "", "emailHtmlTemplate": "", "status": "" };
//     component.ngOnChanges();
//     done();
//   });
//   it('should call on ngonChanges for add with save emailform', (done: DoneFn) => {
//     component.action = 'add';
//     component.saveCliked = true;
//     component.emailForm = fb.group({
//       emailTemplateName: [''],
//       emailSurrId: [''],
//       status: [''],
//       emailSubjectHeader: [''],
//       emailHtmlTemplate: [''],
//       emailConfig: [{
//         triggerEventName: 'test', emailRecipients: '',
//         emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//         dateCreated: '', modifiedBy: '', dateModified: ''
//       },
//       {
//         triggerEventName: 'test', emailRecipients: '',
//         emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//         dateCreated: '', modifiedBy: '', dateModified: ''
//       }]
//     })
//     component.templateData = { "createdBy": null, "dateCreated": null, "modifiedBy": null, "dateModified": null, "emailSurrId": "", "emailTemplateName": "", "emailTemplateDesc": "", "emailSubjectHeader": "", "emailHtmlTemplate": "", "status": "" };
//     component.ngOnChanges();
//     done();
//   });
//   it('should call on ngonChanges for edit with save emailform', (done: DoneFn) => {
//     component.action = 'edit';
//     component.saveCliked = true;
//     component.emailForm = fb.group({
//       emailTemplateName: [''],
//       emailSurrId: [''],
//       status: [''],
//       emailSubjectHeader: [''],
//       emailHtmlTemplate: [''],
//       emailConfig: [{
//         triggerEventName: 'test', emailRecipients: '',
//         emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//         dateCreated: '', modifiedBy: '', dateModified: ''
//       },
//       {
//         triggerEventName: 'test', emailRecipients: '',
//         emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//         dateCreated: '', modifiedBy: '', dateModified: ''
//       }]
//     })
//     component.templateData = { "createdBy": null, "dateCreated": null, "modifiedBy": null, "dateModified": null, "emailSurrId": "", "emailTemplateName": "", "emailTemplateDesc": "", "emailSubjectHeader": "", "emailHtmlTemplate": "", "status": "" };
//     component.ngOnChanges();
//     done();
//   });
//   it('should call on getData for add', (done: DoneFn) => {
//     component.action = 'add';
//     component.data['emailTemplate'] = { "createdBy": null, "dateCreated": null, "modifiedBy": null, "dateModified": null, "emailSurrId": "", "emailTemplateName": "", "emailTemplateDesc": "", "emailSubjectHeader": "", "emailHtmlTemplate": "", "status": "" };
//     component.data['emailConfig'] = [{
//       triggerEventName: '', emailRecipients: '',
//       emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//       dateCreated: '', modifiedBy: '', dateModified: ''
//     }];
//     fixture.detectChanges();
//     component.templateData = { "createdBy": null, "dateCreated": null, "modifiedBy": null, "dateModified": null, "emailSurrId": "", "emailTemplateName": "", "emailTemplateDesc": "", "emailSubjectHeader": "", "emailHtmlTemplate": "", "status": "" };
//     component.getData();
//     done();
//   });
//   it('should call on getData for view', (done: DoneFn) => {
//     component.action = 'view';
//     component.data['emailTemplate'] = { "createdBy": null, "dateCreated": null, "modifiedBy": null, "dateModified": null, "emailSurrId": "", "emailTemplateName": "", "emailTemplateDesc": "", "emailSubjectHeader": "", "emailHtmlTemplate": "", "status": "" };
//     component.data['emailConfig'] = [{
//       triggerEventName: '', emailRecipients: '',
//       emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//       dateCreated: '', modifiedBy: '', dateModified: ''
//     }];
//     fixture.detectChanges();
//     component.templateData = { "createdBy": null, "dateCreated": null, "modifiedBy": null, "dateModified": null, "emailSurrId": "", "emailTemplateName": "", "emailTemplateDesc": "", "emailSubjectHeader": "", "emailHtmlTemplate": "", "status": "" };
//     component.getData();
//     done();
//   });
//   // it('should call for checkDuplicateAttrName', (done: DoneFn) => {
//   //   component.emailForm = fb.group({
//   //     emailTemplateName: [''],
//   //     emailSurrId: [''],
//   //     status: [''],
//   //     emailSubjectHeader: [''],
//   //     emailHtmlTemplate: [''],
//   //     emailConfig: [{
//   //       triggerEventName: 'test', emailRecipients: '',
//   //       emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//   //       dateCreated: '', modifiedBy: '', dateModified: ''
//   //     },
//   //     {
//   //       triggerEventName: 'test', emailRecipients: '',
//   //       emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//   //       dateCreated: '', modifiedBy: '', dateModified: ''
//   //     }]
//   //   });
//   // component.data = {
//   //   emailConfig: [{
//   //     triggerEventName: 'test', emailRecipients: 'sd@dbs.com',
//   //     emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//   //     dateCreated: '', modifiedBy: '', dateModified: ''
//   //   }, {
//   //     triggerEventName: 'test', emailRecipients: 'sadasd@dbs.com',
//   //     emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//   //     dateCreated: '', modifiedBy: '', dateModified: ''
//   //   }],
//   //   emailTemplate: EMAIL_TEMPLATE
//   // };

//   //   component.checkDuplicateAttrName();
//   //   // component.hasDuplicateAttr = false;
//   //   // component.data.emailConfig[0].triggerEventName = component.data.emailConfig[1].triggerEventName;
//   //   // component.hasDuplicateAttr = true;
//   //   done();
//   // });
//   // it('addTriggerEvent()', () => {
//   //    component.data = {
//   //     emailConfig: [{
//   //     triggerEventName: 'test', emailRecipients: 'sd@dbs.com',
//   //     emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//   //     dateCreated: '', modifiedBy: '', dateModified: ''
//   //   }, {
//   //     triggerEventName: 'test', emailRecipients: 'sadasd@dbs.com',
//   //     emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//   //     dateCreated: '', modifiedBy: '', dateModified: ''
//   //   }],
//   //   emailTemplate: EMAIL_TEMPLATE
//   // };
//   //   component.action = 'edit';
//   //   fixture.detectChanges();
//   //   component.emailForm = fb.group({
//   //         emailTemplateName: ['dfsd'],
//   //         emailSurrId: ['21'],
//   //         status: ['active'],
//   //         emailSubjectHeader: ['sdfsdf'],
//   //         emailHtmlTemplate: ['sdfdsfdsf'],
//   //         emailConfig: [{
//   //           triggerEventName: 'test', emailRecipients: '',
//   //           emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//   //           dateCreated: '', modifiedBy: '', dateModified: ''
//   //         },
//   //         {
//   //           triggerEventName: 'test', emailRecipients: '',
//   //           emailCc: '', emailBcc: '', emailSurrId: '', emailTemplateName: '', createdBy: '',
//   //           dateCreated: '', modifiedBy: '', dateModified: ''
//   //         }]
//   //       });
//   //   spyOn(component, 'checkDuplicateAttrName');
//   //   component.addTriggerEvent();
//   //   expect(component.checkDuplicateAttrName).toHaveBeenCalled();
//   // });
// });

// class MockRestService {
//   get() {
//     return of([{}]);
//   }
//   post() {
//     return of({});
//   }

//   put() {
//     return of({});
//   }
// }
// class Mockmap {
//   map() {
//     return of({});
//   }
// }

// const EMAIL_TEMPLATE = {
//   'createdBy': null,
//   'dateCreated': null,
//   'modifiedBy': 'pooja3',
//   'dateModified': 1573627836000,
//   "emailSurrId": "",
//   "emailTemplateName": "sdf",
//   "emailTemplateDesc": "fssdf",
//   "emailSubjectHeader": "sdfsdf",
//   "emailHtmlTemplate": "dfsf",
//   "status": "active"
// };

// class MockMatDialogRef {
//   afterClosed() {
//     return of({});
//   }
// }

// class MockDataService {
//   subject: Subject<any>;

//   getCustomMessage() {
//     return 'marissa';
//   }

//   getFlag() {
//     return '201908';
//   }

//   getMessage(): Observable<any> {
//     return new Observable;
//   }
// }
