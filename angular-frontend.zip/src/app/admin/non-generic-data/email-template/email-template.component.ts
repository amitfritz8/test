import { Component, OnInit, ViewChild, Input, AfterViewInit, OnChanges, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, AbstractControl } from '@angular/forms';
import { RestService } from 'src/app/common/service/rest.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { RxwebValidators } from '@rxweb/reactive-form-validators';
import { ConfirmDialogComponent } from 'src/app/common/component/dialogues/confirm-dialog/confirm-dialog-component';
import { MatDialog } from '@angular/material/dialog';
import { ToolbarService, LinkService, ImageService, HtmlEditorService, TableService } from '@syncfusion/ej2-angular-richtexteditor';
import { DomSanitizer } from "@angular/platform-browser";

@Component({
  selector: 'app-email-template',
  templateUrl: './email-template.component.html',
  styleUrls: ['./email-template.component.scss'],
  providers: [ToolbarService, LinkService, ImageService, HtmlEditorService, TableService]
})
export class EmailTemplateComponent implements OnInit, AfterViewInit, OnChanges {

  @Input() action;
  @Input() selectedTemplate;
  @Input() cancelCliked;
  @Input() saveCliked;
  @Input() editCliked;
  @Input() errorInAdd;
  @Output() dirtyFormCheck = new EventEmitter<boolean>();
  @Output() saveAction = new EventEmitter<any>();
  data: any;
  emailForm: FormGroup;
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  displayedColumns = ['triggerEventName', 'emailRecipients', 'emailCc', 'emailBcc','dynamicRecipientInd', 'send', 'remove'];
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  templateData: any;
  initialData: any;
  hasDuplicateAttr: boolean = false;
  @Output() back: EventEmitter<boolean> = new EventEmitter();
  tools: object = {
    items: [
      'Bold', 'Italic', 'Underline', '|',
      'FontName', 'FontSize', 'FontColor', 'BackgroundColor', '|',
      'LowerCase', 'UpperCase', '|', 'Alignments', '|',
      'OrderedList', 'UnorderedList', '|',
      'Indent', 'Outdent', '|', 'CreateLink',
      '|', 'Undo', 'Redo', '|', 'ClearFormat']
  };

  constructor(private fb: FormBuilder, private restService: RestService,
    public dialog: MatDialog, private domSanitizer: DomSanitizer) {
    this.dataSource = new MatTableDataSource();
  }
  ngOnInit() {
    this.getData();
    // this.validateEmail();
  }
  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }
  // Added to reflect changes when parent changes.
  ngOnChanges(): void {
    if (this.action !== 'view') {
      if (this.cancelCliked && this.emailForm && this.emailForm.dirty) {
        this.dirtyFormCheck.emit(true);
      } else if (this.cancelCliked && this.emailForm && !this.emailForm.dirty) {
        this.dirtyFormCheck.emit(false);
      }
      if (this.saveCliked) {
        this.save();
      }
      if (this.editCliked && !this.saveCliked) {
        let control = <FormArray>this.emailForm.controls.emailConfig;
        this.data.emailConfig = control.value;
        this.dataSource = new MatTableDataSource();
        this.dataSource.data = this.data.emailConfig;
      }
      if (this.action == 'add' && !this.saveCliked && !this.errorInAdd) {
        this.selectedTemplate = '';
        this.data = {};
        this.data['emailTemplate'] = { "createdBy": null, "dateCreated": null, "modifiedBy": null, "dateModified": null, "emailSurrId": "", "emailTemplateName": null, "emailTemplateDesc": null, "emailSubjectHeader": null, "emailHtmlTemplate": null, "status": "active" };
        this.data['emailConfig'] = [];
        this.templateData = this.data.emailTemplate;
        this.getForm();
      }
    } else {
      this.getData();
    }
  }
  // API call for getting data about email template and EmailConfig.
  getData() {
    if (this.action != 'add') {
      this.restService.get(`/people/email/template/${this.selectedTemplate}`).subscribe(res => {
        this.data = res;
        this.templateData = this.data.emailTemplate;
        this.getForm();
      });
    } else {
      this.selectedTemplate = '';
      this.data = {};
      this.data['emailTemplate'] = { "createdBy": null, "dateCreated": null, "modifiedBy": null, "dateModified": null, "emailSurrId": "", "emailTemplateName": "", "emailTemplateDesc": "", "emailSubjectHeader": "", "emailHtmlTemplate": "", "status": "" };
      this.data['emailConfig'] = [];
      this.templateData = this.data.emailTemplate;
      this.getForm();
    }
  }
  getInnerHTMLValue(html) {
    return this.domSanitizer.bypassSecurityTrustHtml(html);
  }
  // Once we have data then create form.
  getForm() {
    if (this.templateData) {
      this.emailForm = this.fb.group({
        emailTemplateName: [this.templateData.emailTemplateName, [Validators.required, Validators.maxLength(1000)]],
        emailSurrId: [{ value: this.templateData.emailSurrId, disabled: true }, [Validators.required]],
        status: [this.templateData.status, [Validators.required]],
        emailSubjectHeader: [this.templateData.emailSubjectHeader, [Validators.required, Validators.maxLength(1000)]],
        emailHtmlTemplate: [this.templateData.emailHtmlTemplate, [Validators.required, Validators.maxLength(20000)]],
        emailConfig: this.fb.array([])
      });
      this.initialData = this.emailForm.value;
      //defaulting active status for add new page.
      if (this.action === 'add') {
        this.emailForm.patchValue({
          status: 'active'
        });
      }
      this.setEmailConfig();
      this.templateData.emailHtmlTemplate = this.getInnerHTMLValue(this.templateData.emailHtmlTemplate);
    }
  }
  // Added for FormArray configuartion.
  setEmailConfig() {
    let control = <FormArray>this.emailForm.controls.emailConfig;
    if (this.data['emailConfig']) {
      this.data['emailConfig'].forEach(x => {
        control.push(this.fb.group({
          triggerEventName: [x['triggerEventName'], [Validators.required, Validators.maxLength(1000), RxwebValidators.unique()]],
          emailRecipients: [x['emailRecipients'], [Validators.required, this.validateEmail]],
          emailCc: [x['emailCc'], [this.validateEmail]],
          emailBcc: [x['emailBcc'], [this.validateEmail]],
          emailSurrId: [x['emailSurrId']],
          emailTemplateName: [this.templateData.emailTemplateName],
          createdBy: [x['createdBy']],
          dateCreated: [x['dateCreated']],
          modifiedBy: [x['modifiedBy']],
          dateModified: [x['dateModified']],
          dynamicRecipientInd:[x['dynamicRecipientInd']]
        }))
      })
    }
    this.dataSource.data = this.data.emailConfig;
  }
  // convenience getters for easy access to form fields
  get f() {
    return this.emailForm.controls;
  }
  get t() {
    return this.f.emailConfig as FormArray;
  }
  // Added fro GENE-735 -testing email send functionality.
  sendMail(event) {
    this.restService.get(`/people/email/sendEmail/${event}`).subscribe(res => {
    });
  }
  // Sorting of Table of email Config
  sortData(event): void {
    this.dataSource.sortingDataAccessor = (data, header) => {
      if (this.displayedColumns.includes(header)) {
        if (typeof (data[header]) != 'number' && data[header]) {
          return data[header].toString().toLowerCase();
        } else {
          return data[header];
        }
      }
    }
    this.dataSource.sort = this.sort;
  }
  //duplicate check
  checkDuplicateAttrName() {
    this.hasDuplicateAttr = false;
    if (this.emailForm) {
      let control = this.emailForm.controls.emailConfig as FormArray;
      this.data.emailConfig = control.value;
      this.data.emailConfig.map(v => v['triggerEventName']).sort().sort((a, b) => {
        if (a.toLowerCase() === b.toLowerCase()) {
          this.hasDuplicateAttr = true;
        }
      })
    }
  }

  // Delete triggerEvent
  deleteTriggerEvent(index, ele) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        header: 'Delete Trigger Event?',
        body: 'Do you want to proceed with deletion of selected trigger event?',
        note: '',
        button1: 'Cancel',
        button2: 'Yes'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        let control = <FormArray>this.emailForm.controls.emailConfig;
        if (control) {
          control.removeAt(index)
        }
        if (ele.emailSurrId) {
          let deleteIndex = this.dataSource.data.findIndex(temp => temp.emailSurrId === ele.emailSurrId);
          this.dataSource.data.splice(deleteIndex, 1);
          this.data.emailConfig = this.dataSource.data;
        } else if (ele.emailSurrId === '') {
          this.dataSource.data.splice(index, 1);
          this.data.emailConfig = this.dataSource.data;
        }
        this.dataSource = new MatTableDataSource();
        this.dataSource.data = this.data.emailConfig;
      }
    });
  }
  checkbox(event,index){
    if(event.checked){
      ((this.emailForm.get('emailConfig') as FormArray).at(index) as FormGroup).get('dynamicRecipientInd').patchValue('Y');
    }
    else{
      ((this.emailForm.get('emailConfig') as FormArray).at(index) as FormGroup).get('dynamicRecipientInd').patchValue('N');
    }
  }

  // Add new triggerEvent
  addTriggerEvent() {
    let control = <FormArray>this.emailForm.controls.emailConfig;
    this.data.emailConfig = control.value;
    this.checkDuplicateAttrName();
    control.push(
      this.fb.group({
        triggerEventName: ['', [Validators.required, Validators.maxLength(100), RxwebValidators.unique()]],
        emailRecipients: ['', [Validators.required, this.validateEmail]],
        emailCc: ['', [this.validateEmail]],
        emailBcc: ['', [this.validateEmail]],
        emailSurrId: [''],
        emailTemplateName: [this.emailForm.value['emailTemplateName']],
        createdBy: [''],
        dateCreated: [''],
        modifiedBy: [''],
        dateModified: [''],
        dynamicRecipientInd:['']
      })
    )
    this.data.emailConfig = control.value;
    this.dataSource = new MatTableDataSource();
    this.dataSource.data = this.data.emailConfig;
  }
  // Save form API
  save() {
    const controls = this.emailForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        this.emailForm.controls[name].markAsTouched();
      }
    }
    if (this.emailForm.invalid) {
      this.emailForm.markAllAsTouched();
      this.saveAction.emit('invalid form');
    } else if (this.emailForm.valid) {
      const controlAttr = <FormArray>this.emailForm.controls.emailConfig;
      this.data.emailConfig = controlAttr.value;
      for (var i in this.templateData) {
        if (this.emailForm.controls.hasOwnProperty(i)) {
          this.templateData[i] = this.emailForm.controls[i].value;
        }
      }
      // for(var email of this.data['emailConfig']){
      //   if(email.dynamicRecipientInd==true){
      //     email.dynamicRecipientInd='Y'
      //   }
      //   else{
      //     email.dynamicRecipientInd='N'
      //   }
      // }
      let dataObject = { 'emailTemplate': this.templateData, 'emailConfig': this.data['emailConfig'] }
      if (this.action === 'edit') {
        if (this.templateData['status'] === 'inactive' && this.initialData['status'] === 'active') {
          const dialogRef = this.dialog.open(ConfirmDialogComponent, {
            data: {
              header: 'Set to Inactive?',
              body: 'Your request to set Email Template to "Inactive" will result in associated Email Trigger Events to be no longer valid.',
              note: 'Do you want to proceed?',
              button1: 'Cancel',
              button2: 'Set Inactive'
            }
          });
          dialogRef.afterClosed().subscribe(result => {
            if (result === 'yes') {
              this.restService.put(`/people/email/template/${this.templateData.emailSurrId}`, dataObject).subscribe(data => {
                this.back.emit(true);
                this.saveAction.emit(data);
              });
            }
          });
        }
        else {
          this.restService.put(`/people/email/template/${this.templateData.emailSurrId}`, dataObject).subscribe(data => {
            this.saveAction.emit(data);
          });
        }
      }
      else if (this.action === 'add') {
        if (this.templateData['status'] === 'inactive' && this.emailForm.controls.status.touched && this.emailForm.controls.status.dirty) {
          const dialogRef = this.dialog.open(ConfirmDialogComponent, {
            data: {
              header: 'Set to Inactive?',
              body: 'Your request to set Email Template to "Inactive" will result in associated Email Trigger Events to be no longer valid.',
              note: 'Do you want to proceed?',
              button1: 'Cancel',
              button2: 'Set Inactive'
            }
          });
          dialogRef.afterClosed().subscribe(result => {
            if (result === 'yes') {
              this.restService.post(`/people/email/template`, dataObject).subscribe(data => {
                this.back.emit(true);
                this.saveAction.emit(data);
              });
            }
          });
        }
        else {
          this.restService.post(`/people/email/template`, dataObject).subscribe(data => {
            this.saveAction.emit(data);
          });
        }
      }
    }
  }
  // function for email validation with ';' as delimiter and @dbs.com domain
  validateEmail(control: AbstractControl) {
    let validEmail: boolean = false;
    let emailValidation;
    const listOfEmails = control.value.split('.com');
    if (control.value.includes('.com')) {
      // checking for semicolon as delimiter
      for (var i = 1; i < listOfEmails.length; i++) {
        listOfEmails[i].trim();
        if (listOfEmails[i].charAt(0) == ';') {
          validEmail = true;
        } else if (i == listOfEmails.length - 1 && (listOfEmails[i].charAt(0) == '' || listOfEmails[i].charAt(0) == ';')) {
          validEmail = true;
        } else {
          validEmail = false;
          break;
        }
      }
    } else if (control.value == "") {
      return null;
    } else { emailValidation = true; }

    if (validEmail) {
      const emails = control.value.split(';');
      var re = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
      for (let index = 0; index < emails.length; index++) {
        if (index != emails.length - 1 && re.test(emails[index])) {
          //Email valid. Procees to test if it's from the right domain (Second argument is to check that the string ENDS with this domain, and that it doesn't just contain it)
          if (emails[index].indexOf("@dbs.com", emails[index].length - "@dbs.com".length) !== -1) {
            emailValidation = null; // valid emails
          } else {
            emailValidation = true;
            break;
          }
        } else if (index == emails.length - 1 && emails[index] == '') {
          emailValidation = null; // valid emails
        } else if (index == emails.length - 1 && emails[index] != '') {
          if (re.test(emails[index])) {
            //Email valid. Procees to test if it's from the right domain (Second argument is to check that the string ENDS with this domain, and that it doesn't just contain it)
            if (emails[index].indexOf("@dbs.com", emails[index].length - "@dbs.com".length) !== -1) {
              emailValidation = null; // valid emails
            } else {
              emailValidation = true;
              break;
            }
          } else {
            emailValidation = true;
            break;
          }
        } else {
          emailValidation = true;
          break;
        }
      }
    } else {
      emailValidation = true;
    }
    if (emailValidation) {
      return ({ 'validateEmail': emailValidation });
    } else {
      return null;
    }
  }
}

