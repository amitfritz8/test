import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {SharedModule} from '../../common/module/shared.module';
import {GenericDataSummaryComponent} from './generic-data-summary.component';
import {SummaryDetailsComponent} from './summary-details/summary-details.component';

const routes: Routes = [
  {path: '', component: GenericDataSummaryComponent},
  {path: 'summary-details', component: SummaryDetailsComponent}
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule
  ],
  declarations: [GenericDataSummaryComponent, SummaryDetailsComponent]
})

export class GenericDataSummaryRoutingModule {
}
