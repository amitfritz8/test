import {Component, OnInit, AfterViewInit, Input, Output, EventEmitter, Attribute} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {FormBuilder, FormGroup, FormArray, Validators} from '@angular/forms';
import {RestService} from 'src/app/common/service/rest.service';
import {ConfirmDialogComponent} from 'src/app/common/component/dialogues/confirm-dialog/confirm-dialog-component';
import {MatDialog} from '@angular/material/dialog';
import {RxwebValidators} from '@rxweb/reactive-form-validators'

import {DataService} from 'src/app/common/service/data.service';
//import { ErrorsNotificationComponent } from 'srcomponents/errors-notification/errors-notification.component';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-summary-details',
  templateUrl: './summary-details.component.html',
  styleUrls: ['./summary-details.component.scss']
})
export class SummaryDetailsComponent implements OnInit, AfterViewInit {

  @Input() action: string;
  @Input() element: any;
  @Output() back: EventEmitter<boolean> = new EventEmitter();
  attrList: any;
  summaryForm: FormGroup;
  submitted = false;
  dataSummary: any;
  initialData: any;
  hasDuplicateAttr: boolean = false;
  disabled: boolean = false;
  headerInfo: any;
  isErrorExists: boolean = false;
  msg: string;
  msg1: any;
  subscription: Subscription;

  constructor(private fb: FormBuilder, private route: ActivatedRoute, private router: Router, private dataService: DataService,
              private restService: RestService, public dialog: MatDialog) {
    this.restService.track('GENERIC DATA SUMMARY DETAILS');
    this.headerInfo = {
      show_filters: false,
      nav_bk_url: "genericsummary",
      nav_bk_info: "Generic Data Summary",
      btns: {}
    }

    this.subscription = this.dataService.getMessage().subscribe(message => {
      this.goback();
    });

  }

  ngOnInit() {
    if (this.action !== 'add') {
      this.disabled = true;
      // removing null values from list.
      if (this.element['attributes']) {
        this.element['attributes'] = this.element['attributes'].filter(e => {
          return (e !== null);
        })
      }
      this.dataSummary = this.element['dataSummary'];
    } else {
      this.dataSummary = this.element['dataSummary'];
    }

    this.summaryForm = this.fb.group({
      dataName: [{value: this.dataSummary.dataName, disabled: this.disabled}, [Validators.required, Validators.maxLength(100)]],
      dataCode: [{value: this.dataSummary.dataCode, disabled: true}, [Validators.required]],
      status: [this.dataSummary.status, [Validators.required]],
      dataDesc: [this.dataSummary.dataDesc, [Validators.required, Validators.maxLength(1000)]],
      goldenSource: [this.dataSummary.goldenSource, [Validators.required, Validators.maxLength(50)]],
      interimSource: [this.dataSummary.interimSource, [Validators.required, Validators.maxLength(50)]],
      owner1Bankid: [this.dataSummary.owner1Bankid, [Validators.required, Validators.maxLength(50)]],
      ownerDeptname: [this.dataSummary.ownerDeptname, [Validators.required, Validators.maxLength(100)]],
      updateMethod: [this.dataSummary.updateMethod, [Validators.required, Validators.maxLength(100)]],
      updateFreq: [this.dataSummary.updateFreq, [Validators.required, Validators.maxLength(100)]],
      attributes: this.fb.array([])
    })

    this.initialData = this.summaryForm.value;

    //defaulting active status for add new page.
    if (this.action === 'add') {
      this.disabled = false;
      this.summaryForm.patchValue({
        status: 'active'
      });
      this.element['attributes'] = [{attrNo: 1, attr: ''}];
    } else {
      this.disabled = true;
    }
    this.setAttributes();
  }

  getControls(){
    return (this.summaryForm.get('attributes') as FormArray).controls;
  }

  //setting attributes form
  setAttributes() {
    let control = <FormArray>this.summaryForm.controls.attributes;
    if (this.element['attributes']) {
      this.element['attributes'].forEach(x => {
        control.push(this.fb.group({
          attrNo: [x['attrNo']],
          attr: [x['attr'], [Validators.required, Validators.maxLength(100), RxwebValidators.unique()]]
        }))
      })
    }
  }

  ngAfterViewInit() {
  }

  // Edit form
  editForm() {
    this.action = 'edit';
  }

  goback() {
    this.back.emit(true);
  }

  // Save Action
  save() {
    const controls = this.summaryForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        this.summaryForm.controls[name].markAsTouched();
      }
    }
    if (this.summaryForm.invalid) {
      this.summaryForm.markAllAsTouched();
    } else if (this.summaryForm.valid) {
      const controlAttr = <FormArray>this.summaryForm.controls.attributes;
      this.element.attributes = controlAttr.value;
      //fixing delete for previosly added attributes.
      //putting logic to rearrange attrNO so that it will work properly.
      if (this.element.attributes && this.element.attributes.length > 0) {
        for (var j = 0; j < this.element.attributes.length; j++) {
          this.element.attributes[j]['attrNo'] = j + 1;
        }
      }
      for (var i in this.dataSummary) {
        if (this.summaryForm.controls.hasOwnProperty(i)) {
          this.dataSummary[i] = this.summaryForm.controls[i].value;
        }
      }
      // console.log(this.summaryForm.controls);
      let dataObject = {'dataSummary': this.dataSummary, 'attributes': this.element['attributes']}
      if (this.action === 'edit') {
        // console.log(this.dataSummary['status']);
        // console.log(this.initialData['status']);
        if (this.dataSummary['status'] === 'inactive' && this.initialData['status'] === 'active') {
          const dialogRef = this.dialog.open(ConfirmDialogComponent, {
            data: {
              header: 'Set to Inactive?',
              body: 'Your request to set Ref Data Type to "Inactive" will result in associated Ref Data Values to be no longer available for selection.',
              note: 'Do you want to proceed?',
              button1: 'Cancel',
              button2: 'Set Inactive'
            }
          });
          dialogRef.afterClosed().subscribe(result => {
            if (result === 'yes') {
              this.restService.put(`/people/data/dataSummary/values/${this.dataSummary.dataCode}`, dataObject).subscribe(data => {
                this.back.emit(true);
              });
            }
          });
        }
        else {
          this.restService.put(`/people/data/dataSummary/values/${this.dataSummary.dataCode}`, dataObject).subscribe(data => {
            if (data['errorFlag'] !== null) {
              this.isErrorExists = true;
              this.dataService.getCustomMessage(data['message']);
              this.dataService.getFlag(data['errorFlag']);
            }
            //this.back.emit(true);
          });
        }
      }
      else if (this.action === 'add') {
        if (this.dataSummary['status'] === 'inactive' && this.summaryForm.controls.status.touched && this.summaryForm.controls.status.dirty) {
          const dialogRef = this.dialog.open(ConfirmDialogComponent, {
            data: {
              header: 'Set to Inactive?',
              body: 'Your request to set Ref Data Type to "Inactive" will result in associated Ref Data Values to be no longer available for selection.',
              note: 'Do you want to proceed?',
              button1: 'Cancel',
              button2: 'Set Inactive'
            }
          });
          dialogRef.afterClosed().subscribe(result => {
            if (result === 'yes') {
              this.restService.post(`/people/data/dataSummary/values/`, dataObject).subscribe(data => {
                this.back.emit(true);
              });
            }
          });
        }
        else {
          this.restService.post(`/people/data/dataSummary/values/`, dataObject).subscribe(data => {

            if (data['errorFlag'] !== null) {
              this.isErrorExists = true;
              this.dataService.getCustomMessage(data['message']);
              this.dataService.getFlag(data['errorFlag']);
            }
            //this.back.emit(true);
          });
        }
      }
    }
  }

  // Add new attribute
  addAttr() {
    let control = <FormArray>this.summaryForm.controls.attributes;
    this.element.attributes = control.value;
    this.checkDuplicateAttrName();
    if (this.element.attributes && this.element.attributes.length < 12 && !this.hasDuplicateAttr) {
      control.push(
        this.fb.group({
          attrNo: [this.element.attributes.length + 1],
          attr: ['', [Validators.maxLength(100), RxwebValidators.unique()]],
        })
      )
    }
    this.element.attributes = control.value;
  }

  // Delete attribute
  deleteAttr(index) {
    let control = <FormArray>this.summaryForm.controls.attributes;
    if (control && control.length > 1) {
      control.removeAt(index)
    }
  }

  // convenience getters for easy access to form fields
  get f() {
    return this.summaryForm.controls;
  }

  get t() {
    return this.f.attributes as FormArray;
  }

  //duplicate check
  checkDuplicateAttrName() {
    this.hasDuplicateAttr = false;
    let control = <FormArray>this.summaryForm.controls.attributes;
    this.element.attributes = control.value;
    this.element.attributes.map(v => v['attr']).sort().sort((a, b) => {
      if (a === b) {
        this.hasDuplicateAttr = true;
      }
    })
  }
}
