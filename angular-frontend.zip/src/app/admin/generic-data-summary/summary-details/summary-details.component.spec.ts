// import {ComponentFixture, TestBed} from '@angular/core/testing';
// import {SummaryDetailsComponent} from './summary-details.component';
// import {Component} from '@angular/core';
// import { RestService } from 'src/app/common/service/rest.service';
// import { DataService } from 'src/app/common/service/data.service';
// import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// import {MaterialModule} from 'src/app/material.module';
// import {FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormBuilder, FormArray} from '@angular/forms';
// import {BrowserModule, By} from '@angular/platform-browser';
// import {of, Subscription, Observable, Subject} from 'rxjs';
// import { ErrorsNotificationComponent } from 'src/app/common/component/errors-notification/errors-notification.component';
// import {ActivatedRoute, Router} from '@angular/router';
// import 'rxjs/add/operator/map';
// import {MatDialogRef} from '@angular/material/dialog'
// import {configureTestSuite} from 'ng-bullet';

// describe('SummaryDetailsComponent', () => {
//   let component: SummaryDetailsComponent;
//   let fixture: ComponentFixture<SummaryDetailsComponent>;
//   const formBuilder: FormBuilder = new FormBuilder();

//   configureTestSuite(() => {
//     TestBed.configureTestingModule({
//       declarations: [SummaryDetailsComponent, ErrorsNotificationComponent],
//       imports: [BrowserAnimationsModule,
//         MaterialModule,
//         FormsModule,
//         ReactiveFormsModule,
//         BrowserModule],
//       providers: [
//         {provide: RestService, useClass: MockRestService},
//         {provide: MatDialogRef, useClass: MockMatDialogRef},
//         {provide: ErrorsNotificationComponent},
//         {provide: ActivatedRoute},
//         {provide: Router, useClass: MockRouter},
//         {provide: DataService, useClass: MockDataService},
//         {provide: Subscription},
//         {provide: Component},
//         {provide: FormBuilder, useValue: formBuilder}
//       ]
//     })

//   });
//   beforeEach(() => {
//     fixture = TestBed.createComponent(SummaryDetailsComponent);
//     component = fixture.componentInstance;
//     component.element = {
//       attributes: [{attrNo: 1, attr: ''}],
//       dataSummary: DATA_SUMMARY
//     };
//     component.action = 'view';
//     component.disabled = false;
//     fixture.detectChanges();
//   });


//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('edit form()', () => {
//     component.action = 'add';
//     component.editForm();

//   });

//   it('goBack()', () => {
//     component.goback();
//   });

//   it('save()', () => {
//     component.element = {
//       attributes: [{'attr': 'sdcsdc'}, {'attr': 'sdcsdc'}],
//       dataSummary: DATA_SUMMARY
//     };
//     component.action = 'edit';
//     fixture.detectChanges();
//     component.summaryForm = formBuilder.group({

//       dataName: [''],
//       dataCode: [''],
//       status: [''],
//       dataDesc: [''],
//       goldenSource: [''],
//       interimSource: [''],
//       owner1Bankid: [''],
//       ownerDeptname: [''],
//       updateMethod: [''],
//       updateFreq: [''],
//       attributes: [{'attr': 'sdcsdc'}, {'attr': 'sdcsdc'}]

//     })
//     fixture.componentInstance.save();
//     component.action = 'edit';
//     expect(component.action).toEqual('edit');
//   });

//   it('save() add', () => {
//     component.element = {
//       attributes: [{'attr': 'sdcsdc'}, {'attr': 'sdcsdc'}],
//       dataSummary: DATA_SUMMARY
//     };
//     component.action = 'add';
//     fixture.detectChanges();
//     component.summaryForm = formBuilder.group({

//       dataName: [''],
//       dataCode: [''],
//       status: [''],
//       dataDesc: [''],
//       goldenSource: [''],
//       interimSource: [''],
//       owner1Bankid: [''],
//       ownerDeptname: [''],
//       updateMethod: [''],
//       updateFreq: [''],
//       attributes: [{'attr': 'sdcsdc'}, {'attr': 'sdcsdc'}]

//     })
//     fixture.componentInstance.save();
//     component.action = 'add';
//     expect(component.action).toEqual('add');
//   });

//   it('save() with no summaryform', () => {
//     component.element = {
//       attributes: [{'attr': 'sdcsdc'}, {'attr': 'sdcsdc'}],
//       dataSummary: DATA_SUMMARY
//     };
//     component.action = 'add';
//     fixture.detectChanges();
//     fixture.componentInstance.save();
//     component.action = 'add';

//     expect(component.action).toEqual('add');
//   });

//   it('addAttr()', () => {
//     component.element = {
//       attributes: [
//         {
//           'attrNo': '1',
//           'attr': 'Countrycode'
//         },
//         {
//           'attrNo': '2',
//           'attr': 'dass'
//         },
//         {
//           'attrNo': '3',
//           'attr': 'count'
//         },
//         {
//           'attrNo': '4',
//           'attr': 'sss'
//         }
//       ],
//       dataSummary: DATA_SUMMARY
//     };
//     component.action = 'add';
//     fixture.detectChanges();
//     component.summaryForm = formBuilder.group({

//       dataName: [''],
//       dataCode: [''],
//       status: [''],
//       dataDesc: [''],
//       goldenSource: [''],
//       interimSource: [''],
//       owner1Bankid: [''],
//       ownerDeptname: [''],
//       updateMethod: [''],
//       updateFreq: [''],
//       attributes: [{'attr': 'sdcsdc'}, {'attr': 'sdcsdc'}]

//     })
//     spyOn(component, 'checkDuplicateAttrName');
//     component.addAttr();
//     expect(component.checkDuplicateAttrName).toHaveBeenCalled();
//   });

//   it('deleteAttr()', () => {
//     component.element = {
//       attributes: [{'attr': 'sdcsdc'}, {'attr': 'sdcsdc'}],
//       dataSummary: DATA_SUMMARY
//     };
//     component.action = 'add';
//     fixture.detectChanges();
//     component.summaryForm = formBuilder.group({

//       dataName: [''],
//       dataCode: [''],
//       status: [''],
//       dataDesc: [''],
//       goldenSource: [''],
//       interimSource: [''],
//       owner1Bankid: [''],
//       ownerDeptname: [''],
//       updateMethod: [''],
//       updateFreq: [''],
//       attributes: [{'attr': 'sdcsdc'}, {'attr': 'sdcsdc'}]

//     })
//     fixture.detectChanges();
//     component.hasDuplicateAttr = false;

//     component.deleteAttr(3);
//   });

//   it('should call for checkDuplicateAttrName', (done: DoneFn) => {
//     component.checkDuplicateAttrName();
//     component.hasDuplicateAttr = false;
//     component.element = {
//       attributes: [{'attr': 'sa'}, {'attr': 'sa'}],
//       dataSummary: DATA_SUMMARY
//     };
//     component.element.attributes[0].attr = component.element.attributes[1].attr;
//     component.hasDuplicateAttr = true;
//     done();
//   });


// });

// class MockRestService {
//   get() {
//     return of([{'platformId': '1', 'platformIndex': '01', 'platform': 'test platform'}]);
//   }

//   put() {
//     return of({});
//   }

//   post() {
//     return of({});
//   }
//   track(pageName: string) {
//     return null;
//   }
// }

// class MockDataService {
//   subject: Subject<any>;

//   getCustomMessage() {
//     return 'marissa';
//   }

//   getFlag() {
//     return '201908';
//   }

//   getMessage(): Observable<any> {
//     return new Observable;
//   }
// }

// class MockRouter {
//   navigateByUrl(url: any) {
//     return null;
//   }
// }

// class Mockmap {
//   map() {
//     return of({});
//   }
// }

// const DATA_SUMMARY = {
//   'createdBy': null,
//   'dateCreated': null,
//   'modifiedBy': 'pooja3',
//   'dateModified': 1573627836000,
//   'dataCode': 1,
//   'dataName': 'Country',
//   'dataDesc': 'List of DBS offices in various countries 1',
//   'status': 'active',
//   'goldenSource': 'GENE',
//   'interimSource': 'Not Applicable',
//   'owner1Bankid': 'Smita CHOUDHARY',
//   'ownerDeptname': 'PTO',
//   'updateMethod': 'Manual Entry',
//   'updateFreq': 'frequency'
// };

// class MockMatDialogRef {
//   afterClosed() {
//     return of({});
//   }
// }
