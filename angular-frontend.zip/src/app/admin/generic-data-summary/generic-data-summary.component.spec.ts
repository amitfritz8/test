// import {async, ComponentFixture, TestBed, fakeAsync, tick} from '@angular/core/testing';

// import {GenericDataSummaryComponent} from './generic-data-summary.component';
// import {NO_ERRORS_SCHEMA} from '@angular/core';
// import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// import {BrowserModule, By} from '@angular/platform-browser';
// import 'rxjs/add/operator/map';
// import 'rxjs/operator/delay';
// import 'rxjs/operator/mergeMap';
// import 'rxjs/operator/switchMap';
// import {of, Subject} from 'rxjs';
// import {FormBuilder, FormControl, FormGroup, Validators, FormsModule, ReactiveFormsModule} from '@angular/forms';
// import {MaterialModule} from 'src/app/material.module';
// import { RestService } from 'src/app/common/service/rest.service';
// import { DataService } from 'src/app/common/service/data.service';
// import {HttpHeaders, HttpClient, HttpClientModule} from '@angular/common/http';
// import {dataUri} from '@rxweb/reactive-form-validators';
// import {configureTestSuite} from 'ng-bullet';

// xdescribe('GenericDataSummaryComponent', () => {
//   let component: GenericDataSummaryComponent;
//   let fixture: ComponentFixture<GenericDataSummaryComponent>;


//   configureTestSuite(() => {
//     TestBed.configureTestingModule({
//       declarations: [GenericDataSummaryComponent],
//       schemas: [NO_ERRORS_SCHEMA],
//       imports: [BrowserAnimationsModule,
//         MaterialModule,
//         FormsModule,
//         ReactiveFormsModule,
//         BrowserModule, HttpClientModule],
//       providers: [
//         {provide: RestService, useClass: MockRestService},
//         DataService]
//     })
//     fixture = TestBed.createComponent(GenericDataSummaryComponent);
//     component = fixture.componentInstance;
//   });

//   it('should create', async () => {
//     expect(component).toBeTruthy();
//   });

//   it('should call for ngOninit', (done: DoneFn) => {
//     component.ngOnInit();
//     let s: MockRestService = new MockRestService();
//     spyOn(s, 'get');
//     s.get();
//     expect(s.get).toHaveBeenCalled();
//     done();
//   });

//   it('should call for applyFilter', (done: DoneFn) => {
//     spyOn(component, 'applyFilter').and.callThrough();
//     component.applyFilter('filtervalue');
//     expect(component.applyFilter).toHaveBeenCalled();
//     done();
//   });

//   it('should call for ngAfterViewInit', (done: DoneFn) => {
//     spyOn(component, 'ngAfterViewInit').and.callThrough();
//     component.ngAfterViewInit();
//     expect(component.ngAfterViewInit).toHaveBeenCalled();
//     done();
//   });

//   it('should call for gotoDetails for add', (done: DoneFn) => {
//     const element = [{'element': {'code': '123'}}];
//     spyOn(component, 'gotoDetails').and.callThrough();
//     component.gotoDetails('e', element, 'add');
//     expect(component.gotoDetails).toHaveBeenCalled();
//     done();
//   });

//   it('should call for getData', (done: DoneFn) => {
//     component.getData();
//     let s: MockRestService = new MockRestService();
//     spyOn(s, 'get');
//     s.get();
//     expect(s.get).toHaveBeenCalled();
//     done();
//   });

//   it('should call for onBackClicked', (done: DoneFn) => {
//     component.onBackClicked(null);
//     let s: MockRestService = new MockRestService();
//     spyOn(s, 'get');
//     s.get();
//     expect(s.get).toHaveBeenCalled();
//     done();
//   });

// })
// ;

// class MockRestService {
//   get() {
//     return of([{status: 'active'}]);
//   }
//   track(pageName: string) {
//     return null;
//   }
// }
