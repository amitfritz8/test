import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { URL_PREFIX } from 'src/app/common/constants/urlprefix';
import LoginModel from "./login.model";
import { Observable } from 'rxjs';

@Injectable()
export class LoginService {
  private ACCESS_TOKEN = 'access_token';

  constructor(private http: HttpClient) { }

  public isUserLoggedIn(): Promise<boolean> {
    return this.getUserInfo().then((userInfo) => {
      return (!!userInfo.user_name);
    });
  }

  /**
   * once user successfully logs in, this will help get the ldap user related custom application settings from server
   */
  public getUserInfo(): Promise<any> {
    const accessToken = localStorage.getItem(this.ACCESS_TOKEN);
    return Promise.resolve((accessToken && accessToken.length) ? this.parseJwt(accessToken) : {});
  }

  public entitlementLogin(username: string, password: string): Promise<any> {
    var headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return new Promise((resolve, reject) => {
      if (username && password) {
        const data = {
          username: username,
          password: password
        };
        const url = URL_PREFIX.AUTH + '/authenticate';
        localStorage.clear();
        const options = { headers: headers };
        this.http.post(url, data, options).toPromise().then((response: Response) => {
          const userInfo = response;
          let user: any = userInfo;
          if (user.errorFlag == 0 && this.storeAuthenticationToken(userInfo)) {
            if (user.errorFlag == '0') {
              this.getUserInfo().then(resolve);
            } else {
              return reject(new Error('Invalid Authorization header'));
            }
          } else if (user.errorFlag == '1') {
            return reject(new Error(user.message));
          }
        }, reject).catch(reject);
      } else {
        return reject(new Error('Either username or password missing'));
      }
    });
  }

  /**
   * this method parses the JWT token to get the userInfo.
   * @param token - UAA returned JWT token
   */
  private parseJwt(token) {
    const basedUrls = token.split('.');
    const base64Url = basedUrls[1];
    const base64 = base64Url.replace('-', '+').replace('_', '/');
    return JSON.parse(atob(base64));
  }

  private storeAuthenticationToken(userData): boolean {
    if (userData && userData.token) {
      localStorage.setItem(this.ACCESS_TOKEN, userData.token);
      localStorage.setItem('userinfo', JSON.stringify(userData.userInfo));
      localStorage.setItem('userOneBankId', userData.userInfo.username);
      return true;
    }
    return false;
  }

  public sampleService(username: string, password: string): Observable<LoginModel> {
    try {
      const url = URL_PREFIX.AUTH + '/authenticate';
      return this.http.post<LoginModel>(url, {
        username: username,
        password: password
      });
    }catch(e){
      console.log(e);
    }
  }
}
