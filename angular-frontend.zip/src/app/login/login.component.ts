import { Component, OnDestroy, OnInit, NgZone } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Subscription } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/operator/delay';
import 'rxjs/operator/mergeMap';
import 'rxjs/operator/switchMap';
import * as moment from 'moment';

import { LoginService } from './login.service';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import LoginModel from "./login.model";
import {CommonService} from 'src/app/common/service/common.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
    public date: string;
    public time: string;
    public username: string;
    public password: string;
    public appName: string;
    form: FormGroup;

    loginInfo: LoginModel;

    private ACCESS_TOKEN = 'access_token';
    public USER_ROLE = 'user_role';
    public loginWelcomeMsg: string = 'Welcome';
    public inValidCredentials: boolean = false;

    private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    public base_url: string;

    public loginPanelStyle: any = {
        'scale-down': false
    };
    public usernameStyle: any = {
        'hide-sg-portal--username': false
    };
    public isOpen = false;
    public footerButtonStyle: any = {
        'move-down': true
    };
    public numberedButtonStyle: any = {
        disappear: false
    };
    public TIME_REFRESH_INTERVAL: number = 1 * 1000;
    private timerSubs: Subscription;
    private clearTimer: any;

    public returnUrl;
    ErrorExists: boolean = false;
    errorMsg: any;

    constructor(private _fb: FormBuilder, private activatedRoute: ActivatedRoute, private zone: NgZone, private http: HttpClient,
        private router: Router, private ls: LoginService, private commonService: CommonService) {

        // FIX to use runOutsideAngular() for protractor testing: https://medium.com/@jarifibrahim/the-curious-case-of-protractor-and-page-synchronization-58b4e81366ac
        this.zone.runOutsideAngular(() =>{
            setInterval(() => {
                this.zone.run(() => {
                    var today = new Date();
                    var h = today.getHours();
                    var m = today.getMinutes();
                    var s = today.getSeconds();
                    this.time = this.addZero(h) + ':' + this.addZero(m) + ':' + this.addZero(s);
                });
            }, 1);
        });

        
    }

    addZero(i) {
        return (i < 10) ? `0${i}` : i;
    }

    public ngOnInit() {
        // document.getElementById('bg-vid').play();

        this.form = this._fb.group({
            username: new FormControl(Validators.compose([])),
            password: new FormControl(Validators.compose([]))
        });
        if (localStorage.getItem('access_token')) {
            this.router.navigateByUrl('/home');
        } else {
            this.appName = 'Gene';
            this.date = moment().format('DD MMMM YYYY');
            this.activatedRoute.queryParams
                .subscribe((queryParamsObj: Params) => {
                    let returnUrlFromParams = queryParamsObj['returnUrl'] || '/';
                    this.returnUrl = decodeURIComponent(returnUrlFromParams);
                });
            sessionStorage.clear();
        }
    }

    public login(): void {
        this.username = this.form.controls.username.value;
        this.password = this.form.controls.password.value;
        // console.log(this.password);
        this.inValidCredentials = false;
        this.ErrorExists = false;
        this.ls.entitlementLogin(this.username, this.password).then((userInfo: any) => {
            this.commonService.loaderEvent.emit(true);
            if ((-1 !== window.location.hostname.indexOf('localhost')) ||
                (-1 !== window.location.hostname.indexOf('.dev')) ||
                (-1 !== window.location.hostname.indexOf('.sit'))) {
                if (this.returnUrl === '/') {
                    this.router.navigateByUrl('/home');
                } else {
                    this.router.navigateByUrl(this.returnUrl);
                }
            } else if ((-1 !== window.location.hostname.indexOf('.uat')) ||
                (-1 !== window.location.hostname.indexOf('.prod'))) {
                if (this.returnUrl === '/') {
                    this.router.navigateByUrl('/home');
                } else {
                    this.router.navigateByUrl(this.returnUrl);
                }
            }
        }).catch((msg) => {
            this.errorMsg = msg;
            if (this.errorMsg.status === 401) {
                this.ErrorExists = true;
                this.errorMsg.message = 'Unable to verify 1BankId or password. Please try again with valid credentials';
            } else {
                this.ErrorExists = true;
            }
        });

        // this.ls.sampleService(this.username, this.password).subscribe(data=>{
        //     this.loginInfo = data;
        //     console.log(data);
        // }, err =>{
        //     console.log(err);
        // });
    }

    public footerButton(): void {
        this.isOpen = !this.isOpen;
    }

    public onValueChange(value: string, type: string): void {
        if (type === 'username') {
            this.username = value;
        } else {
            this.password = value;
        }
    }

    public ngOnDestroy() {
        if (this.timerSubs) {
            this.timerSubs.unsubscribe();
        }
        if (this.clearTimer) {
            clearTimeout(this.clearTimer);
        }
    }
}
