class UserInfo{
    ldapUserInfo: object;
    mapping: object;
    username: string;
    displayName: string;
    departmentCode: string;
    securityGroups: Array<string>;
}

export default UserInfo;