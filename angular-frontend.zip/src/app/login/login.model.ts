import UserInfo from "./login-userinfo.model";

class LoginModel{
    token: number;
    message: string;
    timestamp: number;
    errorFlag: string;
    userInfo: string;
}

export default LoginModel;