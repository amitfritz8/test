import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/common/module/shared.module';
import { EditWorkstreamComponent } from './edit-workstream.component';

const routes: Routes = [
    {path: '', component: EditWorkstreamComponent}
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
    CommonModule
  ],
  declarations: [
    EditWorkstreamComponent
  ],
  exports: [],
  entryComponents: []
})

export class EditWorkStreamRoutingModule {
}