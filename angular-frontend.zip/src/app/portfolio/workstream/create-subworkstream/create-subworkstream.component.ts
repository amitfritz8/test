import {Component, OnInit, OnDestroy} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import {Router} from '@angular/router';
import {RestService} from 'src/app/common/service/rest.service';
import {DateUtility} from 'src/app/common/utility/date-utility';
import {DataService} from 'src/app/common/service/data.service';
import {WORK_HIERARCHY_CONST} from 'src/constants/workHierarchy';
import {URL_PREFIX} from 'src/constants/urlsprefix';
import {CommonService} from 'src/app/common/service/common.service'
import {Subscription} from 'rxjs';
import {MatDialog} from '@angular/material/dialog';
import {CommonDialogComponent} from 'src/app/common/component/dialogues/common-dialog/common-dialog-component';
import { debounce } from 'lodash';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-create-subworkstream',
  templateUrl: './create-subworkstream.component.html',
  styleUrls: ['./create-subworkstream.component.scss']
})
export class CreateSubworkstreamComponent implements OnInit, OnDestroy {

  subWorkStreamForm: FormGroup;
  deliveryPlatformUnitList: any = [];
  deliveryUnitTooltip: string;
  workStreamId: any;
  workStreamName: any;
  subWorkStreamId: any;
  subWorkStreamName: any;
  subWorkStreamData: any = [];
  portfolioId: any;
  portfolioName: any;
  resSuccess: boolean;
  isDeliveryUnitExist: boolean;
  prepareData: any;

  headerInfo;
  tabObserver: Subscription;
  selectedTab: string;

  constructor(private formBuilder: FormBuilder, private dataService: DataService, private router: Router, private restService: RestService,
              private dateUtility: DateUtility, private commonService: CommonService, public dialog: MatDialog) {
    this.headerInfo = {
      title: 'Create Sub-WorkStream',
      show_filters: false,
      tabs: ['Work Profile']
    }
    this.selectedTab = this.headerInfo.tabs[0];
    this.commonService.recieveMessage(this.headerInfo);
  }

  ngOnInit() {
    // tab observer
    this.tabObserver = this.commonService.selectedTab.subscribe(data => {
      this.selectedTab = data;
    });

    this.subWorkStreamForm = this.formBuilder.group({
      subWorkStreamName: ['', [Validators.required, Validators.maxLength(200)]],
      deliveryUnit: ['', [Validators.required]]
    });

    this.subWorkStreamForm.get('subWorkStreamName').valueChanges.pipe(debounceTime(500)).subscribe(data => {
      this.checkSubWorkStreamExist(data);
    });
    this.getData();
  }

  ngOnDestroy() {
    this.tabObserver.unsubscribe();
  }

  getData() {
    this.restService.get(URL_PREFIX.PEOPLE + '/data/platforms/all').subscribe(data => {
      data.forEach((element: { platformId: any; platformIndex: string; platform: string; }) => {
        this.deliveryPlatformUnitList.push({key: element.platformId, value: element.platformIndex + ' - ' + element.platform});
      });

    });
  }

  cnfmClbk(dialogRef) {
    dialogRef.close();
    this.router.navigateByUrl('home/portfolio');
  }

  goback() {
    if (this.subWorkStreamForm.touched) {
      const dialogRef = this.dialog.open(CommonDialogComponent, {
        data: {
          type: 'warning',
          contentTitle: 'Unsaved Changes',
          content: 'You are leaving with unsaved changes, any changes will be lost.\nAre you sure you want to leave this page?',
          confirmTxt: 'Proceed',
          cancelTxt: 'Cancel',
          confirmCallBack: this.cnfmClbk.bind(this)
        }
      });
    } else {
      this.router.navigateByUrl('home/portfolio');
    }
  }

  get formData() {
    return this.subWorkStreamForm.controls;
  }

  saveSubWorkStream() {
    const controls = this.subWorkStreamForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        this.subWorkStreamForm.controls[name].markAsTouched();
      }
    }
    if (this.subWorkStreamForm.invalid) {
      this.subWorkStreamForm.markAllAsTouched();
    } else if (this.subWorkStreamForm.valid) {
      this.prepareData.portFolioSubWorkStreamEntity = this.subWorkStreamForm.value;
      this.restService.post(URL_PREFIX.PORTFOLIO + '/data/subworkstream/generation', this.prepareData).subscribe(data => {
          if (data.subWorkStreamId !== undefined && data.subWorkStreamId !== null) {
            console.log('in if condition>>>>>>>' + typeof (data));
            this.subWorkStreamId = data.subWorkStreamId;
            this.subWorkStreamName = data.subWorkStreamName;
            sessionStorage.setItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID, this.subWorkStreamId);
            sessionStorage.setItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME, this.subWorkStreamName);
            this.dataService.sendMessageItemChange(WORK_HIERARCHY_CONST.PORTFOLIO);
            this.resSuccess = true;
            this.subWorkStreamData = data;
            this.commonService.showSnackBar({
              type: 'success',
              message: 'Subworkstream Created'
            });
            this.subWorkStreamForm.reset();
          } else {
            console.log('in else condition>>>>>>>>>  ' + typeof (data));
            this.isDeliveryUnitExist = true;
          }
        },
        error => {
          if (error.status !== null) {
          }
        }
      );
    }
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustom(date);
  }

  checkSubWorkStreamExist(subWorkStreamName: any) {
    const postData = {
      dataType: WORK_HIERARCHY_CONST.SUB_WORKSTREAM,
      dataName: subWorkStreamName,
      streamId: sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID)
    };
    this.restService.post(URL_PREFIX.PORTFOLIO + '/data/portfolio/dataname', postData).subscribe(data => {
        if(data){
          this.subWorkStreamForm.get('subWorkStreamName').setErrors({duplicate: true});
        }else{
          this.subWorkStreamForm.get('subWorkStreamName').setErrors(null);
        }
      }
    );
  }

  onDeliveryUnitChnage() {
    this.portfolioId = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID);
    this.portfolioName = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME);
    this.workStreamId = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID);
    this.workStreamName = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME);
    console.log(this.subWorkStreamForm);
    this.prepareData = {
      portFolioSubWorkStreamEntity: this.subWorkStreamForm.value,
      workStreamId: this.workStreamId,
      workStreamName: decodeURIComponent(this.workStreamName),
      portfolioId: this.portfolioId,
      portfolioName: decodeURIComponent(this.portfolioName)
    };
    this.subWorkStreamForm.controls.deliveryUnit.markAsTouched();
    this.isDeliveryUnitExist = false;
    this.restService.post(URL_PREFIX.PORTFOLIO + '/data/subworkstream/generation/isExistsWorkStreamId', this.prepareData).subscribe(data => {

        if (data) {
          console.log('in if condition>>>>>>>' + typeof (data));
          this.isDeliveryUnitExist = true;
        }
      },
      error => {
        if (error.status !== null) {
        }
      }
    );
  }
}
