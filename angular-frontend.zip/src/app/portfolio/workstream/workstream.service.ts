import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class WorkStreamService {

    constructor(private httpClient: HttpClient) { }

    copyTo(data): any {
        return this.httpClient.post('portfolio/data/workstream/copyScenario', data);
    }

    getScenario(params): any {
        return this.httpClient.get('portfolio/data/workstream/scenarios', { params: params });
    }

    getApprovers(params): any {
        return this.httpClient.get(`portfolio/data/workstream/scenariosForCopyApproval`, { params: params });
    }

    postApprovers(data): any {
        const HttpUploadOptions = {
            headers: new HttpHeaders({ "Content-Type": "multipart/form-data" })
        }
        return this.httpClient.post(`portfolio/data/workstream/approveCopyScenario`, data);
    }
}