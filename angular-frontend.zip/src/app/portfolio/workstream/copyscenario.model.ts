export interface CopyScenarioModel {
    workStreamId: string;
    scenarioFrom: string;
    scenarioTo: string;
    portFolioId: string;
}