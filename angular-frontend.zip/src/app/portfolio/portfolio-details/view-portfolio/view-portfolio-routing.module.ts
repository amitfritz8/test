import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/common/module/shared.module';
import { ViewPortfolioComponent } from './view-portfolio.component';

const routes: Routes = [
    {path: '', component: ViewPortfolioComponent}
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
  ],
  declarations: [
    ViewPortfolioComponent
  ],
  exports: [],
  entryComponents: []
})

export class ViewPortfolioRoutingModule {
}