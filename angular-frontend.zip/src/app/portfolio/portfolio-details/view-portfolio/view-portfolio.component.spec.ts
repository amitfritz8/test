import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewPortfolioComponent } from './view-portfolio.component';
import { DebugElement, Component } from '@angular/core';
import { By, BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/material.module';
import { SharedModule } from 'src/app/common/module/shared.module';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { RouterTestingModule } from '@angular/router/testing';
import { } from 'jasmine';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { TimeFormat } from 'src/app/common/pipes/timeFormater.pipe';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { of } from 'rxjs';

xdescribe('ViewPortfolioComponent', () => {
  let component: ViewPortfolioComponent;
  let fixture: ComponentFixture<ViewPortfolioComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ViewPortfolioComponent],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        SharedModule,
        RouterTestingModule,
        HttpClientModule,
        BrowserAnimationsModule
      ],
      providers: [
        // tslint:disable-next-line: no-use-before-declare
        { provide: DateUtility, useClass: MockDateUtility },
        // tslint:disable-next-line: no-use-before-declare
        { provide: RestService, useClass: MockRestService },
        DataService,
        // tslint:disable-next-line: no-use-before-declare
        { provide: TimeFormat, useClass: MockTimeFormat },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPortfolioComponent);
    component = fixture.componentInstance;
    component.portfolioID = 'P01-180014-I';
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.mainDiv'));
    el = de.nativeElement;
  });

  it('should create', () => {
    expect(ViewPortfolioComponent).toBeTruthy();
  });


  describe('dateFormat', () => {
    it('should call date format', () => {
      const date = new Date();
      component.dateFormat(new Date());
      // tslint:disable-next-line: no-use-before-declare
      const c: MockDateUtility = new MockDateUtility();
      spyOn(c, 'dateFormatterCustom');
      c.dateFormatterCustom(date);
      expect(c.dateFormatterCustom).toHaveBeenCalled();
    });
  });

  describe('timeFormat', () => {
    it('should call time format', () => {
      const date = new Date();
      component.timeFormat(new Date());
      // tslint:disable-next-line: no-use-before-declare
      const c: MockTimeFormat = new MockTimeFormat();
      spyOn(c, 'transform');
      c.transform(date);
      expect(c.transform).toHaveBeenCalled();
    });
  });

  describe('goback', () => {
    it('should call go back', () => {
      component.goback();
      // tslint:disable-next-line: no-use-before-declare
      const router: MockRouter = new MockRouter();
      spyOn(router, 'navigateByUrl');
      router.navigateByUrl('home/portfolio');
      expect(router.navigateByUrl).toHaveBeenCalled();
    });
  });


});


class MockRestService {
  get() {
    return of({
      data: {
        portfolioId: 'P01-180014-I',
        portfolioName: 'asdasdas',
        initiationYear: '2018',
        workType: 'I',
        primaryPlatformIndex: '01',
        primaryPlatformName: '01 - CBG Customer Mgt & Analytics',
      }

    });
  }
}


class MockRouter {
  navigateByUrl(url: any) {
    return null;
  }
}

class MockDateUtility {
  dateFormatterCustom(date?: Date) {
    return '';
  }
}

class MockTimeFormat {
  transform(date?: Date) {
    return '';
  }
}



