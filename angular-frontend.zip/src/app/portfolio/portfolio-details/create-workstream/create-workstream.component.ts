import {Component, OnInit, OnDestroy} from '@angular/core';
import {Validators, FormBuilder, FormGroup} from '@angular/forms';
import {Router} from '@angular/router';
import {RestService} from 'src/app/common/service/rest.service';
import {DataService} from 'src/app/common/service/data.service';
import {WORK_HIERARCHY_CONST} from 'src/constants/workHierarchy';
import {DateUtility} from 'src/app/common/utility/date-utility';
import {URL_PREFIX} from 'src/constants/urlsprefix';
import {CommonService} from 'src/app/common/service/common.service';
import {Observable, Subscription, BehaviorSubject} from 'rxjs';
import {debounceTime, switchMap, distinctUntilChanged, filter} from 'rxjs/operators';
import {MatDialog} from '@angular/material/dialog';
import {CommonDialogComponent} from 'src/app/common/component/dialogues/common-dialog/common-dialog-component';

@Component({
  selector: 'app-create-workstream',
  templateUrl: './create-workstream.component.html',
  styleUrls: ['./create-workstream.component.scss']
})
export class CreateWorkstreamComponent implements OnInit, OnDestroy {
  workstreamForm: FormGroup;
  countryDropdown: any = [];
  action: string = 'add';
  workstreamID: any;
  workstreamName: any;
  portfolioId: string;
  portfolioName: any;
  resSuccess: boolean;
  workStreamData: any = [];
  isWorkStreamNameExist: boolean;
  showName: string;
  data: any;
  headerInfo;
  selectedTab: string;
  tabObserver: Subscription;
  wsName$ = new BehaviorSubject<string>('');
  wsNameExist$: Observable<any>;

  constructor(private fb: FormBuilder, private router: Router, private restService: RestService, private dataService: DataService, private dateUtility: DateUtility,
              private commonService: CommonService, public dialog: MatDialog) {
    this.headerInfo = {
      title: 'Create Workstream',
      additional_info: ' ',
      show_filters: false,
      tabs: ['Work Profile']
    }
    this.commonService.recieveMessage(this.headerInfo);
    this.selectedTab = this.headerInfo.tabs[0];
  }

  ngOnInit() {
    this.workstreamForm = this.fb.group({
      workStreamName: ['', [Validators.required]],
      country: ['', [Validators.required]],
    });
    this.getData();

    // for updating tabs
    this.tabObserver = this.commonService.selectedTab.subscribe(data => {
      this.selectedTab = data;
    })

    this.wsNameExist$ = this.wsName$.pipe(
      filter(text => text.length >= 2),
      debounceTime(1000),
      distinctUntilChanged(),
      switchMap(workStreamName => this.checkWorkStreamExist(workStreamName))
    );

    this.wsNameExist$.subscribe(
      data => {
        if (data) {
          this.workstreamForm.controls['workStreamName'].setErrors({duplicate: true});
        } else {
          this.workstreamForm.controls['workStreamName'].setErrors(null);
        }
        this.isWorkStreamNameExist = data;
      }
    );
  }

  ngOnDestroy() {
    this.tabObserver.unsubscribe();
    this.wsName$.complete();
  }

  getData() {
    this.action = this.dataService.getAction();
    this.countryDropdown = [];
    let locations = JSON.parse(sessionStorage.getItem('locationsAsPerUAMS'));
    locations.forEach(element => {
      this.countryDropdown.push({'value': element, 'display': element});
    });
  }

  get f() {
    return this.workstreamForm.controls;
  }

  cnfmClbk(dialogRef) {
    dialogRef.close();
    this.router.navigateByUrl('home/portfolio');
  }

  goback() {
    if (this.workstreamForm.touched) {
      const dialogRef = this.dialog.open(CommonDialogComponent, {
        data: {
          type: 'warning',
          contentTitle: 'Unsaved Changes',
          content: 'You are leaving with unsaved changes, any changes will be lost.\nAre you sure you want to leave this page?',
          confirmTxt: 'Proceed',
          cancelTxt: 'Cancel',
          confirmCallBack: this.cnfmClbk.bind(this)
        }
      });
    } else {
      this.router.navigateByUrl('home/portfolio');
    }
  }

  saveworkstream() {

    if (this.isWorkStreamNameExist) {
      return;
    }
    const controls = this.workstreamForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        this.workstreamForm.controls[name].markAsTouched();
      }
    }
    if (this.workstreamForm.invalid) {
      this.workstreamForm.markAllAsTouched();
    } else if (this.workstreamForm.valid) {
      let list = this.workstreamForm.value;
      console.log(this.workstreamForm.value);
      if (this.action === 'add') {
        this.portfolioId = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID);
        this.portfolioName = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME);

        const prepareData = {
          portFolioWorkStreamEntity: this.workstreamForm.value,
          portfolioId: this.portfolioId,
          portfolioName: this.portfolioName,
          loggedInUserBankid: localStorage.getItem('userOneBankId')
        }
        this.restService.post(URL_PREFIX.PORTFOLIO + '/data/workstream/generation', prepareData).subscribe(data => {
            if (data !== null && data['workStreamId'] !== null) {
              this.workStreamData = data;
              sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID, this.workstreamID);
              sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME, this.workstreamName);
              this.dataService.sendMessageItemChange(WORK_HIERARCHY_CONST.PORTFOLIO);
              this.resSuccess = true;
              this.isWorkStreamNameExist = false;
              this.workstreamForm.reset();
              let message = '';
              if (this.portfolioId.substr(this.portfolioId.length - 1, this.portfolioId.length ) === 'I') {
                message = 'Workstream Created. Project ID creation request sent to FinSys, please look out for FinSys email for confirmation.';
              } else {
                message = 'Workstream Created.';
              }
              this.commonService.showSnackBar({
                type: 'success',
                message: message
              });
            }
          },
          error => {
            if (error.status !== null) {
              console.log(list['portfolioName'] + 'portfolioName');
            }
          }
        );
      }
    }
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustom(date);
  }

  checkWorkStreamExist(workStreamName: any): Observable<any> {
    const postData = {
      dataType: WORK_HIERARCHY_CONST.WORKSTREAM,
      dataName: workStreamName,
      streamId: sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID)
    };
    return this.restService.post(URL_PREFIX.PORTFOLIO + '/data/portfolio/dataname', postData);
  }
}
