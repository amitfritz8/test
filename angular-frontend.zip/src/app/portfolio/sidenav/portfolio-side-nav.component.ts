import { Component, OnInit, OnDestroy} from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/common/service/data.service';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { CommonService } from "src/app/common/service/common.service";

/**
 * @title Autosize sidenav
 */
@Component({
  // tslint:disable-next-line: component-selector
  selector: 'portfolio-side-nav',
  templateUrl: './portfolio-side-nav.component.html',
  styleUrls: ['./portfolio-side-nav.component.scss'],
})
export class PortfolioSideNavComponent implements OnInit, OnDestroy {

  constructor(private router: Router, private dataService: DataService, private commonService: CommonService) {}

  ngOnInit() {
    this.commonService.secNavEvent.emit({ display: true });
    if (WORK_HIERARCHY_CONST.WORKSTREAM != this.dataService.getListingView()
      && WORK_HIERARCHY_CONST.SUB_WORKSTREAM != this.dataService.getListingView()) {
      this.router.navigateByUrl('home/portfolio/createPortfolio/showPortfolio');
      this.dataService.setListingView("");
    }
  }

  ngOnDestroy(){
    this.commonService.secNavEvent.emit({ display: false });
  }
}

