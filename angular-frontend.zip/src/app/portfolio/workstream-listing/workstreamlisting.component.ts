import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { DataTableService } from 'src/app/common/service/dataTable.service';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { CommonService } from 'src/app/common/service/common.service';
import { MatPaginator } from '@angular/material/paginator';
import * as _ from 'lodash';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-workstream-listing',
  templateUrl: './workstream-listing.component.html',
  styleUrls: ['./workstream-listing.component.scss']
})
export class WorkstreamListingComponent implements OnInit, OnDestroy {

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  reportingFlag='';
  rprtDrpdown=[];
  sgTotal: number;
  nonSgTotal: number;
  notStartedTotal: number;
  inProgressTotal: number;
  completedTotal: number;
  onHoldTotal: number;
  data: any;
  // observers
  uamsFilterSubscription : Subscription;
  pageSubscription: Subscription;
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  constructor(private restService: RestService, public dialog: MatDialog, private router: Router,
    private readonly dataTableService: DataTableService, private dataService: DataService,
    private commonService: CommonService) {
    this.dataSource = new MatTableDataSource();
    this.commonService.recieveMessage({
      title: "Workstream Listing"
    });
    this.refData = {
      'categoryList': []
    }
  }

  displayedColumns: string[] = ['workStreamName', 'portfolioName', 'platformName', 'subPlatformName', 'location', 'lePCCodeBuild',
    'workStatus'];
  dataLength: any;
  displayCount: number = 0;
  platformList = [];
  workStatusList = [];
  countryDropdown: any = [];
  pcCodeDropdownList: any = [];
  refData = {
    'categoryList': []
  }
  scenario: any;

  @ViewChild(MatSort, { static: false }) sort: MatSort;
  workStreamNameFilter = new FormControl('');
  portFolioNameFilter = new FormControl('');
  platformFilter = new FormControl('');
  subPlatformNameFilter = new FormControl('');
  locationFilter = new FormControl('');
  lePCCodeBuildFilter = new FormControl('');
  workStatusFilter = new FormControl('');
  filterValues = {
    workStreamName: '',
    workStreamId: '',
    portfolioName: '',
    platformName: '',
    subPlatformName: '',
    location: '',
    lePCCodeBuild: '',
    workStatus: '',
  };
  showFilter = false;
  searchText = '';
  ngOnInit() {
    this.getDropdownListForFilter();
    this.scenario = 'Forecast';
    this.reportingFlag = 'Yes,No';
    const list = ['PF_Reporting Flag_Listing'];
    this.restService.post(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues', list).subscribe(data => {
      data['PF_Reporting Flag_Listing'].forEach(element => {
        this.rprtDrpdown.push({ key: element.value, value: element.desc });
      });
    });
    this.restService.get(URL_PREFIX.PORTFOLIO + '/data/non-generic/scenario').subscribe(data => {
      this.refData['categoryList']=data
    });
    this.uamsFilterSubscription = this.commonService.broadCastMessage.subscribe(data => {
      this.getData();
      this.getPlatformList();
      this.getCountryDropdownList();
    });
  }
  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }
  applyFilter(filterValue: string) {
    if (this.showFilter) {
      this.showFilter = false;
    }
    for (var i in this.filterValues) {
      this.filterValues[i] = filterValue.trim().toLowerCase();
    }
    this.dataSource.filter = JSON.stringify(this.filterValues);
    this.dataSource.filterPredicate = this.dataTableService.tableFilterForSearch();
    this.dataLength = this.dataSource.filteredData.length;
    this.paginator.pageIndex = 0;
    this.updateDisplayCount();
  }

  toggleFilter(e) {
    this.searchText = '';
    this.showFilter = !this.showFilter;
    if (this.filterValues) {
      for (let field in this.filterValues) {
        this.filterValues[field] = '';
      }
      this.dataSource.filter = JSON.stringify(this.filterValues);
    }
    this.workStreamNameFilter.setValue('');
    this.portFolioNameFilter.setValue('');
    this.platformFilter.setValue('');
    this.subPlatformNameFilter.setValue('');
    this.locationFilter.setValue('');
    this.lePCCodeBuildFilter.setValue('');
    this.workStatusFilter.setValue('');
  }

  getDropdownListForFilter() {

    this.platformList = [];
    this.workStatusList = [];
    const list = ['Work Status'];
    this.restService.post(URL_PREFIX.PEOPLE + '/data/dataSummary/dataValues', list).subscribe(data => {
      data['Work Status'].forEach((element: { value: any; }) => {
        this.workStatusList.push({ key: element.value, value: element.value });
      });
      this.workStatusList.unshift({ key: 'all', value: 'All' });
    });
  }

    getPlatformList(){
      this.platformList =[];
      let selecetdPlatforms = JSON.parse(sessionStorage.getItem('selectedPIwithNames'));
      selecetdPlatforms.forEach(element => {
        this.platformList.push({ key: element.platformIndex + ' - ' + element.platform, value: element.platformIndex + ' - ' + element.platform });
      });
      this.platformList.unshift({ key: 'all', value: 'All' });
    }

  getCountryDropdownList(){
    this.countryDropdown = [];
    let countryList = JSON.parse(sessionStorage.getItem('locations'));
    countryList.forEach(element => {
      this.countryDropdown.push({ key: element, value: element });
    });
    this.countryDropdown.unshift({ key: 'all', value: 'All' });
  }
  getData() {
    this.dataService.loaderHandler(true);
    const platform = JSON.parse(sessionStorage.getItem('selectedPlatforms'));
    const locations = JSON.parse(sessionStorage.getItem('locations'));
    let idAndRoles = 
    {oneBankId : localStorage.getItem('userOneBankId'),
     roles : Object.keys(JSON.parse(sessionStorage.getItem('roles'))),
    locations : locations,
    platform : platform,
    scenario : this.scenario,
    reportingFlag: this.reportingFlag ? this.reportingFlag.split(','): []}
    //this.restService.get(URL_PREFIX.PORTFOLIO + `/data/workstream/listing?scenario=${this.scenario}`).subscribe(data => {
      this.restService.post(URL_PREFIX.PORTFOLIO + `/data/workstream/listing`,idAndRoles).subscribe(data => {
      this.dataService.loaderHandler(false);
      this.dataSource.data = data;
      this.dataSource.sort = this.sort;
      this.dataSource.sortingDataAccessor = (data, header) => {
        if (this.displayedColumns.includes(header)) {
          if (typeof (data[header]) != 'number' && data[header]) {
            return data[header].toString().toLowerCase();
          } else {
            return data[header];
          }
        }
      }
      this.dataSource.sort = this.sort;
      this.dataLength = this.dataSource.data.length;
      this.dataSource.paginator = this.paginator;
      this.updateDisplayCount();
      this.pageSubscription = this.paginator.page.subscribe(v => {
        this.updateDisplayCount();
      });
      this.checkForUpdatedCounts(this.dataSource.data);
    });
    this.filterChanges();
  }

  ngOnDestroy() {
    this.pageSubscription ? this.pageSubscription.unsubscribe() : '';
    this.uamsFilterSubscription.unsubscribe();
  }

  updateDisplayCount(){
    this.displayCount = (this.paginator.pageIndex + 1) * 20 > this.dataLength ? this.dataLength : (this.paginator.pageIndex + 1) * 20;
  }

  filterChanges() {
    this.workStreamNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.workStreamName = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
    this.portFolioNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.portfolioName = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
    this.platformFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.platformName = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
    this.subPlatformNameFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.subPlatformName = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
    this.locationFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.location = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
    this.lePCCodeBuildFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.lePCCodeBuild = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
    this.workStatusFilter.valueChanges
      .subscribe(
        data => {
          this.filterValues.workStatus = data;
          this.dataSource.filter = JSON.stringify(this.filterValues);
          this.dataSource.filterPredicate = this.dataTableService.tableFilter();
          this.dataLength = this.dataSource.filteredData.length;
          this.checkForUpdatedCounts(this.dataSource.filteredData);
        }
      )
  }
  getMoreInfo(row) {
    sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID, row.portfolioId);
    sessionStorage.setItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME, row.portfolioName);
    sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID, row.workStreamId);
    sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME, row.workStreamName);
    this.dataService.sendMessageItemChange(WORK_HIERARCHY_CONST.WORKSTREAM);
    this.dataService.setListingView(WORK_HIERARCHY_CONST.WORKSTREAM);
    this.router.navigateByUrl(`home/portfolio/createPortfolio/workstream/${row.workStreamId}`);
  }
  checkForUpdatedCounts(data) {
    this.countOfCountry(data);
    this.countOfWorkStatus(data);
    this.updateDisplayCount();
  }
  // countOfEnhancement(data: any): any {
  //   throw new Error("Method not implemented.");
  // }
  // countOfInitNew(data: any): any {
  //   throw new Error("Method not implemented.");
  // }
  // countOfInflight(data: any): any {
  //   throw new Error("Method not implemented.");
  // }
  countOfCountry(data) {
    let sgList = [];
    let nonSgList = [];
    data.forEach(element => {
      if (element['location'] && (element['location'].toLowerCase().includes('sg')
        || element['location'].toLowerCase().includes('singapore'))) {
        sgList.push(element);
      }
      else if (element['location'] && !(element['location'].toLowerCase().includes('sg')
        || element['location'].toLowerCase().includes('singapore'))) {
        nonSgList.push(element);
      }
    });
    this.sgTotal = sgList.length;
    this.nonSgTotal = nonSgList.length;
  }

  countOfWorkStatus(data) {
    this.notStartedTotal = 0;
    this.inProgressTotal = 0;
    this.completedTotal = 0;
    this.onHoldTotal = 0;
    data.forEach(element => {
      if (element['workStatus'] && (element['workStatus'] === 'Not Started')) {
        this.notStartedTotal += 1;
      }
      else if (element['workStatus'] && (element['workStatus'] === 'In Progress')) {
        this.inProgressTotal += 1;
      }
      else if (element['workStatus'] && (element['workStatus'] === 'Completed') || (element['workStatus'] === 'Pending Closure')) {
        this.completedTotal += 1;
      }else if(element['workStatus'] && (element['workStatus'] === 'On-Hold') || (element['workStatus'] === 'Cancelled')){
        this.onHoldTotal += 1;
      }
    });
  }
  clear_search() {
    this.searchText = '';
    this.applyFilter(this.searchText);
  }
  scenarioSelected(event) {
    this.scenario = event.value.trim();
    this.getData();
  }

  getLepcCode(data){
    let result = [];
    if(data && data != ''){
      let temp = data.split(";");
      _.forEach(temp, (val) => {
        result.push(val.split("-")[0].trim());
      })
    }
    return result.length != 0 ? result.join(";"): '';
  }

  reportingFlagSelected(event) {
    this.reportingFlag= event.value.trim();
    this.getData();
  }
}
