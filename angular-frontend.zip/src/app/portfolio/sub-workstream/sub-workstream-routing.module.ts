import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/common/module/shared.module';
import { SubWorkstreamComponent } from '../sub-workstream/sub-workstream.component';

const routes: Routes = [
  { path: '', component: SubWorkstreamComponent },
  {
    path: 'editSubworkstream',
    loadChildren: () => import('src/app/portfolio/sub-workstream/edit-subworkstream/edit-subworkstream-routing.module').then(m => m.EditSubworkstreamRoutingModule),
  },
  {
    path: 'cost-setting',
    loadChildren: () => import('src/app/portfolio/sub-workstream/cost-setting/cost-setting-routing.module').then(m => m.CostSettingRoutingModule),
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
  ],
  declarations: [
    SubWorkstreamComponent
  ],
  exports: [],
  entryComponents: []
})

export class SubWorkStreamRoutingModule {
}