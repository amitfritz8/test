import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormArray, ValidatorFn, ValidationErrors } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import * as _ from 'lodash';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { CommonService } from 'src/app/common/service/common.service';

export class AppDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
    let monthList = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    if (displayFormat === 'input') {
      const day = date.getDate();
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      return `${day} ${monthList[month - 1]} ${year}`;
    } else {
      return date.toDateString();
    }
  }
}

export const APP_DATE_FORMATS =
{
  parse: {
    dateInput: { month: 'short', year: 'numeric', day: 'numeric' },
  },
  display: {
    dateInput: 'input',
    monthYearLabel: { year: 'numeric', month: 'numeric' },
    dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric' },
    monthYearA11yLabel: { year: 'numeric', month: 'long' },
  }
};

@Component({
  selector: 'app-financial-details',
  templateUrl: './financial-details.component.html',
  styleUrls: ['./financial-details.component.scss'],
  providers: [
    {
      provide: DateAdapter, useClass: AppDateAdapter
    },
    {
      provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
    }
  ]
})
export class FinancialDetailsComponent implements OnInit {
  isOtherResourceSelected: boolean = false;
  isOthersSelected: boolean = false;
  isNewTeamSelected: boolean = false;
  isSoftwareSelected: boolean = false;
  isHardwareSelected: boolean = false;
  isSoftwarePQSelected: boolean = false;
  isOtherSoftwareSelected: boolean = false;
  isAddOtherResourceClicked: boolean = false;
  isAddOthersClicked: boolean = false;
  editAction: boolean;
  isITCPQSelected: boolean = false;
  isOtherHardwareSelected: boolean = false;
  hideIndividauladdtion: boolean = false;
  keyDatesErrorExists: boolean = false;
  subWorkStreamId: string;
  subWorkStreamName: string;
  FDKeyDatesErrorMsg: string;
  workStreamId: string;
  incrementSoftware: any;
  goLiveDate: any;
  startDate: any;

  expandedItems = [];
  duplicateResource: object = {};
  existingResource: object = {};

  constructor(private fb: FormBuilder, private datePipe: DatePipe, private router: Router, private restService: RestService, private dataService: DataService,
    private dateUtility: DateUtility, private commonService: CommonService, private dialog: MatDialog, private http: HttpClient, private changeDetectorRef: ChangeDetectorRef) {
  }

  resourceDropdown: any = [];
  financialDetaildatesForm: FormGroup;
  roleDropdown: any = [];
  countryDropdown: any = [];
  ICcountryDropdown: any = [];
  staffTypeDropdown: any = [];
  softwareDropdown: any = [];
  hardwareDropdown: any = [];
  vendorDropdown: any = [];
  rateSourceDropdown: any = [];
  levelDropdown: any = [];
  fteDropdown: any = [];
  currencyDropdown: any = [];
  prepopulateCCCode: any = [];
  teamsDropdown: any = [];
  towerDetailsDropDown: any = [];
  driverDetailsDropDown: any = [];
  uomDetailsDropDown: any = [];
  isIndividualSelected: boolean = false;
  isTeamSelected: boolean = false;
  IndividualsData: any = [];
  otherResourceData: any = [];
  othersData: any = [];
  teamsData: any = [];
  otherSoftwaresData: any = [];
  otherHardwaresData: any = [];
  softwaresData: any = [];
  vendorNameInterim: any;
  hardwaresData: any = [];
  financialDetail: any = [];
  data: any = [];
  action: any = '';
  scenario: any;
  individualFTETotal: number = 1;
  individualCostperDayTotal: number = 1;
  individualCostperMonthTotal: number = 18;
  otherResourceCostTotal: number = 1;
  manDaysPerMonth: number = 1;
  softwareDropDown: any = [];
  currencyCodeType: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.CURRENCY_CODE_TYPE);

  ngOnInit() {
    this.action = history.state.editAction ? 'edit' : 'view';
    this.subWorkStreamId = sessionStorage.getItem('subWorkStreamId');
    this.subWorkStreamName = sessionStorage.getItem('subWorkstreamName');
    this.workStreamId = sessionStorage.getItem('workstreamID');
    this.scenario = 'Forcast';
    this.financialDetaildatesForm = this.fb.group({
      startDate: ['', [Validators.required]],
      goLiveDate: ['', [Validators.required]],
      workStreamId: this.workStreamId,
      userLoggedInCountry: localStorage.getItem('userLoggedInCountry'),
      subWorkStreamId: [this.subWorkStreamId,],
      subWorkStreamName: [this.subWorkStreamName,],
      scenario: ['Forcast',],
      resource: ['',],
      teamsdummy: ['',],
      teams: this.fb.array([]),
      individualContributors: this.fb.array([]),
      otherResource: this.fb.array([]),
      softwares: this.fb.array([]),
      otherSoftware: this.fb.array([]),
      hardwares: this.fb.array([]),
      otherHardware: this.fb.array([]),
      others: this.fb.array([]),
    });
    // Change to REf Data
    this.resourceDropdown.push({ key: 'Individual', value: 'Individual Contributor' });
    this.resourceDropdown.push({ key: 'Other Resource', value: 'Other Resource' });


    this.teamsDropdown.push({ key: 'New Team', value: 'New Team' });
    this.teamsDropdown.push({ key: 'Existing Teams', value: 'Existing Teams' });
    this.teamsDropdown.push({ key: '', value: '----------------------' });
    this.teamsDropdown.push({ key: 'MVP-2', value: 'MVP-2' });
    this.teamsDropdown.push({ key: 'MVP-1', value: 'MVP-1' });
    this.teamsDropdown.push({ key: 'Feros', value: 'Feros' });

    this.softwareDropdown.push({ key: 'Software (PxQ)', value: 'Software (PxQ)' });
    this.softwareDropdown.push({ key: 'Other Software', value: 'Other Software' });


    this.hardwareDropdown.push({ key: 'ITC (PxQ)', value: 'ITC (PxQ)' });
    this.hardwareDropdown.push({ key: 'Other Hardware', value: 'Other Hardware' });
    this.softwareDropDown.push({ key: 'Perpetual', value: 'Perpetual' });
    this.softwareDropDown.push({ key: 'Subscription ', value: 'Subscription ' });
    this.softwareDropDown.push({ key: 'Maintenance', value: 'Maintenance' });
    if (this.dataService.getScenario()) {
      this.financialDetaildatesForm.controls.scenario.setValue(this.dataService.getScenario());
      this.scenario = this.dataService.getScenario();
    }
    else {
      this.financialDetaildatesForm.controls.scenario.setValue('Forcast');
      this.scenario = 'Forcast';
    }
    //this.financialDetaildatesForm.controls.startDate.setValue(this.dataService.getStartDate());
    //this.financialDetaildatesForm.controls.goLiveDate.setValue(this.dataService.getGoLiveDate());
    this.getData();
  }

  private resourceValidator(idx): ValidatorFn {
    return (group: FormGroup): ValidationErrors => {

      let role = group.controls['role'];
      let location = group.controls['location'];
      let staffType = group.controls['staffType'];
      let vendor = group.controls['vendor'];
      let rateSource = group.controls['rateSource'];
      let level = group.controls['level'];

      if (role.value != '' && location.value != '' && staffType.value != '' && vendor.value != '' && rateSource.value != '' && level.value != ''
        && !_.isEmpty(this.duplicateResource)) {
        let str = `${role.value}-${location.value}-${staffType.value}-${vendor.value}-${rateSource.value}-${level.value}`;
        if (this.duplicateResource[idx] == str) {
          group.controls['role'].setErrors({ duplicate: true });
          return;
        } else {
          group.controls['role'].setErrors(null);
          return;
        }
      } else {
        group.controls['role'].setErrors(null);
        return;
      }
    };
  }

  individualContributors(): FormArray {
    return this.financialDetaildatesForm.get('individualContributors') as FormArray;
  }

  team(): FormArray {
    return this.financialDetaildatesForm.get('team') as FormArray;
  }

  teams(): FormArray {
    return this.financialDetaildatesForm.get('teams') as FormArray;
  }

  otherResource(): FormArray {
    return this.financialDetaildatesForm.get('otherResource') as FormArray;
  }

  others(): FormArray {
    return this.financialDetaildatesForm.get('others') as FormArray;
  }

  otherSoftware(): FormArray {
    return this.financialDetaildatesForm.get('otherSoftware') as FormArray;
  }

  otherHardware(): FormArray {
    return this.financialDetaildatesForm.get('otherHardware') as FormArray;
  }

  software(): FormArray {
    return this.financialDetaildatesForm.get('software') as FormArray;
  }

  softwares(): FormArray {
    return this.financialDetaildatesForm.get('softwares') as FormArray;
  }

  hardwares(): FormArray {
    return this.financialDetaildatesForm.get('hardwares') as FormArray;
  }

  hardware(): FormArray {
    return this.financialDetaildatesForm.get('hardware') as FormArray;
  }

  initTeams() {
    return this.fb.group({
      newTeamName: ['', [Validators.required]],
      teamsdummy: ['',],
      team: this.fb.array([
        this.initTeam()
      ]),
    });
  }

  initSoftwares() {
    return this.fb.group({
      vendorName: ['',],
      software: this.fb.array([
        this.initSoftware()
      ]),
    });
  }

  initHardwares() {
    return this.fb.group({
      hardwareName: ['',],
      hardware: this.fb.array([
        this.initHardware()
      ]),
    });
  }

  initTeam() {
    return this.fb.group({
      role: ['', [Validators.required]],
      location: ['', [Validators.required]],
      staffType: ['', [Validators.required]],
      vendor: ['', [Validators.required]],
      rateSource: ['', [Validators.required]],
      level: ['', [Validators.required]],
      fte: [1.0000, [Validators.required]],
      currency: ['', [Validators.required]],
      costPerDay: [1.0000, [Validators.required]],
      activeInd: 'true'
    });
  }

  initSoftware() {
    return this.fb.group({
      vendor: ['',],
      softwareName: ['',],
      softwareType: ['',],
      currency: ['',],
      unitPrice: [1.0000,],
      qty: [1,],
      costInCurrency: ['',],
      surrId: null,
      costPerMonth: [1.0000,],
      activeInd: 'true'
    });
  }

  initHardware() {
    return this.fb.group({
      tower: ['',],
      driverDetails: ['',],
      uom: ['',],
      currency: ['',],
      itcRate: [1.0000, [Validators.required]],
      qty: [1, [Validators.required]],
      costInCurrency: ['',],
      surrId: null,
      costPerMonth: [1.0000, [Validators.required]],
      activeInd: 'true'
    });
  }

  onSelectResource(resource) {

    if (this.expandedItems.indexOf('individualContributors') < 0) {
      this.expandedItems.push('individualContributors');
    }

    if (resource === 'Team') {
      this.isTeamSelected = true;
      this.isNewTeamSelected = false;
      this.addTeams();
    }
    else if (resource === 'Individual Contributor') {
      // this.isIndividualSelected = true;
      if (!this.isIndividualSelected) {
        this.addIndividualContributor();
      }
      this.isIndividualSelected = true;
    }
    else if (resource === 'Other Resource') {
      if (!this.isOtherResourceSelected) {
        this.addOtherResource();
      }
      this.isOtherResourceSelected = true;
    }
    else {
      this.isIndividualSelected = false;
      this.isOtherResourceSelected = false;
    }
    window.scrollTo(0, document.body.scrollHeight);
  }

  onSelectTeam(team) {
    if (team.value === 'New Team') {
      this.isNewTeamSelected = true;
    }
  }

  onAddSoftwareClick(resource) {
    if (this.expandedItems.indexOf('software') < 0) {
      this.expandedItems.push('software');
    }
    if (resource.value === 'Software (PxQ)') {
      this.isSoftwarePQSelected = true;
      this.addSoftwaresPQ();
    }
    else if (resource.value === 'Other Software') {

      if (!this.isOtherSoftwareSelected) {
        this.addMiscSoftware();
      }
      this.isOtherSoftwareSelected = true;

    }
    else {
      this.isHardwareSelected = false;
      this.isSoftwareSelected = false;
    }
    window.scrollTo(0, document.body.scrollHeight);
  }

  onAddHardwareClick(resource) {
    if (this.expandedItems.indexOf('hardware') < 0) {
      this.expandedItems.push('hardware');
    }
    if (resource.value === 'ITC (PxQ)') {
      this.isITCPQSelected = true;
      this.addHardwaresPQ();
    }
    else if (resource.value === 'Other Hardware') {
      if (!this.isOtherHardwareSelected) {
        this.addMiscHardware();
      }
      this.isOtherHardwareSelected = true;

    }
    else {
      this.isHardwareSelected = false;
      this.isSoftwareSelected = false;
    }
    window.scrollTo(0, document.body.scrollHeight);
  }

  getData() {
    this.loadDropDowns()
    this.restService.get(URL_PREFIX.PORTFOLIO + '/financial/cost-settings/financialDetails?subWorkstreamId=' + this.subWorkStreamId + '&subWorkstreamName=' + this.subWorkStreamName + '&workStreamId=' + this.workStreamId + '&scenario=' + this.scenario + '&currencyCodeType=' + this.currencyCodeType).subscribe(data => {
      if (Object.keys(data).length) {
        if (data.financialDetaildatesFormEntity !== null) {
          this.financialDetail = data;
          if (data.financialDetaildatesFormEntity.startDate) {
            this.financialDetaildatesForm.controls.startDate.setValue(data.financialDetaildatesFormEntity.startDate);
          }
          if (data.financialDetaildatesFormEntity.goLiveDate) {
            this.financialDetaildatesForm.controls.goLiveDate.setValue(data.financialDetaildatesFormEntity.goLiveDate);
          }

          if (Object.keys(data.financialDetaildatesFormEntity.softwares.valueOf('software')).length) {
            this.softwaresData = data.financialDetaildatesFormEntity.softwares;
            this.setSoftwares();
          }
          if (Object.keys(data.financialDetaildatesFormEntity.otherSoftware).length) {
            this.otherSoftwaresData = data.financialDetaildatesFormEntity.otherSoftware;
            this.setOtherSoftware();
          }
          if (Object.keys(data.financialDetaildatesFormEntity.hardwares.valueOf('hardware')).length) {
            this.hardwaresData = data.financialDetaildatesFormEntity.hardwares;
            this.setHardwares();
          }
          if (Object.keys(data.financialDetaildatesFormEntity.otherHardware).length) {
            this.otherHardwaresData = data.financialDetaildatesFormEntity.otherHardware;
            this.setOtherHardware();
          }
          if (Object.keys(data.financialDetaildatesFormEntity.others).length) {
            this.othersData = data.financialDetaildatesFormEntity.others;
            this.setOthers();
          }

          if (Object.keys(data.financialDetaildatesFormEntity.individualContributors).length) {
            this.IndividualsData = data.financialDetaildatesFormEntity.individualContributors;
            this.setIndividualContributor();
          }
          if (Object.keys(data.financialDetaildatesFormEntity.otherResource).length) {
            this.otherResourceData = data.financialDetaildatesFormEntity.otherResource;
            this.setOtherResource();
          }
        }
      }
    }
      ,
      error => {
        if (error.status !== null) {
        }
      }
    );
    if (this.financialDetail.financialDetaildatesFormEntity) {
      console.log(this.financialDetail.financialDetaildatesFormEntity + "this.financialDetail.financialDetaildatesFormEntity");
      this.teamsData = this.financialDetail.financialDetaildatesFormEntity.teams;
      this.IndividualsData = this.financialDetail.financialDetaildatesFormEntity.individualContributors;
      this.otherResourceData = this.financialDetail.financialDetaildatesFormEntity.otherResource;
      this.setTeams();
      // this.setIndividualContributor();
      // this.setOtherResource();
    }
    this.getFDKeydatesError();
  }

  setOtherSoftware() {
    let control = this.financialDetaildatesForm.controls.otherSoftware as FormArray;
    if (this.otherSoftwaresData) {
      this.isOtherSoftwareSelected = true;
      this.otherSoftwaresData.forEach(x => {
        control.push(this.fb.group({
          vendor: x.vendor,
          capexOrOpex: x.capexOrOpex.toLowerCase(),
          currency: x.currency,
          cost: x.cost,
          description: x.description,
          surrId: x.surrId,
          activeInd: x.activeInd
        }))
      });
    }
  }

  setOtherHardware() {
    let control = this.financialDetaildatesForm.controls.otherHardware as FormArray;
    if (this.otherHardwaresData) {
      this.isOtherHardwareSelected = true;
      this.otherHardwaresData.forEach(x => {
        control.push(this.fb.group({
          vendor: x.vendor,
          capexOrOpex: x.capexOrOpex.toLowerCase(),
          currency: x.currency,
          cost: x.cost,
          description: x.description,
          surrId: x.surrId,
          activeInd: x.activeInd
        }))
      });
    }
  }

  setOthers() {
    let control = this.financialDetaildatesForm.controls.others as FormArray;
    if (this.othersData) {
      this.othersData.forEach(x => {
        control.push(this.fb.group({
          vendor: x.vendor,
          capexOrOpex: x.capexOrOpex.toLowerCase(),
          currency: x.currency,
          cost: [x.cost, [Validators.required]],
          description: [x.description],
          surrId: x.surrId,
          activeInd: x.activeInd
        }))
      });
    }
  }

  setIndividualContributor() {
    let control = this.financialDetaildatesForm.controls.individualContributors as FormArray;
    this.duplicateResource = {};
    if (this.IndividualsData) {
      this.isIndividualSelected = true;
      this.IndividualsData.forEach((x, i) => {

        let str = `${x.role}-${x.location}-${x.staffType}-${x.vendor}-${x.rateSource}-${x.level}`;
        (Object.values(this.existingResource).indexOf(str) < 0) ? this.existingResource[i] = str : this.duplicateResource[i] = str;

        control.push(this.fb.group({
          role: x.role,
          location: x.location,
          staffType: x.staffType,
          vendor: x.vendor,
          rateSource: x.rateSource,
          level: x.level,
          fte: [x.fte, [Validators.required]],
          currency: x.currency,
          costPerDay: [x.costPerDay, [Validators.required]],
          surrId: x.surrId,
          fdManDaysPerMonth: x.fdManDaysPerMonth,
          activeInd: x.activeInd,
          staffTypeDropdown: [[]],
          vendorDropdown: [[]],
          rateSourceDropdown: [[]],
          levelDropdown: [[]]
        }, { validator: this.resourceValidator(i) }));
      });
      let icRows = this.individualContributors().controls;
      icRows.forEach((row, index) => {
        let icControls = row['controls'];
        icControls.staffTypeDropdown.value.push(this.getStaffType(icControls.location.value, index, icControls.value));
        icControls.vendorDropdown.value.push(this.getVendor(icControls.staffType.value, index, icControls.value));
        icControls.rateSourceDropdown.value.push(this.getRateSource(icControls.vendor.value, index, icControls.value));
        icControls.levelDropdown.value.push(this.getLevel(icControls.rateSource.value, index, icControls.value));
      });
    }
  }

  setOtherResource() {
    let control = this.financialDetaildatesForm.controls.otherResource as FormArray;
    if (this.otherResourceData) {
      this.isOtherResourceSelected = true;
      this.otherResourceData.forEach(x => {
        control.push(this.fb.group({
          vendor: x.vendor,
          capexOrOpex: x.capexOrOpex.toLowerCase(),
          currency: x.currency,
          cost: [x.cost, [Validators.required]],
          description: [x.description],
          surrId: x.surrId,
          activeInd: x.activeInd
        }))
      });
    }
  }

  setTeams() {
    let control = this.financialDetaildatesForm.controls.teams as FormArray;
    _.forIn(this.teamsData, (x: any, k: any) => {
      this.isNewTeamSelected = true;
      this.isTeamSelected = true;
      if (x != null && x !== '') {
        console.log(x.team + 'this.teamInfox.team');
        console.log(x['team'] + 'this.teamInfox[\'team\']');
        control.push(this.fb.group({
          newTeamName: x.newTeamName,
          teamsdummy: x.teamsdummy,
          team: this.fb.array([])
        }));
        let teamCtrl = control.at(k).get('team') as FormArray;
        _.forIn(x.team, (v: any, k: any) => {
          //this.teamInfoy = v;
          teamCtrl.push(this.fb.group({
            role: this.fb.control(v.role),
            location: this.fb.control(v.location),
            staffType: this.fb.control(v.staffType),
            vendor: this.fb.control(v.vendor),
            rateSource: this.fb.control(v.rateSource),
            level: this.fb.control(v.level),
            fte: this.fb.control(v.fte),
            surrId: this.fb.control(v.surrId),
            currency: this.fb.control(v.currency),
            costPerDay: this.fb.control(v.costPerDay),
            activeInd: this.fb.control(v.activeInd)
          }));
        });
      }
    });
  }

  setSoftwares() {
    let control = this.financialDetaildatesForm.controls.softwares as FormArray;
    _.forIn(this.softwaresData, (x: any, k: any) => {
      console.log(x.vendorName + 'x.vendorName');
      this.isSoftwarePQSelected = true;
      if (x != null && x !== '') {
        control.push(this.fb.group({
          vendorName: x.vendorName,
          software: this.fb.array([])
        }));

        let teamCtrl = control.at(k).get('software') as FormArray;
        _.forIn(x.software, (v: any, k: any) => {
          teamCtrl.push(this.fb.group({
            vendor: this.fb.control(v.vendor),
            softwareName: this.fb.control(v.softwareName),
            softwareType: this.fb.control(v.softwareType),
            currency: this.fb.control(v.currency),
            unitPrice: this.fb.control(v.unitPrice),
            qty: this.fb.control(v.qty),
            costInCurrency: this.fb.control(v.costInCurrency),
            costPerMonth: this.fb.control(v.costPerMonth),
            surrId: this.fb.control(v.surrId),
            activeInd: this.fb.control(v.activeInd)
          }));
        });
      }
    });
  }

  setHardwares() {
    let control = this.financialDetaildatesForm.controls.hardwares as FormArray;
    _.forIn(this.hardwaresData, (x: any, k: any) => {
      this.isITCPQSelected = true;
      if (x != null && x !== '') {
        control.push(this.fb.group({
          hardware: this.fb.array([])
        }));
        let teamCtrl = control.at(k).get('hardware') as FormArray;
        _.forIn(x.hardware, (v: any, k: any) => {
          teamCtrl.push(this.fb.group({
            tower: this.fb.control(v.tower),
            driverDetails: this.fb.control(v.driverDetails),
            uom: this.fb.control(v.uom),
            currency: this.fb.control(v.currency),
            itcRate: this.fb.control(v.itcRate),
            qty: this.fb.control(v.qty),
            costInCurrency: this.fb.control(v.costInCurrency),
            costPerMonth: this.fb.control(v.costPerMonth),
            surrId: this.fb.control(v.surrId),
            activeInd: this.fb.control(v.activeInd)
          }));
        });
      }
    });
  }

  addIndividualContributor() {
    if (this.financialDetaildatesForm.controls.individualContributors.valid) {
      let control = this.financialDetaildatesForm.controls.individualContributors as FormArray;
      this.IndividualsData = control.value;
      control.push(
        this.fb.group({
          role: [''],
          location: [''],
          staffType: [''],
          vendor: [''],
          rateSource: [''],
          level: [''],
          fte: [0],
          currency: [''],
          costPerDay: [''],
          staffTypeDropdown: [[]],
          vendorDropdown: [[]],
          rateSourceDropdown: [[]],
          levelDropdown: [[]],
          surrId: null,
          fdManDaysPerMonth: this.manDaysPerMonth,
          activeInd: 'true'
        }, { validator: this.resourceValidator(control.length) })
      )
      this.IndividualsData = control.value;
    } else {
      let controls = this.individualContributors().controls;
      controls.forEach((element, index) => {
        for (const name in element['controls']) {
          if (element['controls'][name].invalid) {
            this.individualContributors().controls[index]['controls'][name].markAsTouched();
          }
        }
      });
    }
  }

  deleteTeamMember(index) {
    this.team().value[index].activeInd = false;
    let individualList = this.team().controls[index] as FormArray;
    const control = individualList.controls as any;
    control.activeInd.value = false;
    this.team().removeAt(index)
  }

  addTeamMember() {
    if (this.financialDetaildatesForm.controls.team.valid) {
      let control = this.financialDetaildatesForm.controls.team as FormArray;
      this.teamsData = control.value;
      control.push(
        this.fb.group({
          role: ['', [Validators.required]],
          location: ['', [Validators.required]],
          staffType: ['', [Validators.required]],
          vendor: ['', [Validators.required]],
          rateSource: ['', [Validators.required]],
          level: ['', [Validators.required]],
          fte: [1, [Validators.required]],
          currency: [, [Validators.required]],
          costPerDay: [1, [Validators.required]],
          activeInd: 'true'
        })
      )
      this.teamsData = control.value;
    } else {
      let controls = this.team().controls;
      controls.forEach((element, index) => {
        for (const name in element['controls']) {
          if (element['controls'][name].invalid) {
            this.team().controls[index]['controls'][name].markAsTouched();
          }
        }
      });
    }
  }

  addPQSoftware() {
    if (this.financialDetaildatesForm.controls.softwares.valid) {
      let control = this.financialDetaildatesForm.controls.softwares as FormArray;
      control.push(this.initSoftware());
    } else {
      let controls = this.softwares().controls;
      controls.forEach((element, index) => {
        for (const name in element['controls']) {
          if (element['controls'][name].invalid) {
            this.softwares().controls[index]['controls'][name].markAsTouched();
          }
        }
      });
    }
  }

  addPQHardware() {

    if (this.financialDetaildatesForm.controls.hardwares.valid) {
      let control = this.financialDetaildatesForm.controls.hardwares as FormArray;
      control.push(this.initHardware());

    } else {
      let controls = this.hardwares().controls;
      controls.forEach((element, index) => {
        for (const name in element['controls']) {
          if (element['controls'][name].invalid) {
            this.hardwares().controls[index]['controls'][name].markAsTouched();
          }
        }
      });
    }
  }
  savefinancialDetail() {
    const controls = this.financialDetaildatesForm.controls;
    if (!controls.startDate.value && !controls.goLiveDate.value) {
      this.keyDatesErrorExists = true;
    }
    else {
      this.keyDatesErrorExists = false;
    }
    for (const name in controls) {
      if (controls[name].invalid) {
        this.financialDetaildatesForm.controls[name].markAsTouched();
      }
    }
    if (this.financialDetaildatesForm.invalid) {
      this.financialDetaildatesForm.markAllAsTouched();
    } else if (this.financialDetaildatesForm.valid) {
      const controls = this.financialDetaildatesForm.controls;

      if (!this.keyDatesErrorExists) {


        for (const name in controls) {
          if (controls[name].invalid) {
            this.financialDetaildatesForm.controls[name].markAsTouched();
          }
        }
        const prepareData = {
          financialDetaildatesFormEntity: this.financialDetaildatesForm.value,

        }
        this.restService.post(URL_PREFIX.PORTFOLIO + '/financial/cost-settings/financialDetails', prepareData).subscribe(data => {
          this.commonService.showSnackBar({
            type: 'success',
            message: "Financial Details updated successfully"
          })
          this.dataService.setActiveTab('4');
          this.router.navigateByUrl('/home/portfolio/createPortfolio/subworkstream/' + sessionStorage.getItem('subWorkStreamId'));
        },
          error => {
            if (error.status !== null) {
              this.commonService.showSnackBar({ type: 'alert', message: "Financial Details update failed", duration: 3000 });
              // this.dataService.setActiveTab('4');
              // this.router.navigateByUrl('/home/portfolio/createPortfolio/subworkstream/' + sessionStorage.getItem('subWorkStreamId'));
            }
          }
        );
      }
    }
  }




  addMiscSoftware() {
    if (this.financialDetaildatesForm.controls.otherSoftware.valid) {
      let control = this.financialDetaildatesForm.controls.otherSoftware as FormArray;
      control.push(
        this.fb.group({
          vendor: '',
          capexOrOpex: ['capex',],
          currency: '',
          cost: [1,],
          description: '',
          surrId: null,
          activeInd: 'true'
        })
      )
    } else {
      let controls = this.otherSoftware().controls;
      controls.forEach((element, index) => {
        for (const name in element['controls']) {
          if (element['controls'][name].invalid) {
            this.otherSoftware().controls[index]['controls'][name].markAsTouched();
          }
        }
      });
    }
  }
  //Other Software Changes
  deleteOtherResource(index) {
    this.otherResource().value[index].activeInd = false;
    let otherResourceLst = this.otherResource().controls[index] as FormArray;
    const control = otherResourceLst.controls as any;
    control.activeInd.value = false;
  }
  deleteIndividualContributor(index, data) {
    this.individualContributors().value[index].activeInd = false;
    let individualList = this.individualContributors().controls[index] as FormArray;
    const control = individualList.controls as any;
    control.activeInd.value = false;
    control.role.setErrors(null);
    if (data.role != '' && data.location != '' && data.staffType != '' && data.vendor != '' && data.rateSource != '' && data.level != '') {
      let str = `${data.role}-${data.location}-${data.staffType}-${data.vendor}-${data.rateSource}-${data.level}`;
      if (Object.values(this.duplicateResource).indexOf(str) >= 0) {
        delete this.duplicateResource[_.findKey(this.duplicateResource, function (o) {
          return o == str
        })];
      }else{
        delete this.existingResource[_.findKey(this.existingResource, function (o) {
          return o == str
        })];
      }
    }
  }
  deleteOthers(index) {
    this.others().value[index].activeInd = false;
    let othersList = this.others().controls[index] as FormArray;
    const control = othersList.controls as any;
    control.activeInd.value = false;
  }
  deleteMiscSoftwaare(index) {
    this.otherSoftware().value[index].activeInd = false;
    let otherSWList = this.otherSoftware().controls[index] as FormArray;
    const control = otherSWList.controls as any;
    control.activeInd.value = false;
  }

  addMiscHardware() {
    if (this.financialDetaildatesForm.controls.otherHardware.valid) {
      let control = this.financialDetaildatesForm.controls.otherHardware as FormArray;
      control.push(
        this.fb.group({
          vendor: '',
          capexOrOpex: ['capex',],
          currency: '',
          cost: [1,],
          surrId: null,
          description: '',
          activeInd: 'true'
        })
      )
    } else {
      let controls = this.otherHardware().controls;
      controls.forEach((element, index) => {
        for (const name in element['controls']) {
          if (element['controls'][name].invalid) {
            this.otherHardware().controls[index]['controls'][name].markAsTouched();
          }
        }
      });
    }
  }
  deleteMiscHardware(index) {
    this.otherHardware().value[index].activeInd = false;
    let individualList = this.otherHardware().controls[index] as FormArray;
    const control = individualList.controls as any;
    control.activeInd.value = false;
  }

  addOtherResource() {
    if (this.financialDetaildatesForm.controls.otherResource.valid) {
      let control = this.financialDetaildatesForm.controls.otherResource as FormArray;
      this.otherResourceData = control.value;
      control.push(
        this.fb.group({
          vendor: '',
          capexOrOpex: ['capex',],
          currency: '',
          cost: [1],
          description: '',
          surrId: null,
          activeInd: 'true'
        })
      )
      this.otherResourceData = control.value;
    } else {
      let controls = this.otherResource().controls;
      controls.forEach((element, index) => {
        for (const name in element['controls']) {
          if (element['controls'][name].invalid) {
            this.otherResource().controls[index]['controls'][name].markAsTouched();
          }
        }
      });
    }
  }

  addOthers() {
    if (this.financialDetaildatesForm.controls.others.valid) {
      let control = this.financialDetaildatesForm.controls.others as FormArray;
      this.othersData = control.value;
      control.push(
        this.fb.group({
          vendor: [''],
          capexOrOpex: ['capex',],
          currency: '',
          cost: [1,],
          description: '',
          surrId: null,
          activeInd: 'true'
        })
      )
      this.othersData = control.value;
    } else {
      let controls = this.others().controls;
      controls.forEach((element, index) => {
        for (const name in element['controls']) {
          if (element['controls'][name].invalid) {
            this.others().controls[index]['controls'][name].markAsTouched();
          }
        }
      });
    }
  }


  getTeams(form) {
    return form.controls.teams.controls;
  }

  getTeam(form) {
    return form.controls.team.controls;
  }

  getSoftwares(form) {
    return form.controls.softwares.controls;
  }

  getSoftware(form) {
    return form.controls.software.controls;
  }

  getHardwares(form) {
    return form.controls.hardwares.controls;
  }

  getHardware(form) {
    return form.controls.hardware.controls;
  }

  addSoftwaresPQ() {
    const control = <FormArray>this.financialDetaildatesForm.get('softwares');
    control.push(this.initSoftwares());
  }
  addInitOtherSW() {
    const control = <FormArray>this.financialDetaildatesForm.get('softwares');
    control.push(this.initSoftwares());
  }
  addHardwaresPQ() {
    const control = <FormArray>this.financialDetaildatesForm.get('hardwares');
    control.push(this.initHardwares());
  }

  addSoftwareRow(i, j) {

    // const control = this.financialDetaildatesForm.get(`hardwares.${i}.hardware`) as FormArray;
    // control.push(this.initHardware());

    //if (this.financialDetaildatesForm.get(`softwares.${i}.software`).valid) {
    const control = this.financialDetaildatesForm.get(`softwares.${i}.software`) as FormArray;
    control.push(this.initSoftware());
    // }
    // else {
    //   let controls = this.financialDetaildatesForm.get(`softwares.${i}.software`)['controls'];
    //   controls.forEach((element, index) => {
    //     for (const name in element['controls']) {
    //       if (element['controls'][name].invalid) {
    //         this.financialDetaildatesForm.get(`softwares.${i}.software`)['controls'][index]['controls'][name].markAsTouched();
    //       }
    //     }
    //   });
    // }
  }
  addTeams() {
    const control = <FormArray>this.financialDetaildatesForm.get('teams');
    control.push(this.initTeams());
  }

  addTeamRow(i, j) {
    const control = this.financialDetaildatesForm.get(`teams.${i}.team`) as FormArray;
    control.push(this.initTeam());
  }

  deleteTeam(i, j) {
    const control = this.financialDetaildatesForm.get(`teams.${i}.team`) as FormArray;
    control.removeAt(j);
  }

  addHardwareRow(i, j) {
    const control = this.financialDetaildatesForm.get(`hardwares.${i}.hardware`) as FormArray;
    control.push(this.initHardware());
  }

  deleteSoftware(i, j) {
    const control = this.financialDetaildatesForm.get(`softwares.${i}.software`) as FormArray;
    const ctrl = control.controls[j] as FormGroup;
    const val = ctrl.controls.activeInd as any;
    val.value = false;
    control.value[j].activeInd = false;
  }

  deleteHardware(i, j) {
    const control = this.financialDetaildatesForm.get(`hardwares.${i}.hardware`) as FormArray;
    const ctrl = control.controls[j] as FormGroup;
    const val = ctrl.controls.activeInd as any;
    val.value = false;
    control.value[j].activeInd = false;
  }
  resetOthers() {
    const controls = this.others().controls;
    controls.forEach((element, index) => {
      const ctrl = element as FormGroup;
      const val = ctrl.controls.activeInd as any;
      val.value = false;
      ctrl.value.activeInd = false;
    });
  }
  resetOtherHardware() {
    const controls = this.otherHardware().controls;
    controls.forEach((element, index) => {
      const ctrl = element as FormGroup;
      const val = ctrl.controls.activeInd as any;
      val.value = false;
      ctrl.value.activeInd = false;
    });
  }
  resetOtherSoftware() {
    const controls = this.otherSoftware().controls;
    controls.forEach((element, index) => {
      const ctrl = element as FormGroup;
      const val = ctrl.controls.activeInd as any;
      val.value = false;
      ctrl.value.activeInd = false;
    });
  }
  resetIndividual() {
    const controls = this.individualContributors().controls;
    this.duplicateResource = {};
    controls.forEach((element, index) => {
      const ctrl = element as FormGroup;
      const val = ctrl.controls.activeInd as any;
      ctrl['role'].setErrors(null);
      val.value = false;
      ctrl.value.activeInd = false;
    });
  }

  resetOtherResource() {
    const controls = this.otherResource().controls;
    controls.forEach((element, index) => {
      const ctrl = element as FormGroup;
      const val = ctrl.controls.activeInd as any;
      val.value = false;
      ctrl.value.activeInd = false;
    });
  }
  resetSoftwares(i) {
    const control1 = <FormArray>this.financialDetaildatesForm.get('softwares');
    const control = this.financialDetaildatesForm.get(`softwares.${i}.software`) as FormArray;
    control.controls.forEach(element => {
      const ctrl = element as FormGroup;
      const val = ctrl.controls.activeInd as any;
      val.value = false;
      element.value.activeInd = false;
    });
  }

  resetTeams(i) {
    const control = <FormArray>this.financialDetaildatesForm.get('teams');
    control.removeAt(i);
  }

  resetHardwares(i) {
    const control1 = <FormArray>this.financialDetaildatesForm.get('hardwares');
    const control = this.financialDetaildatesForm.get(`hardwares.${i}.hardware`) as FormArray;
    control.controls.forEach(element => {
      const ctrl = element as FormGroup;
      const val = ctrl.controls.activeInd as any;
      val.value = false;
      element.value.activeInd = false;
    });
  }

  //HardWare
  addOthersClicked() {

    if (!this.isOthersSelected) {
      this.addOthers();
    }
    this.isAddOthersClicked = true;
    this.isOthersSelected = true;

    window.scrollTo(0, document.body.scrollHeight);

  }

  loadDropDowns() {
    this.restService.get(URL_PREFIX.PEOPLE + '/team/teammanagement/teamdropdown/role').subscribe(data => {
      if (data) {
        data.forEach(element => {
          this.roleDropdown.push({ value: element, display: element });
        });
      }
    });

    this.restService.get(URL_PREFIX.PEOPLE + '/team/teammanagement/teamdropdown/workLocation').subscribe(data => {
      if (data) {
        data.forEach(element => {
          this.ICcountryDropdown.push({ value: element, display: element });
        });
      }
    });

    this.restService.get(URL_PREFIX.PEOPLE + '/data/dataValues/sys-config?msgKey=Mandays per Month').subscribe(result => {
      this.manDaysPerMonth = parseInt(result['message']);
    });

    this.restService.get(URL_PREFIX.PORTFOLIO + '/financial/cost-settings/financialDetailsTemplate?currencyCodeType=' + this.currencyCodeType).subscribe(data => {
      if (data != null && data !== '') {
        data.countryCodes.forEach(element => {
          this.countryDropdown.push({ value: element, display: element });
        });
        data.currencyCodes.forEach(element => {
          this.currencyDropdown.push({ value: element, display: element });
        });
        data.towerDetails.forEach(element => {
          this.towerDetailsDropDown.push({ value: element, display: element });
        });
        data.driverDetails.forEach(element => {
          this.driverDetailsDropDown.push({ value: element, display: element });
        });
        data.uomDetails.forEach(element => {
          this.uomDetailsDropDown.push({ value: element, display: element });
        });
      }
    });
  }

  checkDuplicateResource(data, idx){

    if(data && data.role != '' && data.location != '' && data.staffType != '' && data.vendor != '' && data.rateSource != '' && data.level != ''){
      let str = `${data.role}-${data.location}-${data.staffType}-${data.vendor}-${data.rateSource}-${data.level}`;
      if(Object.values(this.existingResource).indexOf(str) < 0){
        this.existingResource[idx] = str;
        this.duplicateResource[idx] ? delete this.duplicateResource[idx]: '';
      }else{
        this.duplicateResource[idx] = str;
        this.existingResource[idx] ? delete this.existingResource[idx]: '';
      }
    }

    this.individualContributors().at(idx).updateValueAndValidity();
  }

  getStaffType(workLocation, index, fc) {
    this.checkDuplicateResource(fc, index);
    this.restService.get(URL_PREFIX.PEOPLE + '/team/teammanagement/teamdropdown/staffType?workLocation=' + workLocation).subscribe(data => {
      if (data) {
        this.individualContributors().controls[index]['controls']['staffTypeDropdown'].value = [];
        data.forEach(element => {
          this.individualContributors().controls[index]['controls']['staffTypeDropdown'].value.push({ value: element, display: element });
        });
      }
    });
  }

  getVendor(staffType, index, fc) {
    let icControls = this.individualContributors().controls[index]['controls'] as FormArray;
    let workLocation = icControls['location'].value;
    this.checkDuplicateResource(fc, index);
    this.restService.get(URL_PREFIX.PEOPLE + `/team/teammanagement/teamdropdown/vendor?workLocation=${workLocation}&staffType=${staffType}`).subscribe(data => {
      icControls['vendorDropdown'].value = [];
      if (data) {
        data.forEach(element => {
          icControls['vendorDropdown'].value.push({ value: element, display: element });
        });
      }
    });
  }

  getRateSource(vendor, index, fc) {
    let icControls = this.individualContributors().controls[index]['controls'] as FormArray;
    let workLocation = icControls['location'].value;
    let staffType = icControls['staffType'].value;
    this.checkDuplicateResource(fc, index);
    this.restService.get(URL_PREFIX.PEOPLE + `/team/teammanagement/teamdropdown/rateSource?workLocation=${workLocation}&staffType=${staffType}&vendor=${vendor}`).subscribe(data => {
      if (data) {
        
        icControls['rateSourceDropdown'].value = [];
        data.forEach(element => {
          icControls['rateSourceDropdown'].value.push({ value: element, display: element });
        });
      }
    });
  }

  getLevel(rateSource, index, fc) {
    let icControls = this.individualContributors().controls[index]['controls'] as FormArray;
    let workLocation = icControls['location'].value;
    let staffType = icControls['staffType'].value;
    let vendor = icControls['vendor'].value;
    this.checkDuplicateResource(fc, index);
    this.restService.get(URL_PREFIX.PEOPLE + `/team/teammanagement/teamdropdown/level?workLocation=${workLocation}&staffType=${staffType}&vendor=${vendor}&rateSource=${rateSource}`).subscribe(data => {
      icControls['levelDropdown'].value = [];
      if (data) {
        data.forEach(element => {
          icControls['levelDropdown'].value.push({ value: element, display: element });
        });
      }
    });
  }

  onRoleSelect(index, fc){
    this.checkDuplicateResource(fc,index);
  }

  getCurrency(level, index, fc) {
    let icControls = this.individualContributors().controls[index]['controls'] as FormArray;
    let workLocation = icControls['location'].value;
    let staffType = icControls['staffType'].value;
    let vendor = icControls['vendor'].value;
    let rateSource = icControls['rateSource'].value;
    this.checkDuplicateResource(fc, index);
    this.restService.get(URL_PREFIX.PEOPLE + `/team/teammanagement/teamdropdown/currency?workLocation=${workLocation}&staffType=${staffType}&vendor=${vendor}&rateSource=${rateSource}&level=${level}`, { responseType: 'text' })
      .subscribe(data => {
        if (data) {
          icControls['currency'].patchValue(data);
        }
      });
  }

  getFDKeydatesError() {
    this.restService.get(URL_PREFIX.PEOPLE + '/data/dataValues/sys-msg?msgKey=ERR_KEYDATESBLANK_COSTSETTINGFD').subscribe(data => {
      this.FDKeyDatesErrorMsg = data.message;

    });
  }
  calcCostPerMonth(i, j) {
    const control = this.financialDetaildatesForm.get(`softwares.${i}.software`) as FormArray;
    const ctrl = control.controls[j] as FormGroup;
    const unitPrice = ctrl.controls.unitPrice as any;
    const qty = ctrl.controls.qty as any;
    const costPerMonth = ctrl.controls.costPerMonth as any;
    costPerMonth.value = unitPrice.value * qty.value;
    control.value[j].costPerMonth = costPerMonth.value;
    ((this.financialDetaildatesForm.get(`softwares.${i}.software`) as FormArray).at(j) as FormGroup)
      .get('costPerMonth').patchValue(control.value[j].costPerMonth);
    ((this.financialDetaildatesForm.get(`softwares.${i}.software`) as FormArray).at(j) as FormGroup)
      .get('costInCurrency').patchValue(control.value[j].currency);
  }

  calcCostPerMonthForHardware(i, j) {
    const control = this.financialDetaildatesForm.get(`hardwares.${i}.hardware`) as FormArray;
    const ctrl = control.controls[j] as FormGroup;
    const itcRate = ctrl.controls.itcRate as any;
    const qty = ctrl.controls.qty as any;
    const costPerMonth = ctrl.controls.costPerMonth as any;
    costPerMonth.value = itcRate.value * qty.value;
    control.value[j].costPerMonth = costPerMonth.value;
    ((this.financialDetaildatesForm.get(`hardwares.${i}.hardware`) as FormArray).at(j) as FormGroup)
      .get('costPerMonth').patchValue(control.value[j].costPerMonth);
    ((this.financialDetaildatesForm.get(`hardwares.${i}.hardware`) as FormArray).at(j) as FormGroup)
      .get('costInCurrency').patchValue(control.value[j].currency);
  }
  calcCostforIC(index) {

    let individualList = this.individualContributors().controls[index] as FormArray;
    const control = individualList.controls as any;

    var staffRate: number = 0;
    const prepareData = {
      countryCode: control.location.value,
      currencyCode: control.currency.value,
      staffType: control.staffType.value,
      vendorCode: control.vendor.value,
      rateResource: control.rateSource.value,
      rateLevel: control.level.value
    }
    this.restService.post(URL_PREFIX.PORTFOLIO + '/financial/cost-settings/staffRate', prepareData).subscribe(data => {
      console.log(data + "staffRate")
      staffRate = data - 0;

      control.costPerDay.value = control.fte.value * staffRate;
      control.costPerDay.patchValue(control.fte.value * staffRate);
      control.fte.patchValue(control.fte.value);
      this.ICTotalCost();
    },
      error => {
        if (error.status !== null) {
          console.log(error.status);
        }
      }
    );


  }
  ICTotalCost() {
    let lst = this.financialDetaildatesForm.controls.individualContributors as FormArray;
    var FTETotal: number = 0;
    var CostperDayTotal: number = 0;
    var CostperMonthTotal: number = 0;
    this.individualFTETotal = 0;
    this.individualCostperDayTotal = 0;
    this.individualCostperMonthTotal = 0;
    lst.controls.forEach(element => {
      let array = element as FormArray;
      const control = array.controls as any;
      if (control.activeInd.value == true) {
        FTETotal = (FTETotal - 0) + (control.fte.value - 0);
        CostperDayTotal = (CostperDayTotal - 0) + (control.costPerDay.value - 0);
      }
    });
    CostperMonthTotal = CostperDayTotal * 18;
    this.individualFTETotal = FTETotal;
    this.individualCostperDayTotal = CostperDayTotal;
    this.individualCostperMonthTotal = CostperMonthTotal;
  }
  OtherResourceTotalCost() {
    let lst = this.financialDetaildatesForm.controls.otherResource as FormArray;
    var costTotal: number = 0;
    this.otherResourceCostTotal = 0;
    lst.controls.forEach(element => {
      let array = element as FormArray;
      const control = array.controls as any;
      costTotal = (costTotal - 0) + (control.cost.value - 0);
    });
    this.otherResourceCostTotal = costTotal;
  }

  expandItems(data) {
    let idx = this.expandedItems.indexOf(data);
    idx >= 0 ? this.expandedItems.splice(idx, 1) : this.expandedItems.push(data);
  }

  dateFormat(date?: Date) {
    return this.dateUtility.dateFormatterCustom(date);
  }

  expandPane(e, isEdit) {
    let el, firstElement;
    if (!isEdit) {
      el = e.target.tagName == 'I' ? e.target.parentNode : e.target;
      firstElement = el.firstElementChild;
    } else {
      el = e.target.tagName == 'I' ? e.target.parentNode.parentNode : e.target.parentNode;
      firstElement = el.firstElementChild.firstElementChild;
    }
    if (el && firstElement) {
      if (firstElement.className.indexOf('rotate-90') >= 0) {
        el.nextElementSibling.classList.add('hide');
        firstElement.classList.remove('rotate-90');
      } else {
        el.nextElementSibling.classList.remove('hide');
        firstElement.classList.add('rotate-90');
      }
    }
  }
}

