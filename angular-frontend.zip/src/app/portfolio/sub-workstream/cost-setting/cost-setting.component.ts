import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/common/service/data.service';
import { CommonService } from 'src/app/common/service/common.service';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-cost-setting',
  templateUrl: './cost-setting.component.html',
  styleUrls: ['./cost-setting.component.scss'],
  providers: [],
})
export class CostSettingComponent implements OnInit, OnDestroy {
  currencyCode: any;
  category: any;
  selectedTimestamp: any;
  currencyDropDownList = [];
  categoryList = [];

  selectedTab: string;
  headerInfo: any;
  tabObserver: Subscription;

  constructor(private router: Router, private dataService: DataService, private commonService: CommonService) {
    this.headerInfo = {
      title: 'Cost Settings',
      show_filters: false,
      showExpandIcn: false,
      nav_bk_info: sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME),
      nav_bk_url: `/home/portfolio/createPortfolio/subworkstream/${sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME)}`,
      tabs: ['Financial Details', 'HLE', 'Seed Funding']
    }
    this.selectedTab = this.headerInfo.tabs[0];
    this.commonService.recieveMessage(this.headerInfo);
  }

  ngOnInit() {
    this.tabObserver = this.commonService.selectedTab.subscribe(data => {
      this.selectedTab = data;
    });

    this.selectedTimestamp = 'monthly';
    this.currencyDropDownList = ['SGD', 'HKD'];
    this.categoryList = ['Forcast/Actual', 'test']
    this.currencyCode = 'SGD';
    this.category = 'Forcast/Actual';
  }

  ngOnDestroy(){
    this.tabObserver.unsubscribe();
    this.dataService.setActiveTab('Financials');
    this.commonService.expandEvent.emit('costSettingExt');
  }

  //After selecting timestamp
  getDetails(time) {
    this.selectedTimestamp = time;
    console.log("here: ", time)
  }

  close(){
    this.router.navigateByUrl('/home/portfolio/createPortfolio/subworkstream/'+sessionStorage.getItem('subWorkStreamId'));
  }
    
}