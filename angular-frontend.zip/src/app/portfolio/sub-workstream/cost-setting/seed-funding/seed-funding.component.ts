import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/common/service/data.service';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { RestService } from 'src/app/common/service/rest.service';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from 'src/app/common/service/appDateAdapter';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/common/service/common.service';

@Component({
    selector: 'app-seed-funding',
    templateUrl: './seed-funding.component.html',
    styleUrls: ['./seed-funding.component.scss'],
    providers: [{
        provide: DateAdapter, useClass: AppDateAdapter
    },
    {
        provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
    }
    ]
})
export class SeedFundingComponent implements OnInit {

    seedDataForm: FormGroup;
    //currencyDropDownList = [];
    currencyCode: any;
    editAction: boolean;
    seedData: any;
    totalAmount: any = 0;
    viewStartDate: any;
    viewGoLiveDate: any;
    viewTotalAmount: any = 0;
    SeedFundingFinancialInputmessage: String;
    SeedFundingTotalmessage: String;
    workStreamId: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID);
    subWorkStreamId: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID);
    subWorkStreamName: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME);
    scenario: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.SCENARIO);
    currencyCodeType: string = sessionStorage.getItem(WORK_HIERARCHY_CONST.CURRENCY_CODE_TYPE);
    SeedFundingKeyDatesErrorMsg: any;
    keyDatesErrorExists: boolean = false;

    constructor(private dataService: DataService, private formBuilder: FormBuilder, private dateUtility: DateUtility, 
        private restServcie: RestService, private router: Router, private commonService: CommonService) {}

    ngOnInit() {
        this.editAction = history.state.editAction;
        this.seedDataForm = this.formBuilder.group({
            startDate: ['', [Validators.required]],
            goLiveDate: ['', [Validators.required]],
            seedFundingCostTypes: this.formBuilder.array([]),
            workStreamId: this.workStreamId,
            subWorkStreamId: this.subWorkStreamId,
            subWorkStreamName: this.subWorkStreamName,
            scenario: this.scenario,
            currencyCode: this.currencyCodeType,
            dateCreated: [''],
            modifiedDate: [''],
            createdBy: [''],
            modifiedBy: ['']
        });
        this.loadDropdowns();
        this.getSeedDta();
        this.getSeedFundingKeydatesError();
        this.getFinancialInputData();
    }

    loadDropdowns() {
        this.currencyCode = this.currencyCodeType;
        // this.currencyDropDownList.push( this.currencyCode);
    }

    dateFormat(date?: Date) {
        return this.dateUtility.dateFormatterCustom(date);
    }

    getSeedDta() {
        this.dataService.loaderHandler(true);
        this.restServcie.get(URL_PREFIX.PORTFOLIO + "/financial/view-seed-funding?workStreamId=" + this.workStreamId + "&subWorkStreamId=" + this.subWorkStreamId + "&subWorkStreamName=" + this.subWorkStreamName + "&currencyCodeType=" + this.currencyCodeType + "&scenario=" + this.scenario).subscribe(data => {
            this.seedData = data;
            this.dataService.loaderHandler(false);
            this.seedDataForm.controls.startDate.setValue(data.startDate);
            this.seedDataForm.controls.goLiveDate.setValue(data.goLiveDate);
            this.viewStartDate = data.startDate;
            this.viewGoLiveDate = data.goLiveDate;
            data.seedFundingCostTypes.forEach(e => {
                this.viewTotalAmount += Number(e.value);
            });
            this.seedData = data;
            this.setSeedData();
        },
            error => {
                if (error.status !== null) {
                    this.dataService.loaderHandler(false);
                    // console.log(error + 'error');
                    let control = this.seedDataForm.controls;
                    if (!control.startDate.value && !control.goLiveDate.value) {
                        this.keyDatesErrorExists = true;
                    }
                    else {
                        this.keyDatesErrorExists = false;
                    }
                }
            }
        );

    }

    get seedFormDataInput() {
        return this.seedDataForm.get('seedFundingCostTypes') as FormArray;
    }

    // currencySelection(e){
    //     this.currencyCodeType = e.value;
    //     this.getSeedDta();

    // }

    setSeedData() {
        this.seedData.seedFundingCostTypes.push({
            "sfSurrId": 0,
            "costType": "Total",
            "glCategoryName": "OPEX",
            "value": 0
        });
        let control = <FormArray>this.seedDataForm.controls.seedFundingCostTypes;
        if (this.seedData.seedFundingCostTypes) {
            this.seedData.seedFundingCostTypes.forEach(x => {
                this.totalAmount += Number(x.value);
                if (x.costType == "Total") {
                    x.value = this.totalAmount
                }
                control.push(this.formBuilder.group({
                    sfSurrId: x.sfSurrId,
                    costType: x.costType,
                    glCategoryName: x.glCategoryName,
                    value: x.value,
                }))
            });
        }

    }

    saveSeedData() {
        let control = this.seedDataForm.controls;
        if (!control.startDate.value && !control.goLiveDate.value) {
            this.keyDatesErrorExists = true;
        }
        else {
            this.keyDatesErrorExists = false;
        }
        if (!this.keyDatesErrorExists) {
            let prepareData: any = [];

            let control = <FormArray>this.seedDataForm.controls.seedFundingCostTypes;
            for (let index = 0; index < control.value.length; index++) {
                const element = control.value[index];
                if (element.costType == 'Total') {
                    control.value.splice(index, 1);
                }
            }
            prepareData = this.seedDataForm.value;
            this.restServcie.post(URL_PREFIX.PORTFOLIO + "/financial/save-seed-funding", prepareData).subscribe(data => {
                // if (data == 'success') {
                this.editAction = false;
                // this.dataService.setActiveTab('2');
                this.commonService.showSnackBar({
                    type: 'success',
                    message: "Seed Funding updated successfully"
                });
                this.router.navigateByUrl('/home/portfolio/createPortfolio/subworkstream/' + sessionStorage.getItem('subWorkStreamId') + '/cost-setting');
                this.seedData = [];
                this.viewTotalAmount = 0;
                this.totalAmount = 0;
                this.getSeedDta();
                //  }
            },
                error => {
                    if (error.status !== null) {
                        // this.dataService.setActiveTab('');
                        this.router.navigateByUrl('/home/portfolio/createPortfolio/subworkstream/' + sessionStorage.getItem('subWorkStreamId'));
                    }
                }
            );

        }
    }

    getTotal(initial, data) {
        if (data.costType != 'Total') {
            initial += +data.value;
        }
        return initial;
    }


    getTotalAmount(): void {
        this.totalAmount = Number(Object.values(this.seedDataForm.value.seedFundingCostTypes).reduce(this.getTotal, 0));
        ((this.seedDataForm.get('seedFundingCostTypes') as FormArray).at(this.seedData.seedFundingCostTypes.length - 1) as FormGroup).get('value').patchValue(this.totalAmount);

    }

    getSeedFundingKeydatesError() {
        this.restServcie.get(URL_PREFIX.PEOPLE + '/data/dataValues/sys-msg?msgKey=ERR_KEYDATESBLANK_COSTSETTINGSEEDFUNDING').subscribe(data => {
            this.SeedFundingKeyDatesErrorMsg = data.message;
        });
    }

    getFinancialInputData() {
        this.restServcie.get(URL_PREFIX.PEOPLE + '/data/dataValues/sys-msg?msgKey=MSG_INFO_SeedFunding_Financial_Input').subscribe(data => {
            this.SeedFundingFinancialInputmessage = data.message;
        });
    }

}
