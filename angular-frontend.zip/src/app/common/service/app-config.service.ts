import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// import { InterceptedHttp } from './custom.http.provider';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable ()
export class AppConfigService {
  private allUrls: any = {};

  get urls() {
    return this.allUrls;
  }

  set urls(urls: any) {
    this.allUrls = urls;
  }

  constructor(private http: HttpClient) {
  }

  public load() {
    const promise = new Promise ((resolve, reject) => {
      const localHost = new RegExp ('^localhost$|^127(?:\.[0-9]+){0,2}\.[0-9]+$|^(?:0*\:)*?:?0*1$');
      const appConfigUrl = 'assets/mock-data/app-config.json';
      this.http.get (appConfigUrl)
        .subscribe ((response) => {
            this.allUrls = Object.assign ({}, this.allUrls, response);
            // InterceptedHttp.DEFAULT_ENDPOINT = this.allUrls.api_endpoint;
            resolve (this.allUrls);
          },
          this.handleFailure (reject));
    });
    return promise;
  }

  private handleFailure(reject: (x: any) => void) {
    return (error: Error) => {
      alert (`TODO: Seems like your service(/app-config) not working, Error:${error}`);
      return reject (error);
    };
  }
}
export function startupServiceFactory(appConfig: AppConfigService): () => void {
  return () => {
    return appConfig.load ();
  }; // => required, otherwise `this` won't work inside StartupService::load
}
