import { Injectable } from '@angular/core';

@Injectable()
export class DataTableService {
    constructor() {
    }

    tableFilter(): (data: any, filter: string) => boolean {
        let filterFunction = this.filterFunctionForTable;
        return filterFunction;
    }

    filterFunctionForTable(data, filter): boolean {
        let searchTerms = JSON.parse(filter);
            let result: boolean = true;
            for (var prop in searchTerms) {
                if (!data[prop]) {
                    data[prop] = " ";
                } else {
                    searchTerms[prop] = searchTerms[prop].toLowerCase();
                    // added this to handle all case.
                    if((prop === 'tacoInd' || prop === 'empStatus' || prop === 'chapterName' || prop === 'workType'
                    || prop === 'platformName' || prop === 'budgetSystemOwner' || prop === 'budgetStatus'
                    || prop === 'location' || prop === 'workStatus' || prop === 'workstreamName'
                    || prop === 'bizTechInd' || prop === 'countryCode' || prop === 'platformRole' || prop === 'leadDelegateInd' 
                    || prop === 'teamType' || prop === 'status')
                     && searchTerms[prop] == 'all'){
                        searchTerms[prop] = '';
                    }
                    if ((prop === 'tacoInd' || prop === 'empStatus' || prop === 'chapterName' || prop === 'workType' 
                    || prop === 'budgetSystemOwner' || prop === 'budgetStatus' || prop === 'location' || prop === 'workStatus' 
                    || prop === 'workstreamName' || prop === 'bizTechInd' || prop === 'platformRole' 
                    || prop === 'leadDelegateInd' || prop === 'teamType' || prop === 'status')
                     && searchTerms[prop] !== ''){
                        if(data[prop].toLowerCase().indexOf(searchTerms[prop]) !== -1 && data[prop].toLowerCase() != searchTerms[prop]){
                           result = false;
                        }
                    }
                }
                result = (data[prop].toLowerCase().indexOf(searchTerms[prop]) !== -1) && result;
            }
            return result;
    }

    tableFilterForSearch(): (data: any, filter: string) => boolean {
        let filterFunction = this.filterFunctionForSearch;
        return filterFunction;
    }

    filterFunctionForSearch(data, filter): boolean {
        let searchTerms = JSON.parse(filter);
        let result: boolean = false;
        for (var prop in searchTerms) {
            result = (data[prop] ? data[prop].toLowerCase().indexOf(searchTerms[prop]) !== -1 : '') || result;
        }
        return result;
    }
}
