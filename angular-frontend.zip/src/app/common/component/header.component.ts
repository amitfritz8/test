import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import * as _ from 'lodash';
import { RestService } from '../service/rest.service';
import { CommonService } from '../service/common.service';
import { DataService } from '../service/data.service';
import * as moment from 'moment';
import { Subscription } from 'rxjs';

declare var $: any;
@Component({
  selector: 'app-header',
  templateUrl: '../views/header.component.html',
  styleUrls: ['../css/header.component.scss']
})
export class HeaderComponent implements OnInit, AfterViewInit, OnDestroy {

  basicInfo: any = {
    title: '',
    avatar: false,
    show_filters: true,
    prevent_idx_update: false,
    backnavigation: '',
    nav_bk_url: '',
    nav_bk_info: '',
    additional_info: '',
    tabs: '',
    err_tabs: '',
    btns: '',
    showExpandIcn: true
  }
  headerInfo: any = {};
  portalInfo: any = {
    mapping: {
      countries: [],
      techUnits: []
    }
  };
  platforms: any = [];
  selectedCountries: any = [];
  selectedTechUnits: any = [];
  selectedPlatforms: any = [];
  currentPlatform: any;
  observer: Subscription;
  dataObserserver: Subscription;

  constructor(private commonService: CommonService, private restService: RestService,
    private dataService: DataService) {
    this.observer = this.commonService.captureMessage.subscribe(data => {
      this.headerInfo = _.merge(Object.assign({}, this.basicInfo), data);
    });
  }

  ngOnInit() {
    this.portalInfo = this.commonService.getProtalInfo();
    this.setFindMeData(this.portalInfo);
    this.dataObserserver = this.dataService.getRptPeriodObs().subscribe(data => {
      if (data === 'default message') {
        this.getUserDetails(new Date().getFullYear() + moment(new Date()).format('MM'));
      } else {
        this.getUserDetails(data);
      }
    });
  }

  ngOnDestroy(){
    this.observer.unsubscribe();
    this.dataObserserver.unsubscribe();
  }

  ngAfterViewInit() {
    // watch dropdown close event in fliter to auto populate
    if (this.headerInfo.show_filters) {
      this.watchClassChanges(document.getElementById('countryDwn').childNodes[1]);
      this.watchClassChanges(document.getElementById('techDwn').childNodes[1]);
      this.watchClassChanges(document.getElementById('platformDwn').childNodes[1]);
    }
  }

  watchClassChanges(node) {
    const self = this;
    const observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (mutation) {
        if (mutation.attributeName === 'class') {
          const attributeValue = $(mutation.target).prop(mutation.attributeName);
          if (attributeValue.indexOf('show') < 0) {
            self.populateDefaultValue();
          }
        }
      });
    });
    observer.observe(node, {
      attributes: true
    });
  }

  populateDefaultValue() {
    this.selectedCountries = (this.selectedCountries.length == 0) ? Object.assign([], this.portalInfo.mapping.countries) : this.selectedCountries;
    if (this.selectedTechUnits.length == 0) {
      this.selectedTechUnits = Object.assign([], this.portalInfo.mapping.techUnits);
      this.populateTechPlatforms();
    }
    if (this.selectedPlatforms.length == 0) {
      this.selectedPlatforms = [];
      _.forIn(this.platforms, (v, k) => {
        this.selectedPlatforms.push(v.platformIndex);
      });
    }
  }

  getUserDetails(rptPeriod) {
    let url = '/people/user/findme';
    if (rptPeriod && rptPeriod !== '') {
      url = url + `/rptPeriod/${rptPeriod}`;
    }
    this.restService.get(url).subscribe(data => {
      this.setFindMeData(data);
    });
  }

  selectHandler(item, flag) {
    const idx = (flag == 'location') ? this.selectedCountries.indexOf(item) :
      (flag == 'lobt') ? this.selectedTechUnits.indexOf(item) : this.selectedPlatforms.indexOf(item.platformIndex);

    if (idx >= 0) {
      switch (flag) {
        case 'location':
          this.selectedCountries.splice(idx, 1);
          break;
        case 'lobt':
          this.selectedTechUnits.splice(idx, 1);
          break;
        case 'platforms':
          this.selectedPlatforms.splice(idx, 1);
          break;
      }
    } else {
      switch (flag) {
        case 'location':
          this.selectedCountries.push(item);
          break;
        case 'lobt':
          this.selectedTechUnits.push(item);
          break;
        case 'platforms':
          this.selectedPlatforms.push(item.platformIndex);
          break;
      }
    }

    if (flag == 'lobt') {
      this.populateTechPlatforms();
    }
    if (this.selectedPlatforms.length == 1 && flag == 'platforms') {
      _.forIn(this.platforms, (v, k) => {
        if (v.platformIndex == this.selectedPlatforms[0]) {
          this.currentPlatform = `${v.platformIndex} - ${v.platform}`;
        }
      });
    }
    this.updateSessionStorage();
    this.commonService.broadcastMessage(flag);
  }

  populateTechPlatforms() {
    this.platforms = [];
    this.selectedPlatforms = [];
    _.forIn(this.portalInfo.mapping.techUnitsAndPlatforms, (v, k) => {
      if (this.selectedTechUnits.indexOf(k) >= 0) {
        this.platforms.push(...v);
        _.forIn(v, (v, k) => { this.selectedPlatforms.push(v.platformIndex); });
      }
    });
    this.platforms = this.platforms.sort((a, b) => (a.platformIndex > b.platformIndex) ? 1 : -1);
    sessionStorage.setItem('selectedPIwithNames',this.stringfyJson(this.platforms));
  }


  allHandler(e, flag) {
    if (e.checked) {
      switch (flag) {
        case 'location':
          this.selectedCountries = Object.assign([], this.portalInfo.mapping.countries);
          break;
        case 'lobt':
          this.selectedTechUnits = Object.assign([], this.portalInfo.mapping.techUnits);
          this.populateTechPlatforms();
          break;
        case 'platforms':
          this.selectedPlatforms = [];
          _.forIn(this.platforms, (v, k) => { this.selectedPlatforms.push(v.platformIndex) });
          break;
      }
    } else {
      switch (flag) {
        case 'location':
          this.selectedCountries = [];
          break;
        case 'lobt':
          this.selectedTechUnits = [];
          break;
        case 'platforms':
          this.selectedPlatforms = [];
          break;
      }
    }
    this.updateSessionStorage();
    this.commonService.broadcastMessage(flag);
  }

  level3PermissionForRoles() {
    const userRoleList = (this.portalInfo.mapping.roles !== null || this.portalInfo.mapping.roles !== '') ? Object.keys(this.portalInfo.mapping.roles).toString() : '';
    this.restService.get(`/people/user/level3users?userRole=${userRoleList}&bankID=${this.portalInfo.username}`).subscribe(
      data => {
        if (data) {
          localStorage.setItem('roleListValues', data);
        }
      },
      err => {
        console.log(err);
      }
    );

    if (userRoleList !== null || userRoleList !== '') {
      this.restService.post(`/people/data/dataSummary/roles`, [userRoleList]).subscribe(data => {
        if (data.length > 0) {
          const { desc, attr1 } = data[0];
          localStorage.setItem('readAccess', this.stringfyJson(desc.split(',')));
          localStorage.setItem('writeAccess', this.stringfyJson(attr1.split(',')))
        }
      });
    }
  }

  setFindMeData(data: any) {
    this.portalInfo = data;
    localStorage.setItem('userInfo', data);
    localStorage.setItem('loggedInCountry', data.ldapUserInfo.country);
    this.selectedCountries = Object.assign([], data.mapping.countries);
    this.selectedTechUnits = Object.assign([], data.mapping.techUnits);
    this.platforms = [];
    this.selectedPlatforms = [];
    _.forIn(data.mapping.techUnitsAndPlatforms, (v, k) => {
      this.platforms.push(...v);
      _.forIn(v, (v, k) => { this.selectedPlatforms.push(v.platformIndex); });
    });
    this.platforms = this.platforms.sort((a, b) => (a.platformIndex > b.platformIndex) ? 1 : -1);
    this.updateSessionStorage();
    sessionStorage.setItem('currentUserRole', JSON.stringify(data.securityGroup));
    sessionStorage.setItem('currentUserId', JSON.stringify(data.resourceId));
    sessionStorage.setItem('lobts', JSON.stringify(data.mapping.techUnits));
    sessionStorage.setItem('loggedInUserTechUnit', JSON.stringify(data.techUnit));
    sessionStorage.setItem('techUnitsAndPlatforms', JSON.stringify(data.mapping.techUnitsAndPlatforms));
    sessionStorage.setItem('locationsAsPerUAMS', JSON.stringify(data.mapping.countries));
    sessionStorage.setItem('modulesMapping', JSON.stringify(data.mapping.modules));
    sessionStorage.setItem('roles', JSON.stringify(data.mapping.roles));
    sessionStorage.setItem('platformsAsPerUAMS', this.stringfyJson(this.platforms));
    sessionStorage.setItem('selectedPIwithNames',this.stringfyJson(this.platforms));

    this.level3PermissionForRoles();
  }

  updateSessionStorage() {
    sessionStorage.setItem('selectedPlatforms', this.stringfyJson(this.selectedPlatforms));
    sessionStorage.setItem('selectedLobts', this.stringfyJson(this.selectedTechUnits));
    sessionStorage.setItem('locations', this.stringfyJson(this.selectedCountries));
  }

  toggleMode(){
    this.commonService.expandEvent.emit('true');
  }

  stringfyJson(data) {
    return JSON.stringify(data);
  }
}
