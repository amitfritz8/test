import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PcftRangeComponent } from './pcft-range.component';

xdescribe('PcftRangeComponent', () => {
  let component: PcftRangeComponent;
  let fixture: ComponentFixture<PcftRangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PcftRangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PcftRangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
