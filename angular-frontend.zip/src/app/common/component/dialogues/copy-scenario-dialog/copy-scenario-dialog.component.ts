import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { CopyScenarioModel } from 'src/app/portfolio/workstream/copyscenario.model';

@Component({
  selector: 'app-copy-scenario-dialog',
  templateUrl: './copy-scenario-dialog.component.html',
  styleUrls: ['./copy-scenario-dialog.component.scss']
})
export class CopyScenarioDialogComponent {
  copyFormGroup: FormGroup;

  constructor(public dialogRef: MatDialogRef<CopyScenarioDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private fb: FormBuilder,
    private router: Router, private restService: RestService,
    private dataService: DataService, public dialog: MatDialog,) {

    this.copyFormGroup = this.fb.group({
      workStreamId: this.fb.control(this.data.workStreamId),
      portFolioId: this.fb.control(this.data.portFolioId),
      scenarioTo: this.fb.control("",Validators.required),
      scenarioFrom: this.fb.control("", Validators.required)
    });
  }

  goBack() {
    this.dialogRef.close('no');
  }

  copyScenario() {
    if (this.data.copyToCallback) {
      this.data.copyToCallback(this.copyFormGroup.value, this.dialogRef);
      this.dialogRef.close();
    }
  }
}
