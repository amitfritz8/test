// import {async, ComponentFixture, TestBed} from '@angular/core/testing';
// import {UpdateProfileComponent} from './update-profile-component';
// import {DebugElement} from '@angular/core';
// import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// import {MaterialModule} from '../../../material.module';
// import {BrowserModule, By} from '@angular/platform-browser';
// import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
// import {DataService} from '../../../shared/services/data.service';
// import {HttpClient, HttpHeaders} from '@angular/common/http';
// import {NO_ERRORS_SCHEMA} from '@angular/core';
// import {of} from 'rxjs';
// import {configureTestSuite} from 'ng-bullet';

// describe('UpdateProfileComponent', () => {
//   let component: UpdateProfileComponent;
//   let fixture: ComponentFixture<UpdateProfileComponent>;
//   let de: DebugElement;
//   let el: HTMLElement;

//   configureTestSuite(() => {
//     TestBed.configureTestingModule({
//       declarations: [UpdateProfileComponent],
//       schemas: [NO_ERRORS_SCHEMA],
//       imports: [
//         BrowserAnimationsModule,
//         MaterialModule,
//         BrowserModule],
//       providers: [
//         {provide: MatDialogRef, useClass: MockMatDialogRef},
//         {provide: MAT_DIALOG_DATA, useClass: MockMAT_DIALOG_DATA},
//         {provide: DataService, useClass: MockDataService},
//         {provide: HttpClient, useClass: MockHttpClient}
//       ]
//     })
//     fixture = TestBed.createComponent(UpdateProfileComponent);
//     component = fixture.componentInstance;
//     // component.fileValid = true;
//     // component.validFileExtensions = ['.xlsx'];
//     // component.selectedDate = "2019 August";
//     component.ngOnInit();
//     fixture.detectChanges();
//     de = fixture.debugElement.query(By.css('.mainDiv'));
//     el = de.nativeElement;
//   });


//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   describe('onNoClick', () => {
//     it('should call onNoClick', () => {
//       component.onNoClick();
//       let s: MockMatDialogRef = new MockMatDialogRef();
//       spyOn(s, 'close');
//       s.close('no');
//       expect(s.close).toHaveBeenCalled();
//     });
//   });

//   // describe('onYesClick', () => {
//   //   it('should call onYesClick', () => {
//   //     component.onYesClick();
//   //     const fileValid = component.fileValid = true;
//   //     let s: MockYesClick = new MockYesClick();
//   //     spyOn(s, 'yesClicked');
//   //     s.yesClicked(fileValid);
//   //     expect(s.yesClicked).toHaveBeenCalled();
//   //   });
//   // });

//   // describe('deleteAttachment', () => {
//   //   it('should call deleteAttachment', () => {
//   //     component.deleteAttachment(1);
//   //     component.isErrorExists = false;
//   //     let s: MockMatDialogRef = new MockMatDialogRef();
//   //     spyOn(s, 'updateSize');
//   //     s.updateSize('400', '50%');
//   //     expect(s.updateSize).toHaveBeenCalled();
//   //   });
//   // });
//   // describe('uploadFile', () => {
//   //   it('should call uploadFile', () => {
//   //     component.uploadFile([{'name': 'test.xlsx'}]);
//   //     component.fileValid = false;
//   //     let s: MockMatDialogRef = new MockMatDialogRef();
//   //     spyOn(s, 'updateSize');
//   //     component.files = [];
//   //     s.updateSize('400', '50%');
//   //     expect(s.updateSize).toHaveBeenCalled();
//   //   });
//   // });
//   // describe('validate', () => {
//   //   it('should call validate', () => {
//   //     component.fileValid = false;
//   //     component.isErrorExists = true;
//   //     component.uploadResult = [{message: '', errorFlag: 1}];
//   //     component.validate('test.xlsx');
//   //     let s: MockDataService = new MockDataService();
//   //     spyOn(s, 'getCustomMessage');
//   //     component.files = [];
//   //     s.getCustomMessage('test');
//   //     expect(s.getCustomMessage).toHaveBeenCalled();
//   //   });
//   // });
//   // describe('checkFileValid invalid case', () => {
//   //   it('should call checkFileValid', () => {
//   //     component.fileValid = false;
//   //     component.checkFileValid();
//   //     component.isErrorExists = true;
//   //     component.uploadResult = [{message: '', errorFlag: 1}];
//   //     // component.validate('test.xlsx');
//   //     let s: MockDataService = new MockDataService();
//   //     spyOn(s, 'getCustomMessage');
//   //     spyOn(s, 'getFlag');
//   //     component.files = [];
//   //     s.getCustomMessage('test');
//   //     s.getFlag(1);
//   //     expect(s.getCustomMessage).toHaveBeenCalled();
//   //     expect(s.getFlag).toHaveBeenCalled();
//   //   });
//   // });
//   // describe('checkFileValid for valid file', () => {
//   //   it('should call checkFileValid', (done: DoneFn) => {
//   //     component.fileValid = true;
//   //     component.checkFileValid();
//   //     done();
//   //   });
//   // });
//   // describe('checkFileValid for valid file', () => {
//   //   it('should call checkFileValid', (done: DoneFn) => {
//   //     component.fileValid = true;
//   //     component.checkFileValid();
//   //     done();
//   //   });
//   // });
//   // describe('handleReportingPeriod', () => {
//   //   it('should call handleReportingPeriod', (done: DoneFn) => {
//   //     component.dates = [];
//   //     component.handleReportingPeriod();
//   //     done();
//   //   });
//   // });
// });

// class MockMatDialogRef {
//   updateSize(a, b) {
//     return a * b;
//   }

//   close(test) {
//     return null;
//   }
// }

// class MockMAT_DIALOG_DATA {

// }

// class MockDataService {
//   getCustomMessage(test) {
//     return null;
//   }

//   loaderHandler() {
//     return null;
//   }

//   getFlag(test) {
//     return null;
//   }
// }

// class MockHttpClient {
//   post() {
//     return of({})
//   }
// }

// class MockYesClick {
//   yesClicked(fileValid) {
//     return null;
//   }
// }
