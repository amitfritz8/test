import {AfterViewInit, Component, Inject, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA, MatDialog} from '@angular/material/dialog';
import {MatSelect} from '@angular/material/select';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {DataService} from 'src/app/common/service/data.service';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Observable, ReplaySubject, Subject} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {RestService} from 'src/app/common/service/rest.service';
import {take, takeUntil} from 'rxjs/operators';
import {CdkVirtualScrollViewport} from '@angular/cdk/scrolling';
import { CommonDialogComponent } from 'src/app/common/component/dialogues/common-dialog/common-dialog-component';
import { CommonService } from "src/app/common/service/common.service";
import { asLiteral } from '@angular/compiler/src/render3/view/util';

@Component({
  selector: 'update-profile',
  templateUrl: 'update-profile-component.html',
  styleUrls: ['./update-profile-component.scss'],
})
export class UpdateProfileComponent implements OnInit, AfterViewInit, OnDestroy {

  peopleForm: FormGroup;
  dropDownData: any;
  isErrorExists = false;
  subPlatformData: any;
  chapterData: any;
  filteredSubPlatformData: Observable<any>;
  public chapterMultiCtrl: FormControl = new FormControl();
  public subPlatformCtrl: FormControl = new FormControl('', Validators.required);

  public chapterMultiFilterCtrl: FormControl = new FormControl();
  public subPlatformFilterCtrl: FormControl = new FormControl();

  public filteredChaptersMulti: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

  @ViewChild('multiSelect', {static: true}) multiSelect: MatSelect;
  @ViewChild('singleSelect', {static: true}) singleSelect: MatSelect;

  protected _onDestroy = new Subject<void>();
  editWindowPeriod = '';
  nextMonthUpdateConfirmationMessage = '';
  previousMonthUpdateConfirmationMessage = '';

  subplatformErrorMsg:string = '';
  techUnitsErrorMsg:string = '';
  subPlatform: string[] = [];
  platforms: string[] = [];
  techunits: string[] = [];
  selectedUser:any;

  @ViewChild('virtualScroller', {static: false}) virtualScroller: CdkVirtualScrollViewport;
  warningMsg: any;
  private updatePreviousMonth: boolean;
  private updateNextMonth: boolean;
  private bodyText: string;
  private currentMonthStatus: boolean;
  value=null;
  private subPlatformName: any;
  public isTypeOfWorkMandatory: boolean;

  constructor(private fb: FormBuilder, private http: HttpClient, public dialogRef: MatDialogRef<UpdateProfileComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any, private dataService: DataService, private restService: RestService, public dialog: MatDialog, private commonService: CommonService) {
  }

  filterSubPlatforms(value: string){
    if (!this.subPlatformData) {
      return;
    }
    let filteredData = this.subPlatformData.filter(subplatform => subplatform.subPlatformName.toLowerCase().indexOf(value.toLowerCase()) === 0);
    if(this.subPlatformCtrl.value === ''){
      this.subplatformErrorMsg = 'Please fill up this mandatory field'
    } else if(!this.subPlatformData.find(element => element.subPlatformName === value)){
      this.subplatformErrorMsg = 'Please choose a valid Sub Platform';
    } else {
      this.subplatformErrorMsg = '';
    }
    return filteredData;
  }

  ngOnInit() {
    this.dropDownData = JSON.parse(sessionStorage.getItem('dataValues'));
    this.dialogRef.updateSize('90%', '95%');
    this.loadDataValues();
    let uniqueTypeOfWork1Values = [];
    let uniqueTypeOfWork2Values = [];
    let defaultSubPlatformValue = '';
    this.data.selectedValues.forEach(selectedEmployee => {
      // console.warn('selectedEmployee ++ ', selectedEmployee);
      if (this.platforms.indexOf(selectedEmployee.platformIndex) === -1) {
        this.platforms.push(selectedEmployee.platformIndex);
      }
      if(this.techunits.indexOf(selectedEmployee.techUnit) === -1){
        this.techunits.push(selectedEmployee.techUnit);
      }
      if(this.subPlatform.indexOf(selectedEmployee.subPlatform) === -1){
        this.subPlatform.push(selectedEmployee.subPlatform);
      }
      defaultSubPlatformValue = selectedEmployee.subPlatform;

      if(uniqueTypeOfWork1Values.indexOf(selectedEmployee.typeOfWork1) === -1){
        console.warn('selectedEmployee.typeOfWork1 >> ', selectedEmployee.typeOfWork1);
        uniqueTypeOfWork1Values.push(selectedEmployee.typeOfWork1);
      }
      if(uniqueTypeOfWork2Values.indexOf(selectedEmployee.typeOfWork2) === -1){
        console.warn('selectedEmployee.typeOfWork2 >> ', selectedEmployee.typeOfWork2);
        uniqueTypeOfWork2Values.push(selectedEmployee.typeOfWork2);
      }
    });
    let isEmptyTypeOfWorkValues:boolean = false;
    // unique values, set default selected for both radios
    if(uniqueTypeOfWork1Values.length === 1 && uniqueTypeOfWork2Values.length === 1){
      isEmptyTypeOfWorkValues = !uniqueTypeOfWork1Values[0] || !uniqueTypeOfWork2Values[0];
      this.isTypeOfWorkMandatory = isEmptyTypeOfWorkValues ? true : false;
    } else {
      this.isTypeOfWorkMandatory = false; // for multiple records, user may retain old type of work values
    }
    this.peopleForm = this.fb.group({
      //subPlatform: ['', [Validators.required]],
      typeOfWork1: this.isTypeOfWorkMandatory ? ['', [Validators.required]] : [''],
      typeOfWork2: this.isTypeOfWorkMandatory ? ['', [Validators.required]] : [''],
      //onOffshore: [''],
      chapter: ['']
    });
    if(uniqueTypeOfWork1Values.length === 1 && uniqueTypeOfWork2Values.length === 1 && !isEmptyTypeOfWorkValues){
      this.SetDefaultRadioButtonValues(uniqueTypeOfWork1Values[0], uniqueTypeOfWork2Values[0]); 
    } else {
      this.dropDownData['Type of Work 2'] = [{value: 'Enhancement'}, {value: 'Initiatives'}];
    }
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_PEOPLE_BULKEDIT_AFFECTALL`).subscribe(result => {
      this.warningMsg = result['message'];
    });
    // console.warn('this.patforms', this.platforms);
    if (this.platforms.length === 1) {
      if(this.subPlatform.length === 1){
        this.getSubplatformsByPlatformIndex(this.platforms[0]);
        this.selectedUser= this.subPlatform[0] === "" ? 'Not Applicable' : this.subPlatform[0];
      } else {
        this.getSubplatformsByPlatformIndex(this.platforms[0]);
      }
      this.SetDefaultSubPlatformValues(defaultSubPlatformValue);
    } else {
      this.subPlatformCtrl.disable();
      this.subPlatformFilterCtrl.disable();
      this.subplatformErrorMsg = 'Subplatform cannot be bulk updated for staff selected across different platforms';
    }
    // console.warn('techunits ++ ', this.techunits);
    if (this.techunits.length === 1) {
      this.getChapterByTechUnit(this.techunits[0]);
    } else {
      this.peopleForm.controls['chapter'].disable();
      this.chapterMultiCtrl.disable();
      this.techUnitsErrorMsg = 'Chapters cannot be bulk updated for staff selected across different tech units';
    }
  }

  compare(a: any, b: any){
    let comparision = 0;
    if(a.subPlatformName > b.subPlatformName) {
      comparision = 1;
    }
    else if(a.subPlatformName < b.subPlatformName) {
      comparision = -1;
    }
    return comparision;
  }


  getSubplatformsByPlatformIndex(platformIndex: string) {
    this.restService.get(`/people/data/subPlatforms/list/${platformIndex}`).subscribe(data => {
      this.subPlatformData = data;
      if(!this.subPlatformData.find(element => element.subPlatformName === "Not Applicable")){
        this.subPlatformData.push({subPlatformName: "Not Applicable"});
      }
      this.subPlatformData.sort(this.compare);
      // console.warn('sub platform data >> ', data);
      this.filteredSubPlatformData = this.subPlatformCtrl.valueChanges
      .pipe(
          startWith(''),
          map(subplatform => subplatform ? this.filterSubPlatforms(subplatform) : this.subPlatformData.slice())
      );
    },
    error => {
      console.warn('error subplatform >>', error);
      let message = error.statusText;
      if(error.error){
        message += error.error.message;
        this.commonService.showSnackBar({ type: 'alert', message: message, duration: 3000 });
      }
    })
  }

  getChapterByTechUnit(techUnit: string) {
    this.restService.get(`/people/data/chapters/all/${techUnit}`).subscribe(data => {
      // console.warn('getChapterByTechUnit data is >>', data);
      this.chapterData = data;
      this.filteredChaptersMulti.next(this.chapterData.slice());

      this.chapterMultiFilterCtrl.valueChanges
        .pipe(takeUntil(this._onDestroy))
        .subscribe(() => {
          this.filterChaptersMulti();
        });
    });
  }

  ngAfterViewInit() {
  //  this.setInitialValue();
  }

  // private _filterEmployee(value: string) {
  //   const filterValue = value.toLowerCase();
  //   return this.subPlatformData.filter(employee => employee.subPlatformName.toLowerCase().indexOf(filterValue) === 0);
  // }

  openWarningDialog(title: string, message: string, noButtonText: string, yesButtonText: string, closeIcon: boolean){
    return this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'warning',
        contentTitle: title,
        content: message,
        cancelTxt: noButtonText,
        confirmTxt: yesButtonText,
        showCloseIcon: closeIcon
      }
    });
  }

  openConfirmationDialog(title: string, message: string, noButtonText: string, yesButtonText: string, closeIcon: boolean){
    return this.dialog.open(CommonDialogComponent, {
      data: {
        type: 'confirm',
        contentTitle: title,
        content: message,
        cancelTxt: noButtonText,
        confirmTxt: yesButtonText,
        showCloseIcon: closeIcon
      }
    });
  }

  onNoClick(): void {
    const dialogRef = this.openWarningDialog('Unsaved changes', 
                      'You are leaving with unsaved changes, any changes will be lost.\nAre you sure you want to leave this page?', 
                      'Stay on Page', 'Leave Page', false);

    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.dialogRef.close('cancel');
      }
    });
  }

  isSingleUpdate() : boolean {
    return this.data.selectedValues.length == 1;
  }

  isSubPlatformInvalid(): boolean {
    return this.subPlatformCtrl && this.subPlatformCtrl.invalid;
  }

  onYesClick(): void {
    const controls = this.peopleForm.controls;
    if(this.subPlatformCtrl.enabled && this.subplatformErrorMsg !== ''){
      return;
    }
    if(this.subPlatformCtrl.enabled && this.subPlatformCtrl.value === ''){
      this.subplatformErrorMsg = 'Please fill up this mandatory field';
      return;
    }
    for (const name in controls) {
      if (controls[name].invalid) {
        this.peopleForm.controls[name].markAsTouched();
      }
    }
    if (this.peopleForm.invalid) {
      this.peopleForm.markAllAsTouched();
    }
    if (this.peopleForm.valid) {
      const currentDate = new Date().getDate();
      this.currentMonthStatus = this.dataService.getcurrentMonthStatus();
      if(this.subPlatformCtrl.value != null   || this.subPlatformCtrl.value != undefined ) {
        if(currentDate <= parseInt(this.editWindowPeriod)){
          if(this.isSingleUpdate()){
            let currentMonthFlag = this.currentMonthStatus ? 'Y' : 'N'; 
            let url = `/people/data/employee/individualProfile?id=${this.data.selectedValues[0]['oneBankId']}&currentMonthFlag=${currentMonthFlag}`;
            this.restService.get(url).subscribe(data => {
              data ? this.checkForUpdation(data, this.currentMonthStatus) : this.apiCall();
            });
          } else {
            this.dialogBox(this.currentMonthStatus);
          } 
        } else {
            // current > editWindowperiod
          this.apiCall();
        }
      }
      else {
        this.apiCall();
      }
    }
  }
  checkForUpdation(data, currentMonthStatus) {
    if (!(data['workType2'] === '' || data['workType1'] === '' || data['subPlatform'] === '') &&
      (this.peopleForm.controls.typeOfWork1.value === '' || this.peopleForm.controls.typeOfWork2.value=== '' || this.subPlatformCtrl.value === '')) {
      this.dialogBox(currentMonthStatus);
    }
    if ((data['workType2'] === '' || data['workType1'] === '' || data['subPlatform'] === '') &&
      !(this.peopleForm.controls.typeOfWork1.value === '' || this.peopleForm.controls.typeOfWork2.value=== '' || this.subPlatformCtrl.value === '')) {
      this.dialogBox(currentMonthStatus);
    }
    else if (!(data['workType2'] === '' || data['workType1'] === '' || data['subPlatform'] === '') &&
      !(this.peopleForm.controls.typeOfWork1.value === '' || this.peopleForm.controls.typeOfWork2.value === '' || this.subPlatformCtrl.value === '')) {
      this.dialogBox(currentMonthStatus);
    }
    else if ((data['workType2'] === '' || data['workType1'] === '' || data['subPlatform'] === '') &&
      (this.peopleForm.controls.typeOfWork1.value === '' || this.peopleForm.controls.typeOfWork2.value === '' || this.subPlatformCtrl.value === '')) {
      currentMonthStatus ? this.updatePreviousMonth = true : this.updateNextMonth = true;
      this.apiCall();
    }
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  toggleSelectAll(selectAllValue: boolean) {
    this.filteredChaptersMulti.pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(val => {
        if (selectAllValue) {
          this.chapterMultiCtrl.patchValue(val);
        } else {
          this.chapterMultiCtrl.patchValue([]);
        }
      });
  }

  /**
   * Sets the initial value after the filteredBanks are loaded initially
   */
  /*protected setInitialValue() {
    this.filteredChaptersMulti
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        // setting the compareWith property to a comparison function
        // triggers initializing the selection according to the initial value of
        // the form control (i.e. _initializeSelection())
        // this needs to be done after the filteredBanks are loaded initially
        // and after the mat-option elements are available
        this.multiSelect.compareWith = (a: any, b: any) => a && b && a.chapterName === b.chapterName;
      });
    this.filteredSubPlatform
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        // setting the compareWith property to a comparison function
        // triggers initializing the selection according to the initial value of
        // the form control (i.e. _initializeSelection())
        // this needs to be done after the filteredBanks are loaded initially
        // and after the mat-option elements are available
        this.singleSelect.compareWith = (a: any, b: any) => a && b && a.subPlatformName === b.subPlatformName;
      });
  }*/

  protected filterChaptersMulti() {
    if (!this.chapterData) {
      return;
    }
    // get the search keyword
    let search = this.chapterMultiFilterCtrl.value;
    if (!search) {
      this.filteredChaptersMulti.next(this.chapterData.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredChaptersMulti.next(
      this.chapterData.filter(bank => bank.chapterName.toLowerCase().indexOf(search) > -1)
    );
  }

  SetDefaultSubPlatformValues(defaultSubPlatform: string){
    this.subPlatformCtrl.setValue(defaultSubPlatform);
  }

  SetDefaultRadioButtonValues(defaultTypeOfWork1: string, defaultTypeOfWork2: string){
    this.OntypeOfWork(defaultTypeOfWork1 === 'Build' ? this.dropDownData['Type of Work 1'][0] : this.dropDownData['Type of Work 1'][1]);
    this.peopleForm.controls.typeOfWork1.setValue(defaultTypeOfWork1 ? defaultTypeOfWork1 : this.dropDownData['Type of Work 1'][0].value);
    this.peopleForm.controls.typeOfWork2.setValue(defaultTypeOfWork2 ? defaultTypeOfWork2 : this.dropDownData['Type of Work 2'][0].value);
  }

  IsTypeOfWork1Selected(defaultValue: string): boolean{
    if(this.peopleForm.controls.typeOfWork1){
      return this.peopleForm.controls.typeOfWork1.value === defaultValue;
    }
    return false;
  }
  IsTypeOfWork2Selected(defaultValue: string): boolean{
    if(this.peopleForm.controls.typeOfWork2){
      return this.peopleForm.controls.typeOfWork2.value === defaultValue;
    }
    return false;
  }
  OntypeOfWork(selectedRadio) {
    if (selectedRadio.value === 'Build') {
      this.dropDownData['Type of Work 2'] = [{value: 'Enhancement'}, {value: 'Initiatives'}];
      this.peopleForm.controls.typeOfWork2.setValue('Enhancement');
    } else if (selectedRadio.value === 'Operate') {
      this.dropDownData['Type of Work 2'] = [{value: 'Operate'}];
      this.peopleForm.controls.typeOfWork2.setValue('Operate');
    }
  }


  get f() {
    return this.peopleForm.controls;
  }
  loadDataValues() {
    this.restService.get(`/people/data/dataValues/sys-config?msgKey=People Edit Window - Previous Month`).subscribe(result => {
      this.editWindowPeriod = result['message'];
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_PEOPLE_EDIT_NXTMONTH_CONFIRMATION`).subscribe(result => {
      this.nextMonthUpdateConfirmationMessage = result['message'];
    });
    this.restService.get(`/people/data/dataValues/sys-msg?msgKey=MSG_PEOPLE_EDIT_PREVMONTH_CONFIRMATION`).subscribe(result => {
      this.previousMonthUpdateConfirmationMessage = result['message'];
    });
  }

  private apiCall() {
    let selectedIds: number[] = [];
    this.data.selectedValues.forEach(value => {
      if (value.id) {
        selectedIds.push(value.id);
      }
    });
    let chapterName = '';
    if (this.chapterMultiCtrl.value) {
      this.chapterMultiCtrl.value.forEach(value => {
        if (chapterName === '') {
          chapterName = value.chapterName;
        } else {
          chapterName = chapterName + '; ' + value.chapterName;
        }
      });
    }
    if (this.subPlatformCtrl.value !== undefined) {
      this.subPlatformName = this.subPlatformCtrl.value;
    }
    else if(this.subPlatform.length ===1){
      this.subPlatformName=this.subPlatform[0];
    }

    const request = {
      selectedIds: selectedIds,
      subPlatform: this.subPlatformName,
      typeOfWork1: this.peopleForm.controls.typeOfWork1.value,
      typeOfWork2: this.peopleForm.controls.typeOfWork2.value,
      chapterName: chapterName,
      'updatePreviousMonth': this.updatePreviousMonth,
      'updateNextMonth': this.updateNextMonth,
      'modifiedBy' : JSON.parse(localStorage.getItem('userinfo')).username
    };
    this.restService.post(`/people/data/employee/update/newjoiners`, request).subscribe(data => {
      this.dialogRef.close('no');
      this.commonService.showSnackBar({ type: 'success', message: data.message, duration: 3000 });
    },error=>{
      this.showErrorMessage(error);
    });;
  }

  showErrorDialog(title: string, message: string){
    this.dialog.open(CommonDialogComponent, {
      data: {
      type: 'alert',
      contentTitle: title,
      content: message,
      confirmTxt: "Ok"
      }
    });
  }

  showErrorMessage(errorResponse: any){
    this.commonService.showSnackBar({ type: 'alert', message: errorResponse.statusText + ': ' + errorResponse.error.path + ' \n' + errorResponse.error.message, duration: 3000 });
  }

  private dialogBox(currentMonthStatus: any) {
    this.bodyText = currentMonthStatus ? this.previousMonthUpdateConfirmationMessage : this.nextMonthUpdateConfirmationMessage;
    let yesButtonText = '';
    let noButtonText = 'Update Current Month';
    if(this.bodyText.indexOf('?') != -1){
      let line1 = this.bodyText.substring(0, this.bodyText.indexOf('?')+1);
      let line2 = this.bodyText.substring(this.bodyText.indexOf('?')+1);
      this.bodyText = line1 + '\n' + line2;
    }
    this.updateNextMonth = false;
    this.updatePreviousMonth = false;
    yesButtonText = currentMonthStatus ? 'Update Current and Previous Month' : 'Update Current and Next Month';
    const dialogRef = this.openConfirmationDialog('Update Details', this.bodyText, noButtonText, yesButtonText, true); 
    dialogRef.afterClosed().subscribe(result => {
      if(result === 'yes'){
        currentMonthStatus ? this.updatePreviousMonth = true : this.updateNextMonth = true;
        this.apiCall();
      } else if(result === 'no'){
        this.apiCall();
      }
    });
  }
}
