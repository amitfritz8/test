import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateSnapshotComponent } from './create-snapshot.component';

xdescribe('CreateSnapshotComponent', () => {
  let component: CreateSnapshotComponent;
  let fixture: ComponentFixture<CreateSnapshotComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateSnapshotComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateSnapshotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
