import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RestService } from 'src/app/common/service/rest.service';
import { DataService } from 'src/app/common/service/data.service';
import { DateUtility } from 'src/app/common/utility/date-utility';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PortfolioService } from 'src/app/portfolio/portfolio-details/portfolio.service';
import { URL_PREFIX } from 'src/app/common/constants/urlprefix';
@Component({
  selector: 'app-create-snapshot',
  templateUrl: './create-snapshot.component.html',
  styleUrls: ['./create-snapshot.component.scss']
})
export class CreateSnapshotComponent  {

  snapshotFormGroup: FormGroup;

  constructor(public dialogRef: MatDialogRef<CreateSnapshotComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private fb: FormBuilder,
    private router: Router, private restService: RestService,
    private dataService: DataService, public dialog: MatDialog,private dateUtility: DateUtility,private ps: PortfolioService) {

    this.snapshotFormGroup = this.fb.group({
      scenarioTo: this.fb.control("",Validators.required),
      scenarioFrom: this.fb.control("", Validators.required)
    });
  }

  goBack() {
    this.dialogRef.close('no');
  }

  copySnapshot() {
    if (this.data.copyToCallback) {
      this.data.copyToCallback(this.snapshotFormGroup.value, this.dialogRef);
      this.dialogRef.close();
    }
  }
  dateFormat() {
    const date = new Date();
    return this.dateUtility.datetoString(date);
  }
  loadCopyTo(item)
  {
  this.restService.get(URL_PREFIX.PORTFOLIO + '/data/copy/copySnapshotToScenarios/'+item).subscribe(data => {
      this.data.copyTo = data;
  });
  }
}
