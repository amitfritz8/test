import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AugNonPcftRangeComponent } from './aug-non-pcft-range.component';

xdescribe('AugNonPcftRangeComponent', () => {
  let component: AugNonPcftRangeComponent;
  let fixture: ComponentFixture<AugNonPcftRangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AugNonPcftRangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AugNonPcftRangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
