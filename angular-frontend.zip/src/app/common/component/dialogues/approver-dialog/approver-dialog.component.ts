import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import * as _ from "lodash";

@Component({
  selector: 'app-approver-dialog',
  templateUrl: './approver-dialog.component.html',
  styleUrls: ['./approver-dialog.component.scss']
})
export class ApproverDialogComponent implements OnInit {
  approverFormGroup: FormGroup;
  files: any = [];
  fileValid: boolean = false;
  validFileExtensions = ['.xlsx'];

  constructor(public dialogRef: MatDialogRef<ApproverDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private fb: FormBuilder, public dialog: MatDialog,) {

    this.approverFormGroup = this.fb.group({
      approvalDate: this.fb.control("", Validators.required),
      scenarioTo: this.fb.control("", Validators.required)
    });
  }

  ngOnInit() {}

  uploadFile(event) {
    this.fileValid = false;
    _.forEach(event, (file) => {
      if (this.validate(file.name)) {
        //for (let index = 0; index < event.length; index++) {
          const element = file;
          this.files.push(element);
          // this.dialogRef.updateSize('62%', '60%');
        //}
      }
    })
  }

  removeFile(idx){
    if(this.files.length >= idx){
      this.files.splice(idx, 1);
    }
  }

  validate(fileName) {
    let sFileName = fileName;
    if (sFileName.length > 0) {
      this.fileValid = false;
      for (let j = 0; j < this.validFileExtensions.length; j++) {
        const sCurExtension = this.validFileExtensions[j];
        if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() === sCurExtension.toLowerCase()) {
          this.fileValid = true;
          break;
        }
        this.checkFileValid();
      }
      return true;
    }
    return false;
  }

  checkFileValid() {
    if (!this.fileValid) {
      return false;
    } else {
      return;
    }
  }

  goBack() {
    this.dialogRef.close('no');
  }

  copyScenario() {
    if (this.data.callback) {
      let obj = this.approverFormGroup.value;
      obj.file = this.files
      this.data.callback(obj, this.dialogRef);
      this.dialogRef.close();
    }
  }
}
