import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PortfolioDialogComponent } from './portfolio-dialog.component';
import { DebugElement } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from 'src/app/material.module';
import { BrowserModule, By } from '@angular/platform-browser';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReactiveFormsModule, Validators, FormBuilder } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';

xdescribe('PortfolioDialogComponent', () => {
  let component: PortfolioDialogComponent;
  let fixture: ComponentFixture<PortfolioDialogComponent>;
  let de: DebugElement;
  let el: HTMLElement;
  const formBuilder: FormBuilder = new FormBuilder();
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PortfolioDialogComponent ],
      schemas: [NO_ERRORS_SCHEMA],
      imports:[
        ReactiveFormsModule
      ],
      providers: [
          { provide: MatDialogRef, useClass: MockMatDialogRef },
          { provide: MAT_DIALOG_DATA, useClass: MockMAT_DIALOG_DATA }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PortfolioDialogComponent);
    component = fixture.componentInstance;
    component.portfolioform = formBuilder.group({

      portfolioName: ['test ', [Validators.required, Validators.maxLength(100)]],
      initiationYear: ['121', [Validators.required]],
      workType: ['I',],
      primaryPlatformName: ['test', [Validators.required]],
      workStreamName: ['test', [Validators.required, Validators.maxLength(100)]],
      country: ['test', [Validators.required]],
      subWorkStreamName: ['test', [Validators.required, Validators.maxLength(100)]],
      deliveryPlatformUnit: ['test', [Validators.required]]

    })
   // component.disabled = false;
    //component.ngOnInit();
    //fixture.detectChanges();
    //fixture.detectChanges();
    //de = fixture.debugElement.query(By.css('.mainDiv'));
    //el = de.nativeElement;
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
  // it('should call for PlatformSelected', (done: DoneFn) => {
  //   spyOn(component, 'PlatformSelected').and.callThrough();
  //   component.PlatformSelected('test');
  //   expect(component.PlatformSelected).toHaveBeenCalled();
  //   done();
  // });
});
class MockMatDialogRef {
  updateSize(a, b) {
      return a * b;
  }
  close(test) {
      return null;
  }
}
class MockMAT_DIALOG_DATA {

}
