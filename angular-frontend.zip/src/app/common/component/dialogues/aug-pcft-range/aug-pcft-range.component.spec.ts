import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AugPcftRangeComponent } from './aug-pcft-range.component';

xdescribe('AugPcftRangeComponent', () => {
  let component: AugPcftRangeComponent;
  let fixture: ComponentFixture<AugPcftRangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AugPcftRangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AugPcftRangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
