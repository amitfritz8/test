import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NonPcftRangeComponent } from './non-pcft-range.component';

xdescribe('NonPcftRangeComponent', () => {
  let component: NonPcftRangeComponent;
  let fixture: ComponentFixture<NonPcftRangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NonPcftRangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NonPcftRangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
