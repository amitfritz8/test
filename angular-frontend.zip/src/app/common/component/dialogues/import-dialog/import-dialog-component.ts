import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DataService } from 'src/app/common/service/data.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonDialogComponent } from 'src/app/common/component/dialogues/common-dialog/common-dialog-component';
import { RestService } from 'src/app/common/service/rest.service';
import * as _ from 'lodash';
import { CommonService } from 'src/app/common/service/common.service';

@Component({
  selector: 'import-dialog',
  templateUrl: './import-dialog-component.html',
  styleUrls: ['./import-dialog-component.scss'],
})
export class ImportDialogComponent implements OnInit {
  body = '';
  header = '';
  selectedDate: string;
  dates: string[] = [];
  techUnits: string[] = [];
  countries: string[] = [];
  techUnit = Array();
  country = Array();
  months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  validFileExtensionsForPeople = ['.xlsx'];
  validFileExtensionsForPccode = ['.csv'];
  validFileExtensionsText : string = '';
  invalidFilesText: string = '';
  fileValid = false;
  files: any = [];
  uploadResult: any = [];
  isErrorExists = false;
  showTechUnits = false;
  showAsOfDate = false;
  showCountries = false;
  showRptPeriod = false;
  refType = '';
  asODateSelected = null;
  userId = '';

  importFormGroup: FormGroup;

  @ViewChild('attachments') attachment: any;

  constructor(private http: HttpClient, public dialogRef: MatDialogRef<ImportDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private fb: FormBuilder, private dataService: DataService, public dialog: MatDialog, 
    private restService: RestService, private commonService: CommonService) {  
    }

  ngOnInit() {
    this.handleReportingPeriod();
    // this.techUnits = JSON.parse(sessionStorage.getItem('selectedLobts'));
    // this.countries = JSON.parse(sessionStorage.getItem('locations'));
    this.header = this.data.header;
    this.body = this.data.body;
    this.refType = this.data.refType;
    this.userId = localStorage.getItem('userOneBankId');
    if (this.refType !== 'PEOPLE') {
      this.validFileExtensionsText = this.populateFileExtensionText(this.validFileExtensionsForPccode);
      this.showTechUnits = false;
      this.showAsOfDate = true;
      this.showRptPeriod = false;
      this.showCountries = false;
    } else {
      this.restService.get('/people/data/dataSummary/dataValues/Country').subscribe(data => {
        data.forEach(d => {
          this.countries.push(d.value);
        });
      });
      this.restService.get('/people/data/platforms/techUnits/all').subscribe(data => {
        this.techUnits = data;
        const loggedInUserTechUnitName = JSON.parse(sessionStorage.getItem('loggedInUserTechUnit'));
        if (this.techUnits.includes((loggedInUserTechUnitName === undefined) ? 'NonTech' : loggedInUserTechUnitName)) {
          if (sessionStorage.getItem('loggedInUserTechUnit') && sessionStorage.getItem('loggedInUserTechUnit') === 'undefined') {
            this.techUnit.push('NonTech');
          } else {
            this.techUnit.push(JSON.parse(sessionStorage.getItem('loggedInUserTechUnit')));
          }
        }
      });
      this.validFileExtensionsText = this.populateFileExtensionText(this.validFileExtensionsForPeople);
      this.showTechUnits = true;
      this.showAsOfDate = false;
      this.showRptPeriod = true;
      this.showCountries = true;
    }

    this.importFormGroup = this.fb.group({
      reportingPeriodControl: this.fb.control("", this.showRptPeriod ? Validators.required : []),
      datePickerControl: this.fb.control("", this.showAsOfDate ? Validators.required : []),
      countryDropdownControl: this.fb.control("", this.showCountries ? Validators.required : []),
      techUnitDropdownControl: this.fb.control("", this.showTechUnits ? Validators.required : []),
    });
  }

  populateFileExtensionText(extensions:string[]) : string {
    let validExtensions : string = '';
    for(let i=0; i<extensions.length; i++){
      validExtensions += '('+extensions[i]+')';
      validExtensions += (i != extensions.length-1) ? ', ' : '';
    }
    return validExtensions;
  }

  handleReportingPeriod() {
    const currentMonth=new Date().getMonth() -1;
    const currentYear = new Date().getFullYear();
    const previousYear = (currentYear - 1);

    this.dates = [];
      if(currentMonth==-1){
      this.dates.push(previousYear + ' ' + this.months[10]);
      this.dates.push(previousYear + ' ' + this.months[11]);
      }
      else if(currentMonth==0){
        this.dates.push(previousYear + ' ' + this.months[11]);
        this.dates.push(currentYear + ' ' + this.months[0]);
      }
      else {
        for (var i = currentMonth; i >= currentMonth - 1; i--) {
          this.dates.push(currentYear + ' ' + this.months[i]);
        }
      }


/*    if (currentYear != lastOptionYear) {
      //adding current year & month
      // when current month is not Jan
      if (currentMonth != -1) {
        for (var i = currentMonth; i >= 0; i--) {
          this.dates.push(currentYear + ' ' + this.months[i]);
        }
      }
      //adding last years options till august 2019.
      if (previousYear != lastOptionYear) { // previous year > 2019
        for (var year = previousYear; year >= lastOptionYear; year--) {
          if (year != lastOptionYear) { // previous year > 2019
            for (var i = 11; i >= 0; i--) {
              this.dates.push(year + ' ' + this.months[i]);
            }
          } else { // previous year = 2019
            for (var i = 11; i >= lastOptionMonth; i--) {
              this.dates.push(year + ' ' + this.months[i]);
            }
          }
        }
      } else if (previousYear == lastOptionYear) { // previous Year = 2019
        for (var i = 11; i >= lastOptionMonth; i--) {
          this.dates.push(previousYear + ' ' + this.months[i]);
        }
      }
      this.selectedDate = this.dates[0];
    }
    // adding dates when we are in 2019.
    else if (currentYear == lastOptionYear) {
      for (var i = currentMonth; i >= currentMonth-1; i--) {
        this.selectedDate = currentYear + ' ' + this.months[currentMonth];
        this.dates.push(currentYear + ' ' + this.months[i]);
      }
    }*/

  }

  scrollTo(el: Element): void {
    if(el) {
     el.scrollIntoView({ behavior: 'smooth' });
    }
  }
  scrollToError(): void {
    const firstElementWithError = _.find(document.querySelectorAll('.ng-invalid'), function(item){
      return item.tagName.toLowerCase() !== 'form';
    });

    this.scrollTo(firstElementWithError);
  }

  validateForms() : boolean {
    let controls = this.importFormGroup.controls;
    let isValid = true;
    for (const name in controls) {
      if (controls[name].invalid) {
        controls[name].markAsTouched();
        isValid = false;
      }
    }
    return isValid;
  }

  onYesClick(): void {
    if(!this.validateForms()){
      this.scrollToError();
      return;
    }

    if(this.isEmptyFile()) {
      this.showErrorDialog('No File Uploaded', 'Please upload a file to import.');
      return;
    }

    let month: string = '0' + (this.months.indexOf(this.selectedDate.substring(5, this.selectedDate.length)) + 1);
    let year: string = this.selectedDate.substring(0, 4);
    const reportingPeriod = year + '' + month.slice(-2);
    let test: FormData = new FormData();
    test.append('file', this.files[0]);
    let unit = '';
    let con = '';
    let url = '';
    const options = {headers: new HttpHeaders({'Authorization': 'Bearer ' + localStorage.getItem('access_token')})};
    if (this.refType === 'PEOPLE') {
      test.append('reportPeriod', reportingPeriod);
      this.techUnit.forEach(tech => {
        unit === '' ? unit = tech : unit = tech + ',' + unit;
      });
      this.country.forEach(countryy => {
        con === '' ? con = countryy : con = countryy + ',' + con;
      })
      this.http.post(`/people/upload/staff?techUnit=${unit}&country=${con}&loggedInUserBankId=${localStorage.getItem('userOneBankId')}`, test, options).subscribe(res => {
      });
      this.dialogRef.close({errorFlag: '0'});
    } else {
      if (this.refType === 'GLAccountTree') {
        url = `/people/data/glaccounttree/upload?asOfDate=${this.asODateSelected}&userId=${this.userId}`;
      } else if (this.refType === 'itc_rate') {
        url = `/people/data/ref-non-ref-uploader/itcrate/upload?asOfDate=${this.asODateSelected}&userId=${this.userId}`;
      } else if (this.refType === 'xref_app_code_master') {
        url = `/people/data/ref-non-ref-uploader/appcodemaster/upload?asOfDate=${this.asODateSelected}&userId=${this.userId}`;
      } else if (this.refType === 'exchange_rates') {
        url = `/people/data/ref-non-ref-uploader/exchangerate/upload?asOfDate=${this.asODateSelected}&userId=${this.userId}`;
      } else if (this.refType === 'map_glsetid_to_hypleid') {
        url = `/people/data/ref-non-ref-uploader/mapper-psgl-setid-to-hyperion-lecode/upload?asOfDate=${this.asODateSelected}&userId=${this.userId}`;
      } else {
        url = `/people/data/pcCodes/upload?asOfDate=${this.asODateSelected}`;
      }
      this.http.post(url, test, options).subscribe(res => {
          this.uploadResult = res;
          if (this.uploadResult.errorFlag === '1') {
            this.showErrorDialog('Import Failed', res['message']);
            this.dialogRef.close('no');
          } else if (this.uploadResult.errorFlag === '0') {
            this.showSuccessDialog('Successfully Imported!', 'Your data import has been submitted.\nYou will be notified via email on the status.');
            this.dialogRef.close(this.uploadResult);
          }
        },
        error => {
          let message = error.statusText;
          if(error.error){
            message += error.error.message;
          } else {
            message = 'Data has failed to import.';
          }
          this.showErrorDialog('Import Failed', message);
          this.dialogRef.close('no');
        });
    }
  }

  onNoClick(): void {
    this.dialogRef.close('no');
  }

  uploadFile(fileList) {
    let allFilesValid = true;
    this.invalidFilesText = "";
    _.forEach(fileList, (file) => {
      if (this.validate(file.name)) {
          const element = file;
          this.files.push(element);
      } else {
        this.invalidFilesText += '('+file.name+')' + ' ';
        allFilesValid = false;
      }
    })
    this.attachment.nativeElement.value = ''; // reset file native element, for re-import
    if(!allFilesValid){
      this.showErrorDialog('Upload Unsuccessful', 'Error uploading files: \n' + this.invalidFilesText + '\nPlease use a valid file format ' + this.validFileExtensionsText + ' to import the data.');
    }
  }

  isEmptyFile(){
    return this.files.length == 0;
  }

  removeFile(idx){
    if(this.files.length >= idx){
      this.files.splice(idx, 1);
    }
  }

  validate(fileName) {
    let sFileName = fileName;
    if (sFileName.length > 0) {
      this.fileValid = false;
      let validFileExtensions: string[] = this.refType === 'PEOPLE' ? this.validFileExtensionsForPeople : this.validFileExtensionsForPccode;
      for (let j = 0; j < validFileExtensions.length; j++) {
        const sCurExtension = validFileExtensions[j];
        if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() === sCurExtension.toLowerCase()) {
          this.fileValid = true;
          break;
        }
      }
      return this.fileValid;
    }
    return false;
  }

  showSuccessDialog(title: string, message: string){
    this.dialog.open(CommonDialogComponent, {
      data: {
      type: 'success',
      contentTitle: title,
      content: message,
      confirmTxt: "Ok"
      }
    });
  }

  showErrorDialog(title: string, message: string){
    this.dialog.open(CommonDialogComponent, {
      data: {
      type: 'alert',
      contentTitle: title,
      content: message,
      confirmTxt: "Ok"
      }
    });
  }

  addEvent(event: any) {
    this.asODateSelected = event.value;
  }
}
