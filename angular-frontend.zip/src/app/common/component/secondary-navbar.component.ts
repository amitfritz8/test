import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { CommonService } from 'src/app/common/service/common.service';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { Subscription } from 'rxjs';
import { WORK_HIERARCHY_CONST } from 'src/constants/workHierarchy';
import { RestService } from 'src/app/common/service/rest.service';
import { URL_PREFIX } from 'src/constants/urlsprefix';
import { DataService } from 'src/app/common/service/data.service';

@Component({
    selector: 'app-secondary-navbar',
    templateUrl: '../views/secondary-navbar.component.html',
    styleUrls: ['../css/header.component.scss']
})
export class SecondaryNavbarComponent implements OnInit, OnDestroy {

    _hideNav: boolean;

    @Input()
    set hideNav(hideNav) {
        this._hideNav = hideNav;
        setTimeout(() => {
            let h = document.getElementById('header').offsetHeight;
            if (document.getElementById('secondary-header')) {
                document.getElementById('secondary-header').style.height = `${(h).toString()}px`;
            }
        }, 0)
    }

    baseInfo: any = {
        display: false,
        nav_bk_url: '',
        nav_bk_lbl: '',
        title: '',
        currentStream: '',
        avatar: '',
        navItems: []
    };

    _data: any;
    resizeListener;
    secObserver: Subscription;
    subscription: Subscription;

    expandedMenu: Array<string> = [];
    currentStream: string;

    constructor(private commonService: CommonService, private restService: RestService, private dataService: DataService, private router: Router) {
        this._data = Object.assign({}, this.baseInfo);
    }

    ngOnInit() {
        this.secObserver = this.commonService.secNavEvent.subscribe(data => {
            this._data = _.merge(Object.assign({}, this.baseInfo), data);
            if (this._data.display) {
                this.getData();
            }
            this.resize();
        })

        this.commonService.captureMessage.subscribe(data => {
            this.resize();
        });

        this.subscription = this.dataService.itemChange.subscribe(msg => {
            if (msg === WORK_HIERARCHY_CONST.PORTFOLIO) {
                this.getData();
                this.currentStream = "";
            }
            if (msg === WORK_HIERARCHY_CONST.WORKSTREAM) {
                this.getData();
                if (this.expandedMenu.indexOf(sessionStorage.getItem('workstreamID')) < 0) {
                    this.expandedMenu.push(sessionStorage.getItem('workstreamID'));
                }
                this.currentStream = sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID) + sessionStorage.getItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME);
            }
            if (msg === WORK_HIERARCHY_CONST.SUB_WORKSTREAM) {
                this.getData();
                if (this.expandedMenu.indexOf(sessionStorage.getItem('workstreamID')) < 0) {
                    this.expandedMenu.push(sessionStorage.getItem('workstreamID'));
                }
                this.currentStream = sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID) + sessionStorage.getItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME) ;
            }
            if (msg === 'showSideNav') {
                // this.showSideNave = true;
            }
            if (msg === 'hideSideNav') {
                // this.showSideNave = false;
            }
        });

        if (WORK_HIERARCHY_CONST.WORKSTREAM != this.dataService.getListingView()
            && WORK_HIERARCHY_CONST.SUB_WORKSTREAM != this.dataService.getListingView()) {
            if (this._data.display) {
                this.router.navigateByUrl('home/portfolio/createPortfolio/showPortfolio');
                this.dataService.setListingView("");
            }
        }
        if (WORK_HIERARCHY_CONST.SUB_WORKSTREAM === this.dataService.getListingView()) {
            // this.showSubMenuAll = true;
        }
    }

    getData() {
        switch (this.dataService.getListingView()) {
            case WORK_HIERARCHY_CONST.SUB_WORKSTREAM:
                this._data.nav_bk_lbl = "Subworkstream Listing";
                this._data.nav_bk_url = "portfolio/subworkstream";
                break;
            case WORK_HIERARCHY_CONST.WORKSTREAM:
                this._data.nav_bk_lbl = "Workstream Listing";
                this._data.nav_bk_url = "portfolio/workstream";
                break;
            default:
                this._data.nav_bk_lbl = "Portfolio Listing";
                this._data.nav_bk_url = "portfolio/portfoliolisting";
        }
        this._data.title = sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_NAME);
        this.restService.get(URL_PREFIX.PORTFOLIO + '/data/workHierarchy/portfolio/' + sessionStorage.getItem(WORK_HIERARCHY_CONST.PORTFOLIO_ID)).subscribe(data => {
            this._data.navItems = data as NavItem[];
        });
    }

    expandMenu(data) {
        const idx: number = this.expandedMenu.indexOf(data);
        (idx >= 0) ? this.expandedMenu.splice(idx, 1) : this.expandedMenu.push(data);
    }

    navigateToWorkstream(data) {
        sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID, data.displayID);
        sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_NAME, data.displayName);
        this.expandedMenu.push(data.displayID);
        this.dataService.sendMessageItemChange(WORK_HIERARCHY_CONST.WORKSTREAM);
        this.router.navigateByUrl(`home/portfolio/createPortfolio/workstream/${data.displayID}`);
    }

    navigateToSubworkstream(item, workStreamId) {
        sessionStorage.setItem(WORK_HIERARCHY_CONST.WORKSTREAM_ID, workStreamId.displayID);
        sessionStorage.setItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_ID, item.displayID);
        sessionStorage.setItem(WORK_HIERARCHY_CONST.SUB_WORKSTREAM_NAME, item.displayName);
        this.dataService.sendMessageItemChange(WORK_HIERARCHY_CONST.SUB_WORKSTREAM);
        this.router.navigateByUrl(`home/portfolio/createPortfolio/subworkstream/${item.displayID}`);
    }

    navtoportfolio() {
        this.currentStream = '';
        this.router.navigateByUrl('/home/portfolio/createPortfolio/showPortfolio');
    }

    resize() {
        if (this._data.display) {
            setTimeout(() => {
                let h = document.getElementById('header').offsetHeight;
                if (document.getElementById('secondary-header')) {
                    document.getElementById('secondary-header').style.height = `${(h).toString()}px`;

                    if (this.resizeListener !== null) {
                        this.resizeListener = null;
                    }

                    this.resizeListener = window.addEventListener('resize', () => {
                        let h = document.getElementById('header').offsetHeight;
                        if (document.getElementById('secondary-header')) {
                            document.getElementById('secondary-header').style.height = `${(h).toString()}px`;
                        }
                    })
                }
            }, 0)

        }
    }

    ngOnDestroy() {
        // release consumed resource.
        this._data.display = false;
        this.secObserver.unsubscribe();
        this.subscription.unsubscribe();
        this.resizeListener = null;
    }

}

class NavItem {
    displayName: string;
    displayID: string;
    isShow?: string;
    route?: string;
    children?: NavItem[];
}