import { RouterModule, Routes } from "@angular/router";
import { NgModule } from "@angular/core";
import { CommonComponent } from "../component/appcommon.component";

const routes: Routes = [
  {
    path: "",
    component: CommonComponent,
    children: [
      {
        path: "workforce",
        loadChildren:  () => import('src/app/workforce-management/workforce-routing.module').then(m => m.WorkforceRoutingModule)
      },
      {
        path: "settings",
        loadChildren:  () => import('src/app/settings/settings.module').then(m => m.SettingsModule)
      },
      {
        path: "admin",
        loadChildren:  () => import('src/app/admin/admin-routing.module').then(m => m.AdminRoutingModule)
      },
      {
        path: "portfolio",
        loadChildren:  () => import('src/app/portfolio/portfolio-routing.module').then(m => m.PortfolioRoutingModule)
      },
      {
        path: "reports",
        loadChildren:  () => import('src/app/workforce-management/report/report-routing.module').then(m => m.ReportModule)
      },
      {
        path: "",
        redirectTo: "workforce"
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CommonRouterModule { }
