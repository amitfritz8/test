import {
  ElementRef,
  AfterViewInit,
  Directive,
  Host,
  Optional,
  Renderer2,
  Self,
  ViewContainerRef,
  Input,
  ChangeDetectorRef,
  DoCheck
} from "@angular/core";
import { MatPaginator } from "@angular/material/paginator";

@Directive({
  selector: "[gene-paginator]"
})
export class GenePaginatorDirective implements DoCheck, AfterViewInit {
  private _currentPage = 0;
  private _pageGapTxt = "...";
  private _rangeStart;
  private _rangeEnd;
  private size = 0;
  private _buttons = [];

  @Input()
  get showTotalPages(): number { return this._showTotalPages; }
  set showTotalPages(value: number) {
    this._showTotalPages = value % 2 == 0 ? value + 1 : value;
  }
  private _showTotalPages = 3;

  constructor(
    @Host() @Self() @Optional() private readonly matPag: MatPaginator,
    private vr: ViewContainerRef,
    private ren: Renderer2
  ) {
    //Sub to rerender buttons when next page and last page is used
    this.matPag.page.subscribe((v) => {
      this._currentPage = v.pageIndex;
      this.matPag.pageIndex = v.pageIndex;
      this.initPageRange();
    });
  }

  private buildPageNumbers(range) {
    const actionContainer = this.vr.element.nativeElement.querySelector(
      "div.mat-paginator-range-actions"
    );
    const nextPageNode = this.vr.element.nativeElement.querySelector(
      "button.mat-paginator-navigation-next"
    );
    const prevButtonCount = this._buttons.length;

    // remove buttons before creating new ones
    if (this._buttons.length > 0) {
      this._buttons.forEach(button => {
        this.ren.removeChild(actionContainer, button);
      });
      //Empty state array
      this._buttons.length = 0;
    }

    //initialize next page and last page buttons
    if (this._buttons.length == 0) {
      let nodeArray = this.vr.element.nativeElement.childNodes[0].childNodes[0]
        .childNodes[2] ? this.vr.element.nativeElement.childNodes[0].childNodes[0]
          .childNodes[2].childNodes : [];
      setTimeout(() => {
        for (let i = 0; i < nodeArray.length; i++) {
          if (nodeArray[i].nodeName === "BUTTON") {

            this.ren.setStyle(
              nodeArray[i],
              "min-width",
              "70px"
            );
            this.ren.setStyle(
              nodeArray[i],
              "margin-bottom",
              "1px"
            );
            if (this.matPag.getNumberOfPages() > 1) {
              nodeArray[i].classList.remove('invisible');
              if (nodeArray[i].disabled) {
                nodeArray[i].childNodes[0].innerHTML = `<button mat-button class="g-btn g-btn-s g-btn-pg" disabled style="padding: 0.3rem 1rem">
                ${nodeArray[i].classList.contains('mat-paginator-navigation-previous') ? 'Prev' : 'Next'}
                </button>`;
              } else {
                nodeArray[i].childNodes[0].innerHTML = `<button mat-button class="g-btn g-btn-s g-btn-pg" style="padding: 0.3rem 1rem">
                    ${nodeArray[i].classList.contains('mat-paginator-navigation-previous') ? 'Prev' : 'Next'}
                    </button>`;
              }
            } else {
              nodeArray[i].classList.add('invisible');
            }
          }
        }
      });
    }

    let endHelis = false;
    let startHelis = false;
    if (this.matPag.getNumberOfPages() > 1) {
      // for start
      this.ren.insertBefore(
        actionContainer,
        this.createButton(0, this.matPag.pageIndex),
        nextPageNode
      );

      for (let i = 0; i < range.length; i = i + 1) {
        if (range[i] == 'starthelip') {
          this.ren.insertBefore(
            actionContainer,
            this.createButton(this._pageGapTxt, this.matPag.pageIndex, true),
            nextPageNode
          );
        } else if (range[i] == 'endhelip') {
          this.ren.insertBefore(
            actionContainer,
            this.createButton(this._pageGapTxt, this.matPag.pageIndex),
            nextPageNode
          );
        } else {
          this.ren.insertBefore(
            actionContainer,
            this.createButton(range[i], this.matPag.pageIndex),
            nextPageNode
          );
        }
      }

      // for end
      this.ren.insertBefore(
        actionContainer,
        this.createButton(this.matPag.getNumberOfPages() - 1, this.matPag.pageIndex),
        nextPageNode
      );
    }
  }

  private createButton(i: any, pageIndex: number, isStrtHelis: boolean = false): any {
    const linkBtn = this.ren.createElement("mat-button");
    this.ren.addClass(linkBtn, "g-btn");
    this.ren.addClass(linkBtn, "g-btn-s");
    this.ren.addClass(linkBtn, this._currentPage == i ? 'g-btn-primary' : 'g-btn-pg')
    this.ren.setStyle(linkBtn, "margin", "0 0.25rem");

    const pagingTxt = isNaN(i) ? this._pageGapTxt : +(i + 1);
    const text = this.ren.createText(pagingTxt + "");

    this.ren.addClass(linkBtn, "mat-custom-page");
    switch (i) {
      case pageIndex:
        this.ren.setAttribute(linkBtn, "disabled", "disabled");
        break;
      case this._pageGapTxt:
        this.ren.listen(linkBtn, "click", () => {
          this.switchPage(isStrtHelis ? (this._currentPage - this._showTotalPages) : (this._currentPage + this._showTotalPages));
        });
        break;
      default:
        this.ren.listen(linkBtn, "click", () => {
          this.switchPage(i);
        });
        break;
    }

    this.ren.appendChild(linkBtn, text);
    //Add button to private array for state
    this._buttons.push(linkBtn);
    return linkBtn;
  }

  private initPageRange(): void {
    this.size = this.matPag.getNumberOfPages();
    this._rangeStart = this._currentPage - this._showTotalPages / 2;
    this._rangeEnd = this._currentPage + this._showTotalPages / 2;

    let toShow = [];
    let startIdx = this._currentPage != 0 ? (this._currentPage - 1) : this._currentPage;
    let endIdx = (startIdx + 3) > this.size ? this.size : (startIdx + 3);

    if (this._currentPage >= this._showTotalPages) {
      toShow.push('starthelip');
    }

    for (let i = startIdx; i < endIdx; i++) {
      (i != 0 && i != (this.matPag.getNumberOfPages() - 1)) ? toShow.push(i) : '';
    }

    if ((this._currentPage + this._showTotalPages) <= (this.matPag.getNumberOfPages() - 1)) {
      toShow.push('endhelip');
    }

    this.buildPageNumbers(toShow);
  }

  private switchPage(i: number): void {
    this.matPag.page.next({
      pageIndex: i,
      pageSize: this.matPag.pageSize,
      length: this.matPag.length
    });
  }

  ngDoCheck() {
    if (this.size != this.matPag.getNumberOfPages()) {
      this._currentPage = 0;
      this.initPageRange();
    }
  }

  ngAfterViewInit() {
    this.initPageRange();
  }
}
