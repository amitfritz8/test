import { Injectable } from "@angular/core";
import {
    HttpInterceptor,
    HttpHandler,
    HttpRequest,
    HttpEvent,
    HttpResponse,
    HttpErrorResponse
} from "@angular/common/http";
import { tap, finalize } from "rxjs/operators";
import { Observable } from "rxjs";
import { Router } from '@angular/router';

import { CommonService } from 'src/app/common/service/common.service';

@Injectable()
export class AppInterceptor implements HttpInterceptor {
    // when we make any HTTP request, the auth token will be attached automatically using interceptor
    public pendingRequests = 0;

    constructor(private router: Router, private commonService: CommonService) { }

    intercept(
        req: HttpRequest<any>,
        next: HttpHandler // to handle other interceptor
    ): Observable<HttpEvent<any>> {
        if(!req.url.includes("/people/upload/")){
            this.showLoading();
        }
    
        if (req.url.indexOf("authenticate") < 0) {
            if(!req.url.includes("/people/upload/")){
                ++this.pendingRequests;
            }
            let duplicate;

            duplicate = req.clone({
                setHeaders: {
                    "Authorization": `Bearer ${localStorage.getItem("access_token")}`,
                    // "Content-Type": "application/json"
                }
            });
            return next.handle(duplicate).pipe(tap((event: HttpEvent<any>) => { }, (err: any) => {
                if (err instanceof HttpErrorResponse) {
                    if (err.status === 400) {
                        this.commonService.showSnackBar({
                            type: 'alert',
                            message: err.error.message ? err.statusText + ': ' + err.error.path + ' \n' + err.error.message : err.error,
                            duration: 3000 
                        })
                    }else if (err.status === 403) {
                        localStorage.clear();
                        sessionStorage.clear();
                        this.router.navigateByUrl("/login");
                    }
                }
            }), finalize(() => {
                this.hideLoading();
            }));
        } else {
            return next.handle(req).pipe(finalize(() => {
                this.hideLoading();
            }));
        }
    };

    showLoading() {
        this.pendingRequests == 0 ? this.commonService.loaderEvent.emit(true) : '';
    }

    hideLoading() {
        this.pendingRequests = this.pendingRequests != 0 ? --this.pendingRequests : this.pendingRequests;
        if (this.pendingRequests == 0) {
            this.commonService.loaderEvent.emit(false);
        }
    }
}
