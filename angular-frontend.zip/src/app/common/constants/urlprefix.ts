export const URL_PREFIX = {
    AUTH : '/auth',
    PORTFOLIO : '/portfolio',
    PEOPLE : '/people',
    REPORTS : '/gene-reports',
    MATOMOURL: 'https://matomo-dashboard-test.dev.apps.cs.sgp.dbs.com/',
    MATOMOID: 2
};
