export class SummaryData {
    createdBy: string;
    dateCreated: string;
    modifiedBy: string;
    dateModified: string;
    dataCode: string;
    dataName: string;
    dataDesc: string;
    status: string;
    goldenSource: string;
    interimSource: string;
    owner1Bankid: string;
    ownerDeptname: string;
    updateMethod: string;
    updateFreq: string;

    constructor(createdBy: string, dateCreated: string,modifiedBy: string, dateModified: string,dataCode: string,
        dataName: string,dataDesc: string,status: string,goldenSource: string,interimSource: string,
        owner1Bankid: string,ownerDeptname: string,updateMethod: string,updateFreq: string) {
            this.createdBy = createdBy;
            this.dataCode = dataCode;
            this.dateCreated = dateCreated;
            this.modifiedBy = modifiedBy;
            this.dateModified = dateModified;
            this.dataName = dataName;
            this.dataDesc = dataDesc;
            this.status = status;
            this.goldenSource = goldenSource;
            this.interimSource = interimSource;
            this.owner1Bankid = owner1Bankid;
            this.ownerDeptname = ownerDeptname;
            this.updateMethod = updateMethod;
            this.updateFreq = updateFreq;

    }
}
export class Attributes {
    attrNo: string;
    attr: string;
}
