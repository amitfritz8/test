package com.dbs.genesis.portfolio.service;


import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.*;
import com.dbs.genesis.portfolio.resources.SubWorkStreamManagerResource;
import com.dbs.genesis.portfolio.resources.WorkStreamDataSource;
import com.dbs.genesis.portfolio.resources.WorkStreamManagersResource;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.mockito.Mockito.when;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class WorkStreamServiceImplTest {


    @Mock
    private WorkStreamRepo portFolioWorkStreamRepo;

    @Mock
    private PortfolioService portfolioService;

    @Mock
    private SequenceGeneratorRepo portFolioSequenceGeneratorRepo;

    @Mock
    private WorkHierarchyRepo workHierarchyRepo;


    @InjectMocks
    private WorkStreamService workStreamServiceImpl;

    @Mock
    private WorkStreamManagersRepo workStreamManagersRepo;

    @Mock
    private SubWorkStreamManagersRepo subWorkStreamManagersRepo;

    @Mock
    private PortfolioRepository portfolioRepositoryImpl;


    List<WorkStreamEntity> portFolioWorkStreamEntityList = null;
    List<SequenceGeneratorEntity> listSequenceGenerator = null;
    WorkStreamEntity workStreamEntity = null;
    SequenceGeneratorEntity sequenceGeneratorEntity = null;
    WorkHierarchyEntity workHierarchyEntity = null;
    List<WorkHierarchyEntity> workHierarchyEntityList = new ArrayList<>();
    WorkStreamDataSource workStreamDataSource = null;

    List<WorkStreamManagersEntity> workStreamManagersEntityList = null;
    WorkStreamManagersEntity workStreamManagersEntity = null;
    WorkStreamManagersResource workStreamManagersResource = null;
    List<WorkStreamManagersResource> workStreamManagersResourceList = null;

    SubWorkStreamManagersEntity subWorkStreamManagersEntity = null;
    List<SubWorkStreamManagersEntity> subWorkStreamManagersEntityList = null;
    SubWorkStreamManagerResource subWorkStreamManagerResource = null;
    List<SubWorkStreamManagerResource> subWorkStreamManagerResourceList = null;

    String year = "20";
    String costType = "I";
    String platformIndex = "0_CE";
    String platformName = "CE Central Function";
    String country = "SG";
    String deliveryUnit = "0_CE - CE Central Function";
    String portfolioId = "P25-25007-E";
    String workStreamId = "P25DAH2-25007-E0007";
    String seqNoGenerator = "2";

    @Before
    public void setup() {

        portFolioWorkStreamEntityList = new ArrayList<>();
        workStreamEntity = new WorkStreamEntity();
        sequenceGeneratorEntity = new SequenceGeneratorEntity();
        workHierarchyEntity = new WorkHierarchyEntity();
        listSequenceGenerator = new ArrayList<>();

        workStreamManagersEntityList = new ArrayList<>();
        workStreamManagersEntity = new WorkStreamManagersEntity();
        workStreamManagersResource = new WorkStreamManagersResource();
        workStreamManagersResourceList = new ArrayList<>();

        subWorkStreamManagersEntity = new SubWorkStreamManagersEntity();
        subWorkStreamManagersEntityList = new ArrayList<>();
        subWorkStreamManagerResource = new SubWorkStreamManagerResource();
        subWorkStreamManagerResourceList = new ArrayList<>();



        workStreamEntity.setPortfolioId(portfolioId);
        workStreamEntity.setWorkStreamId(workStreamId);
        workStreamEntity.setWorkStreamName("New Work Stream");
        workStreamEntity.setCountry(country);

        portFolioWorkStreamEntityList.add(workStreamEntity);


        sequenceGeneratorEntity.setSeqSurrId(2);
        sequenceGeneratorEntity.setPortFolioIdType(PortfolioConstants.WORKSTREAMNAME);
        sequenceGeneratorEntity.setKey1(platformIndex);
        sequenceGeneratorEntity.setKey2(year);
        sequenceGeneratorEntity.setKey3(country);
        sequenceGeneratorEntity.setKey4(costType);
        sequenceGeneratorEntity.setKey5("");
        sequenceGeneratorEntity.setMaxCounter(1);
        sequenceGeneratorEntity.setGeneratedId("P24SG-24004-E0001");

        listSequenceGenerator.add(sequenceGeneratorEntity);

        workHierarchyEntity.setPortfolioId(portfolioId);
        workHierarchyEntity.setPortfolioName("New Portfolio");
        workHierarchyEntity.setWorkStreamName("New Work Stream");
        workHierarchyEntity.setWorkStreamId(workStreamId);


        workStreamManagersEntity.setDelegateInd("yes");
        workStreamManagersEntity.setOneBankId("manikandanc");
        workStreamManagersEntity.setStaffName("Manikandan C");
        workStreamManagersEntity.setEmailAddress("manikandanc@dbs.com");
        workStreamManagersEntity.setRole("SRE Engineer");
        workStreamManagersEntityList.add(workStreamManagersEntity);

        subWorkStreamManagersEntity.setDelegateInd("yes");
        subWorkStreamManagersEntity.setSubWorkStreamId("P24SG-24004-E0001-P19");
        subWorkStreamManagersEntity.setEmailAddress("manikandanc@dbs.com");
        subWorkStreamManagersEntity.setOneBankId("manikandanc");
        subWorkStreamManagersEntityList.add(subWorkStreamManagersEntity);

        subWorkStreamManagerResource.setDelegateInd("yes");
        subWorkStreamManagerResource.setPlatformIndex("19");
        subWorkStreamManagerResourceList.add(subWorkStreamManagerResource);


    }

    @Test
    public void when_generateWorkStreamId_Return_PortFolioWorkStreamEntity() {

        when(portFolioSequenceGeneratorRepo.save(sequenceGeneratorEntity)).thenReturn(sequenceGeneratorEntity);
        when(workHierarchyRepo.save(workHierarchyEntity)).thenReturn(workHierarchyEntity);
        when(portFolioWorkStreamRepo.save(workStreamEntity)).thenReturn(workStreamEntity);

    }

    @Test
    public void when_getWorkStreamEntityData(){

        when( portFolioWorkStreamRepo.findByOrderByPortfolioIdDesc()).thenReturn(portFolioWorkStreamEntityList);

        workStreamServiceImpl.getWorkStreamEntityData(portfolioId);
    }


    @Test
    public void when_getListOfWorkManagersData_return_ListOfMap() {
        try {

            Map<String,List<WorkStreamManagersResource>> workStreamManagersMap;
            Map<String, List<SubWorkStreamManagerResource>>  subWorkStreamMap ;
            List<Map> mapList = new ArrayList<>();

            when(workStreamManagersRepo.findByWorkStreamIdAndActiveInd(this.workStreamId,"true")).thenReturn(workStreamManagersEntityList);
            workStreamManagersMap = workStreamManagersResourceList.stream().collect(Collectors.groupingBy(WorkStreamManagersResource::getWorkStreamName));
            mapList.add(workStreamManagersMap);
            subWorkStreamMap = subWorkStreamManagerResourceList.stream().collect(Collectors.groupingBy(SubWorkStreamManagerResource::getSubWorkStreamName));
            mapList.add(subWorkStreamMap);


        }catch (Exception e ) {

        }
        workStreamServiceImpl.getListOfWorkManagersData(portfolioId);
    }

    @Test
    public void when_updateWorkStreamData_return_PortFolioWorkStreamEntity() {
        workHierarchyEntityList.add(workHierarchyEntity);
        when(workHierarchyRepo.findByWorkStreamId(this.workStreamId)).thenReturn(workHierarchyEntityList);
        workHierarchyEntity.setWorkStreamName("Test");
        when(workHierarchyRepo.save(workHierarchyEntity)).thenReturn(workHierarchyEntity);
        workStreamEntity.setPortfolioId(this.portfolioId);
        when(portFolioWorkStreamRepo.save(workStreamEntity)).thenReturn(workStreamEntity);
        //workStreamServiceImpl.updateWorkStreamData(workStreamDataSource);
    }
}
