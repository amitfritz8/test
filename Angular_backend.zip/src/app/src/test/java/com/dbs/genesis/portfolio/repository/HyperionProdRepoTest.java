package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.HyperionProductTree;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@DataJpaTest
public class HyperionProdRepoTest {

	@Autowired
	private HyperionProductRepository hyperionProductRepository;
		
	@Test
	public void test_findHyperionProductResource() {
		HyperionProductTree hyperionProductTree = new HyperionProductTree();
		hyperionProductTree.setL0Node("l4_node");
		hyperionProductTree.setL0Desc("l0Desc");
		hyperionProductRepository.save(hyperionProductTree);
		
		List<HyperionProductTree> hyperionProductTrees = hyperionProductRepository.findAll();
		assertNotNull(hyperionProductTrees);
		assertEquals(1, hyperionProductTrees.size());
		assertEquals(hyperionProductTree.getL0Node(), hyperionProductTrees.get(0).getL0Node());
		assertEquals(hyperionProductTree.getL0Desc(), hyperionProductTrees.get(0).getL0Desc());
	}
}
