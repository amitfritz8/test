package com.dbs.genesis.portfolio.service;


import com.dbs.genesis.portfolio.model.SequenceGeneratorEntity;
import com.dbs.genesis.portfolio.model.SubWorkStreamEntity;
import com.dbs.genesis.portfolio.model.WorkHierarchyEntity;
import com.dbs.genesis.portfolio.repository.SequenceGeneratorRepo;
import com.dbs.genesis.portfolio.repository.SubWorkStreamRepo;
import com.dbs.genesis.portfolio.repository.WorkHierarchyRepo;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class SubWorkStreamServiceImplTest {


    @Mock
    private SubWorkStreamRepo portFolioSubWorkStreamRepo;

    @Mock
    private PortfolioService portfolioService;

    @Mock
    private SequenceGeneratorRepo portFolioSequenceGeneratorRepo;

    @Mock
    private WorkHierarchyRepo workHierarchyRepo;


    @InjectMocks
    private WorkStreamService workStreamService;

    @InjectMocks
    private SubWorkStreamService subWorkStreamService;



    List<SubWorkStreamEntity> portFolioSubWorkStreamEntityList = null;
    List<SequenceGeneratorEntity> listSequenceGenerator = null;
    SubWorkStreamEntity subWorkStreamEntity = null;
    SequenceGeneratorEntity sequenceGeneratorEntity = null;
    WorkHierarchyEntity workHierarchyEntity = null;

    String year = "20";
    String costType = "I";
    String platformIndex = "0_CE";
    String platformName = "CE Central Function";
    String country = "SG";
    String deliveryUnit = "0_CE - CE Central Function";
    String portfolioId = "P25-25007-E";
    String workStreamId = "P25DAH2-25007-E0007";
    String seqNoGenerator = "2";

    @Before
    public void setup() {

        portFolioSubWorkStreamEntityList = new ArrayList<>();
        subWorkStreamEntity = new SubWorkStreamEntity();
        sequenceGeneratorEntity = new SequenceGeneratorEntity();
        workHierarchyEntity = new WorkHierarchyEntity();
        listSequenceGenerator = new ArrayList<>();

        //subWorkStreamEntity.setPortfolioId(portfolioId);
        subWorkStreamEntity.setWorkStreamId(workStreamId);
        //subWorkStreamEntity.setWorkStreamName("New Work Stream");
        subWorkStreamEntity.setCountry(country);

        portFolioSubWorkStreamEntityList.add(subWorkStreamEntity);


        sequenceGeneratorEntity.setSeqSurrId(2);
        sequenceGeneratorEntity.setPortFolioIdType(PortfolioConstants.SUBWORKSTREAMNAME);
        sequenceGeneratorEntity.setKey1(platformIndex);
        sequenceGeneratorEntity.setKey2(year);
        sequenceGeneratorEntity.setKey3(country);
        sequenceGeneratorEntity.setKey4(costType);
        sequenceGeneratorEntity.setKey5("");
        sequenceGeneratorEntity.setMaxCounter(1);
        sequenceGeneratorEntity.setGeneratedId("P24SG-24004-E0001");

        listSequenceGenerator.add(sequenceGeneratorEntity);

        workHierarchyEntity.setPortfolioId(portfolioId);
        workHierarchyEntity.setPortfolioName("New Portfolio");
        workHierarchyEntity.setWorkStreamName("New Work Stream");
        workHierarchyEntity.setWorkStreamId(workStreamId);
    }

    @Test
    public void when_generateWorkStreamId_Return_PortFolioWorkStreamEntity() {


        when(portFolioSequenceGeneratorRepo.save(sequenceGeneratorEntity)).thenReturn(sequenceGeneratorEntity);
        when(workHierarchyRepo.save(workHierarchyEntity)).thenReturn(workHierarchyEntity);
        when(portFolioSubWorkStreamRepo.save(subWorkStreamEntity)).thenReturn(subWorkStreamEntity);



    }
    @Test
    public void when_saveWorkStreamData_Return_WorkStreamEntity(){

//        when(workStreamServiceImpl.generateWorkStreamId(portfolioId,GeneConstants.WORKSTREAMNAME,year,platformIndex,
//                GeneConstants.WORKSTREAMNAME,costType,subWorkStreamEntity,"edit")).thenReturn(subWorkStreamEntity);
//        workStreamServiceImpl.saveSubWorkStreamData(portfolioId,"New PortFolio",subWorkStreamEntity,"edit");
    }

    //@Test
//    public void when_getWorkStreamEntityData(){
//
//        when( portFolioSubWorkStreamRepository.findByOrderByPortfolioIdDesc()).thenReturn(portFolioSubWorkStreamEntityList);
//
//        workStreamServiceImpl.getWorkStreamEntityData(portfolioId);
//    }

    @Test
    public void when_existsWorkStreamIdWithDeliveryUnit_return_boolean(){
        try {
            when(portFolioSubWorkStreamRepo.existsByWorkStreamIdAndDeliveryUnit(workStreamId,deliveryUnit)).thenReturn(true);
        } catch (Exception e) {

        }
        subWorkStreamService.existsWorkStreamIdWithDeliveryUnit(workStreamId,deliveryUnit);
    }
}
