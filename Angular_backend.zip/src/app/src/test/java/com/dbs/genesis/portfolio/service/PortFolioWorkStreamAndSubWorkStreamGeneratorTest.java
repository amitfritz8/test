package com.dbs.genesis.portfolio.service;

import org.junit.Test;


public class PortFolioWorkStreamAndSubWorkStreamGeneratorTest {

    PortFolioWorkStreamAndSubWorkStreamGenerator generator = new PortFolioWorkStreamAndSubWorkStreamGenerator();

    @Test
    public void generatePortfolioID() {
//        String portfolioID = generator.generatePortfolioID("16", "I");
        //Assert.assertEquals(portfolioID,"P16-20001-I");
    }

    @Test
    public void getPlatformIndex() {
    }
}
