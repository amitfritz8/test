package com.dbs.genesis.portfolio.service.financials;

import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import com.dbs.genesis.portfolio.repository.SubWorkstreamHardwareCostRepo;
import com.dbs.genesis.portfolio.resources.UnitCostMappingView;
import com.google.common.collect.Lists;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class BreakDownCostHardwareServiceTest {

    @Mock
    SubWorkstreamHardwareCostRepo subWorkstreamHardwareCostRepo;

    @Mock
    BreakDownCostOthersService breakDownCostOthersService;


    @InjectMocks
    BreakDownCostHardwareService serviceUnderTest;

    @Test
    void getListOfMonthlyValuesByHardwareTotal() {
    }

    @Test
    void getCostTypeOverAllTotal() {
    }

    @Test
    void getHardwareUnitCostMapByMonthly() {
    }

    @Test
    void populateUnitCostMappingForGivenTower() {
        List<SubWorkstreamHardwareCost> softwarePeriodList = Lists.newArrayList();
        softwarePeriodList.add(getSubWorkstreamHardwareCost("202004",1234,
                new BigDecimal("10"),new BigDecimal("100000")));
        softwarePeriodList.add(getSubWorkstreamHardwareCost("202005",1234,
                new BigDecimal("10"),new BigDecimal("200000")));
        String currencyCode ="SGD";
        UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
        serviceUnderTest.populateUnitCostMappingForGivenTower(softwarePeriodList,unitCostMappingView, currencyCode);
        Assertions.assertEquals(12,unitCostMappingView.getMonthlyResourcesCosts().size());
        assertEquals(12,unitCostMappingView.getMonthlyResourcesUnits().size());
        assertEquals("01",unitCostMappingView.getMonthlyResourcesUnits().get(0).getMonthNumber().toString());
        assertEquals(0,unitCostMappingView.getMonthlyResourcesUnits().get(0).getSurrId());
        assertEquals(new BigDecimal("0"),
                unitCostMappingView.getMonthlyResourcesUnits().get(0).getValue());
        assertEquals(new BigDecimal("0"), unitCostMappingView.getCostOverAllTotal());
        assertEquals(new BigDecimal("20"), unitCostMappingView.getUnitOverAllTotal());
    }

    private SubWorkstreamHardwareCost
    getSubWorkstreamHardwareCost(String period, int surrId,BigDecimal quantity,BigDecimal cost) {
        SubWorkstreamHardwareCost hardwareCost =  new SubWorkstreamHardwareCost();
        hardwareCost.setPeriod(period);
        hardwareCost.setSwsHwSurrId(surrId);
        hardwareCost.setQuantity(quantity);
        hardwareCost.setCostPerMonthLcy(cost);
        return hardwareCost;
    }
}