package com.dbs.genesis.portfolio.repository;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;
import java.util.List;
import com.dbs.genesis.portfolio.model.PcCodeTree;

@RunWith(SpringRunner.class)
@DataJpaTest
public class PcCodeTreeRepoTest {

	@Autowired
	private PcCodeTreeRepo pcCodeTreeRepo;
	
	@Test
	public void test_findByPlatformIndex() {
		PcCodeTree pcCodeTree = this.getPcCodeTree();
		pcCodeTreeRepo.save(pcCodeTree);
		
		List<PcCodeTree> pcCodeTreeList = pcCodeTreeRepo.findByPlatformIndex(pcCodeTree.getPlatformIndex());
		assertNotNull(pcCodeTreeList);
		assertEquals(1, pcCodeTreeList.size());
		assertEquals(pcCodeTree.getCountryCode(), pcCodeTreeList.get(0).getCountryCode());
		assertEquals(pcCodeTree.getPlatformName(), pcCodeTreeList.get(0).getPlatformName());
		assertEquals(pcCodeTree.getPcCode(), pcCodeTreeList.get(0).getPcCode());
		assertEquals(pcCodeTree.getPlatformIndex(), pcCodeTreeList.get(0).getPlatformIndex());
	}
	
	private PcCodeTree getPcCodeTree(){
		PcCodeTree pcCodeTree = new PcCodeTree();
		pcCodeTree.setCountryCode("Singapore");
		pcCodeTree.setPlatformName("Non-Technology");
		pcCodeTree.setPcCode("007_0377");
		pcCodeTree.setPlatformIndex("NT");
		return pcCodeTree;
	}

}
