package com.dbs.genesis.portfolio.controller;

import com.dbs.genesis.portfolio.repository.HyperionProductRepository;
import com.dbs.genesis.portfolio.repository.HyperionProdRepo;
import com.dbs.genesis.portfolio.resources.HyperionProductResource;

import lombok.extern.slf4j.Slf4j;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Slf4j
@RunWith(SpringRunner.class)
@WebMvcTest(HyperionProductController.class)
public class HyperionProductControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private HyperionProductRepository repo;

    @MockBean
    private HyperionProdRepo repoHyperProd;

    @Rule public TestName name = new TestName();
	
	@Before
	public void setUp() {
		log.info("Executing test-method ----> " + name.getMethodName());
	}
    
    @Test
    public void when_getAppCodeDesc_return_ListOfHyperionProductResource() throws Exception {
        HyperionProductResource hyperionProductResource =
                new HyperionProductResource("5", "10");
        List<HyperionProductResource> hyperionProductResourceList = Arrays.asList(hyperionProductResource);
        given(repoHyperProd.findHyperionProductResource()).willReturn(hyperionProductResourceList);
        mvc.perform( MockMvcRequestBuilders
                .get("/data/productCode/list")
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0]").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0].l0Node").isString())
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0].l0Desc").isString())
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0].l0Node").value("5"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0].l0Desc").value("10"));

    }

}
