package com.dbs.genesis.portfolio.service;

import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.*;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class PortfolioServiceTest {


    @Mock
    private PortfolioRepo portfolioGenerateRepo;

    @Mock
    private WorkStreamService workStreamService;

    @Mock
    private SequenceGeneratorRepo portFolioSequenceGeneratorRepo;

    @Mock
    private WorkHierarchyRepo workHierarchyRepo;

    @Mock
    private WorkStreamRepo workStreamRepo;

    @Mock
    private SubWorkStreamRepo subWorkStreamRepo;

    @Mock
    private PortfolioManagersRepo portfolioManagersRepo;

    @Mock
    private WorkStreamManagersRepo workStreamManagersRepo;

    @Mock
    private PortfolioRepository portfolioRepositoryImpl;

    @InjectMocks
    private PortfolioService portfolioServiceImpl;

    PortfolioEntity portfolioEntity = null;
    WorkStreamEntity workStreamEntity = null;
    SubWorkStreamEntity subWorkStreamEntity = null;
    SequenceGeneratorEntity sequenceGeneratorEntity = null;
    SequenceGeneratorEntity sequenceGeneratorEntity1 = null;
    SequenceGeneratorEntity sequenceGeneratorEntity2 = null;
    WorkHierarchyEntity workHierarchyEntity = null;
    WorkHierarchyResource workHierarchyResource = null;
    PortfolioCreationEvent portfolioCreationEvent = null;

    List<SequenceGeneratorEntity> listSequenceGenerator = null;
    List<SequenceGeneratorEntity> listSequenceGenerator1 = null;
    List<SequenceGeneratorEntity> listSequenceGenerator2 = null;
    List<PortfolioEntity> listOfPortfolioEntity = null;
    List<WorkStreamEntity> portFolioWorkStreamEntityList = null;
    List<SubWorkStreamEntity> portFolioSubWorkStreamEntityList = null;
    DataTypeNameResource dataTypeNameResource = null;

    PortfolioMangersEntity portfolioMangersEntity = null;
    List<PortfolioMangersEntity> portfolioMangersEntityList = null;
    PortfolioMangersResource portfolioMangersResource = null;
    List<PortfolioMangersResource> portfolioMangersResourceList = null;
    List<WorkStreamManagersEntity> workStreamManagersEntityList = null;
    WorkStreamManagersEntity workStreamManagersEntity = null;
    WorkStreamManagersResource workStreamManagersResource = null;
    List<WorkStreamManagersResource> workStreamManagersResourceList = null;
    List<StageWorkdayData> stageWorkdayDataList = null;
    StageWorkdayData stageWorkdayData = null;

    String year = "20";
    String costType = "I";
    String platformIndex = "0_CE";
    String platformName = "CE Central Function";
    String country = "SG";
    String deliveryUnit = "0_CE - CE Central Function";
    String portfolioId = "P25-25007-E";
    String workStreamId = "P25DAH2-25007-E0007";
    String subWorkStreamId = "P25DAH2-25007-E0007-25";
    String seqNoGenerator = "2";


    @Before
    public void setup() {
        portfolioEntity = new PortfolioEntity();
        workStreamEntity = new WorkStreamEntity();
        subWorkStreamEntity = new SubWorkStreamEntity();
        sequenceGeneratorEntity = new SequenceGeneratorEntity();
        sequenceGeneratorEntity1 = new SequenceGeneratorEntity();
        sequenceGeneratorEntity2 = new SequenceGeneratorEntity();
        workHierarchyEntity = new WorkHierarchyEntity();
        portfolioCreationEvent = new PortfolioCreationEvent();
        listSequenceGenerator = new ArrayList<>();
        listSequenceGenerator1 = new ArrayList<>();
        listSequenceGenerator2 = new ArrayList<>();
        listOfPortfolioEntity = new ArrayList<>();
        portFolioWorkStreamEntityList = new ArrayList<>();
        portFolioSubWorkStreamEntityList = new ArrayList<>();
        workHierarchyResource = new WorkHierarchyResource();
        dataTypeNameResource = new DataTypeNameResource();
        portfolioMangersEntity = new PortfolioMangersEntity();
        portfolioMangersEntityList = new ArrayList<>();
        portfolioMangersResource = new PortfolioMangersResource();
        portfolioMangersResourceList = new ArrayList<>();

        workStreamManagersEntityList = new ArrayList<>();
        workStreamManagersEntity = new WorkStreamManagersEntity();
        workStreamManagersResource = new WorkStreamManagersResource();
        workStreamManagersResourceList = new ArrayList<>();

        Lists.newArrayList(PortfolioConstants.WORKSTREAMNAME, PortfolioConstants.PORTFOLIONAME, PortfolioConstants.SUBWORKSTREAMNAME).forEach(
                e -> dataTypeNameResource.setDataType(e));
        Lists.newArrayList(PortfolioConstants.WORKSTREAMNAME, PortfolioConstants.PORTFOLIONAME, PortfolioConstants.SUBWORKSTREAMNAME).forEach(
                e -> dataTypeNameResource.setDataName("test"));


        sequenceGeneratorEntity.setSeqSurrId(1);
        sequenceGeneratorEntity.setPortFolioIdType(PortfolioConstants.PORTFOLIONAME);
        sequenceGeneratorEntity.setKey1(platformIndex);
        sequenceGeneratorEntity.setKey2(year);
        sequenceGeneratorEntity.setKey3("");
        sequenceGeneratorEntity.setKey4(costType);
        sequenceGeneratorEntity.setKey5("");
        sequenceGeneratorEntity.setMaxCounter(1);
        sequenceGeneratorEntity.setGeneratedId("P24-24004-E");

        listSequenceGenerator.add(sequenceGeneratorEntity);

        workHierarchyEntity.setPortfolioName(PortfolioConstants.PORTFOLIONAME);
        workHierarchyEntity.setPortfolioId(portfolioId);

        sequenceGeneratorEntity1.setSeqSurrId(2);
        sequenceGeneratorEntity1.setPortFolioIdType(PortfolioConstants.WORKSTREAMNAME);
        sequenceGeneratorEntity1.setKey1(platformIndex);
        sequenceGeneratorEntity1.setKey2(year);
        sequenceGeneratorEntity1.setKey3(country);
        sequenceGeneratorEntity1.setKey4(costType);
        sequenceGeneratorEntity1.setKey5("");
        sequenceGeneratorEntity1.setMaxCounter(1);
        sequenceGeneratorEntity1.setGeneratedId("P24SG-24004-E0001");
        listSequenceGenerator1.add(sequenceGeneratorEntity1);

        workHierarchyEntity.setWorkStreamName(PortfolioConstants.WORKSTREAMNAME);
        workHierarchyEntity.setWorkStreamId(workStreamId);

        sequenceGeneratorEntity2.setSeqSurrId(3);
        sequenceGeneratorEntity2.setPortFolioIdType(PortfolioConstants.SUBWORKSTREAMNAME);
        sequenceGeneratorEntity2.setKey1(platformIndex);
        sequenceGeneratorEntity2.setKey2(year);
        sequenceGeneratorEntity2.setKey3(country);
        sequenceGeneratorEntity2.setKey4(costType);
        sequenceGeneratorEntity2.setKey5(deliveryUnit);
        sequenceGeneratorEntity2.setMaxCounter(1);
        sequenceGeneratorEntity2.setGeneratedId("P24SG-24004-E0001-24");

        listSequenceGenerator2.add(sequenceGeneratorEntity2);

        workHierarchyEntity.setSubWorkStreamName(PortfolioConstants.SUBWORKSTREAMNAME);
        workHierarchyEntity.setSubWorkStreamId(subWorkStreamId);


        portfolioEntity.setPortfolioId(portfolioId);
        portfolioEntity.setWorkType(costType);
        portfolioEntity.setPortfolioName("New Portfolio");


        workStreamEntity.setPortfolioId(portfolioId);
        workStreamEntity.setWorkStreamId(workStreamId);
        workStreamEntity.setWorkStreamName("New Work Stream");
        workStreamEntity.setCountry(country);


        subWorkStreamEntity.setWorkStreamId(workStreamId);
        subWorkStreamEntity.setSubWorkStreamId(subWorkStreamId);
        subWorkStreamEntity.setDeliveryUnit(deliveryUnit);


        portfolioCreationEvent.setPortfolioName("New PORTFOLIO");
        portfolioCreationEvent.setInitiationYear("2019");
        portfolioCreationEvent.setWorkType("E");
        portfolioCreationEvent.setPrimaryPlatformName("0_CE - CE Central Function");



        portfolioMangersEntity.setOneBankId("manikandanc");
        portfolioMangersEntity.setDelegateInd("Yes");
        portfolioMangersEntity.setStaffName("Manikanda");
        portfolioMangersEntity.setEmailAddress("manikandanc@dbs.com");
        portfolioMangersEntity.setPortMgrSurrId(1);
        portfolioMangersEntity.setPlatformIndex("19");
        portfolioMangersEntity.setPortfolioId(portfolioId);
        portfolioMangersEntityList.add(portfolioMangersEntity);

        portfolioMangersResource.setStaffName("Manikandan c");
        portfolioMangersResource.setPortfolioId(portfolioId);
        portfolioMangersResource.setPlatformIndex("19");
        portfolioMangersResource.setPortfolioName("Finance");
        portfolioMangersResourceList.add(portfolioMangersResource);

        workStreamManagersEntity.setDelegateInd("yes");
        workStreamManagersEntity.setOneBankId("manikandanc");
        workStreamManagersEntity.setStaffName("Manikandan C");
        workStreamManagersEntity.setEmailAddress("manikandanc@dbs.com");
        workStreamManagersEntityList.add(workStreamManagersEntity);

        stageWorkdayDataList = new ArrayList<>();
        stageWorkdayData = new StageWorkdayData("manikandan c","manikandanc@dbs.com");
        stageWorkdayDataList.add(stageWorkdayData);

    }


    @Test
    public void when_generatePortFolioWorkStreamAndSubWorkStreamId_return_WorkHierarchyResource() {

        try {

            when(portFolioSequenceGeneratorRepo.save(sequenceGeneratorEntity)).thenReturn(sequenceGeneratorEntity);
            when(workHierarchyRepo.save(workHierarchyEntity)).thenReturn(workHierarchyEntity);
            when(portfolioGenerateRepo.save(portfolioEntity)).thenReturn(portfolioEntity);
            workHierarchyResource.setPortfolioName("New PORTFOLIO");
            workHierarchyResource.setPortfolioId("P25-25007-E");

            when(portFolioSequenceGeneratorRepo.save(sequenceGeneratorEntity1)).thenReturn(sequenceGeneratorEntity1);
            when(workHierarchyRepo.save(workHierarchyEntity)).thenReturn(workHierarchyEntity);
            when(workStreamRepo.save(workStreamEntity)).thenReturn(workStreamEntity);
            workHierarchyResource.setWorkStreamId("P25DAH2-25007-E0007");
            workHierarchyResource.setWorkStreamName("New Work Stream");

            when(portFolioSequenceGeneratorRepo.save(sequenceGeneratorEntity2)).thenReturn(sequenceGeneratorEntity2);
            when(workHierarchyRepo.save(workHierarchyEntity)).thenReturn(workHierarchyEntity);
            when(subWorkStreamRepo.save(subWorkStreamEntity)).thenReturn(subWorkStreamEntity);
            workHierarchyResource.setSubWorkStreamId("P25DAH2-25007-E0007-25");
            workHierarchyResource.setSubWorkStreamName("New Sub Work Stream");
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Test
    public void when_getListOfPortFolioSequenceGenerator_return_ListPortFolioSequenceGeneratorEntity() {
        try {

            when(portFolioSequenceGeneratorRepo.findByPortFolioIdTypeAndKey1AndKey2(PortfolioConstants.WORKSTREAMNAME, platformIndex, year))
                    .thenReturn(listSequenceGenerator1);
            when(portFolioSequenceGeneratorRepo.findByPortFolioIdTypeAndKey1AndKey2AndKey4(PortfolioConstants.PORTFOLIONAME, platformIndex, year, country))
                    .thenReturn(listSequenceGenerator);
            when(portFolioSequenceGeneratorRepo.findByPortFolioIdTypeAndKey1AndKey2AndKey3AndKey4(PortfolioConstants.SUBWORKSTREAMNAME, platformIndex, year, country, costType))
                    .thenReturn(listSequenceGenerator2);

        } catch (Exception e) {

        }
    }


    @Test
    public void when_getListOfPortfolioData_return_PortFolio() {
        try {
            when(portfolioGenerateRepo.findByPortfolioId(portfolioId))
                    .thenReturn(portfolioEntity);
        } catch (Exception e) {
        }
        portfolioServiceImpl.getListOfPortfolioData(portfolioId);

    }

    @Test
    public void when_getListOfWorkStreamData_return_WorkStreamData() {
        try {
            when(workStreamRepo.findByWorkStreamId(workStreamId))
                    .thenReturn(workStreamEntity);
        } catch (Exception e) {
        }
        portfolioServiceImpl.getListOfWorkStreamData(workStreamId);

    }

    @Test
    public void when_getListOfSubWorkStreamData_return_SubWorkStream() {
        try {
            when(subWorkStreamRepo.findBySubWorkStreamId(subWorkStreamId))
                    .thenReturn(subWorkStreamEntity);
        } catch (Exception e) {
        }

    }

    @Test
    public void when_getDataNameExists_return_boolean() {

        try {
            when(portfolioGenerateRepo.existsByPortfolioName("test")).thenReturn(true);
            when(workStreamRepo.existsByWorkStreamNameAndPortfolioId("test","P19-20001-I")).thenReturn(true);
            when(subWorkStreamRepo.existsBySubWorkStreamNameAndWorkStreamId("test","P19-20001-I0001")).thenReturn(true);
        } catch (Exception e) {

        }
        DataTypeNameResource dataTypeNameResource = new DataTypeNameResource();
        dataTypeNameResource.setDataType(PortfolioConstants.PORTFOLIONAME);
        boolean dataNameExists = portfolioServiceImpl.isDataNameExists(dataTypeNameResource);
        Assertions.assertEquals(dataNameExists,true);

    }

    @Test
    public void when_updatePortfolioData_return_PortfolioEntity(){

        try {
            Mockito.doNothing().when(portfolioServiceImpl).updatePortfolioData(portfolioEntity);

        } catch (Exception e) {

        }
        portfolioServiceImpl.updatePortfolioData(portfolioEntity);
    }

    @Test
    public void when_getListOfWorkManagersData_return_ListOfMap() {
        try {
            Map<String, List<PortfolioMangersResource>>  portfolioManagersMap;
            Map<String,List<WorkStreamManagersResource>> workStreamManagersMap;
            List<Map> mapList = new ArrayList<>();
            when(portfolioManagersRepo.findByPortfolioIdAndActiveInd(this.portfolioId, "true")).thenReturn(portfolioMangersEntityList);
            portfolioManagersMap = portfolioMangersResourceList.stream().collect(Collectors.groupingBy(PortfolioMangersResource :: getPortfolioName));
            when(workStreamManagersRepo.findByPortfolioIdAndActiveInd(this.portfolioId,"true")).thenReturn(workStreamManagersEntityList);
            mapList.add(portfolioManagersMap);
            workStreamManagersMap = workStreamManagersResourceList.stream().collect(Collectors.groupingBy(WorkStreamManagersResource::getWorkStreamName));
            mapList.add(workStreamManagersMap);
        }catch (Exception e ) {

        }
        portfolioServiceImpl.getListOfWorkManagersData(portfolioId);
    }

    @Test
    public void when_getLatestRecordsFromWorkDay_return_ListOfStageWorkdayData() {

        try {
            when(portfolioRepositoryImpl.getStageWorkDayData()).thenReturn(stageWorkdayDataList);

        } catch (Exception e) {
        }
        portfolioServiceImpl.getLatestRecordsFromWorkDay();
    }
}
