package com.dbs.genesis.portfolio.util;

import java.sql.Timestamp;

import com.dbs.genesis.portfolio.model.PcCodeTree;

public class PcCodeTreeUtil {	
	
	public static PcCodeTree prepareAndGetPcCodeTree() {
		PcCodeTree pcCodeTree = new PcCodeTree();
		pcCodeTree.setCountryCode("SG");
		pcCodeTree.setCreatedBy("Created-By");
		pcCodeTree.setDateCreated(new Timestamp(System.currentTimeMillis()));
		pcCodeTree.setDateModified(new Timestamp(System.currentTimeMillis()));
		pcCodeTree.setL1Desc("L1Desc");
		pcCodeTree.setL1Node("L1Node");
		pcCodeTree.setL2Desc("L1Desc");
		pcCodeTree.setL2Node("L2Node");
		pcCodeTree.setL3Desc("L3Desc");
		pcCodeTree.setL3Node("L3Node");
		pcCodeTree.setL4Desc("L4Desc");
		pcCodeTree.setL4Node("L4Node");
		pcCodeTree.setL5Desc("L5Desc");
		pcCodeTree.setL5Node("L5Node");
		pcCodeTree.setL6Desc("L6Desc");
		pcCodeTree.setL6Node("L6Node");
		pcCodeTree.setL7Desc("L7Desc");
		pcCodeTree.setL7Node("L7Node");
		pcCodeTree.setL8Desc("L8Desc");
		pcCodeTree.setL8Desc("L8Desc");
		pcCodeTree.setL9Desc("L9Desc");
		pcCodeTree.setL9Node("L9Node");
		pcCodeTree.setModifiedBy("Modified-By");
		pcCodeTree.setPcCode("Pc-Code");
		pcCodeTree.setPcCodeDesc("Pc-Code-Description");
		pcCodeTree.setPlatformIndex("Platform-Index");
		pcCodeTree.setPlatformName("Platform-Name");
		
		return pcCodeTree;
	}

}
