//package com.dbs.genesis.portfolio.service.financials;
//
//import com.dbs.genesis.portfolio.model.SubWorkstreamOtherCost;
//import com.dbs.genesis.portfolio.repository.SubWorkstreamOtherCostRepo;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.MockitoJUnitRunner;
//
//import java.math.BigDecimal;
//import java.util.Arrays;
//import java.util.List;
//
//import static org.hamcrest.Matchers.*;
//import static org.junit.Assert.assertThat;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.when;
//
//
//@RunWith(MockitoJUnitRunner.class)
//public class BreakDownCostOthersServiceTest {
//
//    @Mock
//    SubWorkstreamOtherCostRepo subWorkstreamHardwareCostRepo;
//
//    @InjectMocks
//    BreakDownCostOthersService uut;
//
//    @Test
//    public void when_getOthersHardwareByMonthly_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        assertThat("There is at leaset one others hardware present for the given month", uut.getOthersHardwareByMonthly("subWorkStreamId",
//                "subWorkStreamName", "period", "scenario", "SGD"), not(empty()));
//    }
//
//    @Test
//    public void when_getOthersHardwareByQuarterly_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        assertThat("There is at leaset one others hardware by quarterly present", uut.getOthersHardwareByQuarterly("subWorkStreamId",
//                "subWorkStreamName", "period", "scenario", "SGD"), not(empty()));
//    }
//
//    @Test
//    public void when_getOthersHardwareByYearly_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        assertThat("There is at leaset one others hardware by yearly present", uut.getOthersHardwareByYearly("subWorkStreamId",
//                "subWorkStreamName", "period", "scenario", "SGD"), not(empty()));
//    }
//
//    @Test
//    public void when_getOtherSoftwareByMonthly_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        assertThat("There is at leaset one others software by monthly present", uut.getOtherSoftwareByMonthly("subWorkStreamId",
//                "subWorkStreamName", "period", "scenario", "SGD"), not(empty()));
//    }
//
//    @Test
//    public void when_getOtherSoftwareByQuarterly_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        when(subWorkstreamHardwareCostRepo.getTotalOthersCostByTypeAndGrpCcy(anyString(), anyString(), anyString(), anyString())).thenReturn(BigDecimal.valueOf(1250.0));
//        assertThat("There is at leaset one others software by quarterly present", uut.getOtherSoftwareByQuarterly("subWorkStreamId",
//                "subWorkStreamName", "period", "scenario", "SGD"), not(empty()));
//    }
//
//    @Test
//    public void when_getOthersSoftwareByYearly_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        when(subWorkstreamHardwareCostRepo.getTotalOthersCostByTypeAndGrpCcy(anyString(), anyString(), anyString(), anyString())).thenReturn(BigDecimal.valueOf(1250.0));
//        assertThat("There is at leaset one others software by yearly present", uut.getOthersSoftwareByYearly("subWorkStreamId",
//                "subWorkStreamName", "period", "scenario", "SGD"), not(empty()));
//    }
//
//    @Test
//    public void when_getOthersByMonthly_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        assertThat("There is at leaset one others by monthly present", uut.getOthersByMonthly("subWorkStreamId",
//                "subWorkStreamName", "period", "scenario", "SGD"), not(empty()));
//    }
//
//    @Test
//    public void when_getOthersHeaderByMonthly_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        assertThat("There is at leaset one others header by monthly present", uut.getOthersHeaderByMonthly("subWorkStreamId",
//                "subWorkStreamName", "period", "scenario", "SGD"), not(empty()));
//    }
//
//
//    @Test
//    public void when_getOthersHeaderTotal_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndType(anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        assertThat("Others Header Data total should match sum of unit mapping costs", uut.getOthersHeaderTotal("subWorkStreamId",
//                "subWorkStreamName", "scenario", "SGD"), is(BigDecimal.valueOf(1000)));
//    }
//
//    @Test
//    public void when_getOthersByQuarterlyTotalSum_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findDistinctOfYears(anyString(), anyString(), anyString(), anyString())).thenReturn(Arrays.asList("2020", "2019"));
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        assertThat("Others Data by quarterly total sum contain for year 2020", uut.getOthersByQuarterlyTotalSum("subWorkStreamId",
//                "subWorkStreamName", "scenario", "SGD"), hasKey("2020"));
//    }
//
//    @Test
//    public void when_getOthersHeaderDataByQuarterly_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findDistinctOfYears(anyString(), anyString(), anyString(), anyString())).thenReturn(Arrays.asList("2020", "2019"));
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        assertThat("Others Header Data by quarterly contain for year 2020", uut.getOthersHeaderDataByQuarterly("subWorkStreamId",
//                "subWorkStreamName", "scenario", "SGD"), hasKey("2020"));
//    }
//
//    @Test
//    public void when_getYearlyOthersData_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findDistinctOfYears(anyString(), anyString(), anyString(), anyString())).thenReturn(Arrays.asList("2020", "2019"));
//        when(subWorkstreamHardwareCostRepo.getTotalOthersCostByTypeAndGrpCcy(anyString(), anyString(), anyString(), anyString())).thenReturn(BigDecimal.valueOf(1250l));
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        assertThat("Yearly others data should contain 2020", uut.getYearlyOthersData("subWorkStreamId",
//                "subWorkStreamName", "scenario", "SGD"), hasKey("2020"));
//    }
//
//
//    @Test
//    public void when_getYearlySummaryData_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findDistinctOfYears(anyString(), anyString(), anyString(), anyString())).thenReturn(Arrays.asList("2020", "2019"));
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        assertThat("Yearly summary should match sum of all sub work streams group ccy value", uut.getYearlySummaryData("subWorkStreamId",
//                "subWorkStreamName", "scenario", "SGD"), hasEntry("2020", BigDecimal.valueOf(1000)));
//    }
//
//    @Test
//    public void when_getOthersSummaryByMonthly_return_UnitMappingCosts() {
//
//        when(subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContaining(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(getSubWorkstreamOtherCosts());
//        assertThat("Others Monthly  summary should match sum of all sub work streams group ccy value", uut.getOthersSummaryByMonthly("subWorkStreamId",
//                "subWorkStreamName", "period", "scenario", "type", "SGD"), hasItemInArray(BigDecimal.valueOf(1000)));
//    }
//
//    private List<SubWorkstreamOtherCost> getSubWorkstreamOtherCosts() {
//
//        SubWorkstreamOtherCost swsoc = new SubWorkstreamOtherCost();
//        swsoc.setPeriod("02-005-2020");
//        swsoc.setSwsOtherSurrId(123);
//        swsoc.setGroupCcyVal(BigDecimal.valueOf(1000));
//        swsoc.setRefSwsOtherSurrId(2);
//        swsoc.setVendorName("Intel");
//        return Arrays.asList(swsoc);
//    }
//
//}
