package com.dbs.genesis.portfolio.service.costsettings;

import com.dbs.genesis.portfolio.repository.EmployeeRateCardRepo;
import com.dbs.genesis.portfolio.repository.ITCRateRepo;
import com.dbs.genesis.portfolio.resources.FinancialDetailsTemplateResource;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CostSettingServiceTest {

    @Mock
    private EmployeeRateCardRepo employeeRateCardRepo;
    @Mock
    private ITCRateRepo itcRateRepo;
    @InjectMocks
    private CostSettingService costSettingService;


    private List<String> countryCodes;
    private List<String> currencyCodes;
    private List<String> rateLevels;
    private List<String> rateSources;
    private List<String> staffTypes;
    private List<String> vendorCodes;
    private List<String> towers;
    private List<String> driverDetails;
    private List<String> uoms;
    private String CURRENCY_CODE_SGD = "SGD";

    private void setUpForFinancialDetailsTemplate(){
        countryCodes = Arrays.asList( "SG", "IN");
        currencyCodes = Arrays.asList(CURRENCY_CODE_SGD);
        rateLevels = Arrays.asList("L1", "L2", "L3");
        rateSources = Arrays.asList("C2E", "EASRE", "FR", "IBGT", "ITT", "MOT", "TACO");
        staffTypes = Arrays.asList("DBS", "Vendor - MS", "Vendor - SA");
        vendorCodes =Arrays.asList( "AIT", "CapG", "Comtel", "DBS", "HCL", "Helius", "IBM", "ITPS", "MS", "NCS");
        towers = Arrays.asList("Database", "Mainframe", "Nearline storage", "Non-EPC (P7)", "Offline storage");
        driverDetails = Arrays.asList("AIX vMem", "CAS storage", "Gold", "Linux vCPU");
        uoms = Arrays.asList("per CPU mins", "per GB", "per instance", "per OS");
    }

    @Test
    public void when_getFinancialDetailsTemplate_return_financialDetailsTemplate(){
        setUpForFinancialDetailsTemplate();
        when(employeeRateCardRepo.findDistinctCountryCodes()).thenReturn(countryCodes);
        when(employeeRateCardRepo.findDistinctRateLevels()).thenReturn(rateLevels);
        when(employeeRateCardRepo.findDistinctRateSources()).thenReturn(rateSources);
        when(employeeRateCardRepo.findDistinctStaffTypes()).thenReturn(staffTypes);
        when(employeeRateCardRepo.findDistinctVendorCodes()).thenReturn(vendorCodes);
        when(itcRateRepo.findDistinctTowers()).thenReturn(towers);
        when(itcRateRepo.findDistinctDriverDetails()).thenReturn(driverDetails);
        when(itcRateRepo.findDistinctUOM()).thenReturn(uoms);
        FinancialDetailsTemplateResource financialDetailsTemplateResource =
                costSettingService.getFinancialDetailsTemplate(CURRENCY_CODE_SGD);

        assertNotNull(financialDetailsTemplateResource);
        assertThat(financialDetailsTemplateResource.getCountryCodes().size()).isEqualTo(countryCodes.size());
        assertThat(financialDetailsTemplateResource.getCurrencyCodes().size()).isEqualTo(currencyCodes.size());
        assertThat(financialDetailsTemplateResource.getDriverDetails().size()).isEqualTo(driverDetails.size());
        assertThat(financialDetailsTemplateResource.getRateLevels().size()).isEqualTo(rateLevels.size());
        assertThat(financialDetailsTemplateResource.getRateSources().size()).isEqualTo(rateSources.size());
        assertThat(financialDetailsTemplateResource.getStaffTypes().size()).isEqualTo(staffTypes.size());
        assertThat(financialDetailsTemplateResource.getUomDetails().size()).isEqualTo(uoms.size());
        assertThat(financialDetailsTemplateResource.getVendorCodes().size()).isEqualTo(vendorCodes.size());
    }
}