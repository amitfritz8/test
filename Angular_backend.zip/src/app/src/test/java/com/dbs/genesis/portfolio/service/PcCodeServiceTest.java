package com.dbs.genesis.portfolio.service;

import com.dbs.genesis.portfolio.model.PcCodeTree;
import com.dbs.genesis.portfolio.repository.PcCodeTreeRepo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
@RunWith(SpringRunner.class)
public class PcCodeServiceTest {

    @Mock
    private PcCodeTreeRepo pcCodeTreeRepo;


    @InjectMocks
    private PcCodeService pcCodeService;

    @Before
    public void setUp(){

    }

    @Test
    public void when_getPcCodesTreeList_return_ListOfPcCodes_by_PlatformIndex() {
        String plaformIndex = "NT";
        when(pcCodeTreeRepo.findByPlatformIndex(plaformIndex))
                .thenReturn(getPcCodes());
       List<PcCodeTree> pcCodeTrees = pcCodeService.getPcCodesTreeListByPlatform(plaformIndex);
        assertEquals(1,pcCodeTrees.size());
        assertEquals("007_0377",pcCodeTrees.get(0).getPcCode());

    }

    @Test
    public void when_getPcCodesTreeList_return_emptyList_databaseException() {
        String plaformIndex = "NT";
        when(pcCodeTreeRepo.findByPlatformIndex(plaformIndex)).thenThrow(new RuntimeException());
        List<PcCodeTree> pcCodeTrees = pcCodeService.getPcCodesTreeListByPlatform(plaformIndex);
        assertEquals(pcCodeTrees.size(),0);

    }

    private PcCodeTree getPcCodeData(){
        PcCodeTree pcCodeTree = new PcCodeTree();
        pcCodeTree.setPcCode("007_0377");
        pcCodeTree.setPlatformIndex("NT");
        pcCodeTree.setPlatformName("Non-Technology");
        pcCodeTree.setCountryCode("Singapore");
        return pcCodeTree;
    }

    private List<PcCodeTree> getPcCodes(){
        List<PcCodeTree> pcCodeTrees = new ArrayList<>();
        pcCodeTrees.add(getPcCodeData());
        return pcCodeTrees;
    }
}
