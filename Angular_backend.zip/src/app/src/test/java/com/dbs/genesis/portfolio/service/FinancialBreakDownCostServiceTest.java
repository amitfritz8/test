package com.dbs.genesis.portfolio.service;

import org.junit.jupiter.api.Test;

class FinancialBreakDownCostServiceTest {

    @Test
    void getBreakDownCostData() {
    }

    @Test
    void getCostInputMonthlyData() {
    }

    @Test
    void getMonthlyData() {
    }
}