package com.dbs.genesis.portfolio.common;

import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertThat;

public class DateExtensionsTest implements DateExtensions {

    @Test
    public void when_getMonthYearListByAddingMonths_By3months() {
        Date date = new Date();
        assertThat(getMonthYearListByAddingMonths(date,3),hasSize(3));
    }

    @Test
    public void when_getMonthYearListByStartDateAndEndDate_return_YearMonthList() {
        Date currentDate = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        calendar.add(Calendar.MONTH,6);
        assertThat(getMonthYearListByStartDateAndEndDate(currentDate,calendar.getTime()),hasSize(7));
    }

}