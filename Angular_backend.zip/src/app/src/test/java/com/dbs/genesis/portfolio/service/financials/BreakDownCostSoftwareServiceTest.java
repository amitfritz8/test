//package com.dbs.genesis.portfolio.service.financials;
//
//import com.dbs.genesis.portfolio.common.PortfolioConstants;
//import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
//import com.dbs.genesis.portfolio.repository.PortfolioRepository;
//import com.dbs.genesis.portfolio.repository.SubWorkstreamOtherCostRepo;
//import com.dbs.genesis.portfolio.repository.SubWorkstreamSoftwareCostRepo;
//import com.dbs.genesis.portfolio.resources.FinancialSummaryResource;
//import com.dbs.genesis.portfolio.resources.UnitCostMappingView;
//import org.junit.Assert;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.MockitoJUnitRunner;
//
//import java.math.BigDecimal;
//import java.util.Arrays;
//import java.util.List;
//
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.when;
//
//
//@RunWith(MockitoJUnitRunner.class)
//public class BreakDownCostSoftwareServiceTest {
//
//    @Mock
//    private SubWorkstreamSoftwareCostRepo subWorkstreamSoftwareCostRepo;
//    @Mock
//    private BreakDownCostOthersService breakDownCostOthersService;
//    @Mock
//    private PortfolioRepository portfolioRepository;
//    @Mock
//    private SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo;
//
//    @InjectMocks
//    private BreakDownCostSoftwareService uut;
//
//    @Test
//    public void when_getCostSettingForFinancialDetails_OtherSoftCostType_CostSettingsView(){
//
//        when(portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndGroupCurrency(anyString(),anyString(),anyString(),anyString())).thenReturn(getConsolidatedFinancialSummaryByPeriod());
//        when(portfolioRepository.getConsolidatedFinancialSummaryTotalByGroupCurrency(anyString(),anyString(),anyString())).thenReturn(getFinancialSummaryTotal());
//        when(subWorkstreamSoftwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndPeriodContaining(anyString(),anyString(),anyString(),anyString(),anyString(),anyString()))
//            .thenReturn(getSubWorkstreamOtherCosts(),getSubWorkStreamSoftwareByVendor());
//        when(subWorkstreamSoftwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalInd(anyString(),anyString(),anyString(),anyString(),anyString())).
//            thenReturn(getCostTypeOverAllTotal());
//        when(breakDownCostOthersService.getOthersSummaryByMonthly(anyString(),anyString(),anyString(),anyString(),anyString(),anyString())).thenReturn(getOthersSummaryByMonthly());
//        when(breakDownCostOthersService.getOtherTotalSum(anyString(),anyString(),anyString(),anyString(),anyString())).thenReturn(BigDecimal.valueOf(150));
//        when(breakDownCostOthersService.getOtherSoftwareByMonthly(anyString(),anyString(),anyString(),anyString(),anyString())).thenReturn(getUnionCostMappingView());
//
//        List<String> costTypes = Arrays.asList(PortfolioConstants.SOFTWARE_TYPE);
//        Assert.assertNotNull(uut.getCostSettingForFinancialDetails( costTypes,"subWorkStreamId", "subWorkStreamName","period", PortfolioConstants.MONTHLY,"costSettingValue","scenario",PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD));
//
//
//    }
//
//    @Test
//    public void when_getCostSettingForFinancialDetails_OtherHardwareCostType_CostSettingsView(){
//
//        when(subWorkstreamOtherCostRepo.getDistinctOfPeriodFromFinancialTables(anyString(),anyString(),anyString())).thenReturn(Arrays.asList("2020","2021","2019"));
//        when(subWorkstreamSoftwareCostRepo.findDistinctOfPeriodsFromSoftwareCostAndOtherSoftwareCost(anyString(),anyString(),anyString())).thenReturn(Arrays.asList("2020","2021","2019"));
//        when(subWorkstreamSoftwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndPeriodContaining(anyString(),anyString(),anyString(),anyString(),anyString(),anyString()))
//                .thenReturn(getSubWorkStreamSoftwareByVendor());
//        when(portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndGroupCurrency(anyString(),anyString(),anyString(),anyString())).thenReturn(getConsolidatedFinancialSummaryByPeriod());
//        when(subWorkstreamSoftwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalInd(anyString(),anyString(),anyString(),anyString(),anyString())).
//                thenReturn(getCostTypeOverAllTotal());
//       // when(breakDownCostOthersService.getOtherSoftwareByMonthly(anyString(),anyString(),anyString(),anyString())).thenReturn(getUnionCostMappingView());
//        when(breakDownCostOthersService.getOthersByQuarterlyTotalSum(anyString(),anyString(),anyString(),anyString(),anyString(),anyString())).thenReturn(getOthersSummaryByQuarterly());
//
//        List<String> costTypes = Arrays.asList(PortfolioConstants.SOFTWARE_TYPE,PortfolioConstants.HARDWARE_TYPE,PortfolioConstants.OTHERS_TYPE);
//        Assert.assertNotNull(uut.getCostSettingForFinancialDetails( costTypes,"subWorkStreamId", "subWorkStreamName","period", PortfolioConstants.QUARTERLY,"costSettingValue","scenario",PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD));
//
//
//    }
//
//
//    private List<FinancialSummaryResource> getConsolidatedFinancialSummaryByPeriod(){
//
//        FinancialSummaryResource resourceOne = new FinancialSummaryResource(BigDecimal.valueOf(1500),"20200504");
//        FinancialSummaryResource resourceTwo = new FinancialSummaryResource(BigDecimal.valueOf(2500),"20200201");
//        FinancialSummaryResource resourceThree = new FinancialSummaryResource(BigDecimal.valueOf(3500),"20200901");
//        FinancialSummaryResource resourcefour = new FinancialSummaryResource(BigDecimal.valueOf(3500),"20201201");
//        return Arrays.asList(resourceOne, resourceTwo, resourceThree, resourcefour);
//
//    }
//
//
//    private List<FinancialSummaryResource> getFinancialSummaryTotal(){
//
//        FinancialSummaryResource resourceOne = new FinancialSummaryResource(BigDecimal.valueOf(4000),"20200501");
//        return Arrays.asList(resourceOne);
//
//    }
//
//    private List<SubWorkstreamSoftwareCost> getSubWorkstreamOtherCosts(){
//
//        SubWorkstreamSoftwareCost swscOne = new SubWorkstreamSoftwareCost();
//        swscOne.setPeriod("20200501");
//        swscOne.setVendorName("Intel");
//        swscOne.setCostPerMonthGcy(BigDecimal.valueOf(1000));
//
//        SubWorkstreamSoftwareCost swscTwo = new SubWorkstreamSoftwareCost();
//        swscTwo.setPeriod("20200501");
//        swscTwo.setVendorName("Intel");
//        swscTwo.setCostPerMonthGcy(BigDecimal.valueOf(1000));
//
//        return Arrays.asList(swscOne,swscTwo);
//
//    }
//
//    private List<SubWorkstreamSoftwareCost> getSubWorkStreamSoftwareByVendor(){
//
//        SubWorkstreamSoftwareCost swscOne = new SubWorkstreamSoftwareCost();
//        swscOne.setSoftwareName("OS");
//        swscOne.setVendorName("Intel");
//        swscOne.setPeriod("20200101");
//        swscOne.setRefSwsSwSurrId(1);
//        swscOne.setSwsSwSurrId(1);
//        swscOne.setCostPerMonthGcy(BigDecimal.valueOf(1000));
//        swscOne.setQuantity(BigDecimal.valueOf(1));
//
//        SubWorkstreamSoftwareCost swscTwo = new SubWorkstreamSoftwareCost();
//        swscTwo.setSoftwareName("OS");
//        swscTwo.setVendorName("Nvedia");
//        swscTwo.setPeriod("20200501");
//        swscTwo.setRefSwsSwSurrId(2);
//        swscTwo.setSwsSwSurrId(2);
//        swscTwo.setCostPerMonthGcy(BigDecimal.valueOf(1200));
//        swscTwo.setQuantity(BigDecimal.valueOf(2));
//
//        SubWorkstreamSoftwareCost swscThree = new SubWorkstreamSoftwareCost();
//        swscThree.setSoftwareName("OS");
//        swscThree.setVendorName("Google");
//        swscThree.setPeriod("20200801");
//        swscThree.setRefSwsSwSurrId(3);
//        swscThree.setSwsSwSurrId(3);
//        swscThree.setCostPerMonthGcy(BigDecimal.valueOf(1200));
//        swscThree.setQuantity(BigDecimal.valueOf(2));
//
//        SubWorkstreamSoftwareCost swscFour = new SubWorkstreamSoftwareCost();
//        swscFour.setSoftwareName("OS");
//        swscFour.setVendorName("Nvedia");
//        swscFour.setPeriod("20200501");
//        swscFour.setRefSwsSwSurrId(2);
//        swscFour.setSwsSwSurrId(2);
//        swscFour.setCostPerMonthGcy(BigDecimal.valueOf(1200));
//        swscFour.setQuantity(BigDecimal.valueOf(2));
//
//        return Arrays.asList(swscOne,swscTwo,swscThree,swscFour);
//
//    }
//
//    private List<SubWorkstreamSoftwareCost> getCostTypeOverAllTotal(){
//
//        SubWorkstreamSoftwareCost swscOne = new SubWorkstreamSoftwareCost();
//        swscOne.setCostPerMonthGcy(BigDecimal.valueOf(500));
//        swscOne.setQuantity(BigDecimal.valueOf(2));
//
//        SubWorkstreamSoftwareCost swscTwo = new SubWorkstreamSoftwareCost();
//        swscTwo.setCostPerMonthGcy(BigDecimal.valueOf(1000));
//        swscTwo.setQuantity(BigDecimal.valueOf(3));
//
//        return Arrays.asList(swscOne,swscTwo);
//
//    }
//
//    private List<SubWorkstreamSoftwareCost> getSubWorkstreamSoftwareCostWithOrigIndTrue(){
//
//        SubWorkstreamSoftwareCost swscOne = new SubWorkstreamSoftwareCost();
//        swscOne.setPeriod("20200501");
//        swscOne.setVendorName("Intel");
//        swscOne.setUnitPrice(BigDecimal.valueOf(1000));
//        return Arrays.asList(swscOne);
//
//    }
//
//    private BigDecimal[] getOthersSummaryByMonthly(){
//        return new BigDecimal[]{BigDecimal.valueOf(500d),BigDecimal.valueOf(500d)};
//    }
//
//    private List<BigDecimal> getOthersSummaryByQuarterly(){
//        return Arrays.asList(BigDecimal.valueOf(500d),BigDecimal.valueOf(500d),BigDecimal.valueOf(500d),BigDecimal.valueOf(500d));
//    }
//
//    private List<UnitCostMappingView> getUnionCostMappingView() {
//
//        UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
//        unitCostMappingView.setRefSurrId(3);
//        unitCostMappingView.setName("Google");
//        unitCostMappingView.setCurrencyCode("SGD");
//        unitCostMappingView.setUnitPriceValue("1100");
//        unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
//        unitCostMappingView.setYearlyCostOverAllTotal(BigDecimal.valueOf(10));
//        unitCostMappingView.setYearlyUnitOverAllTotal(BigDecimal.valueOf(20));
//        return Arrays.asList(unitCostMappingView);
//
//    }
//}
