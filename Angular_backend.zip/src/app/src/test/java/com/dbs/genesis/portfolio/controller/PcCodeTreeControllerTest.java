package com.dbs.genesis.portfolio.controller;

import com.dbs.genesis.portfolio.model.PcCodeTree;
import com.dbs.genesis.portfolio.service.PcCodeService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(PcCodeTreeController.class)
public class PcCodeTreeControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private PcCodeService pcCodeService;

    @Test
    public void when_getPcCodes_return_ListOfPcCodeTree() throws Exception {
       String plaformIndex = "NT";

        given(pcCodeService.getPcCodesTreeListByPlatform(plaformIndex)).willReturn(getPcCodes());
        mvc.perform( MockMvcRequestBuilders
                .get("/api/v1/pccodes/"+plaformIndex)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0]").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0].pcCode").isString())
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0].platformIndex").isString())
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0].platformName").value("Non-Technology"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0].countryCode").value("Singapore"));

    }

    private PcCodeTree getPcCodeData(){
        PcCodeTree pcCodeTree = new PcCodeTree();
        pcCodeTree.setPcCode("007_0377");
        pcCodeTree.setPlatformIndex("NT");
        pcCodeTree.setPlatformName("Non-Technology");
        pcCodeTree.setCountryCode("Singapore");
        return pcCodeTree;
    }

    private List<PcCodeTree> getPcCodes(){
        List<PcCodeTree> pcCodeTrees = new ArrayList<>();
        pcCodeTrees.add(getPcCodeData());
        return pcCodeTrees;
    }
}
