CREATE OR REPLACE TABLE REVINFO
(
    REV      int auto_increment primary key,
    REVTSTMP bigint null
);


CREATE OR REPLACE TABLE `itc_rate`
(
    `itc_rate_surr_id` int(11) NOT NULL AUTO_INCREMENT,
    `itc_included`     varchar(3)     DEFAULT NULL,
    `tower`            varchar(100)   DEFAULT NULL,
    `driver_detail`    varchar(100)   DEFAULT NULL,
    `uom`              varchar(50)    DEFAULT NULL,
    `rpt_location`     varchar(50)    DEFAULT NULL,
    `ccy_code`         varchar(10)    DEFAULT NULL,
    `itc_version`      varchar(10)    DEFAULT NULL,
    `itc_period`       varchar(10)    DEFAULT NULL,
    `rate_val`         decimal(20, 9) DEFAULT NULL,
    `created_by`       varchar(100)   DEFAULT NULL,
    `date_created`     datetime       DEFAULT NULL,
    `modified_by`      varchar(100)   DEFAULT NULL,
    `date_modified`    datetime       DEFAULT NULL,
    PRIMARY KEY (`itc_rate_surr_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `xref_hyperion_product_tree`
(
    `l0_node`       varchar(50)  DEFAULT NULL,
    `l0_desc`       varchar(100) DEFAULT NULL,
    `l1_node`       varchar(100) DEFAULT NULL,
    `l1_desc`       varchar(100) DEFAULT NULL,
    `l2_node`       varchar(100) DEFAULT NULL,
    `l2_desc`       varchar(100) DEFAULT NULL,
    `l3_node`       varchar(100) DEFAULT NULL,
    `l3_desc`       varchar(100) DEFAULT NULL,
    `l4_node`       varchar(100) DEFAULT NULL,
    `l4_desc`       varchar(100) DEFAULT NULL,
    `l5_node`       varchar(100) DEFAULT NULL,
    `l5_desc`       varchar(100) DEFAULT NULL,
    `l6_node`       varchar(100) DEFAULT NULL,
    `l6_desc`       varchar(100) DEFAULT NULL,
    `loans_dep_tag` varchar(100) DEFAULT NULL,
    `created_by`    varchar(100) DEFAULT NULL,
    `date_created`  datetime     DEFAULT NULL,
    `modified_by`   varchar(100) DEFAULT NULL,
    `date_modified` datetime     DEFAULT NULL
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;

CREATE OR REPLACE TABLE `map_ppm_to_gene`
(
    `map_surr_id`        int(11) NOT NULL AUTO_INCREMENT,
    `portfolio_id`       varchar(100)  DEFAULT NULL,
    `workstream_id`      varchar(100)  DEFAULT NULL,
    `initiative_name`    varchar(1000) DEFAULT NULL,
    `initiative_ref`     varchar(100)  DEFAULT NULL,
    `project_name`       varchar(1000) DEFAULT NULL,
    `project_id`         varchar(100)  DEFAULT NULL,
    `project_req_id`     varchar(100)  DEFAULT NULL,
    `project_pc_code`    varchar(1000) DEFAULT NULL,
    `field_name`         varchar(1000) DEFAULT NULL,
    `document_id`        varchar(100)  DEFAULT NULL,
    `document_name`      varchar(1000) DEFAULT NULL,
    `document_extension` varchar(10)   DEFAULT NULL,
    `request_type`       varchar(100)  DEFAULT NULL,
    `created_by`         varchar(100)  DEFAULT NULL,
    `date_created`       date          DEFAULT NULL,
    `modified_by`        varchar(100)  DEFAULT NULL,
    `date_modified`      date          DEFAULT NULL,
    PRIMARY KEY (`map_surr_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `map_work_to_pccode`
(
    `map_w2pccode_surr_id` int(11) NOT NULL AUTO_INCREMENT,
    `workstream_id`        varchar(100)   DEFAULT NULL,
    `sub_workstream_id`    varchar(100)   DEFAULT NULL,
    `le_pccode`            varchar(20)    DEFAULT NULL,
    `portfolio_id`         varchar(100)   DEFAULT NULL,
    `workstream_name`      varchar(1000)  DEFAULT NULL,
    `sub_workstream_name`  varchar(1000)  DEFAULT NULL,
    `build_operate`        varchar(20)    DEFAULT NULL,
    `allocation_pct`       decimal(10, 2) DEFAULT NULL,
    `reporting_flag`       varchar(10)    DEFAULT NULL,
    `created_by`           varchar(100)   DEFAULT NULL,
    `date_created`         datetime       DEFAULT NULL,
    `modified_by`          varchar(100)   DEFAULT NULL,
    `date_modified`        datetime       DEFAULT NULL,
    PRIMARY KEY (`map_w2pccode_surr_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `le_pccode` (`le_pccode`),
    KEY `sub_workstream_id` (`sub_workstream_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;

CREATE OR REPLACE TABLE `map_glsetid_to_hypleid`
(
    `gl2hyp_surr_id` int(11) NOT NULL AUTO_INCREMENT,
    `gl_set_id`      varchar(1000) DEFAULT NULL,
    `hyperion_le_id` varchar(10)   DEFAULT NULL,
    `created_by`     varchar(100)  DEFAULT NULL,
    `date_created`   datetime      DEFAULT NULL,
    `modified_by`    varchar(100)  DEFAULT NULL,
    `date_modified`  datetime      DEFAULT NULL,
    PRIMARY KEY (`gl2hyp_surr_id`),
    KEY `gl_set_id` (`gl_set_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `map_le_to_country`
(
    `map_le2ctry_surr_id` int(11) NOT NULL AUTO_INCREMENT,
    `le`                  varchar(10)   DEFAULT NULL,
    `le_desc`             varchar(100)  DEFAULT NULL,
    `le_tree_l5_desc`     varchar(100)  DEFAULT NULL,
    `le_pccode`           varchar(20)   DEFAULT NULL,
    `country`             varchar(100)  DEFAULT NULL,
    `country_code`        varchar(10)   DEFAULT NULL,
    `cpms_country_code`   varchar(10)   DEFAULT NULL,
    `cpms_kpi_desc`       varchar(100)  DEFAULT NULL,
    `remarks`             varchar(1000) DEFAULT NULL,
    `created_by`          varchar(100)  DEFAULT NULL,
    `date_created`        datetime      DEFAULT NULL,
    `modified_by`         varchar(100)  DEFAULT NULL,
    `date_modified`       datetime      DEFAULT NULL,
    PRIMARY KEY (`map_le2ctry_surr_id`),
    KEY `le` (`le`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;

CREATE OR REPLACE TABLE `xref_scenario_config`
(
    `scenario_surr_id`  int(11)      NOT NULL AUTO_INCREMENT,
    `scenario_name`     varchar(100) NOT NULL,
    `ws_item`           varchar(100)  DEFAULT NULL,
    `active_ind`        varchar(10)   DEFAULT NULL,
    `scenario_keydate`  varchar(100)  DEFAULT NULL,
    `level_keydate`     varchar(100)  DEFAULT NULL,
    `order_display_key` int(11)       DEFAULT NULL,
    `sws_function`      varchar(100)  DEFAULT NULL,
    `lock_ind`          varchar(100)  DEFAULT NULL,
    `activity_version`  varchar(100)  DEFAULT NULL,
    `snapshot_date`     date          DEFAULT NULL,
    `scenario_report`   varchar(100)  DEFAULT NULL,
    `link_to_report`    varchar(100)  DEFAULT NULL,
    `copy_function`     varchar(100)  DEFAULT NULL,
    `remarks`           varchar(1000) DEFAULT NULL,
    `created_by`        varchar(100)  DEFAULT NULL,
    `date_created`      datetime      DEFAULT NULL,
    `modified_by`       varchar(100)  DEFAULT NULL,
    `date_modified`     datetime      DEFAULT NULL,
    PRIMARY KEY (`scenario_surr_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `employee_rate_card`
(
    `rate_card_surr_id`    int(11) NOT NULL AUTO_INCREMENT,
    `rate_card_code`       varchar(50)    DEFAULT NULL,
    `country_code`         varchar(20)    DEFAULT NULL,
    `staff_type_taco`      varchar(50)    DEFAULT NULL,
    `staff_type_gene`      varchar(50)    DEFAULT NULL,
    `vendor_code`          varchar(20)    DEFAULT NULL,
    `rate_source`          varchar(50)    DEFAULT NULL,
    `rate_card_ref`        varchar(50)    DEFAULT NULL,
    `ccy_code`             varchar(10)    DEFAULT NULL,
    `rate_ind`             varchar(10)    DEFAULT NULL,
    `staff_type`           varchar(50)    DEFAULT NULL,
    `rate_level`           varchar(10)    DEFAULT NULL,
    `staff_rate`           decimal(20, 6) DEFAULT NULL,
    `effective_start_date` datetime       DEFAULT NULL,
    `effective_end_date`   datetime       DEFAULT NULL,
    `staff_rank`           varchar(100)   DEFAULT NULL,
    `staff_exp`            varchar(100)   DEFAULT NULL,
    `created_by`           varchar(100)   DEFAULT NULL,
    `date_created`         datetime       DEFAULT NULL,
    `modified_by`          varchar(100)   DEFAULT NULL,
    `date_modified`        datetime       DEFAULT NULL,
    PRIMARY KEY (`rate_card_surr_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 3
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `exchange_rates`
(
    `ex_rates_surr_id` int(11) NOT NULL AUTO_INCREMENT,
    `ccy_from`         varchar(10)    DEFAULT NULL,
    `ccy_to`           varchar(10)    DEFAULT NULL,
    `rate_type`        varchar(10)    DEFAULT NULL,
    `budget_status`    varchar(50)    DEFAULT NULL,
    `rate_period`      varchar(10)    DEFAULT NULL,
    `rate_val`         decimal(20, 9) DEFAULT NULL,
    `created_by`       varchar(100)   DEFAULT NULL,
    `date_created`     datetime       DEFAULT NULL,
    `modified_by`      varchar(100)   DEFAULT NULL,
    `date_modified`    datetime       DEFAULT NULL,
    PRIMARY KEY (`ex_rates_surr_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;



CREATE OR REPLACE TABLE `sequence_generator`
(
    `seq_surr_id`   int(11) NOT NULL AUTO_INCREMENT,
    `id_type`       varchar(100) DEFAULT NULL,
    `key1`          varchar(100) DEFAULT NULL,
    `key2`          varchar(100) DEFAULT NULL,
    `key3`          varchar(100) DEFAULT NULL,
    `key4`          varchar(100) DEFAULT NULL,
    `key5`          varchar(100) DEFAULT NULL,
    `max_counter`   int(11) NOT NULL,
    `generated_id`  varchar(100) DEFAULT NULL,
    `created_by`    varchar(100) DEFAULT NULL,
    `date_created`  datetime     DEFAULT NULL,
    `modified_by`   varchar(50)  DEFAULT NULL,
    `date_modified` datetime     DEFAULT NULL,
    PRIMARY KEY (`seq_surr_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `work_hierarchy`
(
    `work_hier_surr_id`   int(11)      NOT NULL AUTO_INCREMENT,
    `portfolio_id`        varchar(100) NOT NULL,
    `portfolio_name`      varchar(1000) DEFAULT NULL,
    `workstream_id`       varchar(100)  DEFAULT NULL,
    `workstream_name`     varchar(1000) DEFAULT NULL,
    `sub_workstream_id`   varchar(100)  DEFAULT NULL,
    `sub_workstream_name` varchar(1000) DEFAULT NULL,
    `created_by`          varchar(100)  DEFAULT NULL,
    `date_created`        datetime      DEFAULT NULL,
    `modified_by`         varchar(100)  DEFAULT NULL,
    `date_modified`       datetime      DEFAULT NULL,
    PRIMARY KEY (`work_hier_surr_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;

CREATE OR REPLACE TABLE `xref_app_code_master`
(
    `app_code_id`         int(11) NOT NULL AUTO_INCREMENT,
    `app_code`            varchar(20)   DEFAULT NULL,
    `app_code_name`       varchar(100)  DEFAULT NULL,
    `host_country`        varchar(50)   DEFAULT NULL,
    `lobt`                varchar(50)   DEFAULT NULL,
    `host_app_code`       varchar(10)   DEFAULT NULL,
    `platform_name`       varchar(100)  DEFAULT NULL,
    `category`            varchar(50)   DEFAULT NULL,
    `app_owner`           varchar(100)  DEFAULT NULL,
    `primary_app_mgr`     varchar(100)  DEFAULT NULL,
    `secondary_app_mgr`   varchar(100)  DEFAULT NULL,
    `app_code_desc`       varchar(5000) DEFAULT NULL,
    `used_in_country`     varchar(1000) DEFAULT NULL,
    `status`              varchar(20)   DEFAULT NULL,
    `system_type`         varchar(20)   DEFAULT NULL,
    `requestor_name`      varchar(100)  DEFAULT NULL,
    `app_code_short_desc` varchar(100)  DEFAULT NULL,
    `tech_unit`           varchar(100)  DEFAULT NULL,
    `platform_index`      varchar(20)   DEFAULT NULL,
    `created_by`          varchar(100)  DEFAULT NULL,
    `date_created`        datetime      DEFAULT NULL,
    `modified_by`         varchar(100)  DEFAULT NULL,
    `date_modified`       datetime      DEFAULT NULL,
    `appcode_and_name`    varchar(1000) DEFAULT NULL,
    `appcode_included`    varchar(3)    DEFAULT NULL,
    PRIMARY KEY (`app_code_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `xref_biz_segment_master`
(
    `biz_surr_id`      int(11) NOT NULL AUTO_INCREMENT,
    `platform_index`   varchar(20)  DEFAULT NULL,
    `platform_name`    varchar(100) DEFAULT NULL,
    `biz_segment_name` varchar(50)  DEFAULT NULL,
    `created_by`       varchar(100) DEFAULT NULL,
    `date_created`     datetime     DEFAULT NULL,
    `modified_by`      varchar(50)  DEFAULT NULL,
    `date_modified`    datetime     DEFAULT NULL,
    PRIMARY KEY (`biz_surr_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `portfolio_profile`
(
    `port_surr_id`           int(11)       NOT NULL AUTO_INCREMENT,
    `portfolio_id`           varchar(100)  NOT NULL,
    `portfolio_name`         varchar(1000) NOT NULL,
    `portfolio_desc`         varchar(5000) DEFAULT NULL,
    `initiation_year`        varchar(4)    NOT NULL,
    `work_type`              varchar(50)   NOT NULL,
    `primary_platform_index` varchar(20)   NOT NULL,
    `primary_platform_name`  varchar(100)  NOT NULL,
    `platform_name`          varchar(100)  DEFAULT NULL,
    `requestor_1bank_id`     varchar(50)   DEFAULT NULL,
    `requestor_name`         varchar(100)  DEFAULT NULL,
    `portfolio_reference_id` varchar(100)  DEFAULT NULL,
    `budget_status`          varchar(100)  DEFAULT NULL,
    `budget_system_owner`    varchar(100)  DEFAULT NULL,
    `planning_cycle`         varchar(100)  DEFAULT NULL,
    `biz_segment`            varchar(100)  DEFAULT NULL,
    `thematic`               varchar(100)  DEFAULT NULL,
    `horizon`                varchar(100)  DEFAULT NULL,
    `agile_waterfall`        varchar(100)  DEFAULT NULL,
    `created_by`             varchar(100)  DEFAULT NULL,
    `date_created`           datetime      DEFAULT NULL,
    `modified_by`            varchar(100)  DEFAULT NULL,
    `date_modified`          datetime      DEFAULT NULL,
    `reporting_flag`         varchar(10)   DEFAULT NULL,
    PRIMARY KEY (`port_surr_id`),
    KEY `portfolio_id` (`portfolio_id`),
    KEY `work_type` (`work_type`),
    KEY `primary_platform_index` (`primary_platform_index`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `portfolio_managers`
(
    `port_mgr_surr_id`     int(11)      NOT NULL AUTO_INCREMENT,
    `portfolio_id`         varchar(100) DEFAULT NULL,
    `1bank_id`             varchar(50)  NOT NULL,
    `staff_name`           varchar(100) NOT NULL,
    `role`                 varchar(100) NOT NULL,
    `delegate_ind`         varchar(10)  NOT NULL,
    `active_ind`           varchar(10)  NOT NULL,
    `platform_index`       varchar(20)  NOT NULL,
    `email_address`        varchar(100) NOT NULL,
    `effective_start_date` date         DEFAULT NULL,
    `effective_end_date`   date         DEFAULT NULL,
    `created_by`           varchar(100) DEFAULT NULL,
    `date_created`         datetime     DEFAULT NULL,
    `modified_by`          varchar(100) DEFAULT NULL,
    `date_modified`        datetime     DEFAULT NULL,
    PRIMARY KEY (`port_mgr_surr_id`),
    KEY `portfolio_id` (`portfolio_id`),
    KEY `role` (`role`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `workstream_profile`
(
    `ws_surr_id`               int(11)      NOT NULL AUTO_INCREMENT,
    `portfolio_id`             varchar(100) NOT NULL,
    `workstream_id`            varchar(100) NOT NULL,
    `workstream_name`          varchar(1000) DEFAULT NULL,
    `workstream_desc`          varchar(5000) DEFAULT NULL,
    `country`                  varchar(100)  DEFAULT NULL,
    `sub_platform_name`        varchar(100)  DEFAULT NULL,
    `biz_segment`              varchar(100)  DEFAULT NULL,
    `value_benefit`            varchar(100)  DEFAULT NULL,
    `value_benefit_start_date` date          DEFAULT NULL,
    `work_status`              varchar(100)  DEFAULT NULL,
    `work_phase`               varchar(100)  DEFAULT NULL,
    `thematic`                 varchar(100)  DEFAULT NULL,
    `horizon`                  varchar(100)  DEFAULT NULL,
    `agile_waterfall_ind`      varchar(100)  DEFAULT NULL,
    `category`                 varchar(100)  DEFAULT NULL,
    `le_pccode_build`          varchar(100)  DEFAULT NULL,
    `le_pccode_operate`        varchar(100)  DEFAULT NULL,
    `workstream_ref`           varchar(100)  DEFAULT NULL,
    `created_by`               varchar(100)  DEFAULT NULL,
    `date_created`             datetime      DEFAULT NULL,
    `modified_by`              varchar(100)  DEFAULT NULL,
    `date_modified`            datetime      DEFAULT NULL,
    `overall_risk_level`       varchar(20)   DEFAULT NULL,
    PRIMARY KEY (`ws_surr_id`),
    KEY `portfolio_id` (`portfolio_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `workstream_name` (`workstream_name`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;



CREATE OR REPLACE TABLE `workstream_le_pccodes`
(
    `ws_pccode_surr_id`   int(11) NOT NULL AUTO_INCREMENT,
    `portfolio_id`        varchar(100)  DEFAULT NULL,
    `workstream_id`       varchar(100)  DEFAULT NULL,
    `le_pccode`           varchar(100)  DEFAULT NULL,
    `build_operate`       varchar(50)   DEFAULT NULL,
    `workstream_name`     varchar(1000) DEFAULT NULL,
    `allocation_pct`      decimal(6, 2) DEFAULT NULL,
    `created_by`          varchar(45)   DEFAULT NULL,
    `date_created`        datetime      DEFAULT NULL,
    `modified_by`         varchar(45)   DEFAULT NULL,
    `date_modified`       datetime      DEFAULT NULL,
    `ws_lepccodes_ref_id` int(11)       DEFAULT NULL,
    `active_ind`          varchar(10)   DEFAULT NULL,
    PRIMARY KEY (`ws_pccode_surr_id`),
    KEY `portfolio_id` (`portfolio_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `build_operate` (`build_operate`),
    KEY `le_pccode` (`le_pccode`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `workstream_managers`
(
    `ws_mgr_surr_id`       int(11)      NOT NULL AUTO_INCREMENT,
    `portfolio_id`         varchar(100) NOT NULL,
    `workstream_id`        varchar(100) NOT NULL,
    `1bank_id`             varchar(50)  DEFAULT NULL,
    `staff_name`           varchar(100) DEFAULT NULL,
    `role`                 varchar(100) DEFAULT NULL,
    `delegate_ind`         varchar(10)  DEFAULT NULL,
    `active_ind`           varchar(10)  DEFAULT NULL,
    `platform_index`       varchar(20)  DEFAULT NULL,
    `email_address`        varchar(100) DEFAULT NULL,
    `effective_start_date` date         DEFAULT NULL,
    `effective_end_date`   date         DEFAULT NULL,
    `created_by`           varchar(100) DEFAULT NULL,
    `date_created`         datetime     DEFAULT NULL,
    `modified_by`          varchar(100) DEFAULT NULL,
    `date_modified`        datetime     DEFAULT NULL,
    PRIMARY KEY (`ws_mgr_surr_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `portfolio_id` (`portfolio_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `workstream_others`
(
    `ws_others_surr_id` int(11) NOT NULL AUTO_INCREMENT,
    `portfolio_id`      varchar(100)  DEFAULT NULL,
    `workstream_id`     varchar(100)  DEFAULT NULL,
    `workstream_name`   varchar(1000) DEFAULT NULL,
    `document_type`     varchar(100)  DEFAULT NULL,
    `document_name`     varchar(1000) DEFAULT NULL,
    `description`       varchar(1000) DEFAULT NULL,
    `file_path`         varchar(1000) DEFAULT NULL,
    `created_by`        varchar(100)  DEFAULT NULL,
    `date_created`      datetime      DEFAULT NULL,
    `modified_by`       varchar(100)  DEFAULT NULL,
    `date_modified`     datetime      DEFAULT NULL,
    `active_ind`        varchar(10)   DEFAULT NULL,
    PRIMARY KEY (`ws_others_surr_id`),
    KEY `portfolio_id` (`portfolio_id`),
    KEY `workstream_id` (`workstream_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `workstream_approvers`
(
    `ws_approver_surr_id`  int(11)      NOT NULL AUTO_INCREMENT,
    `portfolio_id`         varchar(100) NOT NULL,
    `workstream_id`        varchar(100) NOT NULL,
    `scenario`             varchar(100) DEFAULT NULL,
    `1bank_id`             varchar(50)  DEFAULT NULL,
    `staff_name`           varchar(100) DEFAULT NULL,
    `role`                 varchar(100) DEFAULT NULL,
    `delegate_ind`         varchar(10)  DEFAULT NULL,
    `active_ind`           varchar(10)  DEFAULT NULL,
    `action`               varchar(50)  DEFAULT NULL,
    `notify_ind`           varchar(10)  DEFAULT NULL,
    `effective_start_date` date         DEFAULT NULL,
    `effective_end_date`   date         DEFAULT NULL,
    `created_by`           varchar(100) DEFAULT NULL,
    `date_created`         datetime     DEFAULT NULL,
    `modified_by`          varchar(100) DEFAULT NULL,
    `date_modified`        datetime     DEFAULT NULL,
    PRIMARY KEY (`ws_approver_surr_id`),
    KEY `portfolio_id` (`portfolio_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `scenario` (`scenario`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;

CREATE OR REPLACE TABLE `workstream_dates`
(
    `ws_dt_surr_id`     int(11)      NOT NULL AUTO_INCREMENT,
    `portfolio_id`      varchar(100) NOT NULL,
    `workstream_id`     varchar(100) NOT NULL,
    `scenario_name`     varchar(100) DEFAULT NULL,
    `active_ind`        varchar(10)  DEFAULT NULL,
    `date_type`         varchar(100) DEFAULT NULL,
    `approval_date`     date         DEFAULT NULL,
    `start_date`        date         DEFAULT NULL,
    `go_live_date`      date         DEFAULT NULL,
    `end_date`          date         DEFAULT NULL,
    `sw_eng_start_date` date         DEFAULT NULL,
    `depre_start_date`  date         DEFAULT NULL,
    `created_by`        varchar(100) DEFAULT NULL,
    `date_created`      datetime     DEFAULT NULL,
    `modified_by`       varchar(100) DEFAULT NULL,
    `date_modified`     datetime     DEFAULT NULL,
    PRIMARY KEY (`ws_dt_surr_id`),
    KEY `portfolio_id` (`portfolio_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `scenario_name` (`scenario_name`),
    KEY `active_ind` (`active_ind`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `workstream_approvers_scenario`
(
    `ws_app_scn_surr_id`  int(11) NOT NULL AUTO_INCREMENT,
    `ws_approver_surr_id` int(11) NOT NULL,
    `scenario`            varchar(100) DEFAULT NULL,
    `created_by`          varchar(100) DEFAULT NULL,
    `date_created`        datetime     DEFAULT NULL,
    `modified_by`         varchar(100) DEFAULT NULL,
    `date_modified`       datetime     DEFAULT NULL,
    PRIMARY KEY (`ws_app_scn_surr_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `sub_workstream_profile`
(
    `subws_surr_id`       int(11)      NOT NULL AUTO_INCREMENT,
    `workstream_id`       varchar(100) NOT NULL,
    `sub_workstream_id`   varchar(100) NOT NULL,
    `sub_workstream_name` varchar(1000) DEFAULT NULL,
    `sub_workstream_desc` varchar(5000) DEFAULT NULL,
    `country`             varchar(100)  DEFAULT NULL,
    `platform_unit`       varchar(100)  DEFAULT NULL,
    `sub_platform_name`   varchar(100)  DEFAULT NULL,
    `delivery_unit`       varchar(100)  DEFAULT NULL,
    `category`            varchar(100)  DEFAULT NULL,
    `app_code`            varchar(50)   DEFAULT NULL,
    `app_code_desc`       varchar(1000) DEFAULT NULL,
    `product_code`        varchar(50)   DEFAULT NULL,
    `product_code_desc`   varchar(1000) DEFAULT NULL,
    `sub_workstream_ref`  varchar(100)  DEFAULT NULL,
    `work_type`           varchar(10)   DEFAULT NULL,
    `created_by`          varchar(100)  DEFAULT NULL,
    `date_created`        datetime      DEFAULT NULL,
    `modified_by`         varchar(100)  DEFAULT NULL,
    `date_modified`       datetime      DEFAULT NULL,
    `workstream_ref_id`   int(11)      NOT NULL,
    PRIMARY KEY (`subws_surr_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `sub_workstream_id` (`sub_workstream_id`),
    KEY `sub_workstream_name` (`sub_workstream_name`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `sub_workstream_profile_aud`
(
    `subws_surr_id`           int(11) NOT NULL,
    `REV`                     int(11) NOT NULL,
    `REVTYPE`                 tinyint(4)    DEFAULT NULL,
    `app_code`                varchar(255)  DEFAULT NULL,
    `app_code_MOD`            bit(1)        DEFAULT NULL,
    `app_code_desc`           varchar(255)  DEFAULT NULL,
    `app_code_desc_MOD`       bit(1)        DEFAULT NULL,
    `category`                varchar(255)  DEFAULT NULL,
    `category_MOD`            bit(1)        DEFAULT NULL,
    `country`                 varchar(255)  DEFAULT NULL,
    `country_MOD`             bit(1)        DEFAULT NULL,
    `delivery_unit`           varchar(255)  DEFAULT NULL,
    `delivery_unit_MOD`       bit(1)        DEFAULT NULL,
    `platform_unit`           varchar(255)  DEFAULT NULL,
    `platform_unit_MOD`       bit(1)        DEFAULT NULL,
    `product_code`            varchar(255)  DEFAULT NULL,
    `product_code_MOD`        bit(1)        DEFAULT NULL,
    `product_code_desc`       varchar(255)  DEFAULT NULL,
    `product_code_desc_MOD`   bit(1)        DEFAULT NULL,
    `sub_platform_name`       varchar(255)  DEFAULT NULL,
    `sub_platform_name_MOD`   bit(1)        DEFAULT NULL,
    `sub_workstream_desc`     varchar(1000) DEFAULT NULL,
    `sub_workstream_desc_MOD` bit(1)        DEFAULT NULL,
    `sub_workstream_id`       varchar(255)  DEFAULT NULL,
    `sub_workstream_id_MOD`   bit(1)        DEFAULT NULL,
    `sub_workstream_name`     varchar(255)  DEFAULT NULL,
    `sub_workstream_name_MOD` bit(1)        DEFAULT NULL,
    `sub_workstream_ref`      varchar(255)  DEFAULT NULL,
    `sub_workstream_ref_MOD`  bit(1)        DEFAULT NULL,
    `workstream_id`           varchar(255)  DEFAULT NULL,
    `workstream_id_MOD`       bit(1)        DEFAULT NULL,
    `workstream_ref_id`       int(11)       DEFAULT NULL,
    `workstream_ref_id_MOD`   bit(1)        DEFAULT NULL,
    `work_type`               varchar(255)  DEFAULT NULL,
    `work_type_MOD`           bit(1)        DEFAULT NULL,
    PRIMARY KEY (`subws_surr_id`, `REV`),
    KEY `FKi8jgwuiesb63m7wcwysyx1yjx` (`REV`),
    CONSTRAINT `FKi8jgwuiesb63m7wcwysyx1yjx` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `sub_workstream_approvers`
(
    `sws_approver_surr_id` int(11)      NOT NULL AUTO_INCREMENT,
    `sub_workstream_id`    varchar(100) NOT NULL,
    `workstream_id`        varchar(100) NOT NULL,
    `sub_workstream_name`  varchar(1000) DEFAULT NULL,
    `scenario`             varchar(100)  DEFAULT NULL,
    `1bank_id`             varchar(50)   DEFAULT NULL,
    `staff_name`           varchar(100)  DEFAULT NULL,
    `role`                 varchar(100)  DEFAULT NULL,
    `delegate_ind`         varchar(10)   DEFAULT NULL,
    `active_ind`           varchar(10)   DEFAULT NULL,
    `action`               varchar(50)   DEFAULT NULL,
    `notify_ind`           varchar(10)   DEFAULT NULL,
    `effective_start_date` date          DEFAULT NULL,
    `effective_end_date`   date          DEFAULT NULL,
    `created_by`           varchar(100)  DEFAULT NULL,
    `date_created`         datetime      DEFAULT NULL,
    `modified_by`          varchar(100)  DEFAULT NULL,
    `date_modified`        datetime      DEFAULT NULL,
    PRIMARY KEY (`sws_approver_surr_id`),
    KEY `sub_workstream_id` (`sub_workstream_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `sub_workstream_name` (`sub_workstream_name`),
    KEY `scenario` (`scenario`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `sub_workstream_dates`
(
    `sws_dt_surr_id`      int(11)      NOT NULL AUTO_INCREMENT,
    `workstream_id`       varchar(100) NOT NULL,
    `sub_workstream_id`   varchar(100) NOT NULL,
    `sub_workstream_name` varchar(1000) DEFAULT NULL,
    `scenario_name`       varchar(100)  DEFAULT NULL,
    `active_ind`          varchar(10)   DEFAULT NULL,
    `date_type`           varchar(100)  DEFAULT NULL,
    `approval_date`       date          DEFAULT NULL,
    `start_date`          date          DEFAULT NULL,
    `go_live_date`        date          DEFAULT NULL,
    `end_date`            date          DEFAULT NULL,
    `sw_eng_start_date`   date          DEFAULT NULL,
    `depre_start_date`    date          DEFAULT NULL,
    `created_by`          varchar(100)  DEFAULT NULL,
    `date_created`        datetime      DEFAULT NULL,
    `modified_by`         varchar(100)  DEFAULT NULL,
    `date_modified`       datetime      DEFAULT NULL,
    PRIMARY KEY (`sws_dt_surr_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `sub_workstream_id` (`sub_workstream_id`),
    KEY `sub_workstream_name` (`sub_workstream_name`),
    KEY `scenario_name` (`scenario_name`),
    KEY `active_ind` (`active_ind`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;

CREATE OR REPLACE TABLE `sub_workstream_fin_details`
(
    `sws_fd_surr_id`      int(11) NOT NULL AUTO_INCREMENT,
    `workstream_id`       varchar(100)   DEFAULT NULL,
    `sub_workstream_id`   varchar(100)   DEFAULT NULL,
    `sub_workstream_name` varchar(1000)  DEFAULT NULL,
    `scenario`            varchar(50)    DEFAULT NULL,
    `cost_settings`       varchar(100)   DEFAULT NULL,
    `gl_category`         varchar(100)   DEFAULT NULL,
    `cost_type`           varchar(1000)  DEFAULT NULL,
    `cost_type_detail`    varchar(1000)  DEFAULT NULL,
    `period`              varchar(20)    DEFAULT NULL,
    `org_ind`             varchar(50)    DEFAULT NULL,
    `local_ccy`           varchar(100)   DEFAULT NULL,
    `group_ccy`           varchar(10)    DEFAULT NULL,
    `local_ccy_val`       decimal(30, 9) DEFAULT NULL,
    `group_ccy_val`       decimal(30, 9) DEFAULT NULL,
    `planned_fte`         decimal(30, 9) DEFAULT NULL,
    `allocation_pct`      decimal(30, 9) DEFAULT NULL,
    `ref_sws_fd_surr_id`  int(11)        DEFAULT NULL,
    `created_by`          varchar(45)    DEFAULT NULL,
    `date_created`        datetime       DEFAULT NULL,
    `modified_by`         varchar(45)    DEFAULT NULL,
    `date_modified`       datetime       DEFAULT NULL,
    PRIMARY KEY (`sws_fd_surr_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `sub_workstream_id` (`sub_workstream_id`),
    KEY `sub_workstream_name` (`sub_workstream_name`),
    KEY `scenario` (`scenario`),
    KEY `cost_type_detail` (`cost_type_detail`),
    KEY `period` (`period`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;



CREATE OR REPLACE TABLE `sub_workstream_hardware_cost`
(
    `sws_hw_surr_id`       int(11) NOT NULL AUTO_INCREMENT,
    `workstream_id`        varchar(100)   DEFAULT NULL,
    `sub_workstream_id`    varchar(100)   DEFAULT NULL,
    `sub_workstream_name`  varchar(100)   DEFAULT NULL,
    `scenario`             varchar(100)   DEFAULT NULL,
    `tower`                varchar(100)   DEFAULT NULL,
    `driver_detail`        varchar(100)   DEFAULT NULL,
    `uom`                  varchar(100)   DEFAULT NULL,
    `quantity`             decimal(20, 9) DEFAULT NULL,
    `gl_category`          varchar(10)    DEFAULT NULL,
    `hw_descr`             varchar(1000)  DEFAULT NULL,
    `hw_cost`              decimal(20, 9) DEFAULT NULL,
    `effective_start_date` datetime       DEFAULT NULL,
    `effective_end_date`   datetime       DEFAULT NULL,
    `created_by`           varchar(100)   DEFAULT NULL,
    `date_created`         datetime       DEFAULT NULL,
    `modified_by`          varchar(100)   DEFAULT NULL,
    `date_modified`        datetime       DEFAULT NULL,
    `cost_settings`        varchar(100)   DEFAULT NULL,
    `cost_type_detail`     varchar(100)   DEFAULT NULL,
    `active_ind`           varchar(50)    DEFAULT NULL,
    `period`               varchar(10)    DEFAULT NULL,
    `local_ccy`            varchar(10)    DEFAULT NULL,
    `group_ccy`            varchar(20)    DEFAULT NULL,
    `original_ind`         varchar(10)    DEFAULT NULL,
    `itc_rate`             decimal(20, 9) DEFAULT NULL,
    `cost_per_month_lcy`   decimal(20, 9) DEFAULT NULL,
    `cost_per_month_gcy`   decimal(20, 9) DEFAULT NULL,
    `ref_hw_cost_surr_id`  int(11)        DEFAULT NULL,
    `capex_opex_surr_id`   int(11)        DEFAULT NULL,
    `add_hardware`         varchar(100)   DEFAULT NULL,
    PRIMARY KEY (`sws_hw_surr_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `sub_workstream_id` (`sub_workstream_id`),
    KEY `sub_workstream_name` (`sub_workstream_name`),
    KEY `scenario` (`scenario`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `sub_workstream_managers`
(
    `subws_mgr_surr_id`    int(11)      NOT NULL AUTO_INCREMENT,
    `workstream_id`        varchar(100) NOT NULL,
    `sub_workstream_id`    varchar(100) NOT NULL,
    `sub_workstream_name`  varchar(1000) DEFAULT NULL,
    `1bank_id`             varchar(50)   DEFAULT NULL,
    `staff_name`           varchar(100)  DEFAULT NULL,
    `role`                 varchar(100)  DEFAULT NULL,
    `delegate_ind`         varchar(10)   DEFAULT NULL,
    `active_ind`           varchar(10)   DEFAULT NULL,
    `platform_index`       varchar(20)   DEFAULT NULL,
    `email_address`        varchar(100)  DEFAULT NULL,
    `effective_start_date` date          DEFAULT NULL,
    `effective_end_date`   date          DEFAULT NULL,
    `created_by`           varchar(100)  DEFAULT NULL,
    `date_created`         datetime      DEFAULT NULL,
    `modified_by`          varchar(100)  DEFAULT NULL,
    `date_modified`        datetime      DEFAULT NULL,
    PRIMARY KEY (`subws_mgr_surr_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `sub_workstream_id` (`sub_workstream_id`),
    KEY `sub_workstream_name` (`sub_workstream_name`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;

CREATE OR REPLACE TABLE `sub_workstream_others`
(
    `sws_others_surr_id`  int(11) NOT NULL AUTO_INCREMENT,
    `workstream_id`       varchar(100)  DEFAULT NULL,
    `sub_workstream_id`   varchar(100)  DEFAULT NULL,
    `sub_workstream_name` varchar(1000) DEFAULT NULL,
    `document_type`       varchar(100)  DEFAULT NULL,
    `document_name`       varchar(1000) DEFAULT NULL,
    `description`         varchar(1000) DEFAULT NULL,
    `file_path`           varchar(1000) DEFAULT NULL,
    `created_by`          varchar(100)  DEFAULT NULL,
    `date_created`        datetime      DEFAULT NULL,
    `modified_by`         varchar(100)  DEFAULT NULL,
    `date_modified`       datetime      DEFAULT NULL,
    `active_ind`          varchar(10)   DEFAULT NULL,
    PRIMARY KEY (`sws_others_surr_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `sub_workstream_id` (`sub_workstream_id`),
    KEY `sub_workstream_name` (`sub_workstream_name`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `sub_workstream_other_cost`
(
    `sws_other_surr_id`     int(11) NOT NULL AUTO_INCREMENT,
    `workstream_id`         varchar(100)   DEFAULT NULL,
    `sub_workstream_id`     varchar(100)   DEFAULT NULL,
    `sub_workstream_name`   varchar(100)   DEFAULT NULL,
    `scenario`              varchar(100)   DEFAULT NULL,
    `other_cost_code`       varchar(100)   DEFAULT NULL,
    `effective_start_date`  datetime       DEFAULT NULL,
    `effective_end_date`    datetime       DEFAULT NULL,
    `created_by`            varchar(100)   DEFAULT NULL,
    `date_created`          datetime       DEFAULT NULL,
    `modified_by`           varchar(100)   DEFAULT NULL,
    `date_modified`         datetime       DEFAULT NULL,
    `cost_settings`         varchar(100)   DEFAULT NULL,
    `cost_type_detail`      varchar(100)   DEFAULT NULL,
    `vendor_name`           varchar(100)   DEFAULT NULL,
    `gl_category`           varchar(100)   DEFAULT NULL,
    `other_descr`           varchar(1000)  DEFAULT NULL,
    `local_ccy`             varchar(10)    DEFAULT NULL,
    `group_ccy`             varchar(10)    DEFAULT NULL,
    `quantity`              decimal(20, 9) DEFAULT NULL,
    `local_ccy_val`         decimal(20, 9) DEFAULT NULL,
    `group_ccy_val`         decimal(20, 9) DEFAULT NULL,
    `type`                  varchar(50)    DEFAULT NULL,
    `active_ind`            varchar(10)    DEFAULT NULL,
    `original_ind`          varchar(10)    DEFAULT NULL,
    `cost_indicator`        varchar(50)    DEFAULT NULL,
    `period`                varchar(10)    DEFAULT NULL,
    `ref_sws_other_surr_id` int(11)        DEFAULT NULL,
    `capex_opex_surr_id`    int(11)        DEFAULT NULL,
    `add_other`             varchar(100)   DEFAULT NULL,
    PRIMARY KEY (`sws_other_surr_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `sub_workstream_id` (`sub_workstream_id`),
    KEY `sub_workstream_name` (`sub_workstream_name`),
    KEY `scenario` (`scenario`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `sub_workstream_resource_cost`
(
    `sws_resource_surr_id`     int(11) NOT NULL AUTO_INCREMENT,
    `workstream_id`            varchar(100)   DEFAULT NULL,
    `sub_workstream_id`        varchar(100)   DEFAULT NULL,
    `sub_workstream_name`      varchar(100)   DEFAULT NULL,
    `scenario`                 varchar(100)   DEFAULT NULL,
    `resource_type`            varchar(100)   DEFAULT NULL,
    `cost_settings`            varchar(100)   DEFAULT NULL,
    `gl_category`              varchar(100)   DEFAULT NULL,
    `platform_index`           varchar(10)    DEFAULT NULL,
    `team_name`                varchar(100)   DEFAULT NULL,
    `location`                 varchar(100)   DEFAULT NULL,
    `staff_type`               varchar(100)   DEFAULT NULL,
    `vendor`                   varchar(100)   DEFAULT NULL,
    `rate_source`              varchar(100)   DEFAULT NULL,
    `staff_level`              varchar(100)   DEFAULT NULL,
    `team_code`                varchar(100)   DEFAULT NULL,
    `team_role`                varchar(100)   DEFAULT NULL,
    `local_ccy`                varchar(10)    DEFAULT NULL,
    `group_ccy`                varchar(10)    DEFAULT NULL,
    `period`                   varchar(10)    DEFAULT NULL,
    `fte`                      decimal(20, 9) DEFAULT NULL,
    `allocation_pct`           decimal(20, 9) DEFAULT NULL,
    `blended_cost_lcy`         decimal(20, 9) DEFAULT NULL,
    `blended_cost_gcy`         decimal(20, 9) DEFAULT NULL,
    `effective_start_date`     datetime       DEFAULT NULL,
    `effective_end_date`       datetime       DEFAULT NULL,
    `created_by`               varchar(100)   DEFAULT NULL,
    `date_created`             datetime       DEFAULT NULL,
    `modified_by`              varchar(100)   DEFAULT NULL,
    `date_modified`            datetime       DEFAULT NULL,
    `add_resource`             varchar(100)   DEFAULT NULL,
    `original_ind`             varchar(10)    DEFAULT NULL,
    `ref_sws_resource_surr_id` int(11)        DEFAULT NULL,
    `active_ind`               varchar(50)    DEFAULT NULL,
    `capex_opex_surr_id`       int(11)        DEFAULT NULL,
    PRIMARY KEY (`sws_resource_surr_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `sub_workstream_id` (`sub_workstream_id`),
    KEY `sub_workstream_name` (`sub_workstream_name`),
    KEY `scenario` (`scenario`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `sub_workstream_software_cost`
(
    `sw_cost_surr_id`      int(11) NOT NULL AUTO_INCREMENT,
    `workstream_id`        varchar(100)   DEFAULT NULL,
    `sub_workstream_id`    varchar(100)   DEFAULT NULL,
    `sub_workstream_name`  varchar(100)   DEFAULT NULL,
    `scenario`             varchar(100)   DEFAULT NULL,
    `software_name`        varchar(100)   DEFAULT NULL,
    `vendor_name`          varchar(100)   DEFAULT NULL,
    `software_type`        varchar(100)   DEFAULT NULL,
    `gl_category`          varchar(20)    DEFAULT NULL,
    `software_desc`        varchar(1000)  DEFAULT NULL,
    `created_by`           varchar(100)   DEFAULT NULL,
    `date_created`         datetime       DEFAULT NULL,
    `modified_by`          varchar(100)   DEFAULT NULL,
    `date_modified`        datetime       DEFAULT NULL,
    `effective_start_date` datetime       DEFAULT NULL,
    `effective_end_date`   datetime       DEFAULT NULL,
    `active_ind`           varchar(50)    DEFAULT NULL,
    `cost_settings`        varchar(100)   DEFAULT NULL,
    `cost_type_detail`     varchar(100)   DEFAULT NULL,
    `period`               varchar(10)    DEFAULT NULL,
    `original_ind`         varchar(10)    DEFAULT NULL,
    `local_ccy`            varchar(20)    DEFAULT NULL,
    `group_ccy`            varchar(20)    DEFAULT NULL,
    `quantity`             decimal(20, 9) DEFAULT NULL,
    `unit_price`           decimal(20, 9) DEFAULT NULL,
    `cost_per_month_lcy`   decimal(20, 9) DEFAULT NULL,
    `cost_per_month_gcy`   decimal(20, 9) DEFAULT NULL,
    `ref_sw_cost_surr_id`  int(11)        DEFAULT NULL,
    `capex_opex_surr_id`   int(11)        DEFAULT NULL,
    `add_software`         varchar(100)   DEFAULT NULL,
    PRIMARY KEY (`sw_cost_surr_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `sub_workstream_id` (`sub_workstream_id`),
    KEY `sub_workstream_name` (`sub_workstream_name`),
    KEY `scenario` (`scenario`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `sws_backend_fin_details`
(
    `sws_fd_surr_id`       int(11) NOT NULL AUTO_INCREMENT,
    `portfolio_id`         varchar(100)   DEFAULT NULL,
    `workstream_id`        varchar(100)   DEFAULT NULL,
    `sub_workstream_id`    varchar(100)   DEFAULT NULL,
    `sub_workstream_name`  varchar(1000)  DEFAULT NULL,
    `scenario`             varchar(50)    DEFAULT NULL,
    `cost_settings`        varchar(100)   DEFAULT NULL,
    `lock_ind`             varchar(10)    DEFAULT NULL,
    `fd_version`           varchar(100)   DEFAULT NULL,
    `snapshot_date`        datetime       DEFAULT NULL,
    `agile_waterfall`      varchar(20)    DEFAULT NULL,
    `approval_date`        datetime       DEFAULT NULL,
    `start_date`           datetime       DEFAULT NULL,
    `sw_eng_date`          datetime       DEFAULT NULL,
    `go_live_date`         datetime       DEFAULT NULL,
    `sws_end_date`         datetime       DEFAULT NULL,
    `depre_start_date`     datetime       DEFAULT NULL,
    `eoy_date`             datetime       DEFAULT NULL,
    `cost_type`            varchar(1000)  DEFAULT NULL,
    `add_resource`         varchar(100)   DEFAULT NULL,
    `team_name`            varchar(1000)  DEFAULT NULL,
    `team_role`            varchar(50)    DEFAULT NULL,
    `team_location`        varchar(100)   DEFAULT NULL,
    `staff_type`           varchar(100)   DEFAULT NULL,
    `staff_vendor`         varchar(1000)  DEFAULT NULL,
    `rate_source`          varchar(100)   DEFAULT NULL,
    `staff_level`          varchar(100)   DEFAULT NULL,
    `fte`                  decimal(20, 9) DEFAULT NULL,
    `staff_rate`           decimal(20, 9) DEFAULT NULL,
    `manday_per_month`     decimal(20, 9) DEFAULT NULL,
    `cost_per_day`         decimal(20, 9) DEFAULT NULL,
    `cost_per_month`       decimal(30, 9) DEFAULT NULL,
    `charge_type`          varchar(100)   DEFAULT NULL,
    `staff_gl_category`    varchar(100)   DEFAULT NULL,
    `hle`                  decimal(30, 9) DEFAULT NULL,
    `monthly_split_period` decimal(20, 9) DEFAULT NULL,
    `add_software`         varchar(100)   DEFAULT NULL,
    `sw_vendor`            varchar(100)   DEFAULT NULL,
    `sw_name`              varchar(100)   DEFAULT NULL,
    `sw_type`              varchar(100)   DEFAULT NULL,
    `sw_unit_price`        decimal(20, 9) DEFAULT NULL,
    `sw_quantity`          int(11)        DEFAULT NULL,
    `sw_gl_category`       varchar(100)   DEFAULT NULL,
    `sw_cost`              decimal(30, 9) DEFAULT NULL,
    `add_hardware`         varchar(100)   DEFAULT NULL,
    `hw_tower`             varchar(100)   DEFAULT NULL,
    `hw_driver_details`    varchar(100)   DEFAULT NULL,
    `hw_uom`               varchar(100)   DEFAULT NULL,
    `hw_itc_rate`          decimal(20, 9) DEFAULT NULL,
    `hw_quantity`          int(11)        DEFAULT NULL,
    `hw_gl_category`       varchar(100)   DEFAULT NULL,
    `hw_cost`              decimal(30, 9) DEFAULT NULL,
    `add_other`            varchar(100)   DEFAULT NULL,
    `other_vendor`         varchar(100)   DEFAULT NULL,
    `other_gl_category`    varchar(100)   DEFAULT NULL,
    `other_cost`           decimal(30, 9) DEFAULT NULL,
    `gl_category`          varchar(100)   DEFAULT NULL,
    `field_in_cost_type`   varchar(100)   DEFAULT NULL,
    `ccy_code`             varchar(10)    DEFAULT NULL,
    `jan_year_1`           decimal(30, 9) DEFAULT NULL,
    `feb_year_1`           decimal(30, 9) DEFAULT NULL,
    `mar_year_1`           decimal(30, 9) DEFAULT NULL,
    `apr_year_1`           decimal(30, 9) DEFAULT NULL,
    `may_year_1`           decimal(30, 9) DEFAULT NULL,
    `jun_year_1`           decimal(30, 9) DEFAULT NULL,
    `jul_year_1`           decimal(30, 9) DEFAULT NULL,
    `aug_year_1`           decimal(30, 9) DEFAULT NULL,
    `sep_year_1`           decimal(30, 9) DEFAULT NULL,
    `oct_year_1`           decimal(30, 9) DEFAULT NULL,
    `nov_year_1`           decimal(30, 9) DEFAULT NULL,
    `dec_year_1`           decimal(30, 9) DEFAULT NULL,
    `jan_year_2`           decimal(30, 9) DEFAULT NULL,
    `feb_year_2`           decimal(30, 9) DEFAULT NULL,
    `mar_year_2`           decimal(30, 9) DEFAULT NULL,
    `apr_year_2`           decimal(30, 9) DEFAULT NULL,
    `may_year_2`           decimal(30, 9) DEFAULT NULL,
    `jun_year_2`           decimal(30, 9) DEFAULT NULL,
    `jul_year_2`           decimal(30, 9) DEFAULT NULL,
    `aug_year_2`           decimal(30, 9) DEFAULT NULL,
    `sep_year_2`           decimal(30, 9) DEFAULT NULL,
    `oct_year_2`           decimal(30, 9) DEFAULT NULL,
    `nov_year_2`           decimal(30, 9) DEFAULT NULL,
    `dec_year_2`           decimal(30, 9) DEFAULT NULL,
    `jan_year_3`           decimal(30, 9) DEFAULT NULL,
    `feb_year_3`           decimal(30, 9) DEFAULT NULL,
    `mar_year_3`           decimal(30, 9) DEFAULT NULL,
    `apr_year_3`           decimal(30, 9) DEFAULT NULL,
    `may_year_3`           decimal(30, 9) DEFAULT NULL,
    `jun_year_3`           decimal(30, 9) DEFAULT NULL,
    `jul_year_3`           decimal(30, 9) DEFAULT NULL,
    `aug_year_3`           decimal(30, 9) DEFAULT NULL,
    `sep_year_3`           decimal(30, 9) DEFAULT NULL,
    `oct_year_3`           decimal(30, 9) DEFAULT NULL,
    `nov_year_3`           decimal(30, 9) DEFAULT NULL,
    `dec_year_3`           decimal(30, 9) DEFAULT NULL,
    `jan_year_4`           decimal(30, 9) DEFAULT NULL,
    `feb_year_4`           decimal(30, 9) DEFAULT NULL,
    `mar_year_4`           decimal(30, 9) DEFAULT NULL,
    `apr_year_4`           decimal(30, 9) DEFAULT NULL,
    `may_year_4`           decimal(30, 9) DEFAULT NULL,
    `jun_year_4`           decimal(30, 9) DEFAULT NULL,
    `jul_year_4`           decimal(30, 9) DEFAULT NULL,
    `aug_year_4`           decimal(30, 9) DEFAULT NULL,
    `sep_year_4`           decimal(30, 9) DEFAULT NULL,
    `oct_year_4`           decimal(30, 9) DEFAULT NULL,
    `nov_year_4`           decimal(30, 9) DEFAULT NULL,
    `dec_year_4`           decimal(30, 9) DEFAULT NULL,
    `jan_year_5`           decimal(30, 9) DEFAULT NULL,
    `feb_year_5`           decimal(30, 9) DEFAULT NULL,
    `mar_year_5`           decimal(30, 9) DEFAULT NULL,
    `apr_year_5`           decimal(30, 9) DEFAULT NULL,
    `may_year_5`           decimal(30, 9) DEFAULT NULL,
    `jun_year_5`           decimal(30, 9) DEFAULT NULL,
    `jul_year_5`           decimal(30, 9) DEFAULT NULL,
    `aug_year_5`           decimal(30, 9) DEFAULT NULL,
    `sep_year_5`           decimal(30, 9) DEFAULT NULL,
    `oct_year_5`           decimal(30, 9) DEFAULT NULL,
    `nov_year_5`           decimal(30, 9) DEFAULT NULL,
    `dec_year_5`           decimal(30, 9) DEFAULT NULL,
    `jan_year_6`           decimal(30, 9) DEFAULT NULL,
    `feb_year_6`           decimal(30, 9) DEFAULT NULL,
    `mar_year_6`           decimal(30, 9) DEFAULT NULL,
    `apr_year_6`           decimal(30, 9) DEFAULT NULL,
    `may_year_6`           decimal(30, 9) DEFAULT NULL,
    `jun_year_6`           decimal(30, 9) DEFAULT NULL,
    `jul_year_6`           decimal(30, 9) DEFAULT NULL,
    `aug_year_6`           decimal(30, 9) DEFAULT NULL,
    `sep_year_6`           decimal(30, 9) DEFAULT NULL,
    `oct_year_6`           decimal(30, 9) DEFAULT NULL,
    `nov_year_6`           decimal(30, 9) DEFAULT NULL,
    `dec_year_6`           decimal(30, 9) DEFAULT NULL,
    `jan_year_7`           decimal(30, 9) DEFAULT NULL,
    `feb_year_7`           decimal(30, 9) DEFAULT NULL,
    `mar_year_7`           decimal(30, 9) DEFAULT NULL,
    `apr_year_7`           decimal(30, 9) DEFAULT NULL,
    `may_year_7`           decimal(30, 9) DEFAULT NULL,
    `jun_year_7`           decimal(30, 9) DEFAULT NULL,
    `jul_year_7`           decimal(30, 9) DEFAULT NULL,
    `aug_year_7`           decimal(30, 9) DEFAULT NULL,
    `sep_year_7`           decimal(30, 9) DEFAULT NULL,
    `oct_year_7`           decimal(30, 9) DEFAULT NULL,
    `nov_year_7`           decimal(30, 9) DEFAULT NULL,
    `dec_year_7`           decimal(30, 9) DEFAULT NULL,
    `jan_year_8`           decimal(30, 9) DEFAULT NULL,
    `feb_year_8`           decimal(30, 9) DEFAULT NULL,
    `mar_year_8`           decimal(30, 9) DEFAULT NULL,
    `apr_year_8`           decimal(30, 9) DEFAULT NULL,
    `may_year_8`           decimal(30, 9) DEFAULT NULL,
    `jun_year_8`           decimal(30, 9) DEFAULT NULL,
    `jul_year_8`           decimal(30, 9) DEFAULT NULL,
    `aug_year_8`           decimal(30, 9) DEFAULT NULL,
    `sep_year_8`           decimal(30, 9) DEFAULT NULL,
    `oct_year_8`           decimal(30, 9) DEFAULT NULL,
    `nov_year_8`           decimal(30, 9) DEFAULT NULL,
    `dec_year_8`           decimal(30, 9) DEFAULT NULL,
    `total_amt`            decimal(30, 9) DEFAULT NULL,
    `data_source`          varchar(100)   DEFAULT NULL,
    `created_by`           varchar(100)   DEFAULT NULL,
    `date_created`         datetime       DEFAULT NULL,
    `modified_by`          varchar(100)   DEFAULT NULL,
    `date_modified`        datetime       DEFAULT NULL,
    PRIMARY KEY (`sws_fd_surr_id`),
    KEY `portfolio_id` (`portfolio_id`),
    KEY `workstream_id` (`workstream_id`),
    KEY `sub_workstream_id` (`sub_workstream_id`),
    KEY `sub_workstream_name` (`sub_workstream_name`),
    KEY `scenario` (`scenario`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `psgl_fin_details`
(
    `psgl_surr_id`         int(11) NOT NULL AUTO_INCREMENT,
    `extraction_date`      date           DEFAULT NULL,
    `biz_unit`             varchar(10)    DEFAULT NULL,
    `journal_id`           varchar(50)    DEFAULT NULL,
    `journal_date`         date           DEFAULT NULL,
    `account`              varchar(50)    DEFAULT NULL,
    `dept_id`              varchar(10)    DEFAULT NULL,
    `product`              varchar(50)    DEFAULT NULL,
    `currency_code`        varchar(10)    DEFAULT NULL,
    `project_id`           varchar(50)    DEFAULT NULL,
    `monetary_amt`         decimal(20, 9) DEFAULT NULL,
    `journal_line_ref`     varchar(50)    DEFAULT NULL,
    `line_desc`            varchar(100)   DEFAULT NULL,
    `line_desc_2_dbs`      varchar(100)   DEFAULT NULL,
    `line_desc_3_dbs`      varchar(100)   DEFAULT NULL,
    `line_desc_4_dbs`      varchar(100)   DEFAULT NULL,
    `line_desc_5_dbs`      varchar(100)   DEFAULT NULL,
    `line_desc_6_dbs`      varchar(100)   DEFAULT NULL,
    `line_desc_7_dbs`      varchar(100)   DEFAULT NULL,
    `foreign_ccy`          varchar(10)    DEFAULT NULL,
    `foreign_amt`          decimal(20, 9) DEFAULT NULL,
    `posted_date`          date           DEFAULT NULL,
    `country_code`         varchar(20)    DEFAULT NULL,
    `platform_index`       varchar(20)    DEFAULT NULL,
    `biz_tech_ind`         varchar(100)   DEFAULT NULL,
    `le_pccode`            varchar(100)   DEFAULT NULL,
    `planning_center`      varchar(100)   DEFAULT NULL,
    `gl_category`          varchar(100)   DEFAULT NULL,
    `platform_gl`          varchar(100)   DEFAULT NULL,
    `budget_gl`            varchar(100)   DEFAULT NULL,
    `cost_type`            varchar(100)   DEFAULT NULL,
    `cost_type_active_ind` varchar(20)    DEFAULT NULL,
    `hyp_level_0_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_3_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_4_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_5_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_6_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_7_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_8_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_9_desc`     varchar(100)   DEFAULT NULL,
    `gl_level_0_desc`      varchar(100)   DEFAULT NULL,
    `gl_level_8_desc`      varchar(100)   DEFAULT NULL,
    `gl_level_9_desc`      varchar(100)   DEFAULT NULL,
    `gl_level_10_desc`     varchar(100)   DEFAULT NULL,
    `gl_level_11_desc`     varchar(100)   DEFAULT NULL,
    `gl_level_12_desc`     varchar(100)   DEFAULT NULL,
    `gl_level_13_desc`     varchar(100)   DEFAULT NULL,
    `gl_level_14_desc`     varchar(100)   DEFAULT NULL,
    `ledger`               varchar(50)    DEFAULT NULL,
    `created_by`           varchar(100)   DEFAULT NULL,
    `date_created`         datetime       DEFAULT NULL,
    `modified_by`          varchar(100)   DEFAULT NULL,
    `date_modified`        datetime       DEFAULT NULL,
    PRIMARY KEY (`psgl_surr_id`),
    KEY `le_pccode` (`le_pccode`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `hyperion_fin_details`
(
    `hypacct_surr_id`      int(11) NOT NULL AUTO_INCREMENT,
    `extraction_date`      date           DEFAULT NULL,
    `year`                 varchar(10)    DEFAULT NULL,
    `period`               varchar(10)    DEFAULT NULL,
    `version`              varchar(50)    DEFAULT NULL,
    `scenario`             varchar(100)   DEFAULT NULL,
    `currency_code`        varchar(10)    DEFAULT NULL,
    `source`               varchar(100)   DEFAULT NULL,
    `product`              varchar(50)    DEFAULT NULL,
    `legal_entity`         varchar(100)   DEFAULT NULL,
    `legal_entity_desc`    varchar(100)   DEFAULT NULL,
    `pccode_co`            varchar(50)    DEFAULT NULL,
    `pccode_co_desc`       varchar(100)   DEFAULT NULL,
    `account`              varchar(50)    DEFAULT NULL,
    `account_desc`         varchar(100)   DEFAULT NULL,
    `data_value`           decimal(20, 9) DEFAULT NULL,
    `country_code`         varchar(20)    DEFAULT NULL,
    `platform_index`       varchar(20)    DEFAULT NULL,
    `biz_tech_ind`         varchar(100)   DEFAULT NULL,
    `pc_type`              varchar(100)   DEFAULT NULL,
    `planning_center`      varchar(100)   DEFAULT NULL,
    `gl_category`          varchar(100)   DEFAULT NULL,
    `platform_gl`          varchar(100)   DEFAULT NULL,
    `budget_gl`            varchar(100)   DEFAULT NULL,
    `cost_type`            varchar(100)   DEFAULT NULL,
    `cost_type_active_ind` varchar(20)    DEFAULT NULL,
    `hyp_level_0_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_3_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_4_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_5_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_6_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_7_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_8_desc`     varchar(100)   DEFAULT NULL,
    `hyp_level_9_desc`     varchar(100)   DEFAULT NULL,
    `gl_level_0_desc`      varchar(100)   DEFAULT NULL,
    `gl_level_8_desc`      varchar(100)   DEFAULT NULL,
    `gl_level_9_desc`      varchar(100)   DEFAULT NULL,
    `gl_level_10_desc`     varchar(100)   DEFAULT NULL,
    `gl_level_11_desc`     varchar(100)   DEFAULT NULL,
    `gl_level_12_desc`     varchar(100)   DEFAULT NULL,
    `gl_level_13_desc`     varchar(100)   DEFAULT NULL,
    `gl_level_14_desc`     varchar(100)   DEFAULT NULL,
    `created_by`           varchar(100)   DEFAULT NULL,
    `date_created`         datetime       DEFAULT NULL,
    `modified_by`          varchar(100)   DEFAULT NULL,
    `date_modified`        datetime       DEFAULT NULL,
    PRIMARY KEY (`hypacct_surr_id`),
    KEY `pccode_co` (`pccode_co`),
    KEY `legal_entity_desc` (`legal_entity_desc`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `stg_psgl`
(
    `stg_psgl_surr_id`      int(11) NOT NULL AUTO_INCREMENT,
    `extraction_date`       date           DEFAULT NULL,
    `biz_unit`              varchar(10)    DEFAULT NULL,
    `journal_id`            varchar(50)    DEFAULT NULL,
    `journal_date`          date           DEFAULT NULL,
    `unpost_seq`            int(11)        DEFAULT NULL,
    `journal_line`          int(11)        DEFAULT NULL,
    `ledger`                varchar(50)    DEFAULT NULL,
    `speedchart_key`        varchar(50)    DEFAULT NULL,
    `speedtype_key`         varchar(50)    DEFAULT NULL,
    `account`               varchar(50)    DEFAULT NULL,
    `alt_acct`              varchar(50)    DEFAULT NULL,
    `dept_id`               varchar(10)    DEFAULT NULL,
    `operating_unit`        varchar(10)    DEFAULT NULL,
    `product`               varchar(50)    DEFAULT NULL,
    `fund_code`             varchar(50)    DEFAULT NULL,
    `class_fld`             varchar(10)    DEFAULT NULL,
    `program_code`          varchar(10)    DEFAULT NULL,
    `budget_ref`            varchar(10)    DEFAULT NULL,
    `affiliate`             varchar(10)    DEFAULT NULL,
    `affiliate_intra1`      varchar(10)    DEFAULT NULL,
    `affiliate_intra2`      varchar(10)    DEFAULT NULL,
    `chartfield1`           varchar(10)    DEFAULT NULL,
    `chartfield2`           varchar(10)    DEFAULT NULL,
    `chartfield3`           varchar(10)    DEFAULT NULL,
    `book_code`             varchar(50)    DEFAULT NULL,
    `gl_adjust_type`        varchar(50)    DEFAULT NULL,
    `budget_period`         varchar(50)    DEFAULT NULL,
    `scenario`              varchar(50)    DEFAULT NULL,
    `currency_code`         varchar(10)    DEFAULT NULL,
    `biz_unit_pc`           varchar(10)    DEFAULT NULL,
    `project_id`            varchar(50)    DEFAULT NULL,
    `activity_id`           varchar(50)    DEFAULT NULL,
    `resource_type`         varchar(50)    DEFAULT NULL,
    `resource_category`     varchar(50)    DEFAULT NULL,
    `resource_sub_cat`      varchar(50)    DEFAULT NULL,
    `analysis_type`         varchar(50)    DEFAULT NULL,
    `statistics_code`       varchar(50)    DEFAULT NULL,
    `monetary_amt`          decimal(20, 9) DEFAULT NULL,
    `movement_flag`         varchar(10)    DEFAULT NULL,
    `statistic_amt`         decimal(20, 9) DEFAULT NULL,
    `journal_line_ref`      varchar(50)    DEFAULT NULL,
    `suspended_line`        varchar(50)    DEFAULT NULL,
    `line_desc`             varchar(100)   DEFAULT NULL,
    `line_desc_2_dbs`       varchar(100)   DEFAULT NULL,
    `line_desc_3_dbs`       varchar(100)   DEFAULT NULL,
    `line_desc_4_dbs`       varchar(100)   DEFAULT NULL,
    `line_desc_5_dbs`       varchar(100)   DEFAULT NULL,
    `line_desc_6_dbs`       varchar(100)   DEFAULT NULL,
    `line_desc_7_dbs`       varchar(100)   DEFAULT NULL,
    `journal_line_status`   varchar(10)    DEFAULT NULL,
    `journal_line_date`     date           DEFAULT NULL,
    `foreign_ccy`           varchar(10)    DEFAULT NULL,
    `rt_type`               varchar(10)    DEFAULT NULL,
    `foreign_amt`           decimal(20, 9) DEFAULT NULL,
    `rate_div`              decimal(20, 9) DEFAULT NULL,
    `rate_mult`             decimal(20, 9) DEFAULT NULL,
    `process_instance`      varchar(50)    DEFAULT NULL,
    `doc_type`              varchar(10)    DEFAULT NULL,
    `doc_seq_nbr`           varchar(10)    DEFAULT NULL,
    `doc_seq_date`          date           DEFAULT NULL,
    `doc_seq_status`        varchar(10)    DEFAULT NULL,
    `journal_line_source`   varchar(10)    DEFAULT NULL,
    `budget_date`           date           DEFAULT NULL,
    `budget_line_status`    varchar(10)    DEFAULT NULL,
    `settlement_date`       date           DEFAULT NULL,
    `date_code`             varchar(10)    DEFAULT NULL,
    `closing_status`        varchar(10)    DEFAULT NULL,
    `entry_event`           varchar(10)    DEFAULT NULL,
    `ee_proc_status`        varchar(10)    DEFAULT NULL,
    `journal_line_gfee`     varchar(10)    DEFAULT NULL,
    `iu_tran_grp_nbr`       varchar(10)    DEFAULT NULL,
    `iu_anchor_flag`        varchar(10)    DEFAULT NULL,
    `pc_distrib_status`     varchar(10)    DEFAULT NULL,
    `source_id`             varchar(10)    DEFAULT NULL,
    `source_data`           varchar(50)    DEFAULT NULL,
    `tas_gwa`               varchar(10)    DEFAULT NULL,
    `betc_cd`               varchar(10)    DEFAULT NULL,
    `journal_line_orig_src` varchar(50)    DEFAULT NULL,
    `account_code`          varchar(10)    DEFAULT NULL,
    `posted_date`           date           DEFAULT NULL,
    `source`                varchar(100)   DEFAULT NULL,
    `created_by`            varchar(100)   DEFAULT NULL,
    `date_created`          date           DEFAULT NULL,
    `modified_by`           varchar(100)   DEFAULT NULL,
    `date_modified`         date           DEFAULT NULL,
    PRIMARY KEY (`stg_psgl_surr_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `stg_psgl_error_log`
(
    `stg_psgl_surr_id`      int(11) NOT NULL AUTO_INCREMENT,
    `biz_unit`              varchar(10)    DEFAULT NULL,
    `journal_id`            varchar(50)    DEFAULT NULL,
    `journal_date`          varchar(100)   DEFAULT NULL,
    `unpost_seq`            int(11)        DEFAULT NULL,
    `journal_line`          int(11)        DEFAULT NULL,
    `ledger`                varchar(50)    DEFAULT NULL,
    `speedchart_key`        varchar(50)    DEFAULT NULL,
    `speedtype_key`         varchar(50)    DEFAULT NULL,
    `account`               varchar(50)    DEFAULT NULL,
    `alt_acct`              varchar(50)    DEFAULT NULL,
    `dept_id`               varchar(10)    DEFAULT NULL,
    `operating_unit`        varchar(10)    DEFAULT NULL,
    `product`               varchar(50)    DEFAULT NULL,
    `fund_code`             varchar(50)    DEFAULT NULL,
    `class_fld`             varchar(10)    DEFAULT NULL,
    `program_code`          varchar(10)    DEFAULT NULL,
    `budget_ref`            varchar(10)    DEFAULT NULL,
    `affiliate`             varchar(10)    DEFAULT NULL,
    `affiliate_intra1`      varchar(10)    DEFAULT NULL,
    `affiliate_intra2`      varchar(10)    DEFAULT NULL,
    `chartfield1`           varchar(10)    DEFAULT NULL,
    `chartfield2`           varchar(10)    DEFAULT NULL,
    `chartfield3`           varchar(10)    DEFAULT NULL,
    `book_code`             varchar(50)    DEFAULT NULL,
    `gl_adjust_type`        varchar(50)    DEFAULT NULL,
    `budget_period`         varchar(50)    DEFAULT NULL,
    `scenario`              varchar(50)    DEFAULT NULL,
    `currency_code`         varchar(10)    DEFAULT NULL,
    `biz_unit_pc`           varchar(10)    DEFAULT NULL,
    `project_id`            varchar(50)    DEFAULT NULL,
    `activity_id`           varchar(50)    DEFAULT NULL,
    `resource_type`         varchar(50)    DEFAULT NULL,
    `resource_category`     varchar(50)    DEFAULT NULL,
    `resource_sub_cat`      varchar(50)    DEFAULT NULL,
    `analysis_type`         varchar(50)    DEFAULT NULL,
    `statistics_code`       varchar(50)    DEFAULT NULL,
    `monetary_amt`          decimal(20, 9) DEFAULT NULL,
    `movement_flag`         varchar(10)    DEFAULT NULL,
    `statistic_amt`         decimal(20, 9) DEFAULT NULL,
    `journal_line_ref`      varchar(50)    DEFAULT NULL,
    `suspended_line`        varchar(50)    DEFAULT NULL,
    `line_desc`             varchar(100)   DEFAULT NULL,
    `line_desc_2_dbs`       varchar(100)   DEFAULT NULL,
    `line_desc_3_dbs`       varchar(100)   DEFAULT NULL,
    `line_desc_4_dbs`       varchar(100)   DEFAULT NULL,
    `line_desc_5_dbs`       varchar(100)   DEFAULT NULL,
    `line_desc_6_dbs`       varchar(100)   DEFAULT NULL,
    `line_desc_7_dbs`       varchar(100)   DEFAULT NULL,
    `journal_line_status`   varchar(10)    DEFAULT NULL,
    `journal_line_date`     varchar(100)   DEFAULT NULL,
    `foreign_ccy`           varchar(10)    DEFAULT NULL,
    `rt_type`               varchar(10)    DEFAULT NULL,
    `foreign_amt`           decimal(20, 9) DEFAULT NULL,
    `rate_div`              decimal(20, 9) DEFAULT NULL,
    `rate_mult`             decimal(20, 9) DEFAULT NULL,
    `process_instance`      varchar(50)    DEFAULT NULL,
    `doc_type`              varchar(10)    DEFAULT NULL,
    `doc_seq_nbr`           varchar(10)    DEFAULT NULL,
    `doc_seq_date`          varchar(100)   DEFAULT NULL,
    `doc_seq_status`        varchar(10)    DEFAULT NULL,
    `journal_line_source`   varchar(10)    DEFAULT NULL,
    `budget_date`           varchar(100)   DEFAULT NULL,
    `budget_line_status`    varchar(10)    DEFAULT NULL,
    `settlement_date`       varchar(100)   DEFAULT NULL,
    `date_code`             varchar(10)    DEFAULT NULL,
    `closing_status`        varchar(10)    DEFAULT NULL,
    `entry_event`           varchar(10)    DEFAULT NULL,
    `ee_proc_status`        varchar(10)    DEFAULT NULL,
    `journal_line_gfee`     varchar(10)    DEFAULT NULL,
    `iu_tran_grp_nbr`       varchar(10)    DEFAULT NULL,
    `iu_anchor_flag`        varchar(10)    DEFAULT NULL,
    `pc_distrib_status`     varchar(10)    DEFAULT NULL,
    `source_id`             varchar(10)    DEFAULT NULL,
    `source_data`           varchar(50)    DEFAULT NULL,
    `tas_gwa`               varchar(10)    DEFAULT NULL,
    `betc_cd`               varchar(10)    DEFAULT NULL,
    `journal_line_orig_src` varchar(50)    DEFAULT NULL,
    `account_code`          varchar(10)    DEFAULT NULL,
    `posted_date`           varchar(100)   DEFAULT NULL,
    `source`                varchar(10)    DEFAULT NULL,
    `error_msg`             varchar(1000)  DEFAULT NULL,
    `created_by`            varchar(100)   DEFAULT NULL,
    `date_created`          date           DEFAULT NULL,
    `modified_by`           varchar(100)   DEFAULT NULL,
    `date_modified`         date           DEFAULT NULL,
    PRIMARY KEY (`stg_psgl_surr_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `stg_psam`
(
    `stg_psam_surr_id`    int(11) NOT NULL AUTO_INCREMENT,
    `biz_unit`            varchar(10)    DEFAULT NULL,
    `pc`                  varchar(10)    DEFAULT NULL,
    `category`            varchar(100)   DEFAULT NULL,
    `profile`             varchar(100)   DEFAULT NULL,
    `descr`               varchar(1000)  DEFAULT NULL,
    `life`                int(11)        DEFAULT NULL,
    `in_service_date`     date           DEFAULT NULL,
    `end_depr_date`       date           DEFAULT NULL,
    `cost`                decimal(20, 9) DEFAULT NULL,
    `accum_depr`          decimal(20, 9) DEFAULT NULL,
    `nbv`                 decimal(20, 9) DEFAULT NULL,
    `ytd_depr`            decimal(20, 9) DEFAULT NULL,
    `current_period_depr` decimal(20, 9) DEFAULT NULL,
    `asset_id`            varchar(100)   DEFAULT NULL,
    `manufacturer`        varchar(100)   DEFAULT NULL,
    `tag_number`          varchar(100)   DEFAULT NULL,
    `payment_date`        date           DEFAULT NULL,
    `serial_id`           varchar(100)   DEFAULT NULL,
    `model`               varchar(100)   DEFAULT NULL,
    `quantity`            int(11)        DEFAULT NULL,
    `invoice_number`      varchar(100)   DEFAULT NULL,
    `project_id`          varchar(100)   DEFAULT NULL,
    `project_descr`       varchar(1000)  DEFAULT NULL,
    `as_of_date`          date           DEFAULT NULL,
    `acccount`            varchar(50)    DEFAULT NULL,
    `accum_acct`          varchar(50)    DEFAULT NULL,
    `asset_class`         varchar(100)   DEFAULT NULL,
    `location`            varchar(10)    DEFAULT NULL,
    `created_by`          varchar(100)   DEFAULT NULL,
    `date_created`        date           DEFAULT NULL,
    `modified_by`         varchar(100)   DEFAULT NULL,
    `date_modified`       date           DEFAULT NULL,
    PRIMARY KEY (`stg_psam_surr_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `stg_psam_error_log`
(
    `stg_psam_surr_id`    int(11) NOT NULL AUTO_INCREMENT,
    `biz_unit`            varchar(10)    DEFAULT NULL,
    `pc`                  varchar(10)    DEFAULT NULL,
    `category`            varchar(100)   DEFAULT NULL,
    `profile`             varchar(100)   DEFAULT NULL,
    `descr`               varchar(1000)  DEFAULT NULL,
    `life`                int(11)        DEFAULT NULL,
    `in_service_date`     varchar(20)    DEFAULT NULL,
    `end_depr_date`       varchar(20)    DEFAULT NULL,
    `cost`                decimal(20, 9) DEFAULT NULL,
    `accum_depr`          decimal(20, 9) DEFAULT NULL,
    `nbv`                 decimal(20, 9) DEFAULT NULL,
    `ytd_depr`            decimal(20, 9) DEFAULT NULL,
    `current_period_depr` decimal(20, 9) DEFAULT NULL,
    `asset_id`            varchar(100)   DEFAULT NULL,
    `manufacturer`        varchar(100)   DEFAULT NULL,
    `tag_number`          varchar(100)   DEFAULT NULL,
    `payment_date`        varchar(20)    DEFAULT NULL,
    `serial_id`           varchar(100)   DEFAULT NULL,
    `model`               varchar(100)   DEFAULT NULL,
    `quantity`            int(11)        DEFAULT NULL,
    `invoice_number`      varchar(100)   DEFAULT NULL,
    `project_id`          varchar(100)   DEFAULT NULL,
    `project_descr`       varchar(1000)  DEFAULT NULL,
    `as_of_date`          varchar(20)    DEFAULT NULL,
    `acccount`            varchar(50)    DEFAULT NULL,
    `accum_acct`          varchar(50)    DEFAULT NULL,
    `asset_class`         varchar(100)   DEFAULT NULL,
    `location`            varchar(10)    DEFAULT NULL,
    `error_msg`           varchar(1000)  DEFAULT NULL,
    `created_by`          varchar(100)   DEFAULT NULL,
    `date_created`        date           DEFAULT NULL,
    `modified_by`         varchar(100)   DEFAULT NULL,
    `date_modified`       date           DEFAULT NULL,
    PRIMARY KEY (`stg_psam_surr_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `stg_hyperion_acct`
(
    `stg_hypacct_surr_id` int(11) NOT NULL AUTO_INCREMENT,
    `extraction_date`     date           DEFAULT NULL,
    `year`                varchar(10)    DEFAULT NULL,
    `period`              varchar(10)    DEFAULT NULL,
    `version`             varchar(50)    DEFAULT NULL,
    `scenario`            varchar(100)   DEFAULT NULL,
    `currency_code`       varchar(10)    DEFAULT NULL,
    `source`              varchar(100)   DEFAULT NULL,
    `product`             varchar(50)    DEFAULT NULL,
    `legal_entity`        varchar(100)   DEFAULT NULL,
    `legal_entity_desc`   varchar(100)   DEFAULT NULL,
    `pccode_co`           varchar(50)    DEFAULT NULL,
    `pccode_co_desc`      varchar(100)   DEFAULT NULL,
    `account`             varchar(50)    DEFAULT NULL,
    `account_desc`        varchar(100)   DEFAULT NULL,
    `data_value`          decimal(20, 9) DEFAULT NULL,
    `created_by`          varchar(100)   DEFAULT NULL,
    `date_created`        date           DEFAULT NULL,
    `modified_by`         varchar(100)   DEFAULT NULL,
    `date_modified`       date           DEFAULT NULL,
    PRIMARY KEY (`stg_hypacct_surr_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `stg_hyperion_acct_error_log`
(
    `stg_hypacct_surr_id` int(11) NOT NULL AUTO_INCREMENT,
    `year`                varchar(10)    DEFAULT NULL,
    `period`              varchar(10)    DEFAULT NULL,
    `version`             varchar(50)    DEFAULT NULL,
    `scenario`            varchar(100)   DEFAULT NULL,
    `currency_code`       varchar(10)    DEFAULT NULL,
    `source`              varchar(100)   DEFAULT NULL,
    `product`             varchar(50)    DEFAULT NULL,
    `legal_entity`        varchar(100)   DEFAULT NULL,
    `legal_entity_desc`   varchar(100)   DEFAULT NULL,
    `pccode_co`           varchar(50)    DEFAULT NULL,
    `pccode_co_desc`      varchar(100)   DEFAULT NULL,
    `account`             varchar(50)    DEFAULT NULL,
    `account_desc`        varchar(100)   DEFAULT NULL,
    `data_value`          decimal(20, 9) DEFAULT NULL,
    `error_msg`           varchar(50)    DEFAULT NULL,
    `created_by`          varchar(100)   DEFAULT NULL,
    `date_created`        date           DEFAULT NULL,
    `modified_by`         varchar(100)   DEFAULT NULL,
    `date_modified`       date           DEFAULT NULL,
    PRIMARY KEY (`stg_hypacct_surr_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;



CREATE OR REPLACE TABLE `employee_rate`
(
    `emp_rate_surr_id`     int(11)     NOT NULL AUTO_INCREMENT,
    `1bank_id`             varchar(50) NOT NULL,
    `rate_card_id`         int(11)      DEFAULT NULL,
    `effective_start_date` datetime     DEFAULT NULL,
    `effective_end_date`   datetime     DEFAULT NULL,
    `created_by`           varchar(100) DEFAULT NULL,
    `date_created`         datetime     DEFAULT NULL,
    `modified_by`          varchar(100) DEFAULT NULL,
    `date_modified`        datetime     DEFAULT NULL,
    `rate_card_code`       varchar(50)  DEFAULT NULL,
    PRIMARY KEY (`emp_rate_surr_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;



-- Data exporting was unselected.
-- Dumping structure for table gene_uat.portfolio_profile_aud
CREATE OR REPLACE TABLE `portfolio_profile_aud`
(
    `port_surr_id`               int(11) NOT NULL,
    `REV`                        int(11) NOT NULL,
    `REVTYPE`                    tinyint(4)   DEFAULT NULL,
    `agile_waterfall`            varchar(255) DEFAULT NULL,
    `agile_waterfall_MOD`        bit(1)       DEFAULT NULL,
    `biz_segment`                varchar(255) DEFAULT NULL,
    `biz_segment_MOD`            bit(1)       DEFAULT NULL,
    `budget_status`              varchar(255) DEFAULT NULL,
    `budget_status_MOD`          bit(1)       DEFAULT NULL,
    `budget_system_owner`        varchar(255) DEFAULT NULL,
    `budget_system_owner_MOD`    bit(1)       DEFAULT NULL,
    `horizon`                    varchar(255) DEFAULT NULL,
    `horizon_MOD`                bit(1)       DEFAULT NULL,
    `initiation_year`            varchar(255) DEFAULT NULL,
    `initiation_year_MOD`        bit(1)       DEFAULT NULL,
    `planning_cycle`             varchar(255) DEFAULT NULL,
    `planning_cycle_MOD`         bit(1)       DEFAULT NULL,
    `platform_name`              varchar(255) DEFAULT NULL,
    `platform_name_MOD`          bit(1)       DEFAULT NULL,
    `portfolio_desc`             varchar(255) DEFAULT NULL,
    `portfolio_desc_MOD`         bit(1)       DEFAULT NULL,
    `portfolio_id`               varchar(255) DEFAULT NULL,
    `portfolio_id_MOD`           bit(1)       DEFAULT NULL,
    `portfolio_name`             varchar(255) DEFAULT NULL,
    `portfolio_name_MOD`         bit(1)       DEFAULT NULL,
    `portfolio_reference_id`     varchar(255) DEFAULT NULL,
    `portfolio_reference_id_MOD` bit(1)       DEFAULT NULL,
    `primary_platform_index`     varchar(255) DEFAULT NULL,
    `primary_platform_index_MOD` bit(1)       DEFAULT NULL,
    `primary_platform_name`      varchar(255) DEFAULT NULL,
    `primary_platform_name_MOD`  bit(1)       DEFAULT NULL,
    `reporting_flag`             varchar(255) DEFAULT NULL,
    `reporting_flag_MOD`         bit(1)       DEFAULT NULL,
    `requestor_1bank_id`         varchar(255) DEFAULT NULL,
    `requestor_1bank_id_MOD`     bit(1)       DEFAULT NULL,
    `requestor_name`             varchar(255) DEFAULT NULL,
    `requestor_name_MOD`         bit(1)       DEFAULT NULL,
    `thematic`                   varchar(255) DEFAULT NULL,
    `thematic_MOD`               bit(1)       DEFAULT NULL,
    `work_type`                  varchar(255) DEFAULT NULL,
    `work_type_MOD`              bit(1)       DEFAULT NULL,
    PRIMARY KEY (`port_surr_id`, `REV`),
    KEY `FKrtju08uhw5upj9vgj4xadlhqf` (`REV`),
    CONSTRAINT `FKrtju08uhw5upj9vgj4xadlhqf` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;


-- Dumping structure for table gene_uat.sub_workstream_dates_aud
CREATE OR REPLACE TABLE `sub_workstream_dates_aud`
(
    `sws_dt_surr_id`          int(11) NOT NULL,
    `REV`                     int(11) NOT NULL,
    `REVTYPE`                 tinyint(4)   DEFAULT NULL,
    `active_ind`              varchar(255) DEFAULT NULL,
    `active_ind_MOD`          bit(1)       DEFAULT NULL,
    `approval_date`           date         DEFAULT NULL,
    `approval_date_MOD`       bit(1)       DEFAULT NULL,
    `date_type`               varchar(255) DEFAULT NULL,
    `date_type_MOD`           bit(1)       DEFAULT NULL,
    `depre_start_date`        date         DEFAULT NULL,
    `depre_start_date_MOD`    bit(1)       DEFAULT NULL,
    `end_date`                date         DEFAULT NULL,
    `end_date_MOD`            bit(1)       DEFAULT NULL,
    `go_live_date`            date         DEFAULT NULL,
    `go_live_date_MOD`        bit(1)       DEFAULT NULL,
    `scenario_name`           varchar(255) DEFAULT NULL,
    `scenario_name_MOD`       bit(1)       DEFAULT NULL,
    `start_date`              date         DEFAULT NULL,
    `start_date_MOD`          bit(1)       DEFAULT NULL,
    `sub_workstream_id`       varchar(255) DEFAULT NULL,
    `sub_workstream_id_MOD`   bit(1)       DEFAULT NULL,
    `sub_workstream_name`     varchar(255) DEFAULT NULL,
    `sub_workstream_name_MOD` bit(1)       DEFAULT NULL,
    `sw_eng_start_date`       date         DEFAULT NULL,
    `sw_eng_start_date_MOD`   bit(1)       DEFAULT NULL,
    `workstream_id`           varchar(255) DEFAULT NULL,
    `workstream_id_MOD`       bit(1)       DEFAULT NULL,
    PRIMARY KEY (`sws_dt_surr_id`, `REV`),
    KEY `FKdvmufct5auo39cr9guhgx0k37` (`REV`),
    CONSTRAINT `FKdvmufct5auo39cr9guhgx0k37` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;

-- Data exporting was unselected.
-- Dumping structure for table gene_uat.sub_workstream_hardware_cost_aud
CREATE OR REPLACE TABLE `sub_workstream_hardware_cost_aud`
(
    `sws_hw_surr_id`           int(11) NOT NULL,
    `REV`                      int(11) NOT NULL,
    `REVTYPE`                  tinyint(4)     DEFAULT NULL,
    `active_ind`               varchar(255)   DEFAULT NULL,
    `active_ind_MOD`           bit(1)         DEFAULT NULL,
    `add_hardware`             varchar(255)   DEFAULT NULL,
    `add_hardware_MOD`         bit(1)         DEFAULT NULL,
    `capex_opex_surr_id`       int(11)        DEFAULT NULL,
    `capex_opex_surr_id_MOD`   bit(1)         DEFAULT NULL,
    `cost_per_month_gcy`       decimal(19, 2) DEFAULT NULL,
    `cost_per_month_gcy_MOD`   bit(1)         DEFAULT NULL,
    `cost_per_month_lcy`       decimal(19, 2) DEFAULT NULL,
    `cost_per_month_lcy_MOD`   bit(1)         DEFAULT NULL,
    `cost_settings`            varchar(255)   DEFAULT NULL,
    `cost_settings_MOD`        bit(1)         DEFAULT NULL,
    `cost_type_detail`         varchar(255)   DEFAULT NULL,
    `cost_type_detail_MOD`     bit(1)         DEFAULT NULL,
    `driver_detail`            varchar(255)   DEFAULT NULL,
    `driver_detail_MOD`        bit(1)         DEFAULT NULL,
    `effective_end_date`       datetime(6)    DEFAULT NULL,
    `effective_end_date_MOD`   bit(1)         DEFAULT NULL,
    `effective_start_date`     datetime(6)    DEFAULT NULL,
    `effective_start_date_MOD` bit(1)         DEFAULT NULL,
    `gl_category`              varchar(255)   DEFAULT NULL,
    `gl_category_MOD`          bit(1)         DEFAULT NULL,
    `group_ccy`                varchar(255)   DEFAULT NULL,
    `group_ccy_MOD`            bit(1)         DEFAULT NULL,
    `hw_cost`                  decimal(19, 2) DEFAULT NULL,
    `hw_cost_MOD`              bit(1)         DEFAULT NULL,
    `hw_descr`                 varchar(255)   DEFAULT NULL,
    `hw_descr_MOD`             bit(1)         DEFAULT NULL,
    `itc_rate`                 decimal(19, 2) DEFAULT NULL,
    `itc_rate_MOD`             bit(1)         DEFAULT NULL,
    `local_ccy`                varchar(255)   DEFAULT NULL,
    `local_ccy_MOD`            bit(1)         DEFAULT NULL,
    `original_ind`             varchar(255)   DEFAULT NULL,
    `original_ind_MOD`         bit(1)         DEFAULT NULL,
    `period`                   varchar(255)   DEFAULT NULL,
    `period_MOD`               bit(1)         DEFAULT NULL,
    `quantity`                 decimal(19, 2) DEFAULT NULL,
    `quantity_MOD`             bit(1)         DEFAULT NULL,
    `ref_hw_cost_surr_id`      int(11)        DEFAULT NULL,
    `ref_hw_cost_surr_id_MOD`  bit(1)         DEFAULT NULL,
    `scenario`                 varchar(255)   DEFAULT NULL,
    `scenario_MOD`             bit(1)         DEFAULT NULL,
    `sub_workstream_id`        varchar(255)   DEFAULT NULL,
    `sub_workstream_id_MOD`    bit(1)         DEFAULT NULL,
    `sub_workstream_name`      varchar(255)   DEFAULT NULL,
    `sub_workstream_name_MOD`  bit(1)         DEFAULT NULL,
    `tower`                    varchar(255)   DEFAULT NULL,
    `tower_MOD`                bit(1)         DEFAULT NULL,
    `uom`                      varchar(255)   DEFAULT NULL,
    `uom_MOD`                  bit(1)         DEFAULT NULL,
    `workstream_id`            varchar(255)   DEFAULT NULL,
    `workstream_id_MOD`        bit(1)         DEFAULT NULL,
    PRIMARY KEY (`sws_hw_surr_id`, `REV`),
    KEY `FKj4y3l24tits7q6kotxrvq035y` (`REV`),
    CONSTRAINT `FKj4y3l24tits7q6kotxrvq035y` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `sub_workstream_other_cost_aud`
(
    `sws_other_surr_id`         int(11) NOT NULL,
    `REV`                       int(11) NOT NULL,
    `REVTYPE`                   tinyint(4)     DEFAULT NULL,
    `active_ind`                varchar(255)   DEFAULT NULL,
    `active_ind_MOD`            bit(1)         DEFAULT NULL,
    `add_other`                 varchar(255)   DEFAULT NULL,
    `add_other_MOD`             bit(1)         DEFAULT NULL,
    `capex_opex_surr_id`        int(11)        DEFAULT NULL,
    `capex_opex_surr_id_MOD`    bit(1)         DEFAULT NULL,
    `cost_settings`             varchar(255)   DEFAULT NULL,
    `cost_settings_MOD`         bit(1)         DEFAULT NULL,
    `cost_type_detail`          varchar(255)   DEFAULT NULL,
    `cost_type_detail_MOD`      bit(1)         DEFAULT NULL,
    `effective_end_date`        datetime(6)    DEFAULT NULL,
    `effective_end_date_MOD`    bit(1)         DEFAULT NULL,
    `effective_start_date`      datetime(6)    DEFAULT NULL,
    `effective_start_date_MOD`  bit(1)         DEFAULT NULL,
    `gl_category`               varchar(255)   DEFAULT NULL,
    `gl_category_MOD`           bit(1)         DEFAULT NULL,
    `group_ccy`                 varchar(255)   DEFAULT NULL,
    `group_ccy_MOD`             bit(1)         DEFAULT NULL,
    `group_ccy_val`             decimal(19, 2) DEFAULT NULL,
    `group_ccy_val_MOD`         bit(1)         DEFAULT NULL,
    `local_ccy`                 varchar(255)   DEFAULT NULL,
    `local_ccy_MOD`             bit(1)         DEFAULT NULL,
    `local_ccy_val`             decimal(19, 2) DEFAULT NULL,
    `local_ccy_val_MOD`         bit(1)         DEFAULT NULL,
    `original_ind`              varchar(255)   DEFAULT NULL,
    `original_ind_MOD`          bit(1)         DEFAULT NULL,
    `other_descr`               varchar(255)   DEFAULT NULL,
    `other_descr_MOD`           bit(1)         DEFAULT NULL,
    `period`                    varchar(255)   DEFAULT NULL,
    `period_MOD`                bit(1)         DEFAULT NULL,
    `quantity`                  decimal(19, 2) DEFAULT NULL,
    `quantity_MOD`              bit(1)         DEFAULT NULL,
    `ref_sws_other_surr_id`     int(11)        DEFAULT NULL,
    `ref_sws_other_surr_id_MOD` bit(1)         DEFAULT NULL,
    `scenario`                  varchar(255)   DEFAULT NULL,
    `scenario_MOD`              bit(1)         DEFAULT NULL,
    `sub_workstream_id`         varchar(255)   DEFAULT NULL,
    `sub_workstream_id_MOD`     bit(1)         DEFAULT NULL,
    `sub_workstream_name`       varchar(255)   DEFAULT NULL,
    `sub_workstream_name_MOD`   bit(1)         DEFAULT NULL,
    `type`                      varchar(255)   DEFAULT NULL,
    `type_MOD`                  bit(1)         DEFAULT NULL,
    `vendor_name`               varchar(255)   DEFAULT NULL,
    `vendor_name_MOD`           bit(1)         DEFAULT NULL,
    `workstream_id`             varchar(255)   DEFAULT NULL,
    `workstream_id_MOD`         bit(1)         DEFAULT NULL,
    PRIMARY KEY (`sws_other_surr_id`, `REV`),
    KEY `FK51cviftym98sxmkqb4pd2gel2` (`REV`),
    CONSTRAINT `FK51cviftym98sxmkqb4pd2gel2` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `sub_workstream_profile_aud`
(
    `subws_surr_id`           int(11) NOT NULL,
    `REV`                     int(11) NOT NULL,
    `REVTYPE`                 tinyint(4)    DEFAULT NULL,
    `app_code`                varchar(255)  DEFAULT NULL,
    `app_code_MOD`            bit(1)        DEFAULT NULL,
    `app_code_desc`           varchar(255)  DEFAULT NULL,
    `app_code_desc_MOD`       bit(1)        DEFAULT NULL,
    `category`                varchar(255)  DEFAULT NULL,
    `category_MOD`            bit(1)        DEFAULT NULL,
    `country`                 varchar(255)  DEFAULT NULL,
    `country_MOD`             bit(1)        DEFAULT NULL,
    `delivery_unit`           varchar(255)  DEFAULT NULL,
    `delivery_unit_MOD`       bit(1)        DEFAULT NULL,
    `platform_unit`           varchar(255)  DEFAULT NULL,
    `platform_unit_MOD`       bit(1)        DEFAULT NULL,
    `product_code`            varchar(255)  DEFAULT NULL,
    `product_code_MOD`        bit(1)        DEFAULT NULL,
    `product_code_desc`       varchar(255)  DEFAULT NULL,
    `product_code_desc_MOD`   bit(1)        DEFAULT NULL,
    `sub_platform_name`       varchar(255)  DEFAULT NULL,
    `sub_platform_name_MOD`   bit(1)        DEFAULT NULL,
    `sub_workstream_desc`     varchar(1000) DEFAULT NULL,
    `sub_workstream_desc_MOD` bit(1)        DEFAULT NULL,
    `sub_workstream_id`       varchar(255)  DEFAULT NULL,
    `sub_workstream_id_MOD`   bit(1)        DEFAULT NULL,
    `sub_workstream_name`     varchar(255)  DEFAULT NULL,
    `sub_workstream_name_MOD` bit(1)        DEFAULT NULL,
    `sub_workstream_ref`      varchar(255)  DEFAULT NULL,
    `sub_workstream_ref_MOD`  bit(1)        DEFAULT NULL,
    `workstream_id`           varchar(255)  DEFAULT NULL,
    `workstream_id_MOD`       bit(1)        DEFAULT NULL,
    `workstream_ref_id`       int(11)       DEFAULT NULL,
    `workstream_ref_id_MOD`   bit(1)        DEFAULT NULL,
    `work_type`               varchar(255)  DEFAULT NULL,
    `work_type_MOD`           bit(1)        DEFAULT NULL,
    PRIMARY KEY (`subws_surr_id`, `REV`),
    KEY `FKi8jgwuiesb63m7wcwysyx1yjx` (`REV`),
    CONSTRAINT `FKi8jgwuiesb63m7wcwysyx1yjx` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `sub_workstream_resource_cost_aud`
(
    `sws_resource_surr_id`         int(11) NOT NULL,
    `REV`                          int(11) NOT NULL,
    `REVTYPE`                      tinyint(4)     DEFAULT NULL,
    `active_ind`                   varchar(255)   DEFAULT NULL,
    `active_ind_MOD`               bit(1)         DEFAULT NULL,
    `add_resource`                 varchar(255)   DEFAULT NULL,
    `add_resource_MOD`             bit(1)         DEFAULT NULL,
    `allocation_pct`               decimal(19, 2) DEFAULT NULL,
    `allocation_pct_MOD`           bit(1)         DEFAULT NULL,
    `blended_cost_gcy`             decimal(19, 2) DEFAULT NULL,
    `blended_cost_gcy_MOD`         bit(1)         DEFAULT NULL,
    `blended_cost_lcy`             decimal(19, 2) DEFAULT NULL,
    `blended_cost_lcy_MOD`         bit(1)         DEFAULT NULL,
    `capex_opex_surr_id`           int(11)        DEFAULT NULL,
    `capex_opex_surr_id_MOD`       bit(1)         DEFAULT NULL,
    `cost_settings`                varchar(255)   DEFAULT NULL,
    `cost_settings_MOD`            bit(1)         DEFAULT NULL,
    `effective_end_date`           datetime(6)    DEFAULT NULL,
    `effective_end_date_MOD`       bit(1)         DEFAULT NULL,
    `effective_start_date`         datetime(6)    DEFAULT NULL,
    `effective_start_date_MOD`     bit(1)         DEFAULT NULL,
    `fte`                          decimal(19, 2) DEFAULT NULL,
    `fte_MOD`                      bit(1)         DEFAULT NULL,
    `gl_category`                  varchar(255)   DEFAULT NULL,
    `gl_category_MOD`              bit(1)         DEFAULT NULL,
    `group_ccy`                    varchar(255)   DEFAULT NULL,
    `group_ccy_MOD`                bit(1)         DEFAULT NULL,
    `local_ccy`                    varchar(255)   DEFAULT NULL,
    `local_ccy_MOD`                bit(1)         DEFAULT NULL,
    `location`                     varchar(255)   DEFAULT NULL,
    `location_MOD`                 bit(1)         DEFAULT NULL,
    `original_ind`                 varchar(255)   DEFAULT NULL,
    `original_ind_MOD`             bit(1)         DEFAULT NULL,
    `period`                       varchar(255)   DEFAULT NULL,
    `period_MOD`                   bit(1)         DEFAULT NULL,
    `platform_index`               varchar(255)   DEFAULT NULL,
    `platform_index_MOD`           bit(1)         DEFAULT NULL,
    `rate_source`                  varchar(255)   DEFAULT NULL,
    `rate_source_MOD`              bit(1)         DEFAULT NULL,
    `ref_sws_resource_surr_id`     int(11)        DEFAULT NULL,
    `ref_sws_resource_surr_id_MOD` bit(1)         DEFAULT NULL,
    `resource_type`                varchar(255)   DEFAULT NULL,
    `resource_type_MOD`            bit(1)         DEFAULT NULL,
    `scenario`                     varchar(255)   DEFAULT NULL,
    `scenario_MOD`                 bit(1)         DEFAULT NULL,
    `staff_level`                  varchar(255)   DEFAULT NULL,
    `staff_level_MOD`              bit(1)         DEFAULT NULL,
    `staff_type`                   varchar(255)   DEFAULT NULL,
    `staff_type_MOD`               bit(1)         DEFAULT NULL,
    `sub_workstream_id`            varchar(255)   DEFAULT NULL,
    `sub_workstream_id_MOD`        bit(1)         DEFAULT NULL,
    `sub_workstream_name`          varchar(255)   DEFAULT NULL,
    `sub_workstream_name_MOD`      bit(1)         DEFAULT NULL,
    `team_code`                    varchar(255)   DEFAULT NULL,
    `team_code_MOD`                bit(1)         DEFAULT NULL,
    `team_name`                    varchar(255)   DEFAULT NULL,
    `team_name_MOD`                bit(1)         DEFAULT NULL,
    `team_role`                    varchar(255)   DEFAULT NULL,
    `team_role_MOD`                bit(1)         DEFAULT NULL,
    `vendor`                       varchar(255)   DEFAULT NULL,
    `vendor_MOD`                   bit(1)         DEFAULT NULL,
    `workstream_id`                varchar(255)   DEFAULT NULL,
    `workstream_id_MOD`            bit(1)         DEFAULT NULL,
    PRIMARY KEY (`sws_resource_surr_id`, `REV`),
    KEY `FKfxcpodami56q5lgsibdobnebg` (`REV`),
    CONSTRAINT `FKfxcpodami56q5lgsibdobnebg` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;

CREATE OR REPLACE TABLE `sub_workstream_software_cost_aud`
(
    `sw_cost_surr_id`          int(11) NOT NULL,
    `REV`                      int(11) NOT NULL,
    `REVTYPE`                  tinyint(4)     DEFAULT NULL,
    `active_ind`               varchar(255)   DEFAULT NULL,
    `active_ind_MOD`           bit(1)         DEFAULT NULL,
    `add_software`             varchar(255)   DEFAULT NULL,
    `add_software_MOD`         bit(1)         DEFAULT NULL,
    `capex_opex_surr_id`       int(11)        DEFAULT NULL,
    `capex_opex_surr_id_MOD`   bit(1)         DEFAULT NULL,
    `cost_per_month_gcy`       decimal(19, 2) DEFAULT NULL,
    `cost_per_month_gcy_MOD`   bit(1)         DEFAULT NULL,
    `cost_per_month_lcy`       decimal(19, 2) DEFAULT NULL,
    `cost_per_month_lcy_MOD`   bit(1)         DEFAULT NULL,
    `cost_settings`            varchar(255)   DEFAULT NULL,
    `cost_settings_MOD`        bit(1)         DEFAULT NULL,
    `cost_type_detail`         varchar(255)   DEFAULT NULL,
    `cost_type_detail_MOD`     bit(1)         DEFAULT NULL,
    `effective_end_date`       datetime(6)    DEFAULT NULL,
    `effective_end_date_MOD`   bit(1)         DEFAULT NULL,
    `effective_start_date`     datetime(6)    DEFAULT NULL,
    `effective_start_date_MOD` bit(1)         DEFAULT NULL,
    `gl_category`              varchar(255)   DEFAULT NULL,
    `gl_category_MOD`          bit(1)         DEFAULT NULL,
    `group_ccy`                varchar(255)   DEFAULT NULL,
    `group_ccy_MOD`            bit(1)         DEFAULT NULL,
    `local_ccy`                varchar(255)   DEFAULT NULL,
    `local_ccy_MOD`            bit(1)         DEFAULT NULL,
    `original_ind`             varchar(255)   DEFAULT NULL,
    `original_ind_MOD`         bit(1)         DEFAULT NULL,
    `period`                   varchar(255)   DEFAULT NULL,
    `period_MOD`               bit(1)         DEFAULT NULL,
    `quantity`                 decimal(19, 2) DEFAULT NULL,
    `quantity_MOD`             bit(1)         DEFAULT NULL,
    `ref_sw_cost_surr_id`      int(11)        DEFAULT NULL,
    `ref_sw_cost_surr_id_MOD`  bit(1)         DEFAULT NULL,
    `scenario`                 varchar(255)   DEFAULT NULL,
    `scenario_MOD`             bit(1)         DEFAULT NULL,
    `software_desc`            varchar(255)   DEFAULT NULL,
    `software_desc_MOD`        bit(1)         DEFAULT NULL,
    `software_name`            varchar(255)   DEFAULT NULL,
    `software_name_MOD`        bit(1)         DEFAULT NULL,
    `software_type`            varchar(255)   DEFAULT NULL,
    `software_type_MOD`        bit(1)         DEFAULT NULL,
    `sub_workstream_id`        varchar(255)   DEFAULT NULL,
    `sub_workstream_id_MOD`    bit(1)         DEFAULT NULL,
    `sub_workstream_name`      varchar(255)   DEFAULT NULL,
    `sub_workstream_name_MOD`  bit(1)         DEFAULT NULL,
    `unit_price`               decimal(19, 2) DEFAULT NULL,
    `unit_price_MOD`           bit(1)         DEFAULT NULL,
    `vendor_name`              varchar(255)   DEFAULT NULL,
    `vendor_name_MOD`          bit(1)         DEFAULT NULL,
    `workstream_id`            varchar(255)   DEFAULT NULL,
    `workstream_id_MOD`        bit(1)         DEFAULT NULL,
    PRIMARY KEY (`sw_cost_surr_id`, `REV`),
    KEY `FKphvpw8g38c3ifpglaiac1u8li` (`REV`),
    CONSTRAINT `FKphvpw8g38c3ifpglaiac1u8li` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;

CREATE OR REPLACE TABLE `workstream_dates_aud`
(
    `ws_dt_surr_id`         int(11) NOT NULL,
    `REV`                   int(11) NOT NULL,
    `REVTYPE`               tinyint(4)   DEFAULT NULL,
    `active_ind`            varchar(255) DEFAULT NULL,
    `active_ind_MOD`        bit(1)       DEFAULT NULL,
    `approval_date`         date         DEFAULT NULL,
    `approval_date_MOD`     bit(1)       DEFAULT NULL,
    `date_type`             varchar(255) DEFAULT NULL,
    `date_type_MOD`         bit(1)       DEFAULT NULL,
    `end_date`              date         DEFAULT NULL,
    `end_date_MOD`          bit(1)       DEFAULT NULL,
    `go_live_date`          date         DEFAULT NULL,
    `go_live_date_MOD`      bit(1)       DEFAULT NULL,
    `portfolio_id`          varchar(255) DEFAULT NULL,
    `portfolio_id_MOD`      bit(1)       DEFAULT NULL,
    `scenario_name`         varchar(255) DEFAULT NULL,
    `scenario_name_MOD`     bit(1)       DEFAULT NULL,
    `start_date`            date         DEFAULT NULL,
    `start_date_MOD`        bit(1)       DEFAULT NULL,
    `sw_eng_start_date`     date         DEFAULT NULL,
    `sw_eng_start_date_MOD` bit(1)       DEFAULT NULL,
    `workstream_id`         varchar(255) DEFAULT NULL,
    `workstream_id_MOD`     bit(1)       DEFAULT NULL,
    PRIMARY KEY (`ws_dt_surr_id`, `REV`),
    KEY `FK9u5hlgrvrb0ljlgs7lfsu9gc9` (`REV`),
    CONSTRAINT `FK9u5hlgrvrb0ljlgs7lfsu9gc9` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;

CREATE OR REPLACE TABLE `workstream_profile_aud`
(
    `ws_surr_id`                   int(11) NOT NULL,
    `REV`                          int(11) NOT NULL,
    `REVTYPE`                      tinyint(4)    DEFAULT NULL,
    `agile_waterfall_ind`          varchar(255)  DEFAULT NULL,
    `agile_waterfall_ind_MOD`      bit(1)        DEFAULT NULL,
    `biz_segment`                  varchar(255)  DEFAULT NULL,
    `biz_segment_MOD`              bit(1)        DEFAULT NULL,
    `category`                     varchar(255)  DEFAULT NULL,
    `category_MOD`                 bit(1)        DEFAULT NULL,
    `country`                      varchar(255)  DEFAULT NULL,
    `country_MOD`                  bit(1)        DEFAULT NULL,
    `horizon`                      varchar(255)  DEFAULT NULL,
    `horizon_MOD`                  bit(1)        DEFAULT NULL,
    `le_pccode_build`              varchar(255)  DEFAULT NULL,
    `le_pccode_build_MOD`          bit(1)        DEFAULT NULL,
    `le_pccode_operate`            varchar(255)  DEFAULT NULL,
    `le_pccode_operate_MOD`        bit(1)        DEFAULT NULL,
    `overall_risk_level`           varchar(255)  DEFAULT NULL,
    `overall_risk_level_MOD`       bit(1)        DEFAULT NULL,
    `portfolio_id`                 varchar(255)  DEFAULT NULL,
    `portfolio_id_MOD`             bit(1)        DEFAULT NULL,
    `sub_platform_name`            varchar(255)  DEFAULT NULL,
    `sub_platform_name_MOD`        bit(1)        DEFAULT NULL,
    `thematic`                     varchar(255)  DEFAULT NULL,
    `thematic_MOD`                 bit(1)        DEFAULT NULL,
    `value_benefit`                varchar(255)  DEFAULT NULL,
    `value_benefit_MOD`            bit(1)        DEFAULT NULL,
    `value_benefit_start_date`     date          DEFAULT NULL,
    `value_benefit_start_date_MOD` bit(1)        DEFAULT NULL,
    `work_phase`                   varchar(255)  DEFAULT NULL,
    `work_phase_MOD`               bit(1)        DEFAULT NULL,
    `work_status`                  varchar(255)  DEFAULT NULL,
    `work_status_MOD`              bit(1)        DEFAULT NULL,
    `workstream_desc`              varchar(1000) DEFAULT NULL,
    `workstream_desc_MOD`          bit(1)        DEFAULT NULL,
    `workstream_id`                varchar(255)  DEFAULT NULL,
    `workstream_id_MOD`            bit(1)        DEFAULT NULL,
    `workstream_name`              varchar(255)  DEFAULT NULL,
    `workstream_name_MOD`          bit(1)        DEFAULT NULL,
    `workstream_ref`               varchar(255)  DEFAULT NULL,
    `workstream_ref_MOD`           bit(1)        DEFAULT NULL,
    `sub_work_stream_entities_mod` bit(1)        DEFAULT NULL,
    PRIMARY KEY (`ws_surr_id`, `REV`),
    KEY `FK6g2sa88moqupqa34llgmm2i2g` (`REV`),
    CONSTRAINT `FK6g2sa88moqupqa34llgmm2i2g` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;



CREATE OR REPLACE TABLE `edit_log`
(
    `edit_id`            int(11) NOT NULL AUTO_INCREMENT,
    `portfolio_id`       varchar(100) DEFAULT NULL,
    `portfolio_type`     varchar(100) DEFAULT NULL,
    `portfolio_name`     varchar(100) DEFAULT NULL,
    `staff_display_name` varchar(100) DEFAULT NULL,
    `created_by`         varchar(100) DEFAULT NULL,
    `date_created`       datetime     DEFAULT NULL,
    `modified_by`        varchar(100) DEFAULT NULL,
    `date_modified`      datetime     DEFAULT NULL,
    PRIMARY KEY (`edit_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;



CREATE OR REPLACE TABLE `work_stream_entity_sub_work_stream_entity_aud`
(
    `REV`               int(11) NOT NULL,
    `workstream_ref_id` int(11) NOT NULL,
    `subws_surr_id`     int(11) NOT NULL,
    `REVTYPE`           tinyint(4) DEFAULT NULL,
    PRIMARY KEY (`REV`, `workstream_ref_id`, `subws_surr_id`),
    CONSTRAINT `FKpylr2rxq1g80d2mybm544pbml` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;


CREATE OR REPLACE TABLE `work_stream_entity_workstream_le_pccodes_entity_aud`
(
    `REV`                 int(11) NOT NULL,
    `ws_lepccodes_ref_id` int(11) NOT NULL,
    `ws_pccode_surr_id`   int(11) NOT NULL,
    `REVTYPE`             tinyint(4) DEFAULT NULL,
    PRIMARY KEY (`REV`, `ws_lepccodes_ref_id`, `ws_pccode_surr_id`),
    CONSTRAINT `FK536owojkn1p257lthjwyaq966` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;

CREATE OR REPLACE TABLE `xref_gl_account_tree`
(
    `gl_acct_surr_id`      int(11) NOT NULL AUTO_INCREMENT,
    `gl_acct`              varchar(50)  DEFAULT NULL,
    `gl_acct_desc`         varchar(100) DEFAULT NULL,
    `l1_node`              varchar(100) DEFAULT NULL,
    `l1_desc`              varchar(100) DEFAULT NULL,
    `l2_node`              varchar(100) DEFAULT NULL,
    `l2_desc`              varchar(100) DEFAULT NULL,
    `l3_node`              varchar(100) DEFAULT NULL,
    `l3_desc`              varchar(100) DEFAULT NULL,
    `l4_node`              varchar(100) DEFAULT NULL,
    `l4_desc`              varchar(100) DEFAULT NULL,
    `l5_node`              varchar(100) DEFAULT NULL,
    `l5_desc`              varchar(100) DEFAULT NULL,
    `l6_node`              varchar(100) DEFAULT NULL,
    `l6_desc`              varchar(100) DEFAULT NULL,
    `l7_node`              varchar(100) DEFAULT NULL,
    `l7_desc`              varchar(100) DEFAULT NULL,
    `l8_node`              varchar(100) DEFAULT NULL,
    `l8_desc`              varchar(100) DEFAULT NULL,
    `l9_node`              varchar(100) DEFAULT NULL,
    `l9_desc`              varchar(100) DEFAULT NULL,
    `l10_node`             varchar(100) DEFAULT NULL,
    `l10_desc`             varchar(100) DEFAULT NULL,
    `l11_node`             varchar(100) DEFAULT NULL,
    `l11_desc`             varchar(100) DEFAULT NULL,
    `l12_node`             varchar(100) DEFAULT NULL,
    `l12_desc`             varchar(100) DEFAULT NULL,
    `l13_node`             varchar(100) DEFAULT NULL,
    `l13_desc`             varchar(100) DEFAULT NULL,
    `l14_node`             varchar(100) DEFAULT NULL,
    `l14_desc`             varchar(100) DEFAULT NULL,
    `gl_category`          varchar(100) DEFAULT NULL,
    `platform_gl`          varchar(100) DEFAULT NULL,
    `budget_gl`            varchar(100) DEFAULT NULL,
    `cost_type`            varchar(100) DEFAULT NULL,
    `as_of_date`           date         DEFAULT NULL,
    `created_by`           varchar(100) DEFAULT NULL,
    `date_created`         datetime     DEFAULT NULL,
    `modified_by`          varchar(100) DEFAULT NULL,
    `date_modified`        datetime     DEFAULT NULL,
    `cost_type_active_ind` varchar(20)  DEFAULT NULL,
    PRIMARY KEY (`gl_acct_surr_id`),
    KEY `gl_acct` (`gl_acct`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;

CREATE OR REPLACE TABLE `xref_gl_account_tree`
(
    `gl_acct_surr_id`      int(11) NOT NULL AUTO_INCREMENT,
    `gl_acct`              varchar(50)  DEFAULT NULL,
    `gl_acct_desc`         varchar(100) DEFAULT NULL,
    `l1_node`              varchar(100) DEFAULT NULL,
    `l1_desc`              varchar(100) DEFAULT NULL,
    `l2_node`              varchar(100) DEFAULT NULL,
    `l2_desc`              varchar(100) DEFAULT NULL,
    `l3_node`              varchar(100) DEFAULT NULL,
    `l3_desc`              varchar(100) DEFAULT NULL,
    `l4_node`              varchar(100) DEFAULT NULL,
    `l4_desc`              varchar(100) DEFAULT NULL,
    `l5_node`              varchar(100) DEFAULT NULL,
    `l5_desc`              varchar(100) DEFAULT NULL,
    `l6_node`              varchar(100) DEFAULT NULL,
    `l6_desc`              varchar(100) DEFAULT NULL,
    `l7_node`              varchar(100) DEFAULT NULL,
    `l7_desc`              varchar(100) DEFAULT NULL,
    `l8_node`              varchar(100) DEFAULT NULL,
    `l8_desc`              varchar(100) DEFAULT NULL,
    `l9_node`              varchar(100) DEFAULT NULL,
    `l9_desc`              varchar(100) DEFAULT NULL,
    `l10_node`             varchar(100) DEFAULT NULL,
    `l10_desc`             varchar(100) DEFAULT NULL,
    `l11_node`             varchar(100) DEFAULT NULL,
    `l11_desc`             varchar(100) DEFAULT NULL,
    `l12_node`             varchar(100) DEFAULT NULL,
    `l12_desc`             varchar(100) DEFAULT NULL,
    `l13_node`             varchar(100) DEFAULT NULL,
    `l13_desc`             varchar(100) DEFAULT NULL,
    `l14_node`             varchar(100) DEFAULT NULL,
    `l14_desc`             varchar(100) DEFAULT NULL,
    `gl_category`          varchar(100) DEFAULT NULL,
    `platform_gl`          varchar(100) DEFAULT NULL,
    `budget_gl`            varchar(100) DEFAULT NULL,
    `cost_type`            varchar(100) DEFAULT NULL,
    `as_of_date`           date         DEFAULT NULL,
    `created_by`           varchar(100) DEFAULT NULL,
    `date_created`         datetime     DEFAULT NULL,
    `modified_by`          varchar(100) DEFAULT NULL,
    `date_modified`        datetime     DEFAULT NULL,
    `cost_type_active_ind` varchar(20)  DEFAULT NULL,
    PRIMARY KEY (`gl_acct_surr_id`),
    KEY `gl_acct` (`gl_acct`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;

  create or replace view vw_rpt_monthly_pf as

select distinct
	d.country,
	a.portfolio_id,
	portfolio_name,
	portfolio_desc,
	initiation_year,
	a.work_type,
	c.scenario,
	primary_platform_index,

	(select distinct platform_unit
	from xref_platform_master
	where platform_index=primary_platform_index
	and b.effective_end_date is null) as platform_unit,

	primary_platform_name,
	biz_segment,
	thematic,
	horizon,
	a.agile_waterfall,
	portfolio_reference_id,
	budget_status,
	planning_cycle,
	budget_system_owner,
	(select group_concat(distinct staff_name)
		from vw_work_managers c
		where role='BUSU'
		and c.portfolio_id=a.portfolio_id
		order by staff_name) as pf_work_manager_bu,
	(select group_concat(distinct staff_name)
		from vw_work_managers c
		where role='Technology'
		and c.portfolio_id=a.portfolio_id
		order by staff_name) as pf_work_manager_tech,
	gl_group,
	c.gl_category,
	c.cost_type,
	ccy_code,
	concat(sum(jan_year_1),'|',c.scenario) as jan_year_1,
	concat(sum(feb_year_1),'|',c.scenario) as feb_year_1,
	concat(sum(mar_year_1),'|',c.scenario) as mar_year_1,
	concat(sum(apr_year_1),'|',c.scenario) as apr_year_1,
	concat(sum(may_year_1),'|',c.scenario) as may_year_1,
	concat(sum(jun_year_1),'|',c.scenario) as jun_year_1,
	concat(sum(jul_year_1),'|',c.scenario) as jul_year_1,
	concat(sum(aug_year_1),'|',c.scenario) as aug_year_1,
	concat(sum(sep_year_1),'|',c.scenario) as sep_year_1,
	concat(sum(oct_year_1),'|',c.scenario) as oct_year_1,
	concat(sum(nov_year_1),'|',c.scenario) as nov_year_1,
	concat(sum(dec_year_1),'|',c.scenario) as dec_year_1,
	concat(sum(jan_year_2),'|',c.scenario) as jan_year_2,
	concat(sum(feb_year_2),'|',c.scenario) as feb_year_2,
	concat(sum(mar_year_2),'|',c.scenario) as mar_year_2,
	concat(sum(apr_year_2),'|',c.scenario) as apr_year_2,
	concat(sum(may_year_2),'|',c.scenario) as may_year_2,
	concat(sum(jun_year_2),'|',c.scenario) as jun_year_2,
	concat(sum(jul_year_2),'|',c.scenario) as jul_year_2,
	concat(sum(aug_year_2),'|',c.scenario) as aug_year_2,
	concat(sum(sep_year_2),'|',c.scenario) as sep_year_2,
	concat(sum(oct_year_2),'|',c.scenario) as oct_year_2,
	concat(sum(nov_year_2),'|',c.scenario) as nov_year_2,
	concat(sum(dec_year_2),'|',c.scenario) as dec_year_2,
	concat(sum(jan_year_3),'|',c.scenario) as jan_year_3,
	concat(sum(feb_year_3),'|',c.scenario) as feb_year_3,
	concat(sum(mar_year_3),'|',c.scenario) as mar_year_3,
	concat(sum(apr_year_3),'|',c.scenario) as apr_year_3,
	concat(sum(may_year_3),'|',c.scenario) as may_year_3,
	concat(sum(jun_year_3),'|',c.scenario) as jun_year_3,
	concat(sum(jul_year_3),'|',c.scenario) as jul_year_3,
	concat(sum(aug_year_3),'|',c.scenario) as aug_year_3,
	concat(sum(sep_year_3),'|',c.scenario) as sep_year_3,
	concat(sum(oct_year_3),'|',c.scenario) as oct_year_3,
	concat(sum(nov_year_3),'|',c.scenario) as nov_year_3,
	concat(sum(dec_year_3),'|',c.scenario) as dec_year_3,
	concat(sum(jan_year_4),'|',c.scenario) as jan_year_4,
	concat(sum(feb_year_4),'|',c.scenario) as feb_year_4,
	concat(sum(mar_year_4),'|',c.scenario) as mar_year_4,
	concat(sum(apr_year_4),'|',c.scenario) as apr_year_4,
	concat(sum(may_year_4),'|',c.scenario) as may_year_4,
	concat(sum(jun_year_4),'|',c.scenario) as jun_year_4,
	concat(sum(jul_year_4),'|',c.scenario) as jul_year_4,
	concat(sum(aug_year_4),'|',c.scenario) as aug_year_4,
	concat(sum(sep_year_4),'|',c.scenario) as sep_year_4,
	concat(sum(oct_year_4),'|',c.scenario) as oct_year_4,
	concat(sum(nov_year_4),'|',c.scenario) as nov_year_4,
	concat(sum(dec_year_4),'|',c.scenario) as dec_year_4,
	concat(sum(jan_year_5),'|',c.scenario) as jan_year_5,
	concat(sum(feb_year_5),'|',c.scenario) as feb_year_5,
	concat(sum(mar_year_5),'|',c.scenario) as mar_year_5,
	concat(sum(apr_year_5),'|',c.scenario) as apr_year_5,
	concat(sum(may_year_5),'|',c.scenario) as may_year_5,
	concat(sum(jun_year_5),'|',c.scenario) as jun_year_5,
	concat(sum(jul_year_5),'|',c.scenario) as jul_year_5,
	concat(sum(aug_year_5),'|',c.scenario) as aug_year_5,
	concat(sum(sep_year_5),'|',c.scenario) as sep_year_5,
	concat(sum(oct_year_5),'|',c.scenario) as oct_year_5,
	concat(sum(nov_year_5),'|',c.scenario) as nov_year_5,
	concat(sum(dec_year_5),'|',c.scenario) as dec_year_5,
	concat(sum(jan_year_6),'|',c.scenario) as jan_year_6,
	concat(sum(feb_year_6),'|',c.scenario) as feb_year_6,
	concat(sum(mar_year_6),'|',c.scenario) as mar_year_6,
	concat(sum(apr_year_6),'|',c.scenario) as apr_year_6,
	concat(sum(may_year_6),'|',c.scenario) as may_year_6,
	concat(sum(jun_year_6),'|',c.scenario) as jun_year_6,
	concat(sum(jul_year_6),'|',c.scenario) as jul_year_6,
	concat(sum(aug_year_6),'|',c.scenario) as aug_year_6,
	concat(sum(sep_year_6),'|',c.scenario) as sep_year_6,
	concat(sum(oct_year_6),'|',c.scenario) as oct_year_6,
	concat(sum(nov_year_6),'|',c.scenario) as nov_year_6,
	concat(sum(dec_year_6),'|',c.scenario) as dec_year_6,
	concat(sum(jan_year_7),'|',c.scenario) as jan_year_7,
	concat(sum(feb_year_7),'|',c.scenario) as feb_year_7,
	concat(sum(mar_year_7),'|',c.scenario) as mar_year_7,
	concat(sum(apr_year_7),'|',c.scenario) as apr_year_7,
	concat(sum(may_year_7),'|',c.scenario) as may_year_7,
	concat(sum(jun_year_7),'|',c.scenario) as jun_year_7,
	concat(sum(jul_year_7),'|',c.scenario) as jul_year_7,
	concat(sum(aug_year_7),'|',c.scenario) as aug_year_7,
	concat(sum(sep_year_7),'|',c.scenario) as sep_year_7,
	concat(sum(oct_year_7),'|',c.scenario) as oct_year_7,
	concat(sum(nov_year_7),'|',c.scenario) as nov_year_7,
	concat(sum(dec_year_7),'|',c.scenario) as dec_year_7,
	concat(sum(jan_year_8),'|',c.scenario) as jan_year_8,
	concat(sum(feb_year_8),'|',c.scenario) as feb_year_8,
	concat(sum(mar_year_8),'|',c.scenario) as mar_year_8,
	concat(sum(apr_year_8),'|',c.scenario) as apr_year_8,
	concat(sum(may_year_8),'|',c.scenario) as may_year_8,
	concat(sum(jun_year_8),'|',c.scenario) as jun_year_8,
	concat(sum(jul_year_8),'|',c.scenario) as jul_year_8,
	concat(sum(aug_year_8),'|',c.scenario) as aug_year_8,
	concat(sum(sep_year_8),'|',c.scenario) as sep_year_8,
	concat(sum(oct_year_8),'|',c.scenario) as oct_year_8,
	concat(sum(nov_year_8),'|',c.scenario) as nov_year_8,
	concat(sum(dec_year_8),'|',c.scenario) as dec_year_8,
	concat(sum(total_amt),'|',c.scenario) as total_amt
from portfolio_profile a, xref_platform_master b, sws_backend_fin_details c, sub_workstream_profile d,
((select distinct b.refdata_value,if(b.refdata_value='OPEX',substring(b.refdata_desc,1,instr(b.refdata_desc,",")-1),b.refdata_desc) as gl_group
from xref_data_summary a, xref_data_values b
where a.refdata_name='GL Category'
and a.refdata_code=b.refdata_code) union
(select distinct b.refdata_value,substring(b.refdata_desc,instr(b.refdata_desc,",")+1,length(b.refdata_desc)) as gl_group
from xref_data_summary a, xref_data_values b
where a.refdata_name='GL Category'
and a.refdata_code=b.refdata_code
and b.refdata_value='OPEX')) as gl_groups
where
	a.reporting_flag='Yes'
	and a.portfolio_id=c.portfolio_id
	and refdata_value=c.gl_category
	and c.workstream_id=d.workstream_id

group by
	a.portfolio_id,
	portfolio_name,
	portfolio_desc,
	initiation_year,
	a.work_type,
	c.scenario,
	primary_platform_index,
	primary_platform_name,
	biz_segment,
	thematic,
	horizon,
	a.agile_waterfall,
	portfolio_reference_id,
	budget_status,
	planning_cycle,
	budget_system_owner,
	pf_work_manager_bu,
	pf_work_manager_tech,
	gl_group,
	c.gl_category,
	c.cost_type


create or replace view vw_rpt_sws_a_and_c_work as
select distinct
	a.sub_workstream_id,
	a.sub_workstream_name,
	a.sub_workstream_desc,
	a.country,
	a.delivery_unit,
	d.work_type,
	c.scenario,
	c.cost_settings,
	c.ccy_code,
	a.sub_workstream_ref,

	(select group_concat(staff_name)
		from vw_work_managers x
		where role='BUSU'
		and x.sub_workstream_id=a.sub_workstream_id
		order by staff_name) as sws_work_manager_bu,
	(select group_concat(staff_name)
		from vw_work_managers x
		where role='Technology'
		and x.sub_workstream_id=a.sub_workstream_id
		order by staff_name) as sws_work_manager_tech,

	b.start_date,
	b.sw_eng_start_date,
	b.go_live_date,

	gl_group,
	c.gl_category,
	c.cost_type,

	concat(sum(jan_year_1),'|',c.scenario) as jan_year_1,
	concat(sum(feb_year_1),'|',c.scenario) as feb_year_1,
	concat(sum(mar_year_1),'|',c.scenario) as mar_year_1,
	concat(sum(apr_year_1),'|',c.scenario) as apr_year_1,
	concat(sum(may_year_1),'|',c.scenario) as may_year_1,
	concat(sum(jun_year_1),'|',c.scenario) as jun_year_1,
	concat(sum(jul_year_1),'|',c.scenario) as jul_year_1,
	concat(sum(aug_year_1),'|',c.scenario) as aug_year_1,
	concat(sum(sep_year_1),'|',c.scenario) as sep_year_1,
	concat(sum(oct_year_1),'|',c.scenario) as oct_year_1,
	concat(sum(nov_year_1),'|',c.scenario) as nov_year_1,
	concat(sum(dec_year_1),'|',c.scenario) as dec_year_1,
	concat(sum(jan_year_2),'|',c.scenario) as jan_year_2,
	concat(sum(feb_year_2),'|',c.scenario) as feb_year_2,
	concat(sum(mar_year_2),'|',c.scenario) as mar_year_2,
	concat(sum(apr_year_2),'|',c.scenario) as apr_year_2,
	concat(sum(may_year_2),'|',c.scenario) as may_year_2,
	concat(sum(jun_year_2),'|',c.scenario) as jun_year_2,
	concat(sum(jul_year_2),'|',c.scenario) as jul_year_2,
	concat(sum(aug_year_2),'|',c.scenario) as aug_year_2,
	concat(sum(sep_year_2),'|',c.scenario) as sep_year_2,
	concat(sum(oct_year_2),'|',c.scenario) as oct_year_2,
	concat(sum(nov_year_2),'|',c.scenario) as nov_year_2,
	concat(sum(dec_year_2),'|',c.scenario) as dec_year_2,
	concat(sum(jan_year_3),'|',c.scenario) as jan_year_3,
	concat(sum(feb_year_3),'|',c.scenario) as feb_year_3,
	concat(sum(mar_year_3),'|',c.scenario) as mar_year_3,
	concat(sum(apr_year_3),'|',c.scenario) as apr_year_3,
	concat(sum(may_year_3),'|',c.scenario) as may_year_3,
	concat(sum(jun_year_3),'|',c.scenario) as jun_year_3,
	concat(sum(jul_year_3),'|',c.scenario) as jul_year_3,
	concat(sum(aug_year_3),'|',c.scenario) as aug_year_3,
	concat(sum(sep_year_3),'|',c.scenario) as sep_year_3,
	concat(sum(oct_year_3),'|',c.scenario) as oct_year_3,
	concat(sum(nov_year_3),'|',c.scenario) as nov_year_3,
	concat(sum(dec_year_3),'|',c.scenario) as dec_year_3,
	concat(sum(jan_year_4),'|',c.scenario) as jan_year_4,
	concat(sum(feb_year_4),'|',c.scenario) as feb_year_4,
	concat(sum(mar_year_4),'|',c.scenario) as mar_year_4,
	concat(sum(apr_year_4),'|',c.scenario) as apr_year_4,
	concat(sum(may_year_4),'|',c.scenario) as may_year_4,
	concat(sum(jun_year_4),'|',c.scenario) as jun_year_4,
	concat(sum(jul_year_4),'|',c.scenario) as jul_year_4,
	concat(sum(aug_year_4),'|',c.scenario) as aug_year_4,
	concat(sum(sep_year_4),'|',c.scenario) as sep_year_4,
	concat(sum(oct_year_4),'|',c.scenario) as oct_year_4,
	concat(sum(nov_year_4),'|',c.scenario) as nov_year_4,
	concat(sum(dec_year_4),'|',c.scenario) as dec_year_4,
	concat(sum(jan_year_5),'|',c.scenario) as jan_year_5,
	concat(sum(feb_year_5),'|',c.scenario) as feb_year_5,
	concat(sum(mar_year_5),'|',c.scenario) as mar_year_5,
	concat(sum(apr_year_5),'|',c.scenario) as apr_year_5,
	concat(sum(may_year_5),'|',c.scenario) as may_year_5,
	concat(sum(jun_year_5),'|',c.scenario) as jun_year_5,
	concat(sum(jul_year_5),'|',c.scenario) as jul_year_5,
	concat(sum(aug_year_5),'|',c.scenario) as aug_year_5,
	concat(sum(sep_year_5),'|',c.scenario) as sep_year_5,
	concat(sum(oct_year_5),'|',c.scenario) as oct_year_5,
	concat(sum(nov_year_5),'|',c.scenario) as nov_year_5,
	concat(sum(dec_year_5),'|',c.scenario) as dec_year_5,
	concat(sum(jan_year_6),'|',c.scenario) as jan_year_6,
	concat(sum(feb_year_6),'|',c.scenario) as feb_year_6,
	concat(sum(mar_year_6),'|',c.scenario) as mar_year_6,
	concat(sum(apr_year_6),'|',c.scenario) as apr_year_6,
	concat(sum(may_year_6),'|',c.scenario) as may_year_6,
	concat(sum(jun_year_6),'|',c.scenario) as jun_year_6,
	concat(sum(jul_year_6),'|',c.scenario) as jul_year_6,
	concat(sum(aug_year_6),'|',c.scenario) as aug_year_6,
	concat(sum(sep_year_6),'|',c.scenario) as sep_year_6,
	concat(sum(oct_year_6),'|',c.scenario) as oct_year_6,
	concat(sum(nov_year_6),'|',c.scenario) as nov_year_6,
	concat(sum(dec_year_6),'|',c.scenario) as dec_year_6,
	concat(sum(jan_year_7),'|',c.scenario) as jan_year_7,
	concat(sum(feb_year_7),'|',c.scenario) as feb_year_7,
	concat(sum(mar_year_7),'|',c.scenario) as mar_year_7,
	concat(sum(apr_year_7),'|',c.scenario) as apr_year_7,
	concat(sum(may_year_7),'|',c.scenario) as may_year_7,
	concat(sum(jun_year_7),'|',c.scenario) as jun_year_7,
	concat(sum(jul_year_7),'|',c.scenario) as jul_year_7,
	concat(sum(aug_year_7),'|',c.scenario) as aug_year_7,
	concat(sum(sep_year_7),'|',c.scenario) as sep_year_7,
	concat(sum(oct_year_7),'|',c.scenario) as oct_year_7,
	concat(sum(nov_year_7),'|',c.scenario) as nov_year_7,
	concat(sum(dec_year_7),'|',c.scenario) as dec_year_7,
	concat(sum(jan_year_8),'|',c.scenario) as jan_year_8,
	concat(sum(feb_year_8),'|',c.scenario) as feb_year_8,
	concat(sum(mar_year_8),'|',c.scenario) as mar_year_8,
	concat(sum(apr_year_8),'|',c.scenario) as apr_year_8,
	concat(sum(may_year_8),'|',c.scenario) as may_year_8,
	concat(sum(jun_year_8),'|',c.scenario) as jun_year_8,
	concat(sum(jul_year_8),'|',c.scenario) as jul_year_8,
	concat(sum(aug_year_8),'|',c.scenario) as aug_year_8,
	concat(sum(sep_year_8),'|',c.scenario) as sep_year_8,
	concat(sum(oct_year_8),'|',c.scenario) as oct_year_8,
	concat(sum(nov_year_8),'|',c.scenario) as nov_year_8,
	concat(sum(dec_year_8),'|',c.scenario) as dec_year_8,
	concat(sum(total_amt),'|',c.scenario) as total_amt
from sub_workstream_profile a, sub_workstream_dates b, sws_backend_fin_details c, portfolio_profile d, ((select distinct b.refdata_value,if(b.refdata_value='OPEX',substring(b.refdata_desc,1,instr(b.refdata_desc,",")-1),b.refdata_desc) as gl_group
from xref_data_summary a, xref_data_values b
where a.refdata_name='GL Category'
and a.refdata_code=b.refdata_code) union
(select distinct b.refdata_value,substring(b.refdata_desc,instr(b.refdata_desc,",")+1,length(b.refdata_desc)) as gl_group
from xref_data_summary a, xref_data_values b
where a.refdata_name='GL Category'
and a.refdata_code=b.refdata_code
and b.refdata_value='OPEX')) as gl_groups
where
	d.reporting_flag='Yes'
	and c.portfolio_id=d.portfolio_id
	and d.primary_platform_name<>a.delivery_unit
	and a.workstream_id=c.workstream_id
	and a.sub_workstream_id=c.sub_workstream_id
	and a.sub_workstream_name=c.sub_workstream_name
	and a.workstream_id=b.workstream_id
	and a.sub_workstream_id=b.sub_workstream_id
	and a.sub_workstream_name=b.sub_workstream_name
	and b.active_ind='True'
	and c.scenario=b.scenario_name
	and refdata_value=c.gl_category
group by
	a.sub_workstream_id,
	a.sub_workstream_name,
	a.sub_workstream_desc,
	a.delivery_unit,
	a.country,
	a.delivery_unit,
	d.work_type,
	c.scenario,
	c.cost_settings,
	c.ccy_code,
	a.sub_workstream_ref,

	sws_work_manager_bu,
	sws_work_manager_tech,

	gl_group,
	c.gl_category,
	c.cost_type



create or replace view vw_sws_hardware_cost as
select
	sub_workstream_id,
	sub_workstream_name,
	cost_settings,
	'Hardware' as cost_type,
	'Forecast' as cost_type_detail,
	gl_category,
	scenario,
	period,
	sum(ifnull(quantity,0)) as quantity,
	sum(ifnull(cost_per_month_lcy,0)) as cost_per_month_lcy,
	sum(ifnull(cost_per_month_gcy,0)) as cost_per_month_gcy
from sub_workstream_hardware_cost a
where original_ind='false'
and period > ifnull((select max(period) from sub_workstream_fin_details b
			  where a.sub_workstream_id=b.sub_workstream_id
			  and a.sub_workstream_name=b.sub_workstream_name
			  and substring(b.cost_type_detail,1,6)='Actual'),0)
group by
	sub_workstream_id,
	sub_workstream_name,
	cost_settings,
	cost_type,
	gl_category,
	scenario,
	period
union
select
	sub_workstream_id,
	sub_workstream_name,
	cost_settings,
	cost_type,
	cost_type_detail,
	gl_category,
	scenario,
	period,
	0 as quantity,
	sum(ifnull(local_ccy_val,0)) as cost_per_month_lcy,
	sum(ifnull(group_ccy_val,0)) as cost_per_month_gcy
from sub_workstream_fin_details a
where org_ind='false'
and cost_type='Hardware'
and period <= ifnull((select max(period) from sub_workstream_fin_details b
			  where a.sub_workstream_id=b.sub_workstream_id
			  and a.sub_workstream_name=b.sub_workstream_name
			  and substring(b.cost_type_detail,1,6)='Actual'),0)
group by
	sub_workstream_id,
	sub_workstream_name,
	cost_settings,
	cost_type,
	cost_type_detail,
	gl_category,
	scenario,
	period



create or replace view vw_sws_resource_cost as
select
	sub_workstream_id,
	sub_workstream_name,
	cost_settings,
	'Resource' as cost_type,
	'Forecast' as cost_type_detail,
	gl_category,
	scenario,
	period,
	sum(ifnull(fte,0)) as fte,
	sum(ifnull(blended_cost_lcy,0)) as blended_cost_lcy,
	sum(ifnull(blended_cost_gcy,0)) as blended_cost_gcy
from sub_workstream_resource_cost a
where original_ind='false'
and period > ifnull((select max(period) from sub_workstream_fin_details b
			  where a.sub_workstream_id=b.sub_workstream_id
			  and a.sub_workstream_name=b.sub_workstream_name
			  and substring(b.cost_type_detail,1,6)='Actual'),0)
group by
	sub_workstream_id,
	sub_workstream_name,
	cost_settings,
	gl_category,
	scenario,
	period
union
select
	sub_workstream_id,
	sub_workstream_name,
	cost_settings,
	cost_type,
	cost_type_detail,
	gl_category,
	scenario,
	period,
	0 as fte,
	sum(ifnull(local_ccy_val,0)) as blended_cost_lcy,
	sum(ifnull(group_ccy_val,0)) as blended_cost_gcy
from sub_workstream_fin_details a
where org_ind='false'
and cost_type='Resource'
and period <= ifnull((select max(period) from sub_workstream_fin_details b
			  where a.sub_workstream_id=b.sub_workstream_id
			  and a.sub_workstream_name=b.sub_workstream_name
			  and substring(b.cost_type_detail,1,6)='Actual'),0)
group by
	sub_workstream_id,
	sub_workstream_name,
	cost_settings,
	cost_type,
	cost_type_detail,
	gl_category,
	scenario,
	period

create or replace view vw_sws_software_cost as
select
	sub_workstream_id,
	sub_workstream_name,
	cost_settings,
	'Software' as cost_type,
	'Forecast' as cost_type_detail,
	gl_category,
	scenario,
	period,
	sum(ifnull(quantity,0)) as quantity,
	sum(ifnull(cost_per_month_lcy,0)) as cost_per_month_lcy,
	sum(ifnull(cost_per_month_gcy,0)) as cost_per_month_gcy
from sub_workstream_software_cost a
where original_ind='false'
and period > ifnull((select max(period) from sub_workstream_fin_details b
			  where a.sub_workstream_id=b.sub_workstream_id
			  and a.sub_workstream_name=b.sub_workstream_name
			  and substring(b.cost_type_detail,1,6)='Actual'),0)
group by
	sub_workstream_id,
	sub_workstream_name,
	cost_settings,
	cost_type,
	gl_category,
	scenario,
	period
union
select
	sub_workstream_id,
	sub_workstream_name,
	cost_settings,
	cost_type,
	cost_type_detail,
	gl_category,
	scenario,
	period,
	0 as quantity,
	sum(ifnull(local_ccy_val,0)) as cost_per_month_lcy,
	sum(ifnull(group_ccy_val,0)) as cost_per_month_gcy
from sub_workstream_fin_details a
where org_ind='false'
and cost_type='Software'
and period <= ifnull((select max(period) from sub_workstream_fin_details b
			  where a.sub_workstream_id=b.sub_workstream_id
			  and a.sub_workstream_name=b.sub_workstream_name
			  and substring(b.cost_type_detail,1,6)='Actual'),0)
group by
	sub_workstream_id,
	sub_workstream_name,
	cost_settings,
	cost_type,
	cost_type_detail,
	gl_category,
	scenario,
	period



create or replace view vw_work_managers as
select
	(select distinct portfolio_id
	from workstream_profile b
	where a.workstream_id=b.workstream_id) as portfolio_id,
	(select distinct workstream_id
	from workstream_profile b
	where a.workstream_id=b.workstream_id) as workstream_id,
	sub_workstream_id,
	1bank_id,
	staff_name,
	role,
	delegate_ind,
	active_ind,
	platform_index,
	email_address,
	effective_start_date,
	effective_end_date
from sub_workstream_managers a
where active_ind='True'
union
select
	portfolio_id,
	workstream_id,
	null as sub_workstream_id,
	1bank_id,
	staff_name,
	role,
	delegate_ind,
	active_ind,
	platform_index,
	email_address,
	effective_start_date,
	effective_end_date
from workstream_managers a
where active_ind='True'
union
select
	portfolio_id,
	null as workstream_id,
	null as sub_workstream_id,
	1bank_id,
	staff_name,
	role,
	delegate_ind,
	active_ind,
	platform_index,
	email_address,
	effective_start_date,
	effective_end_date
from portfolio_managers a
where active_ind='True'











