DELIMITER //
CREATE OR REPLACE PROCEDURE `sp_etl_hyperion_fin_details`()
BEGIN

    declare hyp_extraction_date date;

    set @hyp_extraction_date = (select max(extraction_date) from stg_hyperion_acct);

    delete from hyperion_fin_details
    where extraction_date=@hyp_extraction_date;

    INSERT INTO hyperion_fin_details (extraction_date, `year`, period, `version`, scenario, currency_code, source, product,
                                      legal_entity, legal_entity_desc, pccode_co, pccode_co_desc, account, account_desc, data_value,
                                      country_code,
                                      platform_index,
                                      biz_tech_ind,
                                      pc_type,
                                      planning_center,
                                      gl_category,
                                      platform_gl,
                                      budget_gl,
                                      cost_type,
                                      hyp_level_0_desc,
                                      hyp_level_3_desc,
                                      hyp_level_4_desc,
                                      hyp_level_5_desc,
                                      hyp_level_6_desc,
                                      hyp_level_7_desc,
                                      hyp_level_8_desc,
                                      hyp_level_9_desc,
                                      gl_level_0_desc,
                                      gl_level_8_desc,
                                      gl_level_9_desc,
                                      gl_level_10_desc,
                                      gl_level_11_desc,
                                      gl_level_12_desc,
                                      gl_level_13_desc,
                                      gl_level_14_desc,

                                      created_by,
                                      date_created
    )
    select
        extraction_date,
        concat('20',substring(`year`,3,2)) as `year`,
        lpad(month(str_to_date(period,'%M')),2,'0') as period,
        `version`,
        scenario,
        currency_code,
        source,
        product,
        a.legal_entity,
        a.legal_entity_desc,
        pccode_co,
        pccode_co_desc,
        account,
        account_desc,
        data_value,

        b.country_code as country_code,
        b.platform_index as platform_index,
        b.biz_tech_ind as biz_tech_ind,
        b.pc_type as pc_type,
        b.planning_centre as planning_center,
        c.gl_category as gl_category,
        c.platform_gl as platform_gl,
        c.budget_gl as budget_gl,
        c.cost_type as cost_type,

        b.le_pccode_desc as hyp_level_0_desc,
        b.l3_desc as hyp_level_3_desc,
        b.l4_desc as hyp_level_4_desc,
        b.l5_desc as hyp_level_5_desc,
        b.l6_desc as hyp_level_6_desc,
        b.l7_desc as hyp_level_7_desc,
        b.l8_desc as hyp_level_8_desc,
        b.l9_desc as hyp_level_9_desc,
        c.gl_acct_desc as gl_level_0_desc,
        c.l8_desc as gl_level_8_desc,
        c.l9_desc as gl_level_9_desc,
        c.l10_desc as gl_level_10_desc,
        c.l11_desc as gl_level_11_desc,
        c.l12_desc as gl_level_12_desc,
        c.l13_desc as gl_level_13_desc,
        c.l14_desc as gl_level_14_desc,

        'System' as created_by,
        now() as date_created
    from stg_hyperion_acct a,xref_le_pccode_tree b,xref_gl_account_tree c
    where extraction_date=@hyp_extraction_date
      and a.pccode_co=b.le_pccode
      and a.account=c.gl_acct ;


END//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_etl_hyperion_to_sws_fin_details`()
BEGIN

    declare hyp_extraction_date date;

    set @hyp_extraction_date = (select max(extraction_date) from stg_hyperion_acct);

    delete from sub_workstream_fin_details
    where cost_type_detail='Actual-Hyperion'
      and scenario='Forecast'
      and period in (select distinct concat(year,period)
                     from hyperion_fin_details
                     where extraction_date=@hyp_extraction_date);


    insert into sub_workstream_fin_details(
        workstream_id,
        sub_workstream_id,
        sub_workstream_name,
        scenario,
        gl_category,
        cost_type,
        cost_type_detail,
        period,
        cost_settings,
        local_ccy,
        group_ccy,
        local_ccy_val,
        group_ccy_val,
        org_ind,
        created_by,
        date_created)
    select
        b.workstream_id,
        b.sub_workstream_id,
        b.sub_workstream_name,
        c.scenario_name as scenario,
        a.gl_category,
        a.cost_type,
        'Actual-Hyperion' as cost_type_detail,
        concat(a.year,a.period) as period,
        'Financial Details' as cost_settings,
        refdata_desc as local_ccy,
        if(a.currency_code='R_SGD','SGD',null) as group_ccy,

        sum(ifnull(data_value*ifnull(d.allocation_pct,0)/100*ifnull((select 1/rate_val
                                                                     from exchange_rates
                                                                     where ccy_from='SGD'
                                                                       and ccy_to=refdata_desc
                                                                       and rate_period=concat(a.year,a.period)),0),0)) as local_ccy_val,

        sum(ifnull(data_value,0))*ifnull(d.allocation_pct,0)/100 as group_ccy_val,

        'False' as org_ind,
        'System' as created_by,
        now() as date_created

    from hyperion_fin_details a, map_work_to_pccode b, sub_workstream_dates c, workstream_le_pccodes d,
         (select distinct b.refdata_value, b.refdata_desc, b.status
          from xref_data_summary a, xref_data_values b
          where a.refdata_name='FD_HYP_Base CCY'
            and a.refdata_code=b.refdata_code
            and b.status='Active') as le_desc

    where b.build_operate='Build'
      and c.scenario_name='Forecast'
      and c.active_ind='True'
      and a.pccode_co=b.le_pccode
      and refdata_value=a.legal_entity_desc
      and b.sub_workstream_id=c.sub_workstream_id
      and b.sub_workstream_name=c.sub_workstream_name
      and b.workstream_id=d.workstream_id
      and b.le_pccode=d.le_pccode
      and d.active_ind='True'
    group by
        b.workstream_id,
        b.sub_workstream_id,
        b.sub_workstream_name,
        c.scenario_name,
        a.gl_category,
        a.cost_type,
        refdata_desc,
        concat(a.year,a.period);

END//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_etl_psgl_fin_details`()
BEGIN

    declare gl_extract_date varchar(10);

    set @gl_extract_date = (select max(extraction_date)
                            from stg_psgl,map_glsetid_to_hypleid
                            where biz_unit=gl_set_id);

    delete from psgl_fin_details
    where date(extraction_date)=date(@gl_extract_date);

    INSERT INTO psgl_fin_details (extraction_date,biz_unit, journal_id, journal_date, account, dept_id, product,
                                  currency_code, project_id, monetary_amt, journal_line_ref, line_desc, line_desc_2_dbs,
                                  line_desc_3_dbs, line_desc_4_dbs, line_desc_5_dbs, line_desc_6_dbs, line_desc_7_dbs,
                                  foreign_ccy, foreign_amt, posted_date,

                                  le_pccode,
                                  country_code,
                                  platform_index,
                                  biz_tech_ind,
                                  planning_center,
                                  gl_category,
                                  platform_gl,
                                  budget_gl,
                                  cost_type,
                                  hyp_level_0_desc,
                                  hyp_level_3_desc,
                                  hyp_level_4_desc,
                                  hyp_level_5_desc,
                                  hyp_level_6_desc,
                                  hyp_level_7_desc,
                                  hyp_level_8_desc,
                                  hyp_level_9_desc,
                                  gl_level_0_desc,
                                  gl_level_8_desc,
                                  gl_level_9_desc,
                                  gl_level_10_desc,
                                  gl_level_11_desc,
                                  gl_level_12_desc,
                                  gl_level_13_desc,
                                  gl_level_14_desc,

                                  created_by,
                                  date_created
    )
    select extraction_date, biz_unit, journal_id, journal_date, account, dept_id, product,
           currency_code, project_id, monetary_amt, journal_line_ref, line_desc, line_desc_2_dbs,
           line_desc_3_dbs, line_desc_4_dbs, line_desc_5_dbs, line_desc_6_dbs, line_desc_7_dbs,
           foreign_ccy, foreign_amt, posted_date,

           concat(d.hyperion_le_id,'_',a.dept_id) as le_pccode,
           b.country_code as country_code,
           b.platform_index as platform_index,
           b.biz_tech_ind as biz_tech_ind,
           b.planning_centre as planning_center,
           c.gl_category as gl_category,
           c.platform_gl as platform_gl,
           c.budget_gl as budget_gl,
           c.cost_type as cost_type,

           b.le_pccode_desc as hyp_level_0_desc,
           b.l3_desc as hyp_level_3_desc,
           b.l4_desc as hyp_level_4_desc,
           b.l5_desc as hyp_level_5_desc,
           b.l6_desc as hyp_level_6_desc,
           b.l7_desc as hyp_level_7_desc,
           b.l8_desc as hyp_level_8_desc,
           b.l9_desc as hyp_level_9_desc,
           c.gl_acct_desc as gl_level_0_desc,
           c.l8_desc as gl_level_8_desc,
           c.l9_desc as gl_level_9_desc,
           c.l10_desc as gl_level_10_desc,
           c.l11_desc as gl_level_11_desc,
           c.l12_desc as gl_level_12_desc,
           c.l13_desc as gl_level_13_desc,
           c.l14_desc as gl_level_14_desc,

           'System' as created_by,
           now() as date_created
    from stg_psgl a,xref_le_pccode_tree b,xref_gl_account_tree c,map_glsetid_to_hypleid d
    where line_desc<>'TRF'
      and date(extraction_date)=date(@gl_extract_date)
      and b.le_pccode=concat(d.hyperion_le_id,'_',a.dept_id)
      and a.biz_unit=d.gl_set_id
      and a.account=c.gl_acct;


END//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_etl_psgl_to_sws_fin_details`()
BEGIN

    declare gl_extraction_date date;

    set @gl_extraction_date=(select max(extraction_date) from psgl_fin_details);

    delete from sub_workstream_fin_details
    where cost_type_detail='Actual-PSGL'
      and scenario='Forecast'
      and period in (select distinct date_format(journal_date,'%Y%m')
                     from psgl_fin_details
                     where extraction_date=@gl_extraction_date);


    insert into sub_workstream_fin_details(
        workstream_id,
        sub_workstream_id,
        sub_workstream_name,
        scenario,
        gl_category,
        cost_type,
        cost_type_detail,
        period,
        cost_settings,
        local_ccy,
        group_ccy,
        local_ccy_val,
        group_ccy_val,
        org_ind,
        created_by,
        date_created)
    select
        b.workstream_id,
        b.sub_workstream_id,
        b.sub_workstream_name,
        c.scenario_name as scenario,
        a.gl_category,
        a.cost_type,
        'Actual-PSGL' as cost_type_detail,
        date_format(journal_date,'%Y%m') as period,
        'Financial Details' as cost_settings,
        currency_code as local_ccy,
        'SGD' as group_ccy,
        sum(ifnull(monetary_amt,0)*ifnull(d.allocation_pct,0)/100) as local_ccy_val,

        sum(ifnull(monetary_amt*ifnull(d.allocation_pct,0)/100*ifnull((select rate_val
                                                                       from exchange_rates
                                                                       where ccy_from=currency_code
                                                                         and ccy_to='SGD'
                                                                         and rate_period=date_format(a.journal_date,'%Y%m')),0),0)) as group_ccy_val,

        'False' as org_ind,
        'System' as created_by,
        now() as date_created

    from psgl_fin_details a, map_work_to_pccode b, sub_workstream_dates c, workstream_le_pccodes d

    where b.build_operate='Build'
      and c.scenario_name='Forecast'
      and c.active_ind='True'
      and a.le_pccode=b.le_pccode
      and b.sub_workstream_id=c.sub_workstream_id
      and b.sub_workstream_name=c.sub_workstream_name
      and b.workstream_id=d.workstream_id
      and b.le_pccode=d.le_pccode
      and d.active_ind='True'

    group by
        b.workstream_id,
        b.sub_workstream_id,
        b.sub_workstream_name,
        c.scenario_name,
        a.gl_category,
        a.cost_type,
        date_format(a.journal_date,'%Y%m'),
        currency_code;

END//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_recon_employee_count`(
    IN `rptperiod` VARCHAR(10),
    IN `asofdate` VARCHAR(10)
)
emp_proc:
BEGIN

    if trim(rptperiod)='' or isnull(rptperiod) or trim(asofdate)='' or isnull(asofdate) then
        select 'Invalid parameter. Cannot be blank or null.';
        select rptperiod;
        select asofdate;
        leave emp_proc;
    end if;

    SELECT concat('rptperiod is ', rptperiod);
    SELECT concat('asofdate is ', asofdate);

    delete from recon_employee_count
    where rpt_period = rptperiod
      and as_of_date=asofdate;

    INSERT INTO recon_employee_count (as_of_date,rpt_period,src_table_name,src_rec_count_nofilter,src_rec_count_filtered,tgt_table_name,tgt_rec_count)
        (select distinct as_of_date,
                         rptperiod,
                         'stg_workday',
                         (select count(*) from stg_workday where as_of_date=asofdate),
                         (select count(*) from stg_workday where as_of_date=asofdate and level_3_descr='Technology & Operations' and level_4_descr in ('Technology','Management Office')),
                         'employee',
                         (select count(*) from employee where rpt_period=rptperiod and staff_status='Active' and staff_type='DBS')
         from stg_workday
         where as_of_date=asofdate
         limit 1);

END//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_sws_backend_fin_details`(
    IN `subwkstream_id` VARCHAR(100),
    IN `subwkstream_name` VARCHAR(1000),
    IN `rptyear` VARCHAR(10)
    ,
    IN `cost_component` VARCHAR(100)
)
BEGIN

    declare pfid varchar(100);
    declare wsid varchar(100);
    declare swsid varchar(100);
    declare swsname varchar(1000);

    DECLARE done INT DEFAULT FALSE;
    declare sws_cur CURSOR FOR select distinct c.portfolio_id,b.workstream_id,a.sub_workstream_id,a.sub_workstream_name
                               from sub_workstream_profile a,workstream_profile b,portfolio_profile c
                               where a.sub_workstream_id=subwkstream_id
                                 and a.sub_workstream_name=subwkstream_name
                                 and a.workstream_id=b.workstream_id
                                 and b.portfolio_id=c.portfolio_id;
    declare CONTINUE HANDLER FOR NOT FOUND SET done=TRUE;


    set @sws_id=subwkstream_id;
    set @sws_name=subwkstream_name;

    set @curryear='2018';

    OPEN sws_cur;
    read_loop: LOOP
        FETCH sws_cur INTO pfid,wsid,swsid,swsname;

        IF done THEN
            LEAVE read_loop;
        END IF;

        set @agile_waterfall_ind = (select distinct agile_waterfall
                                    from portfolio_profile
                                    where portfolio_id=pfid);

        if @agile_waterfall_ind='Agile' then
            set @depre_life=(select cast(b.refdata_attr1 as integer)
                             from xref_data_summary a, xref_data_values b
                             where a.refdata_name='Agile/Waterfall'
                               and a.refdata_code=b.refdata_code
                               and b.refdata_value='Agile');
        else
            set @depre_life=(select cast(b.refdata_attr1 as integer)
                             from xref_data_summary a, xref_data_values b
                             where a.refdata_name='Agile/Waterfall'
                               and a.refdata_code=b.refdata_code
                               and b.refdata_value='Waterfall');
        end if;

        case cost_component
            when 'HLE/FD'
                then
                    delete from sws_backend_fin_details
                    where sub_workstream_id=swsid
                      and sub_workstream_name=swsname
                      and data_source='sub_workstream_fin_details';

                    call sp_sws_fin_details_hle_sf(pfid,wsid,swsid,swsname,@depre_life,@curryear);

            when 'Resource Cost'
                then
                    delete from sws_backend_fin_details
                    where sub_workstream_id=swsid
                      and sub_workstream_name=swsname
                      and data_source='sub_workstream_resource_cost';

                    call sp_sws_fin_details_resource_cost(pfid,wsid,swsid,swsname,@depre_life,@curryear);

            when 'Software Cost'
                then
                    delete from sws_backend_fin_details
                    where sub_workstream_id=swsid
                      and sub_workstream_name=swsname
                      and data_source='sub_workstream_software_cost';

                    call sp_sws_fin_details_software(pfid,wsid,swsid,swsname,@depre_life,@curryear);

            when 'Hardware Cost'
                then
                    delete from sws_backend_fin_details
                    where sub_workstream_id=swsid
                      and sub_workstream_name=swsname
                      and data_source='sub_workstream_hardware_cost';

                    call sp_sws_fin_details_hardware(pfid,wsid,swsid,swsname,@depre_life,@curryear);

            else
                delete from sws_backend_fin_details
                where sub_workstream_id=swsid
                  and sub_workstream_name=swsname
                  and data_source='sub_workstream_other_cost';

                call sp_sws_fin_details_others(pfid,wsid,swsid,swsname,@depre_life,@curryear);
            end case;

    END LOOP;

    CLOSE sws_cur;

END//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_sws_fin_details_hardware`(
    IN `pfid` VARCHAR(100),
    IN `ws_id` VARCHAR(100),
    IN `sws_id` VARCHAR(100),
    IN `sws_name` VARCHAR(100),
    IN `depre_life` INT,
    IN `rptyear` VARCHAR(10)





)
BEGIN

    set @curryear=rptyear;

    set @eoydate=last_day(concat(rptyear,'-12-31'));

    set @lastyear_depre = (select year(end_date)+5 from sub_workstream_dates
                           where sub_workstream_id=@sws_id
                             and sub_workstream_name=@sws_name
                             and active_ind='True'
                             and scenario_name='Forecast');

-- Hardware Quantity
    insert into sws_backend_fin_details(
        portfolio_id,
        workstream_id,
        sub_workstream_id,
        sub_workstream_name,
        scenario,
        cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_date,
        go_live_date,
        sws_end_date,
        depre_start_date,
        eoy_date,
        gl_category,
        cost_type,

        ccy_code,

        add_hardware,
        hw_tower,
        hw_driver_details,
        hw_uom,
        hw_itc_rate,
        hw_quantity,
        hw_cost,

        hw_gl_category,
        field_in_cost_type,

        jan_year_1,
        feb_year_1,
        mar_year_1,
        apr_year_1,
        may_year_1,
        jun_year_1,
        jul_year_1,
        aug_year_1,
        sep_year_1,
        oct_year_1,
        nov_year_1,
        dec_year_1,

        jan_year_2,
        feb_year_2,
        mar_year_2,
        apr_year_2,
        may_year_2,
        jun_year_2,
        jul_year_2,
        aug_year_2,
        sep_year_2,
        oct_year_2,
        nov_year_2,
        dec_year_2,

        jan_year_3,
        feb_year_3,
        mar_year_3,
        apr_year_3,
        may_year_3,
        jun_year_3,
        jul_year_3,
        aug_year_3,
        sep_year_3,
        oct_year_3,
        nov_year_3,
        dec_year_3,

        jan_year_4,
        feb_year_4,
        mar_year_4,
        apr_year_4,
        may_year_4,
        jun_year_4,
        jul_year_4,
        aug_year_4,
        sep_year_4,
        oct_year_4,
        nov_year_4,
        dec_year_4,

        jan_year_5,
        feb_year_5,
        mar_year_5,
        apr_year_5,
        may_year_5,
        jun_year_5,
        jul_year_5,
        aug_year_5,
        sep_year_5,
        oct_year_5,
        nov_year_5,
        dec_year_5,

        jan_year_6,
        feb_year_6,
        mar_year_6,
        apr_year_6,
        may_year_6,
        jun_year_6,
        jul_year_6,
        aug_year_6,
        sep_year_6,
        oct_year_6,
        nov_year_6,
        dec_year_6,

        jan_year_7,
        feb_year_7,
        mar_year_7,
        apr_year_7,
        may_year_7,
        jun_year_7,
        jul_year_7,
        aug_year_7,
        sep_year_7,
        oct_year_7,
        nov_year_7,
        dec_year_7,

        jan_year_8,
        feb_year_8,
        mar_year_8,
        apr_year_8,
        may_year_8,
        jun_year_8,
        jul_year_8,
        aug_year_8,
        sep_year_8,
        oct_year_8,
        nov_year_8,
        dec_year_8,

        total_amt
    )
    select distinct
        pfid as portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        null as lock_ind,
        null as fd_version,
        null as snapshot_date,
        null as agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        date_add(date_add(go_live_date,interval 60 day),interval -day(date_add(go_live_date,interval 60 day)) +1 day) as depre_start_date,
        @eoydate as eoy_date,
        a.gl_category,
        cost_type,

        a.group_ccy as ccy_code,

        c.add_hardware,
        tower as hw_tower,
        driver_detail as hw_driver_detail,
        uom as hw_uom,
        itc_rate as hw_itc_rate,

        (select distinct quantity
         from sub_workstream_hardware_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.tower=c.tower
           and d.driver_detail=c.driver_detail
           and d.uom=c.uom
           and c.original_ind='false'
           and d.original_ind='true') as hw_quantity,

        (select distinct cost_per_month_lcy
         from sub_workstream_hardware_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.tower=c.tower
           and d.driver_detail=c.driver_detail
           and d.uom=c.uom
           and c.original_ind='false'
           and d.original_ind='true') as hw_cost,

        c.gl_category as hw_gl_category,
        'Qty' as field_in_cost_type,

        SUM(IF(c.period = concat(@curryear,'01'), ifnull(c.quantity,0), 0)) AS jan_year_1,
        SUM(IF(c.period = concat(@curryear,'02'), ifnull(c.quantity,0), 0)) AS feb_year_1,
        SUM(IF(c.period = concat(@curryear,'03'), ifnull(c.quantity,0), 0)) AS mar_year_1,
        SUM(IF(c.period = concat(@curryear,'04'), ifnull(c.quantity,0), 0)) AS apr_year_1,
        SUM(IF(c.period = concat(@curryear,'05'), ifnull(c.quantity,0), 0)) AS may_year_1,
        SUM(IF(c.period = concat(@curryear,'06'), ifnull(c.quantity,0), 0)) AS jun_year_1,
        SUM(IF(c.period = concat(@curryear,'07'), ifnull(c.quantity,0), 0)) AS jul_year_1,
        SUM(IF(c.period = concat(@curryear,'08'), ifnull(c.quantity,0), 0)) AS aug_year_1,
        SUM(IF(c.period = concat(@curryear,'09'), ifnull(c.quantity,0), 0)) AS sep_year_1,
        SUM(IF(c.period = concat(@curryear,'10'), ifnull(c.quantity,0), 0)) AS oct_year_1,
        SUM(IF(c.period = concat(@curryear,'11'), ifnull(c.quantity,0), 0)) AS nov_year_1,
        SUM(IF(c.period = concat(@curryear,'12'), ifnull(c.quantity,0), 0)) AS dec_year_1,

        SUM(IF(c.period = concat(@curryear+1,'01'), ifnull(c.quantity,0), 0)) AS jan_year_2,
        SUM(IF(c.period = concat(@curryear+1,'02'), ifnull(c.quantity,0), 0)) AS feb_year_2,
        SUM(IF(c.period = concat(@curryear+1,'03'), ifnull(c.quantity,0), 0)) AS mar_year_2,
        SUM(IF(c.period = concat(@curryear+1,'04'), ifnull(c.quantity,0), 0)) AS apr_year_2,
        SUM(IF(c.period = concat(@curryear+1,'05'), ifnull(c.quantity,0), 0)) AS may_year_2,
        SUM(IF(c.period = concat(@curryear+1,'06'), ifnull(c.quantity,0), 0)) AS jun_year_2,
        SUM(IF(c.period = concat(@curryear+1,'07'), ifnull(c.quantity,0), 0)) AS jul_year_2,
        SUM(IF(c.period = concat(@curryear+1,'08'), ifnull(c.quantity,0), 0)) AS aug_year_2,
        SUM(IF(c.period = concat(@curryear+1,'09'), ifnull(c.quantity,0), 0)) AS sep_year_2,
        SUM(IF(c.period = concat(@curryear+1,'10'), ifnull(c.quantity,0), 0)) AS oct_year_2,
        SUM(IF(c.period = concat(@curryear+1,'11'), ifnull(c.quantity,0), 0)) AS nov_year_2,
        SUM(IF(c.period = concat(@curryear+1,'12'), ifnull(c.quantity,0), 0)) AS dec_year_2,

        SUM(IF(c.period = concat(@curryear+2,'01'), ifnull(c.quantity,0), 0)) AS jan_year_3,
        SUM(IF(c.period = concat(@curryear+2,'02'), ifnull(c.quantity,0), 0)) AS feb_year_3,
        SUM(IF(c.period = concat(@curryear+2,'03'), ifnull(c.quantity,0), 0)) AS mar_year_3,
        SUM(IF(c.period = concat(@curryear+2,'04'), ifnull(c.quantity,0), 0)) AS apr_year_3,
        SUM(IF(c.period = concat(@curryear+2,'05'), ifnull(c.quantity,0), 0)) AS may_year_3,
        SUM(IF(c.period = concat(@curryear+2,'06'), ifnull(c.quantity,0), 0)) AS jun_year_3,
        SUM(IF(c.period = concat(@curryear+2,'07'), ifnull(c.quantity,0), 0)) AS jul_year_3,
        SUM(IF(c.period = concat(@curryear+2,'08'), ifnull(c.quantity,0), 0)) AS aug_year_3,
        SUM(IF(c.period = concat(@curryear+2,'09'), ifnull(c.quantity,0), 0)) AS sep_year_3,
        SUM(IF(c.period = concat(@curryear+2,'10'), ifnull(c.quantity,0), 0)) AS oct_year_3,
        SUM(IF(c.period = concat(@curryear+2,'11'), ifnull(c.quantity,0), 0)) AS nov_year_3,
        SUM(IF(c.period = concat(@curryear+2,'12'), ifnull(c.quantity,0), 0)) AS dec_year_3,

        SUM(IF(c.period = concat(@curryear+3,'01'), ifnull(c.quantity,0), 0)) AS jan_year_4,
        SUM(IF(c.period = concat(@curryear+3,'02'), ifnull(c.quantity,0), 0)) AS feb_year_4,
        SUM(IF(c.period = concat(@curryear+3,'03'), ifnull(c.quantity,0), 0)) AS mar_year_4,
        SUM(IF(c.period = concat(@curryear+3,'04'), ifnull(c.quantity,0), 0)) AS apr_year_4,
        SUM(IF(c.period = concat(@curryear+3,'05'), ifnull(c.quantity,0), 0)) AS may_year_4,
        SUM(IF(c.period = concat(@curryear+3,'06'), ifnull(c.quantity,0), 0)) AS jun_year_4,
        SUM(IF(c.period = concat(@curryear+3,'07'), ifnull(c.quantity,0), 0)) AS jul_year_4,
        SUM(IF(c.period = concat(@curryear+3,'08'), ifnull(c.quantity,0), 0)) AS aug_year_4,
        SUM(IF(c.period = concat(@curryear+3,'09'), ifnull(c.quantity,0), 0)) AS sep_year_4,
        SUM(IF(c.period = concat(@curryear+3,'10'), ifnull(c.quantity,0), 0)) AS oct_year_4,
        SUM(IF(c.period = concat(@curryear+3,'11'), ifnull(c.quantity,0), 0)) AS nov_year_4,
        SUM(IF(c.period = concat(@curryear+3,'12'), ifnull(c.quantity,0), 0)) AS dec_year_4,

        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'01'), ifnull(c.quantity,0), 0))) AS jan_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'02'), ifnull(c.quantity,0), 0))) AS feb_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'03'), ifnull(c.quantity,0), 0))) AS mar_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'04'), ifnull(c.quantity,0), 0))) AS apr_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'05'), ifnull(c.quantity,0), 0))) AS may_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'06'), ifnull(c.quantity,0), 0))) AS jun_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'07'), ifnull(c.quantity,0), 0))) AS jul_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'08'), ifnull(c.quantity,0), 0))) AS aug_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'09'), ifnull(c.quantity,0), 0))) AS sep_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'10'), ifnull(c.quantity,0), 0))) AS oct_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'11'), ifnull(c.quantity,0), 0))) AS nov_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'12'), ifnull(c.quantity,0), 0))) AS dec_year_5,

        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'01'), ifnull(c.quantity,0), 0))) AS jan_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'02'), ifnull(c.quantity,0), 0))) AS feb_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'03'), ifnull(c.quantity,0), 0))) AS mar_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'04'), ifnull(c.quantity,0), 0))) AS apr_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'05'), ifnull(c.quantity,0), 0))) AS may_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'06'), ifnull(c.quantity,0), 0))) AS jun_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'07'), ifnull(c.quantity,0), 0))) AS jul_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'08'), ifnull(c.quantity,0), 0))) AS aug_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'09'), ifnull(c.quantity,0), 0))) AS sep_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'10'), ifnull(c.quantity,0), 0))) AS oct_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'11'), ifnull(c.quantity,0), 0))) AS nov_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'12'), ifnull(c.quantity,0), 0))) AS dec_year_6,

        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'01'), ifnull(c.quantity,0), 0))) AS jan_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'02'), ifnull(c.quantity,0), 0))) AS feb_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'03'), ifnull(c.quantity,0), 0))) AS mar_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'04'), ifnull(c.quantity,0), 0))) AS apr_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'05'), ifnull(c.quantity,0), 0))) AS may_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'06'), ifnull(c.quantity,0), 0))) AS jun_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'07'), ifnull(c.quantity,0), 0))) AS jul_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'08'), ifnull(c.quantity,0), 0))) AS aug_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'09'), ifnull(c.quantity,0), 0))) AS sep_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'10'), ifnull(c.quantity,0), 0))) AS oct_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'11'), ifnull(c.quantity,0), 0))) AS nov_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'12'), ifnull(c.quantity,0), 0))) AS dec_year_7,

        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'01'), ifnull(c.quantity,0), 0))) AS jan_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'02'), ifnull(c.quantity,0), 0))) AS feb_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'03'), ifnull(c.quantity,0), 0))) AS mar_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'04'), ifnull(c.quantity,0), 0))) AS apr_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'05'), ifnull(c.quantity,0), 0))) AS may_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'06'), ifnull(c.quantity,0), 0))) AS jun_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'07'), ifnull(c.quantity,0), 0))) AS jul_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'08'), ifnull(c.quantity,0), 0))) AS aug_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'09'), ifnull(c.quantity,0), 0))) AS sep_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'10'), ifnull(c.quantity,0), 0))) AS oct_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'11'), ifnull(c.quantity,0), 0))) AS nov_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'12'), ifnull(c.quantity,0), 0))) AS dec_year_8,

        null AS total_amt

    from sub_workstream_fin_details a,sub_workstream_dates b, sub_workstream_hardware_cost c
    where a.sub_workstream_id=@sws_id
      and a.sub_workstream_name=@sws_name
      and a.sub_workstream_id=b.sub_workstream_id
      and a.sub_workstream_name=b.sub_workstream_name
      and a.scenario=b.scenario_name
      and b.active_ind='True'
      and a.sub_workstream_id=c.sub_workstream_id
      and a.sub_workstream_name=c.sub_workstream_name
      and a.scenario=c.scenario
      and a.org_ind='False'
      and c.original_ind='false'
      and cost_type='Hardware'
    group by
        portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        b.depre_start_date,
        eoy_date,
        ccy_code,
        a.gl_category,
        cost_type,
        tower,
        driver_detail,
        uom;

-- Hardware ITC Rate
    insert into sws_backend_fin_details(
        portfolio_id,
        workstream_id,
        sub_workstream_id,
        sub_workstream_name,
        scenario,
        cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_date,
        go_live_date,
        sws_end_date,
        depre_start_date,
        eoy_date,
        gl_category,
        cost_type,

        ccy_code,

        add_hardware,
        hw_tower,
        hw_driver_details,
        hw_uom,
        hw_itc_rate,
        hw_quantity,
        hw_cost,

        hw_gl_category,
        field_in_cost_type,

        jan_year_1,
        feb_year_1,
        mar_year_1,
        apr_year_1,
        may_year_1,
        jun_year_1,
        jul_year_1,
        aug_year_1,
        sep_year_1,
        oct_year_1,
        nov_year_1,
        dec_year_1,

        jan_year_2,
        feb_year_2,
        mar_year_2,
        apr_year_2,
        may_year_2,
        jun_year_2,
        jul_year_2,
        aug_year_2,
        sep_year_2,
        oct_year_2,
        nov_year_2,
        dec_year_2,

        jan_year_3,
        feb_year_3,
        mar_year_3,
        apr_year_3,
        may_year_3,
        jun_year_3,
        jul_year_3,
        aug_year_3,
        sep_year_3,
        oct_year_3,
        nov_year_3,
        dec_year_3,

        jan_year_4,
        feb_year_4,
        mar_year_4,
        apr_year_4,
        may_year_4,
        jun_year_4,
        jul_year_4,
        aug_year_4,
        sep_year_4,
        oct_year_4,
        nov_year_4,
        dec_year_4,

        jan_year_5,
        feb_year_5,
        mar_year_5,
        apr_year_5,
        may_year_5,
        jun_year_5,
        jul_year_5,
        aug_year_5,
        sep_year_5,
        oct_year_5,
        nov_year_5,
        dec_year_5,

        jan_year_6,
        feb_year_6,
        mar_year_6,
        apr_year_6,
        may_year_6,
        jun_year_6,
        jul_year_6,
        aug_year_6,
        sep_year_6,
        oct_year_6,
        nov_year_6,
        dec_year_6,

        jan_year_7,
        feb_year_7,
        mar_year_7,
        apr_year_7,
        may_year_7,
        jun_year_7,
        jul_year_7,
        aug_year_7,
        sep_year_7,
        oct_year_7,
        nov_year_7,
        dec_year_7,

        jan_year_8,
        feb_year_8,
        mar_year_8,
        apr_year_8,
        may_year_8,
        jun_year_8,
        jul_year_8,
        aug_year_8,
        sep_year_8,
        oct_year_8,
        nov_year_8,
        dec_year_8,

        total_amt
    )
    select distinct
        pfid as portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        null as lock_ind,
        null as fd_version,
        null as snapshot_date,
        null as agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        date_add(date_add(go_live_date,interval 60 day),interval -day(date_add(go_live_date,interval 60 day)) +1 day) as depre_start_date,
        @eoydate as eoy_date,
        a.gl_category,
        cost_type,

        a.group_ccy as ccy_code,

        c.add_hardware,
        tower as hw_tower,
        driver_detail as hw_driver_detail,
        uom as hw_uom,
        itc_rate as hw_itc_rate,

        (select distinct quantity
         from sub_workstream_hardware_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.tower=c.tower
           and d.driver_detail=c.driver_detail
           and d.uom=c.uom
           and c.original_ind='false'
           and d.original_ind='true') as hw_quantity,

        (select distinct cost_per_month_lcy
         from sub_workstream_hardware_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.tower=c.tower
           and d.driver_detail=c.driver_detail
           and d.uom=c.uom
           and c.original_ind='false'
           and d.original_ind='true') as hw_cost,

        c.gl_category as hw_gl_category,
        'ITC Rate' as field_in_cost_type,

        SUM(IF(c.period = concat(@curryear,'01'), ifnull(c.itc_rate,0), 0)) AS jan_year_1,
        SUM(IF(c.period = concat(@curryear,'02'), ifnull(c.itc_rate,0), 0)) AS feb_year_1,
        SUM(IF(c.period = concat(@curryear,'03'), ifnull(c.itc_rate,0), 0)) AS mar_year_1,
        SUM(IF(c.period = concat(@curryear,'04'), ifnull(c.itc_rate,0), 0)) AS apr_year_1,
        SUM(IF(c.period = concat(@curryear,'05'), ifnull(c.itc_rate,0), 0)) AS may_year_1,
        SUM(IF(c.period = concat(@curryear,'06'), ifnull(c.itc_rate,0), 0)) AS jun_year_1,
        SUM(IF(c.period = concat(@curryear,'07'), ifnull(c.itc_rate,0), 0)) AS jul_year_1,
        SUM(IF(c.period = concat(@curryear,'08'), ifnull(c.itc_rate,0), 0)) AS aug_year_1,
        SUM(IF(c.period = concat(@curryear,'09'), ifnull(c.itc_rate,0), 0)) AS sep_year_1,
        SUM(IF(c.period = concat(@curryear,'10'), ifnull(c.itc_rate,0), 0)) AS oct_year_1,
        SUM(IF(c.period = concat(@curryear,'11'), ifnull(c.itc_rate,0), 0)) AS nov_year_1,
        SUM(IF(c.period = concat(@curryear,'12'), ifnull(c.itc_rate,0), 0)) AS dec_year_1,

        SUM(IF(c.period = concat(@curryear+1,'01'), ifnull(c.itc_rate,0), 0)) AS jan_year_2,
        SUM(IF(c.period = concat(@curryear+1,'02'), ifnull(c.itc_rate,0), 0)) AS feb_year_2,
        SUM(IF(c.period = concat(@curryear+1,'03'), ifnull(c.itc_rate,0), 0)) AS mar_year_2,
        SUM(IF(c.period = concat(@curryear+1,'04'), ifnull(c.itc_rate,0), 0)) AS apr_year_2,
        SUM(IF(c.period = concat(@curryear+1,'05'), ifnull(c.itc_rate,0), 0)) AS may_year_2,
        SUM(IF(c.period = concat(@curryear+1,'06'), ifnull(c.itc_rate,0), 0)) AS jun_year_2,
        SUM(IF(c.period = concat(@curryear+1,'07'), ifnull(c.itc_rate,0), 0)) AS jul_year_2,
        SUM(IF(c.period = concat(@curryear+1,'08'), ifnull(c.itc_rate,0), 0)) AS aug_year_2,
        SUM(IF(c.period = concat(@curryear+1,'09'), ifnull(c.itc_rate,0), 0)) AS sep_year_2,
        SUM(IF(c.period = concat(@curryear+1,'10'), ifnull(c.itc_rate,0), 0)) AS oct_year_2,
        SUM(IF(c.period = concat(@curryear+1,'11'), ifnull(c.itc_rate,0), 0)) AS nov_year_2,
        SUM(IF(c.period = concat(@curryear+1,'12'), ifnull(c.itc_rate,0), 0)) AS dec_year_2,

        SUM(IF(c.period = concat(@curryear+2,'01'), ifnull(c.itc_rate,0), 0)) AS jan_year_3,
        SUM(IF(c.period = concat(@curryear+2,'02'), ifnull(c.itc_rate,0), 0)) AS feb_year_3,
        SUM(IF(c.period = concat(@curryear+2,'03'), ifnull(c.itc_rate,0), 0)) AS mar_year_3,
        SUM(IF(c.period = concat(@curryear+2,'04'), ifnull(c.itc_rate,0), 0)) AS apr_year_3,
        SUM(IF(c.period = concat(@curryear+2,'05'), ifnull(c.itc_rate,0), 0)) AS may_year_3,
        SUM(IF(c.period = concat(@curryear+2,'06'), ifnull(c.itc_rate,0), 0)) AS jun_year_3,
        SUM(IF(c.period = concat(@curryear+2,'07'), ifnull(c.itc_rate,0), 0)) AS jul_year_3,
        SUM(IF(c.period = concat(@curryear+2,'08'), ifnull(c.itc_rate,0), 0)) AS aug_year_3,
        SUM(IF(c.period = concat(@curryear+2,'09'), ifnull(c.itc_rate,0), 0)) AS sep_year_3,
        SUM(IF(c.period = concat(@curryear+2,'10'), ifnull(c.itc_rate,0), 0)) AS oct_year_3,
        SUM(IF(c.period = concat(@curryear+2,'11'), ifnull(c.itc_rate,0), 0)) AS nov_year_3,
        SUM(IF(c.period = concat(@curryear+2,'12'), ifnull(c.itc_rate,0), 0)) AS dec_year_3,

        SUM(IF(c.period = concat(@curryear+3,'01'), ifnull(c.itc_rate,0), 0)) AS jan_year_4,
        SUM(IF(c.period = concat(@curryear+3,'02'), ifnull(c.itc_rate,0), 0)) AS feb_year_4,
        SUM(IF(c.period = concat(@curryear+3,'03'), ifnull(c.itc_rate,0), 0)) AS mar_year_4,
        SUM(IF(c.period = concat(@curryear+3,'04'), ifnull(c.itc_rate,0), 0)) AS apr_year_4,
        SUM(IF(c.period = concat(@curryear+3,'05'), ifnull(c.itc_rate,0), 0)) AS may_year_4,
        SUM(IF(c.period = concat(@curryear+3,'06'), ifnull(c.itc_rate,0), 0)) AS jun_year_4,
        SUM(IF(c.period = concat(@curryear+3,'07'), ifnull(c.itc_rate,0), 0)) AS jul_year_4,
        SUM(IF(c.period = concat(@curryear+3,'08'), ifnull(c.itc_rate,0), 0)) AS aug_year_4,
        SUM(IF(c.period = concat(@curryear+3,'09'), ifnull(c.itc_rate,0), 0)) AS sep_year_4,
        SUM(IF(c.period = concat(@curryear+3,'10'), ifnull(c.itc_rate,0), 0)) AS oct_year_4,
        SUM(IF(c.period = concat(@curryear+3,'11'), ifnull(c.itc_rate,0), 0)) AS nov_year_4,
        SUM(IF(c.period = concat(@curryear+3,'12'), ifnull(c.itc_rate,0), 0)) AS dec_year_4,

        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'01'), ifnull(c.itc_rate,0), 0))) AS jan_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'02'), ifnull(c.itc_rate,0), 0))) AS feb_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'03'), ifnull(c.itc_rate,0), 0))) AS mar_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'04'), ifnull(c.itc_rate,0), 0))) AS apr_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'05'), ifnull(c.itc_rate,0), 0))) AS may_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'06'), ifnull(c.itc_rate,0), 0))) AS jun_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'07'), ifnull(c.itc_rate,0), 0))) AS jul_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'08'), ifnull(c.itc_rate,0), 0))) AS aug_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'09'), ifnull(c.itc_rate,0), 0))) AS sep_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'10'), ifnull(c.itc_rate,0), 0))) AS oct_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'11'), ifnull(c.itc_rate,0), 0))) AS nov_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'12'), ifnull(c.itc_rate,0), 0))) AS dec_year_5,

        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'01'), ifnull(c.itc_rate,0), 0))) AS jan_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'02'), ifnull(c.itc_rate,0), 0))) AS feb_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'03'), ifnull(c.itc_rate,0), 0))) AS mar_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'04'), ifnull(c.itc_rate,0), 0))) AS apr_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'05'), ifnull(c.itc_rate,0), 0))) AS may_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'06'), ifnull(c.itc_rate,0), 0))) AS jun_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'07'), ifnull(c.itc_rate,0), 0))) AS jul_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'08'), ifnull(c.itc_rate,0), 0))) AS aug_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'09'), ifnull(c.itc_rate,0), 0))) AS sep_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'10'), ifnull(c.itc_rate,0), 0))) AS oct_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'11'), ifnull(c.itc_rate,0), 0))) AS nov_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'12'), ifnull(c.itc_rate,0), 0))) AS dec_year_6,

        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'01'), ifnull(c.itc_rate,0), 0))) AS jan_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'02'), ifnull(c.itc_rate,0), 0))) AS feb_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'03'), ifnull(c.itc_rate,0), 0))) AS mar_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'04'), ifnull(c.itc_rate,0), 0))) AS apr_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'05'), ifnull(c.itc_rate,0), 0))) AS may_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'06'), ifnull(c.itc_rate,0), 0))) AS jun_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'07'), ifnull(c.itc_rate,0), 0))) AS jul_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'08'), ifnull(c.itc_rate,0), 0))) AS aug_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'09'), ifnull(c.itc_rate,0), 0))) AS sep_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'10'), ifnull(c.itc_rate,0), 0))) AS oct_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'11'), ifnull(c.itc_rate,0), 0))) AS nov_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'12'), ifnull(c.itc_rate,0), 0))) AS dec_year_7,

        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'01'), ifnull(c.itc_rate,0), 0))) AS jan_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'02'), ifnull(c.itc_rate,0), 0))) AS feb_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'03'), ifnull(c.itc_rate,0), 0))) AS mar_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'04'), ifnull(c.itc_rate,0), 0))) AS apr_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'05'), ifnull(c.itc_rate,0), 0))) AS may_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'06'), ifnull(c.itc_rate,0), 0))) AS jun_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'07'), ifnull(c.itc_rate,0), 0))) AS jul_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'08'), ifnull(c.itc_rate,0), 0))) AS aug_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'09'), ifnull(c.itc_rate,0), 0))) AS sep_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'10'), ifnull(c.itc_rate,0), 0))) AS oct_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'11'), ifnull(c.itc_rate,0), 0))) AS nov_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'12'), ifnull(c.itc_rate,0), 0))) AS dec_year_8,

        null AS total_amt

    from sub_workstream_fin_details a,sub_workstream_dates b, sub_workstream_hardware_cost c
    where a.sub_workstream_id=@sws_id
      and a.sub_workstream_name=@sws_name
      and a.sub_workstream_id=b.sub_workstream_id
      and a.sub_workstream_name=b.sub_workstream_name
      and a.scenario=b.scenario_name
      and b.active_ind='True'
      and a.sub_workstream_id=c.sub_workstream_id
      and a.sub_workstream_name=c.sub_workstream_name
      and a.scenario=c.scenario
      and a.org_ind='False'
      and c.original_ind='false'
      and cost_type='Hardware'
    group by
        portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        b.depre_start_date,
        eoy_date,
        ccy_code,
        a.gl_category,
        cost_type,
        tower,
        driver_detail,
        uom;


-- Hardware Cost
    insert into sws_backend_fin_details(
        portfolio_id,
        workstream_id,
        sub_workstream_id,
        sub_workstream_name,
        scenario,
        cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_date,
        go_live_date,
        sws_end_date,
        depre_start_date,
        eoy_date,
        gl_category,
        cost_type,

        ccy_code,

        add_hardware,
        hw_tower,
        hw_driver_details,
        hw_uom,
        hw_itc_rate,
        hw_quantity,
        hw_cost,

        hw_gl_category,
        field_in_cost_type,

        jan_year_1,
        feb_year_1,
        mar_year_1,
        apr_year_1,
        may_year_1,
        jun_year_1,
        jul_year_1,
        aug_year_1,
        sep_year_1,
        oct_year_1,
        nov_year_1,
        dec_year_1,

        jan_year_2,
        feb_year_2,
        mar_year_2,
        apr_year_2,
        may_year_2,
        jun_year_2,
        jul_year_2,
        aug_year_2,
        sep_year_2,
        oct_year_2,
        nov_year_2,
        dec_year_2,

        jan_year_3,
        feb_year_3,
        mar_year_3,
        apr_year_3,
        may_year_3,
        jun_year_3,
        jul_year_3,
        aug_year_3,
        sep_year_3,
        oct_year_3,
        nov_year_3,
        dec_year_3,

        jan_year_4,
        feb_year_4,
        mar_year_4,
        apr_year_4,
        may_year_4,
        jun_year_4,
        jul_year_4,
        aug_year_4,
        sep_year_4,
        oct_year_4,
        nov_year_4,
        dec_year_4,

        jan_year_5,
        feb_year_5,
        mar_year_5,
        apr_year_5,
        may_year_5,
        jun_year_5,
        jul_year_5,
        aug_year_5,
        sep_year_5,
        oct_year_5,
        nov_year_5,
        dec_year_5,

        jan_year_6,
        feb_year_6,
        mar_year_6,
        apr_year_6,
        may_year_6,
        jun_year_6,
        jul_year_6,
        aug_year_6,
        sep_year_6,
        oct_year_6,
        nov_year_6,
        dec_year_6,

        jan_year_7,
        feb_year_7,
        mar_year_7,
        apr_year_7,
        may_year_7,
        jun_year_7,
        jul_year_7,
        aug_year_7,
        sep_year_7,
        oct_year_7,
        nov_year_7,
        dec_year_7,

        jan_year_8,
        feb_year_8,
        mar_year_8,
        apr_year_8,
        may_year_8,
        jun_year_8,
        jul_year_8,
        aug_year_8,
        sep_year_8,
        oct_year_8,
        nov_year_8,
        dec_year_8,

        total_amt
    )
    select distinct
        pfid as portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        null as lock_ind,
        null as fd_version,
        null as snapshot_date,
        null as agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        date_add(date_add(go_live_date,interval 60 day),interval -day(date_add(go_live_date,interval 60 day)) +1 day) as depre_start_date,
        @eoydate as eoy_date,
        a.gl_category,
        cost_type,

        sws_ccy_code as ccy_code,

        c.add_hardware,
        tower as hw_tower,
        driver_detail as hw_driver_detail,
        uom as hw_uom,
        itc_rate as hw_itc_rate,

        (select distinct quantity
         from sub_workstream_hardware_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.tower=c.tower
           and d.driver_detail=c.driver_detail
           and d.uom=c.uom
           and c.original_ind='false'
           and d.original_ind='true') as hw_quantity,

        (select distinct cost_per_month_lcy
         from sub_workstream_hardware_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.tower=c.tower
           and d.driver_detail=c.driver_detail
           and d.uom=c.uom
           and c.original_ind='false'
           and d.original_ind='true') as hw_cost,

        c.gl_category as hw_gl_category,
        'Cost' as field_in_cost_type,

        SUM(IF(c.period = concat(@curryear,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jan_year_1,
        SUM(IF(c.period = concat(@curryear,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS feb_year_1,
        SUM(IF(c.period = concat(@curryear,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS mar_year_1,
        SUM(IF(c.period = concat(@curryear,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS apr_year_1,
        SUM(IF(c.period = concat(@curryear,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS may_year_1,
        SUM(IF(c.period = concat(@curryear,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jun_year_1,
        SUM(IF(c.period = concat(@curryear,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jul_year_1,
        SUM(IF(c.period = concat(@curryear,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS aug_year_1,
        SUM(IF(c.period = concat(@curryear,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS sep_year_1,
        SUM(IF(c.period = concat(@curryear,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS oct_year_1,
        SUM(IF(c.period = concat(@curryear,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS nov_year_1,
        SUM(IF(c.period = concat(@curryear,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS dec_year_1,

        SUM(IF(c.period = concat(@curryear+1,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jan_year_2,
        SUM(IF(c.period = concat(@curryear+1,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS feb_year_2,
        SUM(IF(c.period = concat(@curryear+1,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS mar_year_2,
        SUM(IF(c.period = concat(@curryear+1,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS apr_year_2,
        SUM(IF(c.period = concat(@curryear+1,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS may_year_2,
        SUM(IF(c.period = concat(@curryear+1,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jun_year_2,
        SUM(IF(c.period = concat(@curryear+1,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jul_year_2,
        SUM(IF(c.period = concat(@curryear+1,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS aug_year_2,
        SUM(IF(c.period = concat(@curryear+1,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS sep_year_2,
        SUM(IF(c.period = concat(@curryear+1,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS oct_year_2,
        SUM(IF(c.period = concat(@curryear+1,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS nov_year_2,
        SUM(IF(c.period = concat(@curryear+1,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS dec_year_2,

        SUM(IF(c.period = concat(@curryear+2,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jan_year_3,
        SUM(IF(c.period = concat(@curryear+2,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS feb_year_3,
        SUM(IF(c.period = concat(@curryear+2,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS mar_year_3,
        SUM(IF(c.period = concat(@curryear+2,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS apr_year_3,
        SUM(IF(c.period = concat(@curryear+2,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS may_year_3,
        SUM(IF(c.period = concat(@curryear+2,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jun_year_3,
        SUM(IF(c.period = concat(@curryear+2,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jul_year_3,
        SUM(IF(c.period = concat(@curryear+2,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS aug_year_3,
        SUM(IF(c.period = concat(@curryear+2,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS sep_year_3,
        SUM(IF(c.period = concat(@curryear+2,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS oct_year_3,
        SUM(IF(c.period = concat(@curryear+2,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS nov_year_3,
        SUM(IF(c.period = concat(@curryear+2,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS dec_year_3,

        SUM(IF(c.period = concat(@curryear+3,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jan_year_4,
        SUM(IF(c.period = concat(@curryear+3,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS feb_year_4,
        SUM(IF(c.period = concat(@curryear+3,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS mar_year_4,
        SUM(IF(c.period = concat(@curryear+3,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS apr_year_4,
        SUM(IF(c.period = concat(@curryear+3,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS may_year_4,
        SUM(IF(c.period = concat(@curryear+3,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jun_year_4,
        SUM(IF(c.period = concat(@curryear+3,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jul_year_4,
        SUM(IF(c.period = concat(@curryear+3,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS aug_year_4,
        SUM(IF(c.period = concat(@curryear+3,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS sep_year_4,
        SUM(IF(c.period = concat(@curryear+3,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS oct_year_4,
        SUM(IF(c.period = concat(@curryear+3,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS nov_year_4,
        SUM(IF(c.period = concat(@curryear+3,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS dec_year_4,

        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jan_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS feb_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS mar_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS apr_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS may_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jun_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jul_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS aug_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS sep_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS oct_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS nov_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS dec_year_5,

        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jan_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS feb_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS mar_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS apr_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS may_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jun_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jul_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS aug_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS sep_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS oct_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS nov_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS dec_year_6,

        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jan_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS feb_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS mar_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS apr_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS may_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jun_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jul_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS aug_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS sep_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS oct_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS nov_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS dec_year_7,

        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jan_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS feb_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS mar_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS apr_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS may_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jun_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jul_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS aug_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS sep_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS oct_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS nov_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS dec_year_8,

        SUM(if(sws_ccy_ind='Local CCY',if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS total_amt

    from sub_workstream_fin_details a,sub_workstream_dates b, sub_workstream_hardware_cost c, ((select distinct sub_workstream_id,local_ccy as sws_ccy_code,'Local CCY' as sws_ccy_ind
                                                                                                from sub_workstream_fin_details
                                                                                                where sub_workstream_id=@sws_id
                                                                                                  and sub_workstream_name=@sws_name
                                                                                                  and org_ind='False'
                                                                                               ) union
                                                                                               (select distinct sub_workstream_id,group_ccy as sws_ccy_code,'Group CCY' as sws_ccy_ind
                                                                                                from sub_workstream_fin_details
                                                                                                where sub_workstream_id=@sws_id
                                                                                                  and sub_workstream_name=@sws_name
                                                                                                  and org_ind='False'
                                                                                                  and group_ccy<>local_ccy
                                                                                               )) as sws_ccy_code
    where a.sub_workstream_id=@sws_id
      and a.sub_workstream_name=@sws_name
      and a.sub_workstream_id=b.sub_workstream_id
      and a.sub_workstream_name=b.sub_workstream_name
      and a.scenario=b.scenario_name
      and b.active_ind='True'
      and a.sub_workstream_id=c.sub_workstream_id
      and a.sub_workstream_name=c.sub_workstream_name
      and a.scenario=c.scenario
      and a.org_ind='False'
      and c.original_ind='false'
      and cost_type='Hardware'
    group by
        portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        b.depre_start_date,
        eoy_date,
        ccy_code,
        a.gl_category,
        cost_type,
        tower,
        driver_detail,
        uom;

-- Other Hardware
    insert into sws_backend_fin_details(
        portfolio_id,
        workstream_id,
        sub_workstream_id,
        sub_workstream_name,
        scenario,
        cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_date,
        go_live_date,
        sws_end_date,
        depre_start_date,
        eoy_date,
        ccy_code,
        gl_category,
        cost_type,

        add_hardware,
        hw_tower,
        hw_driver_details,
        hw_uom,
        hw_itc_rate,
        hw_quantity,
        hw_cost,

        hw_gl_category,
        field_in_cost_type,

        jan_year_1,
        feb_year_1,
        mar_year_1,
        apr_year_1,
        may_year_1,
        jun_year_1,
        jul_year_1,
        aug_year_1,
        sep_year_1,
        oct_year_1,
        nov_year_1,
        dec_year_1,

        jan_year_2,
        feb_year_2,
        mar_year_2,
        apr_year_2,
        may_year_2,
        jun_year_2,
        jul_year_2,
        aug_year_2,
        sep_year_2,
        oct_year_2,
        nov_year_2,
        dec_year_2,

        jan_year_3,
        feb_year_3,
        mar_year_3,
        apr_year_3,
        may_year_3,
        jun_year_3,
        jul_year_3,
        aug_year_3,
        sep_year_3,
        oct_year_3,
        nov_year_3,
        dec_year_3,

        jan_year_4,
        feb_year_4,
        mar_year_4,
        apr_year_4,
        may_year_4,
        jun_year_4,
        jul_year_4,
        aug_year_4,
        sep_year_4,
        oct_year_4,
        nov_year_4,
        dec_year_4,

        jan_year_5,
        feb_year_5,
        mar_year_5,
        apr_year_5,
        may_year_5,
        jun_year_5,
        jul_year_5,
        aug_year_5,
        sep_year_5,
        oct_year_5,
        nov_year_5,
        dec_year_5,

        jan_year_6,
        feb_year_6,
        mar_year_6,
        apr_year_6,
        may_year_6,
        jun_year_6,
        jul_year_6,
        aug_year_6,
        sep_year_6,
        oct_year_6,
        nov_year_6,
        dec_year_6,

        jan_year_7,
        feb_year_7,
        mar_year_7,
        apr_year_7,
        may_year_7,
        jun_year_7,
        jul_year_7,
        aug_year_7,
        sep_year_7,
        oct_year_7,
        nov_year_7,
        dec_year_7,

        jan_year_8,
        feb_year_8,
        mar_year_8,
        apr_year_8,
        may_year_8,
        jun_year_8,
        jul_year_8,
        aug_year_8,
        sep_year_8,
        oct_year_8,
        nov_year_8,
        dec_year_8,

        total_amt
    )
    select distinct
        pfid as portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        null as lock_ind,
        null as fd_version,
        null as snapshot_date,
        null as agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        date_add(date_add(go_live_date,interval 60 day),interval -day(date_add(go_live_date,interval 60 day)) +1 day) as depre_start_date,
        @eoydate as eoy_date,
        a.gl_category,
        type as cost_type,

        sws_ccy_code as ccy_code,

        c.add_other,
        null as hw_tower,
        null as hw_driver_detail,
        null as hw_uom,
        null as hw_itc_rate,

        null as hw_quantity,

        (select distinct local_ccy_val
         from sub_workstream_other_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.vendor_name=c.vendor_name
           and d.type='Hardware'
           and c.original_ind='false'
           and d.original_ind='true') as hw_cost,

        c.gl_category as sw_gl_category,
        'Cost' as field_in_cost_type,

        SUM(IF(c.period = concat(@curryear,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jan_year_1,
        SUM(IF(c.period = concat(@curryear,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS feb_year_1,
        SUM(IF(c.period = concat(@curryear,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS mar_year_1,
        SUM(IF(c.period = concat(@curryear,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS apr_year_1,
        SUM(IF(c.period = concat(@curryear,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS may_year_1,
        SUM(IF(c.period = concat(@curryear,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jun_year_1,
        SUM(IF(c.period = concat(@curryear,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jul_year_1,
        SUM(IF(c.period = concat(@curryear,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS aug_year_1,
        SUM(IF(c.period = concat(@curryear,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS sep_year_1,
        SUM(IF(c.period = concat(@curryear,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS oct_year_1,
        SUM(IF(c.period = concat(@curryear,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS nov_year_1,
        SUM(IF(c.period = concat(@curryear,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS dec_year_1,

        SUM(IF(c.period = concat(@curryear+1,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jan_year_2,
        SUM(IF(c.period = concat(@curryear+1,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS feb_year_2,
        SUM(IF(c.period = concat(@curryear+1,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS mar_year_2,
        SUM(IF(c.period = concat(@curryear+1,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS apr_year_2,
        SUM(IF(c.period = concat(@curryear+1,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS may_year_2,
        SUM(IF(c.period = concat(@curryear+1,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jun_year_2,
        SUM(IF(c.period = concat(@curryear+1,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jul_year_2,
        SUM(IF(c.period = concat(@curryear+1,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS aug_year_2,
        SUM(IF(c.period = concat(@curryear+1,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS sep_year_2,
        SUM(IF(c.period = concat(@curryear+1,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS oct_year_2,
        SUM(IF(c.period = concat(@curryear+1,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS nov_year_2,
        SUM(IF(c.period = concat(@curryear+1,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS dec_year_2,

        SUM(IF(c.period = concat(@curryear+2,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jan_year_3,
        SUM(IF(c.period = concat(@curryear+2,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS feb_year_3,
        SUM(IF(c.period = concat(@curryear+2,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS mar_year_3,
        SUM(IF(c.period = concat(@curryear+2,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS apr_year_3,
        SUM(IF(c.period = concat(@curryear+2,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS may_year_3,
        SUM(IF(c.period = concat(@curryear+2,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jun_year_3,
        SUM(IF(c.period = concat(@curryear+2,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jul_year_3,
        SUM(IF(c.period = concat(@curryear+2,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS aug_year_3,
        SUM(IF(c.period = concat(@curryear+2,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS sep_year_3,
        SUM(IF(c.period = concat(@curryear+2,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS oct_year_3,
        SUM(IF(c.period = concat(@curryear+2,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS nov_year_3,
        SUM(IF(c.period = concat(@curryear+2,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS dec_year_3,

        SUM(IF(c.period = concat(@curryear+3,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jan_year_4,
        SUM(IF(c.period = concat(@curryear+3,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS feb_year_4,
        SUM(IF(c.period = concat(@curryear+3,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS mar_year_4,
        SUM(IF(c.period = concat(@curryear+3,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS apr_year_4,
        SUM(IF(c.period = concat(@curryear+3,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS may_year_4,
        SUM(IF(c.period = concat(@curryear+3,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jun_year_4,
        SUM(IF(c.period = concat(@curryear+3,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jul_year_4,
        SUM(IF(c.period = concat(@curryear+3,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS aug_year_4,
        SUM(IF(c.period = concat(@curryear+3,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS sep_year_4,
        SUM(IF(c.period = concat(@curryear+3,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS oct_year_4,
        SUM(IF(c.period = concat(@curryear+3,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS nov_year_4,
        SUM(IF(c.period = concat(@curryear+3,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS dec_year_4,

        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jan_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS feb_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS mar_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS apr_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS may_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jun_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jul_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS aug_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS sep_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS oct_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS nov_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS dec_year_5,

        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jan_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS feb_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS mar_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS apr_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS may_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jun_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jul_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS aug_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS sep_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS oct_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS nov_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS dec_year_6,

        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jan_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS feb_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS mar_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS apr_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS may_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jun_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jul_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS aug_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS sep_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS oct_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS nov_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS dec_year_7,

        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jan_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS feb_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS mar_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS apr_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS may_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jun_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jul_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS aug_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS sep_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS oct_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS nov_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS dec_year_8,

        SUM(if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0))) AS total_amt

    from sub_workstream_fin_details a,sub_workstream_dates b, sub_workstream_other_cost c, ((select distinct sub_workstream_id,local_ccy as sws_ccy_code,'Local CCY' as sws_ccy_ind
                                                                                             from sub_workstream_fin_details
                                                                                             where sub_workstream_id=@sws_id
                                                                                               and sub_workstream_name=@sws_name
                                                                                               and org_ind='False'
                                                                                            ) union
                                                                                            (select distinct sub_workstream_id,group_ccy as sws_ccy_code,'Group CCY' as sws_ccy_ind
                                                                                             from sub_workstream_fin_details
                                                                                             where sub_workstream_id=@sws_id
                                                                                               and sub_workstream_name=@sws_name
                                                                                               and group_ccy<>local_ccy
                                                                                               and org_ind='False'
                                                                                            )) as sws_ccy_code
    where a.sub_workstream_id=@sws_id
      and a.sub_workstream_name=@sws_name
      and a.sub_workstream_id=b.sub_workstream_id
      and a.sub_workstream_name=b.sub_workstream_name
      and a.scenario=b.scenario_name
      and b.active_ind='True'
      and a.sub_workstream_id=c.sub_workstream_id
      and a.sub_workstream_name=c.sub_workstream_name
      and a.scenario=c.scenario
      and a.org_ind='False'
      and c.original_ind='false'
      and c.type='Hardware'
    group by
        portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        b.depre_start_date,
        eoy_date,
        ccy_code,
        a.gl_category,
        vendor_name,
        c.gl_category;

END//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_sws_fin_details_hle_sf`(
    IN `pfid` VARCHAR(100),
    IN `ws_id` VARCHAR(100),
    IN `sws_id` VARCHAR(100),
    IN `sws_name` VARCHAR(1000),
    IN `depre_life` INT,
    IN `rptyear` VARCHAR(10)









)
BEGIN

    set @curryear=rptyear;
    set @eoydate=last_day(concat(rptyear,'-12-31'));

    set @lastyear_depre = (select year(end_date)+5 from sub_workstream_dates
                           where sub_workstream_id=@sws_id
                             and sub_workstream_name=@sws_name
                             and active_ind='True'
                             and scenario_name='Forecast');

    insert into sws_backend_fin_details(
        portfolio_id,
        workstream_id,
        sub_workstream_id,
        sub_workstream_name,
        scenario,
        cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_date,
        go_live_date,
        sws_end_date,
        depre_start_date,
        eoy_date,
        gl_category,
        cost_type,

        ccy_code,

        jan_year_1,
        feb_year_1,
        mar_year_1,
        apr_year_1,
        may_year_1,
        jun_year_1,
        jul_year_1,
        aug_year_1,
        sep_year_1,
        oct_year_1,
        nov_year_1,
        dec_year_1,

        jan_year_2,
        feb_year_2,
        mar_year_2,
        apr_year_2,
        may_year_2,
        jun_year_2,
        jul_year_2,
        aug_year_2,
        sep_year_2,
        oct_year_2,
        nov_year_2,
        dec_year_2,

        jan_year_3,
        feb_year_3,
        mar_year_3,
        apr_year_3,
        may_year_3,
        jun_year_3,
        jul_year_3,
        aug_year_3,
        sep_year_3,
        oct_year_3,
        nov_year_3,
        dec_year_3,

        jan_year_4,
        feb_year_4,
        mar_year_4,
        apr_year_4,
        may_year_4,
        jun_year_4,
        jul_year_4,
        aug_year_4,
        sep_year_4,
        oct_year_4,
        nov_year_4,
        dec_year_4,

        jan_year_5,
        feb_year_5,
        mar_year_5,
        apr_year_5,
        may_year_5,
        jun_year_5,
        jul_year_5,
        aug_year_5,
        sep_year_5,
        oct_year_5,
        nov_year_5,
        dec_year_5,

        jan_year_6,
        feb_year_6,
        mar_year_6,
        apr_year_6,
        may_year_6,
        jun_year_6,
        jul_year_6,
        aug_year_6,
        sep_year_6,
        oct_year_6,
        nov_year_6,
        dec_year_6,

        jan_year_7,
        feb_year_7,
        mar_year_7,
        apr_year_7,
        may_year_7,
        jun_year_7,
        jul_year_7,
        aug_year_7,
        sep_year_7,
        oct_year_7,
        nov_year_7,
        dec_year_7,

        jan_year_8,
        feb_year_8,
        mar_year_8,
        apr_year_8,
        may_year_8,
        jun_year_8,
        jul_year_8,
        aug_year_8,
        sep_year_8,
        oct_year_8,
        nov_year_8,
        dec_year_8,

        total_amt

    )
    select distinct
        pfid as portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        cost_settings,
        null as lock_ind,
        null as fd_version,
        null as snapshot_date,
        null as agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        date_add(date_add(go_live_date,interval depre_life day),interval -day(date_add(go_live_date,interval depre_life day)) +1 day) as depre_start_date,
        @eoydate as eoy_date,
        gl_category,
        cost_type,

        sws_ccy_code as ccy_code,

        SUM(IF(period = concat(@curryear,'01'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS jan_year_1,
        SUM(IF(period = concat(@curryear,'02'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS feb_year_1,
        SUM(IF(period = concat(@curryear,'03'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS mar_year_1,
        SUM(IF(period = concat(@curryear,'04'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS apr_year_1,
        SUM(IF(period = concat(@curryear,'05'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS may_year_1,
        SUM(IF(period = concat(@curryear,'06'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS jun_year_1,
        SUM(IF(period = concat(@curryear,'07'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS jul_year_1,
        SUM(IF(period = concat(@curryear,'08'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS aug_year_1,
        SUM(IF(period = concat(@curryear,'09'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS sep_year_1,
        SUM(IF(period = concat(@curryear,'10'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS oct_year_1,
        SUM(IF(period = concat(@curryear,'11'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS nov_year_1,
        SUM(IF(period = concat(@curryear,'12'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS dec_year_1,

        SUM(IF(period = concat(@curryear+1,'01'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS jan_year_2,
        SUM(IF(period = concat(@curryear+1,'02'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS feb_year_2,
        SUM(IF(period = concat(@curryear+1,'03'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS mar_year_2,
        SUM(IF(period = concat(@curryear+1,'04'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS apr_year_2,
        SUM(IF(period = concat(@curryear+1,'05'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS may_year_2,
        SUM(IF(period = concat(@curryear+1,'06'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS jun_year_2,
        SUM(IF(period = concat(@curryear+1,'07'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS jul_year_2,
        SUM(IF(period = concat(@curryear+1,'08'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS aug_year_2,
        SUM(IF(period = concat(@curryear+1,'09'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS sep_year_2,
        SUM(IF(period = concat(@curryear+1,'10'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS oct_year_2,
        SUM(IF(period = concat(@curryear+1,'11'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS nov_year_2,
        SUM(IF(period = concat(@curryear+1,'12'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS dec_year_2,

        SUM(IF(period = concat(@curryear+2,'01'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS jan_year_3,
        SUM(IF(period = concat(@curryear+2,'02'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS feb_year_3,
        SUM(IF(period = concat(@curryear+2,'03'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS mar_year_3,
        SUM(IF(period = concat(@curryear+2,'04'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS apr_year_3,
        SUM(IF(period = concat(@curryear+2,'05'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS may_year_3,
        SUM(IF(period = concat(@curryear+2,'06'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS jun_year_3,
        SUM(IF(period = concat(@curryear+2,'07'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS jul_year_3,
        SUM(IF(period = concat(@curryear+2,'08'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS aug_year_3,
        SUM(IF(period = concat(@curryear+2,'09'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS sep_year_3,
        SUM(IF(period = concat(@curryear+2,'10'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS oct_year_3,
        SUM(IF(period = concat(@curryear+2,'11'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS nov_year_3,
        SUM(IF(period = concat(@curryear+2,'12'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS dec_year_3,

        SUM(IF(period = concat(@curryear+3,'01'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS jan_year_4,
        SUM(IF(period = concat(@curryear+3,'02'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS feb_year_4,
        SUM(IF(period = concat(@curryear+3,'03'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS mar_year_4,
        SUM(IF(period = concat(@curryear+3,'04'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS apr_year_4,
        SUM(IF(period = concat(@curryear+3,'05'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS may_year_4,
        SUM(IF(period = concat(@curryear+3,'06'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS jun_year_4,
        SUM(IF(period = concat(@curryear+3,'07'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS jul_year_4,
        SUM(IF(period = concat(@curryear+3,'08'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS aug_year_4,
        SUM(IF(period = concat(@curryear+3,'09'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS sep_year_4,
        SUM(IF(period = concat(@curryear+3,'10'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS oct_year_4,
        SUM(IF(period = concat(@curryear+3,'11'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS nov_year_4,
        SUM(IF(period = concat(@curryear+3,'12'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0)) AS dec_year_4,

        if(@curryear+4>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+4,'01'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS jan_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+4,'02'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS feb_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+4,'03'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS mar_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+4,'04'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS apr_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+4,'05'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS may_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+4,'06'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS jun_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+4,'07'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS jul_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+4,'08'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS aug_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+4,'09'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS sep_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+4,'10'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS oct_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+4,'11'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS nov_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+4,'12'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS dec_year_5,

        if(@curryear+5>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+5,'01'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS jan_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+5,'02'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS feb_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+5,'03'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS mar_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+5,'04'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS apr_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+5,'05'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS may_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+5,'06'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS jun_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+5,'07'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS jul_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+5,'08'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS aug_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+5,'09'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS sep_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+5,'10'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS oct_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+5,'11'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS nov_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+5,'12'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS dec_year_6,

        if(@curryear+6>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+6,'01'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS jan_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+6,'02'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS feb_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+6,'03'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS mar_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+6,'04'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS apr_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+6,'05'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS may_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+6,'06'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS jun_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+6,'07'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS jul_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+6,'08'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS aug_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+6,'09'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS sep_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+6,'10'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS oct_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+6,'11'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS nov_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+6,'12'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS dec_year_7,

        if(@curryear+7>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+7,'01'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS jan_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+7,'02'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS feb_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+7,'03'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS mar_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+7,'04'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS apr_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+7,'05'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS may_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+7,'06'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS jun_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+7,'07'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS jul_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+7,'08'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS aug_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+7,'09'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS sep_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+7,'10'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS oct_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+7,'11'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS nov_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(period = concat(@curryear+7,'12'), if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0)), 0))) AS dec_year_8,

        SUM(if(sws_ccy_ind='Local CCY',ifnull(local_ccy_val,0),ifnull(group_ccy_val,0))) AS total_amt

    from sub_workstream_fin_details a,sub_workstream_dates b,((select distinct sub_workstream_id,local_ccy as sws_ccy_code,'Local CCY' as sws_ccy_ind
                                                               from sub_workstream_fin_details
                                                               where sub_workstream_id=@sws_id
                                                                 and sub_workstream_name=@sws_name
                                                                 and org_ind='False'
                                                              ) union
                                                              (select distinct sub_workstream_id,group_ccy as sws_ccy_code,'Group CCY' as sws_ccy_ind
                                                               from sub_workstream_fin_details
                                                               where sub_workstream_id=@sws_id
                                                                 and sub_workstream_name=@sws_name
                                                                 and org_ind='False'
                                                                 and group_ccy<>local_ccy
                                                              )) as sws_ccy_code

    where a.sub_workstream_id=@sws_id
      and a.sub_workstream_name=@sws_name
      and a.sub_workstream_id=b.sub_workstream_id
      and a.sub_workstream_name=b.sub_workstream_name
      and a.scenario=b.scenario_name
      and b.active_ind='True'
      and a.org_ind='False'

    group by
        portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        b.depre_start_date,
        eoy_date,
        ccy_code,
        gl_category,
        cost_type;

END//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_sws_fin_details_others`(
    IN `pfid` VARCHAR(100),
    IN `ws_id` VARCHAR(100),
    IN `sws_id` VARCHAR(100),
    IN `sws_name` VARCHAR(100),
    IN `depre_life` INT,
    IN `rptyear` VARCHAR(10)






)
BEGIN

    set @curryear=rptyear;

    set @lastyear_depre = (select year(end_date)+5 from sub_workstream_dates
                           where sub_workstream_id=@sws_id
                             and sub_workstream_name=@sws_name
                             and active_ind='True'
                             and scenario_name='Forecast');

    insert into sws_backend_fin_details(
        portfolio_id,
        workstream_id,
        sub_workstream_id,
        sub_workstream_name,
        scenario,
        cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_date,
        go_live_date,
        sws_end_date,
        depre_start_date,
        eoy_date,
        gl_category,
        cost_type,

        ccy_code,

        add_other,
        other_vendor,
        other_cost,

        other_gl_category,
        field_in_cost_type,

        jan_year_1,
        feb_year_1,
        mar_year_1,
        apr_year_1,
        may_year_1,
        jun_year_1,
        jul_year_1,
        aug_year_1,
        sep_year_1,
        oct_year_1,
        nov_year_1,
        dec_year_1,

        jan_year_2,
        feb_year_2,
        mar_year_2,
        apr_year_2,
        may_year_2,
        jun_year_2,
        jul_year_2,
        aug_year_2,
        sep_year_2,
        oct_year_2,
        nov_year_2,
        dec_year_2,

        jan_year_3,
        feb_year_3,
        mar_year_3,
        apr_year_3,
        may_year_3,
        jun_year_3,
        jul_year_3,
        aug_year_3,
        sep_year_3,
        oct_year_3,
        nov_year_3,
        dec_year_3,

        jan_year_4,
        feb_year_4,
        mar_year_4,
        apr_year_4,
        may_year_4,
        jun_year_4,
        jul_year_4,
        aug_year_4,
        sep_year_4,
        oct_year_4,
        nov_year_4,
        dec_year_4,

        jan_year_5,
        feb_year_5,
        mar_year_5,
        apr_year_5,
        may_year_5,
        jun_year_5,
        jul_year_5,
        aug_year_5,
        sep_year_5,
        oct_year_5,
        nov_year_5,
        dec_year_5,

        jan_year_6,
        feb_year_6,
        mar_year_6,
        apr_year_6,
        may_year_6,
        jun_year_6,
        jul_year_6,
        aug_year_6,
        sep_year_6,
        oct_year_6,
        nov_year_6,
        dec_year_6,

        jan_year_7,
        feb_year_7,
        mar_year_7,
        apr_year_7,
        may_year_7,
        jun_year_7,
        jul_year_7,
        aug_year_7,
        sep_year_7,
        oct_year_7,
        nov_year_7,
        dec_year_7,

        jan_year_8,
        feb_year_8,
        mar_year_8,
        apr_year_8,
        may_year_8,
        jun_year_8,
        jul_year_8,
        aug_year_8,
        sep_year_8,
        oct_year_8,
        nov_year_8,
        dec_year_8,

        total_amt
    )
    select distinct
        pfid as portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        null as lock_ind,
        null as fd_version,
        null as snapshot_date,
        null as agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        date_add(date_add(go_live_date,interval 60 day),interval -day(date_add(go_live_date,interval 60 day)) +1 day) as depre_start_date,
        last_day(go_live_date) as eoy_date,
        a.gl_category,
        type as cost_type,

        sws_ccy_code as ccy_code,

        c.add_other,
        vendor_name as other_vendor,

        (select distinct local_ccy_val
         from sub_workstream_other_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.vendor_name=c.vendor_name
           and d.type='Others'
           and c.original_ind='false'
           and d.original_ind='true') as other_cost,

        c.gl_category as other_gl_category,
        'Cost' as field_in_cost_type,

        SUM(IF(c.period = concat(@curryear,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jan_year_1,
        SUM(IF(c.period = concat(@curryear,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS feb_year_1,
        SUM(IF(c.period = concat(@curryear,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS mar_year_1,
        SUM(IF(c.period = concat(@curryear,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS apr_year_1,
        SUM(IF(c.period = concat(@curryear,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS may_year_1,
        SUM(IF(c.period = concat(@curryear,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jun_year_1,
        SUM(IF(c.period = concat(@curryear,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jul_year_1,
        SUM(IF(c.period = concat(@curryear,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS aug_year_1,
        SUM(IF(c.period = concat(@curryear,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS sep_year_1,
        SUM(IF(c.period = concat(@curryear,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS oct_year_1,
        SUM(IF(c.period = concat(@curryear,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS nov_year_1,
        SUM(IF(c.period = concat(@curryear,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS dec_year_1,

        SUM(IF(c.period = concat(@curryear+1,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jan_year_2,
        SUM(IF(c.period = concat(@curryear+1,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS feb_year_2,
        SUM(IF(c.period = concat(@curryear+1,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS mar_year_2,
        SUM(IF(c.period = concat(@curryear+1,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS apr_year_2,
        SUM(IF(c.period = concat(@curryear+1,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS may_year_2,
        SUM(IF(c.period = concat(@curryear+1,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jun_year_2,
        SUM(IF(c.period = concat(@curryear+1,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jul_year_2,
        SUM(IF(c.period = concat(@curryear+1,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS aug_year_2,
        SUM(IF(c.period = concat(@curryear+1,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS sep_year_2,
        SUM(IF(c.period = concat(@curryear+1,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS oct_year_2,
        SUM(IF(c.period = concat(@curryear+1,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS nov_year_2,
        SUM(IF(c.period = concat(@curryear+1,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS dec_year_2,

        SUM(IF(c.period = concat(@curryear+2,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jan_year_3,
        SUM(IF(c.period = concat(@curryear+2,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS feb_year_3,
        SUM(IF(c.period = concat(@curryear+2,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS mar_year_3,
        SUM(IF(c.period = concat(@curryear+2,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS apr_year_3,
        SUM(IF(c.period = concat(@curryear+2,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS may_year_3,
        SUM(IF(c.period = concat(@curryear+2,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jun_year_3,
        SUM(IF(c.period = concat(@curryear+2,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jul_year_3,
        SUM(IF(c.period = concat(@curryear+2,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS aug_year_3,
        SUM(IF(c.period = concat(@curryear+2,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS sep_year_3,
        SUM(IF(c.period = concat(@curryear+2,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS oct_year_3,
        SUM(IF(c.period = concat(@curryear+2,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS nov_year_3,
        SUM(IF(c.period = concat(@curryear+2,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS dec_year_3,

        SUM(IF(c.period = concat(@curryear+3,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jan_year_4,
        SUM(IF(c.period = concat(@curryear+3,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS feb_year_4,
        SUM(IF(c.period = concat(@curryear+3,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS mar_year_4,
        SUM(IF(c.period = concat(@curryear+3,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS apr_year_4,
        SUM(IF(c.period = concat(@curryear+3,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS may_year_4,
        SUM(IF(c.period = concat(@curryear+3,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jun_year_4,
        SUM(IF(c.period = concat(@curryear+3,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jul_year_4,
        SUM(IF(c.period = concat(@curryear+3,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS aug_year_4,
        SUM(IF(c.period = concat(@curryear+3,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS sep_year_4,
        SUM(IF(c.period = concat(@curryear+3,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS oct_year_4,
        SUM(IF(c.period = concat(@curryear+3,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS nov_year_4,
        SUM(IF(c.period = concat(@curryear+3,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS dec_year_4,

        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jan_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS feb_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS mar_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS apr_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS may_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jun_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jul_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS aug_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS sep_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS oct_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS nov_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS dec_year_5,

        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jan_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS feb_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS mar_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS apr_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS may_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jun_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jul_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS aug_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS sep_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS oct_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS nov_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS dec_year_6,

        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jan_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS feb_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS mar_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS apr_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS may_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jun_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jul_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS aug_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS sep_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS oct_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS nov_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS dec_year_7,

        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jan_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS feb_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS mar_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS apr_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS may_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jun_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jul_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS aug_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS sep_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS oct_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS nov_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS dec_year_8,

        SUM(if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0))) AS total_amt

    from sub_workstream_fin_details a,sub_workstream_dates b, sub_workstream_other_cost c, ((select distinct sub_workstream_id,local_ccy as sws_ccy_code,'Local CCY' as sws_ccy_ind
                                                                                             from sub_workstream_fin_details
                                                                                             where sub_workstream_id=@sws_id
                                                                                               and sub_workstream_name=@sws_name
                                                                                               and org_ind='False'
                                                                                            ) union
                                                                                            (select distinct sub_workstream_id,group_ccy as sws_ccy_code,'Group CCY' as sws_ccy_ind
                                                                                             from sub_workstream_fin_details
                                                                                             where sub_workstream_id=@sws_id
                                                                                               and sub_workstream_name=@sws_name
                                                                                               and group_ccy<>local_ccy
                                                                                               and org_ind='False'
                                                                                            )) as sws_ccy_code
    where a.sub_workstream_id=@sws_id
      and a.sub_workstream_name=@sws_name
      and a.sub_workstream_id=b.sub_workstream_id
      and a.sub_workstream_name=b.sub_workstream_name
      and a.scenario=b.scenario_name
      and b.active_ind='True'
      and a.sub_workstream_id=c.sub_workstream_id
      and a.sub_workstream_name=c.sub_workstream_name
      and a.scenario=c.scenario
      and a.org_ind='False'
      and c.original_ind='false'
      and c.type='Others'
    group by
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        b.depre_start_date,
        eoy_date,
        a.local_ccy,
        a.gl_category,
        vendor_name,
        c.gl_category;

END//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_sws_fin_details_resource_cost`(
    IN `pfid` VARCHAR(100),
    IN `ws_id` VARCHAR(100),
    IN `sws_id` VARCHAR(100),
    IN `sws_name` VARCHAR(100),
    IN `depre_life` INT,
    IN `rptyear` VARCHAR(100)




)
BEGIN

    set @eoydate=last_day(concat(rptyear,'-12-31'));

    set @lastyear_depre = (select year(end_date)+5 from sub_workstream_dates
                           where sub_workstream_id=@sws_id
                             and sub_workstream_name=@sws_name
                             and active_ind='True'
                             and scenario_name='Forecast');


    insert into sws_backend_fin_details(
        portfolio_id,
        workstream_id,
        sub_workstream_id,
        sub_workstream_name,
        scenario,
        cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_date,
        go_live_date,
        sws_end_date,
        depre_start_date,
        eoy_date,
        gl_category,
        cost_type,

        ccy_code,

        add_resource,
        team_name,
        team_role,
        team_location,
        staff_type,
        staff_vendor,
        rate_source,
        staff_level,
        fte,
        staff_rate,
        manday_per_month,
        cost_per_day,
        cost_per_month,
        charge_type,
        staff_gl_category,

        jan_year_1,
        feb_year_1,
        mar_year_1,
        apr_year_1,
        may_year_1,
        jun_year_1,
        jul_year_1,
        aug_year_1,
        sep_year_1,
        oct_year_1,
        nov_year_1,
        dec_year_1,

        jan_year_2,
        feb_year_2,
        mar_year_2,
        apr_year_2,
        may_year_2,
        jun_year_2,
        jul_year_2,
        aug_year_2,
        sep_year_2,
        oct_year_2,
        nov_year_2,
        dec_year_2,

        jan_year_3,
        feb_year_3,
        mar_year_3,
        apr_year_3,
        may_year_3,
        jun_year_3,
        jul_year_3,
        aug_year_3,
        sep_year_3,
        oct_year_3,
        nov_year_3,
        dec_year_3,

        jan_year_4,
        feb_year_4,
        mar_year_4,
        apr_year_4,
        may_year_4,
        jun_year_4,
        jul_year_4,
        aug_year_4,
        sep_year_4,
        oct_year_4,
        nov_year_4,
        dec_year_4,

        jan_year_5,
        feb_year_5,
        mar_year_5,
        apr_year_5,
        may_year_5,
        jun_year_5,
        jul_year_5,
        aug_year_5,
        sep_year_5,
        oct_year_5,
        nov_year_5,
        dec_year_5,

        jan_year_6,
        feb_year_6,
        mar_year_6,
        apr_year_6,
        may_year_6,
        jun_year_6,
        jul_year_6,
        aug_year_6,
        sep_year_6,
        oct_year_6,
        nov_year_6,
        dec_year_6,

        jan_year_7,
        feb_year_7,
        mar_year_7,
        apr_year_7,
        may_year_7,
        jun_year_7,
        jul_year_7,
        aug_year_7,
        sep_year_7,
        oct_year_7,
        nov_year_7,
        dec_year_7,

        jan_year_8,
        feb_year_8,
        mar_year_8,
        apr_year_8,
        may_year_8,
        jun_year_8,
        jul_year_8,
        aug_year_8,
        sep_year_8,
        oct_year_8,
        nov_year_8,
        dec_year_8,

        total_amt

    )
    select distinct
        pfid as portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        a.cost_settings,
        null as lock_ind,
        null as fd_version,
        null as snapshot_date,
        null as agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        date_add(date_add(go_live_date,interval depre_life day),interval -day(date_add(go_live_date,interval depre_life day)) +1 day) as depre_start_date,
        @eoydate as eoy_date,
        a.gl_category,
        cost_type,

        sws_ccy_code as ccy_code,

        add_resource,
        c.team_name,
        d.team_role,
        d.work_location as team_location,
        d.staff_type,
        d.vendor_name as staff_vendor,
        d.rate_source,
        d.skill_level as staff_level,
        d.planned_fte as fte,
        null as staff_rate,
        null as manday_per_month,
        null as cost_per_day,
        null as cost_per_month,
        null as charge_type,
        c.gl_category as staff_gl_category,

        SUM(IF(c.period = concat(@curryear,'01'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS jan_year_1,
        SUM(IF(c.period = concat(@curryear,'02'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS feb_year_1,
        SUM(IF(c.period = concat(@curryear,'03'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS mar_year_1,
        SUM(IF(c.period = concat(@curryear,'04'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS apr_year_1,
        SUM(IF(c.period = concat(@curryear,'05'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS may_year_1,
        SUM(IF(c.period = concat(@curryear,'06'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS jun_year_1,
        SUM(IF(c.period = concat(@curryear,'07'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS jul_year_1,
        SUM(IF(c.period = concat(@curryear,'08'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS aug_year_1,
        SUM(IF(c.period = concat(@curryear,'09'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS sep_year_1,
        SUM(IF(c.period = concat(@curryear,'10'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS oct_year_1,
        SUM(IF(c.period = concat(@curryear,'11'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS nov_year_1,
        SUM(IF(c.period = concat(@curryear,'12'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS dec_year_1,

        SUM(IF(c.period = concat(@curryear+1,'01'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS jan_year_2,
        SUM(IF(c.period = concat(@curryear+1,'02'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS feb_year_2,
        SUM(IF(c.period = concat(@curryear+1,'03'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS mar_year_2,
        SUM(IF(c.period = concat(@curryear+1,'04'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS apr_year_2,
        SUM(IF(c.period = concat(@curryear+1,'05'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS may_year_2,
        SUM(IF(c.period = concat(@curryear+1,'06'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS jun_year_2,
        SUM(IF(c.period = concat(@curryear+1,'07'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS jul_year_2,
        SUM(IF(c.period = concat(@curryear+1,'08'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS aug_year_2,
        SUM(IF(c.period = concat(@curryear+1,'09'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS sep_year_2,
        SUM(IF(c.period = concat(@curryear+1,'10'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS oct_year_2,
        SUM(IF(c.period = concat(@curryear+1,'11'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS nov_year_2,
        SUM(IF(c.period = concat(@curryear+1,'12'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS dec_year_2,

        SUM(IF(c.period = concat(@curryear+2,'01'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS jan_year_3,
        SUM(IF(c.period = concat(@curryear+2,'02'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS feb_year_3,
        SUM(IF(c.period = concat(@curryear+2,'03'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS mar_year_3,
        SUM(IF(c.period = concat(@curryear+2,'04'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS apr_year_3,
        SUM(IF(c.period = concat(@curryear+2,'05'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS may_year_3,
        SUM(IF(c.period = concat(@curryear+2,'06'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS jun_year_3,
        SUM(IF(c.period = concat(@curryear+2,'07'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS jul_year_3,
        SUM(IF(c.period = concat(@curryear+2,'08'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS aug_year_3,
        SUM(IF(c.period = concat(@curryear+2,'09'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS sep_year_3,
        SUM(IF(c.period = concat(@curryear+2,'10'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS oct_year_3,
        SUM(IF(c.period = concat(@curryear+2,'11'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS nov_year_3,
        SUM(IF(c.period = concat(@curryear+2,'12'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS dec_year_3,

        SUM(IF(c.period = concat(@curryear+3,'01'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS jan_year_4,
        SUM(IF(c.period = concat(@curryear+3,'02'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS feb_year_4,
        SUM(IF(c.period = concat(@curryear+3,'03'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS mar_year_4,
        SUM(IF(c.period = concat(@curryear+3,'04'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS apr_year_4,
        SUM(IF(c.period = concat(@curryear+3,'05'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS may_year_4,
        SUM(IF(c.period = concat(@curryear+3,'06'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS jun_year_4,
        SUM(IF(c.period = concat(@curryear+3,'07'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS jul_year_4,
        SUM(IF(c.period = concat(@curryear+3,'08'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS aug_year_4,
        SUM(IF(c.period = concat(@curryear+3,'09'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS sep_year_4,
        SUM(IF(c.period = concat(@curryear+3,'10'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS oct_year_4,
        SUM(IF(c.period = concat(@curryear+3,'11'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS nov_year_4,
        SUM(IF(c.period = concat(@curryear+3,'12'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0)) AS dec_year_4,

        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'01'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS jan_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'02'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS feb_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'03'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS mar_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'04'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS apr_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'05'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS may_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'06'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS jun_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'07'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS jul_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'08'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS aug_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'09'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS sep_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'10'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS oct_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'11'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS nov_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'12'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS dec_year_5,

        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'01'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS jan_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'02'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS feb_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'03'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS mar_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'04'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS apr_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'05'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS may_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'06'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS jun_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'07'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS jul_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'08'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS aug_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'09'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS sep_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'10'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS oct_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'11'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS nov_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'12'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS dec_year_6,

        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'01'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS jan_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'02'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS feb_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'03'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS mar_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'04'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS apr_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'05'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS may_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'06'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS jun_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'07'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS jul_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'08'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS aug_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'09'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS sep_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'10'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS oct_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'11'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS nov_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'12'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS dec_year_7,

        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'01'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS jan_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'02'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS feb_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'03'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS mar_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'04'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS apr_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'05'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS may_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'06'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS jun_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'07'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS jul_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'08'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS aug_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'09'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS sep_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'10'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS oct_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'11'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS nov_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'12'), if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0)), 0))) AS dec_year_8,

        SUM(if(sws_ccy_ind='Local CCY',ifnull(d.blended_cost_lcy,0),ifnull(d.blended_cost_gcy,0))) AS total_amt

    from sub_workstream_fin_details a,sub_workstream_dates b,sub_workstream_resource_cost c,team_planned_capacity d, ((select distinct sub_workstream_id,local_ccy as sws_ccy_code,'Local CCY' as sws_ccy_ind
                                                                                                                       from sub_workstream_fin_details
                                                                                                                       where sub_workstream_id=@sws_id
                                                                                                                         and sub_workstream_name=@sws_name
                                                                                                                         and org_ind='False'
                                                                                                                      ) union
                                                                                                                      (select distinct sub_workstream_id,group_ccy as sws_ccy_code,'Group CCY' as sws_ccy_ind
                                                                                                                       from sub_workstream_fin_details
                                                                                                                       where sub_workstream_id=@sws_id
                                                                                                                         and sub_workstream_name=@sws_name
                                                                                                                         and group_ccy<>local_ccy
                                                                                                                         and org_ind='False'
                                                                                                                      )) as sws_ccy_code

    where a.sub_workstream_id=@sws_id
      and a.sub_workstream_name=@sws_name
      and a.sub_workstream_id=b.sub_workstream_id
      and a.sub_workstream_name=b.sub_workstream_name
      and a.scenario=b.scenario_name
      and a.org_ind='False'
      and b.active_ind='True'
      and a.sub_workstream_id=c.sub_workstream_id
      and a.sub_workstream_name=c.sub_workstream_name
      and c.platform_index=d.platform_index
      and a.scenario=c.scenario
      and c.team_name=d.team_name

    group by
        portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        b.depre_start_date,
        eoy_date,
        ccy_code,
        gl_category,
        cost_type;

END//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_sws_fin_details_software`(
    IN `pfid` VARCHAR(100),
    IN `ws_id` VARCHAR(100),
    IN `sws_id` VARCHAR(100),
    IN `sws_name` VARCHAR(100),
    IN `depre_life` INT,
    IN `rptyear` VARCHAR(10)
)
BEGIN

    set @curryear=rptyear;

    set @eoydate=last_day(concat(rptyear,'-12-31'));

    set @lastyear_depre = (select year(end_date)+5 from sub_workstream_dates
                           where sub_workstream_id=@sws_id
                             and sub_workstream_name=@sws_name
                             and active_ind='True'
                             and scenario_name='Forecast');

-- Software Quantity
    insert into sws_backend_fin_details(
        portfolio_id,
        workstream_id,
        sub_workstream_id,
        sub_workstream_name,
        scenario,
        cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_date,
        go_live_date,
        sws_end_date,
        depre_start_date,
        eoy_date,
        gl_category,
        cost_type,

        ccy_code,

        add_software,
        sw_vendor,
        sw_name,
        sw_type,
        sw_unit_price,
        sw_quantity,
        sw_cost,

        sw_gl_category,
        field_in_cost_type,

        jan_year_1,
        feb_year_1,
        mar_year_1,
        apr_year_1,
        may_year_1,
        jun_year_1,
        jul_year_1,
        aug_year_1,
        sep_year_1,
        oct_year_1,
        nov_year_1,
        dec_year_1,

        jan_year_2,
        feb_year_2,
        mar_year_2,
        apr_year_2,
        may_year_2,
        jun_year_2,
        jul_year_2,
        aug_year_2,
        sep_year_2,
        oct_year_2,
        nov_year_2,
        dec_year_2,

        jan_year_3,
        feb_year_3,
        mar_year_3,
        apr_year_3,
        may_year_3,
        jun_year_3,
        jul_year_3,
        aug_year_3,
        sep_year_3,
        oct_year_3,
        nov_year_3,
        dec_year_3,

        jan_year_4,
        feb_year_4,
        mar_year_4,
        apr_year_4,
        may_year_4,
        jun_year_4,
        jul_year_4,
        aug_year_4,
        sep_year_4,
        oct_year_4,
        nov_year_4,
        dec_year_4,

        jan_year_5,
        feb_year_5,
        mar_year_5,
        apr_year_5,
        may_year_5,
        jun_year_5,
        jul_year_5,
        aug_year_5,
        sep_year_5,
        oct_year_5,
        nov_year_5,
        dec_year_5,

        jan_year_6,
        feb_year_6,
        mar_year_6,
        apr_year_6,
        may_year_6,
        jun_year_6,
        jul_year_6,
        aug_year_6,
        sep_year_6,
        oct_year_6,
        nov_year_6,
        dec_year_6,

        jan_year_7,
        feb_year_7,
        mar_year_7,
        apr_year_7,
        may_year_7,
        jun_year_7,
        jul_year_7,
        aug_year_7,
        sep_year_7,
        oct_year_7,
        nov_year_7,
        dec_year_7,

        jan_year_8,
        feb_year_8,
        mar_year_8,
        apr_year_8,
        may_year_8,
        jun_year_8,
        jul_year_8,
        aug_year_8,
        sep_year_8,
        oct_year_8,
        nov_year_8,
        dec_year_8,

        total_amt

    )
    select distinct
        pfid as portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        null as lock_ind,
        null as fd_version,
        null as snapshot_date,
        null as agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        date_add(date_add(go_live_date,interval 60 day),interval -day(date_add(go_live_date,interval 60 day)) +1 day) as depre_start_date,
        @eoydate as eoy_date,
        a.gl_category,
        cost_type,

        a.local_ccy as ccy_code,

        c.add_software,
        vendor_name as sw_vendor,
        software_name as sw_name,
        software_type as sw_type,
        unit_price as sw_unit_price,

        (select distinct quantity
         from sub_workstream_software_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.vendor_name=c.vendor_name
           and d.software_name=c.software_name
           and d.software_type=c.software_type
           and c.original_ind='false'
           and d.original_ind='true') as sw_quantity,

        (select distinct cost_per_month_lcy
         from sub_workstream_software_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.vendor_name=c.vendor_name
           and d.software_name=c.software_name
           and d.software_type=c.software_type
           and c.original_ind='false'
           and d.original_ind='true') as sw_cost,

        c.gl_category as sw_gl_category,
        'Qty' as field_in_cost_type,

        SUM(IF(c.period = concat(@curryear,'01'), ifnull(c.quantity,0), 0)) AS jan_year_1,
        SUM(IF(c.period = concat(@curryear,'02'), ifnull(c.quantity,0), 0)) AS feb_year_1,
        SUM(IF(c.period = concat(@curryear,'03'), ifnull(c.quantity,0), 0)) AS mar_year_1,
        SUM(IF(c.period = concat(@curryear,'04'), ifnull(c.quantity,0), 0)) AS apr_year_1,
        SUM(IF(c.period = concat(@curryear,'05'), ifnull(c.quantity,0), 0)) AS may_year_1,
        SUM(IF(c.period = concat(@curryear,'06'), ifnull(c.quantity,0), 0)) AS jun_year_1,
        SUM(IF(c.period = concat(@curryear,'07'), ifnull(c.quantity,0), 0)) AS jul_year_1,
        SUM(IF(c.period = concat(@curryear,'08'), ifnull(c.quantity,0), 0)) AS aug_year_1,
        SUM(IF(c.period = concat(@curryear,'09'), ifnull(c.quantity,0), 0)) AS sep_year_1,
        SUM(IF(c.period = concat(@curryear,'10'), ifnull(c.quantity,0), 0)) AS oct_year_1,
        SUM(IF(c.period = concat(@curryear,'11'), ifnull(c.quantity,0), 0)) AS nov_year_1,
        SUM(IF(c.period = concat(@curryear,'12'), ifnull(c.quantity,0), 0)) AS dec_year_1,

        SUM(IF(c.period = concat(@curryear+1,'01'), ifnull(c.quantity,0), 0)) AS jan_year_2,
        SUM(IF(c.period = concat(@curryear+1,'02'), ifnull(c.quantity,0), 0)) AS feb_year_2,
        SUM(IF(c.period = concat(@curryear+1,'03'), ifnull(c.quantity,0), 0)) AS mar_year_2,
        SUM(IF(c.period = concat(@curryear+1,'04'), ifnull(c.quantity,0), 0)) AS apr_year_2,
        SUM(IF(c.period = concat(@curryear+1,'05'), ifnull(c.quantity,0), 0)) AS may_year_2,
        SUM(IF(c.period = concat(@curryear+1,'06'), ifnull(c.quantity,0), 0)) AS jun_year_2,
        SUM(IF(c.period = concat(@curryear+1,'07'), ifnull(c.quantity,0), 0)) AS jul_year_2,
        SUM(IF(c.period = concat(@curryear+1,'08'), ifnull(c.quantity,0), 0)) AS aug_year_2,
        SUM(IF(c.period = concat(@curryear+1,'09'), ifnull(c.quantity,0), 0)) AS sep_year_2,
        SUM(IF(c.period = concat(@curryear+1,'10'), ifnull(c.quantity,0), 0)) AS oct_year_2,
        SUM(IF(c.period = concat(@curryear+1,'11'), ifnull(c.quantity,0), 0)) AS nov_year_2,
        SUM(IF(c.period = concat(@curryear+1,'12'), ifnull(c.quantity,0), 0)) AS dec_year_2,

        SUM(IF(c.period = concat(@curryear+2,'01'), ifnull(c.quantity,0), 0)) AS jan_year_3,
        SUM(IF(c.period = concat(@curryear+2,'02'), ifnull(c.quantity,0), 0)) AS feb_year_3,
        SUM(IF(c.period = concat(@curryear+2,'03'), ifnull(c.quantity,0), 0)) AS mar_year_3,
        SUM(IF(c.period = concat(@curryear+2,'04'), ifnull(c.quantity,0), 0)) AS apr_year_3,
        SUM(IF(c.period = concat(@curryear+2,'05'), ifnull(c.quantity,0), 0)) AS may_year_3,
        SUM(IF(c.period = concat(@curryear+2,'06'), ifnull(c.quantity,0), 0)) AS jun_year_3,
        SUM(IF(c.period = concat(@curryear+2,'07'), ifnull(c.quantity,0), 0)) AS jul_year_3,
        SUM(IF(c.period = concat(@curryear+2,'08'), ifnull(c.quantity,0), 0)) AS aug_year_3,
        SUM(IF(c.period = concat(@curryear+2,'09'), ifnull(c.quantity,0), 0)) AS sep_year_3,
        SUM(IF(c.period = concat(@curryear+2,'10'), ifnull(c.quantity,0), 0)) AS oct_year_3,
        SUM(IF(c.period = concat(@curryear+2,'11'), ifnull(c.quantity,0), 0)) AS nov_year_3,
        SUM(IF(c.period = concat(@curryear+2,'12'), ifnull(c.quantity,0), 0)) AS dec_year_3,

        SUM(IF(c.period = concat(@curryear+3,'01'), ifnull(c.quantity,0), 0)) AS jan_year_4,
        SUM(IF(c.period = concat(@curryear+3,'02'), ifnull(c.quantity,0), 0)) AS feb_year_4,
        SUM(IF(c.period = concat(@curryear+3,'03'), ifnull(c.quantity,0), 0)) AS mar_year_4,
        SUM(IF(c.period = concat(@curryear+3,'04'), ifnull(c.quantity,0), 0)) AS apr_year_4,
        SUM(IF(c.period = concat(@curryear+3,'05'), ifnull(c.quantity,0), 0)) AS may_year_4,
        SUM(IF(c.period = concat(@curryear+3,'06'), ifnull(c.quantity,0), 0)) AS jun_year_4,
        SUM(IF(c.period = concat(@curryear+3,'07'), ifnull(c.quantity,0), 0)) AS jul_year_4,
        SUM(IF(c.period = concat(@curryear+3,'08'), ifnull(c.quantity,0), 0)) AS aug_year_4,
        SUM(IF(c.period = concat(@curryear+3,'09'), ifnull(c.quantity,0), 0)) AS sep_year_4,
        SUM(IF(c.period = concat(@curryear+3,'10'), ifnull(c.quantity,0), 0)) AS oct_year_4,
        SUM(IF(c.period = concat(@curryear+3,'11'), ifnull(c.quantity,0), 0)) AS nov_year_4,
        SUM(IF(c.period = concat(@curryear+3,'12'), ifnull(c.quantity,0), 0)) AS dec_year_4,

        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'01'), ifnull(c.quantity,0), 0))) AS jan_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'02'), ifnull(c.quantity,0), 0))) AS feb_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'03'), ifnull(c.quantity,0), 0))) AS mar_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'04'), ifnull(c.quantity,0), 0))) AS apr_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'05'), ifnull(c.quantity,0), 0))) AS may_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'06'), ifnull(c.quantity,0), 0))) AS jun_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'07'), ifnull(c.quantity,0), 0))) AS jul_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'08'), ifnull(c.quantity,0), 0))) AS aug_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'09'), ifnull(c.quantity,0), 0))) AS sep_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'10'), ifnull(c.quantity,0), 0))) AS oct_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'11'), ifnull(c.quantity,0), 0))) AS nov_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'12'), ifnull(c.quantity,0), 0))) AS dec_year_5,

        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'01'), ifnull(c.quantity,0), 0))) AS jan_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'02'), ifnull(c.quantity,0), 0))) AS feb_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'03'), ifnull(c.quantity,0), 0))) AS mar_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'04'), ifnull(c.quantity,0), 0))) AS apr_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'05'), ifnull(c.quantity,0), 0))) AS may_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'06'), ifnull(c.quantity,0), 0))) AS jun_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'07'), ifnull(c.quantity,0), 0))) AS jul_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'08'), ifnull(c.quantity,0), 0))) AS aug_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'09'), ifnull(c.quantity,0), 0))) AS sep_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'10'), ifnull(c.quantity,0), 0))) AS oct_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'11'), ifnull(c.quantity,0), 0))) AS nov_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'12'), ifnull(c.quantity,0), 0))) AS dec_year_6,

        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'01'), ifnull(c.quantity,0), 0))) AS jan_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'02'), ifnull(c.quantity,0), 0))) AS feb_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'03'), ifnull(c.quantity,0), 0))) AS mar_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'04'), ifnull(c.quantity,0), 0))) AS apr_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'05'), ifnull(c.quantity,0), 0))) AS may_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'06'), ifnull(c.quantity,0), 0))) AS jun_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'07'), ifnull(c.quantity,0), 0))) AS jul_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'08'), ifnull(c.quantity,0), 0))) AS aug_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'09'), ifnull(c.quantity,0), 0))) AS sep_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'10'), ifnull(c.quantity,0), 0))) AS oct_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'11'), ifnull(c.quantity,0), 0))) AS nov_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'12'), ifnull(c.quantity,0), 0))) AS dec_year_7,

        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'01'), ifnull(c.quantity,0), 0))) AS jan_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'02'), ifnull(c.quantity,0), 0))) AS feb_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'03'), ifnull(c.quantity,0), 0))) AS mar_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'04'), ifnull(c.quantity,0), 0))) AS apr_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'05'), ifnull(c.quantity,0), 0))) AS may_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'06'), ifnull(c.quantity,0), 0))) AS jun_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'07'), ifnull(c.quantity,0), 0))) AS jul_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'08'), ifnull(c.quantity,0), 0))) AS aug_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'09'), ifnull(c.quantity,0), 0))) AS sep_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'10'), ifnull(c.quantity,0), 0))) AS oct_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'11'), ifnull(c.quantity,0), 0))) AS nov_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'12'), ifnull(c.quantity,0), 0))) AS dec_year_8,

        SUM(ifnull(c.quantity,0)) AS total_amt

    from sub_workstream_fin_details a,sub_workstream_dates b, sub_workstream_software_cost c
    where a.sub_workstream_id=@sws_id
      and a.sub_workstream_name=@sws_name
      and a.sub_workstream_id=b.sub_workstream_id
      and a.sub_workstream_name=b.sub_workstream_name
      and a.scenario=b.scenario_name
      and b.active_ind='True'
      and a.sub_workstream_id=c.sub_workstream_id
      and a.sub_workstream_name=c.sub_workstream_name
      and a.scenario=c.scenario
      and c.original_ind='false'
      and cost_type='Software'
    group by
        portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        b.depre_start_date,
        eoy_date,
        a.local_ccy,
        a.gl_category,
        cost_type,
        add_software,
        vendor_name,
        software_name,
        software_type;

-- Software Cost
    insert into sws_backend_fin_details(
        portfolio_id,
        workstream_id,
        sub_workstream_id,
        sub_workstream_name,
        scenario,
        cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_date,
        go_live_date,
        sws_end_date,
        depre_start_date,
        eoy_date,
        gl_category,
        cost_type,

        ccy_code,

        add_software,
        sw_vendor,
        sw_name,
        sw_type,
        sw_unit_price,
        sw_quantity,
        sw_cost,

        sw_gl_category,
        field_in_cost_type,

        jan_year_1,
        feb_year_1,
        mar_year_1,
        apr_year_1,
        may_year_1,
        jun_year_1,
        jul_year_1,
        aug_year_1,
        sep_year_1,
        oct_year_1,
        nov_year_1,
        dec_year_1,

        jan_year_2,
        feb_year_2,
        mar_year_2,
        apr_year_2,
        may_year_2,
        jun_year_2,
        jul_year_2,
        aug_year_2,
        sep_year_2,
        oct_year_2,
        nov_year_2,
        dec_year_2,

        jan_year_3,
        feb_year_3,
        mar_year_3,
        apr_year_3,
        may_year_3,
        jun_year_3,
        jul_year_3,
        aug_year_3,
        sep_year_3,
        oct_year_3,
        nov_year_3,
        dec_year_3,

        jan_year_4,
        feb_year_4,
        mar_year_4,
        apr_year_4,
        may_year_4,
        jun_year_4,
        jul_year_4,
        aug_year_4,
        sep_year_4,
        oct_year_4,
        nov_year_4,
        dec_year_4,

        jan_year_5,
        feb_year_5,
        mar_year_5,
        apr_year_5,
        may_year_5,
        jun_year_5,
        jul_year_5,
        aug_year_5,
        sep_year_5,
        oct_year_5,
        nov_year_5,
        dec_year_5,

        jan_year_6,
        feb_year_6,
        mar_year_6,
        apr_year_6,
        may_year_6,
        jun_year_6,
        jul_year_6,
        aug_year_6,
        sep_year_6,
        oct_year_6,
        nov_year_6,
        dec_year_6,

        jan_year_7,
        feb_year_7,
        mar_year_7,
        apr_year_7,
        may_year_7,
        jun_year_7,
        jul_year_7,
        aug_year_7,
        sep_year_7,
        oct_year_7,
        nov_year_7,
        dec_year_7,

        jan_year_8,
        feb_year_8,
        mar_year_8,
        apr_year_8,
        may_year_8,
        jun_year_8,
        jul_year_8,
        aug_year_8,
        sep_year_8,
        oct_year_8,
        nov_year_8,
        dec_year_8,

        total_amt

    )
    select distinct
        pfid as portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        null as lock_ind,
        null as fd_version,
        null as snapshot_date,
        null as agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        date_add(date_add(go_live_date,interval depre_life day),interval -day(date_add(go_live_date,interval depre_life day)) +1 day) as depre_start_date,
        @eoydate as eoy_date,
        a.gl_category,
        cost_type,

        sws_ccy_code as ccy_code,

        c.add_software,
        vendor_name as sw_vendor,
        software_name as sw_name,
        software_type as sw_type,
        unit_price as sw_unit_price,

        (select distinct quantity
         from sub_workstream_software_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.vendor_name=c.vendor_name
           and d.software_name=c.software_name
           and d.software_type=c.software_type
           and c.original_ind='false'
           and d.original_ind='true') as sw_quantity,

        (select distinct cost_per_month_lcy
         from sub_workstream_software_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.vendor_name=c.vendor_name
           and d.software_name=c.software_name
           and d.software_type=c.software_type
           and c.original_ind='false'
           and d.original_ind='true') as sw_cost,

        c.gl_category as sw_gl_category,
        'Cost' as field_in_cost_type,

        SUM(IF(c.period = concat(@curryear,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jan_year_1,
        SUM(IF(c.period = concat(@curryear,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS feb_year_1,
        SUM(IF(c.period = concat(@curryear,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS mar_year_1,
        SUM(IF(c.period = concat(@curryear,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS apr_year_1,
        SUM(IF(c.period = concat(@curryear,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS may_year_1,
        SUM(IF(c.period = concat(@curryear,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jun_year_1,
        SUM(IF(c.period = concat(@curryear,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jul_year_1,
        SUM(IF(c.period = concat(@curryear,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS aug_year_1,
        SUM(IF(c.period = concat(@curryear,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS sep_year_1,
        SUM(IF(c.period = concat(@curryear,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS oct_year_1,
        SUM(IF(c.period = concat(@curryear,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS nov_year_1,
        SUM(IF(c.period = concat(@curryear,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS dec_year_1,

        SUM(IF(c.period = concat(@curryear+1,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jan_year_2,
        SUM(IF(c.period = concat(@curryear+1,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS feb_year_2,
        SUM(IF(c.period = concat(@curryear+1,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS mar_year_2,
        SUM(IF(c.period = concat(@curryear+1,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS apr_year_2,
        SUM(IF(c.period = concat(@curryear+1,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS may_year_2,
        SUM(IF(c.period = concat(@curryear+1,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jun_year_2,
        SUM(IF(c.period = concat(@curryear+1,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jul_year_2,
        SUM(IF(c.period = concat(@curryear+1,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS aug_year_2,
        SUM(IF(c.period = concat(@curryear+1,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS sep_year_2,
        SUM(IF(c.period = concat(@curryear+1,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS oct_year_2,
        SUM(IF(c.period = concat(@curryear+1,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS nov_year_2,
        SUM(IF(c.period = concat(@curryear+1,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS dec_year_2,

        SUM(IF(c.period = concat(@curryear+2,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jan_year_3,
        SUM(IF(c.period = concat(@curryear+2,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS feb_year_3,
        SUM(IF(c.period = concat(@curryear+2,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS mar_year_3,
        SUM(IF(c.period = concat(@curryear+2,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS apr_year_3,
        SUM(IF(c.period = concat(@curryear+2,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS may_year_3,
        SUM(IF(c.period = concat(@curryear+2,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jun_year_3,
        SUM(IF(c.period = concat(@curryear+2,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jul_year_3,
        SUM(IF(c.period = concat(@curryear+2,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS aug_year_3,
        SUM(IF(c.period = concat(@curryear+2,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS sep_year_3,
        SUM(IF(c.period = concat(@curryear+2,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS oct_year_3,
        SUM(IF(c.period = concat(@curryear+2,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS nov_year_3,
        SUM(IF(c.period = concat(@curryear+2,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS dec_year_3,

        SUM(IF(c.period = concat(@curryear+3,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jan_year_4,
        SUM(IF(c.period = concat(@curryear+3,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS feb_year_4,
        SUM(IF(c.period = concat(@curryear+3,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS mar_year_4,
        SUM(IF(c.period = concat(@curryear+3,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS apr_year_4,
        SUM(IF(c.period = concat(@curryear+3,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS may_year_4,
        SUM(IF(c.period = concat(@curryear+3,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jun_year_4,
        SUM(IF(c.period = concat(@curryear+3,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS jul_year_4,
        SUM(IF(c.period = concat(@curryear+3,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS aug_year_4,
        SUM(IF(c.period = concat(@curryear+3,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS sep_year_4,
        SUM(IF(c.period = concat(@curryear+3,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS oct_year_4,
        SUM(IF(c.period = concat(@curryear+3,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS nov_year_4,
        SUM(IF(c.period = concat(@curryear+3,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS dec_year_4,

        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jan_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS feb_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS mar_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS apr_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS may_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jun_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jul_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS aug_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS sep_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS oct_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS nov_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS dec_year_5,

        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jan_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS feb_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS mar_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS apr_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS may_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jun_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jul_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS aug_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS sep_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS oct_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS nov_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS dec_year_6,

        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jan_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS feb_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS mar_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS apr_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS may_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jun_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jul_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS aug_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS sep_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS oct_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS nov_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS dec_year_7,

        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jan_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS feb_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS mar_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS apr_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS may_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jun_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS jul_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS aug_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS sep_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS oct_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS nov_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0))) AS dec_year_8,

        SUM(if(sws_ccy_ind='Local CCY',if(sws_ccy_ind='Local CCY',ifnull(c.cost_per_month_lcy,0),ifnull(c.cost_per_month_gcy,0)), 0)) AS total_amt

    from sub_workstream_fin_details a,sub_workstream_dates b, sub_workstream_software_cost c,((select distinct sub_workstream_id,local_ccy as sws_ccy_code,'Local CCY' as sws_ccy_ind
                                                                                               from sub_workstream_fin_details
                                                                                               where sub_workstream_id=@sws_id
                                                                                                 and sub_workstream_name=@sws_name
                                                                                              ) union
                                                                                              (select distinct sub_workstream_id,group_ccy as sws_ccy_code,'Group CCY' as sws_ccy_ind
                                                                                               from sub_workstream_fin_details
                                                                                               where sub_workstream_id=@sws_id
                                                                                                 and sub_workstream_name=@sws_name
                                                                                                 and group_ccy<>local_ccy
                                                                                              )) as sws_ccy_code
    where a.sub_workstream_id=@sws_id
      and a.sub_workstream_name=@sws_name
      and a.sub_workstream_id=b.sub_workstream_id
      and a.sub_workstream_name=b.sub_workstream_name
      and a.scenario=b.scenario_name
      and b.active_ind='True'
      and a.sub_workstream_id=c.sub_workstream_id
      and a.sub_workstream_name=c.sub_workstream_name
      and a.scenario=c.scenario_name
      and a.scenario=c.scenario
      and c.original_ind='false'
      and cost_type='Software'
    group by
        portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        b.depre_start_date,
        eoy_date,
        a.local_ccy,
        a.gl_category,
        cost_type,
        add_software,
        vendor_name,
        software_name,
        software_type;

-- Other Software
    insert into sws_backend_fin_details(
        portfolio_id,
        workstream_id,
        sub_workstream_id,
        sub_workstream_name,
        scenario,
        cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_date,
        go_live_date,
        sws_end_date,
        depre_start_date,
        eoy_date,
        gl_category,
        cost_type,

        ccy_code,

        add_software,
        sw_vendor,
        sw_name,
        sw_type,
        sw_unit_price,
        sw_quantity,
        sw_cost,

        sw_gl_category,
        field_in_cost_type,

        jan_year_1,
        feb_year_1,
        mar_year_1,
        apr_year_1,
        may_year_1,
        jun_year_1,
        jul_year_1,
        aug_year_1,
        sep_year_1,
        oct_year_1,
        nov_year_1,
        dec_year_1,

        jan_year_2,
        feb_year_2,
        mar_year_2,
        apr_year_2,
        may_year_2,
        jun_year_2,
        jul_year_2,
        aug_year_2,
        sep_year_2,
        oct_year_2,
        nov_year_2,
        dec_year_2,

        jan_year_3,
        feb_year_3,
        mar_year_3,
        apr_year_3,
        may_year_3,
        jun_year_3,
        jul_year_3,
        aug_year_3,
        sep_year_3,
        oct_year_3,
        nov_year_3,
        dec_year_3,

        jan_year_4,
        feb_year_4,
        mar_year_4,
        apr_year_4,
        may_year_4,
        jun_year_4,
        jul_year_4,
        aug_year_4,
        sep_year_4,
        oct_year_4,
        nov_year_4,
        dec_year_4,

        jan_year_5,
        feb_year_5,
        mar_year_5,
        apr_year_5,
        may_year_5,
        jun_year_5,
        jul_year_5,
        aug_year_5,
        sep_year_5,
        oct_year_5,
        nov_year_5,
        dec_year_5,

        jan_year_6,
        feb_year_6,
        mar_year_6,
        apr_year_6,
        may_year_6,
        jun_year_6,
        jul_year_6,
        aug_year_6,
        sep_year_6,
        oct_year_6,
        nov_year_6,
        dec_year_6,

        jan_year_7,
        feb_year_7,
        mar_year_7,
        apr_year_7,
        may_year_7,
        jun_year_7,
        jul_year_7,
        aug_year_7,
        sep_year_7,
        oct_year_7,
        nov_year_7,
        dec_year_7,

        jan_year_8,
        feb_year_8,
        mar_year_8,
        apr_year_8,
        may_year_8,
        jun_year_8,
        jul_year_8,
        aug_year_8,
        sep_year_8,
        oct_year_8,
        nov_year_8,
        dec_year_8,

        total_amt

    )
    select distinct
        pfid as portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        null as lock_ind,
        null as fd_version,
        null as snapshot_date,
        null as agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        date_add(date_add(go_live_date,interval 60 day),interval -day(date_add(go_live_date,interval 60 day)) +1 day) as depre_start_date,
        @eoydate as eoy_date,
        a.gl_category,
        type as cost_type,

        sws_ccy_code as ccy_code,

        c.add_other,
        vendor_name as sw_vendor,
        other_descr as sw_name,
        null as sw_type,
        null as sw_unit_price,
        null as sw_quantity,

        (select distinct if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0))
         from sub_workstream_other_cost d
         where d.sub_workstream_id=@sws_id
           and d.sub_workstream_name=@sws_name
           and d.sub_workstream_id=c.sub_workstream_id
           and d.sub_workstream_name=c.sub_workstream_name
           and d.vendor_name=c.vendor_name
           and d.type='Software'
           and c.original_ind='false'
           and d.original_ind='true') as sw_cost,

        c.gl_category as sw_gl_category,
        'Cost' as field_in_cost_type,

        SUM(IF(c.period = concat(@curryear,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jan_year_1,
        SUM(IF(c.period = concat(@curryear,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS feb_year_1,
        SUM(IF(c.period = concat(@curryear,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS mar_year_1,
        SUM(IF(c.period = concat(@curryear,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS apr_year_1,
        SUM(IF(c.period = concat(@curryear,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS may_year_1,
        SUM(IF(c.period = concat(@curryear,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jun_year_1,
        SUM(IF(c.period = concat(@curryear,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jul_year_1,
        SUM(IF(c.period = concat(@curryear,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS aug_year_1,
        SUM(IF(c.period = concat(@curryear,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS sep_year_1,
        SUM(IF(c.period = concat(@curryear,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS oct_year_1,
        SUM(IF(c.period = concat(@curryear,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS nov_year_1,
        SUM(IF(c.period = concat(@curryear,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS dec_year_1,

        SUM(IF(c.period = concat(@curryear+1,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jan_year_2,
        SUM(IF(c.period = concat(@curryear+1,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS feb_year_2,
        SUM(IF(c.period = concat(@curryear+1,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS mar_year_2,
        SUM(IF(c.period = concat(@curryear+1,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS apr_year_2,
        SUM(IF(c.period = concat(@curryear+1,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS may_year_2,
        SUM(IF(c.period = concat(@curryear+1,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jun_year_2,
        SUM(IF(c.period = concat(@curryear+1,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jul_year_2,
        SUM(IF(c.period = concat(@curryear+1,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS aug_year_2,
        SUM(IF(c.period = concat(@curryear+1,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS sep_year_2,
        SUM(IF(c.period = concat(@curryear+1,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS oct_year_2,
        SUM(IF(c.period = concat(@curryear+1,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS nov_year_2,
        SUM(IF(c.period = concat(@curryear+1,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS dec_year_2,

        SUM(IF(c.period = concat(@curryear+2,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jan_year_3,
        SUM(IF(c.period = concat(@curryear+2,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS feb_year_3,
        SUM(IF(c.period = concat(@curryear+2,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS mar_year_3,
        SUM(IF(c.period = concat(@curryear+2,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS apr_year_3,
        SUM(IF(c.period = concat(@curryear+2,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS may_year_3,
        SUM(IF(c.period = concat(@curryear+2,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jun_year_3,
        SUM(IF(c.period = concat(@curryear+2,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jul_year_3,
        SUM(IF(c.period = concat(@curryear+2,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS aug_year_3,
        SUM(IF(c.period = concat(@curryear+2,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS sep_year_3,
        SUM(IF(c.period = concat(@curryear+2,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS oct_year_3,
        SUM(IF(c.period = concat(@curryear+2,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS nov_year_3,
        SUM(IF(c.period = concat(@curryear+2,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS dec_year_3,

        SUM(IF(c.period = concat(@curryear+3,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jan_year_4,
        SUM(IF(c.period = concat(@curryear+3,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS feb_year_4,
        SUM(IF(c.period = concat(@curryear+3,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS mar_year_4,
        SUM(IF(c.period = concat(@curryear+3,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS apr_year_4,
        SUM(IF(c.period = concat(@curryear+3,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS may_year_4,
        SUM(IF(c.period = concat(@curryear+3,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jun_year_4,
        SUM(IF(c.period = concat(@curryear+3,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS jul_year_4,
        SUM(IF(c.period = concat(@curryear+3,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS aug_year_4,
        SUM(IF(c.period = concat(@curryear+3,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS sep_year_4,
        SUM(IF(c.period = concat(@curryear+3,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS oct_year_4,
        SUM(IF(c.period = concat(@curryear+3,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS nov_year_4,
        SUM(IF(c.period = concat(@curryear+3,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0)) AS dec_year_4,

        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jan_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS feb_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS mar_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS apr_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS may_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jun_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jul_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS aug_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS sep_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS oct_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS nov_year_5,
        if(@curryear+4>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+4,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS dec_year_5,

        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jan_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS feb_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS mar_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS apr_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS may_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jun_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jul_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS aug_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS sep_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS oct_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS nov_year_6,
        if(@curryear+5>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+5,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS dec_year_6,

        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jan_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS feb_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS mar_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS apr_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS may_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jun_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jul_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS aug_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS sep_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS oct_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS nov_year_7,
        if(@curryear+6>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+6,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS dec_year_7,

        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'01'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jan_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'02'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS feb_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'03'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS mar_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'04'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS apr_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'05'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS may_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'06'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jun_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'07'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS jul_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'08'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS aug_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'09'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS sep_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'10'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS oct_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'11'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS nov_year_8,
        if(@curryear+7>=@lastyear_depre,0,SUM(IF(c.period = concat(@curryear+7,'12'), if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0)), 0))) AS dec_year_8,

        SUM(if(sws_ccy_ind='Local CCY',ifnull(c.local_ccy_val,0),ifnull(c.group_ccy_val,0))) AS total_amt

    from sub_workstream_fin_details a,sub_workstream_dates b, sub_workstream_other_cost c, ((select distinct sub_workstream_id,local_ccy as sws_ccy_code,'Local CCY' as sws_ccy_ind
                                                                                             from sub_workstream_fin_details
                                                                                             where sub_workstream_id=@sws_id
                                                                                               and sub_workstream_name=@sws_name
                                                                                            ) union
                                                                                            (select distinct sub_workstream_id,group_ccy as sws_ccy_code,'Group CCY' as sws_ccy_ind
                                                                                             from sub_workstream_fin_details
                                                                                             where sub_workstream_id=@sws_id
                                                                                               and sub_workstream_name=@sws_name
                                                                                               and group_ccy<>local_ccy
                                                                                            )) as sws_ccy_code
    where a.sub_workstream_id=@sws_id
      and a.sub_workstream_name=@sws_name
      and a.sub_workstream_id=b.sub_workstream_id
      and a.sub_workstream_name=b.sub_workstream_name
      and a.scenario=b.scenario_name
      and b.active_ind='True'
      and a.sub_workstream_id=c.sub_workstream_id
      and a.sub_workstream_name=c.sub_workstream_name
      and a.scenario=c.scenario
      and c.original_ind='false'
      and c.type='Software'
    group by
        portfolio_id,
        a.workstream_id,
        a.sub_workstream_id,
        a.sub_workstream_name,
        a.scenario,
        c.cost_settings,
        lock_ind,
        fd_version,
        snapshot_date,
        agile_waterfall,
        approval_date,
        start_date,
        sw_eng_start_date,
        go_live_date,
        end_date,
        b.depre_start_date,
        eoy_date,
        ccy_code,
        a.gl_category,
        vendor_name,
        c.gl_category;


END//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_update_allprevious_month_forecast_to_inactive`()
begin

    DECLARE id1 varchar(100) DEFAULT "";
    DECLARE id2 varchar(100) DEFAULT "";
    DECLARE id3 varchar(100) DEFAULT "";
    DECLARE id4 varchar(100) DEFAULT "";
    DECLARE done1 INT DEFAULT FALSE;
    DECLARE done2 INT DEFAULT FALSE;
    DECLARE done3 INT DEFAULT FALSE;
    DECLARE done4 INT DEFAULT FALSE;

    DECLARE sub_workstream_hardware_cost_cursor
        CURSOR FOR
        select sws_hw_surr_id from sub_workstream_hardware_cost
        where scenario ='Forecast'
          and active_ind = 'true' and original_ind = 'false'
          and ((month(STR_TO_DATE(period, '%Y%m')) < MONTH(current_date())
            and (year(STR_TO_DATE(period, '%Y')) = year(STR_TO_DATE(current_date(), '%Y'))))
            or ( year(STR_TO_DATE(period, '%Y')) < year(STR_TO_DATE(current_date(), '%Y'))));

    DECLARE sub_workstream_software_cost_cursor
        CURSOR FOR
        select sw_cost_surr_id from sub_workstream_software_cost
        where scenario ='Forecast'
          and active_ind = 'true' and original_ind = 'false'
          and ((month(STR_TO_DATE(period, '%Y%m')) < MONTH(current_date())
            and (year(STR_TO_DATE(period, '%Y')) = year(STR_TO_DATE(current_date(), '%Y'))))
            or ( year(STR_TO_DATE(period, '%Y')) < year(STR_TO_DATE(current_date(), '%Y'))));

    DECLARE sub_workstream_other_cost_cursor
        CURSOR FOR
        select sws_other_surr_id from sub_workstream_other_cost
        where scenario ='Forecast'
          and active_ind = 'true' and original_ind = 'false'
          and ((month(STR_TO_DATE(period, '%Y%m')) < MONTH(current_date())
            and (year(STR_TO_DATE(period, '%Y')) = year(STR_TO_DATE(current_date(), '%Y'))))
            or ( year(STR_TO_DATE(period, '%Y')) < year(STR_TO_DATE(current_date(), '%Y'))));

    DECLARE sub_workstream_resource_cost_cursor
        CURSOR FOR
        select sws_resource_surr_id from sub_workstream_resource_cost
        where scenario ='Forecast'
          and active_ind = 'true' and original_ind = 'false'
          and ((month(STR_TO_DATE(period, '%Y%m')) < MONTH(current_date())
            and (year(STR_TO_DATE(period, '%Y')) = year(STR_TO_DATE(current_date(), '%Y'))))
            or ( year(STR_TO_DATE(period, '%Y')) < year(STR_TO_DATE(current_date(), '%Y'))));



-- SELECT concat('first loop');

    OPEN sub_workstream_hardware_cost_cursor;

    BLOCK1: begin
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done1 = TRUE;

        sub_workstream_hardware_cost_cursor_1: LOOP
            FETCH sub_workstream_hardware_cost_cursor INTO id1;
            IF done1 THEN
                -- SELECT concat('end first loop');
                LEAVE sub_workstream_hardware_cost_cursor_1;
            END IF;
            SELECT concat('loop id1=', id1);
            update sub_workstream_hardware_cost set active_ind = 'false'
            where scenario ='Forecast' and active_ind = 'true' and original_ind = 'false'
              and sws_hw_surr_id =id1;
        END LOOP;
        CLOSE sub_workstream_hardware_cost_cursor;
    end BLOCK1;

    BLOCK2: begin
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done2 = TRUE;
-- SELECT concat('second loop');
        OPEN sub_workstream_software_cost_cursor;

        loop2: LOOP
            FETCH sub_workstream_software_cost_cursor INTO id2;
            IF done2 THEN
                -- SELECT concat('end second loop');
                LEAVE loop2;
            END IF;
            -- SELECT concat('loop id2=', id2);
            update sub_workstream_software_cost set active_ind = 'false'
            where scenario ='Forecast' and active_ind = 'true' and original_ind = 'false'
              and sw_cost_surr_id =id2;
        END LOOP;
        CLOSE sub_workstream_software_cost_cursor;
    end BLOCK2;

    BLOCK3: begin
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done3 = TRUE;
-- SELECT concat('third loop');
        OPEN sub_workstream_other_cost_cursor;

        loop3: LOOP
            FETCH sub_workstream_other_cost_cursor INTO id3;
            IF done3 THEN
                -- SELECT concat('end 3 loop');
                LEAVE loop3;
            END IF;
            -- SELECT concat('loop id3=', id3);
            update sub_workstream_other_cost set active_ind = 'false'
            where scenario ='Forecast' and active_ind = 'true' and original_ind = 'false'
              and sws_other_surr_id = id3;
        END LOOP;
        CLOSE sub_workstream_other_cost_cursor;
    end BLOCK3;

    BLOCK4: begin
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done4 = TRUE;
-- SELECT concat('fourth loop');
        OPEN sub_workstream_resource_cost_cursor;

        loop4: LOOP
            FETCH sub_workstream_resource_cost_cursor INTO id4;
            IF done4 THEN
                -- SELECT concat('end 4 loop');
                LEAVE loop4;
            END IF;
            update sub_workstream_resource_cost set active_ind = 'false'
            where scenario ='Forecast' and active_ind = 'true' and original_ind = 'false'
              and sws_resource_surr_id =id4;
            -- SELECT concat('loop id4=', id4);
        END LOOP;
        CLOSE sub_workstream_resource_cost_cursor;
    end BLOCK4;
end//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_update_previous_month_forecast_to_inactive`()
begin

    DECLARE id1 varchar(100) DEFAULT "";
    DECLARE id2 varchar(100) DEFAULT "";
    DECLARE id3 varchar(100) DEFAULT "";
    DECLARE id4 varchar(100) DEFAULT "";
    DECLARE done1 INT DEFAULT FALSE;
    DECLARE done2 INT DEFAULT FALSE;
    DECLARE done3 INT DEFAULT FALSE;
    DECLARE done4 INT DEFAULT FALSE;

    DECLARE sub_workstream_hardware_cost_cursor
        CURSOR FOR
        select sws_hw_surr_id from sub_workstream_hardware_cost
        where scenario ='Forecast'
          and active_ind = 'true' and original_ind = 'false'
          and month(STR_TO_DATE(period, '%Y%m')) = MONTH(current_date())-1
          and year(STR_TO_DATE(period, '%Y')) = year(STR_TO_DATE(current_date(), '%Y'));

    DECLARE sub_workstream_software_cost_cursor
        CURSOR FOR
        select sw_cost_surr_id from sub_workstream_software_cost
        where scenario ='Forecast'
          and active_ind = 'true' and original_ind = 'false'
          and month(STR_TO_DATE(period, '%Y%m')) = MONTH(current_date())-1
          and year(STR_TO_DATE(period, '%Y')) = year(STR_TO_DATE(current_date(), '%Y'));

    DECLARE sub_workstream_other_cost_cursor
        CURSOR FOR
        select sws_other_surr_id from sub_workstream_other_cost
        where scenario ='Forecast'
          and active_ind = 'true' and original_ind = 'false'
          and month(STR_TO_DATE(period, '%Y%m')) = MONTH(current_date())-1
          and year(STR_TO_DATE(period, '%Y')) = year(STR_TO_DATE(current_date(), '%Y'));

    DECLARE sub_workstream_resource_cost_cursor
        CURSOR FOR
        select sws_resource_surr_id from sub_workstream_resource_cost
        where scenario ='Forecast'
          and active_ind = 'true' and original_ind = 'false'
          and month(STR_TO_DATE(period, '%Y%m')) = MONTH(current_date())-1
          and year(STR_TO_DATE(period, '%Y')) = year(STR_TO_DATE(current_date(), '%Y'));



-- SELECT concat('first loop');

    OPEN sub_workstream_hardware_cost_cursor;

    BLOCK1: begin
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done1 = TRUE;

        sub_workstream_hardware_cost_cursor_1: LOOP
            FETCH sub_workstream_hardware_cost_cursor INTO id1;
            IF done1 THEN
                -- SELECT concat('end first loop');
                LEAVE sub_workstream_hardware_cost_cursor_1;
            END IF;
            SELECT concat('loop id1=', id1);
            update sub_workstream_hardware_cost set active_ind = 'false'
            where scenario ='Forecast' and active_ind = 'true' and original_ind = 'false'
              and sws_hw_surr_id =id1;
        END LOOP;
        CLOSE sub_workstream_hardware_cost_cursor;
    end BLOCK1;

    BLOCK2: begin
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done2 = TRUE;
-- SELECT concat('second loop');
        OPEN sub_workstream_software_cost_cursor;

        loop2: LOOP
            FETCH sub_workstream_software_cost_cursor INTO id2;
            IF done2 THEN
                -- SELECT concat('end second loop');
                LEAVE loop2;
            END IF;
            -- SELECT concat('loop id2=', id2);
            update sub_workstream_software_cost set active_ind = 'false'
            where scenario ='Forecast' and active_ind = 'true' and original_ind = 'false'
              and sw_cost_surr_id =id2;
        END LOOP;
        CLOSE sub_workstream_software_cost_cursor;
    end BLOCK2;

    BLOCK3: begin
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done3 = TRUE;
-- SELECT concat('third loop');
        OPEN sub_workstream_other_cost_cursor;

        loop3: LOOP
            FETCH sub_workstream_other_cost_cursor INTO id3;
            IF done3 THEN
                -- SELECT concat('end 3 loop');
                LEAVE loop3;
            END IF;
            -- SELECT concat('loop id3=', id3);
            update sub_workstream_other_cost set active_ind = 'false'
            where scenario ='Forecast' and active_ind = 'true' and original_ind = 'false'
              and sws_other_surr_id = id3;
        END LOOP;
        CLOSE sub_workstream_other_cost_cursor;
    end BLOCK3;

    BLOCK4: begin
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done4 = TRUE;
-- SELECT concat('fourth loop');
        OPEN sub_workstream_resource_cost_cursor;

        loop4: LOOP
            FETCH sub_workstream_resource_cost_cursor INTO id4;
            IF done4 THEN
                -- SELECT concat('end 4 loop');
                LEAVE loop4;
            END IF;
            update sub_workstream_resource_cost set active_ind = 'false'
            where scenario ='Forecast' and active_ind = 'true' and original_ind = 'false'
              and sws_resource_surr_id =id4;
            -- SELECT concat('loop id4=', id4);
        END LOOP;
        CLOSE sub_workstream_resource_cost_cursor;
    end BLOCK4;
end//
DELIMITER ;

DELIMITER //
CREATE  OR REPLACE PROCEDURE `sp_update_previous_month_forecast_to_inactive_on_useraction`(
    IN `subworkstream_id` VARCHAR(1000),
    IN `subworkstream_name` VARCHAR(1000))
begin
    DECLARE id1 varchar(100) DEFAULT "";
    DECLARE id2 varchar(100) DEFAULT "";
    DECLARE id3 varchar(100) DEFAULT "";
    DECLARE id4 varchar(100) DEFAULT "";
    DECLARE done1 INT DEFAULT FALSE;
    DECLARE done2 INT DEFAULT FALSE;
    DECLARE done3 INT DEFAULT FALSE;
    DECLARE done4 INT DEFAULT FALSE;

    DECLARE sub_workstream_hardware_cost_cursor
        CURSOR FOR
        select sws_hw_surr_id from sub_workstream_hardware_cost
        where scenario ='Forecast'
          and active_ind = 'true' and original_ind = 'false'
          and month(STR_TO_DATE(period, '%Y%m')) = MONTH(current_date())-1
          and year(STR_TO_DATE(period, '%Y')) = year(STR_TO_DATE(current_date(), '%Y'))
          and sub_workstream_id=subworkstream_id
          and sub_workstream_name=subworkstream_name;

    DECLARE sub_workstream_software_cost_cursor
        CURSOR FOR
        select sw_cost_surr_id from sub_workstream_software_cost
        where scenario ='Forecast'
          and active_ind = 'true' and original_ind = 'false'
          and month(STR_TO_DATE(period, '%Y%m')) = MONTH(current_date())-1
          and year(STR_TO_DATE(period, '%Y')) = year(STR_TO_DATE(current_date(), '%Y'))
          and sub_workstream_id=subworkstream_id
          and sub_workstream_name=subworkstream_name;

    DECLARE sub_workstream_other_cost_cursor
        CURSOR FOR
        select sws_other_surr_id from sub_workstream_other_cost
        where scenario ='Forecast'
          and active_ind = 'true' and original_ind = 'false'
          and month(STR_TO_DATE(period, '%Y%m')) = MONTH(current_date())-1
          and year(STR_TO_DATE(period, '%Y')) = year(STR_TO_DATE(current_date(), '%Y'))
          and sub_workstream_id=subworkstream_id
          and sub_workstream_name=subworkstream_name;

    DECLARE sub_workstream_resource_cost_cursor
        CURSOR FOR
        select sws_resource_surr_id from sub_workstream_resource_cost
        where scenario ='Forecast'
          and active_ind = 'true' and original_ind = 'false'
          and month(STR_TO_DATE(period, '%Y%m')) = MONTH(current_date())-1
          and year(STR_TO_DATE(period, '%Y')) = year(STR_TO_DATE(current_date(), '%Y'))
          and sub_workstream_id=subworkstream_id
          and sub_workstream_name=subworkstream_name;



-- SELECT concat('first loop');

    OPEN sub_workstream_hardware_cost_cursor;

    BLOCK1: begin
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done1 = TRUE;

        sub_workstream_hardware_cost_cursor_1: LOOP
            FETCH sub_workstream_hardware_cost_cursor INTO id1;
            IF done1 THEN
                -- SELECT concat('end first loop');
                LEAVE sub_workstream_hardware_cost_cursor_1;
            END IF;
            -- SELECT concat('loop id1=', id1);
            update sub_workstream_hardware_cost set active_ind = 'false'
            where scenario ='Forecast' and active_ind = 'true' and original_ind = 'false'
              and sws_hw_surr_id =id1;
        END LOOP;
        CLOSE sub_workstream_hardware_cost_cursor;
    end BLOCK1;

    BLOCK2: begin
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done2 = TRUE;
-- SELECT concat('second loop');
        OPEN sub_workstream_software_cost_cursor;

        loop2: LOOP
            FETCH sub_workstream_software_cost_cursor INTO id2;
            IF done2 THEN
                -- SELECT concat('end second loop');
                LEAVE loop2;
            END IF;
            -- SELECT concat('loop id2=', id2);
            update sub_workstream_software_cost set active_ind = 'false'
            where scenario ='Forecast' and active_ind = 'true' and original_ind = 'false'
              and sw_cost_surr_id =id2;
        END LOOP;
        CLOSE sub_workstream_software_cost_cursor;
    end BLOCK2;

    BLOCK3: begin
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done3 = TRUE;
-- SELECT concat('third loop');
        OPEN sub_workstream_other_cost_cursor;

        loop3: LOOP
            FETCH sub_workstream_other_cost_cursor INTO id3;
            IF done3 THEN
                -- SELECT concat('end 3 loop');
                LEAVE loop3;
            END IF;
            -- SELECT concat('loop id3=', id3);
            update sub_workstream_other_cost set active_ind = 'false'
            where scenario ='Forecast' and active_ind = 'true' and original_ind = 'false'
              and sws_other_surr_id = id3;
        END LOOP;
        CLOSE sub_workstream_other_cost_cursor;
    end BLOCK3;

    BLOCK4: begin
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done4 = TRUE;
-- SELECT concat('fourth loop');
        OPEN sub_workstream_resource_cost_cursor;

        loop4: LOOP
            FETCH sub_workstream_resource_cost_cursor INTO id4;
            IF done4 THEN
                -- SELECT concat('end 4 loop');
                LEAVE loop4;
            END IF;
            update sub_workstream_resource_cost set active_ind = 'false'
            where scenario ='Forecast' and active_ind = 'true' and original_ind = 'false'
              and sws_resource_surr_id =id4;
            -- SELECT concat('loop id4=', id4);
        END LOOP;
        CLOSE sub_workstream_resource_cost_cursor;
    end BLOCK4;

END//
DELIMITER ;
