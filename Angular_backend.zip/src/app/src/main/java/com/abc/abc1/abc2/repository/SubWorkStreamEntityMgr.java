package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.resources.SubWorkStreamListingSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Slf4j
@Repository
public class SubWorkStreamEntityMgr {
    @PersistenceContext
    private EntityManager entityManager;

    public List<SubWorkStreamListingSource> getSubWorkStreamListingByOneBankId(String scenario, List<String> platform, List<String> reportingFlag, List<String> locations, String oneBankId) {
        Query query = entityManager.createNamedQuery("subWorkStreamListingByOneBankId");
        query.setParameter(1,scenario);
        query.setParameter(2,platform);
        query.setParameter(3,reportingFlag);
        query.setParameter(4,locations);
        query.setParameter(5,oneBankId);
        return query.getResultList();
    }

    public List<SubWorkStreamListingSource> getAllSubWorkStreams(String scenario, List<String> platform, List<String> reportingFlag, List<String> locations){
        Query query = entityManager.createNamedQuery("subWorkStreamListingAll");
        query.setParameter(1,scenario);
        query.setParameter(2,platform);
        query.setParameter(3,reportingFlag);
        query.setParameter(4,locations);
        return query.getResultList();
    }

}
