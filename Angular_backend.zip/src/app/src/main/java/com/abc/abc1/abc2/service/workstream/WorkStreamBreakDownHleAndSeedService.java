package com.dbs.genesis.portfolio.service.workstream;

import com.dbs.genesis.portfolio.common.CommonFinancialTypes;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.SubWorkstreamFinDetailsEntity;
import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.repository.SubWorkstreamFinDetailsRepo;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.service.financials.FinancialService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Slf4j
@Service
public class WorkStreamBreakDownHleAndSeedService implements CommonFinancialTypes {

    private final PortfolioRepository portfolioRepository;
    private final SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo;
    private final FinancialService financialService;

    public WorkStreamBreakDownHleAndSeedService(PortfolioRepository portfolioRepository, SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo, FinancialService financialService) {
        this.portfolioRepository = portfolioRepository;
        this.subWorkstreamFinDetailsRepo = subWorkstreamFinDetailsRepo;
        this.financialService = financialService;
    }

    public CostSettingsView getCostSettingForHLE(List<String> costTypes, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String period, String costSettingType,
                                                 String scenario, String costSettingValue, String currencyCode) {

        CostSettingsView costSettingsView = null;

        if(PortfolioConstants.MONTHLY.equalsIgnoreCase(costSettingType)) {
            costSettingsView = getCostSettingsByMonthly(costTypes, subWorkStreamIdAndNames,
                    period, costSettingValue,PortfolioConstants.COST_SETTING_TYPE_HLE,scenario,currencyCode);
        } if(PortfolioConstants.QUARTERLY.equalsIgnoreCase(costSettingType)) {
            costSettingsView = getCostSettingsByQuarterly( subWorkStreamIdAndNames, scenario,
                    costSettingValue,costTypes,currencyCode);
        }
        if (PortfolioConstants.YEARLY.equalsIgnoreCase(costSettingType)) {
            costSettingsView = getCostSettingsByYearly(costTypes, subWorkStreamIdAndNames,
                    scenario, costSettingValue,currencyCode);
        }

        return costSettingsView;
    }

    private CostSettingsView getCostSettingsByMonthly(List<String> costTypes,List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String period, String costSetting, String costSettingType,String scenario, String currencyCode) {

        CostSettingsView costSettingsView = new CostSettingsView();
        List<CostTypeCategoryView> costTypeCategoryViewList = new ArrayList<>();
        costSettingsView.setName(costSetting);
        List<FinancialSummaryResource> finSummaryByCostSetting =
                subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                        PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                                portfolioRepository.getFinSummaryForCostSettingsByGroupCurrency(subWorkStreamIdAndName.getWorkStreamId(),
                        subWorkStreamIdAndName.getSubWorkStreamId(),subWorkStreamIdAndName.getSubWorkStreamName(),period,costSetting,scenario,
                        PortfolioConstants.ORIGINAL_INDICATOR_FALSE) :
                                portfolioRepository.getFinSummaryForCostSettingsByLocalCurrency(subWorkStreamIdAndName.getWorkStreamId(),
                                        subWorkStreamIdAndName.getSubWorkStreamId(),subWorkStreamIdAndName.getSubWorkStreamName(),period,costSetting,scenario,
                                        PortfolioConstants.ORIGINAL_INDICATOR_FALSE)).flatMap(List::stream).collect(Collectors.toList());

        List<BigDecimal> monthlyDataList = getMonthlyCostSettingList(finSummaryByCostSetting);
        costSettingsView.setMonthlyCostSettings(monthlyDataList);
        costSettingsView.setCostSettingsTotal(monthlyDataList.stream().reduce(BigDecimal::add)
                .orElse(BigDecimal.ZERO));
        final BigDecimal costSettingsOverAllSum =BigDecimal.ZERO;

        List<CompletableFuture> cfstFutures = new ArrayList<>(subWorkStreamIdAndNames.size());

        subWorkStreamIdAndNames.forEach(swsIdNm -> {
            CompletableFuture<BigDecimal> cf = null;
            if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)){
                cf = CompletableFuture.supplyAsync(() -> subWorkstreamFinDetailsRepo.getCostSettingsOverAllSumByGrpCcy(swsIdNm.getWorkStreamId(), swsIdNm.getSubWorkStreamId(), swsIdNm.getSubWorkStreamName(), scenario, costSettingType));
            } else {
                cf = CompletableFuture.supplyAsync(() -> subWorkstreamFinDetailsRepo.getCostSettingsOverAllSumByLocalCcy(swsIdNm.getWorkStreamId(), swsIdNm.getSubWorkStreamId(), swsIdNm.getSubWorkStreamName(), scenario, costSettingType));
            }
            cfstFutures.add(cf);
        });

        CompletableFuture.allOf(cfstFutures.stream().toArray(CompletableFuture[]::new))
                .whenComplete((v,t) -> {
                    cfstFutures.forEach(cf -> costSettingsOverAllSum.add((BigDecimal) cf.getNow(BigDecimal.ZERO)));
                }).join();

        /*for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
            costSettingsOverAllSum = costSettingsOverAllSum.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    subWorkstreamFinDetailsRepo.getCostSettingsOverAllSumByGrpCcy(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, costSettingType)
                    : subWorkstreamFinDetailsRepo.getCostSettingsOverAllSumByLocalCcy(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, costSettingType));
        }*/
        costSettingsView.setCostSettingsOverAllTotal(costSettingsOverAllSum);


        /*costTypes.forEach(costType -> costTypeCategoryViewList.add(getMonthlyDataBasedOnCategoryAndCostType(
                costSetting, costType, subWorkStreamIdAndNames,period,scenario,currencyCode)));
        costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);*/

        List<CompletableFuture> allFutures = new ArrayList<>(costTypes.size());

        costTypes.forEach(costType -> {
            CompletableFuture<CostTypeCategoryView> cf = CompletableFuture.supplyAsync(() -> getMonthlyDataBasedOnCategoryAndCostType(costSetting, costType, subWorkStreamIdAndNames,period,scenario,currencyCode));
            allFutures.add(cf);
        });

        CompletableFuture.allOf(allFutures.stream().toArray(CompletableFuture[]::new))
                .whenComplete((v, th) -> {
                    allFutures.forEach(cf -> costTypeCategoryViewList.add((CostTypeCategoryView)cf.getNow(new CostTypeCategoryView())));
                }).join();

        costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);

        return costSettingsView;
    }

    public CostSettingsView getCostSettingForSeedFunding(List<String> costTypes, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String period, String costSettingType, String scenario,
                                                          String costSettingValue, String currencyCode) {

        CostSettingsView costSettingsView = null;
        if(PortfolioConstants.MONTHLY.equalsIgnoreCase(costSettingType)) {
            costSettingsView = getCostSettingsByMonthly(costTypes, subWorkStreamIdAndNames,
                    period, costSettingValue, PortfolioConstants.COST_SETTING_TYPE_SEED_FUNDING,scenario,currencyCode);
        }
        if(PortfolioConstants.QUARTERLY.equalsIgnoreCase(costSettingType)) {
            costSettingsView = getCostSettingsByQuarterly( subWorkStreamIdAndNames, scenario,
                    costSettingValue,costTypes,currencyCode);
        }
        if (PortfolioConstants.YEARLY.equalsIgnoreCase(costSettingType)) {
            costSettingsView = getCostSettingsByYearly(costTypes, subWorkStreamIdAndNames,
                    scenario, costSettingValue,currencyCode);
        }
        return costSettingsView;
    }

    private CostSettingsView getCostSettingsByYearly(List<String> costTypes, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario,
                                                     String costSettingValue, String currencyCode) {
        CostSettingsView costSettingsView = new CostSettingsView();
        costSettingsView.setName(costSettingValue);
        List<CostTypeCategoryView> costTypeCategoryViewList = new ArrayList<>();
        Map<String, BigDecimal> yearlyFinSummary = new HashMap<>();
        BigDecimal completeTotalYearsAmount = BigDecimal.ZERO;
        List<BigDecimal> yearlySum = new ArrayList<>();

        List<String> financialYearsByCostSetting = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamFinDetailsRepo.getListOfFinancialYearsByCostSetting(
                        subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),subWorkStreamIdAndName.getSubWorkStreamName(),scenario, costSettingValue))
                .flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
        for (String year : financialYearsByCostSetting) {
            List<FinancialSummaryResource> yearlySumForSeedFunding =
                    subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                            PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                            portfolioRepository.getYearlySumForCostTypeByGroupCurrency(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),
                                    subWorkStreamIdAndName.getSubWorkStreamName(), year,
                                    costSettingValue,scenario,PortfolioConstants.ORIGINAL_INDICATOR_FALSE)
                            : portfolioRepository.getYearlySumForCostTypeByLocalCurrency(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),
                                    subWorkStreamIdAndName.getSubWorkStreamName(), year,
                                    costSettingValue,scenario,PortfolioConstants.ORIGINAL_INDICATOR_FALSE)).flatMap(List::stream).collect(Collectors.toList());
            yearlySumForSeedFunding.forEach(financialSummaryResource -> {
                if(financialSummaryResource.getCurrencyValue() != null &&
                        financialSummaryResource.getCurrencyValue().intValue() !=0) {
                    yearlyFinSummary.put(year,financialSummaryResource.getCurrencyValue());
                }
                yearlySum.add(financialSummaryResource.getCurrencyValue());
            });
        }
        if(!yearlySum.isEmpty()) {
            completeTotalYearsAmount = completeTotalYearsAmount.add(yearlySum.stream().reduce(BigDecimal::add)
                    .orElse(BigDecimal.ZERO));
        }
        costSettingsView.setYearlyCostSettings(yearlyFinSummary);
        costSettingsView.setCostSettingsOverAllTotal(completeTotalYearsAmount);
        costTypes.forEach(costType -> costTypeCategoryViewList.add(
                getYearlyDataBasedOnCategoryByCostType(costSettingValue,
                        costType, subWorkStreamIdAndNames,scenario,currencyCode)));
        costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);
        return costSettingsView;
    }

    private CostTypeCategoryView getYearlyDataBasedOnCategoryByCostType(String costSettingValue, String costType,
                                                                          List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario,String currencyCode) {
        Map<String,BigDecimal> yearlyFinanceSummary = new HashMap<>();
        List<BigDecimal> overAllTotal = new ArrayList<>();
        BigDecimal overAllYearsTotal = BigDecimal.ZERO;
        List<String> financialYearsByCostSetting = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> subWorkstreamFinDetailsRepo.
                getListOfFinancialYearsByCostSetting(
                        subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),subWorkStreamIdAndName.getSubWorkStreamName(),scenario, costSettingValue)
        ).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());

        for (String costSettingYear : financialYearsByCostSetting) {
            BigDecimal calculateTotalAmount = BigDecimal.ZERO;
            List<SubWorkstreamFinDetailsEntity> finDetailsEntityList =
                    subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> subWorkstreamFinDetailsRepo.
                            findByCostSettingAndWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndCostTypeAndOrgIndAndPeriodContainingAndScenario(
                                    costSettingValue, subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),subWorkStreamIdAndName.getSubWorkStreamName(),
                                    costType,PortfolioConstants.FALSE, costSettingYear,scenario)).flatMap(List::stream).collect(Collectors.toList());

            List<BigDecimal> bigDecimalList = new ArrayList<>();
            for (SubWorkstreamFinDetailsEntity subWorkStreamFinDetailsEntity : finDetailsEntityList) {
                if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) && subWorkStreamFinDetailsEntity.getGroupCcyVal() != null &&
                        subWorkStreamFinDetailsEntity.getGroupCcyVal().intValue() !=0) {
                    BigDecimal groupCcyVal = subWorkStreamFinDetailsEntity.getGroupCcyVal();
                    bigDecimalList.add(groupCcyVal);

                }else{
                    if(subWorkStreamFinDetailsEntity.getLocalCcyVal() != null &&
                            subWorkStreamFinDetailsEntity.getLocalCcyVal().intValue() !=0){
                        BigDecimal localCcyVal = subWorkStreamFinDetailsEntity.getLocalCcyVal();
                        bigDecimalList.add(localCcyVal);
                    }
                }
            }
            if (!bigDecimalList.isEmpty()) {
                calculateTotalAmount = calculateTotalAmount.add(bigDecimalList.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
            }
            yearlyFinanceSummary.put(costSettingYear,calculateTotalAmount);
            overAllTotal.add(calculateTotalAmount);
        }
        if (!overAllTotal.isEmpty()) {
            overAllYearsTotal = overAllYearsTotal.add(overAllTotal.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        }

        return getCostTypeCategoryResource(costType,
                Arrays.asList(BigDecimal.ZERO), new TreeMap() ,yearlyFinanceSummary,overAllYearsTotal,BigDecimal.ZERO,
                new HashMap<>());
    }

    private CostSettingsView getCostSettingsByQuarterly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario, String costSettingName,
                                                        List<String> costTypes, String currencyCode) {
        CostSettingsView costSettingsView = new CostSettingsView();
        costSettingsView.setName(costSettingName);
        List<CostTypeCategoryView> costTypeCategoryViewList = new ArrayList<>();
        Map<String, List<BigDecimal>> quarterlyCostSettings = new HashMap<>();
        Map<String,BigDecimal> costSettingsQuarterlyDataPerYear = new HashMap<>();
        List<List<BigDecimal>> consolidatedQuarterlyOverAllSum = new ArrayList<>();
        BigDecimal totalOverAllQuarterlySum = BigDecimal.ZERO;
        List<BigDecimal> quarterlySummaryList = new ArrayList<>();
        List<String> financialYearsByCostSetting = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamFinDetailsRepo.getListOfFinancialYearsByCostSetting(
                        subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),subWorkStreamIdAndName.getSubWorkStreamName(),scenario, costSettingName)
        ).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());

        for (String year : financialYearsByCostSetting) {
            List<FinancialSummaryResource> finSummaryByCostSetting =
                    subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                            portfolioRepository.getFinSummaryForCostSettingsByGroupCurrency(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),
                                    subWorkStreamIdAndName.getSubWorkStreamName(), year,costSettingName,
                            scenario,PortfolioConstants.ORIGINAL_INDICATOR_FALSE)
                            : portfolioRepository.getFinSummaryForCostSettingsByLocalCurrency(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),
                            subWorkStreamIdAndName.getSubWorkStreamName(), year,costSettingName,
                            scenario,PortfolioConstants.ORIGINAL_INDICATOR_FALSE)).flatMap(List::stream).collect(Collectors.toList());

            quarterlySummaryList = financialService.getQuarterlySummaryListData(finSummaryByCostSetting);
            quarterlyCostSettings.put(year, quarterlySummaryList);
            consolidatedQuarterlyOverAllSum.add(quarterlySummaryList);
        }
        quarterlyCostSettings.forEach((year, bigDecimals) -> {
            costSettingsQuarterlyDataPerYear.put(year,bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        });
        if (!quarterlySummaryList.isEmpty()) {
            for (List<BigDecimal> list: consolidatedQuarterlyOverAllSum){
                totalOverAllQuarterlySum = totalOverAllQuarterlySum.add(list.stream().reduce(BigDecimal::add)
                        .orElse(BigDecimal.ZERO));
            }
            costSettingsView.setCostSettingsOverAllTotal(totalOverAllQuarterlySum);
        }
        costSettingsView.setQuarterlyCostSettings(quarterlyCostSettings);
        costSettingsView.setIndividualYearSummaryForQuarterly(costSettingsQuarterlyDataPerYear);
        costTypes.forEach(costType -> {
            costTypeCategoryViewList.add(getQuarterlySummaryForCostSettingByCostType(costSettingName,
                    costType, subWorkStreamIdAndNames,scenario,currencyCode));
        });
        costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);
        return costSettingsView;
    }

    private CostTypeCategoryView getQuarterlySummaryForCostSettingByCostType(String costSetting, String costType,
                                                                             List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                                                             String scenario, String currencyCode) {
        Map<String, List<BigDecimal>> quarterlyMap = new HashMap<>();
        List<List<BigDecimal>> completeQuarterlySum = new ArrayList<>();
        BigDecimal totalQuarterlySum = BigDecimal.ZERO;
        Map<String,BigDecimal> individualYearSummaryForQuarterlyData = new HashMap<>();
        List<BigDecimal> quarterlyData;
        List<String> financialYearsByScenario = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamFinDetailsRepo.getListOfFinancialYearsByCostSetting(
                        subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),subWorkStreamIdAndName.getSubWorkStreamName(),scenario,costSetting)
        ).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
        for (String period : financialYearsByScenario) {
            List<SubWorkstreamFinDetailsEntity> finDetailsEntityList =
                    subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> subWorkstreamFinDetailsRepo.
                            findByCostSettingAndWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndCostTypeAndOrgIndAndPeriodContainingAndScenario(
                                    costSetting, subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),subWorkStreamIdAndName.getSubWorkStreamName(),
                                    costType,PortfolioConstants.FALSE, period,scenario)).flatMap(List::stream).collect(Collectors.toList());

            quarterlyData = financialService.getQuarterlyData(period, finDetailsEntityList,currencyCode);
            quarterlyMap.put(period,quarterlyData);
            completeQuarterlySum.add(quarterlyData);
        }
        for (List<BigDecimal> list: completeQuarterlySum){
            totalQuarterlySum = totalQuarterlySum.add(list.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        }
        quarterlyMap.forEach((year, bigDecimals) -> {
            individualYearSummaryForQuarterlyData.put(year,bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        });
        CostTypeCategoryView costTypeCategoryView = getCostTypeCategoryResource(costType,
                Arrays.asList(BigDecimal.ZERO), quarterlyMap,new TreeMap(),totalQuarterlySum,
                BigDecimal.ZERO, individualYearSummaryForQuarterlyData);

        return costTypeCategoryView;
    }



    private List<BigDecimal> getMonthlyCostSettingList(List<FinancialSummaryResource> finSummaryForCostInput) {
        return getCostSettingMonthlyData(finSummaryForCostInput);
    }



    private List<BigDecimal> getMonthlyCostTypeList(List<SubWorkstreamFinDetailsEntity>
                                                            subWorkStreamFinDetailsEntityList, String currencyCode) {
        return financialService.getMonthlyData(subWorkStreamFinDetailsEntityList, currencyCode);
    }

    private CostTypeCategoryView getMonthlyDataBasedOnCategoryAndCostType(String costSettings, String costType,
             List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String period, String scenario, String currencyCode) {

        List<SubWorkstreamFinDetailsEntity> finDetailsEntityList =
                subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> subWorkstreamFinDetailsRepo.
                        findByCostSettingAndWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndCostTypeAndOrgIndAndPeriodContainingAndScenario(
                                costSettings, subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),subWorkStreamIdAndName.getSubWorkStreamName(),
                                costType,PortfolioConstants.FALSE, period,scenario)).flatMap(List::stream).collect(Collectors.toList());

        List<BigDecimal> monthlyDataList = getMonthlyCostTypeList(finDetailsEntityList,currencyCode);
        List<MonthlyResource> monthlyDataByObject = financialService.getMonthlyDataByObject(finDetailsEntityList,currencyCode);
        BigDecimal costTypeOverAllSum=BigDecimal.ZERO;
      /*  subWorkStreamIdAndNames.stream().forEach(subWorkStreamIdAndName -> {
            costTypeOverAllSum.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamFinDetailsRepo.getCostTypeOverAllSumByGrpCcy(workStreamId, subWorkStreamIdAndName.getSubWorkStreamId(),subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.DEFAULT_SEED_FUNDING_CATEGORY, costType, costSettings)
                    : subWorkstreamFinDetailsRepo.getCostTypeOverAllSumByLocalCcy(workStreamId, subWorkStreamIdAndName.getSubWorkStreamId(),subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.DEFAULT_SEED_FUNDING_CATEGORY, costType, costSettings));
        });
*/
        if(costSettings.equalsIgnoreCase(PortfolioConstants.COST_SETTING_TYPE_HLE)) {
            List<SubWorkstreamFinDetailsEntity> subWorkstreamFinDetailsEntityList =
                    subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                            subWorkstreamFinDetailsRepo.findByWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndScenarioAndCostTypeAndCostSettingAndOrgInd(
                                    subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),
                                    scenario, costType, PortfolioConstants.COST_SETTING_TYPE_HLE, PortfolioConstants.TRUE)).flatMap(List::stream).collect(Collectors.toList());
            for (SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity : subWorkstreamFinDetailsEntityList) {
                costTypeOverAllSum = costTypeOverAllSum.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        subWorkstreamFinDetailsEntity.getGroupCcyVal(): subWorkstreamFinDetailsEntity.getLocalCcyVal());
            }
        }else if(costSettings.equalsIgnoreCase(PortfolioConstants.COST_SETTING_TYPE_SEED_FUNDING)){
            BigDecimal invidualSum= BigDecimal.ZERO;
             if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)) {
                 for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                     invidualSum = invidualSum.add(subWorkstreamFinDetailsRepo.getCostTypeOverAllSumByGrpCcy(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),
                             subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.DEFAULT_SEED_FUNDING_CATEGORY, costType, costSettings));
                 }
             }
            else {
                 for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                     invidualSum = invidualSum.add(subWorkstreamFinDetailsRepo.getCostTypeOverAllSumByLocalCcy(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),
                             subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.DEFAULT_SEED_FUNDING_CATEGORY, costType, costSettings));
                 }
             }
            costTypeOverAllSum = invidualSum;
        }

        BigDecimal costTypeTotal = monthlyDataList.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        CostTypeCategoryView costTypeCategoryView = new CostTypeCategoryView();
        costTypeCategoryView.setName(costType);
        costTypeCategoryView.setMonthlyCostTypes(monthlyDataList);
        costTypeCategoryView.setCostTypeTotal(costTypeTotal);
        costTypeCategoryView.setCostTypeOverAllTotal(costTypeOverAllSum);
        costTypeCategoryView.setMonthlyResources(monthlyDataByObject);
        return costTypeCategoryView;
    }


    private CostTypeCategoryView getCostTypeCategoryResource(String costType, List<BigDecimal> monthly,
                                                             Map<String,List<BigDecimal>> quarterly,
                                                             Map<String,BigDecimal> yearly,
                                                             BigDecimal costTypeTotal, BigDecimal costTypeOverAllSum,
                                                             Map<String,BigDecimal> individualYearSummaryForQuarterly) {
        CostTypeCategoryView costTypeCategoryView = new CostTypeCategoryView();
        costTypeCategoryView.setName(costType);
        costTypeCategoryView.setMonthlyCostTypes(monthly);
        costTypeCategoryView.setQuarterlyCostType(quarterly);
        costTypeCategoryView.setYearlyCostType(yearly);
        costTypeCategoryView.setCostTypeTotal(costTypeTotal);
        costTypeCategoryView.setCostTypeOverAllTotal(costTypeTotal);
        costTypeCategoryView.setIndividualYearSummaryForQuarterly(individualYearSummaryForQuarterly);
        return costTypeCategoryView;
    }

}
