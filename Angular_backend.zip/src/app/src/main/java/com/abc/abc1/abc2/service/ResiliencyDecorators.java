package com.dbs.genesis.portfolio.service;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.decorators.Decorators;
import io.github.resilience4j.retry.Retry;
import io.vavr.control.Try;

import java.util.function.Supplier;

public interface ResiliencyDecorators {

    static <T> DecorateSupplier<T> ofSupplier(Supplier<T> supplier, Supplier<T> failedSupplier) {
        return new ResiliencyDecorators.DecorateSupplier<>(supplier, failedSupplier);
    }

    class DecorateSupplier<T> {

        private String resiliencyName = "backend";
        CircuitBreaker circuitBreaker = CircuitBreaker.ofDefaults(resiliencyName);
        Retry retry = Retry.ofDefaults(resiliencyName);
        private Supplier<T> commandSupplier;
        private Supplier<T> failedSupplier;

        private DecorateSupplier(Supplier<T> commandSupplier, Supplier<T> failedSupplier) {
            this.commandSupplier = commandSupplier;
            this.failedSupplier = failedSupplier;
        }

        public T get() {
            Supplier<T> decoratedSupplier = Decorators.ofSupplier(commandSupplier)
                    .withRetry(retry)
                    .withCircuitBreaker(circuitBreaker)
                    .decorate();
            return Try.ofSupplier(decoratedSupplier)
                    .recover(throwable -> failedSupplier.get()).get();
        }
    }
}
