package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.WorkstreamOthersEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WorkstreamOthersRepo extends JpaRepository<WorkstreamOthersEntity, Integer> {

    List<WorkstreamOthersEntity> findByWorkStreamIdIgnoreCaseAndActiveIndIgnoreCase(String workstreamId, String activeInd);
}
