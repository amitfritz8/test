package com.dbs.genesis.portfolio;


import lombok.Data;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
@Data
public class Delete {
    public static void main(String[] args) {



        Period diff = Period.between(LocalDate.parse("2016-01-31").withDayOfMonth(1),
                LocalDate.parse("2016-12-30").withDayOfMonth(1));

        System.out.println(">>>>>>"+diff.getMonths());

        LocalDate currentdate = LocalDate.now();
        System.out.println(currentdate.getMonth().getValue()-1);

        String s = "202001";
        System.out.println("************  "+s.substring(0,4));

        long monthsBetween = ChronoUnit.MONTHS.between(
                LocalDate.parse("2016-08-31").withDayOfMonth(1),
                LocalDate.parse("2018-08-30").withDayOfMonth(1));
        System.out.println(monthsBetween); //3


        String date1 = "JAN-2015";
        String date2 = "APR-2015";

        DateFormat formater = new SimpleDateFormat("MMM-yyyy");
        List<String> list = new ArrayList<>();
        Calendar beginCalendar = Calendar.getInstance();
        Calendar finishCalendar = Calendar.getInstance();

        try {
            beginCalendar.setTime(formater.parse(date1));
            finishCalendar.setTime(formater.parse(date2));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        while (beginCalendar.before(finishCalendar)) {
            String date =     formater.format(beginCalendar.getTime()).toUpperCase();
            System.out.println(date);
            beginCalendar.add(Calendar.MONTH, 1);
            list.add(date);
        }

        System.out.println("&&&&&&&&&&&&"+getCurrentYearMonthBetweenDates("2020-03","2020-03"));

        System.out.println("2020-03-25T00:00:00.000Z".substring(0,7));
        System.out.println("P11SG-20001-I0001".substring(3));
        System.out.println("P18bREG-20001-I0001".substring(3));

    }

    String getMonthNumber;

    public static List<String> getCurrentYearMonthBetweenDates(String startDate, String endDate) {

        List<String> list = new ArrayList<>();
        DateFormat formater = new SimpleDateFormat("yyyy-MM");
        Calendar beginCalendar = Calendar.getInstance();
        Calendar finishCalendar = Calendar.getInstance();
        try {
            beginCalendar.setTime(formater.parse(startDate));
            finishCalendar.setTime(formater.parse(endDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        DateFormat formaterYd = new SimpleDateFormat("yyyy-MM");
        while (beginCalendar.before(finishCalendar)) {
            String date = formaterYd.format(beginCalendar.getTime());
            beginCalendar.add(Calendar.MONTH, 1);
            list.add(date.replaceAll("-",""));
        }
        list.add(endDate.replaceAll("-",""));
        Collections.sort(list);
        return list;
    }


}
