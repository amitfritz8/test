package com.dbs.genesis.portfolio.repository;


import com.dbs.genesis.portfolio.model.WorkHierarchyEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkHierarchyRepo extends JpaRepository<WorkHierarchyEntity, String> {
    List<WorkHierarchyEntity> getByPortfolioId(String portfolioId);
    List<WorkHierarchyEntity> findByPortfolioIdAndWorkStreamId(String portfolioId,String workStreamId);
    WorkHierarchyEntity findByPortfolioId(String portfolioId);
    List<WorkHierarchyEntity> findByWorkStreamId(String workStreamId);
    WorkHierarchyEntity findBySubWorkStreamId(String subWorkStreamId);
    WorkHierarchyEntity findBySubWorkStreamIdAndSubWorkStreamName(String subWorkStreamId,String subWorkStreamName);

    @Query("select whe from WorkHierarchyEntity whe where whe.portfolioId = :portfolioId")
    List<WorkHierarchyEntity> getWorkHierarchyEntityByPortfolioId(@Param("portfolioId") String portfolioId);

}
