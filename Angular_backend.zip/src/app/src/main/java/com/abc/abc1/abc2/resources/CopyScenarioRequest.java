package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class CopyScenarioRequest {
    private String portFolioId;
    private String platformId;
    private String workStreamId;
    private String scenarioFrom;
    private String scenarioTo;
    private String approvalDate;

}
