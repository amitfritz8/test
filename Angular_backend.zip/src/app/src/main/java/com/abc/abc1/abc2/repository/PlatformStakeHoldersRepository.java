package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.PlatformStakeHolders;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;




@Repository
public interface PlatformStakeHoldersRepository extends JpaRepository<PlatformStakeHolders, Integer> {


    @Query(value = "select a.* from xref_platform_stakeholders a where platform_index =:platformIndex and platform_role =:role group by 1bank_id;",nativeQuery = true)
    List<PlatformStakeHolders> getStaffNamesByPlatformIndexAndRole(String platformIndex, String role);
}
