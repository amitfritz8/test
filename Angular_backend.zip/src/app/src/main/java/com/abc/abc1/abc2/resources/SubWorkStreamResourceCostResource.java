package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.apache.logging.log4j.util.Strings;

import java.math.BigDecimal;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class SubWorkStreamResourceCostResource {

    private String role;
    private String location;
    private String currency;
    private String staffType;
    private String vendor;
    private String rateSource;
    private String level;
    private BigDecimal fdManDaysPerMonth;
    private BigDecimal fte;
    private BigDecimal staffRate;
    private BigDecimal costPerDay;
    private String activeInd;
    private Integer surrId;
    private BigDecimal costPerMonth;

    public boolean validate() {

        return Strings.isNotEmpty(role) && Strings.isNotEmpty(location) && Strings.isNotEmpty(currency) && Strings.isNotEmpty(staffType)
                && Strings.isNotEmpty(vendor) && Strings.isNotEmpty(rateSource) && Strings.isNotEmpty(level);
    }
}
