package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class UnitCostResource {
    int surrId;
    String monthNumber;
    BigDecimal value;
    String glCategory;

    @JsonIgnore
    Integer numericMonthNumber;
    public Integer getNumericMonthNumber() {
        return Integer.parseInt(monthNumber);
    }

}
