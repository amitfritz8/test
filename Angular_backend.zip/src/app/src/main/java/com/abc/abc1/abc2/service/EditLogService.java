package com.dbs.genesis.portfolio.service;

import com.dbs.genesis.portfolio.model.EditLog;
import com.dbs.genesis.portfolio.repository.EditLogRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import java.sql.Timestamp;
import java.time.Instant;

@Slf4j
@Service
@Transactional
public class EditLogService {

    private EditLogRepo editLogRepo;

    public EditLogService(EditLogRepo editLogRepo){
        this.editLogRepo = editLogRepo;
    }

    public boolean extendEditLog(EditLog editLog){

        EditLog currentLock = editLogRepo.findByPortfolioIdAndPortfolioNameAndPortfolioType(editLog.getPortfolioId(),editLog.getPortfolioName(),editLog.getPortfolioType());
        // Checking whether the user is the owner of current lock
        if(!ObjectUtils.isEmpty(currentLock) && currentLock.getStaffDisplayName().equalsIgnoreCase(editLog.getStaffDisplayName())){
            currentLock.setDateModified(Timestamp.from(Instant.now()));
            editLogRepo.save(currentLock);
            log.info("Edit Log extended for User:"+editLog.getStaffDisplayName());
        } else {
            log.info("The user:"+editLog.getStaffDisplayName()+" is not holding the lock");
            return false;
        }

        return true;
    }
}
