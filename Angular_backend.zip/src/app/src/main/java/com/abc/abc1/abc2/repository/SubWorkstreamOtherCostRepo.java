package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.SubWorkstreamOtherCost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Repository
public interface SubWorkstreamOtherCostRepo extends JpaRepository<SubWorkstreamOtherCost, Integer> {


    List<SubWorkstreamOtherCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContainingAndGlCategoryNotIn(
            String subWorkStreamId, String subWorkStreamName, String scenario, String aTrue, String
                                                                            financialCostTypesHardware, String originalInd,String period, List glCategories);
    List<SubWorkstreamOtherCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndGlCategoryNotInAndPeriodContaining(
            String subWorkStreamId, String subWorkStreamName, String scenario, String aTrue, String
            financialCostTypesHardware, String originalInd, List<String> glCategories, String period);

    @Query(value = "select coalesce (sum(group_ccy_val),0) from sub_workstream_other_cost where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name =:subWorkStreamName and scenario = :scenario and type = :type and active_ind = 'true' and original_ind='false' and gl_Category not in :glCategories " ,
            nativeQuery = true)
    BigDecimal getTotalOthersCostByTypeAndGrpCcy(@Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName, @Param("scenario") String scenario,
                                                 @Param("type") String type, @Param("glCategories") List<String> glCategories);

    @Query(value = "select coalesce (sum(local_ccy_val),0) from sub_workstream_other_cost where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name =:subWorkStreamName and scenario = :scenario and type = :type and active_ind = 'true' and original_ind='false' and gl_Category not in :glCategories" ,
            nativeQuery = true)
    BigDecimal getTotalOthersCostByTypeAndLocalCcy(@Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName, @Param("scenario") String scenario,
                                                   @Param("type") String type, @Param("glCategories") List<String> glCategories);

    List<SubWorkstreamOtherCost> findAllByRefSwsOtherSurrIdIn(List<Integer> refSwsOtherSurrId);
    @Query(value = "FROM SubWorkstreamOtherCost e where " +
            "e.swsOtherSurrId IN (:swsOtherSurrId) or e.capexOpexSurrId IN (:capexOpexSurrId)")
    List<SubWorkstreamOtherCost> findAllByParentOrChildIdIn(Set<Integer> swsOtherSurrId, Set<Integer> capexOpexSurrId);

    List<SubWorkstreamOtherCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalInd(
            String subWorkStreamId, String subWorkStreamName, String scenario, String activeInd, String type, String originalInd);

    List<SubWorkstreamOtherCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndType(
            String subWorkStreamId, String subWorkStreamName, String scenario, String aTrue, String originalInd,String otherOthersType);

    @Query(value = " select distinct substr(period,1,4) from sub_workstream_other_cost s where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name= :subWorkStreamName  and scenario= :scenario and type = :type and original_ind='false' and period is not null " +
            " union SELECT DISTINCT substr(e.period,1,4) as period FROM vw_sws_other_cost e where e.sub_workstream_id = :subWorkStreamId and e.sub_workstream_name = :subWorkStreamName and " +
            " e.scenario = :scenario and e.cost_type = :type  and period is not null",nativeQuery = true)
    List<String> findDistinctOfYears(@Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName,@Param("scenario") String scenario,
                                     @Param("type") String type);

    @Query(value = "select coalesce(sum(group_ccy_val),0) from sub_workstream_other_cost where  sub_workstream_id= :subWorkStreamId " +
            "and sub_workstream_name= :subWorkStreamName and scenario= :scenario  and active_ind = 'true' and original_ind = 'false' and type = :otherOthersType and gl_category not in :glCategories" ,nativeQuery = true)
    BigDecimal getSoftwareOthersTotalByGrpCcy
            (@Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName, @Param("scenario") String scenario,@Param("otherOthersType") String otherOthersType, @Param("glCategories")  List<String> glCategories);

    @Query(value = "select coalesce(sum(local_ccy_val),0) from sub_workstream_other_cost where  sub_workstream_id= :subWorkStreamId " +
            "and sub_workstream_name= :subWorkStreamName and scenario= :scenario  and active_ind = 'true' and original_ind = 'false' and type = :otherOthersType and gl_category not in :glCategories " ,nativeQuery = true)
    BigDecimal getSoftwareOthersTotalByLocalCcy(@Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName, @Param("scenario") String scenario,@Param("otherOthersType") String otherOthersType
            , @Param("glCategories")  List<String> glCategories);

    @Query(value = "select coalesce(sum(group_ccy_val),0) from sub_workstream_other_cost where  sub_workstream_id= :subWorkStreamId " +
            "and sub_workstream_name= :subWorkStreamName and scenario= :scenario  and active_ind = 'true' and original_ind = 'false' and substring(period,1,4)= :year and type = :type and gl_category not in :glCategories" ,nativeQuery = true)
    BigDecimal getOthersTotalByYearAndGrpCcy(@Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName, @Param("scenario") String scenario, @Param("year") String year, @Param("type") String type, @Param("glCategories")  List<String> glCategories);

    @Query(value = "select coalesce(sum(local_ccy_val),0) from sub_workstream_other_cost where  sub_workstream_id= :subWorkStreamId " +
            "and sub_workstream_name= :subWorkStreamName and scenario= :scenario  and active_ind = 'true' and original_ind = 'false' and substring(period,1,4)= :year and type = :type and gl_category not in :glCategories " ,nativeQuery = true)
    BigDecimal getOthersTotalByYearAndLocalCcy(String subWorkStreamId, String subWorkStreamName, String scenario, String year, String type, List<String> glCategories);

    @Query(value = "select period from (select distinct substr(period,1,4) as period from sub_workstream_software_cost where sub_workstream_id= :subWorkStreamId and sub_workstream_name= :subWorkStreamName \n" +
            "and scenario= :scenario and active_ind='true' and original_ind='false' and period is not null group by period\n" +
            "union\n" +
            "select distinct substr(period,1,4) as period from sub_workstream_other_cost where sub_workstream_id= :subWorkStreamId and sub_workstream_name= :subWorkStreamName \n" +
            "and scenario= :scenario and active_ind='true' and original_ind='false' and period is not null group by period\n" +
            "union\n" +
            "select distinct substr(period,1,4) as period from sub_workstream_hardware_cost where sub_workstream_id= :subWorkStreamId and sub_workstream_name= :subWorkStreamName \n" +
            "and scenario= :scenario and active_ind='true' and original_ind='false' and period is not null group by period \n" +
            "union select distinct substr(period,1,4) as period from sub_workstream_resource_cost where sub_workstream_id= :subWorkStreamId and sub_workstream_name= :subWorkStreamName \n" +
            "            and scenario= :scenario and active_ind='true' and original_ind='false' and period is not null group by period \n" +
            "union select distinct substr(period,1,4) as period from sub_workstream_fin_details where sub_workstream_id= :subWorkStreamId and sub_workstream_name= :subWorkStreamName \n" +
            "                        and scenario= :scenario and period is not null group by period) as distinct_periods",nativeQuery = true)
    List<String> getDistinctOfPeriodFromFinancialTables(@Param("subWorkStreamId") String subWorkStreamId,@Param("subWorkStreamName") String subWorkStreamName, @Param("scenario") String scenario);

    List<SubWorkstreamOtherCost> findAllByWorkStreamIdAndSubWorkStreamIdInAndScenario(
            String workStreamId, List<String> subWorkStreamIds, String scenario);

    Integer deleteAllByWorkStreamIdAndSubWorkStreamIdAndScenarioIn(
            String workStreamId, String subWorkStreamId, List<String> scenarios);

    List<SubWorkstreamOtherCost> findBySubWorkStreamIdAndSubWorkStreamNameAndVendorNameAndScenarioAndActiveIndAndOriginalInd(
            String subWorkStreamId, String subWorkStreamName, String vendorName, String scenario, String aTrue,String originalInd);

    List<SubWorkstreamOtherCost> findBySubWorkStreamIdAndSubWorkStreamNameAndVendorNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotIn(
            String subWorkStreamId, String subWorkStreamName, String vendorName, String scenario, String aTrue,String originalInd, List<String> glCategories);

    SubWorkstreamOtherCost findAllBySwsOtherSurrId(Integer swsOtherSurrId);

    @Query(value = "select coalesce (sum(group_ccy_val),0) from sub_workstream_other_cost where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name =:subWorkStreamName and scenario = :scenario and gl_category = :glCategory  and ref_sws_other_surr_id = :refSurrId  and active_ind = 'true' and original_ind='false' " ,
            nativeQuery = true)
    BigDecimal getTotalCapexForOthersByGrpCcy(String subWorkStreamId, String subWorkStreamName, String scenario, String glCategory, Integer refSurrId);

    @Query(value = "select coalesce (sum(local_ccy_val),0) from sub_workstream_other_cost where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name =:subWorkStreamName and scenario = :scenario and gl_category = :glCategory  and ref_sws_other_surr_id = :refSurrId  and active_ind = 'true' and original_ind='false' " ,
            nativeQuery = true)
    BigDecimal getTotalCapexForOthersByLocalCcy(String subWorkStreamId, String subWorkStreamName, String scenario, String glCategory, Integer refSurrId);


    @Query(value = "delete from sub_workstream_software_cost where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name =:subWorkStreamName and scenario = :scenario and gl_category = :glCategory and ref_sw_cost_surr_id = :refSurrId and active_ind = 'true' and original_ind='false' " ,
            nativeQuery = true)
    void deleteAllItDepreciationBySoftware(String subWorkStreamId, String subWorkStreamName, String scenario, String glCategory, Integer refSurrId);


    SubWorkstreamOtherCost findByScenarioAndCapexOpexSurrIdAndGlCategoryAndOriginalIndAndActiveInd(String scenario,Integer capexOpexSurrId,String glCategory,String orgInd,String activeInd);

    List<SubWorkstreamOtherCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndGlCategoryAndRefSwsOtherSurrIdAndActiveIndAndOriginalInd(String subWorkstreamId, String subWorkstreamName, String scenario, String glCategory, Integer refSwsOtherSurrId, String activeInd, String originalInd);

    List<SubWorkstreamOtherCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndGlCategoryAndRefSwsOtherSurrIdAndPeriodInAndActiveIndAndOriginalInd(String subWorkstreamId, String subWorkstreamName, String scenario, String ownership, Integer refSurrId, List<String> ownerShipPeriods, String aTrue, String aFalse);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update SubWorkstreamOtherCost otherCost set otherCost.scenario =:approvalScenario " +
            "where otherCost.workStreamId in (:workStreamIds) and otherCost.scenario=:scenario")
    Integer updateApprovalScenarioForWorkStreamsAndScenario(@Param("workStreamIds") List<String> workStreamIds,
                                                            @Param("scenario") String scenario,
                                                            @Param("approvalScenario") String approvalScenario);
}
