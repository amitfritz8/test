package com.dbs.genesis.portfolio.mapper;

import com.dbs.genesis.portfolio.common.MathExtentions;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.service.costsettings.FinancialDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
public class CostSettingsMapper implements MathExtentions {

	@Autowired
	FinancialDetailsService financialDetailsService;
	public HLERefDataResource mapHLEEntityToResource(Date startDate, Date goLiveDate,
													 Map<String, List<SubWorkstreamFinDetailsEntity>> entitiesPerCostType,
													 String currencyCodeType, String scenario, List<String> glCategories,
													 List<String> costTypes){

		HLERefDataResource hleRefDataResource = new HLERefDataResource();
		List<String> currencyCodes = new ArrayList<>();
		hleRefDataResource.setStartDate(startDate);
		hleRefDataResource.setGoLiveDate(goLiveDate);
		hleRefDataResource.setScenario(scenario);
		hleRefDataResource.setCurrencyCodeType(currencyCodeType);
		currencyCodes.add(currencyCodeType);
		List<FinancialInputGroupResource> financialInputGroupResources = new ArrayList<>();
		if(entitiesPerCostType != null) {
			entitiesPerCostType.forEach((costType, finDetailsEntities)->{
				FinancialInputGroupResource financialInputGroupResource = new FinancialInputGroupResource();
				financialInputGroupResource.setCostType(costType);
				mapHLEDynamicFieldsMap(hleRefDataResource, financialInputGroupResource, finDetailsEntities,
						currencyCodeType);
				financialInputGroupResources.add(financialInputGroupResource);
			});
		}
		List<FinancialInputGroupResource> financialInputGroupResourcesInOrder =
				initialiseDefaultCostTypes(financialInputGroupResources , glCategories, costTypes);
		//hleRefDataResource.setFinancialInputGroup(financialInputGroupResources);
		hleRefDataResource.setFinancialInputGroup(financialInputGroupResourcesInOrder);

		return hleRefDataResource;
	}

	private List<FinancialInputGroupResource> initialiseDefaultCostTypes(List<FinancialInputGroupResource> financialInputGroupResources ,
			List<String> glCategories,List<String> allCostTypes) {
			List<String> costTypes = financialInputGroupResources.stream()
    		    .map(FinancialInputGroupResource::getCostType).distinct()
    		    .collect(Collectors.toList());
			List<String> diffCostTypes = allCostTypes.stream()
                    .filter(i -> !costTypes.contains(i))
                    .collect (Collectors.toList());
			financialInputGroupResources.addAll(createEmptyCostTypes(diffCostTypes, glCategories));
		List<FinancialInputGroupResource> financialInputGroupResourcesInOrder =
				applyCostTypesOrderingForHLE(allCostTypes, financialInputGroupResources, glCategories);
		//financialInputGroupResourcesInOrder = applyCostTypesOrderingForHLE(allCostTypes, financialInputGroupResources);
		return financialInputGroupResourcesInOrder;
	}

	private List<FinancialInputGroupResource> applyCostTypesOrderingForHLE(List<String> allCostTypesInOrder,
											  List<FinancialInputGroupResource> financialInputGroupResources, List<String> glCategories){
		List<FinancialInputGroupResource> finGroupResourcesInOrder = new ArrayList<>();
		allCostTypesInOrder.forEach(costType->{
			financialInputGroupResources.forEach(finGroupResource->{
				if(costType.equalsIgnoreCase(finGroupResource.getCostType())){
					finGroupResourcesInOrder.add(finGroupResource);
				}
			});
		});

		for (FinancialInputGroupResource financialInputGroup: finGroupResourcesInOrder) {
			List<HLECostType> dynamicData = new ArrayList<>();
			glCategories.forEach(glCategory -> {
				financialInputGroup.getDynamicData().forEach(element -> {
					if (glCategory.equalsIgnoreCase(element.getGlCategoryName())) {
						dynamicData.add(element);
					}
				});
			});
			financialInputGroup.setDynamicData(dynamicData);
		}
		return finGroupResourcesInOrder;
	}

	private List<FinancialInputGroupResource> createEmptyCostTypes(List<String> diffCostTypes,
																   List<String> glCategories){
		List<FinancialInputGroupResource> figResources = new ArrayList<>();
		diffCostTypes.forEach(costType->{
			FinancialInputGroupResource financialInputGroupResource = new FinancialInputGroupResource();
			glCategories.forEach(glCategorie->{
				HLECostType hleCostType = new HLECostType();
				hleCostType.setCostType(costType);
				hleCostType.setGlCategoryName(glCategorie);
				hleCostType.setHleSurrId(0);
				hleCostType.setValue(BigDecimal.ZERO);
				financialInputGroupResource.setCostType(costType);
				financialInputGroupResource.getDynamicData().add(hleCostType);
			});
			figResources.add(financialInputGroupResource);
		});
		return figResources;
	}

	private void mapHLEDynamicFieldsMap(HLERefDataResource hleRefDataResource,
										FinancialInputGroupResource financialInputGroupResource,
										List<SubWorkstreamFinDetailsEntity> finDetailsEntities,
										String currencyCodeType){
		finDetailsEntities.forEach(finDetailEntity->{
			hleRefDataResource.setCreatedBy(finDetailEntity.getCreatedBy());
			hleRefDataResource.setModifiedBy(finDetailEntity.getModifiedBy());
			hleRefDataResource.setWorkStreamId(finDetailEntity.getWorkstreamId());
			hleRefDataResource.setSubWorkStreamId(finDetailEntity.getSubWorkstreamId());
			hleRefDataResource.setSubWorkStreamName(finDetailEntity.getSubWorkstreamName());
			hleRefDataResource.setDateCreated(finDetailEntity.getDateCreated().toString());
			HLECostType hleCostType = new HLECostType();
			hleCostType.setCostType(finDetailEntity.getCostType());
			hleCostType.setHleSurrId(finDetailEntity.getSubWorkStreamFinSurrId());
			hleCostType.setGlCategoryName(finDetailEntity.getGlCategory());
			BigDecimal currencyValue = BigDecimal.ZERO;
			if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCodeType)){
				currencyValue = finDetailEntity.getGroupCcyVal();
			}else{
				currencyValue = finDetailEntity.getLocalCcyVal();
			/*divideWithScaleHalfUp(finDetailEntity.getGroupCcyVal(),
						financialDetailsService.getExchangeValue(finDetailEntity.getPeriod(),
								currencyCodeType,finDetailEntity.getWorkstreamId()));*/
			}
			if(currencyValue.intValue() != 0)
				hleCostType.setValue(currencyValue);
			financialInputGroupResource.getDynamicData().add(hleCostType);
		});
	}
}
