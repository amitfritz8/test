package com.dbs.genesis.portfolio.model;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Data
@Entity
@Table(name = "itc_rate")
@EntityListeners(AuditingEntityListener.class)
public class ITCRateEntity extends CommonEntity<Integer> {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "itc_rate_surr_id")
    private Integer ItcRateSurrId;
    @Column(name ="itc_included")
    private String itcIncluded;
    @Column(name ="tower")
    private String tower;
    @Column(name ="driver_detail")
    private String driverDetail;
    @Column(name ="uom")
    private String uom;
    @Column(name ="rpt_location")
    private String rptLocation;
    @Column(name ="ccy_code")
    private String ccyCode;
    @Column(name ="itc_version")
    private String itcVersion;
    @Column(name ="itc_period")
    private String itcPeriod;
    @Column(name ="rate_val")
    private String rateValue;

}
