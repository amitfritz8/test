package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.sql.Date;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkStreamApproversResource {

    private String workStreamName;
    private String role;
    private String delegateInd;
    private String staffName;
    private String scenario;
    private String action;
    private String notifyInd;
    private String oneBankId;
    private String workStreamId;
    private Integer wsApproverSurrId;
    private String activeInd;
    private Date effectiveStartDate;
    private Date effectiveEndDate;


}
