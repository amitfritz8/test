package com.dbs.genesis.portfolio.model.copyscenario;

import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class SubWorkStreamHardwareOpexCopyHolder {

    private SubWorkstreamHardwareCost subWorkStreamHardwareOpexCostParent;
    private List<SubWorkstreamHardwareCost> subWorkStreamHardwareOpexCostChildren =
            new ArrayList<>();

    private SubWorkstreamHardwareCost subWorkStreamHardwareOwnershipCostParent;
    private List<SubWorkstreamHardwareCost> subWorkStreamHardwareOwnershipCostChildren =
            new ArrayList<>();

}
