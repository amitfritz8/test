package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.ExchangeRatesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ExchangeRatesRepo extends JpaRepository<ExchangeRatesEntity, Integer> {

    @Override
    Optional<ExchangeRatesEntity> findById(Integer integer);

    ExchangeRatesEntity findByCurrencyFromAndCurrencyToAndRateTypeAndBudgetStatusAndRatePeriod(String currencyFrom,
                                                                                               String currencyTo,
                                                                                               String rateType,String
                                                                                                       budgetStatus,
                                                                                               String ratePeriod);

}
