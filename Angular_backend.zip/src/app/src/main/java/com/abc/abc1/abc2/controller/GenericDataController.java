package com.dbs.genesis.portfolio.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

public abstract class GenericDataController<T, ID extends Serializable> {

    private JpaRepository<T, ID> repo;

    public GenericDataController(JpaRepository<T, ID> repo) {
        this.repo = repo;
    }

    @GetMapping
    public ResponseEntity<List<T>> listAll() {
        return ResponseEntity.ok(this.repo.findAll());
    }

    @GetMapping("/page")
    public ResponseEntity<Page<T>> listAllByPage(Pageable pageable) {
        return ResponseEntity.ok(this.repo.findAll(pageable));
    }

    @PostMapping
    public ResponseEntity<T> create(@RequestBody T json) {
        return ResponseEntity.ok(this.repo.save(json));
    }
    @GetMapping("/{id}")
    public ResponseEntity<T> getById(@PathVariable ID id) {
        Optional<T> optional = this.repo.findById(id);
        return optional.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.badRequest().build());
    }
    @PutMapping("/{id}")
    public ResponseEntity<T> update(@PathVariable ID id, @RequestBody T json) {
        if(!this.repo.findById(id).isPresent()){
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.ok(this.repo.save(json));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity delete(@PathVariable ID id) {
        if(!repo.findById(id).isPresent()){
            return ResponseEntity.badRequest().build();
        }
        repo.deleteById(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/delete")
    public ResponseEntity deleteByParam(@RequestParam ID id){
        if(!repo.findById(id).isPresent()){
            return ResponseEntity.badRequest().build();
        }
        repo.deleteById(id);
        return ResponseEntity.ok().build();
    }

}
