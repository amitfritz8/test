package com.dbs.genesis.portfolio.resources;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class WorkStreamListingSource {

    String portfolioId;
    String portfolioName;
    String workStreamId;
    String workStreamName;
    String platformName;
    String location;
    String lePCCodeBuild;
    String workStatus;
    String subPlatformName;

}
