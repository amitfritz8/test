package com.dbs.genesis.portfolio.model;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Data
@Entity
@Table(name = "xref_biz_segment_master")
@EntityListeners(AuditingEntityListener.class)
public class BusinessSegmentMasterEntity extends CommonEntity<String> {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "biz_surr_id")
    private Integer businessSurrId;

    @Column(name = "platform_index")
    private String platformIndex;

    @Column(name = "platform_name")
    private String platformName;

    @Column(name = "biz_segment_name")
    private String bizSegmentName;
}
