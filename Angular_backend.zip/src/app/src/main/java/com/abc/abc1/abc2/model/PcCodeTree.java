package com.dbs.genesis.portfolio.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


@NamedStoredProcedureQuery(name = "sp_etl_psgl_to_sws_fin_details", procedureName = "sp_etl_psgl_to_sws_fin_details")
@NamedStoredProcedureQuery(name = "sp_etl_hyperion_to_sws_fin_details", procedureName = "sp_etl_hyperion_to_sws_fin_details")




@Data
@Entity
@Table(name = "xref_le_pccode_tree")
@EntityListeners(AuditingEntityListener.class)
public class PcCodeTree extends CommonEntity<String> {

    @Id
    @Column(name = "le_pccode")
    private String pcCode;
    @Column(name = "le_pccode_desc")
    private String pcCodeDesc;
    @Column(name = "l1_node")
    private String l1Node;
    @Column(name = "l1_desc")
    private String l1Desc;
    @Column(name = "l2_node")
    private String l2Node;
    @Column(name = "l2_desc")
    private String l2Desc;
    @Column(name = "l3_node")
    private String l3Node;
    @Column(name = "l3_desc")
    private String l3Desc;
    @Column(name = "l4_node")
    private String l4Node;
    @Column(name = "l4_desc")
    private String l4Desc;
    @Column(name = "l5_node")
    private String l5Node;
    @Column(name = "l5_desc")
    private String l5Desc;
    @Column(name = "l6_node")
    private String l6Node;
    @Column(name = "l6_desc")
    private String l6Desc;
    @Column(name = "l7_node")
    private String l7Node;
    @Column(name = "l7_desc")
    private String l7Desc;
    @Column(name = "l8_node")
    private String l8Node;
    @Column(name = "l8_desc")
    private String l8Desc;
    @Column(name = "l9_node")
    private String l9Node;
    @Column(name = "l9_desc")
    private String l9Desc;

    @Column(name = "platform_index")
    private String platformIndex;

    @Column(name = "platform_name")
    private String platformName;

    @Column(name = "country_code")
    private String countryCode;

}
