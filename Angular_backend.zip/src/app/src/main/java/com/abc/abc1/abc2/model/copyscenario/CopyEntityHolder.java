package com.dbs.genesis.portfolio.model.copyscenario;

import lombok.Data;

@Data
public class CopyEntityHolder {

    private SubWorkStreamFinDetailsEntityCopyHolder subWorkStreamFinDetailsEntityCopyHolder;
    private SubWorkStreamSoftwareCostCopyHolder subWorkStreamSoftwareCostCopyHolder;
    private SubWorkStreamHardwareCostCopyHolder subWorkStreamHardwareCostCopyHolder;


}
