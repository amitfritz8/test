package com.dbs.genesis.portfolio.controller;

import com.dbs.genesis.portfolio.common.GeneUtils;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.EditLogRepo;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import com.dbs.genesis.portfolio.service.PortFolioWorkStreamAndSubWorkStreamGenerator;
import com.dbs.genesis.portfolio.service.PortfolioService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;


@Slf4j
@RestController
@RequestMapping("/data/portfolio")

public class PortFolioController {

    @Autowired
    private PortfolioService portfolioService;

    @Autowired
    private DataSummaryService dataSummaryService;

    @Autowired
    private PortFolioWorkStreamAndSubWorkStreamGenerator pwsGen;

    @Autowired
    private EditLogRepo editLogRepo;


    @PostMapping("/generate/default/portfoliogeneration")
    public ResponseEntity savePortfolio(@RequestParam("userId") String userId, @RequestBody PortfolioCreationEvent portfolioCreationEvent) {
        try {
            List<WorkHierarchyEntity> workHierarchyEntity = pwsGen.generate(portfolioCreationEvent,userId);
            return ResponseEntity.ok().body(workHierarchyEntity);
        } catch (Exception e) {
            log.error("While Creating the Portfolio id Generation", e);
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(Collections.singletonMap("failure", "Save portfolio failed"));
        }
    }


    @GetMapping("/common/getportfoliodata/{portfolioId}/{portfolioType}/{name}")
    public ResponseEntity getPortfolioData(@PathVariable String portfolioId, @PathVariable String portfolioType,
                                           @PathVariable String name, @RequestParam String staffName) {
        ResponseEntity responseEntity = null;

        if (PortfolioConstants.PORTFOLIONAME.equalsIgnoreCase(portfolioType)) {
            PortfolioEntity portfolioEntity = portfolioService.getListOfPortfolioData(portfolioId);
            responseEntity = ResponseEntity.ok().body(portfolioEntity);
        } else if (PortfolioConstants.WORKSTREAMNAME.equalsIgnoreCase(portfolioType)) {
            WorkStreamEntity workStreamEntity = portfolioService.getListOfWorkStreamData(portfolioId);
            String countryCode = workStreamEntity.getCountry();
            List<WorkstreamLePccodesEntity> workstreamLePccodesEntity = portfolioService.getListOfWorkStreamLepccodesData(portfolioId);
            workStreamEntity.setWorkstreamLePccodesEntities(workstreamLePccodesEntity);
            List<DataValues> dataValuesList = dataSummaryService.getDataValuesBySummary(PortfolioConstants.COUNTRY);
            for (DataValues values : dataValuesList) {
                if (StringUtils.isNotEmpty(values.toString()) && StringUtils.isNotEmpty(values.toString())) {
                    if (countryCode.equalsIgnoreCase(values.getDesc())) {
                        workStreamEntity.setCountry(values.getValue());
                    }
                }
            }
            responseEntity = ResponseEntity.ok().body(workStreamEntity);
        } else if (PortfolioConstants.SUBWORKSTREAMNAME.equalsIgnoreCase(portfolioType) && Strings.isNotEmpty(name)) {
            SubWorkStreamEntity subWorkStreamEntity = portfolioService.getListOfSubWorkStreamData(portfolioId,name);
            responseEntity = ResponseEntity.ok().body(subWorkStreamEntity);
        }

        if(!Objects.isNull(responseEntity)){
            if(StringUtils.isNotBlank(staffName)){
                EditLog editLog = editLogRepo.findByPortfolioIdAndPortfolioNameAndPortfolioType(portfolioId,name,portfolioType);
                if(Objects.isNull(editLog))
                    editLogRepo.saveAndFlush(new EditLog(portfolioId,portfolioType,name,staffName));
                else
                    GeneUtils.populateStaffNameAndEditFlag(responseEntity,editLog,portfolioType,staffName);
            }

        } else {
            responseEntity = ResponseEntity.ok().body("Error while fetching PortfolioData");
        }

        return responseEntity;
    }

    @PostMapping("/dataname")
    public boolean getPortfolioName(@RequestBody DataTypeNameResource dataNamesResource) {
        return portfolioService.isDataNameExists(dataNamesResource);
    }

    @PutMapping("/edit/updateportfolio")
    public ResponseEntity saveEditPortfolio(@RequestBody PortfolioEntityDataSource portfolioEntityDataSource) {
        PortfolioEntity entity = portfolioService.updatePortfolioDataSource(portfolioEntityDataSource);
        return ResponseEntity.ok().body(entity);
    }

    @GetMapping("/getworkmanagers/{portfolioId}")
    public ResponseEntity getWorkManagersData(@PathVariable String portfolioId) {
        List<Map> workManagerData = portfolioService.getListOfWorkManagersData(portfolioId);
        return ResponseEntity.ok().body(workManagerData);
    }

    @GetMapping("/latestworkdayrecord")
    public ResponseEntity getWorkManagersData() {
        List<StageWorkdayData> stageWorkdaysData = portfolioService.getLatestRecordsFromWorkDay();
        return ResponseEntity.ok().body(stageWorkdaysData);
    }

    @GetMapping("/business/segment/{platformIndex}")
    public ResponseEntity getBusinessSegmentMasterList(@PathVariable String platformIndex) {
        List<BusinessSegmentMasterEntity> segmentMasterEntities = portfolioService.getBusinessSegmentMasterData(platformIndex);
        return ResponseEntity.ok().body(segmentMasterEntities);
    }

    @GetMapping("/approvers/{portfolioId}")
    public ResponseEntity getListOfWorkStreamApproves(@PathVariable String portfolioId) {
        List<Map> map = portfolioService.getListOfWorkStreamApproves(portfolioId);
        return ResponseEntity.ok().body(map);


    }

    @PostMapping("/listing")
    public ResponseEntity getPortfolioListingData(@RequestBody IdAndRoles idAndRoles) {
        List<PortfolioListingSource> portfolioListingSourceList = portfolioService.getAllPortfolioListing(idAndRoles);
        ResponseEntity<List<PortfolioListingSource>> responseEntity = ResponseEntity.ok().body(portfolioListingSourceList);
        return responseEntity;
    }

    @GetMapping("/breakdown-financial-data")
    public Map getBreakDownFinancialData(@RequestParam("scenario") String scenario,
                                         @RequestParam("portfolioId") String portfolioId,
                                         @RequestParam("period")
                                                 String period, @RequestParam("ccyCode") String currencyCode, @RequestParam("typeOfData") String typeOfData) {
        return portfolioService.getBreakDownFinancialDataByScenario(scenario, portfolioId,
                period, currencyCode, typeOfData);
    }

    @GetMapping("/breakdown-cost-data")
    public Map getBreakDownCostData(@RequestParam("scenario") String scenario,
                                    @RequestParam("portfolioId") String portfolioId,
                                    @RequestParam("period")
                                            String period, @RequestParam("ccyCode") String currencyCode, @RequestParam("typeOfData") String typeOfData) {
        return portfolioService.getBreakDownCostDataByScenario(scenario, portfolioId,
                period, currencyCode, typeOfData);
    }

    @GetMapping("/listOfFinYears")
    public ResponseEntity getListOfFinanceYears(@RequestParam("portfolioId") String portfolioId,
                                                @RequestParam("scenario") String scenario) {
        List<String> listOfYears = portfolioService.getFinancialYearsByScenario(portfolioId, scenario);
        return ResponseEntity.ok().body(listOfYears);
    }
}
