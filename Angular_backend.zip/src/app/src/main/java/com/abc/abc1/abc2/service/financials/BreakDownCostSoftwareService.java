package com.dbs.genesis.portfolio.service.financials;

import com.dbs.genesis.portfolio.common.CombineTwoArrayValues;
import com.dbs.genesis.portfolio.common.CommonFinancialTypes;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.repository.SubWorkstreamOtherCostRepo;
import com.dbs.genesis.portfolio.repository.SubWorkstreamSoftwareCostRepo;
import com.dbs.genesis.portfolio.resources.*;
import com.google.common.collect.Lists;
import io.vavr.Tuple2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Slf4j
@Service
public class BreakDownCostSoftwareService implements CombineTwoArrayValues, CommonFinancialTypes {

    private final SubWorkstreamSoftwareCostRepo subWorkstreamSoftwareCostRepo;
    private final BreakDownCostHardwareService breakDownCostHardwareService;
    private final BreakDownCostOthersService breakDownCostOthersService;
    private final PortfolioRepository portfolioRepository;
    private final SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo;
    private final BreakDownCostResourceService breakDownCostResourceService;

    @Autowired
    public BreakDownCostSoftwareService(SubWorkstreamSoftwareCostRepo subWorkstreamSoftwareCostRepo,
                                        BreakDownCostHardwareService breakDownCostHardwareService,
                                        BreakDownCostOthersService breakDownCostOthersService,
                                        PortfolioRepository portfolioRepository,
                                        SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo,
                                        BreakDownCostResourceService breakDownCostResourceService) {
        this.subWorkstreamSoftwareCostRepo = subWorkstreamSoftwareCostRepo;
        this.breakDownCostHardwareService = breakDownCostHardwareService;
        this.breakDownCostOthersService = breakDownCostOthersService;
        this.portfolioRepository = portfolioRepository;
        this.subWorkstreamOtherCostRepo = subWorkstreamOtherCostRepo;
        this.breakDownCostResourceService = breakDownCostResourceService;
    }


    public CostSettingsView getCostSettingForFinancialDetails(List<String> costTypes,
                                                              String subWorkStreamId, String subWorkStreamName,
                                                              String period, String periodType,
                                                              String costSettingValue, String scenario, String currencyCode) {
        CostSettingsView costSettingsView = null;

        if (PortfolioConstants.MONTHLY.equalsIgnoreCase(periodType)) {
            costSettingsView = getCostSettingsByMonthlyForFinancial(costTypes, subWorkStreamId, subWorkStreamName,
                    period, costSettingValue, scenario, currencyCode);
        }
        if (PortfolioConstants.QUARTERLY.equalsIgnoreCase(periodType)) {
            costSettingsView = getCostSettingsByQuarterlyForFinancial(costTypes, subWorkStreamId, subWorkStreamName,
                    costSettingValue, scenario, currencyCode);
        }
        if (PortfolioConstants.YEARLY.equalsIgnoreCase(periodType)) {
            costSettingsView = getCostSettingsByYearlyForFinancial(costTypes, subWorkStreamId, subWorkStreamName,
                    costSettingValue, scenario, currencyCode);
        }

        return costSettingsView;
    }

    private CostSettingsView getCostSettingsByMonthlyForFinancial(List<String> costTypes,
                                                                  String subWorkStreamId, String subWorkStreamName,
                                                                  String period, String costSettingValue, String scenario, String currencyCode) {
        CostSettingsView costSettingsView = new CostSettingsView();
        costSettingsView.setName(costSettingValue);
        //level 0
        List<FinancialSummaryResource> consolidatedFinancialSummary =
                PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, period, scenario)
                        : portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, period, scenario);
        List<BigDecimal> monthlyCostSettings = getCostSettingMonthlyData(consolidatedFinancialSummary);
        costSettingsView.setMonthlyCostSettings(monthlyCostSettings);
        costSettingsView.setCostSettingsTotal(monthlyCostSettings.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        costSettingsView.setCostSettingsOverAllTotal(
                PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        portfolioRepository.getConsolidatedFinancialSummaryTotalByGroupCurrency(subWorkStreamId, subWorkStreamName, scenario).get(0).getCurrencyValue()
                        : portfolioRepository.getConsolidatedFinancialSummaryTotalByLocalCurrency(subWorkStreamId, subWorkStreamName, scenario).get(0).getCurrencyValue());

        List<CostTypeCategoryView> costTypeCategoryViewList = new ArrayList<>();
        costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);

        List<CompletableFuture> allFutures = new ArrayList<>();

         costTypes.forEach(costType -> {
            CompletableFuture<CostTypeCategoryView> cf = CompletableFuture.supplyAsync(() -> getCostTypeForFinancialByMonthly(costType ,subWorkStreamId, subWorkStreamName, period, scenario, currencyCode));
            allFutures.add(cf);
         });

        CompletableFuture.allOf(allFutures.stream().toArray(CompletableFuture[]::new))
           .whenComplete((v, th) -> {
               allFutures.forEach(cf -> costTypeCategoryViewList.add((CostTypeCategoryView)cf.getNow(new CostTypeCategoryView())));
           }).join();

        return costSettingsView;
    }

    private CostTypeCategoryView getCostTypeForFinancialByMonthly(String costType,
                                                                  String subWorkStreamId, String subWorkStreamName,
                                                                  String period, String scenario, String currencyCode) {
        CostTypeCategoryView costTypeCategoryView = new CostTypeCategoryView();
        switch (costType) {
            case PortfolioConstants.SOFTWARE_TYPE:
                //level1
                List<BigDecimal> monthlyValuesBySoftwareTotal = getListOfMonthlyValuesBySoftwareTotal(subWorkStreamId, subWorkStreamName, period, scenario, currencyCode,costType);

                List<UnitCostMappingView> softwareUnitCostMapByMonthly = getSoftwareUnitCostMapByMonthly(subWorkStreamId, subWorkStreamName, period, scenario, currencyCode);
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setMonthlyCostTypes(monthlyValuesBySoftwareTotal);
                costTypeCategoryView.setCostTypeTotal(monthlyValuesBySoftwareTotal.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                costTypeCategoryView.setCostTypeOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        portfolioRepository.getSubworkstreamCostTypeOverAllTotalByGroupCurrency(subWorkStreamId, subWorkStreamName, scenario,
                                "financialSoftwareCostTypeOverAllTotalByGroupCurrency",  PortfolioConstants.SOFTWARE_TYPE).get(0).getCurrencyValue()
                        : portfolioRepository.getSubworkstreamCostTypeOverAllTotalByLocalCurrency(subWorkStreamId, subWorkStreamName, scenario,
                        "financialSoftwareCostTypeOverAllTotalByLocalCurrency",  PortfolioConstants.SOFTWARE_TYPE).get(0).getCurrencyValue());
                //level2
                costTypeCategoryView.setMonthlyUnitCostList(softwareUnitCostMapByMonthly);
                break;
            case PortfolioConstants.HARDWARE_TYPE:
                List<BigDecimal> monthlyValuesByHardwareTotal = breakDownCostHardwareService.getListOfMonthlyValuesByHardwareTotal(subWorkStreamId, subWorkStreamName, period,scenario,currencyCode,costType);
                List<UnitCostMappingView> hardwareUnitCostMapByMonthly = breakDownCostHardwareService.getHardwareUnitCostMapByMonthly(subWorkStreamId, subWorkStreamName, period,scenario,currencyCode);
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setMonthlyCostTypes(monthlyValuesByHardwareTotal);
                costTypeCategoryView.setCostTypeTotal(monthlyValuesByHardwareTotal.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                costTypeCategoryView.setCostTypeOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        portfolioRepository.getSubworkstreamCostTypeOverAllTotalByGroupCurrency(subWorkStreamId, subWorkStreamName, scenario,
                                "financialHardwareCostTypeOverAllTotalByGroupCurrency",  PortfolioConstants.HARDWARE_TYPE).get(0).getCurrencyValue()
                        : portfolioRepository.getSubworkstreamCostTypeOverAllTotalByLocalCurrency(subWorkStreamId, subWorkStreamName, scenario,
                        "financialHardwareCostTypeOverAllTotalByLocalCurrency",  PortfolioConstants.HARDWARE_TYPE).get(0).getCurrencyValue());
                costTypeCategoryView.setMonthlyUnitCostList(hardwareUnitCostMapByMonthly);
                break;
            case PortfolioConstants.OTHERS_TYPE:
                List<UnitCostMappingView> othersByMonthly = breakDownCostOthersService.getOthersByMonthly(subWorkStreamId, subWorkStreamName, period,scenario,currencyCode);
                List<BigDecimal> monthlyValuesByOthersTotal =  breakDownCostOthersService.getOthersHeaderByMonthly(subWorkStreamId,subWorkStreamName,period,scenario,currencyCode);
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setMonthlyCostTypes(monthlyValuesByOthersTotal);
                costTypeCategoryView.setCostTypeTotal(monthlyValuesByOthersTotal.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                costTypeCategoryView.setCostTypeOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        portfolioRepository.getSubworkstreamCostTypeOverAllTotalByGroupCurrency(subWorkStreamId, subWorkStreamName, scenario,
                                "financialOthersCostTypeOverAllTotalByGroupCurrency",  PortfolioConstants.OTHERS_TYPE).get(0).getCurrencyValue()
                        : portfolioRepository.getSubworkstreamCostTypeOverAllTotalByLocalCurrency(subWorkStreamId, subWorkStreamName, scenario,
                        "financialOthersCostTypeOverAllTotalByLocalCurrency",  PortfolioConstants.OTHERS_TYPE).get(0).getCurrencyValue());
                costTypeCategoryView.setMonthlyUnitCostList(othersByMonthly);
                break;
            case PortfolioConstants.RESOURCE_TYPE:
                costTypeCategoryView.setName(costType);
                List<List<BigDecimal>> monthlyValuesByResouceTotal = breakDownCostResourceService.getListOfMonthlyValuesByResourceTotal(subWorkStreamId, subWorkStreamName, period, scenario, currencyCode);
                List<BigDecimal> costTypeTotalResource = new ArrayList<>();
                List<BigDecimal> monthlyValues = monthlyValuesByResouceTotal.get(2);
                costTypeTotalResource.add(monthlyValuesByResouceTotal.get(0).stream().reduce(BigDecimal.ZERO, BigDecimal::add));
                //costTypeTotalResource.add(monthlyValuesByResouceTotal.get(1).stream().reduce(BigDecimal.ZERO, BigDecimal::add));
                costTypeTotalResource.add(BigDecimal.ZERO);
                costTypeTotalResource.add(monthlyValues.stream().reduce(BigDecimal.ZERO, BigDecimal::add));
                costTypeCategoryView.setCostTypeTotalResource(costTypeTotalResource);
                List<BigDecimal> resourceOverAllTotal = new ArrayList<>();
                monthlyValuesByResouceTotal.stream().forEach(monthlyValuesByResouceTotalTmp ->
                {

                    BigDecimal total = monthlyValuesByResouceTotalTmp.stream().reduce(BigDecimal.ZERO, BigDecimal::add);
                    resourceOverAllTotal.add(total);
                });

                List<BigDecimal> grandTotal = Arrays.asList(BigDecimal.ZERO,BigDecimal.ZERO,PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        portfolioRepository.getSubworkstreamCostTypeOverAllTotalByGroupCurrency(subWorkStreamId, subWorkStreamName, scenario,
                                "financialResourceCostTypeOverAllTotalByGroupCurrency", PortfolioConstants.RESOURCE_TYPE).get(0).getCurrencyValue()
                        : portfolioRepository.getSubworkstreamCostTypeOverAllTotalByLocalCurrency(subWorkStreamId, subWorkStreamName, scenario,
                        "financialResourceCostTypeOverAllTotalByLocalCurrency", PortfolioConstants.RESOURCE_TYPE).get(0).getCurrencyValue());

//                costTypeCategoryView.setCostTypeOverAllTotal(grandTotal.get(0));
                costTypeCategoryView.setCostTypeOverAllTotalResource(grandTotal);
                costTypeCategoryView.setMonthlyCostTypesResource(monthlyValuesByResouceTotal);
                List<UnitCostMappingView> respourceUnitCostMapByMonthly = breakDownCostResourceService.getResourceUnitCostMapByMonthly(subWorkStreamId, subWorkStreamName, period, scenario, currencyCode);
                costTypeCategoryView.setMonthlyUnitCostList(respourceUnitCostMapByMonthly);
                break;

            default:
                throw new IllegalStateException("Unexpected Cost Type: " + costType);

        }
        return costTypeCategoryView;
    }

    private List<BigDecimal> getListOfMonthlyValuesBySoftwareTotal(String subWorkStreamId, String subWorkStreamName, String period, String scenario, String currencyCode,String costType) {

        List<FinancialSummaryResource> consolidatedFinancialSummary =
                PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, period, scenario,
                                "financialSoftwareHeaderSummaryByPeriodAndGroupCcy",costType)
                        : portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, period, scenario,
                        "financialSoftwareHeaderSummaryByPeriodAndLocalCcy",costType);

        BigDecimal[] monthlyValues = new BigDecimal[12];
        Arrays.fill(monthlyValues, BigDecimal.ZERO);

        for (FinancialSummaryResource summaryResource : consolidatedFinancialSummary) {
            String reportingMonth = summaryResource.getPeriod().substring(4, 6);
            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                monthlyValues[Integer.parseInt(reportingMonth) - 1] = summaryResource.getCurrencyValue();
            }
        }
        BigDecimal[] othersSoftwareByMonthly = breakDownCostOthersService.getOthersSummaryByMonthly(subWorkStreamId, subWorkStreamName, period, scenario, PortfolioConstants.SOFTWARE_TYPE, currencyCode);
        BigDecimal[] combineMonthlyValuesBySoftware = getCombineMonthlyValues(monthlyValues, othersSoftwareByMonthly);
        return Arrays.asList(combineMonthlyValuesBySoftware);
    }


    private Tuple2<BigDecimal, BigDecimal> getCostTypeOverAllTotal(String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        List<SubWorkstreamSoftwareCost> subWorkStreamNameAndScenario =
                subWorkstreamSoftwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotIn(
                        subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, PortfolioConstants.FALSE, glCategories);
        BigDecimal costOverAllTotal = BigDecimal.ZERO;
        BigDecimal unitOverAllTotal = BigDecimal.ZERO;
        for (SubWorkstreamSoftwareCost subWorkStreamSoftwareCost : subWorkStreamNameAndScenario) {
            costOverAllTotal = costOverAllTotal.add(
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            subWorkStreamSoftwareCost.getCostPerMonthGcy() : subWorkStreamSoftwareCost.getCostPerMonthLcy());
            unitOverAllTotal = unitOverAllTotal.add(subWorkStreamSoftwareCost.getQuantity());
        }
        return new Tuple2<>(costOverAllTotal, unitOverAllTotal);
    }


    private List<UnitCostMappingView> getSoftwareUnitCostMapByMonthly(String subWorkStreamId, String subWorkStreamName,
                                                                      String period, String scenario, String currencyCode) {
        Map<String, Map<String, List<SubWorkstreamSoftwareCost>>> vendorPeriodMap = getSubWorkStreamSoftwareMap(subWorkStreamId, subWorkStreamName, period, scenario);
        List<UnitCostMappingView> unitCostList = Lists.newArrayList();

        vendorPeriodMap.forEach((softwareName, softwareNameListMap) -> {
            softwareNameListMap.forEach((vendorName, subWorkStreamSoftwareCostList) -> {
                UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
                unitCostMappingView.setRefSurrId(subWorkStreamSoftwareCostList.get(0).getRefSwsSwSurrId());
                unitCostMappingView.setName(vendorName + " - " + softwareName);
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setUnitPriceValue(subWorkStreamSoftwareCostList.get(0).getUnitPrice().toString());
                unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
                populateUnitCostMappingForGivenSoftware(subWorkStreamSoftwareCostList, unitCostMappingView, currencyCode);
                Tuple2<BigDecimal, BigDecimal> unitCostOverAllTotal = getUnitCostOverAllTotal(subWorkStreamId, subWorkStreamName, vendorName, scenario, currencyCode);
                unitCostMappingView.setYearlyCostOverAllTotal(unitCostOverAllTotal._1);
                unitCostMappingView.setYearlyUnitOverAllTotal(unitCostOverAllTotal._2);
                unitCostList.add(unitCostMappingView);
            });
        });
        List<UnitCostMappingView> otherSoftwareResource = breakDownCostOthersService.getOtherSoftwareByMonthly(subWorkStreamId, subWorkStreamName, period, scenario, currencyCode);
        unitCostList.addAll(otherSoftwareResource);

        return unitCostList;
    }

    private Map<String, Map<String, List<SubWorkstreamSoftwareCost>>> getVendorNamePeriodAndSoftwareCostList(
            String subWorkStreamId, String subWorkStreamName, String year, String scenario) {
        return getBySubWorkStreamOthersList(subWorkStreamId, subWorkStreamName, year, scenario).stream().collect(
                Collectors.groupingBy(SubWorkstreamSoftwareCost::getVendorName, Collectors.groupingBy(SubWorkstreamSoftwareCost::getSoftwareName)));
    }

    private Map<String, Map<String, List<SubWorkstreamSoftwareCost>>> getSubWorkStreamSoftwareMap(String subWorkStreamId,
                                                                                                  String subWorkStreamName,
                                                                                                  String period, String scenario) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        return subWorkstreamSoftwareCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotInAndPeriodContaining(
                        subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, PortfolioConstants.FALSE, glCategories, period)
                .stream().collect(Collectors.groupingBy(SubWorkstreamSoftwareCost::getSoftwareName, Collectors.groupingBy(
                        SubWorkstreamSoftwareCost::getVendorName)));
    }

    private UnitCostMappingView populateUnitCostMappingForGivenSoftware(List<SubWorkstreamSoftwareCost> softwarePeriodList,
                                                                        UnitCostMappingView unitCostMappingView, String currencyCode) {
        List<UnitCostResource> costResourceList = Lists.newLinkedList();
        List<UnitCostResource> unitResourceList = Lists.newLinkedList();

        BigDecimal unitOverAllTotal = BigDecimal.ZERO;
        BigDecimal costOverAllTotal = BigDecimal.ZERO;

        for (SubWorkstreamSoftwareCost subWorkStreamSoftwareCost : softwarePeriodList) {
            String reportingMonth = subWorkStreamSoftwareCost.getPeriod().substring(4, 6);
            UnitCostResource costResource = new UnitCostResource();
            BigDecimal costPerMonth = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    subWorkStreamSoftwareCost.getCostPerMonthGcy() : subWorkStreamSoftwareCost.getCostPerMonthLcy();
            BigDecimal quantity = subWorkStreamSoftwareCost.getQuantity();

            costResource.setSurrId(subWorkStreamSoftwareCost.getSwsSwSurrId());
            costResource.setMonthNumber(reportingMonth);
            costResource.setValue(costPerMonth);
            costResourceList.add(costResource);
            unitOverAllTotal = unitOverAllTotal.add(quantity);
            costOverAllTotal = costOverAllTotal.add(costPerMonth);

            UnitCostResource unitResource = new UnitCostResource();
            unitResource.setSurrId(subWorkStreamSoftwareCost.getSwsSwSurrId());
            unitResource.setMonthNumber(reportingMonth);
            unitResource.setValue(quantity);
            unitResource.setGlCategory(subWorkStreamSoftwareCost.getGlCategory());
            unitResourceList.add(unitResource);
        }

        costResourceList = costResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(costResourceList) : costResourceList;
        unitResourceList = unitResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(unitResourceList) : unitResourceList;

        unitCostMappingView.setMonthlyResourcesCosts(costResourceList);
        unitCostMappingView.setMonthlyResourcesUnits(unitResourceList);
        unitCostMappingView.setUnitOverAllTotal(unitOverAllTotal);
        unitCostMappingView.setCostOverAllTotal(costOverAllTotal);

        return unitCostMappingView;
    }

    private List<UnitCostResource> getUnitAndCostResourceMonthlyList(List<UnitCostResource> unitAndCostResourceList) {
        List<UnitCostResource> unitAndcostResourceMonthlyList = Lists.newLinkedList();
        if (unitAndCostResourceList.size() < 12) {
            for (int i = 1; i <= 12; i++) {
                UnitCostResource costResource = new UnitCostResource();
                costResource.setSurrId(0);
                costResource.setMonthNumber(i <= 9 ? "0" + i : String.valueOf(i));
                costResource.setValue(BigDecimal.ZERO);
                unitAndcostResourceMonthlyList.add(costResource);
            }
            for (int i = 0; i < unitAndcostResourceMonthlyList.size(); i++) {
                for (int j = 0; j < unitAndCostResourceList.size(); j++) {
                    if (unitAndcostResourceMonthlyList.get(i).getMonthNumber().equalsIgnoreCase(unitAndCostResourceList.get(j).getMonthNumber())) {
                        unitAndcostResourceMonthlyList.set(i, unitAndCostResourceList.get(j));
                        break;
                    }
                }
            }
        }
        return unitAndcostResourceMonthlyList;
    }

    private Tuple2<BigDecimal, BigDecimal> getUnitCostOverAllTotal(String subWorkStreamId, String subWorkStreamName, String vendorName, String scenario, String currencyCode) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        List<SubWorkstreamSoftwareCost> subWorkStreamNameAndScenario =
                subWorkstreamSoftwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndVendorNameAndActiveIndAndOriginalIndAndGlCategoryNotIn(
                        subWorkStreamId, subWorkStreamName, scenario, vendorName, PortfolioConstants.TRUE, PortfolioConstants.FALSE, glCategories);
        BigDecimal costOverAllTotal = BigDecimal.ZERO;
        BigDecimal unitOverAllTotal = BigDecimal.ZERO;
        for (SubWorkstreamSoftwareCost subWorkStreamSoftwareCost : subWorkStreamNameAndScenario) {
            //costOverAllTotal = costOverAllTotal.add(subWorkStreamSoftwareCost.getLocalCcyVal());
            costOverAllTotal = costOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    subWorkStreamSoftwareCost.getCostPerMonthGcy() : subWorkStreamSoftwareCost.getCostPerMonthLcy());
            unitOverAllTotal = unitOverAllTotal.add(subWorkStreamSoftwareCost.getQuantity());
        }
        return new Tuple2<>(costOverAllTotal, unitOverAllTotal);
    }


    private CostSettingsView getCostSettingsByQuarterlyForFinancial(List<String> costTypes, String subWorkStreamId,
                                                                    String subWorkStreamName,
                                                                    String costSettingValue, String scenario, String currencyCode) {
        CostSettingsView costSettingsView = new CostSettingsView();
        costSettingsView.setName(costSettingValue);
        //level 0
        Map<String, List<BigDecimal>> costSettingQuarterlyMap = getCostSettingQuarterlyMap(subWorkStreamId, subWorkStreamName, scenario, currencyCode);
        costSettingsView.setQuarterlyCostSettings(costSettingQuarterlyMap);
        Map<String, BigDecimal> individualYearTotal = new TreeMap<>();
        BigDecimal overAllTotal = BigDecimal.ZERO;
        for (Map.Entry<String, List<BigDecimal>> entry : costSettingQuarterlyMap.entrySet()) {
            String year = entry.getKey();
            List<BigDecimal> bigDecimals = entry.getValue();
            individualYearTotal.put(year, bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
            overAllTotal = overAllTotal.add(bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        }
        costSettingsView.setIndividualYearSummaryForQuarterly(individualYearTotal);
        costSettingsView.setCostSettingsOverAllTotal(overAllTotal);
        List<CostTypeCategoryView> costTypeCategoryViewList = new ArrayList<>();

        costTypes.forEach(costType -> {
            CostTypeCategoryView costTypeCategoryView = getCostTypeForFinancialByQuarterly(costType,
                    subWorkStreamId, subWorkStreamName, scenario, currencyCode);
            costTypeCategoryViewList.add(costTypeCategoryView);
            costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);
        });
        return costSettingsView;
    }

    private Map<String, List<BigDecimal>> getCostSettingQuarterlyMap(String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode) {
        Map<String, List<BigDecimal>> listMap = new TreeMap<>();
        //level 0
        List<String> ofPeriodFromFinancialTables = subWorkstreamOtherCostRepo.getDistinctOfPeriodFromFinancialTables(subWorkStreamId, subWorkStreamName, scenario);
        ofPeriodFromFinancialTables.forEach(year -> {
            List<FinancialSummaryResource> consolidatedFinancialSummary = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, year, scenario)
                    : portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, year, scenario);
            BigDecimal firstQuarter = BigDecimal.ZERO;
            BigDecimal secondQuarter = BigDecimal.ZERO;
            BigDecimal thirdQuarter = BigDecimal.ZERO;
            BigDecimal fourthQuarter = BigDecimal.ZERO;
            for (FinancialSummaryResource financialSummaryResource : consolidatedFinancialSummary) {
                String reportingMonth = financialSummaryResource.getPeriod().substring(4, 6);
                if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                    if (financialSummaryResource.getCurrencyValue() != null && financialSummaryResource.
                            getCurrencyValue().intValue() != 0) {
                        firstQuarter = firstQuarter.add(financialSummaryResource.getCurrencyValue());
                    }
                }
                if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                    if (financialSummaryResource.getCurrencyValue() != null && financialSummaryResource.
                            getCurrencyValue().intValue() != 0) {
                        secondQuarter = secondQuarter.add(financialSummaryResource.getCurrencyValue());
                    }
                }
                if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                    if (financialSummaryResource.getCurrencyValue() != null && financialSummaryResource.
                            getCurrencyValue().intValue() != 0) {
                        thirdQuarter = thirdQuarter.add(financialSummaryResource.getCurrencyValue());
                    }
                }
                if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                    if (financialSummaryResource.getCurrencyValue() != null && financialSummaryResource.
                            getCurrencyValue().intValue() != 0) {
                        fourthQuarter = fourthQuarter.add(financialSummaryResource.getCurrencyValue());
                    }
                }
            }
            listMap.put(year, Arrays.asList(firstQuarter, secondQuarter, thirdQuarter, fourthQuarter));
        });
        return listMap;
    }

    private CostTypeCategoryView getCostTypeForFinancialByQuarterly(String costType, String subWorkStreamId,
                                                                    String subWorkStreamName, String scenario, String currencyCode) {

        CostTypeCategoryView costTypeCategoryView = new CostTypeCategoryView();

        switch (costType) {
            case PortfolioConstants.SOFTWARE_TYPE:
                Map<String, BigDecimal> individualQuarterlySum = new TreeMap<>();
                BigDecimal totalOverAllSum = BigDecimal.ZERO;
                //level 2
                Map<String, List<UnitCostMappingView>> quarterlyUnitCostMapByYear = getSoftwareUnitCostMapQuarterly(subWorkStreamId, subWorkStreamName, scenario, currencyCode);
                //level 1
                Map<String, List<BigDecimal>> softwareQuarterlyListMap = getSoftwareQuarterlyListMap(subWorkStreamId, subWorkStreamName, scenario, currencyCode,costType);
                for (Map.Entry<String, List<BigDecimal>> entry : softwareQuarterlyListMap.entrySet()) {
                    String year = entry.getKey();
                    List<BigDecimal> bigDecimals = entry.getValue();
                    individualQuarterlySum.put(year, bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                    totalOverAllSum = totalOverAllSum.add(bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                }
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setQuarterlyUnitCostList(quarterlyUnitCostMapByYear);
                costTypeCategoryView.setIndividualYearSummaryForQuarterly(individualQuarterlySum);
                costTypeCategoryView.setCostTypeOverAllTotal(totalOverAllSum);
                costTypeCategoryView.setQuarterlyCostType(softwareQuarterlyListMap);
                break;
            case PortfolioConstants.HARDWARE_TYPE:
                Map<String, BigDecimal> individualQuarterlySumForHardware = new TreeMap<>();
                BigDecimal totalOverAllSumForHardware = BigDecimal.ZERO;
                Map<String, List<UnitCostMappingView>> hardwareUnitCostMapQuarterly = breakDownCostHardwareService.getHardwareUnitCostMapQuarterly(subWorkStreamId,
                        subWorkStreamName, scenario, currencyCode);
                Map<String, List<BigDecimal>> hardwareQuarterlyListMap = breakDownCostHardwareService.getHardwareQuarterlyListMap(subWorkStreamId,
                        subWorkStreamName, scenario, currencyCode,costType);

                for (Map.Entry<String, List<BigDecimal>> entry : hardwareQuarterlyListMap.entrySet()) {
                    String year = entry.getKey();
                    List<BigDecimal> bigDecimals = entry.getValue();
                    individualQuarterlySumForHardware.put(year, bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                    totalOverAllSumForHardware = totalOverAllSumForHardware.add(bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                }
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setQuarterlyUnitCostList(hardwareUnitCostMapQuarterly);
                costTypeCategoryView.setIndividualYearSummaryForQuarterly(individualQuarterlySumForHardware);
                costTypeCategoryView.setCostTypeOverAllTotal(totalOverAllSumForHardware);
                costTypeCategoryView.setQuarterlyCostType(hardwareQuarterlyListMap);
                break;
            case PortfolioConstants.OTHERS_TYPE:
                Map<String, BigDecimal> individualQuarterlySumForOthers = new TreeMap<>();
                BigDecimal totalOverAllSumForOthers = BigDecimal.ZERO;
                Map<String, List<UnitCostMappingView>> othersByQuarterly = breakDownCostOthersService.getOthersByQuarterlyTotalSum(subWorkStreamId, subWorkStreamName, scenario, currencyCode);

                Map<String, List<BigDecimal>> othersQuarterlyListMap = breakDownCostOthersService.getOthersHeaderDataByQuarterly(subWorkStreamId, subWorkStreamName, scenario, currencyCode);
                for (Map.Entry<String, List<BigDecimal>> entry : othersQuarterlyListMap.entrySet()) {
                    String year = entry.getKey();
                    List<BigDecimal> bigDecimals = entry.getValue();
                    individualQuarterlySumForOthers.put(year, bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                    totalOverAllSumForOthers = totalOverAllSumForOthers.add(bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                }
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setQuarterlyUnitCostList(othersByQuarterly);
                costTypeCategoryView.setQuarterlyCostType(othersQuarterlyListMap);
                costTypeCategoryView.setIndividualYearSummaryForQuarterly(individualQuarterlySumForOthers);
                costTypeCategoryView.setCostTypeOverAllTotal(totalOverAllSumForOthers);
                break;
            case PortfolioConstants.RESOURCE_TYPE:
                costTypeCategoryView.setName(costType);
                Map<String, List<UnitCostMappingView>> quarterlyUnitCostMapByYearResource = breakDownCostResourceService.getResourceUnitCostMapQuarterly(subWorkStreamId, subWorkStreamName, scenario, currencyCode);
                breakDownCostResourceService.getResourceQuarterlyListMap(subWorkStreamId, subWorkStreamName, scenario, currencyCode,costTypeCategoryView);
                //costTypeCategoryView.setName(costType);
                costTypeCategoryView.setQuarterlyUnitCostList(quarterlyUnitCostMapByYearResource);
//                costTypeCategoryView.setIndividualYearSummaryForQuarterly(individualQuarterlySum);
//                costTypeCategoryView.setCostTypeOverAllTotal(totalOverAllSum);
//                costTypeCategoryView.setQuarterlyCostType(softwareQuarterlyListMap);
                break;

            default:
                throw new IllegalArgumentException("Unexpected Cost Type: " + costType.toUpperCase());
        }
        return costTypeCategoryView;
    }

    private Map<String, List<BigDecimal>> getSoftwareQuarterlyListMap(String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode,String costType) {
        Map<String, List<BigDecimal>> quarterlySum = new TreeMap<>();
        List<FinancialSummaryResource> distinctOfPeriods = portfolioRepository.getSubworkstreamCostTypeOverAllTotalByGroupCurrency(subWorkStreamId, subWorkStreamName, scenario,
                "getDistinctfinancialSoftwareCostTypeOverAllTotal",PortfolioConstants.SOFTWARE_TYPE);
        List<BigDecimal> quarterlySummaryList;
        for (FinancialSummaryResource financialSummaryResource : distinctOfPeriods) {
            List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName,
                            financialSummaryResource.getPeriod(), scenario,"financialSoftwareHeaderSummaryByPeriodAndGroupCcy",costType)
                            : portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, financialSummaryResource.getPeriod(),scenario,
                            "financialSoftwareHeaderSummaryByPeriodAndLocalCcy",costType);

            quarterlySummaryList = getQuarterlySummaryList(consolidatedFinancialSummary, financialSummaryResource.getPeriod(), subWorkStreamId, subWorkStreamName, scenario, currencyCode);
            quarterlySum.put(financialSummaryResource.getPeriod(), quarterlySummaryList);
        }
        return quarterlySum;
    }

    private List<BigDecimal> getQuarterlySummaryList(List<FinancialSummaryResource> consolidatedFinancialSummary, String year,
                                                     String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode) {

        BigDecimal firstQuarter = BigDecimal.ZERO;
        BigDecimal secondQuarter = BigDecimal.ZERO;
        BigDecimal thirdQuarter = BigDecimal.ZERO;
        BigDecimal fourthQuarter = BigDecimal.ZERO;

        for (FinancialSummaryResource financialSummaryResource : consolidatedFinancialSummary) {
            String reportingYear = financialSummaryResource.getPeriod().substring(0, 4);
            if (year.equalsIgnoreCase(reportingYear)) {
                String reportingMonth = financialSummaryResource.getPeriod().substring(4, 6);
                if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                    firstQuarter = getCurrencyValueForQuarterly(currencyCode, firstQuarter, financialSummaryResource.getCurrencyValue());
                }
                if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                    secondQuarter = getCurrencyValueForQuarterly(currencyCode, secondQuarter, financialSummaryResource.getCurrencyValue());
                }
                if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                    thirdQuarter = getCurrencyValueForQuarterly(currencyCode, thirdQuarter, financialSummaryResource.getCurrencyValue());
                }
                if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                    fourthQuarter = getCurrencyValueForQuarterly(currencyCode, fourthQuarter, financialSummaryResource.getCurrencyValue());
                }
            }
        }
        List<BigDecimal> othersByQuarterlyTotalSum = breakDownCostOthersService.getOthersByQuarterlyTotalSum(subWorkStreamId,
                subWorkStreamName, scenario, PortfolioConstants.SOFTWARE_TYPE, year, currencyCode);

        return Arrays.asList(firstQuarter.add(othersByQuarterlyTotalSum.get(0)), secondQuarter.add(othersByQuarterlyTotalSum.get(1)),
                thirdQuarter.add(othersByQuarterlyTotalSum.get(2)), fourthQuarter.add(othersByQuarterlyTotalSum.get(3)));
    }


    private BigDecimal getCurrencyValueForQuarterly(String currencyCode, BigDecimal firstQuarter, BigDecimal ccyValue) {
        if (ccyValue != null && ccyValue.intValue() != 0) {
            firstQuarter = firstQuarter.add(ccyValue);
        }
        return firstQuarter;
    }

    private BigDecimal getCurrencyValueForQuarter(String currencyCode, BigDecimal firstQuarter, BigDecimal GroupCcyValue, BigDecimal LocalCcyValue) {
        if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) && GroupCcyValue != null && GroupCcyValue.intValue() != 0) {
            firstQuarter = firstQuarter.add(GroupCcyValue);
        } else {
            if (LocalCcyValue != null && LocalCcyValue.intValue() != 0) {
                firstQuarter = firstQuarter.add(LocalCcyValue);
            }
        }
        return firstQuarter;
    }

    private List<SubWorkstreamSoftwareCost> getBySubWorkStreamOthersList(String subWorkStreamId, String subWorkStreamName, String year, String scenario) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        return subWorkstreamSoftwareCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotInAndPeriodContaining(
                        subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, PortfolioConstants.FALSE,glCategories, year);
    }

    private Map<String, List<UnitCostMappingView>> getSoftwareUnitCostMapQuarterly(String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        Map<String, List<UnitCostMappingView>> quarterlyUnitCostMapByPeriod = new TreeMap<>();
        List<String> listOfSoftwareYears = subWorkstreamSoftwareCostRepo.findDistinctOfPeriodsFromSoftwareCostAndOtherSoftwareCost(subWorkStreamId, subWorkStreamName, scenario, glCategories);
        for (String year : listOfSoftwareYears) {
            Map<String, Map<String, List<SubWorkstreamSoftwareCost>>> vendorPeriodMap = getVendorNamePeriodAndSoftwareCostList(subWorkStreamId, subWorkStreamName, year, scenario);
            List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
            vendorPeriodMap.forEach((vendorName, softwareNameListMap) -> softwareNameListMap.forEach((softwareName, subWorkStreamSoftwareCostList) -> {
                UnitCostMappingView unitCostMappingView = getUnitCostMappingResourceByQuarterly(subWorkStreamSoftwareCostList, subWorkStreamId, subWorkStreamName, scenario, currencyCode);
                unitCostMappingView.setName(vendorName + " - " + softwareName);
                //TODO set currencytype, currencyvalue
                unitCostMappingView.setRefSurrId(subWorkStreamSoftwareCostList.get(0).getCapexOpexSurrId());
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
                unitCostMappingViewArrayList.add(unitCostMappingView);
            }));
            unitCostMappingViewArrayList.addAll(breakDownCostOthersService.getOtherSoftwareByQuarterly(subWorkStreamId, subWorkStreamName, year, scenario, currencyCode));
            quarterlyUnitCostMapByPeriod.put(year, unitCostMappingViewArrayList);
        }
        return quarterlyUnitCostMapByPeriod;
    }

    private UnitCostMappingView getUnitCostMappingResourceByQuarterly(List<SubWorkstreamSoftwareCost> subWorkStreamSoftwareCostList, String subWorkStreamId,
                                                                      String subWorkStreamName, String scenario, String currencyCode) {

        BigDecimal firstQuarterUnitTotal = BigDecimal.ZERO;
        BigDecimal secondQuarterUnitTotal = BigDecimal.ZERO;
        BigDecimal thirdQuarterUnitTotal = BigDecimal.ZERO;
        BigDecimal fourthQuarterUnitTotal = BigDecimal.ZERO;

        BigDecimal firstQuarterCostTotal = BigDecimal.ZERO;
        BigDecimal secondQuarterCostTotal = BigDecimal.ZERO;
        BigDecimal thirdQuarterCostTotal = BigDecimal.ZERO;
        BigDecimal fourthQuarterCostTotal = BigDecimal.ZERO;

        UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
        unitCostMappingView.setPeriodType(PortfolioConstants.QUARTERLY);
        for (SubWorkstreamSoftwareCost softwareCost : subWorkStreamSoftwareCostList) {
            String reportingMonth = softwareCost.getPeriod().substring(4, 6);
            if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                Tuple2<BigDecimal, BigDecimal> costUnitTotal = getCostUnitTotalForGivenReportingMonth(softwareCost, currencyCode);
                firstQuarterCostTotal = firstQuarterCostTotal.add(costUnitTotal._1);
                firstQuarterUnitTotal = firstQuarterUnitTotal.add(costUnitTotal._2);
            } else if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                Tuple2<BigDecimal, BigDecimal> costUnitTotal = getCostUnitTotalForGivenReportingMonth(softwareCost, currencyCode);
                secondQuarterCostTotal = secondQuarterCostTotal.add(costUnitTotal._1);
                secondQuarterUnitTotal = secondQuarterUnitTotal.add(costUnitTotal._2);
            } else if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                Tuple2<BigDecimal, BigDecimal> costUnitTotal = getCostUnitTotalForGivenReportingMonth(softwareCost, currencyCode);
                thirdQuarterCostTotal = thirdQuarterCostTotal.add(costUnitTotal._1);
                thirdQuarterUnitTotal = thirdQuarterUnitTotal.add(costUnitTotal._2);
            } else if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                Tuple2<BigDecimal, BigDecimal> costUnitTotal = getCostUnitTotalForGivenReportingMonth(softwareCost, currencyCode);
                fourthQuarterCostTotal = fourthQuarterCostTotal.add(costUnitTotal._1);
                fourthQuarterUnitTotal = fourthQuarterUnitTotal.add(costUnitTotal._2);
            }
        }
        unitCostMappingView.setQuarterlyCostTotal(Arrays.asList(firstQuarterCostTotal, secondQuarterCostTotal, thirdQuarterCostTotal, fourthQuarterCostTotal));
        unitCostMappingView.setQuarterlyUnitTotal(Arrays.asList(firstQuarterUnitTotal, secondQuarterUnitTotal, thirdQuarterUnitTotal, fourthQuarterUnitTotal));
        Tuple2<BigDecimal, BigDecimal> costTypeOverAllTotal = getCostTypeOverAllTotal(subWorkStreamId, subWorkStreamName, scenario, currencyCode);
        unitCostMappingView.setYearlyCostOverAllTotal(costTypeOverAllTotal._1);
        unitCostMappingView.setYearlyUnitOverAllTotal(costTypeOverAllTotal._2);

        return unitCostMappingView;
    }

    private Tuple2<BigDecimal, BigDecimal> getCostUnitTotalForGivenReportingMonth(SubWorkstreamSoftwareCost softwareCost, String currencyCode) {
        BigDecimal quarterTotalCost = new BigDecimal(BigInteger.ZERO);
        BigDecimal quarterTotalUnit = new BigDecimal(BigInteger.ZERO);
        quarterTotalUnit = quarterTotalUnit.add(softwareCost.getQuantity());
        quarterTotalCost = quarterTotalCost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                softwareCost.getCostPerMonthGcy() : softwareCost.getCostPerMonthLcy());
        return new Tuple2<>(quarterTotalCost, quarterTotalUnit);
    }

    //yearly start

    private CostSettingsView getCostSettingsByYearlyForFinancial(List<String> costTypes, String subWorkStreamId,
                                                                 String subWorkStreamName, String costSettingValue, String scenario, String currencyCode) {


        CostSettingsView costSettingsView = new CostSettingsView();
        costSettingsView.setName(costSettingValue);
        Map<String, BigDecimal> yearMap = new TreeMap<>();
        BigDecimal allYearsTotal = BigDecimal.ZERO;
        List<String> distinctOfPeriodFromFinancialTables = subWorkstreamOtherCostRepo.getDistinctOfPeriodFromFinancialTables(
                subWorkStreamId, subWorkStreamName, scenario);
        for (String year : distinctOfPeriodFromFinancialTables) {
            List<FinancialSummaryResource> consolidatedFinancialSummaryByPeriod = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, year, scenario)
                    : portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, year, scenario);
            BigDecimal totalSumValue = BigDecimal.ZERO;
            for (FinancialSummaryResource financialSummaryResource : consolidatedFinancialSummaryByPeriod) {
                totalSumValue = totalSumValue.add(financialSummaryResource.getCurrencyValue());
            }
            yearMap.put(year, totalSumValue);
            allYearsTotal = allYearsTotal.add(totalSumValue);
        }
        costSettingsView.setYearlyCostSettings(yearMap);
        costSettingsView.setCostSettingsOverAllTotal(allYearsTotal);
        List<CostTypeCategoryView> costTypeCategoryViewList = new ArrayList<>();

        costTypes.forEach(costType -> {
            CostTypeCategoryView costTypeCategoryView = getCostTypeForFinancialByYearly(costType,
                    subWorkStreamId, subWorkStreamName, scenario, currencyCode);
            costTypeCategoryViewList.add(costTypeCategoryView);
            costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);
        });
        return costSettingsView;
    }

    private CostTypeCategoryView getCostTypeForFinancialByYearly(String costType, String subWorkStreamId,
                                                                 String subWorkStreamName, String scenario, String currencyCode) {

        CostTypeCategoryView costTypeCategoryView = new CostTypeCategoryView();
        switch (costType) {
            case PortfolioConstants.SOFTWARE_TYPE:
                Map<String, List<UnitCostMappingView>> yearlySoftwareData = getYearlySoftwareData(subWorkStreamId, subWorkStreamName, scenario, currencyCode);
                Map<String, BigDecimal> totalYearSumMap = getYearlySoftwareSummary(subWorkStreamId, subWorkStreamName, scenario, currencyCode,costType);
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setYearlyCostType(totalYearSumMap);
                BigDecimal bigDecimal = BigDecimal.ZERO;
                for (Map.Entry<String, BigDecimal> totalValue : totalYearSumMap.entrySet()) {
                    bigDecimal = bigDecimal.add(totalValue.getValue());
                }
                costTypeCategoryView.setYearlyUnitCostList(yearlySoftwareData);
                costTypeCategoryView.setCostTypeOverAllTotal(bigDecimal);
                break;
            case PortfolioConstants.HARDWARE_TYPE:
                Map<String, List<UnitCostMappingView>> yearlyHardwareData = breakDownCostHardwareService.getYearlyHardwareData(subWorkStreamId, subWorkStreamName,
                        scenario, currencyCode);
                Map<String, BigDecimal> totalHardwareSumMap = breakDownCostHardwareService.getYearlyHardwareSummary(subWorkStreamId, subWorkStreamName, scenario, currencyCode,costType);
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setYearlyCostType(totalHardwareSumMap);
                costTypeCategoryView.setYearlyUnitCostList(yearlyHardwareData);
                BigDecimal totalSum = BigDecimal.ZERO;
                for (Map.Entry<String, BigDecimal> totalValue : totalHardwareSumMap.entrySet()) {
                    totalSum = totalSum.add(totalValue.getValue());
                }
                costTypeCategoryView.setCostTypeOverAllTotal(totalSum);
                break;
            case PortfolioConstants.OTHERS_TYPE:
                Map<String, List<UnitCostMappingView>> yearlyOthersData = breakDownCostOthersService.getYearlyOthersData(subWorkStreamId, subWorkStreamName, scenario, currencyCode);
                Map<String, BigDecimal> yearlySummaryData = breakDownCostOthersService.getYearlySummaryData(subWorkStreamId, subWorkStreamName, scenario, currencyCode);
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setYearlyUnitCostList(yearlyOthersData);
                costTypeCategoryView.setYearlyCostType(yearlySummaryData);
                BigDecimal overAllSum = BigDecimal.ZERO;
                for (Map.Entry<String, BigDecimal> totalValue : yearlySummaryData.entrySet()) {
                    overAllSum = overAllSum.add(totalValue.getValue());
                }
                costTypeCategoryView.setCostTypeOverAllTotal(overAllSum);
                break;
            case PortfolioConstants.RESOURCE_TYPE:
                breakDownCostResourceService.getYearlyResourceSummary(subWorkStreamId, subWorkStreamName, scenario, currencyCode,costTypeCategoryView);
                costTypeCategoryView.setName(costType);
                Map<String, List<UnitCostMappingView>> yearlyResourceData = breakDownCostResourceService.getYearlyResourceData(subWorkStreamId, subWorkStreamName, scenario, currencyCode);
                costTypeCategoryView.setYearlyUnitCostList(yearlyResourceData);
                break;

            default:
                throw new IllegalStateException("Unexpected Cost Type: " + costType.toUpperCase());
        }
        return costTypeCategoryView;
    }

    private Map<String, List<UnitCostMappingView>> getYearlySoftwareData(String subWorkStreamId,
                                                                         String subWorkStreamName, String scenario, String currencyCode) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        Map<String, List<UnitCostMappingView>> yearlyCostUnitResource = new TreeMap<>();
        List<String> listOfYears = subWorkstreamSoftwareCostRepo.findDistinctOfPeriodsFromSoftwareCost(subWorkStreamId, subWorkStreamName, scenario);
        for (String year : listOfYears) {
            Map<String, Map<String, List<SubWorkstreamSoftwareCost>>> vendorAndSoftwareMap = getVendorNamePeriodAndSoftwareCostList(subWorkStreamId, subWorkStreamName, year, scenario);
            List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
            vendorAndSoftwareMap.forEach((vendorName, softwareNameMap) -> softwareNameMap.forEach((softwareName, subWorkStreamSoftwareCostList) -> {
                UnitCostMappingView unitCostMappingView = getUnitCostMappingResourceByYearly(subWorkStreamSoftwareCostList, currencyCode);
                unitCostMappingView.setName(vendorName + " - " + softwareName);
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setYearlyCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        subWorkstreamSoftwareCostRepo.getTotalSoftwareCostByTypeAndGrpCcy(subWorkStreamId, subWorkStreamName, scenario, vendorName, glCategories)
                        : subWorkstreamSoftwareCostRepo.getTotalSoftwareCostByTypeAndLocalCcy(subWorkStreamId, subWorkStreamName, scenario, vendorName, glCategories));
                unitCostMappingViewArrayList.add(unitCostMappingView);
            }));
            unitCostMappingViewArrayList.addAll(breakDownCostOthersService.getOthersSoftwareByYearly(subWorkStreamId, subWorkStreamName, year, scenario, currencyCode));
            yearlyCostUnitResource.put(year, unitCostMappingViewArrayList);
        }
        return yearlyCostUnitResource;
    }

    private UnitCostMappingView getUnitCostMappingResourceByYearly(List<SubWorkstreamSoftwareCost> softwarePeriodList, String currencyCode) {

        BigDecimal unitTotal = BigDecimal.ZERO;
        BigDecimal costTotal = BigDecimal.ZERO;
        UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
        unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
        for (SubWorkstreamSoftwareCost subWorkStreamSoftwareCost : softwarePeriodList) {
            unitTotal = unitTotal.add(subWorkStreamSoftwareCost.getQuantity());
            costTotal = costTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    subWorkStreamSoftwareCost.getCostPerMonthGcy() : subWorkStreamSoftwareCost.getCostPerMonthLcy());

        }
        unitCostMappingView.setRefSurrId(softwarePeriodList.get(0).getCapexOpexSurrId());
        unitCostMappingView.addYearlyUnitTotal(unitTotal);
        unitCostMappingView.addYearlyCostTotal(costTotal);
        return unitCostMappingView;
    }

    private Map<String, BigDecimal> getYearlySoftwareSummary(String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode,String costType) {
        Map<String, BigDecimal> totalYearSumMap = new TreeMap<>();
        List<FinancialSummaryResource> listOfYears = portfolioRepository.getSubworkstreamCostTypeOverAllTotalByGroupCurrency(subWorkStreamId, subWorkStreamName, scenario,
                "getDistinctfinancialSoftwareCostTypeOverAllTotal",PortfolioConstants.SOFTWARE_TYPE);
        for (FinancialSummaryResource financialSummaryResource : listOfYears) {
            BigDecimal totalYearSum = BigDecimal.ZERO;
            List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, financialSummaryResource.getPeriod(),
                                    scenario,"financialSoftwareHeaderSummaryByPeriodAndGroupCcy",costType)
                            : portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName,
                            financialSummaryResource.getPeriod(), scenario,"financialSoftwareHeaderSummaryByPeriodAndLocalCcy",costType);

            for (FinancialSummaryResource subWorkStreamSoftwareCost : consolidatedFinancialSummary) {
                totalYearSum = totalYearSum.add(subWorkStreamSoftwareCost.getCurrencyValue());
            }
            BigDecimal softwareYearlySum = breakDownCostOthersService.getOthersByYearlySum(subWorkStreamId, subWorkStreamName, scenario, financialSummaryResource.getPeriod(), PortfolioConstants.SOFTWARE_TYPE, currencyCode);
            totalYearSum = totalYearSum.add(softwareYearlySum);
            totalYearSumMap.put(financialSummaryResource.getPeriod(), totalYearSum);
        }
        return totalYearSumMap;
    }


}
