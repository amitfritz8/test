package com.dbs.genesis.portfolio.resources;

import com.dbs.genesis.portfolio.model.SubWorkStreamApprovers;
import com.dbs.genesis.portfolio.model.SubWorkStreamKeyDatesEntity;
import com.dbs.genesis.portfolio.model.WorkStreamApprovers;
import com.dbs.genesis.portfolio.model.WorkStreamKeyDatesEntity;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class CopyScenarioKeyDatesApproveDataHolder {
    List<WorkStreamKeyDatesEntity> workStreamKeyDatesEntities = new ArrayList<>();
    List<SubWorkStreamKeyDatesEntity> subWorkStreamKeyDatesEntities = new ArrayList<>();
    List<WorkStreamApprovers> workStreamApprovers = new ArrayList<>();
    List<SubWorkStreamApprovers> subWorkStreamApprovers = new ArrayList<>();

}
