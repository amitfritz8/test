package com.dbs.genesis.portfolio.resources;

import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class SubWorkStreamSoftwareCostHolder {
    SubWorkstreamSoftwareCost subWorkstreamSoftwareCost;
    List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCosts = new ArrayList<>();

}
