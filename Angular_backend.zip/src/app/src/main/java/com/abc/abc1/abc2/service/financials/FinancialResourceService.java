package com.dbs.genesis.portfolio.service.financials;

import com.amazonaws.util.CollectionUtils;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.DataValues;
import com.dbs.genesis.portfolio.model.SubWorkStreamResourceCost;
import com.dbs.genesis.portfolio.repository.EmployeeRateCardRepo;
import com.dbs.genesis.portfolio.repository.SubWorkStreamResourceCostRepo;
import com.dbs.genesis.portfolio.resources.MonthlyCostTypeData;
import com.dbs.genesis.portfolio.resources.MonthlyFinancialDetailsResource;
import com.dbs.genesis.portfolio.resources.MonthlyFinancialResource;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import com.dbs.genesis.portfolio.service.costsettings.FinancialDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class FinancialResourceService {

    private final SubWorkStreamResourceCostRepo subWorkStreamResourceCostRepo;
    private final FinancialDetailsService financialDetailsService;
    private final FinancialOthersService financialOthersService;
    private DataSummaryService dataSummaryService;
    private FinancialService financialService;
    @Autowired
    EmployeeRateCardRepo employeeRateCardRepo;

    public FinancialResourceService(SubWorkStreamResourceCostRepo subWorkStreamResourceCostRepo,
                                    FinancialDetailsService financialDetailsService, FinancialOthersService financialOthersService,
                                    DataSummaryService dataSummaryService, FinancialService financialService) {
        this.subWorkStreamResourceCostRepo = subWorkStreamResourceCostRepo;
        this.financialDetailsService = financialDetailsService;
        this.financialOthersService = financialOthersService;
        this.dataSummaryService = dataSummaryService;
        this.financialService = financialService;
    }
    public void persistResource(MonthlyFinancialResource monthlyFinancialResource, MonthlyFinancialDetailsResource financialDetail, String year) {
         financialDetail.getMonthlyCostTypeDataList().stream().forEach(monthlyResource -> {
            if(monthlyResource.getName().startsWith(PortfolioConstants.OTHER_RESOURCE)){
                 financialOthersService.persistOthersIndividual(monthlyFinancialResource, monthlyResource, year);
            }else{
                SubWorkStreamResourceCost subWorkStreamResourceCost = subWorkStreamResourceCostRepo.findById(monthlyResource.getSurrId()).get();
                List<SubWorkStreamResourceCost> subWorkStreamResourceCosts = getResourceEntity(subWorkStreamResourceCost,monthlyFinancialResource, monthlyResource, year);
                subWorkStreamResourceCostRepo.saveAll(subWorkStreamResourceCosts);
                    List<SubWorkStreamResourceCost> subWorkstreamSoftwareCostOwnerships = createSubWorkStreamResourceCostsOwnershipForMonthly(
                            subWorkStreamResourceCosts,monthlyFinancialResource.getSubWorkStreamId(),
                            monthlyFinancialResource.getSubWorkStreamName(),monthlyFinancialResource.getScenario(),subWorkStreamResourceCost);
                    subWorkStreamResourceCostRepo.saveAll(subWorkstreamSoftwareCostOwnerships);

            }
        });
    }

    private List<SubWorkStreamResourceCost> getResourceEntity(SubWorkStreamResourceCost subWorkStreamResourceCost, MonthlyFinancialResource monthlyFinancialResource, MonthlyCostTypeData monthlyResource, String year) {

        List<SubWorkStreamResourceCost> subWorkStreamResourceCosts = monthlyResource.getFteAllocData().stream().map(monthlyFteData -> {
            if (monthlyFteData.getSurrId() == null || monthlyFteData.getSurrId().equals(BigDecimal.ZERO)) {
                SubWorkStreamResourceCost newSubWorkStreamResourceCost = getNewResourceMonthlyData(subWorkStreamResourceCost, monthlyFinancialResource.getScenario()
                        , PortfolioConstants.ORIGINAL_INDICATOR_FALSE, monthlyFteData.getMonthNumber(), year);
                updateCurrencyValuesForResource(newSubWorkStreamResourceCost, monthlyFinancialResource.getCurrencyCode(), subWorkStreamResourceCost.getFte(), subWorkStreamResourceCost.getAllocationPercentage(), monthlyFinancialResource.getCurrencyCodes());
                return newSubWorkStreamResourceCost;
            } else {
                SubWorkStreamResourceCost existingSubWorkStreamResourceCost = subWorkStreamResourceCostRepo.findById(monthlyFteData.getSurrId()).get();
                updateCurrencyValuesForResource(existingSubWorkStreamResourceCost, monthlyFinancialResource.getCurrencyCode(), monthlyFteData.getFteValue(), monthlyFteData.getAllocationValue(),monthlyFinancialResource.getCurrencyCodes());
                return existingSubWorkStreamResourceCost;
            }

        }).collect(Collectors.toList());
        return subWorkStreamResourceCosts;
    }

    private SubWorkStreamResourceCost getNewResourceMonthlyData(SubWorkStreamResourceCost subWorkStreamResourceCost, String scenario,
                                                                String orgInd, String month, String year) {
        SubWorkStreamResourceCost newSubWorkStreamResourceCost = new SubWorkStreamResourceCost();
        newSubWorkStreamResourceCost.setWorkStreamId(subWorkStreamResourceCost.getWorkStreamId());
        newSubWorkStreamResourceCost.setSubWorkStreamId(subWorkStreamResourceCost.getSubWorkStreamId());
        newSubWorkStreamResourceCost.setSubWorkStreamName(subWorkStreamResourceCost.getSubWorkStreamName());
        newSubWorkStreamResourceCost.setGlCategory(subWorkStreamResourceCost.getGlCategory());
        newSubWorkStreamResourceCost.setCostSettings(subWorkStreamResourceCost.getCostSettings());
        newSubWorkStreamResourceCost.setFte(subWorkStreamResourceCost.getFte());
        newSubWorkStreamResourceCost.setRefSwsResourceSurrId(subWorkStreamResourceCost.getSwsResourceSurrId());
        newSubWorkStreamResourceCost.setAllocationPercentage(subWorkStreamResourceCost.getAllocationPercentage());
        newSubWorkStreamResourceCost.setActiveInd(subWorkStreamResourceCost.getActiveInd());
        newSubWorkStreamResourceCost.setScenario(scenario);
        newSubWorkStreamResourceCost.setOriginalInd(orgInd);
        newSubWorkStreamResourceCost.setPeriod(year + month);
        return newSubWorkStreamResourceCost;
    }

    public void updateCurrencyValuesForResource(SubWorkStreamResourceCost subWorkStreamResourceCost,
                                                String currencyCode,
                                                BigDecimal fte,BigDecimal allocationPercentage, HashSet<String> currencyCodes) {
        if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode))
            updateCurrencyValuesForGroupForResource(subWorkStreamResourceCost, currencyCode, fte,allocationPercentage, currencyCodes);
        else
            updateCurrencyValuesForLocalForResource(subWorkStreamResourceCost, currencyCode, fte,allocationPercentage, currencyCodes);
    }

    private SubWorkStreamResourceCost
    updateCurrencyValuesForLocalForResource(SubWorkStreamResourceCost subWorkStreamResourceCost,
                                            String currencyCode,
                                            BigDecimal fte,BigDecimal allocationPercentage,
                                            HashSet<String> currencyCodes) {
        subWorkStreamResourceCost.setLocalCcy(currencyCode);
        subWorkStreamResourceCost.setAllocationPercentage(allocationPercentage);
        BigDecimal blendedeCostPerDay = employeeRateCardRepo.getStaffRate(subWorkStreamResourceCost.getLocation(),
                subWorkStreamResourceCost.getLocalCcy(), subWorkStreamResourceCost.getStaffType(),
                subWorkStreamResourceCost.getVendor(), subWorkStreamResourceCost.getRateSource(), subWorkStreamResourceCost.getStaffLevel(),
                PortfolioConstants.RATE_INDICATOR_BLENDED);
       if(blendedeCostPerDay!=null){
           subWorkStreamResourceCost.setBlendedCostLocalCcy(fte.multiply(BigDecimal.valueOf(getFDManDaysPerMonth())).multiply(blendedeCostPerDay));
       }
        if (allocationPercentage != null) {
            subWorkStreamResourceCost.setAllocationPercentage(allocationPercentage);
        }

        if(fte != null) {
            subWorkStreamResourceCost.setFte(fte);
            currencyCodes.remove(currencyCode);
            if (!currencyCodes.isEmpty()) {
                if(blendedeCostPerDay != null) {
                    subWorkStreamResourceCost.setGroupCcy(currencyCodes.iterator().next());
                    subWorkStreamResourceCost.setBlendedCostGroupCcy(fte.multiply(financialDetailsService.getExchangeValue
                            (subWorkStreamResourceCost.getPeriod(), currencyCode, subWorkStreamResourceCost.getWorkStreamId())).multiply(BigDecimal.valueOf(getFDManDaysPerMonth())).multiply(blendedeCostPerDay));
                }
            }
            else {
                if(blendedeCostPerDay != null) {
                    subWorkStreamResourceCost.setGroupCcy(currencyCode);
                    subWorkStreamResourceCost.setBlendedCostGroupCcy(fte.multiply(BigDecimal.valueOf(getFDManDaysPerMonth())).multiply(blendedeCostPerDay));
                }
            }

        }
        return subWorkStreamResourceCost;
    }

    private SubWorkStreamResourceCost
    updateCurrencyValuesForGroupForResource(SubWorkStreamResourceCost subWorkStreamResourceCost,
                                            String loggedInCurrencyCode,
                                            BigDecimal fte,BigDecimal allocationPercentage,
                                            HashSet<String> currencyCodes) {
        BigDecimal blendedeCostPerDay = employeeRateCardRepo.getStaffRate(subWorkStreamResourceCost.getLocation(),
                subWorkStreamResourceCost.getLocalCcy(), subWorkStreamResourceCost.getStaffType(),
                subWorkStreamResourceCost.getVendor(), subWorkStreamResourceCost.getRateSource(), subWorkStreamResourceCost.getStaffLevel(),
                PortfolioConstants.RATE_INDICATOR_BLENDED);
        subWorkStreamResourceCost.setGroupCcy(loggedInCurrencyCode);
        if(blendedeCostPerDay!=null) {
            subWorkStreamResourceCost.setBlendedCostGroupCcy(fte.multiply(BigDecimal.valueOf(getFDManDaysPerMonth())).multiply(blendedeCostPerDay));
        }
        BigDecimal exchangedValue = financialDetailsService.getExchangeValue
                (subWorkStreamResourceCost.getPeriod(), subWorkStreamResourceCost.getLocalCcy(), subWorkStreamResourceCost.getWorkStreamId());
        if (allocationPercentage != null) {
            subWorkStreamResourceCost.setAllocationPercentage(allocationPercentage);
        }

        currencyCodes.remove(loggedInCurrencyCode);
        if(fte != null) {
            subWorkStreamResourceCost.setFte(fte);
            if (!currencyCodes.isEmpty()) {
                if (blendedeCostPerDay != null) {
                    subWorkStreamResourceCost.setLocalCcy(currencyCodes.iterator().next());
                    subWorkStreamResourceCost.setBlendedCostLocalCcy(fte.multiply(fte.divide(exchangedValue, 9, RoundingMode.HALF_UP)).multiply(BigDecimal.valueOf(getFDManDaysPerMonth())).multiply(blendedeCostPerDay));

                }
            }else {
                if(blendedeCostPerDay != null) {
                    subWorkStreamResourceCost.setLocalCcy(loggedInCurrencyCode);
                    subWorkStreamResourceCost.setBlendedCostLocalCcy(fte.multiply(BigDecimal.valueOf(getFDManDaysPerMonth())).multiply(blendedeCostPerDay));
                }
            }

        }
        return subWorkStreamResourceCost;
    }

    private Integer getFDManDaysPerMonth(){
        List<DataValues> dataValuesList = dataSummaryService.getDataValuesBySummary(PortfolioConstants.FD_MAN_DAYS_PER_MONTH);
        if(!CollectionUtils.isNullOrEmpty(dataValuesList)){
            return Integer.parseInt(dataValuesList.get(0).getValue());
        }
        return 0;
    }

    public List<SubWorkStreamResourceCost> createSubWorkStreamResourceCostsOwnershipForMonthly(List<SubWorkStreamResourceCost> subWorkStreamResourceCosts,
                                                                                               String subWorkstreamId, String subWorkstreamName, String scenario, SubWorkStreamResourceCost subWorkStreamResourceCost) {

        SubWorkStreamResourceCost subWorkstreamResourceCostOwnershipParent = subWorkStreamResourceCostRepo.findParentOwnership(subWorkStreamResourceCost.getSubWorkStreamId(),
                subWorkStreamResourceCost.getSubWorkStreamName(),subWorkStreamResourceCost.getResourceType(),subWorkStreamResourceCost.getScenario(),PortfolioConstants.OWNERSHIP,subWorkStreamResourceCost.getLocation(),
                subWorkStreamResourceCost.getStaffType(),subWorkStreamResourceCost.getVendor(),subWorkStreamResourceCost.getRateSource(),subWorkStreamResourceCost.getStaffLevel(),subWorkStreamResourceCost.getTeamRole());
        Date ownerShipDate = financialService.startingOwnershipPeriod(subWorkstreamId,subWorkstreamName,scenario);
        List<SubWorkStreamResourceCost> subWorkstreamResourceCostsToSave = new ArrayList<>();
        List<String> OwnerShipPeriods = new ArrayList<>();
        subWorkStreamResourceCosts.stream().filter(subWorkstreamResourceCost ->
                financialService.checkOwnershipDate(ownerShipDate,subWorkstreamResourceCost.getPeriod()) && PortfolioConstants.OPEX.equalsIgnoreCase(subWorkstreamResourceCost.getGlCategory()))
                .forEach(subWorkstreamResourceCost -> {
                    SubWorkStreamResourceCost subWorkstreamResourceCostOwnership = new SubWorkStreamResourceCost();
                    subWorkstreamResourceCostOwnership.setWorkStreamId(subWorkstreamResourceCost.getWorkStreamId());
                    subWorkstreamResourceCostOwnership.setSubWorkStreamId(subWorkstreamResourceCost.getSubWorkStreamId());
                    subWorkstreamResourceCostOwnership.setSubWorkStreamName(subWorkstreamResourceCost.getSubWorkStreamName());
                    subWorkstreamResourceCostOwnership.setActiveInd(PortfolioConstants.TRUE);
                    subWorkstreamResourceCostOwnership.setOriginalInd(PortfolioConstants.FALSE);
                    subWorkstreamResourceCostOwnership.setPeriod(subWorkstreamResourceCost.getPeriod());
                    subWorkstreamResourceCostOwnership.setBlendedCostLocalCcy(subWorkstreamResourceCost.getBlendedCostLocalCcy());
                    subWorkstreamResourceCostOwnership.setBlendedCostGroupCcy(subWorkstreamResourceCost.getBlendedCostGroupCcy());
                    subWorkstreamResourceCostOwnership.setGroupCcy(subWorkstreamResourceCost.getGroupCcy());
                    subWorkstreamResourceCostOwnership.setResourceType(subWorkstreamResourceCost.getResourceType());
                    subWorkstreamResourceCostOwnership.setTeamCode(subWorkstreamResourceCost.getTeamCode());
                    subWorkstreamResourceCostOwnership.setTeamRole(subWorkstreamResourceCost.getTeamRole());
                    subWorkstreamResourceCostOwnership.setVendor(subWorkstreamResourceCost.getVendor());
                    subWorkstreamResourceCostOwnership.setStaffType(subWorkstreamResourceCost.getStaffType());
                    subWorkstreamResourceCostOwnership.setStaffLevel(subWorkstreamResourceCost.getStaffLevel());
                    subWorkstreamResourceCostOwnership.setRateSource(subWorkstreamResourceCost.getRateSource());
                    subWorkstreamResourceCostOwnership.setLocation(subWorkstreamResourceCost.getLocation());
                    subWorkstreamResourceCostOwnership.setFte(subWorkstreamResourceCost.getFte());
                    subWorkstreamResourceCostOwnership.setAddResource(subWorkstreamResourceCost.getAddResource());
                    subWorkstreamResourceCostOwnership.setAllocationPercentage(subWorkstreamResourceCost.getAllocationPercentage());
                    subWorkstreamResourceCostOwnership.setTeamName(subWorkstreamResourceCost.getTeamName());
                    subWorkstreamResourceCostOwnership.setPlatformIndex(subWorkstreamResourceCost.getPlatformIndex());
                    subWorkstreamResourceCostOwnership.setCostSettings(subWorkstreamResourceCost.getCostSettings());
                    subWorkstreamResourceCostOwnership.setScenario(subWorkstreamResourceCost.getScenario());
                    subWorkstreamResourceCostOwnership.setRefSwsResourceSurrId(subWorkstreamResourceCostOwnershipParent.getSwsResourceSurrId());
                    subWorkstreamResourceCostOwnership.setCapexOpexSurrId(subWorkStreamResourceCost.getSwsResourceSurrId());
                    subWorkstreamResourceCostOwnership.setGlCategory(PortfolioConstants.OWNERSHIP);
                    subWorkstreamResourceCostsToSave.add(subWorkstreamResourceCostOwnership);
                    OwnerShipPeriods.add(subWorkstreamResourceCostOwnership.getPeriod());
                });
        deleteOwnerships(subWorkstreamId, subWorkstreamName, scenario,subWorkstreamResourceCostOwnershipParent.getSwsResourceSurrId(), OwnerShipPeriods);
        return subWorkstreamResourceCostsToSave;
    }

    public void deleteOwnerships(String subWorkstreamId, String subWorkstreamName, String scenario, Integer refSurrId, List<String> ownerShipPeriods) {
        List<SubWorkStreamResourceCost> subWorkstreamResourceCosts =subWorkStreamResourceCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndGlCategoryAndRefSwsResourceSurrIdAndPeriodInAndActiveIndAndOriginalInd(
                subWorkstreamId,subWorkstreamName,scenario,PortfolioConstants.OWNERSHIP,refSurrId,ownerShipPeriods,PortfolioConstants.TRUE,PortfolioConstants.FALSE);
        subWorkStreamResourceCostRepo.deleteAll(subWorkstreamResourceCosts);
    }
}
