package com.dbs.genesis.portfolio.controller;


import com.dbs.genesis.portfolio.repository.HyperionProductRepository;
import com.dbs.genesis.portfolio.model.HyperionProductTree;
import com.dbs.genesis.portfolio.repository.HyperionProdRepo;
import com.dbs.genesis.portfolio.resources.HyperionProductResource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;


@Slf4j
@RestController
@RequestMapping("/data/productCode")
public class HyperionProductController extends GenericDataController<HyperionProductTree, String> {

    private HyperionProductRepository repo;
    @Autowired
    private HyperionProdRepo repoHyperProd;


    public HyperionProductController(HyperionProductRepository repo) {
        super(repo);
        this.repo = repo;
    }

    @GetMapping("/list")
    public List<HyperionProductResource> getAppCodeDesc() {
        List<HyperionProductResource> productCodes = repoHyperProd.findHyperionProductResource();
        productCodes.removeIf(Objects::isNull);
        return productCodes;
    }

}
