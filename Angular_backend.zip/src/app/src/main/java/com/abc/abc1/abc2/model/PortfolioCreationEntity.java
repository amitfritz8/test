package com.dbs.genesis.portfolio.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PortfolioCreationEntity {

    String portfolioName;
    String initiationYear;
    String workType;
    String primaryPlatformName;
    String workStreamName;
    String country;
    String subWorkStreamName;
    String deliveryPlatformUnit;
}
