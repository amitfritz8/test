package com.dbs.genesis.portfolio.service.financials;

import com.dbs.genesis.portfolio.common.CombineTwoArrayValues;
import com.dbs.genesis.portfolio.common.CommonFinancialTypes;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.SubWorkStreamResourceCost;
import com.dbs.genesis.portfolio.repository.EmployeeRateCardRepo;
import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.repository.SubWorkStreamResourceCostRepo;
import com.dbs.genesis.portfolio.resources.CostTypeCategoryView;
import com.dbs.genesis.portfolio.resources.FinancialSummaryResource;
import com.dbs.genesis.portfolio.resources.UnitCostMappingView;
import com.dbs.genesis.portfolio.resources.UnitCostResource;
import com.dbs.genesis.portfolio.service.costsettings.CostSettingService;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class BreakDownCostResourceService implements CombineTwoArrayValues, CommonFinancialTypes {


    private final SubWorkStreamResourceCostRepo subWorkStreamResourceCostRepo;
    private final BreakDownCostOthersService breakDownCostOthersService;
    private final EmployeeRateCardRepo employeeRateCardRepo;
    private final CostSettingService costSettingService;
    private final PortfolioRepository portfolioRepository;
    private String financialResourceHeaderSummaryByPeriodAndGroupCcy;
    private EntityManager entityManager;


    @Autowired
    public BreakDownCostResourceService(SubWorkStreamResourceCostRepo subWorkStreamResourceCostRepo,
                                        BreakDownCostOthersService breakDownCostOthersService,
                                        EmployeeRateCardRepo employeeRateCardRepo,
                                        CostSettingService costSettingService, PortfolioRepository portfolioRepository,
                                        EntityManager entityManager
    ) {
        this.subWorkStreamResourceCostRepo = subWorkStreamResourceCostRepo;
        this.breakDownCostOthersService = breakDownCostOthersService;
        this.employeeRateCardRepo = employeeRateCardRepo;
        this.costSettingService = costSettingService;
        this.portfolioRepository = portfolioRepository;
        this.entityManager = entityManager;
    }

    public List<List<BigDecimal>> getListOfMonthlyValuesByResourceTotal(String subWorkStreamId, String subWorkStreamName, String period, String scenario, String currencyCode) {

        //Map<String, List<SubWorkStreamResourceCost>> resourceListByPeriod = getBySubWorkStreamResourcesList(subWorkStreamId, subWorkStreamName, period, scenario).stream().collect(
        //        Collectors.groupingBy(SubWorkStreamResourceCost::getPeriod));

        List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            portfolioRepository.getSubworkstreamResourceHeaderRowByPeriodAndGroupCurrency(subWorkStreamId,
                                    subWorkStreamName, period, scenario,
                                    "financialResourceHeaderSummaryByPeriodAndGroupCcy", PortfolioConstants.RESOURCE)
                            : portfolioRepository.getSubworkstreamResourceHeaderRowByPeriodAndLocalCurrency(subWorkStreamId,
                            subWorkStreamName, period, scenario,
                            "financialResourceHeaderSummaryByPeriodAndLocalCcy", PortfolioConstants.RESOURCE);
        Map<String, List<FinancialSummaryResource>> resourceListByPeriod =  consolidatedFinancialSummary.stream().collect(Collectors.groupingBy(FinancialSummaryResource::getPeriod));

        List<List<BigDecimal>> monthlyValuesFinal = new ArrayList<>();
        BigDecimal[] monthlyValuesFTE = new BigDecimal[12];
        BigDecimal[] monthlyValuesAlloc = new BigDecimal[12];
        BigDecimal[] monthlyValuesManDays = new BigDecimal[12];
        Arrays.fill(monthlyValuesFTE, BigDecimal.ZERO);
        Arrays.fill(monthlyValuesAlloc, BigDecimal.ZERO);
        Arrays.fill(monthlyValuesManDays, BigDecimal.ZERO);

//        fte
        resourceListByPeriod.forEach((year, resourcePeriodList) -> {
            BigDecimal totalCostValueFTE = BigDecimal.ZERO;
            String reportingMonth = year.substring(4, 6);
            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                for (FinancialSummaryResource financialSummaryResource : resourcePeriodList) {
                    if (financialSummaryResource.getFte() != null &&
                            financialSummaryResource.getFte().intValue() != 0) {
                        totalCostValueFTE = totalCostValueFTE.add(financialSummaryResource.getFte());
                    }
                }
            }
            monthlyValuesFTE[Integer.parseInt(reportingMonth) - 1] = totalCostValueFTE;
        });


        BigDecimal manDays = BigDecimal.valueOf(costSettingService.getFDManDaysPerMonth());

        resourceListByPeriod.forEach((year, resourcePeriodList) -> {
            BigDecimal totalCostValueManDays = BigDecimal.ZERO;
            String reportingMonth = year.substring(4, 6);

            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                for (FinancialSummaryResource financialSummaryResource : resourcePeriodList) {
                    if (LocalDate.parse(year + "01", DateTimeFormatter.ofPattern("yyyyMMdd", Locale.ENGLISH)).isAfter(LocalDate.now().minusMonths(1))) {
                        totalCostValueManDays = totalCostValueManDays.add(manDays);
                    } else {
                        totalCostValueManDays = totalCostValueManDays.add(BigDecimal.ZERO);
                    }
                }
            }
            monthlyValuesManDays[Integer.parseInt(reportingMonth) - 1] = totalCostValueManDays;
        });

        resourceListByPeriod.forEach((year, resourcePeriodList) -> {
            BigDecimal totalCostValueAlloc = BigDecimal.ZERO;
            String reportingMonth = year.substring(4, 6);
            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                for (FinancialSummaryResource financialSummaryResource : resourcePeriodList) {
                    if (null != financialSummaryResource.getCurrencyValue()) {
                        totalCostValueAlloc = totalCostValueAlloc.add(financialSummaryResource.getCurrencyValue());
                    }
                }
            }
            monthlyValuesAlloc[Integer.parseInt(reportingMonth) - 1] = totalCostValueAlloc;
        });

        //List<BigDecimal> resourceOverAllTotal = getByHeaderByMonthly(subWorkStreamId, subWorkStreamName, period, scenario, currencyCode);

        monthlyValuesFinal.add(Arrays.asList(monthlyValuesFTE));
        monthlyValuesFinal.add(Arrays.asList(monthlyValuesManDays));
        monthlyValuesFinal.add(Arrays.asList(monthlyValuesAlloc));
        return monthlyValuesFinal;
    }

    private List<SubWorkStreamResourceCost> getBySubWorkStreamResourcesList(String subWorkStreamId, String subWorkStreamName, String year, String scenario) {
        return subWorkStreamResourceCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotInAndPeriodNative(
                        subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, PortfolioConstants.FALSE, year);
    }

    public List<BigDecimal> getByHeaderByMonthly (String subWorkStreamId, String subWorkStreamName, String period,String scenario, String currencyCode) {
        List<FinancialSummaryResource> consolidatedFinancialSummary =
                PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        portfolioRepository.getSubworkstreamResourceHeaderRowByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, period, scenario,
                                "financialResourceHeaderSummaryByPeriodAndGroupCcy", PortfolioConstants.RESOURCE)
                        : portfolioRepository.getSubworkstreamResourceHeaderRowByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, period, scenario,
                        "financialResourceHeaderSummaryByPeriodAndLocalCcy", PortfolioConstants.RESOURCE);

        BigDecimal[] costValues = new BigDecimal[12];
        Arrays.fill(costValues, BigDecimal.ZERO);

        for (FinancialSummaryResource summaryResource : consolidatedFinancialSummary) {
            String reportingMonth = summaryResource.getPeriod().substring(4, 6);
            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                costValues[Integer.parseInt(reportingMonth) - 1] = summaryResource.getCurrencyValue();
            }
        }

        return Collections.unmodifiableList(Arrays.asList(costValues));
    }

    public List<BigDecimal> getCostTypeOverAllTotal(String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode) {

        BigDecimal manDays = BigDecimal.valueOf(costSettingService.getFDManDaysPerMonth());

        List<BigDecimal> totalData = new ArrayList<>();
        List<SubWorkStreamResourceCost> subWorkStreamNameAndScenario =
                subWorkStreamResourceCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalInd(
                        subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, PortfolioConstants.FALSE);
        BigDecimal fte = BigDecimal.ZERO;
        for (SubWorkStreamResourceCost workStream : subWorkStreamNameAndScenario) {
            fte = fte.add(workStream.getFte()!=null?workStream.getFte():BigDecimal.ZERO);
        }
        BigDecimal manDaysActual = BigDecimal.ZERO;
        for (SubWorkStreamResourceCost workStream : subWorkStreamNameAndScenario) {
            manDaysActual = manDaysActual.add(manDays);
        }

        BigDecimal cost = BigDecimal.ZERO;
        for (SubWorkStreamResourceCost subWorkStreamResourceCost : subWorkStreamNameAndScenario) {
            if (subWorkStreamResourceCost.getBlendedCostLocalCcy() != null) {
                cost = cost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        subWorkStreamResourceCost.getBlendedCostGroupCcy() : subWorkStreamResourceCost.getBlendedCostLocalCcy());
            }
        }
        totalData.add(fte);
        totalData.add(manDaysActual);
        totalData.add(cost);
        return totalData;
    }


    public List<UnitCostMappingView> getResourceUnitCostMapByMonthly(String subWorkStreamId, String subWorkStreamName,
                                                                     String period, String scenario, String currencyCode) {
        Map<String, Map<String, List<SubWorkStreamResourceCost>>> vendorPeriodMap = getSubWorkStreamResourceMap(subWorkStreamId, subWorkStreamName, period, scenario);
        List<UnitCostMappingView> unitCostList = Lists.newArrayList();
        //parentSurrIdMap.forEach((surrId, vendorPeriodMap) -> {
            vendorPeriodMap.forEach((teamRole, teamRoleListMap) -> {
                teamRoleListMap.forEach((vendorName, subWorkStreamResourceCostList) -> {
                    UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
                    unitCostMappingView.setRefSurrId(subWorkStreamResourceCostList.get(0).getRefSwsResourceSurrId());
                    unitCostMappingView.setName(teamRole + " - " + vendorName);
                    unitCostMappingView.setCurrencyCode(currencyCode);
                    unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
                    populateUnitCostMappingForGivenResource(subWorkStreamResourceCostList, unitCostMappingView, currencyCode, scenario);
                    unitCostList.add(unitCostMappingView);
                });
            });
        //});
        List<UnitCostMappingView> otherSoftwareResource = breakDownCostOthersService.getOtherResourceByMonthly(subWorkStreamId, subWorkStreamName, period, scenario, currencyCode);
        unitCostList.addAll(otherSoftwareResource);

        /*Map<String, Map<String, List<SubWorkStreamResourceCost>>> vendorPeriodMap = getSubWorkStreamResourceMap(subWorkStreamId, subWorkStreamName, period, scenario);
        List<UnitCostMappingView> unitCostList = Lists.newArrayList();

        vendorPeriodMap.forEach((teamRole, teamRoleListMap) -> {
            teamRoleListMap.forEach((vendorName, subWorkStreamResourceCostList) -> {
                UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
                unitCostMappingView.setRefSurrId(subWorkStreamResourceCostList.get(0).getRefSwsResourceSurrId());
                unitCostMappingView.setName(teamRole + " - " + vendorName);
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
                populateUnitCostMappingForGivenResource(subWorkStreamResourceCostList, unitCostMappingView, currencyCode);
                unitCostList.add(unitCostMappingView);
            });
        });
        List<UnitCostMappingView> otherSoftwareResource = breakDownCostOthersService.getOtherResourceByMonthly(subWorkStreamId, subWorkStreamName, period, scenario, currencyCode);
        unitCostList.addAll(otherSoftwareResource);*/

        return unitCostList;
    }

    private Map<String, Map<String, List<SubWorkStreamResourceCost>>> getSubWorkStreamResourceMap(String subWorkStreamId,
                                                                                                  String subWorkStreamName,
                                                                                                  String period, String scenario) {

        /*Map<Integer, Map<String, Map<String, List<SubWorkStreamResourceCost>>>> surrMap = subWorkStreamResourceCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotInAndPeriodContaining(
                        subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, PortfolioConstants.FALSE, GeneUtils.getGlCategoriesNotInclude(), period)
                .stream().collect(Collectors.groupingBy(SubWorkStreamResourceCost::getRefSwsResourceSurrId, Collectors.groupingBy(SubWorkStreamResourceCost::getTeamRole, Collectors.groupingBy(
                SubWorkStreamResourceCost::getVendor)))); */
        return subWorkStreamResourceCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotInAndPeriodNative(
                        subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, PortfolioConstants.FALSE,  period)
                .stream().collect(Collectors.groupingBy(SubWorkStreamResourceCost::getTeamRole, Collectors.groupingBy(
                        SubWorkStreamResourceCost::getVendor)));

        /*return subWorkStreamResourceCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotInAndPeriodContaining(
                        subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, PortfolioConstants.FALSE, GeneUtils.getGlCategoriesNotInclude(), period)
                .stream().collect(Collectors.groupingBy(SubWorkStreamResourceCost::getTeamRole, Collectors.groupingBy(
                        SubWorkStreamResourceCost::getVendor)));*/

    }

    private UnitCostMappingView populateUnitCostMappingForGivenResource(List<SubWorkStreamResourceCost> softwarePeriodList,
                                                                        UnitCostMappingView unitCostMappingView, String currencyCode,
                                                                        String scenario) {
        List<UnitCostResource> costResourceList = Lists.newLinkedList();
        List<UnitCostResource> fteResourceList = Lists.newLinkedList();
        List<UnitCostResource> allocResourceList = Lists.newLinkedList();
        List<UnitCostResource> manDaysResourceList = Lists.newLinkedList();

        BigDecimal fteOverAllTotal = BigDecimal.ZERO;
        BigDecimal costOverAllTotal = BigDecimal.ZERO;
        BigDecimal manDaysOverAllTotal = BigDecimal.ZERO;
        BigDecimal allocOverAllTotal = BigDecimal.ZERO;

        BigDecimal manDaysConfig = BigDecimal.valueOf(costSettingService.getFDManDaysPerMonth());

        BigDecimal blendedeCostPerDay = BigDecimal.ZERO;

        for (SubWorkStreamResourceCost subWorkStreamSoftwareCost : softwarePeriodList) {
            String reportingMonth = subWorkStreamSoftwareCost.getPeriod().substring(4, 6);
            BigDecimal costPerMonth = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    subWorkStreamSoftwareCost.getBlendedCostGroupCcy() : subWorkStreamSoftwareCost.getBlendedCostLocalCcy();
            unitCostMappingView.setUnitPriceValue(costPerMonth.toString());

            UnitCostResource fteResource = new UnitCostResource();
            fteResource.setSurrId(subWorkStreamSoftwareCost.getSwsResourceSurrId());
            fteResource.setMonthNumber(reportingMonth);
            fteResource.setValue(subWorkStreamSoftwareCost.getFte());
            fteResourceList.add(fteResource);
            fteOverAllTotal = fteOverAllTotal.add(Objects.nonNull(subWorkStreamSoftwareCost.getFte())?subWorkStreamSoftwareCost.getFte():BigDecimal.ZERO);

            UnitCostResource allocResource = new UnitCostResource();
            allocResource.setSurrId(subWorkStreamSoftwareCost.getSwsResourceSurrId());
            allocResource.setMonthNumber(reportingMonth);
            allocResource.setValue(subWorkStreamSoftwareCost.getAllocationPercentage());
            allocResourceList.add(allocResource);
            allocOverAllTotal = allocOverAllTotal.add(Objects.nonNull(subWorkStreamSoftwareCost.getAllocationPercentage())? subWorkStreamSoftwareCost.getAllocationPercentage() : BigDecimal.ZERO);

            UnitCostResource manDaysResource = new UnitCostResource();
            manDaysResource.setSurrId(subWorkStreamSoftwareCost.getSwsResourceSurrId());
            manDaysResource.setMonthNumber(reportingMonth);
            manDaysResource.setValue(Objects.nonNull(subWorkStreamSoftwareCost.getAllocationPercentage())? subWorkStreamSoftwareCost.getAllocationPercentage().multiply(Objects.nonNull(subWorkStreamSoftwareCost.getFte())? subWorkStreamSoftwareCost.getFte() : BigDecimal.ZERO).multiply(manDaysConfig) : BigDecimal.ZERO);
            if (manDaysResource.getValue() != null) {
                manDaysResource.setValue(manDaysResource.getValue().divide(BigDecimal.valueOf(100)));
            }
            manDaysResourceList.add(manDaysResource);
            manDaysOverAllTotal = manDaysOverAllTotal.add(manDaysResource.getValue());

            UnitCostResource costResource = new UnitCostResource();
            costResource.setSurrId(subWorkStreamSoftwareCost.getSwsResourceSurrId());
            costResource.setMonthNumber(reportingMonth);
            costResource.setValue(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    subWorkStreamSoftwareCost.getBlendedCostGroupCcy() : subWorkStreamSoftwareCost.getBlendedCostLocalCcy());
            costResourceList.add(costResource);
            /*costOverAllTotal = costOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    subWorkStreamSoftwareCost.getBlendedCostGroupCcy() : subWorkStreamSoftwareCost.getBlendedCostLocalCcy());*/

            //costOverAllTotal = manDaysOverAllTotal.add(subWorkStreamSoftwareCost.getBlendedCostLocalCcy());
            blendedeCostPerDay = employeeRateCardRepo.getStaffRate(subWorkStreamSoftwareCost.getLocation(),
                    subWorkStreamSoftwareCost.getLocalCcy(), subWorkStreamSoftwareCost.getStaffType(),
                    subWorkStreamSoftwareCost.getVendor(), subWorkStreamSoftwareCost.getRateSource(), subWorkStreamSoftwareCost.getStaffLevel(),
                    PortfolioConstants.RATE_INDICATOR_BLENDED);

        }

        List<FinancialSummaryResource> financialSummaryResourceList = portfolioRepository.findGrandTotalOfResourceBasedOnUniqueIdentifierNative
                (softwarePeriodList.get(0).getSubWorkStreamId(),softwarePeriodList.get(0).getSubWorkStreamName(),
                        scenario, softwarePeriodList.get(0).getTeamRole(), softwarePeriodList.get(0).getLocation(),
                        softwarePeriodList.get(0).getStaffType(), softwarePeriodList.get(0).getVendor(), softwarePeriodList.get(0).getRateSource(),
                        softwarePeriodList.get(0).getStaffLevel());

        costOverAllTotal = costOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                financialSummaryResourceList.get(0).getGrpCurrencyValue() : financialSummaryResourceList.get(0).getCurrencyValue());

        fteResourceList = fteResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(fteResourceList) : fteResourceList;
        costResourceList = costResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(costResourceList) : costResourceList;
        manDaysResourceList = manDaysResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(manDaysResourceList) : manDaysResourceList;
        allocResourceList = allocResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(allocResourceList) : allocResourceList;


        unitCostMappingView.setMonthlyResourcesFTEs(fteResourceList);
        unitCostMappingView.setMonthlyResourcesCosts(costResourceList);
        unitCostMappingView.setMonthlyResourcesManDays(manDaysResourceList);
        unitCostMappingView.setMonthlyResourcesAllocations(allocResourceList);


        unitCostMappingView.setCostOverAllTotal(costOverAllTotal);
        unitCostMappingView.setFteOverAllTotal(fteOverAllTotal);
        unitCostMappingView.setManDaysOverAllTotal(manDaysOverAllTotal);
        unitCostMappingView.setAlloCOverAllTotal(allocOverAllTotal);

        unitCostMappingView.setFdManDays(manDaysConfig);

        if (null != blendedeCostPerDay) {
            unitCostMappingView.setBlendedCost(blendedeCostPerDay);
        }
        return unitCostMappingView;
    }

    private List<UnitCostResource> getUnitAndCostResourceMonthlyList(List<UnitCostResource> unitAndCostResourceList) {
        List<UnitCostResource> unitAndcostResourceMonthlyList = Lists.newLinkedList();
        if (unitAndCostResourceList.size() < 12) {
            for (int i = 1; i <= 12; i++) {
                UnitCostResource costResource = new UnitCostResource();
                costResource.setSurrId(0);
                costResource.setMonthNumber(i <= 9 ? "0" + i : String.valueOf(i));
                costResource.setValue(BigDecimal.ZERO);
                unitAndcostResourceMonthlyList.add(costResource);
            }
            for (int i = 0; i < unitAndcostResourceMonthlyList.size(); i++) {
                for (int j = 0; j < unitAndCostResourceList.size(); j++) {
                    if (unitAndcostResourceMonthlyList.get(i).getMonthNumber().equalsIgnoreCase(unitAndCostResourceList.get(j).getMonthNumber())) {
                        unitAndcostResourceMonthlyList.set(i, unitAndCostResourceList.get(j));
                        break;
                    }
                }
            }
        }
        return unitAndcostResourceMonthlyList;
    }

    public Map<String, List<UnitCostMappingView>> getResourceUnitCostMapQuarterly(String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode) {

        Map<String, List<UnitCostMappingView>> quarterlyUnitCostMapByPeriod = new TreeMap<>();
        List<String> listOfSoftwareYears = subWorkStreamResourceCostRepo.findDistinctOfPeriodsFromSoftwareCostAndOtherSoftwareCost(subWorkStreamId, subWorkStreamName, scenario);
        for (String year : listOfSoftwareYears) {
            Map<String, Map<String, List<SubWorkStreamResourceCost>>> vendorPeriodMap = getVendorNamePeriodAndResourceCostList(subWorkStreamId, subWorkStreamName, year, scenario);
            List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
            //parentSurrIdMap.forEach((surrId, vendorPeriodMap) ->
            vendorPeriodMap.forEach((teamRole, resourceNameListMap) ->
            resourceNameListMap.forEach((vendorName, subWorkStreamSoftwareCostList) -> {
                SubWorkStreamResourceCost subWorkStreamSoftwareCost = subWorkStreamSoftwareCostList.get(0);
                UnitCostMappingView unitCostMappingView = getUnitCostMappingResourceByQuarterly(subWorkStreamSoftwareCostList, subWorkStreamId, subWorkStreamName, scenario, currencyCode);
                unitCostMappingView.setName(teamRole + " - " + vendorName);
                String resourceIdentifier = subWorkStreamSoftwareCost.getTeamRole()
                                                                            + "_" + subWorkStreamSoftwareCost.getLocation()
                                                                            + "_" + subWorkStreamSoftwareCost.getStaffType()
                                                                            + "_" + subWorkStreamSoftwareCost.getVendor()
                                                                            + "_" + subWorkStreamSoftwareCost.getRateSource()
                                                                            + "_" + subWorkStreamSoftwareCost.getStaffLevel();
                //unitCostMappingView.setRefSurrId(subWorkStreamSoftwareCostList.get(0).getCapexOpexSurrId());

                unitCostMappingView.setRefSurrId(resourceIdentifier.intern().hashCode());
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
                unitCostMappingViewArrayList.add(unitCostMappingView);
            }));
            //);
            /*
            Map<String, Map<String, List<SubWorkStreamResourceCost>>> vendorPeriodMap = getVendorNamePeriodAndResourceCostList(subWorkStreamId, subWorkStreamName, year, scenario);
            List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
            vendorPeriodMap.forEach((vendorName, resourceNameListMap) -> resourceNameListMap.forEach((teamRole, subWorkStreamSoftwareCostList) -> {
                UnitCostMappingView unitCostMappingView = getUnitCostMappingResourceByQuarterly(subWorkStreamSoftwareCostList, subWorkStreamId, subWorkStreamName, scenario, currencyCode);
                unitCostMappingView.setName(teamRole + " - " + vendorName);
                //TODO set currencytype, currencyvalue
                unitCostMappingView.setRefSurrId(subWorkStreamSoftwareCostList.get(0).getRefSwsResourceSurrId());
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
                unitCostMappingViewArrayList.add(unitCostMappingView);
            }));
             */
            unitCostMappingViewArrayList.addAll(breakDownCostOthersService.getOtherResourceByQuarterly(subWorkStreamId, subWorkStreamName, year, scenario, currencyCode));
            quarterlyUnitCostMapByPeriod.put(year, unitCostMappingViewArrayList);
        }
        return quarterlyUnitCostMapByPeriod;
    }

    public void getResourceQuarterlyListMap(String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode, CostTypeCategoryView costTypeCategoryView) {

        BigDecimal manDays = BigDecimal.valueOf(costSettingService.getFDManDaysPerMonth());

        Map<String, List<BigDecimal>> mandaysYearMap = new HashMap<>();
        Map<String, List<BigDecimal>> fteYearMap = new HashMap<>();
        Map<String, List<BigDecimal>> allocYearMap = new HashMap<>();
        Map<String, List<BigDecimal>> costYearMap = new HashMap<>();

        Map<String, List<BigDecimal>> totalYearMap = new HashMap<>();

        BigDecimal totalFTE = BigDecimal.ZERO;
        BigDecimal totalManDays = BigDecimal.ZERO;
        BigDecimal totalAlloc = BigDecimal.ZERO;
        BigDecimal totalCost = BigDecimal.ZERO;

        List<String> distinctOfPeriods = subWorkStreamResourceCostRepo.findDistinctOfPeriodsFromSoftwareCostAndOtherSoftwareCost(subWorkStreamId, subWorkStreamName, scenario);
        for (String year : distinctOfPeriods) {
            List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            portfolioRepository.getSubworkstreamResourceHeaderRowByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, year, scenario,
                                    "financialResourceHeaderSummaryByPeriodAndGroupCcy", PortfolioConstants.RESOURCE)
                            : portfolioRepository.getSubworkstreamResourceHeaderRowByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, year, scenario,
                            "financialResourceHeaderSummaryByPeriodAndLocalCcy", PortfolioConstants.RESOURCE);
            List<SubWorkStreamResourceCost> subWorkStreamResourceCostList = getBySubWorkStreamResourcesList(subWorkStreamId, subWorkStreamName, year, scenario);

            List<BigDecimal> yearManDays = new ArrayList<>();
            List<BigDecimal> yearFTE = new ArrayList<>();
            List<BigDecimal> yearAlloc = new ArrayList<>();
            List<BigDecimal> yearCost = new ArrayList<>();

            BigDecimal firstQuarterFTE = BigDecimal.ZERO;
            BigDecimal secondQuarterFTE = BigDecimal.ZERO;
            BigDecimal thirdQuarterFTE = BigDecimal.ZERO;
            BigDecimal fourthQuarterFTE = BigDecimal.ZERO;

            BigDecimal firstQuarterAlloc = BigDecimal.ZERO;
            BigDecimal secondQuarterAlloc = BigDecimal.ZERO;
            BigDecimal thirdQuarterAlloc = BigDecimal.ZERO;
            BigDecimal fourthQuarterAlloc = BigDecimal.ZERO;

            BigDecimal firstQuarterCost = BigDecimal.ZERO;
            BigDecimal secondQuarterCost = BigDecimal.ZERO;
            BigDecimal thirdQuarterCost = BigDecimal.ZERO;
            BigDecimal fourthQuarterCost = BigDecimal.ZERO;

            BigDecimal firstQuarterMandays = BigDecimal.ZERO;
            BigDecimal secondQuarterMandays = BigDecimal.ZERO;
            BigDecimal thirdQuarterMandays = BigDecimal.ZERO;
            BigDecimal fourthQuarterMandays = BigDecimal.ZERO;

            BigDecimal fteTotalYear = BigDecimal.ZERO;
            BigDecimal allocTotalYear = BigDecimal.ZERO;
            BigDecimal mandaysTotalYear = BigDecimal.ZERO;
            BigDecimal costTotalYear = BigDecimal.ZERO;

            for (int index = 0; index < consolidatedFinancialSummary.size(); index++) {
                //for (SubWorkStreamResourceCost subWorkStreamResourceCost : subWorkStreamResourceCostList) {
                SubWorkStreamResourceCost subWorkStreamResourceCost = null;
                if (null != subWorkStreamResourceCostList && !subWorkStreamResourceCostList.isEmpty() && index < subWorkStreamResourceCostList.size()) {
                    subWorkStreamResourceCost = subWorkStreamResourceCostList.get(index);
                } else {
                    subWorkStreamResourceCost = new SubWorkStreamResourceCost();
                }
                FinancialSummaryResource financialSummaryResource = consolidatedFinancialSummary.get(index);
                String reportingYear = financialSummaryResource.getPeriod().substring(0, 4);
                if (year.equalsIgnoreCase(reportingYear)) {
                    String reportingMonth = financialSummaryResource.getPeriod().substring(4, 6);
                    if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
//                        firstQuarterMandays = firstQuarterMandays.add(manDays);
                        if (LocalDate.parse(financialSummaryResource.getPeriod() + "01", DateTimeFormatter.ofPattern("yyyyMMdd", Locale.ENGLISH)).isAfter(LocalDate.now())) {
                            firstQuarterMandays = firstQuarterMandays.add(manDays);
                        } else {
                            firstQuarterMandays = firstQuarterMandays.add(BigDecimal.ZERO);
                        }

                        firstQuarterFTE = firstQuarterFTE.add(subWorkStreamResourceCost.getFte());

                        firstQuarterAlloc = firstQuarterAlloc.add(subWorkStreamResourceCost.getAllocationPercentage());

                        firstQuarterCost = firstQuarterCost.add(financialSummaryResource.getCurrencyValue());


                    } else if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {

//                        secondQuarterMandays = secondQuarterMandays.add(manDays);
                        if (LocalDate.parse(financialSummaryResource.getPeriod() + "01", DateTimeFormatter.ofPattern("yyyyMMdd", Locale.ENGLISH)).isAfter(LocalDate.now())) {
                            secondQuarterMandays = secondQuarterMandays.add(manDays);
                        } else {
                            secondQuarterMandays = secondQuarterMandays.add(BigDecimal.ZERO);
                        }
                        secondQuarterFTE = secondQuarterFTE.add(subWorkStreamResourceCost.getFte());

                        secondQuarterAlloc = secondQuarterAlloc.add(subWorkStreamResourceCost.getAllocationPercentage());

                        secondQuarterCost = secondQuarterCost.add(financialSummaryResource.getCurrencyValue());

                    } else if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {

//                        thirdQuarterMandays = thirdQuarterMandays.add(manDays);
                        if (LocalDate.parse(financialSummaryResource.getPeriod() + "01", DateTimeFormatter.ofPattern("yyyyMMdd", Locale.ENGLISH)).isAfter(LocalDate.now())) {
                            thirdQuarterMandays = thirdQuarterMandays.add(manDays);
                        } else {
                            thirdQuarterMandays = thirdQuarterMandays.add(BigDecimal.ZERO);
                        }
                        thirdQuarterFTE = thirdQuarterFTE.add(subWorkStreamResourceCost.getFte());

                        thirdQuarterAlloc = thirdQuarterAlloc.add(subWorkStreamResourceCost.getAllocationPercentage());

                        thirdQuarterCost = thirdQuarterCost.add(financialSummaryResource.getCurrencyValue());

                    } else if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {

//                        fourthQuarterMandays = fourthQuarterMandays.add(manDays);
                        if (LocalDate.parse(financialSummaryResource.getPeriod() + "01", DateTimeFormatter.ofPattern("yyyyMMdd", Locale.ENGLISH)).isAfter(LocalDate.now())) {
                            fourthQuarterMandays = fourthQuarterMandays.add(manDays);
                        } else {
                            fourthQuarterMandays = fourthQuarterMandays.add(BigDecimal.ZERO);
                        }

                        fourthQuarterFTE = fourthQuarterFTE.add(subWorkStreamResourceCost.getFte());

                        fourthQuarterAlloc = fourthQuarterAlloc.add(subWorkStreamResourceCost.getAllocationPercentage());

                        fourthQuarterCost = fourthQuarterCost.add(financialSummaryResource.getCurrencyValue());
                    }


                    fteTotalYear = fteTotalYear.add(subWorkStreamResourceCost.getFte());
                    allocTotalYear = allocTotalYear.add(subWorkStreamResourceCost.getAllocationPercentage());
                    //mandaysTotalYear = mandaysTotalYear.add(manDays);
                    costTotalYear = costTotalYear.add(financialSummaryResource.getCurrencyValue());


                    totalFTE = totalFTE.add(subWorkStreamResourceCost.getFte());
                    totalManDays = totalManDays.add(manDays);
                    totalAlloc = totalAlloc.add(subWorkStreamResourceCost.getAllocationPercentage());
                    totalCost = totalCost.add(financialSummaryResource.getCurrencyValue());

                }
            }
            yearManDays.add(firstQuarterMandays);
            yearManDays.add(secondQuarterMandays);
            yearManDays.add(thirdQuarterMandays);
            yearManDays.add(fourthQuarterMandays);
            mandaysYearMap.put(year, yearManDays);

            yearFTE.add(firstQuarterFTE);
            yearFTE.add(secondQuarterFTE);
            yearFTE.add(thirdQuarterFTE);
            yearFTE.add(fourthQuarterFTE);
            fteYearMap.put(year, yearFTE);


            yearAlloc.add(firstQuarterAlloc);
            yearAlloc.add(secondQuarterAlloc);
            yearAlloc.add(thirdQuarterAlloc);
            yearAlloc.add(fourthQuarterAlloc);
            allocYearMap.put(year, yearAlloc);



            yearCost.add(firstQuarterCost);
            yearCost.add(secondQuarterCost);
            yearCost.add(thirdQuarterCost);
            yearCost.add(fourthQuarterCost);
            costYearMap.put(year, yearCost);

            List<BigDecimal> totalIst = new ArrayList<>();
            totalIst.add(fteTotalYear);
            totalIst.add(mandaysTotalYear);
//            totalIst.add(allocTotalYear);
            totalIst.add(costTotalYear);
            totalYearMap.put(year, totalIst);
        }

        costTypeCategoryView.setQuarterlyFTEType(fteYearMap);
        costTypeCategoryView.setQuarterlyMandaysType(mandaysYearMap);
//        costTypeCategoryView.setQuarterlyAllocationType(allocYearMap);
        costTypeCategoryView.setQuarterlyCostType(costYearMap);
        costTypeCategoryView.setIndividualYearSummaryForQuarterlyForResource(totalYearMap);

        List<BigDecimal> costTypeOverAllTotal = new ArrayList<>();
        costTypeOverAllTotal.add(totalFTE);
        costTypeOverAllTotal.add(BigDecimal.ZERO);
//        costTypeOverAllTotal.add(totalAlloc);
        costTypeOverAllTotal.add(totalCost);

        costTypeCategoryView.setCostTypeOverAllTotalResource(costTypeOverAllTotal);

    }

    private Map<String, Map<String, List<SubWorkStreamResourceCost>>> getVendorNamePeriodAndResourceCostList(
            String subWorkStreamId, String subWorkStreamName, String year, String scenario) {
        /*return getBySubWorkStreamResourcesList(subWorkStreamId, subWorkStreamName, year, scenario).stream().collect(
                Collectors.groupingBy(SubWorkStreamResourceCost::getRefSwsResourceSurrId, Collectors.groupingBy(SubWorkStreamResourceCost::getVendor, Collectors.groupingBy(SubWorkStreamResourceCost::getTeamRole))));

        */
        return getBySubWorkStreamResourcesList(subWorkStreamId, subWorkStreamName, year, scenario).stream().collect(
                Collectors.groupingBy(SubWorkStreamResourceCost::getVendor, Collectors.groupingBy(SubWorkStreamResourceCost::getTeamRole)));
    }

    private UnitCostMappingView getUnitCostMappingResourceByQuarterly(List<SubWorkStreamResourceCost> subWorkStreamSoftwareCostList, String subWorkStreamId,
                                                                      String subWorkStreamName, String scenario, String currencyCode) {

        BigDecimal manDaysConfig = BigDecimal.valueOf(costSettingService.getFDManDaysPerMonth());


        BigDecimal firstQuarterCostTotal = BigDecimal.ZERO;
        BigDecimal secondQuarterCostTotal = BigDecimal.ZERO;
        BigDecimal thirdQuarterCostTotal = BigDecimal.ZERO;
        BigDecimal fourthQuarterCostTotal = BigDecimal.ZERO;

        BigDecimal firstQuarterMandaysTotal = BigDecimal.ZERO;
        BigDecimal secondQuarterMandaysTotal = BigDecimal.ZERO;
        BigDecimal thirdQuarterMandaysTotal = BigDecimal.ZERO;
        BigDecimal fourthQuarterMandaysTotal = BigDecimal.ZERO;

        BigDecimal firstQuarterAllocTotal = BigDecimal.ZERO;
        BigDecimal secondQuarterAllocTotal = BigDecimal.ZERO;
        BigDecimal thirdQuarterAllocTotal = BigDecimal.ZERO;
        BigDecimal fourthQuarterAllocTotal = BigDecimal.ZERO;

        BigDecimal firstQuarterFTETotal = BigDecimal.ZERO;
        BigDecimal secondQuarterFTETotal = BigDecimal.ZERO;
        BigDecimal thirdQuarterFTETotal = BigDecimal.ZERO;
        BigDecimal fourthQuarterFTETotal = BigDecimal.ZERO;


        UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
        unitCostMappingView.setPeriodType(PortfolioConstants.QUARTERLY);
        for (SubWorkStreamResourceCost softwareCost : subWorkStreamSoftwareCostList) {
            String reportingMonth = softwareCost.getPeriod().substring(4, 6);
            BigDecimal quarterTotalCost = new BigDecimal(BigInteger.ZERO);
            BigDecimal quarterTotalMandays = new BigDecimal(BigInteger.ZERO);
            BigDecimal quarterTotalFTE = new BigDecimal(BigInteger.ZERO);
            BigDecimal quarterTotalAlloc = new BigDecimal(BigInteger.ZERO);

            if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {

                firstQuarterCostTotal = getTotalCost(currencyCode, firstQuarterCostTotal, softwareCost, quarterTotalCost);
                firstQuarterMandaysTotal = getManDays(manDaysConfig, firstQuarterMandaysTotal, softwareCost, quarterTotalMandays);
                firstQuarterFTETotal = getTotalFTE(firstQuarterFTETotal, softwareCost, quarterTotalFTE);
                firstQuarterAllocTotal = getTotalAlloc(firstQuarterAllocTotal, softwareCost, quarterTotalAlloc);

            } else if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {

                secondQuarterCostTotal = getTotalCost(currencyCode, secondQuarterCostTotal, softwareCost, quarterTotalCost);
                secondQuarterMandaysTotal = getManDays(manDaysConfig, secondQuarterMandaysTotal, softwareCost, quarterTotalMandays);
                secondQuarterFTETotal = getTotalFTE(secondQuarterFTETotal, softwareCost, quarterTotalFTE);
                secondQuarterAllocTotal = getTotalAlloc(secondQuarterAllocTotal, softwareCost, quarterTotalAlloc);

            } else if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {

                thirdQuarterCostTotal = getTotalCost(currencyCode, thirdQuarterCostTotal, softwareCost, quarterTotalCost);
                thirdQuarterMandaysTotal = getManDays(manDaysConfig, thirdQuarterMandaysTotal, softwareCost, quarterTotalMandays);
                thirdQuarterFTETotal = getTotalFTE(thirdQuarterFTETotal, softwareCost, quarterTotalFTE);
                thirdQuarterAllocTotal = getTotalAlloc(thirdQuarterAllocTotal, softwareCost, quarterTotalAlloc);

            } else if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {

                fourthQuarterCostTotal = getTotalCost(currencyCode, fourthQuarterCostTotal, softwareCost, quarterTotalCost);
                fourthQuarterMandaysTotal = getManDays(manDaysConfig, fourthQuarterMandaysTotal, softwareCost, quarterTotalMandays);
                fourthQuarterFTETotal = getTotalFTE(fourthQuarterFTETotal, softwareCost, quarterTotalFTE);
                fourthQuarterAllocTotal = getTotalAlloc(fourthQuarterAllocTotal, softwareCost, quarterTotalAlloc);
            }
        }
        unitCostMappingView.setQuarterlyCostTotal(Arrays.asList(firstQuarterCostTotal, secondQuarterCostTotal, thirdQuarterCostTotal, fourthQuarterCostTotal));
        unitCostMappingView.setQuarterlyMandaysTotal(Arrays.asList(firstQuarterMandaysTotal, secondQuarterMandaysTotal, thirdQuarterMandaysTotal, fourthQuarterMandaysTotal));
        unitCostMappingView.setQuarterlyFTETotal(Arrays.asList(firstQuarterFTETotal, secondQuarterFTETotal, thirdQuarterFTETotal, fourthQuarterFTETotal));
        unitCostMappingView.setQuarterlyAllocationTotal(Arrays.asList(firstQuarterAllocTotal, secondQuarterAllocTotal, thirdQuarterAllocTotal, fourthQuarterAllocTotal));


        //List<BigDecimal> costTypeOverAllTotal = getCostTypeOverAllTotal(subWorkStreamId, subWorkStreamName, scenario, currencyCode);
        unitCostMappingView.setYearlyCostOverAllTotal(firstQuarterCostTotal.add(secondQuarterCostTotal).add(thirdQuarterCostTotal).add(fourthQuarterCostTotal));
        unitCostMappingView.setYearlyAllocationOverAllTotal(firstQuarterAllocTotal.add(secondQuarterAllocTotal).add(thirdQuarterAllocTotal).add(fourthQuarterAllocTotal));
        unitCostMappingView.setYearlyFTEOverAllTotal(firstQuarterFTETotal.add(secondQuarterFTETotal).add(thirdQuarterFTETotal).add(fourthQuarterFTETotal));
        unitCostMappingView.setYearlyMandaysOverAllTotal(firstQuarterMandaysTotal.add(secondQuarterMandaysTotal).add(thirdQuarterMandaysTotal).add(fourthQuarterMandaysTotal));


        return unitCostMappingView;
    }

    private BigDecimal getTotalAlloc(BigDecimal firstQuarterAllocTotal, SubWorkStreamResourceCost softwareCost, BigDecimal quarterTotalAlloc) {
        quarterTotalAlloc = quarterTotalAlloc.add(softwareCost.getAllocationPercentage());
        firstQuarterAllocTotal = firstQuarterAllocTotal.add(quarterTotalAlloc);
        return firstQuarterAllocTotal;
    }

    private BigDecimal getTotalFTE(BigDecimal firstQuarterFTETotal, SubWorkStreamResourceCost softwareCost, BigDecimal quarterTotalFTE) {
        quarterTotalFTE = quarterTotalFTE.add(softwareCost.getFte());
        firstQuarterFTETotal = firstQuarterFTETotal.add(quarterTotalFTE);
        return firstQuarterFTETotal;
    }

    private BigDecimal getManDays(BigDecimal manDaysConfig, BigDecimal firstQuarterMandaysTotal, SubWorkStreamResourceCost softwareCost, BigDecimal quarterTotalMandays) {
        quarterTotalMandays = quarterTotalMandays.add(softwareCost.getAllocationPercentage().multiply(softwareCost.getFte()).multiply(manDaysConfig));
        firstQuarterMandaysTotal = firstQuarterMandaysTotal.add(quarterTotalMandays);
        return firstQuarterMandaysTotal;
    }

    private BigDecimal getTotalCost(String currencyCode, BigDecimal firstQuarterCostTotal, SubWorkStreamResourceCost softwareCost, BigDecimal quarterTotalCost) {
        quarterTotalCost = quarterTotalCost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                softwareCost.getBlendedCostGroupCcy() : softwareCost.getBlendedCostLocalCcy());
        firstQuarterCostTotal = firstQuarterCostTotal.add(quarterTotalCost);
        return firstQuarterCostTotal;
    }


    public Map<String, List<UnitCostMappingView>> getYearlyResourceData(String subWorkStreamId,
                                                                        String subWorkStreamName, String scenario, String currencyCode) {
        BigDecimal manDaysConfig = BigDecimal.valueOf(costSettingService.getFDManDaysPerMonth());

        Map<String, List<UnitCostMappingView>> yearlyCostUnitResource = new TreeMap<>();
        List<String> listOfYears = subWorkStreamResourceCostRepo.findDistinctOfPeriodsFromSoftwareCostAndOtherSoftwareCost(subWorkStreamId, subWorkStreamName, scenario);
        for (String year : listOfYears) {
            Map<String, Map<String, Map<String, List<SubWorkStreamResourceCost>>>> subWorkstreamIdMap = getVendorNamePeriodAndSoftwareCostList(subWorkStreamId, subWorkStreamName, year, scenario);
            List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
            subWorkstreamIdMap.forEach((parentSurrId, vendorAndSoftwareMap) ->
            //softwareNameMap.forEach((teamRole, subWorkStreamResourceCostList) -> {*/
            vendorAndSoftwareMap.forEach((teamRole, softwareNameMap) ->
            softwareNameMap.forEach((vendorName, subWorkStreamResourceCostList) -> {

                BigDecimal costTotal = BigDecimal.ZERO;
                BigDecimal fteTotal = BigDecimal.ZERO;
                BigDecimal allocationTotal = BigDecimal.ZERO;
                BigDecimal manDaysTotal = BigDecimal.ZERO;

                UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
                unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
                for (SubWorkStreamResourceCost subWorkStreamSoftwareCost : subWorkStreamResourceCostList) {

                    fteTotal = fteTotal.add(subWorkStreamSoftwareCost.getFte());
                    allocationTotal = allocationTotal.add(subWorkStreamSoftwareCost.getAllocationPercentage());
                    manDaysTotal = manDaysTotal.add(subWorkStreamSoftwareCost.getAllocationPercentage().multiply(subWorkStreamSoftwareCost.getFte()).multiply(manDaysConfig));
                    costTotal = costTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            subWorkStreamSoftwareCost.getBlendedCostGroupCcy() : subWorkStreamSoftwareCost.getBlendedCostLocalCcy());

                }
                unitCostMappingView.addYearlyCostTotal(costTotal);
                unitCostMappingView.addYearlyFTETotal(fteTotal);
                unitCostMappingView.addyearlyAllocationTotal(allocationTotal);
                unitCostMappingView.addYearlyMandaysTotal(manDaysTotal);
                unitCostMappingView.setRefSurrId(subWorkStreamResourceCostList.get(0).getCapexOpexSurrId());
                SubWorkStreamResourceCost subWorkStreamResourceCost = subWorkStreamResourceCostList.get(0);
                unitCostMappingView.setName(teamRole + " - " + vendorName);
                String resourceIdentifier = subWorkStreamResourceCost.getTeamRole()
                                + "_" + subWorkStreamResourceCost.getLocation()
                                + "_" + subWorkStreamResourceCost.getStaffType()
                                + "_" + subWorkStreamResourceCost.getVendor()
                                + "_" + subWorkStreamResourceCost.getRateSource()
                                + "_" + subWorkStreamResourceCost.getStaffLevel()
                                + "_" + subWorkStreamResourceCost.getSubWorkStreamId();
                        //unitCostMappingView.setRefSurrId(subWorkStreamSoftwareCostList.get(0).getCapexOpexSurrId());

                        unitCostMappingView.setRefSurrId(resourceIdentifier.intern().hashCode());
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
                unitCostMappingViewArrayList.add(unitCostMappingView);
            })
                    )
        );
            /*
            Map<String, Map<String, List<SubWorkStreamResourceCost>>> vendorAndSoftwareMap = getVendorNamePeriodAndSoftwareCostList(subWorkStreamId, subWorkStreamName, year, scenario);
            List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
            vendorAndSoftwareMap.forEach((vendorName, softwareNameMap) -> softwareNameMap.forEach((teamRole, subWorkStreamResourceCostList) -> {

                BigDecimal costTotal = BigDecimal.ZERO;
                BigDecimal fteTotal = BigDecimal.ZERO;
                BigDecimal allocationTotal = BigDecimal.ZERO;
                BigDecimal manDaysTotal = BigDecimal.ZERO;

                UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
                unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
                for (SubWorkStreamResourceCost subWorkStreamSoftwareCost : subWorkStreamResourceCostList) {

                    fteTotal = fteTotal.add(subWorkStreamSoftwareCost.getFte());
                    allocationTotal = allocationTotal.add(subWorkStreamSoftwareCost.getAllocationPercentage());
                    manDaysTotal = manDaysTotal.add(subWorkStreamSoftwareCost.getAllocationPercentage().multiply(subWorkStreamSoftwareCost.getFte()).multiply(manDaysConfig));
                    costTotal = costTotal.add(subWorkStreamSoftwareCost.getBlendedCostLocalCcy());

                }
                unitCostMappingView.addYearlyCostTotal(costTotal);
                unitCostMappingView.addYearlyFTETotal(fteTotal);
                unitCostMappingView.addyearlyAllocationTotal(allocationTotal);
                unitCostMappingView.addYearlyMandaysTotal(manDaysTotal);
                unitCostMappingView.setRefSurrId(subWorkStreamResourceCostList.get(0).getRefSwsResourceSurrId());
                unitCostMappingView.setName(teamRole + " - " + vendorName);
                unitCostMappingView.setCurrencyCode("SGD");
                unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
                unitCostMappingViewArrayList.add(unitCostMappingView);
            }));
             */
            unitCostMappingViewArrayList.addAll(breakDownCostOthersService.getOthersResourceByYearly(subWorkStreamId, subWorkStreamName, year, scenario, currencyCode));
            yearlyCostUnitResource.put(year, unitCostMappingViewArrayList);
        }
        return yearlyCostUnitResource;
    }

    private Map<String, Map<String, Map<String, List<SubWorkStreamResourceCost>>>> getVendorNamePeriodAndSoftwareCostList(
            String subWorkStreamId, String subWorkStreamName, String year, String scenario) {
        return getBySubWorkStreamResourcesList(subWorkStreamId, subWorkStreamName, year, scenario).stream().collect(
                Collectors.groupingBy(SubWorkStreamResourceCost::getSubWorkStreamId,
                Collectors.groupingBy(SubWorkStreamResourceCost::getTeamRole, Collectors.groupingBy(SubWorkStreamResourceCost::getVendor))));
    }


    public void getYearlyResourceSummary(String subWorkStreamId, String subWorkStreamName, String scenario,
                                         String currencyCode, CostTypeCategoryView costTypeCategoryView) {

        BigDecimal manDaysConfig = BigDecimal.valueOf(costSettingService.getFDManDaysPerMonth());


        Map<String, BigDecimal> yearlyFTEType = new HashMap<>();
        Map<String, BigDecimal> yearlyMandaysType = new HashMap<>();
        Map<String, BigDecimal> yearlyCostType = new HashMap<>();

        BigDecimal fteOverAllYears = BigDecimal.ZERO;
        BigDecimal manDaysOverAllYears = BigDecimal.ZERO;
        BigDecimal costOverAllYears = BigDecimal.ZERO;


        List<String> listOfYears = subWorkStreamResourceCostRepo.findDistinctOfPeriodsFromSoftwareCostAndOtherSoftwareCost(subWorkStreamId, subWorkStreamName, scenario);


        for (String year : listOfYears) {
            BigDecimal fteypeTotalYear = BigDecimal.ZERO;
            BigDecimal manDaysTotalYear = BigDecimal.ZERO;
            BigDecimal costTypeTotalYear = BigDecimal.ZERO;

            List<SubWorkStreamResourceCost> subWorkStreamResourceCostList = getBySubWorkStreamResourcesList(subWorkStreamId, subWorkStreamName, year, scenario);
            List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            portfolioRepository.getSubworkstreamResourceHeaderRowByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, year, scenario,
                                    "financialResourceHeaderSummaryByPeriodAndGroupCcy", PortfolioConstants.RESOURCE)
                            : portfolioRepository.getSubworkstreamResourceHeaderRowByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, year, scenario,
                            "financialResourceHeaderSummaryByPeriodAndLocalCcy", PortfolioConstants.RESOURCE);

            //for (SubWorkStreamResourceCost subWorkStreamSoftwareCost : subWorkStreamSoftwareCostList) {
            for (int index = 0; index < consolidatedFinancialSummary.size(); index++) {
                SubWorkStreamResourceCost subWorkStreamSoftwareCost = null;
                if (null != subWorkStreamResourceCostList && !subWorkStreamResourceCostList.isEmpty() && index < subWorkStreamResourceCostList.size()) {
                    subWorkStreamSoftwareCost = subWorkStreamResourceCostList.get(index);
                } else {
                    subWorkStreamSoftwareCost = new SubWorkStreamResourceCost();
                }
                FinancialSummaryResource financialSummaryResource = consolidatedFinancialSummary.get(index);

                fteypeTotalYear = fteypeTotalYear.add(subWorkStreamSoftwareCost.getFte());

                //manDaysTotalYear = manDaysTotalYear.add(manDaysConfig);

                manDaysTotalYear = BigDecimal.ZERO;

                //costTypeTotalYear = costTypeTotalYear.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                //        subWorkStreamSoftwareCost.getBlendedCostGroupCcy() : subWorkStreamSoftwareCost.getBlendedCostLocalCcy());
                costTypeTotalYear = costTypeTotalYear.add(financialSummaryResource.getCurrencyValue());

            }
            yearlyFTEType.put(year, fteypeTotalYear);
            yearlyMandaysType.put(year, manDaysTotalYear);
            yearlyCostType.put(year, costTypeTotalYear);

            fteOverAllYears = fteOverAllYears.add(fteypeTotalYear);
            manDaysOverAllYears = manDaysOverAllYears.add(manDaysTotalYear);
            costOverAllYears = costOverAllYears.add(costTypeTotalYear);
            //BigDecimal softwareYearlySum = breakDownCostOthersService.getOthersByYearlySum(subWorkStreamId, subWorkStreamName, scenario, year, PortfolioConstants.SOFTWARE_TYPE, currencyCode);
            //totalYearSum = totalYearSum.add(softwareYearlySum);
            //totalYearSumMap.put(year, totalYearSum);
        }
        costTypeCategoryView.setYearlyFTEType(yearlyFTEType);
        costTypeCategoryView.setYearlyMandaysType(yearlyMandaysType);
        costTypeCategoryView.setYearlyCostType(yearlyCostType);

        List<BigDecimal> overAllData = new ArrayList<>();
        overAllData.add(fteOverAllYears);
        overAllData.add(BigDecimal.ZERO);
        overAllData.add(costOverAllYears);

        costTypeCategoryView.setCostTypeOverAllTotalResource(overAllData);

    }


}
