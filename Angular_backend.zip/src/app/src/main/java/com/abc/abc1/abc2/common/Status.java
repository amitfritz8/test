package com.dbs.genesis.portfolio.common;

public enum Status {
    ACTIVE("ACTIVE");
    private final String status;
    Status(String status) {
        this.status = status;
    }
    public String getStatus() {
        return this.status;
    }
}
