package com.dbs.genesis.portfolio.service.financials;

import com.dbs.genesis.portfolio.common.CommonFinancialTypes;
import com.dbs.genesis.portfolio.model.DataValues;
import com.dbs.genesis.portfolio.model.SubWorkstreamFinDetailsEntity;
import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.repository.SubWorkstreamFinDetailsRepo;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

@Slf4j
@Service
public class FinancialBreakDownCostService implements CommonFinancialTypes {

    private  final DataSummaryService dataSummaryService;
    private final SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo;
    private final PortfolioRepository portfolioRepository;
    private final FinancialService financialService;
    private final BreakDownCostSoftwareService breakDownCostSoftwareService;

    @Autowired
    public FinancialBreakDownCostService(DataSummaryService dataSummaryService, SubWorkstreamFinDetailsRepo
            subWorkstreamFinDetailsRepo, PortfolioRepository portfolioRepository, FinancialService financialService,
                                         BreakDownCostSoftwareService breakDownCostSoftwareService) {
        this.dataSummaryService = dataSummaryService;
        this.subWorkstreamFinDetailsRepo = subWorkstreamFinDetailsRepo;
        this.portfolioRepository = portfolioRepository;
        this.financialService = financialService;
        this.breakDownCostSoftwareService = breakDownCostSoftwareService;
    }

    public Map<String,FinancialBreakDownCostView>  getBreakDownCostData(String scenario, String currencyCode,String workStreamId,String
            subWorkStreamId, String subWorkStreamName,String period,String periodType) {

        Map<String,FinancialBreakDownCostView> financialBreakDownCostViewMap = new TreeMap<>();
        FinancialBreakDownCostView breakDownCostView = new FinancialBreakDownCostView();
        try{
            List<DataValues> costSettings =  dataSummaryService.getDataValuesBySummary(PortfolioConstants.COST_SETTINGS);
            List<String> costTypes = getCostTypes();
            List<CostSettingsView> individualCostTypeData = getIndividualCostTypeData(costSettings, costTypes, workStreamId,
                    subWorkStreamId, subWorkStreamName, period, periodType,scenario,currencyCode);
            breakDownCostView.setName("Breakdown By Cost Type");
            breakDownCostView.setCostSettingsViewList(individualCostTypeData);
            financialBreakDownCostViewMap.put(scenario,breakDownCostView);
        } catch (Exception ex) {
            log.error(" Exception in breakdown cost view ",ex);
        }
        return financialBreakDownCostViewMap;
    }

    private List<CostSettingsView> getIndividualCostTypeData(List<DataValues> costSettings, List<String>
            costTypes, String workStreamId, String subWorkStreamId, String subWorkStreamName, String period, String
                                                                     periodType, String scenario, String currencyCode) {

        List<CostSettingsView> costSettingsViewList = new ArrayList<>();
        costSettings.forEach(costSetting -> {
            String costSettingValue = costSetting.getValue();
            if (PortfolioConstants.COST_SETTING_TYPE_SEED_FUNDING.equalsIgnoreCase(costSettingValue)) {
                CostSettingsView costSettingForSeedFunding = getCostSettingForSeedFunding(costTypes, workStreamId,
                        subWorkStreamId, subWorkStreamName, period, periodType, scenario, costSettingValue,currencyCode);
                costSettingsViewList.add(costSettingForSeedFunding);
            } if (PortfolioConstants.COST_SETTING_TYPE_HLE.equalsIgnoreCase(costSettingValue)) {
                CostSettingsView costSettingForHLE = getCostSettingForHLE(costTypes, workStreamId,
                        subWorkStreamId, subWorkStreamName, period, periodType, scenario, costSettingValue,currencyCode);
                costSettingsViewList.add(costSettingForHLE);

            }

            if (PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS.equalsIgnoreCase(costSettingValue)) {

                CostSettingsView costSettingForFinancialDetails = breakDownCostSoftwareService.getCostSettingForFinancialDetails(
                        costTypes, subWorkStreamId, subWorkStreamName, period, periodType, costSettingValue,scenario,currencyCode);
                costSettingsViewList.add(costSettingForFinancialDetails);
            }
        } );
        return costSettingsViewList;
    }

    private CostSettingsView getCostSettingForHLE(List<String> costTypes, String workStreamId, String subWorkStreamId,
                                                  String subWorkStreamName, String period, String costSettingType,
                                                  String scenario, String costSettingValue, String currencyCode) {

        CostSettingsView costSettingsView = null;

        if(PortfolioConstants.MONTHLY.equalsIgnoreCase(costSettingType)) {
            costSettingsView = getCostSettingsByMonthly(costTypes, workStreamId, subWorkStreamId, subWorkStreamName,
                    period, costSettingValue,PortfolioConstants.COST_SETTING_TYPE_HLE,scenario, currencyCode);
        } if(PortfolioConstants.QUARTERLY.equalsIgnoreCase(costSettingType)) {
            costSettingsView = getCostSettingsByQuarterly(workStreamId, subWorkStreamId, subWorkStreamName, scenario,
                    costSettingValue,costTypes, currencyCode);
        }
        if (PortfolioConstants.YEARLY.equalsIgnoreCase(costSettingType)) {
            costSettingsView = getCostSettingsByYearly(costTypes, workStreamId, subWorkStreamId, subWorkStreamName,
                    scenario, costSettingValue, currencyCode);
        }

        return costSettingsView;
    }

    private CostSettingsView getCostSettingForSeedFunding(List<String> costTypes, String workStreamId, String
            subWorkStreamId, String subWorkStreamName, String period, String costSettingType, String scenario,
                                                          String costSettingValue, String currencyCode) {

        CostSettingsView costSettingsView = null;
        if(PortfolioConstants.MONTHLY.equalsIgnoreCase(costSettingType)) {
            costSettingsView = getCostSettingsByMonthly(costTypes, workStreamId, subWorkStreamId, subWorkStreamName,
                    period, costSettingValue, PortfolioConstants.COST_SETTING_TYPE_SEED_FUNDING,scenario,currencyCode);
        }
        if(PortfolioConstants.QUARTERLY.equalsIgnoreCase(costSettingType)) {
            costSettingsView = getCostSettingsByQuarterly(workStreamId, subWorkStreamId, subWorkStreamName, scenario,
                    costSettingValue,costTypes,currencyCode);
        }
        if (PortfolioConstants.YEARLY.equalsIgnoreCase(costSettingType)) {
            costSettingsView = getCostSettingsByYearly(costTypes, workStreamId, subWorkStreamId, subWorkStreamName,
                    scenario, costSettingValue,currencyCode);
        }
        return costSettingsView;
    }

    private CostSettingsView getCostSettingsByYearly(List<String> costTypes, String workStreamId, String
            subWorkStreamId, String subWorkStreamName, String scenario, String costSettingValue, String currencyCode) {
        CostSettingsView costSettingsView = new CostSettingsView();
        costSettingsView.setName(costSettingValue);
        List<CostTypeCategoryView> costTypeCategoryViewList = new ArrayList<>();
        Map<String, BigDecimal> yearlyFinSummary = new HashMap<>();
        BigDecimal completeTotalYearsAmount = BigDecimal.ZERO;
        List<BigDecimal> yearlySum = new ArrayList<>();

        List<String> financialYearsByCostSetting = subWorkstreamFinDetailsRepo.getListOfFinancialYearsByCostSetting(
                        workStreamId, subWorkStreamId,subWorkStreamName,scenario, costSettingValue);
        for (String year : financialYearsByCostSetting) {
            List<FinancialSummaryResource> yearlySumForSeedFunding =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    portfolioRepository.getYearlySumForCostTypeByGroupCurrency(workStreamId, subWorkStreamId, subWorkStreamName, year, costSettingValue,scenario,
                            PortfolioConstants.ORIGINAL_INDICATOR_FALSE)
                    : portfolioRepository.getYearlySumForCostTypeByLocalCurrency(workStreamId, subWorkStreamId, subWorkStreamName, year, costSettingValue,scenario,
                            PortfolioConstants.ORIGINAL_INDICATOR_FALSE);
            yearlySumForSeedFunding.forEach(financialSummaryResource -> {
                if(financialSummaryResource.getCurrencyValue() != null &&
                        financialSummaryResource.getCurrencyValue().intValue() !=0) {
                    yearlyFinSummary.put(year,financialSummaryResource.getCurrencyValue());
                }
                yearlySum.add(financialSummaryResource.getCurrencyValue());
            });
        }
        if(!yearlySum.isEmpty()) {
            completeTotalYearsAmount = completeTotalYearsAmount.add(yearlySum.stream().reduce(BigDecimal::add)
                    .orElse(BigDecimal.ZERO));
        }
        costSettingsView.setYearlyCostSettings(yearlyFinSummary);
        costSettingsView.setCostSettingsOverAllTotal(completeTotalYearsAmount);
        costTypes.forEach(costType -> costTypeCategoryViewList.add(
                getYearlyDataBasedOnCategoryByCostType(costSettingValue,
                costType, workStreamId, subWorkStreamId,subWorkStreamName,scenario,currencyCode)));
        costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);
        return costSettingsView;
    }

    private CostTypeCategoryView getYearlyDataBasedOnCategoryByCostType(String costSettingValue, String costType,
                                                                        String workStreamId, String subWorkStreamId,
                                                                        String subWorkStreamName, String scenario, String currencyCode) {
        Map<String,BigDecimal> yearlyFinanceSummary = new HashMap<>();
        List<BigDecimal> overAllTotal = new ArrayList<>();
        BigDecimal overAllYearsTotal = BigDecimal.ZERO;
        List<String> financialYearsByCostSetting = subWorkstreamFinDetailsRepo.
                getListOfFinancialYearsByCostSetting(
                        workStreamId, subWorkStreamId,subWorkStreamName,scenario, costSettingValue);

        for (String costSettingYear : financialYearsByCostSetting) {
            BigDecimal calculateTotalAmount = BigDecimal.ZERO;
            List<SubWorkstreamFinDetailsEntity> finDetailsEntityList = getSubWorkStreamFinDetailsList(costSettingValue,
                    costType, workStreamId, subWorkStreamId, subWorkStreamName, costSettingYear,scenario);
            List<BigDecimal> bigDecimalList = new ArrayList<>();
            for (SubWorkstreamFinDetailsEntity subWorkStreamFinDetailsEntity : finDetailsEntityList) {

                if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) && subWorkStreamFinDetailsEntity.getGroupCcyVal() != null &&
                        subWorkStreamFinDetailsEntity.getGroupCcyVal().intValue() !=0) {
                    BigDecimal groupCcyVal = subWorkStreamFinDetailsEntity.getGroupCcyVal();
                    bigDecimalList.add(groupCcyVal);

                }else{
                    if(subWorkStreamFinDetailsEntity.getLocalCcyVal() != null &&
                            subWorkStreamFinDetailsEntity.getLocalCcyVal().intValue() !=0){
                        BigDecimal localCcyVal = subWorkStreamFinDetailsEntity.getLocalCcyVal();
                        bigDecimalList.add(localCcyVal);
                    }
                }
            }
            if (!bigDecimalList.isEmpty()) {
                calculateTotalAmount = calculateTotalAmount.add(bigDecimalList.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
            }
            yearlyFinanceSummary.put(costSettingYear,calculateTotalAmount);
            overAllTotal.add(calculateTotalAmount);
        }
        if (!overAllTotal.isEmpty()) {
            overAllYearsTotal = overAllYearsTotal.add(overAllTotal.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        }

        return getCostTypeCategoryResource(costType,
                Arrays.asList(BigDecimal.ZERO), new TreeMap() ,yearlyFinanceSummary,overAllYearsTotal,BigDecimal.ZERO,
                new HashMap<>());
    }

    private List<SubWorkstreamFinDetailsEntity> getSubWorkStreamFinDetailsList(String costSettingValue, String costType,
                                                                               String workStreamId, String subWorkStreamId, String subWorkStreamName, String costSettingYear,String scenario) {
        return subWorkstreamFinDetailsRepo.
                findByCostSettingAndWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndCostTypeAndOrgIndAndPeriodContainingAndScenario(
                        costSettingValue, workStreamId, subWorkStreamId, subWorkStreamName, costType,PortfolioConstants.FALSE, costSettingYear,scenario);
    }

    private CostSettingsView getCostSettingsByQuarterly(String workStreamId, String subWorkStreamId,
                                                        String subWorkStreamName, String scenario, String costSettingName,
                                                        List<String> costTypes, String currencyCode) {
        CostSettingsView costSettingsView = new CostSettingsView();
        costSettingsView.setName(costSettingName);
        List<CostTypeCategoryView> costTypeCategoryViewList = new ArrayList<>();
        Map<String, List<BigDecimal>> quarterlyCostSettings = new HashMap<>();
        Map<String,BigDecimal> costSettingsQuarterlyDataPerYear = new HashMap<>();
        List<List<BigDecimal>> consolidatedQuarterlyOverAllSum = new ArrayList<>();
        BigDecimal totalOverAllQuarterlySum = BigDecimal.ZERO;
        List<BigDecimal> quarterlySummaryList = new ArrayList<>();
        List<String> financialYearsByCostSetting = subWorkstreamFinDetailsRepo.getListOfFinancialYearsByCostSetting(
                workStreamId, subWorkStreamId,subWorkStreamName,scenario, costSettingName);

        for (String year : financialYearsByCostSetting) {
            List<FinancialSummaryResource> finSummaryByCostSetting =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    portfolioRepository.getFinSummaryForCostSettingsByGroupCurrency(
                    workStreamId, subWorkStreamId, subWorkStreamName, year,costSettingName,scenario,PortfolioConstants.ORIGINAL_INDICATOR_FALSE)
                    : portfolioRepository.getFinSummaryForCostSettingsByLocalCurrency(
                            workStreamId, subWorkStreamId, subWorkStreamName, year,costSettingName,scenario,PortfolioConstants.ORIGINAL_INDICATOR_FALSE);
            quarterlySummaryList = financialService.getQuarterlySummaryListData(finSummaryByCostSetting);
            quarterlyCostSettings.put(year, quarterlySummaryList);
            consolidatedQuarterlyOverAllSum.add(quarterlySummaryList);
        }
        quarterlyCostSettings.forEach((year, bigDecimals) -> {
            costSettingsQuarterlyDataPerYear.put(year,bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        });
        if (!quarterlySummaryList.isEmpty()) {
            for (List<BigDecimal> list: consolidatedQuarterlyOverAllSum){
                totalOverAllQuarterlySum = totalOverAllQuarterlySum.add(list.stream().reduce(BigDecimal::add)
                        .orElse(BigDecimal.ZERO));
            }
            costSettingsView.setCostSettingsOverAllTotal(totalOverAllQuarterlySum);
        }
        costSettingsView.setQuarterlyCostSettings(quarterlyCostSettings);
        costSettingsView.setIndividualYearSummaryForQuarterly(costSettingsQuarterlyDataPerYear);
        costTypes.forEach(costType -> {
            costTypeCategoryViewList.add(getQuarterlySummaryForCostSettingByCostType(costSettingName,
                    costType, workStreamId, subWorkStreamId,subWorkStreamName,scenario,currencyCode));
        });
        costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);
        return costSettingsView;
    }

    private CostTypeCategoryView getQuarterlySummaryForCostSettingByCostType(String costSetting, String costType,
                                                                             String workStreamId,
                                                                             String subWorkStreamId,
                                                                             String subWorkStreamName,
                                                                             String scenario, String currencyCode) {
        Map<String, List<BigDecimal>> quarterlyMap = new HashMap<>();
        List<List<BigDecimal>> completeQuarterlySum = new ArrayList<>();
        BigDecimal totalQuarterlySum = BigDecimal.ZERO;
        Map<String,BigDecimal> individualYearSummaryForQuarterlyData = new HashMap<>();
        List<BigDecimal> quarterlyData;
        List<String> financialYearsByScenario = subWorkstreamFinDetailsRepo.getListOfFinancialYearsByCostSetting(
                workStreamId, subWorkStreamId,subWorkStreamName,scenario,costSetting);
        for (String period : financialYearsByScenario) {
            List<SubWorkstreamFinDetailsEntity> finDetailsEntityList = getSubWorkStreamFinDetailsList(costSetting,
                    costType, workStreamId, subWorkStreamId, subWorkStreamName, period,scenario);
            quarterlyData = financialService.getQuarterlyData(period, finDetailsEntityList,currencyCode);
            quarterlyMap.put(period,quarterlyData);
            completeQuarterlySum.add(quarterlyData);
        }
        for (List<BigDecimal> list: completeQuarterlySum){
            totalQuarterlySum = totalQuarterlySum.add(list.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        }
        quarterlyMap.forEach((year, bigDecimals) -> {
            individualYearSummaryForQuarterlyData.put(year,bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        });
        CostTypeCategoryView costTypeCategoryView = getCostTypeCategoryResource(costType,
                Arrays.asList(BigDecimal.ZERO), quarterlyMap,new TreeMap(),totalQuarterlySum,
                BigDecimal.ZERO, individualYearSummaryForQuarterlyData);

        return costTypeCategoryView;
    }

    private CostSettingsView getCostSettingsByMonthly(List<String> costTypes, String workStreamId, String
            subWorkStreamId, String subWorkStreamName, String period, String costSetting, String costSettingType, String scenario, String currencyCode) {

        CostSettingsView costSettingsView = new CostSettingsView();
        List<CostTypeCategoryView> costTypeCategoryViewList = new ArrayList<>();
        costSettingsView.setName(costSetting);
        List<FinancialSummaryResource> finSummaryByCostSetting =
                PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                portfolioRepository.getFinSummaryForCostSettingsByGroupCurrency(workStreamId,
                subWorkStreamId,subWorkStreamName,period,costSetting,scenario,PortfolioConstants.ORIGINAL_INDICATOR_FALSE)
                : portfolioRepository.getFinSummaryForCostSettingsByLocalCurrency(workStreamId,
                        subWorkStreamId,subWorkStreamName,period,costSetting,scenario,PortfolioConstants.ORIGINAL_INDICATOR_FALSE);
        List<BigDecimal> monthlyDataList = getMonthlyCostSettingList(finSummaryByCostSetting);
        costSettingsView.setMonthlyCostSettings(monthlyDataList);
        costSettingsView.setCostSettingsTotal(monthlyDataList.stream().reduce(BigDecimal::add)
                .orElse(BigDecimal.ZERO));
        costSettingsView.setCostSettingsOverAllTotal(
                PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                subWorkstreamFinDetailsRepo.getCostSettingsOverAllSumByGrpCcy(workStreamId,
                subWorkStreamId,subWorkStreamName, scenario, costSettingType)
                 : subWorkstreamFinDetailsRepo.getCostSettingsOverAllSumByLocalCcy(workStreamId,
                        subWorkStreamId,subWorkStreamName, scenario, costSettingType));

        List<CompletableFuture> allFutures = new ArrayList<>();

        costTypes.forEach(costType -> {
            CompletableFuture<CostTypeCategoryView> cf = CompletableFuture.supplyAsync(() -> getMonthlyDataBasedOnCategoryAndCostType(
                    costSetting, costType, workStreamId, subWorkStreamId,subWorkStreamName,period,scenario,currencyCode, costSetting));
            allFutures.add(cf);
        });

        CompletableFuture.allOf(allFutures.stream().toArray(CompletableFuture[]::new))
                .whenComplete((v, th) -> {
                    allFutures.forEach(cf -> costTypeCategoryViewList.add((CostTypeCategoryView)cf.getNow(new CostTypeCategoryView())));
                }).join();

        costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);
        return costSettingsView;
    }

    private List<BigDecimal> getMonthlyCostSettingList(List<FinancialSummaryResource> finSummaryForCostInput) {
        return getCostSettingMonthlyData(finSummaryForCostInput);
    }



    private List<BigDecimal> getMonthlyCostTypeList(List<SubWorkstreamFinDetailsEntity>
                                                            subWorkStreamFinDetailsEntityList, String currencyCode) {
        return financialService.getMonthlyData(subWorkStreamFinDetailsEntityList,currencyCode);
    }

    private CostTypeCategoryView getMonthlyDataBasedOnCategoryAndCostType(String costCategory, String costType,
                                                                          String workStreamId, String subWorkStreamId,
                                                                          String subWorkStreamName, String period, String scenario, String currencyCode, String costSetting) {

        List<SubWorkstreamFinDetailsEntity> finDetailsEntityList = getSubWorkStreamFinDetailsList(costCategory,
                costType, workStreamId, subWorkStreamId, subWorkStreamName, period,scenario);
        List<BigDecimal> monthlyDataList = getMonthlyCostTypeList(finDetailsEntityList,currencyCode);

        List<MonthlyResource> monthlyDataByObject = financialService.getMonthlyDataByObject(finDetailsEntityList,currencyCode);

        BigDecimal costTypeOverAllSum=BigDecimal.ZERO;
        if(costSetting.equalsIgnoreCase(PortfolioConstants.COST_SETTING_TYPE_HLE)) {
            List<SubWorkstreamFinDetailsEntity> subWorkstreamFinDetailsEntityList = subWorkstreamFinDetailsRepo.findByWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndScenarioAndCostTypeAndCostSettingAndOrgInd(
                    workStreamId, subWorkStreamId, subWorkStreamName, scenario, costType, PortfolioConstants.COST_SETTING_TYPE_HLE, PortfolioConstants.TRUE);
            for (SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity : subWorkstreamFinDetailsEntityList) {
                costTypeOverAllSum = costTypeOverAllSum.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        subWorkstreamFinDetailsEntity.getGroupCcyVal(): subWorkstreamFinDetailsEntity.getLocalCcyVal());
            }
        }else if(costSetting.equalsIgnoreCase(PortfolioConstants.COST_SETTING_TYPE_SEED_FUNDING)){

            costTypeOverAllSum = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    subWorkstreamFinDetailsRepo.getCostTypeOverAllSumByGrpCcy(workStreamId, subWorkStreamId,
                            subWorkStreamName, scenario, PortfolioConstants.DEFAULT_SEED_FUNDING_CATEGORY, costType, costCategory)
                    : subWorkstreamFinDetailsRepo.getCostTypeOverAllSumByLocalCcy(workStreamId, subWorkStreamId,
                    subWorkStreamName, scenario, PortfolioConstants.DEFAULT_SEED_FUNDING_CATEGORY, costType, costCategory);
        }

        BigDecimal costTypeTotal = monthlyDataList.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO);

        CostTypeCategoryView costTypeCategoryView = new CostTypeCategoryView();
        costTypeCategoryView.setName(costType);
        costTypeCategoryView.setMonthlyCostTypes(monthlyDataList);
        costTypeCategoryView.setCostTypeTotal(costTypeTotal);
        costTypeCategoryView.setCostTypeOverAllTotal(costTypeOverAllSum);
        costTypeCategoryView.setMonthlyResources(monthlyDataByObject);
        return costTypeCategoryView;
    }


    private CostTypeCategoryView getCostTypeCategoryResource(String costType, List<BigDecimal> monthly,
                                                             Map<String,List<BigDecimal>> quarterly,
                                                             Map<String,BigDecimal> yearly,
                                                             BigDecimal costTypeTotal, BigDecimal costTypeOverAllSum,
                                                             Map<String,BigDecimal> individualYearSummaryForQuarterly) {
        CostTypeCategoryView costTypeCategoryView = new CostTypeCategoryView();
        costTypeCategoryView.setName(costType);
        costTypeCategoryView.setMonthlyCostTypes(monthly);
        costTypeCategoryView.setQuarterlyCostType(quarterly);
        costTypeCategoryView.setYearlyCostType(yearly);
        costTypeCategoryView.setCostTypeTotal(costTypeTotal);
        costTypeCategoryView.setCostTypeOverAllTotal(costTypeTotal);
        costTypeCategoryView.setIndividualYearSummaryForQuarterly(individualYearSummaryForQuarterly);
        return costTypeCategoryView;
    }

    private List<String> getCostTypes() {
        List<DataValues> dataValuesList = dataSummaryService.getDataValuesBySummary(PortfolioConstants.COST_TYPE);
        dataValuesList.sort(Comparator.comparing(DataValues::getAttr1));
        return dataValuesList.stream().map(DataValues::getValue).collect(Collectors.toList());
    }
}
