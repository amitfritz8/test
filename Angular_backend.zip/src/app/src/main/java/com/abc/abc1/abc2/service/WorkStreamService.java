package com.dbs.genesis.portfolio.service;


import com.dbs.genesis.portfolio.client.WorkStreamOCLAClient;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.*;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.service.financials.FinancialService;
import com.dbs.genesis.portfolio.service.workstream.WorkStreamBreakDownCostService;
import com.dbs.genesis.portfolio.service.workstream.WorkStreamBreakDownFinancialService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.transaction.Transactional;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@Transactional
public class WorkStreamService {

    private final WorkStreamRepo workStreamRepo;
    private final WorkStreamEntityMgr workStreamEntityMgr;
    private final PortfolioRepo portfolioRepo;
    private final WorkHierarchyRepo workHierarchyRepo;
    private final WorkStreamManagersRepo workStreamManagersRepo;
    private final SubWorkStreamManagersRepo subWorkStreamManagersRepo;
    private final WorkStreamKeyDatesRepo workStreamKeyDatesRepo;
    private final PortfolioRepository portfolioNativeRepository;
    private final SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    private final SubWorkStreamRepo subWorkStreamRepo;
    private final DataSummaryService dataSummaryService;
    private final WorkStreamApproverRepo workStreamApproverRepo;
    private final WorkStreamApproverRepo workStreamApproversRepository;
    private final SubWorkStreamApprovesRepo subWorkStreamApprovesRepo;
    private final PortFolioWorkStreamAndSubWorkStreamGenerator portFolioWorkStreamAndSubWorkStreamGenerator;
    private final WorkstreamLePccodesRepo workstreamLePccodesRepo;
    private final WorkStreamBreakDownFinancialService workStreamBreakDownFinancialService;
    private final WorkStreamBreakDownCostService workStreamBreakDownCostService;
    private final WorkStreamOCLAClient workStreamOCLAClient;
    private final ApplicationEventPublisher publisher;

    @Autowired
    private FinancialService financialService;
    @Autowired
    private EditLogRepo editLogRepo;


    @Autowired
    public WorkStreamService(PortfolioRepo portfolioRepo, WorkStreamRepo workStreamRepo, WorkStreamEntityMgr workStreamEntityMgr, WorkHierarchyRepo workHierarchyRepo,
                             WorkStreamManagersRepo workStreamManagersRepo, SubWorkStreamManagersRepo subWorkStreamManagersRepo,
                             WorkStreamKeyDatesRepo workStreamKeyDatesRepo, WorkStreamApproverRepo workStreamApproversRepository,
                             PortfolioRepository portfolioNativeRepository, PortFolioWorkStreamAndSubWorkStreamGenerator
                                     portFolioWorkStreamAndSubWorkStreamGenerator, SubWorkStreamKeyDatesRepo
                                     subWorkStreamKeyDatesRepo, SubWorkStreamRepo subWorkStreamRepo, SubWorkStreamApprovesRepo
                                     subWorkStreamApprovesRepo, DataSummaryService dataSummaryService, WorkstreamLePccodesRepo
                                     workstreamLePccodesRepo, WorkStreamApproverRepo workStreamApproverRepo,
                             WorkStreamBreakDownFinancialService workStreamBreakDownFinancialService,
                             WorkStreamBreakDownCostService workStreamBreakDownCostService,
                             WorkStreamOCLAClient workStreamOCLAClient,
                             ApplicationEventPublisher publisher) {
        this.portfolioRepo = portfolioRepo;
        this.workStreamRepo = workStreamRepo;
        this.workStreamEntityMgr = workStreamEntityMgr;
        this.workHierarchyRepo = workHierarchyRepo;
        this.workStreamManagersRepo = workStreamManagersRepo;
        this.subWorkStreamManagersRepo = subWorkStreamManagersRepo;
        this.workStreamKeyDatesRepo = workStreamKeyDatesRepo;
        this.workStreamApproversRepository = workStreamApproversRepository;
        this.portfolioNativeRepository = portfolioNativeRepository;
        this.portFolioWorkStreamAndSubWorkStreamGenerator = portFolioWorkStreamAndSubWorkStreamGenerator;
        this.subWorkStreamKeyDatesRepo = subWorkStreamKeyDatesRepo;
        this.subWorkStreamRepo = subWorkStreamRepo;
        this.subWorkStreamApprovesRepo = subWorkStreamApprovesRepo;
        this.dataSummaryService = dataSummaryService;
        this.workstreamLePccodesRepo = workstreamLePccodesRepo;
        this.workStreamApproverRepo = workStreamApproverRepo;
        this.workStreamBreakDownFinancialService = workStreamBreakDownFinancialService;
        this.workStreamBreakDownCostService = workStreamBreakDownCostService;
        this.workStreamOCLAClient = workStreamOCLAClient;
        this.publisher = publisher;
    }

    static SubWorkStreamKeyDatesResource getSubWorkStreamKeyDatesResource(SubWorkStreamKeyDatesEntity basedOnWorkStreamId,
                                                                          SubWorkStreamRepo subWorkStreamRepo) {
        List<SubWorkStreamEntity> subWorkStreamEntityList = subWorkStreamRepo.findByWorkStreamId(basedOnWorkStreamId.getWorkStreamId());
        SubWorkStreamKeyDatesResource subWorkStreamKeyDatesResource = new SubWorkStreamKeyDatesResource();
        subWorkStreamEntityList.stream().filter(subWorkStreamEntity -> Objects.nonNull(subWorkStreamEntity)).forEach(subWorkStreamEntity -> {
            if (basedOnWorkStreamId.getSubWorkStreamId().equalsIgnoreCase(subWorkStreamEntity.getSubWorkStreamId())
            && basedOnWorkStreamId.getSubWorkStreamName().equalsIgnoreCase(subWorkStreamEntity.getSubWorkStreamName())) {
                subWorkStreamKeyDatesResource.setSubWorkStreamName(subWorkStreamEntity.getSubWorkStreamName());
                subWorkStreamKeyDatesResource.setWorkStreamId(basedOnWorkStreamId.getWorkStreamId());
                subWorkStreamKeyDatesResource.setSubWorkStreamId(basedOnWorkStreamId.getSubWorkStreamId());
                subWorkStreamKeyDatesResource.setActiveInd(basedOnWorkStreamId.getActiveInd());
                subWorkStreamKeyDatesResource.setApprovedDate(basedOnWorkStreamId.getApprovalDate());
                subWorkStreamKeyDatesResource.setEndDate(basedOnWorkStreamId.getEndDate());
                subWorkStreamKeyDatesResource.setSwEngStartDate(basedOnWorkStreamId.getSwEngStartDate());
                subWorkStreamKeyDatesResource.setGoLiveDate(basedOnWorkStreamId.getGoLiveDate());
                subWorkStreamKeyDatesResource.setStartDate(basedOnWorkStreamId.getStartDate());
                subWorkStreamKeyDatesResource.setScenarioName(basedOnWorkStreamId.getScenarioName());
                subWorkStreamKeyDatesResource.setSwsDateSurrId(basedOnWorkStreamId.getSwsDateSurrId());
            }
        });

        return subWorkStreamKeyDatesResource;
    }

    public WorkStreamEntity saveWorkStreamData(String portfolioId, String portfolioName,
                                               WorkStreamEntity workStreamEntity, String loggedInUserBankid) {
        String country = workStreamEntity.getCountry();
        String year = portfolioId.substring(portfolioId.indexOf("-") + 1).substring(0, 2).trim();
        String workType = portfolioId.substring(portfolioId.lastIndexOf('-') + 1);
        String workStreamId = portFolioWorkStreamAndSubWorkStreamGenerator.generateWorkStreamID(portfolioId, country,
                year, workType);
        //saveWorkHierarchy(portfolioId, portfolioName, workStreamEntity, workStreamId);
        saveWorkStreamEntity(portfolioId, workStreamEntity, workStreamId);
        saveDefaultSubWorkStreams(workStreamEntity);
        log.info("Auto email Trigger for Project ID Creation");
        if (workStreamEntity.getPortfolioId().endsWith("I")) {
            publisher.publishEvent(new FinSysProjectIdCreationEvent(workStreamEntity, loggedInUserBankid));
        }
        return workStreamEntity;
    }

    private void saveDefaultSubWorkStreams(WorkStreamEntity workStreamEntity) {

        PortfolioCreationEvent portfolioCreationEvent = new PortfolioCreationEvent();
        String workType = workStreamEntity.getPortfolioId().substring(workStreamEntity.getPortfolioId().length() - 1);
        String initialYear = workStreamEntity.getPortfolioId().substring(workStreamEntity.getPortfolioId().indexOf(PortfolioConstants.HYPHEN) + 1).substring(0, 2);
        SubWorkStream subWorkStream = new SubWorkStream();
        PortfolioEntity portfolioEntity = portfolioRepo.findByPortfolioId(workStreamEntity.getPortfolioId());
        subWorkStream.setDeliveryPlatformUnit(portfolioEntity.getPrimaryPlatformName());
        subWorkStream.setSubWorkStreamName(PortfolioConstants.DEFAULT_SWS + PortfolioConstants.HYPHEN + workStreamEntity.getWorkStreamName());

        portfolioCreationEvent.setInitiationYear(initialYear);
        portfolioCreationEvent.setWorkType(workType);
        portfolioCreationEvent.setPrimaryPlatformName(portfolioEntity.getPrimaryPlatformName());

        SubWorkStreamEntity defaultSubWorkStreamEntity =
                portFolioWorkStreamAndSubWorkStreamGenerator.getSubWorkStreamEntity(workStreamEntity,
                        portfolioCreationEvent, subWorkStream);
        SubWorkStreamEntity subWorkStreamEntitySaved = subWorkStreamRepo.save(defaultSubWorkStreamEntity);
        saveWorkHierarchyForSubWorkStream(portfolioEntity.getPortfolioId(), portfolioEntity.getPortfolioName(), workStreamEntity, subWorkStreamEntitySaved);
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity =
                portFolioWorkStreamAndSubWorkStreamGenerator.createDefaultKeyDates(subWorkStreamEntitySaved);
        subWorkStreamKeyDatesRepo.save(subWorkStreamKeyDatesEntity);


    }

    private void saveWorkHierarchyForSubWorkStream(String portfolioId, String portfolioName, WorkStreamEntity workStreamEntity, SubWorkStreamEntity subWorkStreamEntitySaved) {
        WorkHierarchyEntity workHierarchyEntity = new WorkHierarchyEntity();
        workHierarchyEntity.setPortfolioId(portfolioId);
        workHierarchyEntity.setPortfolioName(portfolioName);
        workHierarchyEntity.setWorkStreamId(workStreamEntity.getWorkStreamId());
        workHierarchyEntity.setWorkStreamName(workStreamEntity.getWorkStreamName());
        workHierarchyEntity.setSubWorkStreamId(subWorkStreamEntitySaved.getSubWorkStreamId());
        workHierarchyEntity.setSubWorkStreamName(subWorkStreamEntitySaved.getSubWorkStreamName());
        workHierarchyRepo.save(workHierarchyEntity);
    }

    private void saveWorkStreamEntity(String portfolioId, WorkStreamEntity WorkStreamEntity,
                                      String workStreamId) {
        WorkStreamEntity.setWorkStreamId(workStreamId);
        WorkStreamEntity.setPortfolioId(portfolioId);
        workStreamRepo.save(WorkStreamEntity);
    }

    private String getWorkStreamId(String portfolioId, String country) {
        String workStreamSequenceNumber = portfolioNativeRepository.getWorkStreamSequence();
        return portfolioId.substring(0, portfolioId.indexOf("-")).trim() +
                country + portfolioId.
                substring(portfolioId.indexOf("-")) + workStreamSequenceNumber;
    }

    private void saveWorkHierarchy(String portfolioId, String portfolioName, WorkStreamEntity workStreamEntity,
                                   String workStreamId) {
        WorkHierarchyEntity workHierarchyEntity = new WorkHierarchyEntity();
        workHierarchyEntity.setPortfolioId(portfolioId);
        workHierarchyEntity.setPortfolioName(portfolioName);
        workHierarchyEntity.setWorkStreamId(workStreamId);
        workHierarchyEntity.setWorkStreamName(workStreamEntity.getWorkStreamName());
        workHierarchyRepo.save(workHierarchyEntity);
    }

    public List<WorkStreamEntity> getWorkStreamEntityData(String portfolioId) {
        List<WorkStreamEntity> workStreamEntityList = workStreamRepo.findByOrderByPortfolioIdDesc();
        return workStreamEntityList;
    }

    public WorkStreamEntity updateWorkStreamData(WorkStreamDataSource workStreamDataSource) {
        try {

            String countryCode = workStreamDataSource.getPortFolioWorkStreamEntity().getCountry();
            List<DataValues> dataValuesList = dataSummaryService.getDataValuesBySummary(PortfolioConstants.COUNTRY);
            for (DataValues values : dataValuesList) {
                if (StringUtils.isNotEmpty(values.toString()) && StringUtils.isNotEmpty(values.toString())) {
                    if (countryCode.equalsIgnoreCase(values.getValue())) {
                        workStreamDataSource.getPortFolioWorkStreamEntity().setCountry(values.getValue());
                    }
                }
            }
            List<WorkHierarchyEntity> workHierarchyEntities = workHierarchyRepo.findByWorkStreamId(workStreamDataSource.
                    getPortFolioWorkStreamEntity().getWorkStreamId());
            workHierarchyEntities.stream().forEach(workHierarchyEntity -> {
                if (workStreamDataSource.getPortFolioWorkStreamEntity().getWorkStreamId().
                        equalsIgnoreCase(workHierarchyEntity.getWorkStreamId())) {
                    workHierarchyEntity.setWorkStreamName(workStreamDataSource.getPortFolioWorkStreamEntity().
                            getWorkStreamName());
                    workHierarchyRepo.save(workHierarchyEntity);
                }
            });

            workStreamDataSource.getPortFolioWorkStreamEntity().setPortfolioId(workStreamDataSource.getPortfolioId());
            workStreamRepo.save(workStreamDataSource.getPortFolioWorkStreamEntity());


            if (workStreamDataSource.getPortFolioWorkStreamEntity().getWorkStreamId() != null) {
                List<WorkstreamLePccodesEntity> workstreamLePccodesEntityList = workStreamDataSource.getWorkstreamLePccodesEntities();
                workstreamLePccodesEntityList.stream().forEach(workstreamLePccodesEntity -> {
                    if (Objects.nonNull(workstreamLePccodesEntity)) {
                        if (Strings.isNotBlank(workstreamLePccodesEntity.getWorkStreamId())) {
                            if (workStreamDataSource.getPortFolioWorkStreamEntity().getWorkStreamId().
                                    equalsIgnoreCase(workstreamLePccodesEntity.getWorkStreamId())) {
                                workstreamLePccodesRepo.save(workstreamLePccodesEntity);
                            }
                        }
                    }
                });
            }

            if (workStreamDataSource.getPortFolioWorkStreamEntity().getWorkStreamId() != null) {
                List<SubWorkStreamEntity> subWorkStreamEntityList = subWorkStreamRepo.findByWorkStreamId
                        (workStreamDataSource.getPortFolioWorkStreamEntity().getWorkStreamId());
                subWorkStreamEntityList.stream().forEach(subWorkStreamEntity -> {
                    if (Objects.nonNull(subWorkStreamEntity)) {
                        if (Strings.isNotBlank(subWorkStreamEntity.getWorkStreamId())) {
                            if (workStreamDataSource.getPortFolioWorkStreamEntity().getWorkStreamId().
                                    equalsIgnoreCase(subWorkStreamEntity.getWorkStreamId())) {
                                subWorkStreamEntity.setSubPlatformName(workStreamDataSource.getPortFolioWorkStreamEntity().
                                        getSubPlatFormName());
                                subWorkStreamRepo.save(subWorkStreamEntity);
                            }
                        }
                    }
                });
            }


            if (workStreamDataSource.getWorkManagers().size() != 0 && !workStreamDataSource.getWorkManagers().
                    isEmpty()) {
                workStreamDataSource.getWorkManagers().forEach(workMangerObj -> {
                    workMangerObj.setWorkStreamId(workStreamDataSource.getPortFolioWorkStreamEntity().
                            getWorkStreamId());
                    updateWorkStreamManagerEntity(workMangerObj, workStreamDataSource.getPortfolioId());
                });
            }
            if (!workStreamDataSource.getKeyDates().isEmpty()) {
                workStreamDataSource.getKeyDates().forEach(wsKeyDates -> {
                    wsKeyDates.setPortfolioId(workStreamDataSource.getPortfolioId());
                    wsKeyDates.setWorkStreamId(workStreamDataSource.getPortFolioWorkStreamEntity().getWorkStreamId());
                    workStreamKeyDatesRepo.save(wsKeyDates);
                });
            }

            if (!workStreamDataSource.getWorkStreamApprovers().isEmpty()) {
                workStreamDataSource.getWorkStreamApprovers().forEach(workStreamApprover -> {
                    workStreamApprover.setPortfolioId(workStreamDataSource.getPortfolioId());
                    workStreamApprover.setWorkStreamId(workStreamDataSource.getPortFolioWorkStreamEntity().getWorkStreamId());
                    workStreamApproverRepo.save(workStreamApprover);
                });
            }
            WorkStreamEntity portFolioWorkStreamEntity = workStreamDataSource.getPortFolioWorkStreamEntity();
            editLogRepo.deleteByPortfolioIdAndPortfolioNameAndPortfolioType(portFolioWorkStreamEntity.getWorkStreamId(), portFolioWorkStreamEntity.getWorkStreamName(), PortfolioConstants.WORKSTREAMNAME);

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return workStreamDataSource.getPortFolioWorkStreamEntity();
    }

    public WorkStreamManagersEntity updateWorkStreamManagerEntity(WorkStreamManagersEntity managersEntity,
                                                                  String portfolioId) {

        managersEntity.setPlatformIndex(portfolioId.substring(1, portfolioId.indexOf("-")).trim());
        managersEntity.setPortfolioId(portfolioId);
        workStreamManagersRepo.save(managersEntity);
        return managersEntity;
    }

    public List<Map> getListOfWorkManagersData(String workStreamId) {
        Map<String, List<SubWorkStreamManagerResource>> subWorkStreamMap;
        Map<String, List<WorkStreamManagersResource>> workStreamManagersMap;
        List<Map> mapList = new ArrayList<>();
        List<WorkStreamManagersEntity> workStreamManagersEntityList = workStreamManagersRepo.
                findByWorkStreamIdAndActiveInd(workStreamId, "true");
        List<WorkStreamManagersResource> workStreamManagersResourceList =
                getListOfWorkStreamMangersList(workStreamManagersEntityList);
        workStreamManagersMap = workStreamManagersResourceList.stream().collect(Collectors.
                groupingBy(WorkStreamManagersResource::getWorkStreamName));
        mapList.add(workStreamManagersMap);
        List<SubWorkStreamManagersEntity> subWorkStreamManagersEntityList = subWorkStreamManagersRepo.
                findByWorkStreamIdAndActiveInd(workStreamId, "true");
        List<SubWorkStreamManagerResource> subWorkStreamManagerResourceList =
                getListOfSubWorkStreamMangerList(subWorkStreamManagersEntityList);
        subWorkStreamMap = subWorkStreamManagerResourceList.stream().collect(Collectors.groupingBy
                (SubWorkStreamManagerResource::getSubWorkStreamName));
        mapList.add(subWorkStreamMap);
        return mapList;
    }

    public List<SubWorkStreamManagerResource> getListOfSubWorkStreamMangerList
            (List<SubWorkStreamManagersEntity> subWorkStreamManagersEntityList) {
        return subWorkStreamManagersEntityList.stream().map
                (this::assembleSubWorkStreamManagerResource).collect(Collectors.toList());
    }

    private SubWorkStreamManagerResource
    assembleSubWorkStreamManagerResource(SubWorkStreamManagersEntity subWorkStreamManagersEntity) {
        SubWorkStreamEntity folioSubWorkStreamEntity = subWorkStreamRepo.findBySubWorkStreamIdAndSubWorkStreamName(
                subWorkStreamManagersEntity.getSubWorkStreamId(),subWorkStreamManagersEntity.getSubWorkStreamName());
        SubWorkStreamManagerResource subWorkStreamManagerResource =
                subWorkStreamManagersEntity.toSubWorkStreamManagerResource();
        subWorkStreamManagerResource.setSubWorkStreamName(folioSubWorkStreamEntity.getSubWorkStreamName());
        return subWorkStreamManagerResource;
    }

    private List<WorkStreamManagersResource>
    getListOfWorkStreamMangersList(List<WorkStreamManagersEntity> workStreamManagersEntityList) {
        return workStreamManagersEntityList.stream().map(streamManagersEntity -> {
            WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(streamManagersEntity.
                    getWorkStreamId());
            WorkStreamManagersResource workStreamManagersResource =
                    streamManagersEntity.toWorkStreamManagersResource();
            workStreamManagersResource.setWorkStreamName(workStreamEntity.getWorkStreamName());
            return workStreamManagersResource;
        }).collect(Collectors.toList());
    }

    public List<Map> getPortfolioKeyDatesData(String portfolioId) {

        Map<String, List<WorkStreamKeyDatesResource>> workStreamKeyDatesMap;
        List<Map> mapList = new ArrayList<>();
        List<WorkStreamKeyDatesEntity> workStreamKeyDateEntities = workStreamKeyDatesRepo.findByPortfolioIdAndActiveInd(portfolioId,
                "true");
        List<WorkStreamKeyDatesResource> workStreamKeyDatesResourceList = getKeyDatesResources(portfolioId,
                workStreamKeyDateEntities);
        workStreamKeyDatesMap = workStreamKeyDatesResourceList.stream().collect(Collectors.groupingBy(
                WorkStreamKeyDatesResource::getWorkStreamName));
        mapList.add(workStreamKeyDatesMap);
        return mapList;
    }

    private List<WorkStreamKeyDatesResource> getKeyDatesResources(String portfolioId, List<WorkStreamKeyDatesEntity>
            workStreamKeyDateEntities) {
        return workStreamKeyDateEntities.stream()
                .map(streamKeyDates -> {
                    WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(
                            streamKeyDates.getWorkStreamId());
                    WorkStreamKeyDatesResource workStreamKeyDatesResource = new WorkStreamKeyDatesResource();
                    workStreamKeyDatesResource.setPortfolioId(portfolioId);
                    workStreamKeyDatesResource.setWorkStreamId(workStreamEntity.getWorkStreamId());
                    return getKeyDatesResource(streamKeyDates, workStreamEntity, workStreamKeyDatesResource);
                })
                .collect(Collectors.toList());
    }

    public List<Map> getWorkStreamKeyDatesData(String workStreamId) {

        Map<String, List<WorkStreamKeyDatesResource>> workStreamKeyDatesMap;
        Map<String, List<SubWorkStreamKeyDatesResource>> subWorkStreamKeyDatesMap;
        List<Map> mapList = new ArrayList<>();

        List<WorkStreamKeyDatesEntity> workStreamKeyDateEntities = workStreamKeyDatesRepo.findByWorkStreamIdAndActiveInd(workStreamId,
                "true");
        List<WorkStreamKeyDatesResource> workStreamKeyDatesResourceList = getKeyDatesResourcesWorkStreamId(workStreamId,
                workStreamKeyDateEntities);
        workStreamKeyDatesMap = workStreamKeyDatesResourceList.stream().collect(Collectors.groupingBy(
                WorkStreamKeyDatesResource::getWorkStreamName));
        mapList.add(workStreamKeyDatesMap);

        List<SubWorkStreamKeyDatesEntity> subWorkStreamKeyDateEntities = subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndActiveInd(workStreamId, "true");

        List<SubWorkStreamKeyDatesResource> subWorkStreamKeyDatesResourceList = subWorkStreamKeyDateEntities.stream().map
                (this::getSubWorkStreamKeyDatesResource).collect(Collectors.toList());


        subWorkStreamKeyDatesMap = subWorkStreamKeyDatesResourceList.stream().collect(Collectors.groupingBy(
                SubWorkStreamKeyDatesResource::getSubWorkStreamName));
        mapList.add(subWorkStreamKeyDatesMap);
        return mapList;
    }

    public List<WorkStreamKeyDatesEntity> getWorkStreamForeCastKeyDates(String workStreamId) {
        List<WorkStreamKeyDatesEntity> allDates = workStreamKeyDatesRepo.findByWorkStreamIdAndActiveInd(workStreamId, "true");
        return allDates
                .stream()
                .filter(date -> PortfolioConstants.SCENARIO_FORECAST.equalsIgnoreCase(date.getScenarioName()))
                .collect(Collectors.toList());

    }

    private List<WorkStreamKeyDatesResource> getKeyDatesResourcesWorkStreamId(String workStreamId,
                                                                              List<WorkStreamKeyDatesEntity>
                                                                                      workStreamKeyDateEntities) {
        return workStreamKeyDateEntities.stream().filter(workStreamKeyDatesEntity -> Objects.nonNull(workStreamKeyDatesEntity))
                .map(streamKeyDates -> {
                    WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(
                            streamKeyDates.getWorkStreamId());
                    PortfolioEntity portfolioEntity = portfolioRepo.findByPortfolioId(streamKeyDates.getPortfolioId());
                    WorkStreamKeyDatesResource workStreamKeyDatesResource = new WorkStreamKeyDatesResource();
                    workStreamKeyDatesResource.setPortfolioId(portfolioEntity.getPortfolioId());
                    workStreamKeyDatesResource.setWorkStreamId(workStreamId);
                    return getKeyDatesResource(streamKeyDates, workStreamEntity, workStreamKeyDatesResource);
                })
                .collect(Collectors.toList());
    }

    private WorkStreamKeyDatesResource getKeyDatesResource(WorkStreamKeyDatesEntity streamKeyDates, WorkStreamEntity
            workStreamEntity, WorkStreamKeyDatesResource workStreamKeyDatesResource) {
        workStreamKeyDatesResource.setWorkStreamName(workStreamEntity.getWorkStreamName());
        workStreamKeyDatesResource.setActiveInd(streamKeyDates.getActiveInd());
        workStreamKeyDatesResource.setApprovedDate(streamKeyDates.getApprovedDate());
        workStreamKeyDatesResource.setEndDate(streamKeyDates.getEndDate());
        workStreamKeyDatesResource.setSwEngStartDate(streamKeyDates.getSwEngStartDate());
        workStreamKeyDatesResource.setGoLiveDate(streamKeyDates.getGoLiveDate());
        workStreamKeyDatesResource.setScenarioName(streamKeyDates.getScenarioName());
        workStreamKeyDatesResource.setStartDate(streamKeyDates.getStartDate());
        workStreamKeyDatesResource.setWsDateSurrId(streamKeyDates.getWsDateSurrId());
        return workStreamKeyDatesResource;
    }

    private SubWorkStreamKeyDatesResource getSubWorkStreamKeyDatesResource(SubWorkStreamKeyDatesEntity
                                                                                   subWorkStreamKeyDatesEntity1) {
        return getSubWorkStreamKeyDatesResource(subWorkStreamKeyDatesEntity1, subWorkStreamRepo);
    }

    public List<Map> getListOfWorkStreamApproves(String workStreamId) {
        Map<String, List<WorkStreamApproversResource>> listMap;
        Map<String, List<SubWorkStreamApproversResource>> stringListMap;
        List<Map> mapList = new ArrayList<>();
        List<WorkStreamApprovers> workStreamApproversList = workStreamApproversRepository.
                findByWorkStreamIdAndActiveInd(workStreamId, "true");
        List<WorkStreamApproversResource> approversResources = getApproversResource(workStreamApproversList);
        listMap = approversResources.stream().collect(Collectors.groupingBy(WorkStreamApproversResource::
                getWorkStreamName, TreeMap::new, Collectors.toList()));
        mapList.add(listMap);

        List<SubWorkStreamApprovers> subWorkStreamApproves = subWorkStreamApprovesRepo.
                findByWorkStreamIdAndActiveInd(workStreamId, "true");
        List<SubWorkStreamApproversResource> subWorkStreamApproversResources = getSubWorkStreamApproversResource
                (subWorkStreamApproves);

        stringListMap = subWorkStreamApproversResources.stream().collect(Collectors.groupingBy(SubWorkStreamApproversResource::
                getSubWorkStreamName, TreeMap::new, Collectors.toList()));
        mapList.add(stringListMap);


        return mapList;
    }

    public List<WorkStreamApproversResource> getApproversResource(List<WorkStreamApprovers> workStreamApproversList) {

        List<WorkStreamApproversResource> approversResourceList = workStreamApproversList.stream().map(
                workStreamApprovers -> {
                    String workStreamName = workStreamRepo.findByWorkStreamId(workStreamApprovers.getWorkStreamId()).
                            getWorkStreamName();
                    WorkStreamApproversResource approversResource = new WorkStreamApproversResource();
                    approversResource.setWorkStreamName(workStreamName);
                    approversResource.setAction(workStreamApprovers.getAction());
                    approversResource.setDelegateInd(workStreamApprovers.getDelegateInd());
                    approversResource.setNotifyInd(workStreamApprovers.getNotifyInd());
                    approversResource.setRole(workStreamApprovers.getRole());
                    approversResource.setScenario(workStreamApprovers.getScenario());
                    approversResource.setStaffName(workStreamApprovers.getStaffName());
                    approversResource.setWorkStreamId(workStreamApprovers.getWorkStreamId());
                    approversResource.setOneBankId(workStreamApprovers.getOneBankId());
                    approversResource.setWsApproverSurrId(workStreamApprovers.getWsApproverSurrId());
                    approversResource.setActiveInd(workStreamApprovers.getActiveInd());
                    approversResource.setEffectiveStartDate(workStreamApprovers.getEffectiveStartDate());
                    approversResource.setEffectiveEndDate(workStreamApprovers.getEffectiveEndDate());
                    return approversResource;
                }).collect(Collectors.toList());

        return approversResourceList;

    }

    private List<SubWorkStreamApproversResource> getSubWorkStreamApproversResource(List<SubWorkStreamApprovers>
                                                                                           subWorkStreamApproves) {

        List<SubWorkStreamApproversResource> approversResourceList = subWorkStreamApproves.stream().map(
                subWorkStreamApprovers -> {
                    String subWorkStreamName = subWorkStreamRepo.findBySubWorkStreamIdAndSubWorkStreamName(subWorkStreamApprovers.
                            getSubWorkStreamId(),subWorkStreamApprovers.getSubWorkStreamName()).
                            getSubWorkStreamName();
                    SubWorkStreamApproversResource approversResource = new SubWorkStreamApproversResource();
                    approversResource.setSubWorkStreamName(subWorkStreamName);
                    approversResource.setAction(subWorkStreamApprovers.getAction());
                    approversResource.setDelegateInd(subWorkStreamApprovers.getDelegateInd());
                    approversResource.setNotifyInd(subWorkStreamApprovers.getNotifyInd());
                    approversResource.setRole(subWorkStreamApprovers.getRole());
                    approversResource.setScenario(subWorkStreamApprovers.getScenario());
                    approversResource.setStaffName(subWorkStreamApprovers.getStaffName());
                    approversResource.setSubWorkStreamId(subWorkStreamApprovers.getSubWorkStreamId());
                    approversResource.setOneBankId(subWorkStreamApprovers.getOneBankId());
                    approversResource.setSwsApproveSurrId(subWorkStreamApprovers.getSwsApproveSurrId());
                    approversResource.setActiveInd(subWorkStreamApprovers.getActiveInd());
                    approversResource.setEffectiveStartDate(subWorkStreamApprovers.getEffectiveStartDate());
                    approversResource.setEffectiveEndDate(subWorkStreamApprovers.getEffectiveEndDate());
                    return approversResource;
                }).collect(Collectors.toList());

        return approversResourceList;

    }

    public List<WorkStreamListingSource> getWorkStreamListing(IdAndRoles idAndRoles) {
//        List<WorkStreamEntity> workStreamEntities;
        List<WorkStreamListingSource> workStreamListingSources;
        log.info("User Roles: " + idAndRoles);
        if (!checkPortfolioRoles(idAndRoles.getRoles())) {
            log.info("Part of checkPortfolioRoles");
            workStreamListingSources = workStreamEntityMgr.getWorkStreamListingByOneBankId(idAndRoles.getScenario(), idAndRoles.getPlatform(), idAndRoles.getReportingFlag(), idAndRoles.getLocations(), idAndRoles.getOneBankId());
//            workStreamEntities = workStreamRepo.findAllByOneBankIdAndPortfolioAndWorkstreamListing(idAndRoles.getScenario(),idAndRoles.getPlatform(),idAndRoles.getLocations(),idAndRoles.getOneBankId());
//            if(CollectionUtils.isEmpty(workStreamEntities)){
//                workStreamEntities = workStreamRepo.findAllByOneBankIdAndWorkStream(idAndRoles.getScenario(),idAndRoles.getPlatform(),idAndRoles.getLocations(),idAndRoles.getOneBankId());
//            }
        } else {
            workStreamListingSources = workStreamEntityMgr.getAllWorkStreamListings(idAndRoles.getScenario(), idAndRoles.getPlatform(), idAndRoles.getReportingFlag(), idAndRoles.getLocations());
//            workStreamEntities = workStreamRepo.findAllByScenarioPlatformAndCountry(idAndRoles.getScenario(),idAndRoles.getPlatform(),idAndRoles.getLocations());
        }
//        return workStreamEntities.stream().map(
//                this::getWorkStreamListingSource).collect(Collectors.toList());
        return CollectionUtils.isEmpty(workStreamListingSources) ? Collections.EMPTY_LIST : populateWorkStreamListingSource(workStreamListingSources);
    }

    private List<WorkStreamListingSource> populateWorkStreamListingSource(List<WorkStreamListingSource> workStreamListingSources) {
        List<WorkstreamLePccodesEntity> lePccodesEntityList = workstreamLePccodesRepo.findByActiveIndAndBuildOperateEqualsIgnoreCase(PortfolioConstants.TRUE, PortfolioConstants.BUILD);
        Map<String, List<WorkstreamLePccodesEntity>> lePccodesEntityMap = lePccodesEntityList
                .stream()
                .collect(Collectors.groupingBy(code -> code.getPortfolioId() + "," + code.getWorkStreamId()));

        workStreamListingSources.forEach(workStreamListingSource -> {
                    List<WorkstreamLePccodesEntity> lePccodes = lePccodesEntityMap.get(String.join(",", workStreamListingSource.getPortfolioId(), workStreamListingSource.getWorkStreamId()));
                    if (!CollectionUtils.isEmpty(lePccodes)) {
                        String lePCCodeString = lePccodes.stream().map(workstreamLePccodesEntity -> workstreamLePccodesEntity.getLePCCode()).collect(Collectors.joining(";"));
                        workStreamListingSource.setLePCCodeBuild(lePCCodeString);
                    }
                }
        );

        return workStreamListingSources;
    }

   /* private WorkStreamListingSource getWorkStreamListingSource(WorkStreamEntity workStreamEntity) {
        WorkStreamListingSource listingSource = new WorkStreamListingSource();
        PortfolioEntity portfolioEntity = portfolioRepo.findByPortfolioId(workStreamEntity.getPortfolioId());
        listingSource.setPortfolioId(workStreamEntity.getPortfolioId());
        listingSource.setPortfolioName(portfolioEntity.getPortfolioName());
        listingSource.setWorkStreamId(workStreamEntity.getWorkStreamId());
        listingSource.setWorkStreamName(workStreamEntity.getWorkStreamName());
        listingSource.setLocation(workStreamEntity.getCountry());
        List<WorkstreamLePccodesEntity> lePccodesEntityList = workstreamLePccodesRepo.findByPortfolioIdAndWorkStreamIdAndActiveIndAndBuildOperateEqualsIgnoreCase(
                portfolioEntity.getPortfolioId(), workStreamEntity.getWorkStreamId(), PortfolioConstants.TRUE,PortfolioConstants.BUILD);
        if (!lePccodesEntityList.isEmpty()) {
            String lePCCodeString = lePccodesEntityList.stream().map(workstreamLePccodesEntity -> workstreamLePccodesEntity.getLePCCode()).collect(Collectors.joining(";"));

            listingSource.setLePCCodeBuild(lePCCodeString);
        }
        listingSource.setPlatformName(portfolioEntity.getPrimaryPlatformName());
        listingSource.setSubPlatformName(workStreamEntity.getSubPlatFormName());
        listingSource.setWorkStatus(workStreamEntity.getWorkStatus());
        return listingSource;
    }
*/

    public Map getBreakDownFinancialDataByScenario(String scenario, String workStreamId, String period, String currencyCode, String typeOfData) {
        List<SubWorkStreamIdAndName> subWorkStreamIdAndNames = getSubWorkStreamIdAndNames(workStreamId);
        return workStreamBreakDownFinancialService.getFinancialDataByScenario(scenario, currencyCode, subWorkStreamIdAndNames, period, typeOfData);
    }


    public Map getBreakDownCostDataByScenario(String scenario, String workStreamId, String period, String currencyCode, String typeOfData) {
        List<SubWorkStreamIdAndName> subWorkStreamIdAndNames = getSubWorkStreamIdAndNames(workStreamId);
        return workStreamBreakDownCostService.getBreakDownCostData(scenario, currencyCode, subWorkStreamIdAndNames, period, typeOfData);
    }

    public List<SubWorkStreamIdAndName> getSubWorkStreamIdAndNames(String workStreamId) {
        List<WorkHierarchyEntity> workHierarchyEntities = workHierarchyRepo.findByWorkStreamId(workStreamId);
        return getSubWorkstreamIdAndNames(workHierarchyEntities);
    }

    public List<SubWorkStreamIdAndName> getSubWorkstreamIdAndNames(List<WorkHierarchyEntity> workHierarchyEntities) {
        return workHierarchyEntities.stream().map(workHierarchyEntity ->
                new SubWorkStreamIdAndName(workHierarchyEntity.getWorkStreamId(), workHierarchyEntity.getSubWorkStreamId(), workHierarchyEntity.getSubWorkStreamName()))
                .collect(Collectors.toList());
    }

    private boolean checkPortfolioRoles(List<String> roles) {
        boolean status = false;
        DataValues dataValues = dataSummaryService.getDataValuesByValue(PortfolioConstants.PF_LIST_ROLES, PortfolioConstants.SYSTEM_CONFIGURATION);
        for (String role : roles) {
            status = dataValues != null && dataValues.getDesc().contains(role);
            if (status)
                break;
        }
        return status;
    }

    public List<String> getFinancialYearsByScenario(String workStreamId, String scenario) {
        List<SubWorkStreamIdAndName> subWorkStreamIdAndNames = getSubWorkStreamIdAndNames(workStreamId);
        return subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                financialService.getFinancialYearsByScenario(subWorkStreamIdAndName.getWorkStreamId(),
                        subWorkStreamIdAndName.getSubWorkStreamId(), scenario, subWorkStreamIdAndName.getSubWorkStreamName())).
                flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
    }

    public List<WorkstreamLePccodesEntity> getWorkstreamPccodes(String workStreamId) {
        return workstreamLePccodesRepo.findByWorkStreamIdAndActiveInd(workStreamId, PortfolioConstants.TRUE);
    }

    public Object postToOCLAW(WorkstreamOclaw workstreamOclaw) {
        return workStreamOCLAClient.postOclawData(workstreamOclaw);
    }


}
