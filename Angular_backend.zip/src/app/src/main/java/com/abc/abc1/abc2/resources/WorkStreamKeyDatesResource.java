package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.util.Date;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkStreamKeyDatesResource {


    String portfolioId;
    String workStreamId;
    String scenarioName;
    Date approvedDate;
    Date startDate;
    Date swEngStartDate;
    Date goLiveDate;
    Date endDate;
    String workStreamName;
    String activeInd;
    int wsDateSurrId;

}
