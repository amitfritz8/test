package com.dbs.genesis.portfolio.controller;

import com.dbs.genesis.portfolio.model.EditLog;
import com.dbs.genesis.portfolio.service.EditLogService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/editlock")
@Slf4j
public class EditLogController {

    @Autowired
    private EditLogService editLogService;

    @PutMapping("/extend")
    public ResponseEntity extendEditLog(@RequestBody EditLog editLog){
        log.info("Extending edit lock of "+editLog.getPortfolioType()+" with name:"+editLog.getPortfolioName()+" for user:"+editLog.getStaffDisplayName());
        ResponseEntity response = null;
        if(editLogService.extendEditLog(editLog)){
            response = ResponseEntity.ok().body("Success");
        } else {
            response = ResponseEntity.status(HttpStatus.GONE).body("Edit lock already removed");
        }
        return response;
    }
}
