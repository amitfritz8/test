package com.dbs.genesis.portfolio.service;

import com.dbs.genesis.portfolio.model.DataSummary;
import com.dbs.genesis.portfolio.model.DataValues;
import com.dbs.genesis.portfolio.repository.DataSummaryRepo;
import com.dbs.genesis.portfolio.repository.DataValuesRepo;
import com.dbs.genesis.portfolio.common.Status;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Transactional
@Service
public class DataSummaryService {

    @Autowired
    DataSummaryRepo dataSummaryRepo;

    @Autowired
    DataValuesRepo dataValuesRepo;


    public List<DataValues> getDataValuesBySummary(String name) {
        List<DataValues> dataValues = new ArrayList<>();
        DataSummary dataSummary = dataSummaryRepo.findByStatusIgnoreCaseAndDataNameIgnoreCase(Status.ACTIVE.getStatus(), name);
        if (null != dataSummary && null != dataSummary.getDataCode()) {
            dataValues = dataValuesRepo.findByCodeAndStatusIgnoreCaseOrderByValue(dataSummary.getDataCode(), Status.ACTIVE.getStatus());
        }
        return dataValues;
    }

    public List<DataValues> getDataValuesBySummaryId(String name) {
        List<DataValues> dataValues = new ArrayList<>();
        DataSummary dataSummary = dataSummaryRepo.findByStatusIgnoreCaseAndDataNameIgnoreCase(Status.ACTIVE.getStatus(), name);
        if (null != dataSummary && null != dataSummary.getDataCode()) {
            dataValues = dataValuesRepo.findByCodeAndStatusIgnoreCaseOrderById(dataSummary.getDataCode(), Status.ACTIVE.getStatus());
        }
        return dataValues;
    }

    public DataValues getDataValuesByValue(String value, String name) {
        DataValues dataValues = new DataValues();
        DataSummary dataSummary = dataSummaryRepo.findByStatusIgnoreCaseAndDataNameIgnoreCase(Status.ACTIVE.
                getStatus(), name);
        if (null != dataSummary && null != dataSummary.getDataCode()) {
            dataValues = dataValuesRepo.findByCodeAndValueAndStatusIgnoreCaseOrderByValue(dataSummary.getDataCode(),
                    value, Status.ACTIVE.getStatus());
        }
        return dataValues;
    }

    public DataValues getDataValuesByDesc(String desc, String name) {
        DataValues dataValues = new DataValues();
        DataSummary dataSummary = dataSummaryRepo.findByStatusIgnoreCaseAndDataNameIgnoreCase(Status.ACTIVE.
                getStatus(), name);
        if (null != dataSummary && null != dataSummary.getDataCode()) {
            dataValues = dataValuesRepo.findByCodeAndDescAndStatusIgnoreCaseOrderByValue(dataSummary.getDataCode(),
                    desc, Status.ACTIVE.getStatus());
        }
        return dataValues;
    }

    public List<String> getGlCategories(String name){
    	List<DataValues> dataValues = this.getDataValuesBySummary(name);
    	return dataValues.stream()
    		    .map(DataValues::getValue).distinct()
    		    .collect(Collectors.toList());
    }

    public List<String> getCostTypes(String name){
    	List<DataValues> dataValues = this.getDataValuesBySummary(name);
    	return dataValues.stream()
    		    .map(DataValues::getValue).distinct()
    		    .collect(Collectors.toList());
    }

    public List<String> findCurrenciesBasedOnUam(String loggedInUserId) {
        return dataValuesRepo.findCurrenciesBasedOnUam(loggedInUserId);
    }
}
