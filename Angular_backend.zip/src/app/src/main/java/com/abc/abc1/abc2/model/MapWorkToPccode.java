package com.dbs.genesis.portfolio.model;


import com.dbs.genesis.portfolio.resources.FinancialSummaryResource;
import com.dbs.genesis.portfolio.resources.SubWorkstreamLePccodeResource;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.math.BigDecimal;
import java.math.BigInteger;


@SqlResultSetMappings({
        @SqlResultSetMapping(name = "subWorkStreamLepccodesMap", classes = {
                @ConstructorResult(targetClass = SubWorkstreamLePccodeResource.class,
                        columns = {
                                @ColumnResult(name = "workStreamId"),
                                @ColumnResult(name = "lePcCode"),
                                @ColumnResult(name = "buildOperate"),
                                @ColumnResult(name = "subWorkStreamLinked"),
                                @ColumnResult(name = "subWorkStreamMapSurrId",type = BigInteger.class)
                        })
        })
})

@NamedNativeQueries({
        @NamedNativeQuery(name = "subWorkStreamLepccodes",
                query = "SELECT\n" +
                        "  wlp.workstream_id AS workStreamId,\n" +
                        "  wlp.le_pccode AS lePcCode,\n" +
                        "  wlp.build_operate AS buildOperate,\n" +
                        "  'true' AS subWorkStreamLinked," +
                        "mwp.map_w2pccode_surr_id AS subWorkStreamMapSurrId " +
                        "FROM workstream_le_pccodes wlp\n" +
                        "  INNER JOIN map_work_to_pccode mwp ON mwp.workstream_id=wlp.workstream_id AND mwp.le_pccode=wlp.le_pccode\n" +
                        "WHERE wlp.active_ind='true'\n" +
                        "      AND wlp.workstream_id=:workStreamId\n" +
                        "      AND mwp.sub_workstream_id=:subWorkStreamId and mwp.sub_workstream_name=:subWorkStreamName " +
                        "UNION " +
                        "SELECT\n" +
                        "  wlp.workstream_id AS workStreamId,\n" +
                        "  wlp.le_pccode AS lePcCode,\n" +
                        "  wlp.build_operate AS buildOperate,\n" +
                        "  'false' AS subWorkStreamLinked,  0 AS   subWorkStreamMapSurrId " +
                        "FROM workstream_le_pccodes wlp\n" +
                        "WHERE wlp.workstream_id=:workStreamId and wlp.le_pccode NOT IN\n" +
                        "      (SELECT coalesce(le_pccode,'0') FROM map_work_to_pccode mwp WHERE mwp.workstream_id =:workStreamId)",
                resultSetMapping = "subWorkStreamLepccodesMap")
})
@Data
@Entity
@Table(name = "map_work_to_pccode")
@EntityListeners(AuditingEntityListener.class)
public class MapWorkToPccode extends CommonEntity<Integer> {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "map_w2pccode_surr_id")
    private Integer mapWorkPccodeSurrId;

    @Column(name = "portfolio_id")
    private String portfolioId;

    @Column(name = "workstream_id")
    private String workstreamId;

    @Column(name = "workstream_name")
    private String workStreamName;

    @Column(name = "le_pccode")
    private String lePcCode;

    @Column(name = "build_operate")
    private String buildOperate;

    @Column(name = "sub_workstream_id")
    private String subWorkstreamId;

    @Column(name = "sub_workstream_name")
    private String subWorkStreamName;

    @Column(name = "allocation_pct")
    private BigDecimal allocationPer;

    @Column(name = "reporting_flag")
    private String reportingFlag;

}
