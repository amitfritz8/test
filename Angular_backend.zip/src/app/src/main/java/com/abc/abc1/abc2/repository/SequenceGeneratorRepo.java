package com.dbs.genesis.portfolio.repository;


import com.dbs.genesis.portfolio.model.SequenceGeneratorEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SequenceGeneratorRepo extends JpaRepository<SequenceGeneratorEntity,String> {

    List<SequenceGeneratorEntity> findByPortFolioIdTypeAndKey1AndKey2AndKey4(String typeOfPortFolio, String platformIndex,
                                                                             String year, String workType);

    List<SequenceGeneratorEntity> findByPortFolioIdTypeAndKey1AndKey2(String typeOfPortFolio, String platformIndex,
                                                                               String year);

    List<SequenceGeneratorEntity> findByPortFolioIdTypeAndKey1AndKey2AndKey3AndKey4(String typeOfPortFolio, String platformIndex,
                                                                                             String year, String country, String workType);
}
