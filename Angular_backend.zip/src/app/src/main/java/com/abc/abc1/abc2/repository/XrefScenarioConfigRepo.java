package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.XrefScenarioConfigEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Set;

public interface XrefScenarioConfigRepo extends JpaRepository<XrefScenarioConfigEntity, Integer>{

    @Query(value = "select distinct scenario_name\n" +
            "from xref_data_summary a, xref_data_values b, xref_scenario_config c \n" +
            "where a.refdata_name='PF_Report Name' \n" +
            "  and a.refdata_code=b.refdata_code \n" +
            "  and b.refdata_attr1=link_to_report \n" +
            "  and copy_function = :copyFunction \n" +
            "  and active_ind = 'Active' \n" +
            "order by scenario_name", nativeQuery = true)
    Set<String> findAllActiveScenariosForCopyByCopyFunction(@Param("copyFunction") String copyFunction);



    @Query(value = "select distinct scenario_name from xref_scenario_config where scenario_name in ('Budget_NextYear','Forecast') and lock_ind='Yes' and active_ind='Active'", nativeQuery = true)
    List<String> getCopySnapshotFromScenarios();

    @Query(value = "select distinct activity_version from xref_scenario_config where lock_ind='Yes' and active_ind='Active' " +
            "and scenario_name=:scenarioName", nativeQuery = true)
    List<String> getCopySnapshotToScenarios(@Param("scenarioName") String scenarioName);

    @Query("select distinct scenarioName from XrefScenarioConfigEntity where activeInd=?1 order by orderDisplayKey")
    List<String> findDistinctByActiveIndEqualsIgnoreCase(String activeInd);
}