package com.dbs.genesis.portfolio.service;

import com.dbs.genesis.portfolio.common.DateExtensions;
import com.dbs.genesis.portfolio.common.S3Storage;
import com.dbs.genesis.portfolio.model.SubWorkStreamOthersEntity;
import com.dbs.genesis.portfolio.model.WorkstreamOthersEntity;
import com.dbs.genesis.portfolio.repository.SubWorkStreamOtherRepo;
import com.dbs.genesis.portfolio.repository.WorkstreamOthersRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Slf4j
@Service
@Transactional
public class S3StorageService implements DateExtensions {

    private static final String ACTIVE_IND = "true";
    private static final String slashDelimiter = "/";
    @Value("${appRootFolder}")
    String appRootFolder;
    @Value("${othersFolder}")
    String othersFolder;
    @Autowired
    private WorkstreamOthersRepo workstreamOthersRepo;
    @Autowired
    private SubWorkStreamOtherRepo subWorkStreamOtherRepo;
    @Autowired
    private S3Storage s3Storage;

    public boolean uploadFile(MultipartFile file, Integer workstreamOthersSurrId, String portfolioId, String
            workStreamId, String documentName, String documentType, String description, String activeInd, String
                                      filePath, String createdBy, String dateCreated, String modifiedBy,
                              String dateModified, String workstreamName) {
        boolean status = true;
        WorkstreamOthersEntity workstreamOthersEntity = WorkstreamOthersEntity.build(workstreamOthersSurrId, portfolioId,
                workStreamId, documentName, documentType, description, activeInd, filePath, createdBy, dateCreated,
                modifiedBy, dateModified, workstreamName);
        if (!workstreamOthersRepo.findById(workstreamOthersSurrId).isPresent()) {
            log.info("workstream_others record not found, workstreamOthersSurrId:- " + workstreamOthersSurrId);
            workstreamOthersEntity = workstreamOthersRepo.saveAndFlush(workstreamOthersEntity);
            status = saveFileToS3(file, workstreamOthersEntity);
        } else {
            log.info("workstream_others record found for workstreamOthersSurrId:- " + workstreamOthersSurrId);
            if (!file.isEmpty()) {
                status = saveFileToS3(file, workstreamOthersEntity);
            }
        }
        log.info(String.format("status:- %s , updating entity with filePath:- %s", status, workstreamOthersEntity.getFilePath()));
        saveFilePathToEntity(status, workstreamOthersEntity);
        return status;
    }

    void saveFilePathToEntity(boolean status, WorkstreamOthersEntity workstreamOthersEntity) {
        if (status) {
            workstreamOthersRepo.saveAndFlush(workstreamOthersEntity);
        } else {
            workstreamOthersRepo.deleteById(workstreamOthersEntity.getWsOthersSurrId());
        }
    }

    boolean saveFileToS3(MultipartFile file, WorkstreamOthersEntity workstreamOthersEntity) {
        boolean status;
        File fileData = convertMultiPartToFile(file);
        String fileWithFolder = appRootFolder + slashDelimiter + othersFolder + slashDelimiter + workstreamOthersEntity.
                getPortfolioId() + slashDelimiter + workstreamOthersEntity.getWorkStreamId() + slashDelimiter +
                workstreamOthersEntity.getWsOthersSurrId() + slashDelimiter + fileData.getName();
        log.info("File upload, fileWithFolder:- " + fileWithFolder);
        try {
            status = s3Storage.uploadInputStream(fileWithFolder, file.getInputStream());
            log.info("File upload to s3 bucket is completed.");
        } catch (IOException e) {
            status = false;
            log.error("Error while uploading file to S3: ", e);
        }
        log.info(String.format("status:- %s , updating entity with fileWithFolder:- %s", status, fileWithFolder));
        workstreamOthersEntity.setFilePath(fileWithFolder);
        return status;
    }

    public InputStream downloadFile(Integer id) {
        InputStream inputStream = null;
        Optional<WorkstreamOthersEntity> wsOthersOptional = workstreamOthersRepo.findById(id);
        if (wsOthersOptional.isPresent()) {
            String filePath = wsOthersOptional.get().getFilePath();
            inputStream = s3Storage.downloadFile(filePath);
        }
        return inputStream;
    }

    public List<WorkstreamOthersEntity> getWorkstreamOthers(String workstreamId) {
        return workstreamOthersRepo.findByWorkStreamIdIgnoreCaseAndActiveIndIgnoreCase(workstreamId, ACTIVE_IND);
    }

    public InputStream getFileObject(String fileNameKey) throws IOException {
        return s3Storage.downloadFile(fileNameKey);
    }

    public boolean deleteFileObject(String fileObjKeyName, int folderId, String userId) {
        try {
            if (s3Storage.delete(fileObjKeyName)) {
            } else {
                return false;
            }
        } catch (Exception e) {
            log.info("Error during deletion" + e.getMessage());
            return false;
        }
        return true;
    }

    public File convertMultiPartToFile(MultipartFile file) {
        File convFile = null;
        try {
            convFile = new File(Objects.requireNonNull(file.getOriginalFilename()));
        } catch (Exception e) {
            log.error("Error converting to Multipart file: " + e.getMessage());
        }
        return convFile;
    }


    public boolean uploadSubWorkStreamFile(MultipartFile multipartFile, String subWorkStreamId, String workStreamId,
                                           String subWorkStreamName, String documentType, String description, String
                                                   activeInd, String filePath, String createdBy, String dateCreated,
                                           String modifiedBy, String dateModified, String documentName, Integer swsOthersSurrId) {
        boolean status = false;
        try {
            SubWorkStreamOthersEntity subWorkStreamOthersEntity = getSubWorkStreamOthersEntity(subWorkStreamId,
                    workStreamId, subWorkStreamName, documentName, documentType, description, activeInd, filePath,
                    createdBy, dateCreated, modifiedBy,
                    dateModified, swsOthersSurrId);
            if (subWorkStreamOtherRepo.findById(swsOthersSurrId).isPresent()) {
                subWorkStreamOthersEntity = subWorkStreamOtherRepo.save(subWorkStreamOthersEntity);
                status = saveFileToS3Bucket(multipartFile, subWorkStreamOthersEntity);
                saveFilePathToSubWorkStreamEntity(status, subWorkStreamOthersEntity);
            } else {
                if (!multipartFile.isEmpty()) {
                    status = saveFileToS3Bucket(multipartFile, subWorkStreamOthersEntity);
                }
                saveFilePathToSubWorkStreamEntity(status, subWorkStreamOthersEntity);
            }
        } catch (Exception e) {
            log.info("Getting error in UploadSubWorkStreamFile", e.getMessage());
        }
        return status;
    }

    private SubWorkStreamOthersEntity getSubWorkStreamOthersEntity(String subWorkStreamId, String workStreamId,
                                                                   String subWorkStreamName, String docName, String
                                                                           documentType, String description,
                                                                   String activeInd, String filePath, String createdBy,
                                                                   String dateCreated, String modifiedBy,
                                                                   String dateModified, Integer swsOthersSurrId) {
        SubWorkStreamOthersEntity subWorkStreamOthersEntity = new SubWorkStreamOthersEntity();
        subWorkStreamOthersEntity.setDescription(description);
        subWorkStreamOthersEntity.setSubWorkStreamId(subWorkStreamId);
        subWorkStreamOthersEntity.setWorkStreamId(workStreamId);
        subWorkStreamOthersEntity.setSubWorkStreamName(subWorkStreamName);
        subWorkStreamOthersEntity.setDocumentType(documentType);
        subWorkStreamOthersEntity.setDocumentName(docName);
        subWorkStreamOthersEntity.setActiveInd(activeInd);
        subWorkStreamOthersEntity.setFilePath(filePath);
        subWorkStreamOthersEntity.setCreatedBy(createdBy);
        subWorkStreamOthersEntity.setDateCreated(convertStrToTimestamp(dateCreated));
        subWorkStreamOthersEntity.setModifiedBy(modifiedBy);
        subWorkStreamOthersEntity.setDateModified(convertStrToTimestamp(dateModified));
        subWorkStreamOthersEntity.setSwsOthersSurrId(swsOthersSurrId);
        return subWorkStreamOthersEntity;
    }

    public List<SubWorkStreamOthersEntity> getSubWorkStreamOthers(String subWorkStreamId, String subWorkStreamName) {
        return subWorkStreamOtherRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndActiveIndIgnoreCase(subWorkStreamId, subWorkStreamName,
                        ACTIVE_IND);
    }

    public InputStream ForSubWorkStreamData(Integer id, HttpServletResponse response,
                                            HttpServletRequest request,
                                            ServletContext context) {

        InputStream inputStream = null;
        Optional<SubWorkStreamOthersEntity> streamOthersEntity = subWorkStreamOtherRepo.findById(id);
        if (streamOthersEntity.isPresent()) {
            String filePath = streamOthersEntity.get().getFilePath();
            inputStream = s3Storage.downloadFile(filePath);
        }
        return inputStream;
    }


    boolean saveFileToS3Bucket(MultipartFile multipartFile, SubWorkStreamOthersEntity subWorkStreamOthersEntity) throws
            IOException {
        boolean status;
        File fileData = convertMultiPartToFile(multipartFile);
        String fileWithFolder = appRootFolder + slashDelimiter + othersFolder + slashDelimiter +
                subWorkStreamOthersEntity.getWorkStreamId() + "-" + subWorkStreamOthersEntity.getSubWorkStreamName() +
                slashDelimiter + subWorkStreamOthersEntity.getSwsOthersSurrId() + slashDelimiter + fileData.getName();
        status = s3Storage.uploadInputStream(fileWithFolder, multipartFile.getInputStream());
        subWorkStreamOthersEntity.setFilePath(fileWithFolder);
        return status;
    }

    void saveFilePathToSubWorkStreamEntity(boolean status, SubWorkStreamOthersEntity subWorkStreamOthersEntity) {
        if (status) {
            subWorkStreamOtherRepo.save(subWorkStreamOthersEntity);
        } else {
            subWorkStreamOtherRepo.deleteById(subWorkStreamOthersEntity.getSwsOthersSurrId());
        }
    }

}
