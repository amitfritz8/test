package com.dbs.genesis.portfolio.resources;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class CostSettingsView {

    String name;
    List<BigDecimal> monthlyCostSettings;
    Map<String,List<BigDecimal>> quarterlyCostSettings;
    Map<String,BigDecimal> yearlyCostSettings;
    BigDecimal costSettingsTotal = BigDecimal.ZERO;
    BigDecimal costSettingsOverAllTotal = BigDecimal.ZERO;
    List<CostTypeCategoryView> costTypeCategoryViewList;
    Map<String,BigDecimal> individualYearSummaryForQuarterly;
    Map<String,List<BigDecimal>> individualYearSummaryForQuarterlyForResources;


}
