package com.dbs.genesis.portfolio.resources;

import com.dbs.genesis.portfolio.model.SubWorkStreamKeyDatesEntity;
import com.dbs.genesis.portfolio.model.WorkStreamKeyDatesEntity;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WSAndSWSKeyDatesResource {
    List<SubWorkStreamKeyDatesEntity> subWorkStreamKeyDates;
    List<WorkStreamKeyDatesEntity> workStreamKeyDates;
 }
