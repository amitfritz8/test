package com.dbs.genesis.portfolio.controller;


import com.dbs.genesis.portfolio.model.NavItem;
import com.dbs.genesis.portfolio.model.WorkHierarchyEntity;
import com.dbs.genesis.portfolio.service.WorkHierarchyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequestMapping("/data/workHierarchy")
public class WorkHierarchyController {

    @Autowired
    WorkHierarchyService workHierarchyService;

    @GetMapping("/portfolio/{portfolioID}")
    List<NavItem> getWorkHierarchy(@PathVariable String portfolioID) {

        List<WorkHierarchyEntity> lstWorkHierarchy = workHierarchyService.getWorkHierarchy(portfolioID);

        Map<String, List<WorkHierarchyEntity>> workStreamMap = lstWorkHierarchy.stream().collect(Collectors.groupingBy(
                WorkHierarchyEntity::getWorkStreamName,
                LinkedHashMap::new, Collectors.toList()));

        List<NavItem> lstNavItems = new ArrayList<>();
        workStreamMap.forEach((k, v) -> {
            NavItem item = new NavItem();
            item.setDisplayName(k);
            item.setIsShow("false");
            v.forEach(obj -> {
                        if (obj.getSubWorkStreamId() != null) {
                            item.getChildren().add(new NavItem(obj.getSubWorkStreamName(), obj.getSubWorkStreamId()));
                        }
                        item.setDisplayID(obj.getWorkStreamId());
                    }
            );
            lstNavItems.add(item);
        });
        return lstNavItems;
    }
}
