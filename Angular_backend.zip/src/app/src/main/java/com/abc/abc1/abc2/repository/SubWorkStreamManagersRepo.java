package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.SubWorkStreamManagersEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubWorkStreamManagersRepo extends JpaRepository<SubWorkStreamManagersEntity,String> {


    List<SubWorkStreamManagersEntity> findByWorkStreamIdAndActiveInd(String workStreamId,String activeInd);

    List<SubWorkStreamManagersEntity> findBySubWorkStreamIdAndActiveIndAndSubWorkStreamName(String subWorkStreamId,
                                                                                            String activeInd,
                                                                                            String subWorkStreamName);
}

