package com.dbs.genesis.portfolio.service;


import com.dbs.genesis.portfolio.common.DateExtensions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.exception.MappingException;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.*;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.service.costsettings.HLEService;
import com.dbs.genesis.portfolio.service.financials.MainFinancialService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.transaction.Transactional;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@Transactional
public class SubWorkStreamService implements DateExtensions {

    @Autowired
    private WorkHierarchyRepo workHierarchyRepo;
    @Autowired
    private SubWorkStreamManagersRepo subWorkStreamManagersRepo;
    @Autowired
    private SubWorkStreamRepo subWorkStreamRepo;
    @Autowired
    private SubWorkStreamEntityMgr swsEntityMgr;
    @Autowired
    private WorkStreamRepo workStreamRepo;
    @Autowired
    private SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    @Autowired
    private SubWorkStreamApprovesRepo subWorkStreamApprovesRepo;
    @Autowired
    private PortfolioRepo portfolioRepo;
    @Autowired
    private EditLogRepo editLogRepo;
    @Autowired
    private PortFolioWorkStreamAndSubWorkStreamGenerator portFolioWorkStreamAndSubWorkStreamGenerator;

    @Autowired
    private MainFinancialService mainFinancialService;

    @Autowired
    private AppCodeRepo appCodeRepo;

    @Autowired
    private MapWorkToPccodeRepo mapWorkToPccodeRepo;

    @Autowired
    private WorkstreamLePccodesRepo workstreamLePccodesRepo;

    private HLEService hleService;

    @Autowired
    private DataSummaryService dataSummaryService;

    @Autowired
    private PortfolioRepository portfolioRepository;

    @Autowired
    public void setHLEService(HLEService hleService) {
        this.hleService = hleService;
    }

    public HLEService getHLEService() {
        return hleService;
    }


    public SubWorkStreamEntity saveSubWorkStreamData(SubWorkStreamDataSource subWorkStreamDataSource) {

        SubWorkStreamEntity subWorkStreamEntity = new SubWorkStreamEntity();
        WorkHierarchyEntity workHierarchyEntity = new WorkHierarchyEntity();

        WorkStreamEntity portFolioWorkStreamEntity = workStreamRepo.findByWorkStreamId(
                subWorkStreamDataSource.getWorkStreamId());

        String deliveryUnit = subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().getDeliveryUnit().substring(0,
                subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().getDeliveryUnit().indexOf("-")).trim();

//        String subWorkStreamPortfolioID = subWorkStreamDataSource.getWorkStreamId() + "-P" + deliveryUnit;
        String year = portFolioWorkStreamEntity.getPortfolioId().substring(portFolioWorkStreamEntity.getPortfolioId()
                .indexOf("-") + 1).substring(0, 2).trim();
        String workType = portFolioWorkStreamEntity.getPortfolioId().substring(portFolioWorkStreamEntity.
                getPortfolioId().lastIndexOf('-') + 1);
        PortfolioCreationEvent portfolioCreationEvent = new PortfolioCreationEvent();
        portfolioCreationEvent.setInitiationYear(year);
        portfolioCreationEvent.setWorkType(workType);
        String subWorkStreamPortfolioID = portFolioWorkStreamAndSubWorkStreamGenerator.getSubWorkStreamPortfolioID
                (portFolioWorkStreamEntity, deliveryUnit, portfolioCreationEvent);

        workHierarchyEntity.setPortfolioId(subWorkStreamDataSource.getPortfolioId());
        workHierarchyEntity.setPortfolioName(subWorkStreamDataSource.getPortfolioName());
        workHierarchyEntity.setWorkStreamId(subWorkStreamDataSource.getWorkStreamId());
        workHierarchyEntity.setWorkStreamName(portFolioWorkStreamEntity.getWorkStreamName());
        workHierarchyEntity.setSubWorkStreamId(subWorkStreamPortfolioID);
        workHierarchyEntity.setSubWorkStreamName(subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().
                getSubWorkStreamName());
        workHierarchyRepo.save(workHierarchyEntity);

        subWorkStreamEntity.setWorkStreamId(subWorkStreamDataSource.getWorkStreamId());
        subWorkStreamEntity.setSubWorkStreamId(subWorkStreamPortfolioID);
        subWorkStreamEntity.setSubWorkStreamName(subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().
                getSubWorkStreamName());
        subWorkStreamEntity.setCountry(portFolioWorkStreamEntity.getCountry());
        subWorkStreamEntity.setDeliveryUnit(subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().
                getDeliveryUnit());

        String primaryPlatform = getDeliveryUnit(portFolioWorkStreamEntity.getPortfolioId());
        String deliveryPlatform = getDeliveryUnit("P" + subWorkStreamDataSource.
                getPortFolioSubWorkStreamEntity().
                getDeliveryUnit());

        if (primaryPlatform.equalsIgnoreCase(deliveryPlatform)) {
            subWorkStreamEntity.setWorkType("A-Work");
        } else {
            subWorkStreamEntity.setWorkType("B-Work");
        }

        subWorkStreamRepo.save(subWorkStreamEntity);

        return subWorkStreamEntity;
    }


    public boolean existsWorkStreamIdWithDeliveryUnit(String workStreamId, String deliveryUnit) {
        boolean isDeliveryUnitExists = false;
        try {
            isDeliveryUnitExists = subWorkStreamRepo.existsByWorkStreamIdAndDeliveryUnit(workStreamId,
                    deliveryUnit);
        } catch (Exception e) {
            log.info("in sub work stream existsWorkStreamIdWithDeliveryUnit");
        }
        return isDeliveryUnitExists;
    }


    public SubWorkStreamEntity updateSubWorkStreamData(SubWorkStreamDataSource subWorkStreamDataSource) throws Exception {
        //GENE-1545 Enable Work Manager to link LE-PC Code to Sub-Workstream ID. validate lepc codes with existing mappings
        validateLepcCodesMapping(subWorkStreamDataSource);

        WorkHierarchyEntity workHierarchyEntity = workHierarchyRepo.findBySubWorkStreamIdAndSubWorkStreamName(
                subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().getSubWorkStreamId(),
                subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().getSubWorkStreamName());
        workHierarchyEntity.setSubWorkStreamName(subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().
                getSubWorkStreamName());
        log.info("Persisting workHierarchyEntity: " + workHierarchyEntity);
        workHierarchyRepo.save(workHierarchyEntity);
        log.info("Persisting PortFolioSubWorkStreamEntity: " + subWorkStreamDataSource.getPortFolioSubWorkStreamEntity());
        subWorkStreamRepo.save(subWorkStreamDataSource.getPortFolioSubWorkStreamEntity());

        mapWorkToPccodeRepo.saveAll(subWorkStreamDataSource.getLePcodesMapping());
        mapWorkToPccodeRepo.deleteAll(subWorkStreamDataSource.getDeletedLePcodesMapping());

        if (!subWorkStreamDataSource.getWorkManagers().isEmpty()) {
            subWorkStreamDataSource.getWorkManagers().forEach(workMangerObj -> {
                workMangerObj.setWorkStreamId(subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().
                        getWorkStreamId());
                workMangerObj.setSubWorkStreamId(subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().
                        getSubWorkStreamId());
                updateWorkStreamManagerEntity(workMangerObj, subWorkStreamDataSource.getPortfolioId());
            });
        }

        if (!subWorkStreamDataSource.getKeyDates().isEmpty()) {

            subWorkStreamDataSource.getKeyDates().stream().forEach(keyDatesEntity -> {
                PortfolioEntity byPortfolioId = portfolioRepo.findByPortfolioId(subWorkStreamDataSource.getPortfolioId());
                keyDatesEntity.setDepreStartDate(calculateDepreStartDate(keyDatesEntity.getGoLiveDate(), byPortfolioId.getAgileWaterFall()));
                SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = null;
                if (PortfolioConstants.SCENARIO_FORECAST.equalsIgnoreCase(keyDatesEntity.getScenarioName()) && PortfolioConstants.TRUE.equalsIgnoreCase(keyDatesEntity.getActiveInd())
                        && Objects.nonNull(keyDatesEntity.getStartDate()) &&
                        Objects.nonNull(keyDatesEntity.getGoLiveDate()) && Objects.nonNull(keyDatesEntity.getSwEngStartDate()) &&
                        Objects.nonNull(keyDatesEntity.getEndDate())) {
                    subWorkStreamKeyDatesEntity = subWorkStreamKeyDatesRepo.
                            findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(keyDatesEntity.getWorkStreamId(),
                                    keyDatesEntity.getSubWorkStreamId(), keyDatesEntity.getSubWorkStreamName(), PortfolioConstants.TRUE, keyDatesEntity.getScenarioName());
                }
                if (Objects.nonNull(subWorkStreamKeyDatesEntity) && Objects.nonNull(subWorkStreamKeyDatesEntity.getStartDate()) &&
                        Objects.nonNull(subWorkStreamKeyDatesEntity.getGoLiveDate()) && Objects.nonNull(subWorkStreamKeyDatesEntity.getSwEngStartDate()) &&
                        Objects.nonNull(subWorkStreamKeyDatesEntity.getEndDate())) {
                    if ((keyDatesEntity.getStartDate().compareTo(subWorkStreamKeyDatesEntity.getStartDate()) != 0 ||
                            keyDatesEntity.getGoLiveDate().compareTo(subWorkStreamKeyDatesEntity.getGoLiveDate()) != 0 ||
                            keyDatesEntity.getSwEngStartDate().compareTo(subWorkStreamKeyDatesEntity.getSwEngStartDate()) != 0 ||
                            keyDatesEntity.getEndDate().compareTo(subWorkStreamKeyDatesEntity.getEndDate()) != 0)) {
                        subWorkStreamKeyDatesRepo.save(keyDatesEntity);
                        hleService.updateHLEDataForRevisedKeyDates(subWorkStreamKeyDatesEntity, subWorkStreamDataSource.getCurrencyCode());
                        portfolioRepository.callSotredProcToRevisePreviousMonthsData(subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().
                                getSubWorkStreamId(), subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().getSubWorkStreamName());
                    }
                } else {
                    subWorkStreamKeyDatesRepo.save(keyDatesEntity);
                }
            });
        }


        if (!subWorkStreamDataSource.getSubWorkStreamApproves().isEmpty()) {
            subWorkStreamDataSource.getSubWorkStreamApproves().stream().forEach(subWorkStreamApproves -> {
                subWorkStreamApprovesRepo.save(subWorkStreamApproves);
            });
        }
        if (subWorkStreamDataSource.getMonthlyFinancialResource() != null) {
            if (subWorkStreamDataSource.getMonthlyFinancialResource().getMonthlySeedFundingData() != null) {
                mainFinancialService.saveMonthlySeedFundingData(subWorkStreamDataSource.getMonthlyFinancialResource());
            }
            if (subWorkStreamDataSource.getMonthlyFinancialResource().getMonthlyFinancialDetailsResources() != null) {
                mainFinancialService.saveFinancialOperationCost(subWorkStreamDataSource.getMonthlyFinancialResource());
            }

        }

        SubWorkStreamEntity portFolioSubWorkStreamEntity = subWorkStreamDataSource.getPortFolioSubWorkStreamEntity();
        editLogRepo.deleteByPortfolioIdAndPortfolioNameAndPortfolioType(portFolioSubWorkStreamEntity.getSubWorkStreamId(), portFolioSubWorkStreamEntity.getSubWorkStreamName(), PortfolioConstants.SUBWORKSTREAMNAME);

        return portFolioSubWorkStreamEntity;
    }

    private void validateLepcCodesMapping(SubWorkStreamDataSource subWorkStreamDataSource) {
        List<String> lepcCodes = subWorkStreamDataSource.getLePcodesMapping()
                .stream()
                .map(code -> code.getLePcCode())
                .collect(Collectors.toList());
        List<MapWorkToPccode> existingMappings = mapWorkToPccodeRepo.findAllByLePcCodeIn(lepcCodes);
        if (!CollectionUtils.isEmpty(existingMappings)) {
            log.info("Existing mappings for lepc codes:" + existingMappings.stream().map(o -> o.getLePcCode()).collect(Collectors.joining(",")));
            String swsId = subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().getSubWorkStreamId();
            for (MapWorkToPccode mapping : existingMappings) {
                if (!swsId.equalsIgnoreCase(mapping.getSubWorkstreamId())) {
                    String msg = "This LE-PC code : " + mapping.getLePcCode() + " is already linked to another SWS ID :" + mapping.getSubWorkstreamId() + " for actual data feed, this update will not be saved in Gene";
                    throw new MappingException(msg);
                }
            }
        }
    }


    public void updateWorkStreamManagerEntity(SubWorkStreamManagersEntity managersEntity,
                                              String PortfolioId) {
        managersEntity.setPlatformIndex(PortfolioId.substring(0, PortfolioId.indexOf("-")).trim());
        subWorkStreamManagersRepo.save(managersEntity);
    }

    public SubWorkStreamKeyDatesEntity getSubWorkStreamKeyDates(String subWorkStreamId, String subWorkStreamName) {
        return subWorkStreamKeyDatesRepo.
                findBySubWorkStreamIdAndActiveIndAndSubWorkStreamName(subWorkStreamId, PortfolioConstants.TRUE, subWorkStreamName);
    }

    public SubWorkStreamKeyDatesEntity getSubWorkStreamKeyDatesBasedonScenario(String subWorkStreamId, String subWorkStreamName, String scenario) {
        return subWorkStreamKeyDatesRepo.
                findBySubWorkStreamIdAndActiveIndAndSubWorkStreamNameAndScenarioName(subWorkStreamId, PortfolioConstants.TRUE, subWorkStreamName, scenario);
    }

    public List<SubWorkStreamKeyDatesEntity> getSubWorkStreamKeyDatesList(String subWorkStreamId, String subWorkStreamName) {
        return subWorkStreamKeyDatesRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndActiveInd(subWorkStreamId, subWorkStreamName, PortfolioConstants.TRUE);
    }

    public List<Map> getListOfWorkMangers(String subWorkStreamId, String subWorkStreamName) {
        List<Map> mapList = new ArrayList<>();
        List<SubWorkStreamManagersEntity> subWorkStreamManagersEntityList = subWorkStreamManagersRepo.
                findBySubWorkStreamIdAndActiveIndAndSubWorkStreamName(subWorkStreamId, "true",
                        subWorkStreamName);
        List<SubWorkStreamManagerResource> subWorkStreamManagerResourceList =
                getListOfSubWorkStreamMangerList(subWorkStreamManagersEntityList);
        Map<String, List<SubWorkStreamManagerResource>> subWorkStreamMap = subWorkStreamManagerResourceList.stream().
                collect(Collectors.groupingBy(SubWorkStreamManagerResource::getSubWorkStreamName, LinkedHashMap::new,
                        Collectors.toList()));

        mapList.add(subWorkStreamMap);
        return mapList;
    }


    public List<SubWorkStreamManagerResource> getListOfSubWorkStreamMangerList
            (List<SubWorkStreamManagersEntity> subWorkStreamManagersEntityList) {
        return subWorkStreamManagersEntityList.stream().map
                (this::assembleSubWorkStreamManagerResource).collect(Collectors.toList());
    }

    private SubWorkStreamManagerResource
    assembleSubWorkStreamManagerResource(SubWorkStreamManagersEntity subWorkStreamManagersEntity) {
        SubWorkStreamEntity folioSubWorkStreamEntity = subWorkStreamRepo.findBySubWorkStreamIdAndSubWorkStreamName(
                subWorkStreamManagersEntity.getSubWorkStreamId(),subWorkStreamManagersEntity.getSubWorkStreamName());
        SubWorkStreamManagerResource subWorkStreamManagerResource =
                subWorkStreamManagersEntity.toSubWorkStreamManagerResource();
        subWorkStreamManagerResource.setSubWorkStreamName(folioSubWorkStreamEntity.getSubWorkStreamName());
        return subWorkStreamManagerResource;
    }

    public List<SubWorkStreamApprovers> getSubWorkStreamApprovesList(String subWorkStreamId, String subWorkStreamName) {
        return subWorkStreamApprovesRepo.findBySubWorkStreamIdAndActiveIndAndSubWorkStreamName(subWorkStreamId,
                "true", subWorkStreamName);
    }

    public List<SubWorkStreamListingSource> getSubWorkStreamListing(IdAndRoles idAndRoles) {
//        List<SubWorkStreamEntity> subWorkStreamEntities;
        List<SubWorkStreamListingSource> swsListingResource;
        if (!checkPortfolioRolesForTeamLeadsOrWorkmanager(idAndRoles.getRoles())) {
            swsListingResource = swsEntityMgr.getSubWorkStreamListingByOneBankId(idAndRoles.getScenario(), idAndRoles.getPlatform(), idAndRoles.getReportingFlag(), idAndRoles.getLocations(), idAndRoles.getOneBankId());
//            subWorkStreamEntities = subWorkStreamRepo.findAllByOneBankIdListing(idAndRoles.getScenario(), idAndRoles.getPlatform(), idAndRoles.getLocations(), idAndRoles.getOneBankId());
//            if (CollectionUtils.isEmpty(subWorkStreamEntities)) {
//                subWorkStreamEntities = subWorkStreamRepo.findAllByOneBankIdAndWorkStream(idAndRoles.getScenario(), idAndRoles.getPlatform(), idAndRoles.getLocations(), idAndRoles.getOneBankId());
//            }
//            if (CollectionUtils.isEmpty(subWorkStreamEntities)) {
//                subWorkStreamEntities = subWorkStreamRepo.findAllByOneBankIdAndSubWorkStream(idAndRoles.getScenario(), idAndRoles.getPlatform(), idAndRoles.getLocations(), idAndRoles.getOneBankId());
//            }
        } else {
            //  subWorkStreamEntities = subWorkStreamRepo.findAllByScenarioPlatformAndCountry(idAndRoles.getScenario(), idAndRoles.getPlatform(), idAndRoles.getLocations());
            swsListingResource = swsEntityMgr.getAllSubWorkStreams(idAndRoles.getScenario(), idAndRoles.getPlatform(), idAndRoles.getReportingFlag(), idAndRoles.getLocations());
        }
//        return subWorkStreamEntities.stream().map(this::
//                getSubWorkStreamListingSource).collect(Collectors.toList());*/
        return swsListingResource;
    }


    private SubWorkStreamListingSource getSubWorkStreamListingSource(SubWorkStreamEntity subWorkStreamEntity) {
        SubWorkStreamListingSource listingSource = new SubWorkStreamListingSource();
        listingSource.setWorkStreamId(subWorkStreamEntity.getWorkStreamId());
        WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(subWorkStreamEntity.
                getWorkStreamId());
        listingSource.setPortfolioId(workStreamEntity.getPortfolioId());
        PortfolioEntity byPortfolioId = portfolioRepo.findByPortfolioId(workStreamEntity.getPortfolioId());
        listingSource.setPortfolioName(byPortfolioId.getPortfolioName());
        listingSource.setWorkStreamName(workStreamEntity.getWorkStreamName());
        listingSource.setAppCode(subWorkStreamEntity.getAppCode());
        listingSource.setPlatformName(subWorkStreamEntity.getDeliveryUnit());
        listingSource.setWorkType(subWorkStreamEntity.getWorkType());
        listingSource.setSubWorkStreamId(subWorkStreamEntity.getSubWorkStreamId());
        listingSource.setSubWorkStreamName(subWorkStreamEntity.getSubWorkStreamName());
        return listingSource;
    }

    String getDeliveryUnit(String platformName) {
        return platformName.substring(0, platformName.indexOf("-")).trim();
    }

    public Map<String, Object> getSubWorkStreamKeyDatesBasedOnGLCategoriesForResourcesIndividualContributorAndHLE(String workStreamId, String subWorkStreamId, String subWorkStreamName,
                                                                                                                  String scenario, String glCategory, String costSettingType) {
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(workStreamId, subWorkStreamId,
                        subWorkStreamName, PortfolioConstants.TRUE, scenario);

        subWorkStreamKeyDatesEntity = getDepreStartDate(workStreamId, subWorkStreamKeyDatesEntity);

        Map<String, Object> monthsBetweenTheDatesMap = new HashMap<String, Object>();
        List<String> monthsBetweenTheDates = new ArrayList<>();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        if (PortfolioConstants.CAPEX.equalsIgnoreCase(glCategory)) {
            monthsBetweenTheDates = getMonthYearListByStartDateAndEndDate(
                    subWorkStreamKeyDatesEntity.getSwEngStartDate(), subWorkStreamKeyDatesEntity.getGoLiveDate());
            String swEngStartDateMonth = df.format(subWorkStreamKeyDatesEntity.getSwEngStartDate()).substring(0, 7).replaceAll("-", "");
            monthsBetweenTheDatesMap.put(PortfolioConstants.ACTUAL_PERIOD, swEngStartDateMonth);
            monthsBetweenTheDatesMap.put(PortfolioConstants.MONTHS_BETWEEN_DATES, monthsBetweenTheDates);
        } else if (PortfolioConstants.OPEX.equalsIgnoreCase(glCategory)) {
            String startDateMonth = df.format(subWorkStreamKeyDatesEntity.getStartDate()).substring(0, 7);
            monthsBetweenTheDates = getCurrentYearMonthBetweenDates(
                    startDateMonth, getMonths(df.format(subWorkStreamKeyDatesEntity.getSwEngStartDate()).substring(0, 7), -1));
            startDateMonth = df.format(subWorkStreamKeyDatesEntity.getStartDate()).substring(0, 7).replaceAll("-", "");
            monthsBetweenTheDatesMap.put(PortfolioConstants.ACTUAL_PERIOD, startDateMonth);
            monthsBetweenTheDatesMap.put(PortfolioConstants.MONTHS_BETWEEN_DATES, monthsBetweenTheDates);
        }
        calculateDateRangeForOwnershipAndItDepreciation(glCategory, costSettingType, subWorkStreamKeyDatesEntity, df, monthsBetweenTheDatesMap);
        return monthsBetweenTheDatesMap;

    }

    public Map<String, Object> getSubWorkStreamKeyDatesBasedOnGLCategories(String workStreamId, String subWorkStreamId, String subWorkStreamName,
                                                                           String scenario, String glCategory, String costSettingType) {
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(workStreamId, subWorkStreamId,
                        subWorkStreamName, PortfolioConstants.TRUE, scenario);

        subWorkStreamKeyDatesEntity = getDepreStartDate(workStreamId, subWorkStreamKeyDatesEntity);

        Map<String, Object> monthsBetweenTheDatesMap = new HashMap<String, Object>();
        List<String> monthsBetweenTheDates = new ArrayList<>();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        if (PortfolioConstants.CAPEX.equalsIgnoreCase(glCategory) || PortfolioConstants.OPEX.equalsIgnoreCase(glCategory)) {
            Date startDate = checkStartDate(subWorkStreamKeyDatesEntity.getStartDate());
           // monthsBetweenTheDates = getMonthYearListByStartDateAndEndDate(subWorkStreamKeyDatesEntity.getStartDate(), subWorkStreamKeyDatesEntity.getGoLiveDate());
            monthsBetweenTheDates = getMonthYearListByStartDateAndEndDate(startDate, subWorkStreamKeyDatesEntity.getGoLiveDate());
            String startDateMonth = df.format(subWorkStreamKeyDatesEntity.getStartDate()).substring(0, 7).replaceAll("-", "");
            monthsBetweenTheDatesMap.put(PortfolioConstants.ACTUAL_PERIOD, startDateMonth);
            monthsBetweenTheDatesMap.put(PortfolioConstants.MONTHS_BETWEEN_DATES, monthsBetweenTheDates);
        }
        calculateDateRangeForOwnershipAndItDepreciation(glCategory, costSettingType, subWorkStreamKeyDatesEntity, df, monthsBetweenTheDatesMap);
        return monthsBetweenTheDatesMap;

    }

    private Map<String, Object> calculateDateRangeForOwnershipAndItDepreciation(String glCategory, String costSettingType, SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity, DateFormat df,
                                                                                Map<String, Object> monthsBetweenTheDatesMap) {
        List<String> monthsBetweenTheDates = new ArrayList<>();
        if (PortfolioConstants.OWNERSHIP.equalsIgnoreCase(glCategory)) {
            if (PortfolioConstants.COST_SETTING_TYPE_HLE.equalsIgnoreCase(costSettingType)) {
                monthsBetweenTheDates = getCurrentYearMonthBetweenDates(getMonths(df.format(subWorkStreamKeyDatesEntity.getGoLiveDate()).substring(0, 7), 1), getDecMonthOfTheDate(subWorkStreamKeyDatesEntity.getEndDate()));
                monthsBetweenTheDatesMap.put(PortfolioConstants.ACTUAL_PERIOD, getMonths(df.format(subWorkStreamKeyDatesEntity.getGoLiveDate()).substring(0, 7), 1));
                monthsBetweenTheDatesMap.put(PortfolioConstants.MONTHS_BETWEEN_DATES, monthsBetweenTheDates);
            } else if (PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS.equalsIgnoreCase(costSettingType)) {
                monthsBetweenTheDates = getCurrentYearMonthBetweenDates(getMonths(df.format(subWorkStreamKeyDatesEntity.getGoLiveDate()).substring(0, 7), 1), getMonths(df.format(subWorkStreamKeyDatesEntity.getGoLiveDate()).substring(0, 7), 60));
                monthsBetweenTheDatesMap.put(PortfolioConstants.ACTUAL_PERIOD, getMonths(df.format(subWorkStreamKeyDatesEntity.getGoLiveDate()).substring(0, 7), 1));
                monthsBetweenTheDatesMap.put(PortfolioConstants.MONTHS_BETWEEN_DATES, monthsBetweenTheDates);
            }
        } else if (PortfolioConstants.ITDEPRECIATION.equalsIgnoreCase(glCategory)) {
            java.sql.Date depreDate = getDepreDate(subWorkStreamKeyDatesEntity.getWorkStreamId(), subWorkStreamKeyDatesEntity);
            if (PortfolioConstants.COST_SETTING_TYPE_HLE.equalsIgnoreCase(costSettingType)) {
                String depreStartDate = df.format(depreDate).substring(0, 7).replaceAll("-", "");
                monthsBetweenTheDates = getCurrentYearMonthBetweenDates(
                        df.format(depreDate).substring(0, 7), getDecMonthOfTheDate(subWorkStreamKeyDatesEntity.getEndDate()));
                monthsBetweenTheDatesMap.put(PortfolioConstants.ACTUAL_PERIOD, depreStartDate);
                monthsBetweenTheDatesMap.put(PortfolioConstants.MONTHS_BETWEEN_DATES, monthsBetweenTheDates);
            } else if (PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS.equalsIgnoreCase(costSettingType)) {
                String depreStartDate = df.format(depreDate).substring(0, 7).replaceAll("-", "");
                monthsBetweenTheDates = getCurrentYearMonthBetweenDates(
                        df.format(depreDate).substring(0, 7), getMonths(df.format(depreDate).substring(0, 7), 59));
                monthsBetweenTheDatesMap.put(PortfolioConstants.ACTUAL_PERIOD, depreStartDate);
                monthsBetweenTheDatesMap.put(PortfolioConstants.MONTHS_BETWEEN_DATES, monthsBetweenTheDates);
            }
        }
        return monthsBetweenTheDatesMap;
    }

    private java.sql.Date getDepreDate(String workStreamId, SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity) {
        WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(workStreamId);
        PortfolioEntity portfolioId = portfolioRepo.findByPortfolioId(workStreamEntity.getPortfolioId());
        java.sql.Date depreStartDate = subWorkStreamKeyDatesEntity.getDepreStartDate();
        if (depreStartDate == null) {
            depreStartDate = calculateDepreStartDate(subWorkStreamKeyDatesEntity.getGoLiveDate(), portfolioId.getAgileWaterFall());
        }
        log.info("calculated Depre start date:" + depreStartDate);
        return depreStartDate;
    }

    private boolean checkPortfolioRolesForTeamLeadsOrWorkmanager(List<String> roles) {
        boolean status = false;
        DataValues dataValues = dataSummaryService.getDataValuesByValue(
                PortfolioConstants.PF_LIST_ROLES, PortfolioConstants.SYSTEM_CONFIGURATION);
        for (String role : roles) {
            status = dataValues != null && dataValues.getDesc().contains(role);
            if (status)
                break;
        }
        return status;
    }

    public SubWorkStreamKeyDatesEntity getDepreStartDate(String workStreamId, SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity) {
        WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(workStreamId);
        PortfolioEntity byPortfolioId = portfolioRepo.findByPortfolioId(workStreamEntity.getPortfolioId());
        if (PortfolioConstants.AGILE.equalsIgnoreCase(byPortfolioId.getAgileWaterFall()) && subWorkStreamKeyDatesEntity.getGoLiveDate() != null) {
            java.util.Date subWorkStreamDataSourceGoLiveDate = getDateAfterNoOfMonths(subWorkStreamKeyDatesEntity.getGoLiveDate(), 3);
            java.sql.Date depreStartDate = new java.sql.Date(subWorkStreamDataSourceGoLiveDate.getTime());
            if (subWorkStreamKeyDatesEntity.getDepreStartDate() == null) {
                subWorkStreamKeyDatesEntity.setDepreStartDate(depreStartDate);
                subWorkStreamKeyDatesRepo.save(subWorkStreamKeyDatesEntity);
            } else if (subWorkStreamKeyDatesEntity.getDepreStartDate() != null && depreStartDate.compareTo(subWorkStreamKeyDatesEntity.getDepreStartDate()) != 0) {
                subWorkStreamKeyDatesEntity.setDepreStartDate(depreStartDate);
                subWorkStreamKeyDatesRepo.save(subWorkStreamKeyDatesEntity);
            }
        } else if (PortfolioConstants.WATERFALL.equalsIgnoreCase(byPortfolioId.getAgileWaterFall()) && subWorkStreamKeyDatesEntity.getGoLiveDate() != null) {
            if (subWorkStreamKeyDatesEntity.getDepreStartDate() == null) {
                subWorkStreamKeyDatesEntity.setDepreStartDate(subWorkStreamKeyDatesEntity.getGoLiveDate());
                subWorkStreamKeyDatesRepo.save(subWorkStreamKeyDatesEntity);
            } else if (subWorkStreamKeyDatesEntity.getDepreStartDate() != null && subWorkStreamKeyDatesEntity.getGoLiveDate().compareTo(subWorkStreamKeyDatesEntity.getDepreStartDate()) != 0) {
                subWorkStreamKeyDatesEntity.setDepreStartDate(subWorkStreamKeyDatesEntity.getGoLiveDate());
                subWorkStreamKeyDatesRepo.save(subWorkStreamKeyDatesEntity);
            }
        }
        return subWorkStreamKeyDatesEntity;
    }

    public List<WorkstreamLePccodesEntity> getSubWorkStreamPccodes(SubWorkStreamIdAndName subWorkStreamIdAndName) {
        return workstreamLePccodesRepo.getSubWorkStreamPccodes(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),
                PortfolioConstants.TRUE, subWorkStreamIdAndName.getSubWorkStreamName());
    }

    public List<SubWorkstreamLePccodeResource> getSubWorkStreamPccodesforEdit(SubWorkStreamIdAndName subWorkStreamIdAndName) {
        return portfolioRepository.getSubWorkStreamLepccodes(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),
                subWorkStreamIdAndName.getSubWorkStreamName());
    }

    public boolean checkForecastExistsForSWS(String subWorkStreamId, String subWorkstreamName) {
        int totalRecords = subWorkStreamRepo.countBySubWorkStreamIdAndWorkStreamName(subWorkStreamId, subWorkstreamName);
        return totalRecords > 0 ? true : false;
    }

    private Date checkStartDate(Date startDate){
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date systemDate = df.parse(LocalDate.now().toString());
            return startDate.compareTo(systemDate)>0 ? startDate :systemDate;
        } catch (ParseException e) {
            log.error("Error while pasring system date : ",e);
            return startDate;
        }
    }
}