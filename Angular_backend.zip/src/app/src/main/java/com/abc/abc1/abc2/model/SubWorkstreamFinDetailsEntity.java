package com.dbs.genesis.portfolio.model;


import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.resources.FinancialSummaryResource;
import com.dbs.genesis.portfolio.resources.SubWorkStreamIdAndName;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;

@SqlResultSetMappings(
        {
            @SqlResultSetMapping(name = "financialSummaryResource"  ,
            classes = {
                    @ConstructorResult(targetClass = FinancialSummaryResource.class,
                            columns = {
                                    @ColumnResult(name = "currencyValue",type = BigDecimal.class),
                                    @ColumnResult(name = "period")
                            }),

            }),
            @SqlResultSetMapping(name = "financialSummaryResourceGrandTotal"  ,
                    classes = {
                            @ConstructorResult(targetClass = FinancialSummaryResource.class,
                                    columns = {
                                            @ColumnResult(name = "currencyValue",type = BigDecimal.class),
                                            @ColumnResult(name = "grpCurrencyValue",type = BigDecimal.class),
                                    }),

                    }),
            @SqlResultSetMapping(name = "financialSummaryResourceValue",
                    classes = {

                    @ConstructorResult(targetClass = FinancialSummaryResource.class,
                            columns = {
                                    @ColumnResult(name = "currencyValue",type = BigDecimal.class)
                            })
            }),
                @SqlResultSetMapping(name = "workStreamIdAndName",
                        classes = {
                                @ConstructorResult(targetClass = SubWorkStreamIdAndName.class,
                                        columns = {
                                                @ColumnResult(name = "subWorkStreamId",type = String.class),
                                                @ColumnResult(name = "subWorkStreamName",type = String.class)
                                        })
                        })

        })

@NamedNativeQueries({
        @NamedNativeQuery(name = "findGrandTotalOfResourceBasedOnUniqueIdentifierNative",
                query = "select coalesce(sum(blended_cost_lcy),0) as currencyValue, coalesce(sum(blended_cost_gcy),0) as grpCurrencyValue \n" +
                        "                        from sub_workstream_resource_cost a, sub_workstream_dates b \n" +
                        "                        where a.sub_workstream_id=b.sub_workstream_id \n" +
                        "                        and a.sub_workstream_name=b.sub_workstream_name \n" +
                        "                        and a.scenario=b.scenario_name \n" +
                        "                        and a.sub_workstream_id = :subWorkstreamId \n" +
                        "                        and a.sub_workstream_name = :subWorkStreamName \n" +
                        "                        and a.scenario = :scenario \n" +
                        "                        and b.active_ind= 'true' \n" +
                        "                        and original_ind='false' \n" +
                        "                        and gl_category = if(period between date_format(start_date,'%Y%m') and \n" +
                        "                date_format(date_add(sw_eng_start_date,interval -1 month),'%Y%m'),'Opex', \n" +
                        "                        if(period between date_format(sw_eng_start_date,'%Y%m') and date_format(go_live_date,'%Y%m'), 'Capex','Opex')) \n" +
                        "                and team_role = :teamRole and location = :location and staff_type = :staffType and vendor = :vendor and rate_source \n" +
                        "                 = :rateSource \n" +
                        "                and staff_level = :staffLevel",
                resultSetMapping = "financialSummaryResourceGrandTotal"),
        @NamedNativeQuery(name = "financialGroupSummaryByPeriodAndGroupCcy",
                query = "select COALESCE(sum(group_ccy_val),0) as currencyValue,period from sub_workstream_fin_details " +
                        "where gl_category in :glCategories and " +
                        "workstream_id= :workStreamId and sub_workstream_id= :subWorkStreamId and " +
                        "sub_workstream_name= :subWorkStreamName and  substring(period,1,4)= :period and org_ind= :orgInd group by period," +
                        "sub_workstream_id,cost_type,sub_workstream_name",
                resultSetMapping = "financialSummaryResource"),

        @NamedNativeQuery(name = "financialGroupSummaryByPeriodAndLocalCcy",
                query = "select COALESCE(sum(local_ccy_val),0) as currencyValue,period from sub_workstream_fin_details " +
                        "where gl_category in :glCategories and " +
                        "workstream_id= :workStreamId and sub_workstream_id= :subWorkStreamId and " +
                        "sub_workstream_name= :subWorkStreamName and  substring(period,1,4)= :period and org_ind= :orgInd group by period," +
                        "sub_workstream_id,cost_type,sub_workstream_name",
                resultSetMapping = "financialSummaryResource"),


        @NamedNativeQuery(name = "financialYearlySummaryByGroupCcy", query = "select COALESCE(sum(group_ccy_val),0) as currencyValue " +
                "from sub_workstream_fin_details where gl_category in :glCategories and " +
                "workstream_id= :workStreamId and sub_workstream_id= :subWorkStreamId and " +
                        "sub_workstream_name= :subWorkStreamName and  substring(period,1,4)= :period and org_ind = :orgInd",
                resultSetMapping = "financialSummaryResourceValue"),

        @NamedNativeQuery(name = "financialYearlySummaryByLocalCcy", query = "select COALESCE(sum(local_ccy_val),0) as currencyValue " +
                "from sub_workstream_fin_details where gl_category in :glCategories and " +
                "workstream_id= :workStreamId and sub_workstream_id= :subWorkStreamId and " +
                "sub_workstream_name= :subWorkStreamName and  substring(period,1,4)= :period and org_ind = :orgInd",
                resultSetMapping = "financialSummaryResourceValue"),

        @NamedNativeQuery(name = "financialCostInputByPeriodAndGroupCcy",
                query = "select COALESCE(sum(group_ccy_val),0) as currencyValue ,period from sub_workstream_fin_details " +
                        "where " +
                        "workstream_id= :workStreamId and sub_workstream_id= :subWorkStreamId and " +
                        "sub_workstream_name= :subWorkStreamName and  substring(period,1,4)= :period and " +
                        "cost_settings= :costSetting and scenario= :scenario and org_ind= :orgInd group by period," +
                        "sub_workstream_id,sub_workstream_name",
                resultSetMapping = "financialSummaryResource"),

        @NamedNativeQuery(name = "financialCostInputByPeriodAndLocalCcy",
                query = "select COALESCE(sum(local_ccy_val),0) as currencyValue ,period from sub_workstream_fin_details " +
                        "where " +
                        "workstream_id= :workStreamId and sub_workstream_id= :subWorkStreamId and " +
                        "sub_workstream_name= :subWorkStreamName and  substring(period,1,4)= :period and " +
                        "cost_settings= :costSetting and scenario= :scenario and org_ind= :orgInd group by period," +
                        "sub_workstream_id,sub_workstream_name",
                resultSetMapping = "financialSummaryResource"),

        @NamedNativeQuery(name = "finYearlySumForCostTypeByGroupCcy", query = "select COALESCE(sum(group_ccy_val),0) as currencyValue " +
                "from sub_workstream_fin_details where " +
                "workstream_id= :workStreamId and sub_workstream_id= :subWorkStreamId and " +
                "sub_workstream_name= :subWorkStreamName and  substring(period,1,4)= :period and " +
                "cost_settings= :costSetting and scenario = :scenario and org_ind= :orgInd",
                resultSetMapping = "financialSummaryResourceValue"),

        @NamedNativeQuery(name = "finYearlySumForCostTypeByLocalCcy",query = "select COALESCE(sum(local_ccy_val),0) as currencyValue " +
                "from sub_workstream_fin_details where " +
                "workstream_id= :workStreamId and sub_workstream_id= :subWorkStreamId and " +
                "sub_workstream_name= :subWorkStreamName and  substring(period,1,4)= :period and " +
                "cost_settings= :costSetting and scenario = :scenario and org_ind= :orgInd",
                resultSetMapping = "financialSummaryResourceValue"),
       /* @NamedNativeQuery(name = "getCostForFinancialCaseSummaryByGroupCcy",query = "select coalesce(sum(currencyValue),0) as currencyValue,coalesce(period,'') as period  from " +
                "(select coalesce(sum(group_ccy_val),0) as currencyValue,period from sub_workstream_fin_details where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                "and gl_category in :glCategories and scenario= :scenario  and org_ind='false'  and substr(period,1,4)= :period and period is not null group by period " +
                "union " +
                "select coalesce(sum(cost_per_month_gcy),0) as currencyValue,period from sub_workstream_software_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false'  and substr(period,1,4)= :period and period is not null group by period " +
                "union " +
                "select coalesce(sum(group_ccy_val),0) as currencyValue,period from sub_workstream_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and substr(period,1,4)= :period and period is not null group by period " +
                "union " +
                "select coalesce(sum(cost_per_month_gcy),0) as currencyValue,period from sub_workstream_hardware_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and substr(period,1,4)= :period  and period is not null group by period " +
                "UNION " +
                "select coalesce(sum(blended_cost_gcy),0) as currencyValue,period from sub_workstream_resource_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and substr(period,1,4)= :period  and period is not null group by period ) as total_cost group by period",
                resultSetMapping = "financialSummaryResource"),*/
        @NamedNativeQuery(name = "getCostForFinancialCaseSummaryByGroupCcy",query ="select period, sum(currencyValue) as currencyValue " +
                "from (select 'Hardware' as costtype ,period, sum(currencyValue) as currencyValue " +
                "      from (select period, " +
                "                   gl_category, " +
                "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                "                      sum(ifnull(cost_per_month_gcy, 0))) as currencyValue " +
                "            from sub_workstream_hardware_cost a, " +
                "                 sub_workstream_dates b " +
                "            where a.sub_workstream_id = :subWorkStreamId " +
                "              and a.sub_workstream_name = :subWorkStreamName " +
                "              and gl_category in :glCategories " +
                "              and scenario = :scenario " +
                "              and original_ind = 'false' and a.active_ind='true' " +
                "              and substr(period, 1, 4) = :period " +
                "              and period is not null " +
                "              and a.sub_workstream_id = b.sub_workstream_id " +
                "              and a.sub_workstream_name = b.sub_workstream_name " +
                "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                "            group by period, gl_category) as sumbyglcategory " +
                "      group by costtype,period " +
                "      union  " +
                "      select 'Fin Details' as costtype,period, sum(currencyValue) as currencyValue " +
                "      from (select period, " +
                "                   gl_category, " +
                "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                "                      sum(ifnull(group_ccy_val, 0))) as currencyValue " +
                "            from sub_workstream_fin_details a, " +
                "                 sub_workstream_dates b " +
                "            where a.sub_workstream_id = :subWorkStreamId " +
                "              and a.sub_workstream_name = :subWorkStreamName " +
                "              and gl_category in :glCategories " +
                "              and scenario = :scenario and a.org_ind='false' " +
                "              and substr(period, 1, 4) = :period " +
                "              and period is not null " +
                "              and a.sub_workstream_id = b.sub_workstream_id " +
                "              and a.sub_workstream_name = b.sub_workstream_name " +
                "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                "            group by period, gl_category) as sumbyglcategory " +
                "      group by costtype, period  " +
                "      union " +
                "      select 'Software' as costtype, period, sum(currencyValue) as currencyValue " +
                "      from (select period, " +
                "                   gl_category, " +
                "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                "                      sum(ifnull(cost_per_month_gcy, 0))) as currencyValue " +
                "            from sub_workstream_software_cost a, " +
                "                 sub_workstream_dates b " +
                "            where a.sub_workstream_id = :subWorkStreamId " +
                "              and a.sub_workstream_name = :subWorkStreamName " +
                "              and gl_category in :glCategories " +
                "              and scenario = :scenario " +
                "              and original_ind = 'false' and a.active_ind='true'" +
                "              and substr(period, 1, 4) = :period " +
                "              and period is not null " +
                "              and a.sub_workstream_id = b.sub_workstream_id " +
                "              and a.sub_workstream_name = b.sub_workstream_name " +
                "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                "            group by period, gl_category) as sumbyglcategory " +
                "      group by costtype,period " +
                "      union " +
                "      select 'Resource' as costtype, period, sum(currencyValue) as currencyValue " +
                "      from (select period, " +
                "                   gl_category, " +
                "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                "                      sum(ifnull(blended_cost_gcy, 0))) as currencyValue " +
                "            from sub_workstream_resource_cost a, " +
                "                 sub_workstream_dates b " +
                "            where a.sub_workstream_id = :subWorkStreamId " +
                "              and a.sub_workstream_name = :subWorkStreamName " +
                "              and gl_category in :glCategories " +
                "              and scenario = :scenario " +
                "              and original_ind = 'false' and a.active_ind='true'" +
                "              and substr(period, 1, 4) = :period " +
                "              and period is not null " +
                "              and a.sub_workstream_id = b.sub_workstream_id " +
                "              and a.sub_workstream_name = b.sub_workstream_name " +
                "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                "            group by period, gl_category) as sumbyglcategory " +
                "      group by costtype,period " +
                "union  " +
                "      select 'Others' as costtype, period, sum(currencyValue) as currencyValue " +
                "      from (select period, " +
                "                   gl_category, " +
                "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                "                      sum(ifnull(group_ccy_val, 0))) as currencyValue " +
                "            from sub_workstream_other_cost a, " +
                "                 sub_workstream_dates b " +
                "            where a.sub_workstream_id = :subWorkStreamId " +
                "              and a.sub_workstream_name = :subWorkStreamName " +
                "              and gl_category in :glCategories " +
                "              and scenario = :scenario " +
                "              and original_ind = 'false' and a.active_ind='true'" +
                "              and substr(period, 1, 4) = :period " +
                "              and period is not null " +
                "              and a.sub_workstream_id = b.sub_workstream_id " +
                "              and a.sub_workstream_name = b.sub_workstream_name " +
                "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                "            group by period, gl_category) as sumbyglcategory " +
                "      group by costtype,period  " +
                "     ) as abc " +
                "group by period;" ,resultSetMapping = "financialSummaryResource"),

       /* @NamedNativeQuery(name = "getCostForFinancialCaseSummaryByLocalCcy",query = "select coalesce(sum(currencyValue),0) as currencyValue,coalesce(period,'') as period  from " +
                "(select coalesce(sum(local_ccy_val),0) as currencyValue,period from sub_workstream_fin_details where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                "and gl_category in :glCategories and scenario= :scenario  and org_ind='false'  and substr(period,1,4)= :period and period is not null group by period " +
                "union " +
                "select coalesce(sum(cost_per_month_lcy),0) as currencyValue,period from sub_workstream_software_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false'  and substr(period,1,4)= :period and period is not null group by period " +
                "union " +
                "select coalesce(sum(local_ccy_val),0) as currencyValue,period from sub_workstream_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and substr(period,1,4)= :period and period is not null group by period " +
                "union " +
                "select coalesce(sum(cost_per_month_lcy),0) as currencyValue,period from sub_workstream_hardware_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and substr(period,1,4)= :period  and period is not null group by period " +
                "union " +
                "select coalesce(sum(blended_cost_lcy),0) as currencyValue,period from sub_workstream_resource_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and substr(period,1,4)= :period  and period is not null group by period) as total_cost group by period",
                resultSetMapping = "financialSummaryResource"),*/
        @NamedNativeQuery(name = "getCostForFinancialCaseSummaryByLocalCcy",query ="select period,  sum(currencyValue) as currencyValue  " +
                "from (select 'Hardware' as costtype,period, sum(currencyValue) as currencyValue " +
                "      from (select period, " +
                "                   gl_category, " +
                "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                "                      sum(ifnull(cost_per_month_lcy, 0))) as currencyValue " +
                "            from sub_workstream_hardware_cost a, " +
                "                 sub_workstream_dates b " +
                "            where a.sub_workstream_id = :subWorkStreamId " +
                "              and a.sub_workstream_name = :subWorkStreamName " +
                "              and gl_category in :glCategories " +
                "              and scenario = :scenario " +
                "              and original_ind = 'false' and a.active_ind = 'true'" +
                "              and substr(period, 1, 4) = :period " +
                "              and period is not null " +
                "              and a.sub_workstream_id = b.sub_workstream_id " +
                "              and a.sub_workstream_name = b.sub_workstream_name " +
                "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                "            group by period, gl_category) as sumbyglcategory " +
                "      group by costtype,period " +
                "      union " +
                "      select 'Fin Details' as costtype, period, sum(currencyValue) as currencyValue " +
                "      from (select period, " +
                "                   gl_category, " +
                "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                "                      sum(ifnull(local_ccy_val, 0))) as currencyValue " +
                "            from sub_workstream_fin_details a, " +
                "                 sub_workstream_dates b " +
                "            where a.sub_workstream_id = :subWorkStreamId " +
                "              and a.sub_workstream_name = :subWorkStreamName " +
                "              and gl_category in :glCategories " +
                "              and scenario = :scenario and a.org_ind='false' " +
                "              and substr(period, 1, 4) = :period " +
                "              and period is not null " +
                "              and a.sub_workstream_id = b.sub_workstream_id " +
                "              and a.sub_workstream_name = b.sub_workstream_name " +
                "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                "            group by period, gl_category) as sumbyglcategory " +
                "      group by costtype,period " +
                "      union " +
                "      select 'Software' as costtype, period, sum(currencyValue) as currencyValue " +
                "      from (select period, " +
                "                   gl_category, " +
                "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                "                      sum(ifnull(cost_per_month_lcy, 0))) as currencyValue " +
                "            from sub_workstream_software_cost a, " +
                "                 sub_workstream_dates b " +
                "            where a.sub_workstream_id = :subWorkStreamId " +
                "              and a.sub_workstream_name = :subWorkStreamName " +
                "              and gl_category in :glCategories " +
                "              and scenario = :scenario " +
                "              and original_ind = 'false' and a.active_ind='true'" +
                "              and substr(period, 1, 4) = :period " +
                "              and period is not null " +
                "              and a.sub_workstream_id = b.sub_workstream_id " +
                "              and a.sub_workstream_name = b.sub_workstream_name " +
                "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                "            group by period, gl_category) as sumbyglcategory " +
                "      group by costtype,period " +
                "      union " +
                "      select 'Resource' as costtype, period, sum(currencyValue) as currencyValue " +
                "      from (select period, " +
                "                   gl_category, " +
                "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                "                      sum(ifnull(blended_cost_lcy, 0))) as currencyValue " +
                "            from sub_workstream_resource_cost a, " +
                "                 sub_workstream_dates b " +
                "            where a.sub_workstream_id = :subWorkStreamId " +
                "              and a.sub_workstream_name = :subWorkStreamName " +
                "              and gl_category in :glCategories " +
                "              and scenario = :scenario " +
                "              and original_ind = 'false' and a.active_ind='true'" +
                "              and substr(period, 1, 4) = :period " +
                "              and period is not null " +
                "              and a.sub_workstream_id = b.sub_workstream_id " +
                "              and a.sub_workstream_name = b.sub_workstream_name " +
                "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                "            group by period, gl_category) as sumbyglcategory " +
                "      group by costtype,period  " +
                "  union " +
                "      select 'Others' as costtype,period, sum(currencyValue) as currencyValue " +
                "      from (select period, " +
                "                   gl_category, " +
                "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                "                      sum(ifnull(local_ccy_val, 0))) as currencyValue " +
                "            from sub_workstream_other_cost a, " +
                "                 sub_workstream_dates b " +
                "            where a.sub_workstream_id = :subWorkStreamId " +
                "              and a.sub_workstream_name = :subWorkStreamName " +
                "              and gl_category in :glCategories " +
                "              and scenario = :scenario " +
                "              and original_ind = 'false' and a.active_ind='true'" +
                "              and substr(period, 1, 4) = :period " +
                "              and period is not null " +
                "              and a.sub_workstream_id = b.sub_workstream_id " +
                "              and a.sub_workstream_name = b.sub_workstream_name " +
                "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                "            group by period, gl_category) as sumbyglcategory " +
                "      group by costtype,period " +
                "     ) as abc " +
                "group by period; " ,resultSetMapping = "financialSummaryResource"),
        /*@NamedNativeQuery(name = "getCostForFinancialCaseSummaryValueByGroupCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue  from " +
                        "(select coalesce(sum(group_ccy_val),0) as currencyValue,period from sub_workstream_fin_details where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                        "and gl_category in :glCategories and scenario= :scenario  and org_ind='false'  and period is not null group by period  " +
                        "union " +
                        "select coalesce(sum(cost_per_month_gcy),0) as currencyValue,period from sub_workstream_software_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                        "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and period is not null group by period " +
                        "union " +
                        "select coalesce(sum(group_ccy_val),0) as currencyValue,period from sub_workstream_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName  " +
                        "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and period is not null group by period " +
                        "union " +
                        "select coalesce(sum(cost_per_month_gcy),0) as currencyValue,period from sub_workstream_hardware_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                        "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and period is not null group by period " +
                        "union " +
                        "select coalesce(sum(blended_cost_gcy),0) as currencyValue,period from sub_workstream_resource_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                        "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and period is not null group by period ) as totalCost;",
                resultSetMapping = "financialSummaryResourceResultValue"),*/
        @NamedNativeQuery(name = "getCostForFinancialCaseSummaryValueByGroupCcy",
                query = "select  coalesce(sum(currencyValue),0) as currencyValue  " +
                        "from (select period, sum(currencyValue) as currencyValue " +
                        "      from (select period, " +
                        "                   gl_category, " +
                        "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                        "                      sum(ifnull(cost_per_month_gcy, 0))) as currencyValue " +
                        "            from sub_workstream_hardware_cost a, " +
                        "                 sub_workstream_dates b " +
                        "            where a.sub_workstream_id = :subWorkStreamId " +
                        "              and a.sub_workstream_name = :subWorkStreamName " +
                        "              and gl_category in :glCategories " +
                        "              and scenario = :scenario " +
                        "              and original_ind = 'false' and a.active_ind='true'" +
                        "              and period is not null " +
                        "              and a.sub_workstream_id = b.sub_workstream_id " +
                        "              and a.sub_workstream_name = b.sub_workstream_name " +
                        "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                        "            group by period, gl_category) as sumbyglcategory " +
                        "      group by period " +
                        "      union " +
                        "      select period, sum(currencyValue) as currencyValue " +
                        "      from (select period, " +
                        "                   gl_category, " +
                        "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                        "                      sum(ifnull(group_ccy_val, 0))) as currencyValue " +
                        "            from sub_workstream_fin_details a, " +
                        "                 sub_workstream_dates b " +
                        "            where a.sub_workstream_id = :subWorkStreamId " +
                        "              and a.sub_workstream_name = :subWorkStreamName " +
                        "              and gl_category in :glCategories " +
                        "              and scenario = :scenario and a.org_ind='false' " +
                        "              and period is not null " +
                        "              and a.sub_workstream_id = b.sub_workstream_id " +
                        "              and a.sub_workstream_name = b.sub_workstream_name " +
                        "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                        "            group by period, gl_category) as sumbyglcategory " +
                        "      group by period " +
                        "      union " +
                        "      select period, sum(currencyValue) as currencyValue " +
                        "      from (select period, " +
                        "                   gl_category, " +
                        "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                        "                      sum(ifnull(cost_per_month_gcy, 0))) as currencyValue " +
                        "            from sub_workstream_software_cost a, " +
                        "                 sub_workstream_dates b " +
                        "            where a.sub_workstream_id = :subWorkStreamId " +
                        "              and a.sub_workstream_name = :subWorkStreamName " +
                        "              and gl_category in :glCategories " +
                        "              and scenario = :scenario " +
                        "              and original_ind = 'false' and a.active_ind='true'" +
                        "              and period is not null " +
                        "              and a.sub_workstream_id = b.sub_workstream_id " +
                        "              and a.sub_workstream_name = b.sub_workstream_name " +
                        "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                        "            group by period, gl_category) as sumbyglcategory " +
                        "      group by period " +
                        "      union " +
                        "      select period, sum(currencyValue) as currencyValue " +
                        "      from (select period, " +
                        "                   gl_category, " +
                        "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                        "                      sum(ifnull(blended_cost_gcy, 0))) as currencyValue " +
                        "            from sub_workstream_resource_cost a, " +
                        "                 sub_workstream_dates b " +
                        "            where a.sub_workstream_id = :subWorkStreamId " +
                        "              and a.sub_workstream_name = :subWorkStreamName " +
                        "              and gl_category in :glCategories " +
                        "              and scenario = :scenario " +
                        "              and original_ind = 'false' and a.active_ind='true'" +
                        "              and period is not null " +
                        "              and a.sub_workstream_id = b.sub_workstream_id " +
                        "              and a.sub_workstream_name = b.sub_workstream_name " +
                        "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                        "            group by period, gl_category) as sumbyglcategory " +
                        "      group by period  " +
                        " union " +
                        "  select period, sum(currencyValue) as currencyValue " +
                        "  from (select period, " +
                        "  gl_category, " +
                        "   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                        "   sum(ifnull(group_ccy_val, 0))) as currencyValue " +
                        "  from sub_workstream_other_cost a, " +
                        "  sub_workstream_dates b " +
                        "  where a.sub_workstream_id = :subWorkStreamId " +
                        "  and a.sub_workstream_name = :subWorkStreamName " +
                        "   and gl_category in :glCategories " +
                        "  and scenario = :scenario " +
                        "  and original_ind = 'false' and a.active_ind='true'" +
                        "  and period is not null " +
                        "  and a.sub_workstream_id = b.sub_workstream_id " +
                        "   and a.sub_workstream_name = b.sub_workstream_name " +
                        "   and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                        "    group by period, gl_category) as sumbyglcategory " +
                        "    group by period " +
                        "     ) as abc;",
                resultSetMapping = "financialSummaryResourceResultValue"),
       /* @NamedNativeQuery(name = "getCostForFinancialCaseSummaryValueByLocalCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue  from " +
                        "(select coalesce(sum(local_ccy_val),0) as currencyValue,period from sub_workstream_fin_details where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName  " +
                        "and gl_category in :glCategories and scenario= :scenario  and org_ind='false'  and period is not null group by period  " +
                        "union "+
                        "select coalesce(sum(cost_per_month_lcy),0) as currencyValue,period from sub_workstream_software_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                        "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and period is not null group by period " +
                        "union " +
                        "select coalesce(sum(local_ccy_val),0) as currencyValue,period from sub_workstream_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName  " +
                        "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and period is not null group by period " +
                        "union " +
                        "select coalesce(sum(cost_per_month_lcy),0) as currencyValue,period from sub_workstream_hardware_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                        "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and period is not null group by period " +
                        "union " +
                        "select coalesce(sum(blended_cost_lcy),0) as currencyValue,period from sub_workstream_resource_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                        "and gl_category in :glCategories and scenario= :scenario and active_ind='true' and original_ind='false' and period is not null group by period ) as totalCost;",
                resultSetMapping = "financialSummaryResourceResultValue"),*/
        @NamedNativeQuery(name = "getCostForFinancialCaseSummaryValueByLocalCcy",
                query = "select  coalesce(sum(currencyValue),0) as currencyValue  " +
                        "from (select period, sum(currencyValue) as currencyValue " +
                        "      from (select period, " +
                        "                   gl_category, " +
                        "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                        "                      sum(ifnull(cost_per_month_lcy, 0))) as currencyValue " +
                        "            from sub_workstream_hardware_cost a, " +
                        "                 sub_workstream_dates b " +
                        "            where a.sub_workstream_id = :subWorkStreamId " +
                        "              and a.sub_workstream_name = :subWorkStreamName " +
                        "              and gl_category in :glCategories " +
                        "              and scenario = :scenario " +
                        "              and original_ind = 'false' and a.active_ind='true'" +
                        "              and period is not null " +
                        "              and a.sub_workstream_id = b.sub_workstream_id " +
                        "              and a.sub_workstream_name = b.sub_workstream_name " +
                        "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                        "            group by period, gl_category) as sumbyglcategory " +
                        "      group by period " +
                        "      union " +
                        "      select period, sum(currencyValue) as currencyValue " +
                        "      from (select period, " +
                        "                   gl_category, " +
                        "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                        "                      sum(ifnull(local_ccy_val, 0))) as currencyValue " +
                        "            from sub_workstream_fin_details a, " +
                        "                 sub_workstream_dates b " +
                        "            where a.sub_workstream_id = :subWorkStreamId " +
                        "              and a.sub_workstream_name = :subWorkStreamName " +
                        "              and gl_category in :glCategories " +
                        "              and scenario = :scenario and a.org_ind='false' " +
                        "              and period is not null " +
                        "              and a.sub_workstream_id = b.sub_workstream_id " +
                        "              and a.sub_workstream_name = b.sub_workstream_name " +
                        "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                        "            group by period, gl_category) as sumbyglcategory  " +
                        "      group by period " +
                        "      union " +
                        "      select period, sum(currencyValue) as currencyValue " +
                        "      from (select period, " +
                        "                   gl_category, " +
                        "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                        "                      sum(ifnull(cost_per_month_lcy, 0))) as currencyValue " +
                        "            from sub_workstream_software_cost a, " +
                        "                 sub_workstream_dates b " +
                        "            where a.sub_workstream_id = :subWorkStreamId  " +
                        "              and a.sub_workstream_name = :subWorkStreamName  " +
                        "              and gl_category in :glCategories " +
                        "              and scenario = :scenario " +
                        "              and original_ind = 'false' and a.active_ind='true'" +
                        "              and period is not null " +
                        "              and a.sub_workstream_id = b.sub_workstream_id " +
                        "              and a.sub_workstream_name = b.sub_workstream_name " +
                        "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                        "            group by period, gl_category) as sumbyglcategory " +
                        "      group by period " +
                        "      union " +
                        "      select period, sum(currencyValue) as currencyValue " +
                        "      from (select period, " +
                        "                   gl_category, " +
                        "                   if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                        "                      sum(ifnull(blended_cost_lcy, 0))) as currencyValue " +
                        "            from sub_workstream_resource_cost a, " +
                        "                 sub_workstream_dates b " +
                        "            where a.sub_workstream_id = :subWorkStreamId " +
                        "              and a.sub_workstream_name = :subWorkStreamName " +
                        "              and gl_category in :glCategories " +
                        "              and scenario = :scenario " +
                        "              and original_ind = 'false' and a.active_ind='true'" +
                        "              and period is not null " +
                        "              and a.sub_workstream_id = b.sub_workstream_id " +
                        "              and a.sub_workstream_name = b.sub_workstream_name " +
                        "              and b.active_ind = 'true' and a.scenario = b.scenario_name " +
                        "            group by period, gl_category) as sumbyglcategory " +
                        "      group by period " +
                        "union " +
                        "select period, sum(currencyValue) as currencyValue " +
                        "from (select period, " +
                        "gl_category, " +
                        " if(gl_category in (:conditionalGlCategories) and a.scenario = 'Forecast' and period > date_format(go_live_date, '%Y%m'), 0, " +
                        " sum(ifnull(local_ccy_val, 0))) as currencyValue " +
                        "from sub_workstream_other_cost a, " +
                        "sub_workstream_dates b  " +
                        "where a.sub_workstream_id = :subWorkStreamId " +
                        "and a.sub_workstream_name = :subWorkStreamName " +
                        " and gl_category in :glCategories " +
                        "and scenario = :scenario " +
                        "and original_ind = 'false' and a.active_ind='true'" +
                        "and period is not null " +
                        "and a.sub_workstream_id = b.sub_workstream_id " +
                        " and a.sub_workstream_name = b.sub_workstream_name " +
                        " and b.active_ind = 'true'  and a.scenario = b.scenario_name " +
                        "  group by period, gl_category) as sumbyglcategory " +
                        "  group by period " +
                        "    ) as abc;",
                resultSetMapping = "financialSummaryResourceResultValue"),

        @NamedNativeQuery(name = "getSubWorkStreamIdAndSubWorkStreamName", query = "select distinct sub_workstream_id as subWorkStreamId ," +
                "sub_workstream_name as subWorkStreamName from sub_workstream_fin_details where workstream_id= :workStreamId",
                resultSetMapping = "workStreamIdAndName")
       })

@NamedStoredProcedureQuery(name = "sp_sws_backend_fin_details", procedureName = "sp_sws_backend_fin_details",parameters = {
        @StoredProcedureParameter(mode = ParameterMode.IN, name = "subwkstream_id",type = String.class),
        @StoredProcedureParameter(mode = ParameterMode.IN, name = "subwkstream_name",type = String.class),
        @StoredProcedureParameter(mode = ParameterMode.IN, name = "rptyear",type = String.class),
        @StoredProcedureParameter(mode = ParameterMode.IN, name = "cost_component",type = String.class)
})

@NamedStoredProcedureQuery(name = "updateAllPreviousMonthForecast", procedureName = "sp_update_allprevious_month_forecast_to_inactive_on_useraction",parameters = {
        @StoredProcedureParameter(mode = ParameterMode.IN, name = "subworkstream_id",type = String.class),
        @StoredProcedureParameter(mode = ParameterMode.IN, name = "subworkstream_name",type = String.class),

})

@NamedStoredProcedureQuery(name = "sp_create_snapshot", procedureName = "sp_create_snapshot",parameters = {
        @StoredProcedureParameter(mode = ParameterMode.IN, name = "copyfrom",type = String.class),
        @StoredProcedureParameter(mode = ParameterMode.IN, name = "copyto",type = String.class),

})

@Data
@Entity
@Table(name = "sub_workstream_fin_details")
@EntityListeners(AuditingEntityListener.class)
public class SubWorkstreamFinDetailsEntity extends CommonEntity<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sws_fd_surr_id")
    private Integer subWorkStreamFinSurrId;

    @Column(name = "workstream_id")
    private String workstreamId;

    @Column(name = "sub_workstream_id")
    private String subWorkstreamId;

    @Column(name = "sub_workstream_name")
    private String subWorkstreamName;

    @Column(name = "scenario")
    private String scenario;

    @Column(name = "gl_category")
    private String glCategory;

    @Column(name = "cost_type")
    private String costType;

    @Column(name = "period")
    private String period;

    @Column(name = "local_ccy")
    private String localCcy;

    @Column(name = "group_ccy")
    private String groupCcy;

    @Column(name = "local_ccy_val")
    private BigDecimal localCcyVal;

    @Column(name = "group_ccy_val")
    private BigDecimal groupCcyVal;

    @Column(name = "cost_type_detail")
    private String costTypeDetail;

    @Column(name = "cost_settings")
    private String costSetting;

    @Column(name = "org_ind")
    private String orgInd;

    @Column(name = "ref_sws_fd_surr_id")
    private Integer refSwsFdSurrId;

    public static SubWorkstreamFinDetailsEntity
    build(String workStreamId, String subWorkStreamId, String subWorkStreamName,
                               String glCategory, String costType,
                               String yearMonth, String costSetting,
                               String scenario, String orgInd, Integer surrId) {
        SubWorkstreamFinDetailsEntity finDetailsEntity = new SubWorkstreamFinDetailsEntity();
        finDetailsEntity.setWorkstreamId(workStreamId);
        finDetailsEntity.setSubWorkstreamId(subWorkStreamId);
        finDetailsEntity.setSubWorkstreamName(subWorkStreamName);
        finDetailsEntity.setCostSetting(costSetting);
        finDetailsEntity.setScenario(scenario);
        finDetailsEntity.setGlCategory(glCategory);
        finDetailsEntity.setCostType(costType);
        finDetailsEntity.setPeriod(yearMonth);
        finDetailsEntity.setOrgInd(orgInd);
        finDetailsEntity.setRefSwsFdSurrId(surrId);
        finDetailsEntity.setCostTypeDetail(PortfolioConstants.SCENARIO_FORECAST);
        return finDetailsEntity;
    }
}
