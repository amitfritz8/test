package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.apache.logging.log4j.util.Strings;

import java.math.BigDecimal;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class SubWorkStreamSoftwareCostResource {

    private String vendor;
    private String softwareName;
    private String softwareType;
    private String currency;
    private BigDecimal unitPrice;
    private BigDecimal qty;
    private String costInCurrency;
    private BigDecimal costPerMonth;
    private String activeInd;
    private Integer surrId;

    public boolean validate() {
        return Strings.isNotEmpty(vendor) && Strings.isNotEmpty(softwareName) && Strings.isNotEmpty(softwareType)
                && Strings.isNotEmpty(currency) && Strings.isNotEmpty(costInCurrency);

    }

}
