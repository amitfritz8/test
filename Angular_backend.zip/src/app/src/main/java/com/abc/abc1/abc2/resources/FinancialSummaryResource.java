package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
import java.math.BigDecimal;
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@NoArgsConstructor
public class FinancialSummaryResource {

    BigDecimal currencyValue = BigDecimal.ZERO;
    String period;
    BigDecimal fte = BigDecimal.ZERO;
    BigDecimal grpCurrencyValue = BigDecimal.ZERO;

    public FinancialSummaryResource(BigDecimal currencyValue, String period, BigDecimal fte) {
        this.currencyValue = currencyValue;
        this.period = period;
        this.fte = fte;
    }

    public FinancialSummaryResource(BigDecimal currencyValue, String period) {
        this.currencyValue = currencyValue;
        this.period = period;
    }

    public FinancialSummaryResource(BigDecimal currencyValue, BigDecimal grpCurrencyValue) {
        this.currencyValue = currencyValue;
        this.grpCurrencyValue = grpCurrencyValue;
    }

    public FinancialSummaryResource(BigDecimal currencyValue) {
        this.currencyValue = currencyValue;
    }

    public FinancialSummaryResource(String period) {
        this.period = period;
    }
}
