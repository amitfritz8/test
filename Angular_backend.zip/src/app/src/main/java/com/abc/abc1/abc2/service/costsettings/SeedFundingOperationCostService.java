package com.dbs.genesis.portfolio.service.costsettings;

import com.dbs.genesis.portfolio.common.DateExtensions;
import com.dbs.genesis.portfolio.common.MathExtentions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.SubWorkStreamKeyDatesEntity;
import com.dbs.genesis.portfolio.model.SubWorkstreamFinDetailsEntity;
import com.dbs.genesis.portfolio.repository.SubWorkStreamKeyDatesRepo;
import com.dbs.genesis.portfolio.repository.SubWorkstreamFinDetailsRepo;
import com.dbs.genesis.portfolio.resources.CostSettingsUpdateEvent;
import com.dbs.genesis.portfolio.resources.SeedFundingCostType;
import com.dbs.genesis.portfolio.resources.SeedFundingOperationCostResource;
import com.dbs.genesis.portfolio.service.financials.FinancialService;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@Transactional
public class SeedFundingOperationCostService implements MathExtentions, DateExtensions {


    private final SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo;
    private final SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    private final FinancialDetailsService financialDetailsService;
    private final ApplicationEventPublisher publisher;

    @Autowired
    public SeedFundingOperationCostService(SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo,
                                           SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo,
                                           FinancialDetailsService financialDetailsService,
                                           ApplicationEventPublisher publisher) {
        this.subWorkstreamFinDetailsRepo = subWorkstreamFinDetailsRepo;
        this.subWorkStreamKeyDatesRepo = subWorkStreamKeyDatesRepo;
        this.financialDetailsService = financialDetailsService;
        this.publisher = publisher;
    }


    public List<SubWorkstreamFinDetailsEntity>
    saveSeedFundingOperationCost(SeedFundingOperationCostResource seedFundingOperationCostResource) {
         SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity= getKeyDates(seedFundingOperationCostResource.getWorkStreamId(),
                 seedFundingOperationCostResource.getSubWorkStreamId(),seedFundingOperationCostResource.getSubWorkStreamName(),seedFundingOperationCostResource.getScenario());
        List<String> currentYearMonthBetweenDates = getMonthYearListByAddingMonths(subWorkStreamKeyDatesEntity.getStartDate(), 3);
        List<SubWorkstreamFinDetailsEntity> subWorkStreamFinDetailsEntities = Lists.newArrayList();
        for (SeedFundingCostType seedFundingCostType : seedFundingOperationCostResource.getSeedFundingCostTypes()) {
            subWorkStreamFinDetailsEntities.addAll(saveSeedFundingOperationCostByYearMonth(seedFundingOperationCostResource,
                    seedFundingCostType, currentYearMonthBetweenDates));
        }

        publisher.publishEvent(new CostSettingsUpdateEvent(seedFundingOperationCostResource.getSubWorkStreamId(),
                seedFundingOperationCostResource.getSubWorkStreamName(),getCurrentYear(),PortfolioConstants.PROC_COST_COMP_HLE_FD));

        return subWorkStreamFinDetailsEntities;
    }

    private List<SubWorkstreamFinDetailsEntity>
    saveSeedFundingOperationCostByYearMonth(
            SeedFundingOperationCostResource seedFundingOperationCostResource,
            SeedFundingCostType seedFundingCostType,
            List<String> currentYearMonthBetweenDates) {

        Optional<SubWorkstreamFinDetailsEntity> subWorkStreamFinDetailsEntityOptional =
                subWorkstreamFinDetailsRepo.findById(seedFundingCostType.getSfSurrId());
        SubWorkstreamFinDetailsEntity finDetails = subWorkStreamFinDetailsEntityOptional.map(
                subWorkStreamFinDetailsEntity ->
                        updateSeedFundingOperationCost(seedFundingOperationCostResource, seedFundingCostType,
                                subWorkStreamFinDetailsEntity)).orElseGet(
                () -> createNewSeedFundingOperationCost(seedFundingOperationCostResource, seedFundingCostType));
        List<SubWorkstreamFinDetailsEntity> subWorkStreamFinDetailsEntities = subWorkstreamFinDetailsRepo
                .findByRefSwsFdSurrIdAndOrgIndIgnoreCase(finDetails.getSubWorkStreamFinSurrId(), PortfolioConstants.FALSE);

        return subWorkStreamFinDetailsEntities.isEmpty() ? createOperationCostsWithOriginalIndicatorFalse(seedFundingOperationCostResource,
                seedFundingCostType,
                currentYearMonthBetweenDates,
                finDetails) :
                updateOperationCostsWithOriginalIndicatorFalse(seedFundingOperationCostResource, seedFundingCostType, subWorkStreamFinDetailsEntities);
    }

    private List<SubWorkstreamFinDetailsEntity>
    updateOperationCostsWithOriginalIndicatorFalse(
            SeedFundingOperationCostResource seedFundingOperationCostResource,
            SeedFundingCostType seedFundingCostType,
            List<SubWorkstreamFinDetailsEntity> subWorkStreamFinDetailsEntities) {
        List<String> months = subWorkStreamFinDetailsEntities.stream().map(SubWorkstreamFinDetailsEntity::getPeriod).collect(Collectors.toList());
        List<SubWorkstreamFinDetailsEntity> finDetailsEntityList = subWorkStreamFinDetailsEntities.stream().peek(
                subWorkStreamFinDetailsEntityExisting ->
                        financialDetailsService.updateCurrencyValuesMonthly(
                                seedFundingOperationCostResource.getCurrencyCode(),
                                seedFundingCostType.getValue(), months,
                                subWorkStreamFinDetailsEntityExisting)).collect(Collectors.toList());
        return subWorkstreamFinDetailsRepo.saveAll(finDetailsEntityList);
    }

    private List<SubWorkstreamFinDetailsEntity>
    createOperationCostsWithOriginalIndicatorFalse(SeedFundingOperationCostResource seedFundingOperationCostResource,
                                                   SeedFundingCostType seedFundingCostType,
                                                   List<String> currentYearMonthBetweenDates,
                                                   SubWorkstreamFinDetailsEntity finDetails) {
        if (!currentYearMonthBetweenDates.isEmpty()) {
            List<SubWorkstreamFinDetailsEntity> finDetailsEntityList = currentYearMonthBetweenDates.stream().map(
                    yearMonth -> {
                        SubWorkstreamFinDetailsEntity finDetailsEntity = SubWorkstreamFinDetailsEntity.build(finDetails.getWorkstreamId(),
                                finDetails.getSubWorkstreamId(), finDetails.getSubWorkstreamName(),
                                finDetails.getGlCategory(), finDetails.getCostType(), yearMonth,
                                finDetails.getCostSetting(), finDetails.getScenario(),
                                PortfolioConstants.ORIGINAL_INDICATOR_FALSE,
                                finDetails.getSubWorkStreamFinSurrId());
                        financialDetailsService.updateCurrencyValuesMonthly(
                                seedFundingOperationCostResource.getCurrencyCode(),
                                seedFundingCostType.getValue(),
                                currentYearMonthBetweenDates, finDetailsEntity);
                        return finDetailsEntity;
                    }).collect(Collectors.toList());
            return subWorkstreamFinDetailsRepo.saveAll(finDetailsEntityList);
        }
        return Lists.newArrayList();
    }

    private SubWorkstreamFinDetailsEntity
    createNewSeedFundingOperationCost(SeedFundingOperationCostResource seedFundingOperationCostResource,
                                      SeedFundingCostType seedFundingCostType) {
        SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity = SubWorkstreamFinDetailsEntity.build(
                seedFundingOperationCostResource.getWorkStreamId(), seedFundingOperationCostResource.getSubWorkStreamId(),
                seedFundingOperationCostResource.getSubWorkStreamName(), seedFundingCostType.getGlCategoryName(),
                seedFundingCostType.getCostType(), getCurrentPeriod(),
                PortfolioConstants.COST_SETTING_TYPE_SEED_FUNDING,
                seedFundingOperationCostResource.getScenario(),
                PortfolioConstants.ORIGINAL_INDICATOR_TRUE, null);
        financialDetailsService.updateCurrencyValues(subWorkstreamFinDetailsEntity,
                seedFundingOperationCostResource.getCurrencyCode(),
                seedFundingCostType.getValue()
                );
        return subWorkstreamFinDetailsRepo.save(subWorkstreamFinDetailsEntity);
    }

    private SubWorkstreamFinDetailsEntity
    updateSeedFundingOperationCost(SeedFundingOperationCostResource seedFundingOperationCostResource,
                                   SeedFundingCostType seedFundingCostType,
                                   SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity) {
        financialDetailsService.updateCurrencyValues(subWorkstreamFinDetailsEntity,
                seedFundingOperationCostResource.getCurrencyCode(), seedFundingCostType.getValue()
                );
        return subWorkstreamFinDetailsRepo.save(subWorkstreamFinDetailsEntity);
    }

    public SubWorkStreamKeyDatesEntity getKeyDates(String workStreamId, String subWorkStreamId , String subWorkStreamName, String scenarioName ) {
        return subWorkStreamKeyDatesRepo.findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(
                workStreamId, subWorkStreamId, subWorkStreamName, PortfolioConstants.TRUE, scenarioName);
    }

    private String getCurrentPeriod() {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String startDateString = df.format(Date.from(Instant.now()));
        return startDateString.substring(0, 7).replaceAll("-", "");
    }

}
