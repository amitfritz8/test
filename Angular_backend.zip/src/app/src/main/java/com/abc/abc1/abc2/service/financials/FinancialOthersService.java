package com.dbs.genesis.portfolio.service.financials;

import com.amazonaws.util.CollectionUtils;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.CommonEntity;
import com.dbs.genesis.portfolio.model.SubWorkstreamOtherCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import com.dbs.genesis.portfolio.repository.SubWorkstreamOtherCostRepo;
import com.dbs.genesis.portfolio.resources.MonthlyCostTypeData;
import com.dbs.genesis.portfolio.resources.MonthlyFinancialDetailsResource;
import com.dbs.genesis.portfolio.resources.MonthlyFinancialResource;
import com.dbs.genesis.portfolio.service.SubWorkStreamService;
import com.dbs.genesis.portfolio.service.costsettings.FinancialDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class FinancialOthersService {

    private final FinancialDetailsService financialDetailsService;
    private final SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo;
    private SubWorkStreamService subWorkStreamService;
    private FinancialService financialService;

    public FinancialOthersService(FinancialDetailsService financialDetailsService, SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo, SubWorkStreamService subWorkStreamService, FinancialService financialService) {
        this.financialDetailsService = financialDetailsService;
        this.subWorkstreamOtherCostRepo = subWorkstreamOtherCostRepo;
        this.subWorkStreamService = subWorkStreamService;
        this.financialService = financialService;
    }

    public void persistOthers(MonthlyFinancialResource monthlyFinancialResource, MonthlyFinancialDetailsResource financialDetail, String year) {
         financialDetail.getMonthlyCostTypeDataList().stream().forEach(monthlyOthers -> {
             SubWorkstreamOtherCost subWorkstreamOtherCost = subWorkstreamOtherCostRepo.findById(monthlyOthers.getSurrId()).get();
            List<SubWorkstreamOtherCost> subWorkstreamOtherCosts = getOtherCostsEntity(subWorkstreamOtherCost,monthlyFinancialResource, monthlyOthers, year);
             subWorkstreamOtherCostRepo.saveAll(subWorkstreamOtherCosts);
             if(PortfolioConstants.OPEX.equalsIgnoreCase(subWorkstreamOtherCost.getGlCategory())){
                 List<SubWorkstreamOtherCost> subWorkstreamOtherCostOwnerships = createSubWorkstreamOtherCostsOwnershipForMonthly(
                         subWorkstreamOtherCosts,monthlyFinancialResource.getSubWorkStreamId(),
                         monthlyFinancialResource.getSubWorkStreamName(),monthlyFinancialResource.getScenario(),monthlyOthers.getSurrId());
                 subWorkstreamOtherCostRepo.saveAll(subWorkstreamOtherCostOwnerships);
             }else{
                 saveItDepreciation(monthlyOthers,monthlyFinancialResource.getCurrencyCode(),monthlyFinancialResource.getCurrencyCodes(),monthlyFinancialResource.getScenario());
             }

        });
    }

    public void persistOthersIndividual(MonthlyFinancialResource monthlyFinancialResource, MonthlyCostTypeData monthlyCostTypeData, String year) {
        SubWorkstreamOtherCost subWorkstreamOtherCost = subWorkstreamOtherCostRepo.findById(monthlyCostTypeData.getSurrId()).get();
            List<SubWorkstreamOtherCost> subWorkstreamOtherCosts = getOtherCostsEntity(subWorkstreamOtherCost,monthlyFinancialResource, monthlyCostTypeData, year);
             subWorkstreamOtherCostRepo.saveAll(subWorkstreamOtherCosts);
        if(PortfolioConstants.OPEX.equalsIgnoreCase(subWorkstreamOtherCost.getGlCategory())){
            List<SubWorkstreamOtherCost> subWorkstreamOtherCostOwnerships = createSubWorkstreamOtherCostsOwnershipForMonthly(
                    subWorkstreamOtherCosts,monthlyFinancialResource.getSubWorkStreamId(),
                    monthlyFinancialResource.getSubWorkStreamName(),monthlyFinancialResource.getScenario(),monthlyCostTypeData.getSurrId());
            subWorkstreamOtherCostRepo.saveAll(subWorkstreamOtherCostOwnerships);
        }else{
            saveItDepreciation(monthlyCostTypeData,monthlyFinancialResource.getCurrencyCode(),monthlyFinancialResource.getCurrencyCodes(),monthlyFinancialResource.getScenario());
        }
    }

    private List<SubWorkstreamOtherCost> getOtherCostsEntity(SubWorkstreamOtherCost subWorkstreamOtherCost,MonthlyFinancialResource monthlyFinancialResource, MonthlyCostTypeData monthlyOthers, String year) {

        List<SubWorkstreamOtherCost> subWorkstreamOtherCosts = monthlyOthers.getMonthlyData().stream().map(monthlyData -> {
            if (monthlyData.getSurrId() == null || monthlyData.getSurrId().intValue() == 0) {
                SubWorkstreamOtherCost newSubWorkstreamOtherCost = getNewOtherMonthlyData(subWorkstreamOtherCost, monthlyFinancialResource.getScenario(),
                        PortfolioConstants.ORIGINAL_INDICATOR_FALSE, monthlyData.getMonthNumber(), year);
                updateCurrencyValuesForOthers(newSubWorkstreamOtherCost, monthlyFinancialResource.getCurrencyCode(), monthlyData.getValue(), monthlyFinancialResource.getCurrencyCodes());
                return newSubWorkstreamOtherCost;
            } else {
                SubWorkstreamOtherCost existingSubWorkstreamOtherCost = subWorkstreamOtherCostRepo.findById(monthlyData.getSurrId()).get();
                updateCurrencyValuesForOthers(existingSubWorkstreamOtherCost, monthlyFinancialResource.getCurrencyCode(), monthlyData.getValue(), monthlyFinancialResource.getCurrencyCodes());
                return existingSubWorkstreamOtherCost;
            }
        }).collect(Collectors.toList());
        return subWorkstreamOtherCosts;
    }

    private SubWorkstreamOtherCost getNewOtherMonthlyData(SubWorkstreamOtherCost subWorkstreamOtherCost, String scenario, String originalIndicatorFalse, String month, String year) {
        SubWorkstreamOtherCost newSubWorkStreamOtherCost = new SubWorkstreamOtherCost();
        newSubWorkStreamOtherCost.setWorkStreamId(subWorkstreamOtherCost.getWorkStreamId());
        newSubWorkStreamOtherCost.setSubWorkStreamId(subWorkstreamOtherCost.getSubWorkStreamId());
        newSubWorkStreamOtherCost.setSubWorkStreamName(subWorkstreamOtherCost.getSubWorkStreamName());
        newSubWorkStreamOtherCost.setGlCategory(subWorkstreamOtherCost.getGlCategory());
        newSubWorkStreamOtherCost.setCostSettings(subWorkstreamOtherCost.getCostSettings());
        newSubWorkStreamOtherCost.setVendorName(subWorkstreamOtherCost.getVendorName());
        newSubWorkStreamOtherCost.setType(subWorkstreamOtherCost.getType());
        newSubWorkStreamOtherCost.setAddOther(subWorkstreamOtherCost.getAddOther());
        newSubWorkStreamOtherCost.setActiveInd(subWorkstreamOtherCost.getActiveInd());
        newSubWorkStreamOtherCost.setScenario(scenario);
        newSubWorkStreamOtherCost.setOriginalInd(originalIndicatorFalse);
        newSubWorkStreamOtherCost.setOtherDesc(subWorkstreamOtherCost.getOtherDesc());
        newSubWorkStreamOtherCost.setRefSwsOtherSurrId(subWorkstreamOtherCost.getSwsOtherSurrId());
        newSubWorkStreamOtherCost.setPeriod(year + month);
        return newSubWorkStreamOtherCost;
    }

    private void updateCurrencyValuesForOthers(SubWorkstreamOtherCost subWorkstreamOtherCost, String currencyCode, BigDecimal cost, HashSet<String> currencyCodes) {
        if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode))
            updateCurrencyValuesForGroupForOther(subWorkstreamOtherCost, currencyCode, cost, currencyCodes);
        else
            updateCurrencyValuesForLocalForOther(subWorkstreamOtherCost, currencyCode, cost, currencyCodes);
    }

    private SubWorkstreamOtherCost
    updateCurrencyValuesForLocalForOther(SubWorkstreamOtherCost subWorkStreamOtherCost,
                                         String loggedInCurrencyCode,
                                         BigDecimal currencyValue,
                                         HashSet<String> currencyCodes) {
        subWorkStreamOtherCost.setLocalCcyVal(currencyValue);
        subWorkStreamOtherCost.setLocalCcy(loggedInCurrencyCode);
        currencyCodes.remove(loggedInCurrencyCode);
        if (!currencyCodes.isEmpty()) {
            subWorkStreamOtherCost.setGroupCcy(currencyCodes.iterator().next());
            subWorkStreamOtherCost.setGroupCcyVal(currencyValue.multiply(financialDetailsService.getExchangeValue
                    (subWorkStreamOtherCost.getPeriod(), loggedInCurrencyCode, subWorkStreamOtherCost.getWorkStreamId())));
        } else {
            subWorkStreamOtherCost.setGroupCcy(loggedInCurrencyCode);
            subWorkStreamOtherCost.setGroupCcyVal(currencyValue);
        }

        return subWorkStreamOtherCost;
    }

    private SubWorkstreamOtherCost
    updateCurrencyValuesForGroupForOther(SubWorkstreamOtherCost subWorkstreamOtherCost,
                                         String loggedInCurrencyCode,
                                         BigDecimal value,
                                         HashSet<String> currencyCodes) {
        subWorkstreamOtherCost.setGroupCcyVal(value);
        subWorkstreamOtherCost.setGroupCcy(loggedInCurrencyCode);
        currencyCodes.remove(loggedInCurrencyCode);
        if (!currencyCodes.isEmpty()) {
            subWorkstreamOtherCost.setLocalCcy(currencyCodes.iterator().next());
            BigDecimal exchangedValue = financialDetailsService.getExchangeValue
                    (subWorkstreamOtherCost.getPeriod(), subWorkstreamOtherCost.getLocalCcy(), subWorkstreamOtherCost.getWorkStreamId());
            subWorkstreamOtherCost.setLocalCcyVal(value.divide(exchangedValue, 9, RoundingMode.HALF_UP));
        } else {
            subWorkstreamOtherCost.setLocalCcy(loggedInCurrencyCode);
            subWorkstreamOtherCost.setLocalCcyVal(value);
        }
        return subWorkstreamOtherCost;
    }

    private void saveItDepreciation(MonthlyCostTypeData monthlyCostTypeData,String currencyCode, HashSet<String> currencyCodes,String scenario){
        Optional<SubWorkstreamOtherCost> subWorkstreamOtherCostOptional = subWorkstreamOtherCostRepo.findById(monthlyCostTypeData.getSurrId());
        if(subWorkstreamOtherCostOptional.isPresent() && subWorkstreamOtherCostOptional.get().getGlCategory().equalsIgnoreCase(PortfolioConstants.CAPEX)){
            SubWorkstreamOtherCost subWorkstreamOtherCostItDepre = subWorkstreamOtherCostRepo.findByScenarioAndCapexOpexSurrIdAndGlCategoryAndOriginalIndAndActiveInd(scenario,
                    subWorkstreamOtherCostOptional.get().getSwsOtherSurrId(),PortfolioConstants.ITDEPRECIATION,PortfolioConstants.TRUE,PortfolioConstants.TRUE);
            List<SubWorkstreamOtherCost> subWorkstreamOtherCostsWithCapex = createItDepreciation(subWorkstreamOtherCostOptional.get(),currencyCode,currencyCodes,subWorkstreamOtherCostItDepre.getSwsOtherSurrId());
            if(!CollectionUtils.isNullOrEmpty(subWorkstreamOtherCostsWithCapex)) {
                deleteItDepreRecords(subWorkstreamOtherCostItDepre.getSwsOtherSurrId(), subWorkstreamOtherCostOptional.get().getSubWorkStreamId(),
                        subWorkstreamOtherCostOptional.get().getSubWorkStreamName(),subWorkstreamOtherCostOptional.get().getScenario());
                subWorkstreamOtherCostRepo.saveAll(subWorkstreamOtherCostsWithCapex);
            }
        }

    }

    private void deleteItDepreRecords(Integer ItDepreSurrId, String subWorkstreamId, String subWorkstreamName, String scenario) {
        List<SubWorkstreamOtherCost> subWorkstreamOtherCosts =subWorkstreamOtherCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndGlCategoryAndRefSwsOtherSurrIdAndActiveIndAndOriginalInd
                (subWorkstreamId, subWorkstreamName, scenario, PortfolioConstants.ITDEPRECIATION, ItDepreSurrId,PortfolioConstants.TRUE,PortfolioConstants.FALSE);
        subWorkstreamOtherCostRepo.deleteAll(subWorkstreamOtherCosts);
    }

    private List<SubWorkstreamOtherCost> createItDepreciation(SubWorkstreamOtherCost subWorkstreamOtherCost,String currencyCode, HashSet<String> currencyCodes,Integer itDepreSurrId) {
        BigDecimal totalCapex = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                subWorkstreamOtherCostRepo.getTotalCapexForOthersByGrpCcy(subWorkstreamOtherCost.getSubWorkStreamId(),subWorkstreamOtherCost.getSubWorkStreamName(),
                subWorkstreamOtherCost.getScenario(),PortfolioConstants.CAPEX,subWorkstreamOtherCost.getSwsOtherSurrId())
                : subWorkstreamOtherCostRepo.getTotalCapexForOthersByLocalCcy(subWorkstreamOtherCost.getSubWorkStreamId(),subWorkstreamOtherCost.getSubWorkStreamName(),
                subWorkstreamOtherCost.getScenario(),PortfolioConstants.CAPEX,subWorkstreamOtherCost.getSwsOtherSurrId());

        Map<String, Object> dateDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategories(subWorkstreamOtherCost.getWorkStreamId(),
                subWorkstreamOtherCost.getSubWorkStreamId(), subWorkstreamOtherCost.getSubWorkStreamName(), subWorkstreamOtherCost.getScenario(),
                PortfolioConstants.GL_CATEGORY_ITDEPRECIATION, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
        List<String> monthBetweenDates = (List<String>) dateDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);
        Integer capexOpexSurrId = subWorkstreamOtherCost.getSwsOtherSurrId();
        return monthBetweenDates.stream().map(month -> {
            SubWorkstreamOtherCost subWorkstreamOtherCostNew = new SubWorkstreamOtherCost();
            subWorkstreamOtherCostNew.setWorkStreamId(subWorkstreamOtherCost.getWorkStreamId());
            subWorkstreamOtherCostNew.setSubWorkStreamId(subWorkstreamOtherCost.getSubWorkStreamId());
            subWorkstreamOtherCostNew.setSubWorkStreamName(subWorkstreamOtherCost.getSubWorkStreamName());
            subWorkstreamOtherCostNew.setType(subWorkstreamOtherCost.getType());
            subWorkstreamOtherCostNew.setVendorName(subWorkstreamOtherCost.getVendorName());
            subWorkstreamOtherCostNew.setScenario(subWorkstreamOtherCost.getScenario());
            subWorkstreamOtherCostNew.setCostSettings(subWorkstreamOtherCost.getCostSettings());
            subWorkstreamOtherCostNew.setCostTypeDetail(subWorkstreamOtherCost.getCostTypeDetail());
            subWorkstreamOtherCostNew.setQuantity(subWorkstreamOtherCost.getQuantity());
            subWorkstreamOtherCostNew.setOtherDesc(subWorkstreamOtherCost.getOtherDesc());
            subWorkstreamOtherCostNew.setAddOther(subWorkstreamOtherCost.getAddOther());
            subWorkstreamOtherCostNew.setOriginalInd(PortfolioConstants.FALSE);
            subWorkstreamOtherCostNew.setGlCategory(PortfolioConstants.ITDEPRECIATION);
            subWorkstreamOtherCostNew.setActiveInd(PortfolioConstants.TRUE);
            subWorkstreamOtherCostNew.setRefSwsOtherSurrId(itDepreSurrId);
            subWorkstreamOtherCostNew.setCapexOpexSurrId(capexOpexSurrId);
            subWorkstreamOtherCostNew.setPeriod(month);
            subWorkstreamOtherCostNew.setSwsOtherSurrId(0);
            updateCurrencyValuesForDepreOther(subWorkstreamOtherCostNew,currencyCode,currencyCodes,totalCapex,monthBetweenDates.size());
            return subWorkstreamOtherCostNew;
        }).collect(Collectors.toList());
    }


    public void updateCurrencyValuesForDepreOther(SubWorkstreamOtherCost subWorkstreamOtherCost,
                                                  String currencyCode, HashSet<String> currencyCodes, BigDecimal totalCapex, int noOfMonths) {
        if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode))
            updateCurrencyValuesForGroupForOtherDepre(subWorkstreamOtherCost, currencyCode,  currencyCodes,totalCapex,noOfMonths);
        else
            updateCurrencyValuesForLocalForOtherDepre(subWorkstreamOtherCost, currencyCode, currencyCodes,totalCapex,noOfMonths);

    }

    private SubWorkstreamOtherCost
    updateCurrencyValuesForLocalForOtherDepre(SubWorkstreamOtherCost subWorkstreamOtherCost,
                                              String currencyCode,
                                              HashSet<String> currencyCodes, BigDecimal totalCapex, int noOfMonths) {
        BigDecimal costPerMonth = totalCapex.divide(BigDecimal.valueOf(noOfMonths), 9, RoundingMode.HALF_UP);
        subWorkstreamOtherCost.setLocalCcyVal(costPerMonth);
        subWorkstreamOtherCost.setLocalCcy(currencyCode);
        currencyCodes.remove(currencyCode);
        if (!currencyCodes.isEmpty()) {
            subWorkstreamOtherCost.setGroupCcy(currencyCodes.iterator().next());
            subWorkstreamOtherCost.setGroupCcyVal(costPerMonth.multiply(financialDetailsService.getExchangeValue
                    (subWorkstreamOtherCost.getPeriod(), currencyCode, subWorkstreamOtherCost.getWorkStreamId())));
        } else {
            subWorkstreamOtherCost.setGroupCcy(currencyCode);
            subWorkstreamOtherCost.setGroupCcyVal(costPerMonth);
        }

        return subWorkstreamOtherCost;
    }

    private SubWorkstreamOtherCost
    updateCurrencyValuesForGroupForOtherDepre(SubWorkstreamOtherCost subWorkstreamOtherCost,
                                              String loggedInCurrencyCode,
                                              HashSet<String> currencyCodes, BigDecimal totalCapex, int noOfMonths) {
        BigDecimal costPerMonth = totalCapex.divide(BigDecimal.valueOf(noOfMonths), 9, RoundingMode.HALF_UP);
        subWorkstreamOtherCost.setGroupCcyVal(costPerMonth);
        subWorkstreamOtherCost.setGroupCcy(loggedInCurrencyCode);
        currencyCodes.remove(loggedInCurrencyCode);
        if (!currencyCodes.isEmpty()) {
            subWorkstreamOtherCost.setLocalCcy(currencyCodes.iterator().next());
            BigDecimal exchangedValue = financialDetailsService.getExchangeValue
                    (subWorkstreamOtherCost.getPeriod(), subWorkstreamOtherCost.getLocalCcy(), subWorkstreamOtherCost.getWorkStreamId());
            subWorkstreamOtherCost.setLocalCcyVal(costPerMonth.divide(exchangedValue, 9, RoundingMode.HALF_UP));
        } else {
            subWorkstreamOtherCost.setLocalCcy(loggedInCurrencyCode);
            subWorkstreamOtherCost.setLocalCcyVal(costPerMonth);
        }
        return subWorkstreamOtherCost;
    }

    public List<SubWorkstreamOtherCost> createSubWorkstreamOtherCostsOwnershipForMonthly(List<SubWorkstreamOtherCost> subWorkStreamOtherCosts,
                                                                                               String subWorkstreamId,String subWorkstreamName,String scenario,Integer refSurrId) {
        SubWorkstreamOtherCost subWorkstreamOtherCostOwnershipParent = subWorkstreamOtherCostRepo.findByScenarioAndCapexOpexSurrIdAndGlCategoryAndOriginalIndAndActiveInd(
                scenario,refSurrId,PortfolioConstants.OWNERSHIP,PortfolioConstants.TRUE,PortfolioConstants.TRUE);
        Date ownerShipDate = financialService.startingOwnershipPeriod(subWorkstreamId,subWorkstreamName,scenario);
        List<SubWorkstreamOtherCost> subWorkstreamOtherCostsToSave = subWorkStreamOtherCosts.stream().filter(subWorkStreamOtherCost ->
                financialService.checkOwnershipDate(ownerShipDate,subWorkStreamOtherCost.getPeriod()))
                .map(subWorkstreamOtherCost -> {
                    SubWorkstreamOtherCost subWorkstreamOtherCostOwnership = new SubWorkstreamOtherCost();
                    subWorkstreamOtherCostOwnership.setWorkStreamId(subWorkstreamOtherCost.getWorkStreamId());
                    subWorkstreamOtherCostOwnership.setSubWorkStreamId(subWorkstreamOtherCost.getSubWorkStreamId());
                    subWorkstreamOtherCostOwnership.setSubWorkStreamName(subWorkstreamOtherCost.getSubWorkStreamName());
                    subWorkstreamOtherCostOwnership.setActiveInd(PortfolioConstants.TRUE);
                    subWorkstreamOtherCostOwnership.setOriginalInd(PortfolioConstants.FALSE);
                    subWorkstreamOtherCostOwnership.setPeriod(subWorkstreamOtherCost.getPeriod());
                    subWorkstreamOtherCostOwnership.setType(subWorkstreamOtherCost.getType());
                    subWorkstreamOtherCostOwnership.setLocalCcyVal(subWorkstreamOtherCost.getLocalCcyVal());
                    subWorkstreamOtherCostOwnership.setGroupCcyVal(subWorkstreamOtherCost.getGroupCcyVal());
                    subWorkstreamOtherCostOwnership.setGroupCcy(subWorkstreamOtherCost.getGroupCcy());
                    subWorkstreamOtherCostOwnership.setLocalCcy(subWorkstreamOtherCost.getLocalCcy());
                    subWorkstreamOtherCostOwnership.setAddOther(subWorkstreamOtherCost.getAddOther());
                    subWorkstreamOtherCostOwnership.setVendorName(subWorkstreamOtherCost.getVendorName());
                    subWorkstreamOtherCostOwnership.setOtherDesc(subWorkstreamOtherCost.getOtherDesc());
                    subWorkstreamOtherCostOwnership.setCostTypeDetail(subWorkstreamOtherCost.getCostTypeDetail());
                    subWorkstreamOtherCostOwnership.setCostSettings(subWorkstreamOtherCost.getCostSettings());
                    subWorkstreamOtherCostOwnership.setScenario(subWorkstreamOtherCost.getScenario());
                    subWorkstreamOtherCostOwnership.setRefSwsOtherSurrId(subWorkstreamOtherCostOwnershipParent.getSwsOtherSurrId());
                    subWorkstreamOtherCostOwnership.setCapexOpexSurrId(refSurrId);
                    subWorkstreamOtherCostOwnership.setGlCategory(PortfolioConstants.OWNERSHIP);
                    return subWorkstreamOtherCostOwnership;
                }).collect(Collectors.toList());
        List<String> OwnerShipPeriods = subWorkstreamOtherCostsToSave.stream().map(subWorkstreamSoftwareCost -> subWorkstreamSoftwareCost.getPeriod()).collect(Collectors.toList());
        deleteOwnerships(subWorkstreamId, subWorkstreamName, scenario,subWorkstreamOtherCostOwnershipParent.getSwsOtherSurrId(), OwnerShipPeriods);
        return subWorkstreamOtherCostsToSave;
    }

    public void deleteOwnerships(String subWorkstreamId, String subWorkstreamName, String scenario, Integer refSurrId, List<String> ownerShipPeriods) {
        List<SubWorkstreamOtherCost> subWorkstreamSoftwareCosts =subWorkstreamOtherCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndGlCategoryAndRefSwsOtherSurrIdAndPeriodInAndActiveIndAndOriginalInd(
                subWorkstreamId,subWorkstreamName,scenario,PortfolioConstants.OWNERSHIP,refSurrId,ownerShipPeriods,PortfolioConstants.TRUE,PortfolioConstants.FALSE);
        subWorkstreamOtherCostRepo.deleteAll(subWorkstreamSoftwareCosts);
    }

}
