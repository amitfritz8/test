package com.dbs.genesis.portfolio.model.copyscenario;

import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class SubWorkStreamSoftwareOpexCopyHolder {

    private SubWorkstreamSoftwareCost subWorkStreamSoftwareOpexCostParent;
    private List<SubWorkstreamSoftwareCost> subWorkStreamSoftwareOpexCostChildren =
            new ArrayList<>();

    private SubWorkstreamSoftwareCost subWorkStreamSoftwareOwnershipCostParent;
    private List<SubWorkstreamSoftwareCost> subWorkStreamSoftwareOwnershipCostChildren =
            new ArrayList<>();
}
