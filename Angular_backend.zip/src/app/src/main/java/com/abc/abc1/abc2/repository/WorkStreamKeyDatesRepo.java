package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.WorkStreamKeyDatesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Repository
public interface WorkStreamKeyDatesRepo extends JpaRepository<WorkStreamKeyDatesEntity,String> {

    List<WorkStreamKeyDatesEntity> findByPortfolioIdAndActiveInd(String portfolioId, String activeInd);
    List<WorkStreamKeyDatesEntity> findByWorkStreamIdAndActiveInd(String workStreamId, String activeInd);
    List<WorkStreamKeyDatesEntity> findAllByWorkStreamIdInAndScenarioName(Set<String> workStreamIds, String scenario);
    Integer deleteAllByWorkStreamIdInAndScenarioNameIn(
            List<String> workStreamId, List<String> scenarios);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update WorkStreamKeyDatesEntity keyDates set keyDates.approvedDate =:approvalDate , " +
            " keyDates.scenarioName =:approvalScenario " +
            "where keyDates.workStreamId in (:workStreamIds) and keyDates.scenarioName=:scenarioName")
    Integer updateApprovalDateAndScenarioForWorkStreamsAndScenario(@Param("workStreamIds") List<String> workStreamIds,
                                                        @Param("scenarioName") String scenarioName,
                                                        @Param("approvalDate") Date approvalDate,
                                                        @Param("approvalScenario") String approvalScenario);

    @Query("SELECT DISTINCT keyDates.scenarioName FROM WorkStreamKeyDatesEntity keyDates " +
            "where keyDates.workStreamId in (:workStreamIds) and keyDates.scenarioName in (:scenarios) and " +
            "keyDates.approvedDate IS NULL  order by keyDates.scenarioName ASC")
    Set<String> findAllDistinctByWorkStreamIdInAndScenarioNameInAndApprovalDateIsNull(
            @Param("workStreamIds") List<String> workStreamIds, @Param("scenarios") Set<String> scenarios);
}