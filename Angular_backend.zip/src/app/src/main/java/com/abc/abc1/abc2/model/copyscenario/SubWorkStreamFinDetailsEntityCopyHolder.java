package com.dbs.genesis.portfolio.model.copyscenario;

import com.dbs.genesis.portfolio.model.SubWorkstreamFinDetailsEntity;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import lombok.Data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class SubWorkStreamFinDetailsEntityCopyHolder {

    private Map<SubWorkstreamFinDetailsEntity, List<SubWorkstreamFinDetailsEntity>>
            finDetailsOriginalIndWithChildren = new HashMap<>();

}
