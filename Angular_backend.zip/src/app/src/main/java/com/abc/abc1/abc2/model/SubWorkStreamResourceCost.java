package com.dbs.genesis.portfolio.model;

import lombok.Data;
import lombok.ToString;
import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@Entity
@Table(name = "sub_workstream_resource_cost")
@EntityListeners(AuditingEntityListener.class)
@ToString
@Audited(withModifiedFlag = true)
public class SubWorkStreamResourceCost extends CommonEntity<String> {

    @Id
    @Column(name = "sws_resource_surr_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer swsResourceSurrId;
    @Column(name = "workstream_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "workstream_id_MOD")
    private String workStreamId;
    @Column(name = "sub_workstream_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_id_MOD")
    private String subWorkStreamId;
    @Column(name = "sub_workstream_name")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_name_MOD")
    private String subWorkStreamName;
    @Column(name = "resource_type")
    @Audited (withModifiedFlag = true, modifiedColumnName = "resource_type_MOD")
    private String resourceType;
    @Column(name = "scenario")
    @Audited (withModifiedFlag = true, modifiedColumnName = "scenario_MOD")
    private String scenario;
    @Column(name = "cost_settings")
    @Audited (withModifiedFlag = true, modifiedColumnName = "cost_settings_MOD")
    private String costSettings;
    @Column(name = "gl_category")
    @Audited (withModifiedFlag = true, modifiedColumnName = "gl_category_MOD")
    private String glCategory;
    @Column(name = "platform_index")
    @Audited (withModifiedFlag = true, modifiedColumnName = "platform_index_MOD")
    private String platformIndex;
    @Column(name = "team_name")
    @Audited (withModifiedFlag = true, modifiedColumnName = "team_name_MOD")
    private String teamName;
    @Column(name = "location")
    @Audited (withModifiedFlag = true, modifiedColumnName = "location_MOD")
    private String location;
    @Column(name = "staff_type")
    @Audited (withModifiedFlag = true, modifiedColumnName = "staff_type_MOD")
    private String staffType;
    @Column(name = "vendor")
    @Audited (withModifiedFlag = true, modifiedColumnName = "vendor_MOD")
    private String vendor;
    @Column(name = "rate_source")
    @Audited (withModifiedFlag = true, modifiedColumnName = "rate_source_MOD")
    private String rateSource;
    @Column(name = "staff_level")
    @Audited (withModifiedFlag = true, modifiedColumnName = "staff_level_MOD")
    private String staffLevel;
    @Column(name = "team_code")
    @Audited (withModifiedFlag = true, modifiedColumnName = "team_code_MOD")
    private String teamCode;
    @Column(name = "team_role")
    @Audited (withModifiedFlag = true, modifiedColumnName = "team_role_MOD")
    private String teamRole;
    @Column(name = "local_ccy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "local_ccy_MOD")
    private String localCcy;
    @Column(name = "group_ccy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "group_ccy_MOD")
    private String groupCcy;
    @Column(name = "period")
    @Audited (withModifiedFlag = true, modifiedColumnName = "period_MOD")
    private String period;
    @Column(name = "fte")
    @Audited (withModifiedFlag = true, modifiedColumnName = "fte_MOD")
    private BigDecimal fte = BigDecimal.ZERO;
    @Column(name = "allocation_pct")
    @Audited (withModifiedFlag = true, modifiedColumnName = "allocation_pct_MOD")
    private BigDecimal allocationPercentage = BigDecimal.ZERO;
    @Column(name = "blended_cost_lcy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "blended_cost_lcy_MOD")
    private BigDecimal blendedCostLocalCcy = BigDecimal.ZERO;
    @Column(name = "blended_cost_gcy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "blended_cost_gcy_MOD")
    private BigDecimal blendedCostGroupCcy = BigDecimal.ZERO;
    @Column(name = "effective_start_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "effective_start_date_MOD")
    private Timestamp effectiveStartDate;
    @Column(name = "effective_end_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "effective_end_date_MOD")
    private Timestamp effectiveEndDate;
    @Column(name = "add_resource")
    @Audited (withModifiedFlag = true, modifiedColumnName = "add_resource_MOD")
    private String addResource;
    @Column(name = "original_ind")
    @Audited (withModifiedFlag = true, modifiedColumnName = "original_ind_MOD")
    private String originalInd;
    @Column(name = "active_ind")
    @Audited (withModifiedFlag = true, modifiedColumnName = "active_ind_MOD")
    private String activeInd;
    @Column(name = "ref_sws_resource_surr_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "ref_sws_resource_surr_id_MOD")
    private Integer refSwsResourceSurrId;
    @Column(name = "capex_opex_surr_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "capex_opex_surr_id_MOD")
    private Integer capexOpexSurrId;

    @Transient
    private String viewIdentifier;

    public String getViewIdentifier (){
        return this.getWorkStreamId() + "_" + this.getSubWorkStreamName();
    }





}
