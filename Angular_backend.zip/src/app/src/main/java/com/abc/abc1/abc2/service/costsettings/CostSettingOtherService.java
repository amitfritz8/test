package com.dbs.genesis.portfolio.service.costsettings;

import com.dbs.genesis.portfolio.common.DateExtensions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.mapper.CostSettingOtherMapper;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.PortfolioRepo;
import com.dbs.genesis.portfolio.repository.SubWorkStreamKeyDatesRepo;
import com.dbs.genesis.portfolio.repository.SubWorkstreamOtherCostRepo;
import com.dbs.genesis.portfolio.repository.WorkStreamRepo;
import com.dbs.genesis.portfolio.resources.FinancialDetailsResource;
import com.dbs.genesis.portfolio.resources.SubWorkStreamOtherCostHolder;
import com.dbs.genesis.portfolio.resources.SubWorkStreamOtherCostResource;
import com.dbs.genesis.portfolio.service.SubWorkStreamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class CostSettingOtherService implements DateExtensions{

    @Autowired
    CostSettingOtherMapper costSettingOtherMapper;
    @Autowired
    SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo;
    @Autowired
    FinancialDetailsService financialDetailsService;
    @Autowired
    SubWorkStreamService subWorkStreamService;
    @Autowired
    private SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    @Autowired
    private WorkStreamRepo workStreamRepo;
    @Autowired
    private PortfolioRepo portfolioRepo;

    public  Map<String, List<List<SubWorkStreamOtherCostHolder>>> processCostSetting(FinancialDetailsResource financialDetailsResource,
                                                           List<String> currentYearMonthBetweenDates){
        Map<String, List<List<SubWorkStreamOtherCostHolder>>> dbOpTypeAndAllOtherCostHoldersMap =
                new HashMap<>();
        if(financialDetailsResource.getOtherSoftware() != null && financialDetailsResource.getOtherSoftware().size() > 0){
            Map<String, List<List<SubWorkStreamOtherCostHolder>>> dbOpTypeAndOtherSoftwareHoldersMap =
                    processCostSettingForOther(financialDetailsResource,
                    financialDetailsResource.getOtherSoftware(),
                    currentYearMonthBetweenDates, PortfolioConstants.SOFTWARE_TYPE);
            appendOtherHolderMapToMainOtherHolderMap(dbOpTypeAndOtherSoftwareHoldersMap, dbOpTypeAndAllOtherCostHoldersMap);
        }
        if(financialDetailsResource.getOtherHardware() != null && financialDetailsResource.getOtherHardware().size() > 0){
            Map<String, List<List<SubWorkStreamOtherCostHolder>>> dbOpTypeAndOtherHardwareHoldersMap =
                    processCostSettingForOther(financialDetailsResource,
                    financialDetailsResource.getOtherHardware(),
                    currentYearMonthBetweenDates, PortfolioConstants.HARDWARE_TYPE);
            appendOtherHolderMapToMainOtherHolderMap(dbOpTypeAndOtherHardwareHoldersMap, dbOpTypeAndAllOtherCostHoldersMap);
        }
        if(financialDetailsResource.getOtherResource() != null && financialDetailsResource.getOtherResource().size() > 0){
            Map<String, List<List<SubWorkStreamOtherCostHolder>>> dbOpTypeAndOtherResourceHoldersMap =
                    processCostSettingForOther(financialDetailsResource,
                    financialDetailsResource.getOtherResource(),
                    currentYearMonthBetweenDates, PortfolioConstants.RESOURCE_TYPE);
            appendOtherHolderMapToMainOtherHolderMap(dbOpTypeAndOtherResourceHoldersMap, dbOpTypeAndAllOtherCostHoldersMap);
        }
        if(financialDetailsResource.getOthers() != null && financialDetailsResource.getOthers().size() > 0){
            Map<String, List<List<SubWorkStreamOtherCostHolder>>> dbOpTypeAndOthersHoldersMap =
                    processCostSettingForOther(financialDetailsResource,
                    financialDetailsResource.getOthers(),
                    currentYearMonthBetweenDates, PortfolioConstants.OTHERS_TYPE);
            appendOtherHolderMapToMainOtherHolderMap(dbOpTypeAndOthersHoldersMap, dbOpTypeAndAllOtherCostHoldersMap);
        }
        return dbOpTypeAndAllOtherCostHoldersMap;
    }

    private void appendOtherHolderMapToMainOtherHolderMap(Map<String, List<List<SubWorkStreamOtherCostHolder>>> dbOpTypeAndOtherHoldersMap,
                                                          Map<String, List<List<SubWorkStreamOtherCostHolder>>> dbOpTypeAndAllOtherCostHoldersMap){
        if(dbOpTypeAndOtherHoldersMap != null){
            dbOpTypeAndOtherHoldersMap.keySet().forEach(dbOpTypeKey->{
                if(dbOpTypeAndAllOtherCostHoldersMap.containsKey(dbOpTypeKey)){
                    dbOpTypeAndAllOtherCostHoldersMap.get(dbOpTypeKey).addAll(dbOpTypeAndOtherHoldersMap.get(dbOpTypeKey));
                }else{
                    dbOpTypeAndAllOtherCostHoldersMap.put(dbOpTypeKey, dbOpTypeAndOtherHoldersMap.get(dbOpTypeKey));
                }
            });
        }
    }

    public  Map<String, List<List<SubWorkStreamOtherCostHolder>>> processCostSettingForOther(FinancialDetailsResource financialDetailsResource,
                                                                   List<SubWorkStreamOtherCostResource> otherCostResources,
                                                                   List<String> currentYearMonthBetweenDates, String type){
        Map<String, List<List<SubWorkStreamOtherCostHolder>>> dbOpTypeAndOtherCostHoldersMap = new HashMap<>();
        List<SubWorkStreamOtherCostResource> createOtherCostList = new ArrayList<>();
        List<SubWorkStreamOtherCostResource> updateOtherCostList = new ArrayList<>();
        List<SubWorkStreamOtherCostResource> inactiveOtherCostList = new ArrayList<>();

        otherCostResources.stream().filter(SubWorkStreamOtherCostResource::validate).forEach(otherCost->{
            if(otherCost.getSurrId() == null || otherCost.getSurrId() == 0){
                createOtherCostList.add(otherCost);
            }else if (otherCost.getActiveInd().equals(PortfolioConstants.FALSE)){
                inactiveOtherCostList.add(otherCost);
            }else{
                inactiveOtherCostList.add(otherCost);
                createOtherCostList.add(otherCost);
            }

        });
        if(createOtherCostList.size() > 0){
            dbOpTypeAndOtherCostHoldersMap.put(PortfolioConstants.CREATE,
                    convertOtherResourceToEntityForCreate(financialDetailsResource, createOtherCostList,
                            currentYearMonthBetweenDates, type, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS));
        }
        if(inactiveOtherCostList.size() > 0){
            List<List<SubWorkStreamOtherCostHolder>> subWorkStreamOtherCostHolderBasedOnGLCategories = new ArrayList<>();
            List<SubWorkStreamOtherCostHolder> subWorkStreamOtherCostHolders = new ArrayList<>();
            Set<Integer> surrIds = new HashSet<>();
            inactiveOtherCostList.forEach(inactiveOther->{
                surrIds.add(inactiveOther.getSurrId());
            });
            List<SubWorkstreamOtherCost> subWorkstreamOtherCostsForInactive =
                    subWorkstreamOtherCostRepo.findAllByParentOrChildIdIn(surrIds, surrIds);
            SubWorkStreamOtherCostHolder subWorkStreamOtherCostHolder = new SubWorkStreamOtherCostHolder();
            subWorkStreamOtherCostHolder.setSubWorkstreamOtherCosts(subWorkstreamOtherCostsForInactive);
            subWorkStreamOtherCostHolders.add(subWorkStreamOtherCostHolder);
            subWorkStreamOtherCostHolderBasedOnGLCategories.add(subWorkStreamOtherCostHolders);
            dbOpTypeAndOtherCostHoldersMap.put(PortfolioConstants.INACTIVE, subWorkStreamOtherCostHolderBasedOnGLCategories);
        }
        return dbOpTypeAndOtherCostHoldersMap;
    }

    public List<SubWorkStreamOtherCostResource> getCostSettingDetails(String workStreamId,
                                                                      String subWorkstreamId, String subWorkstreamName,
                                                                      String scenario,
                                                                      List<String> currentYearMonthBetweenDates,
                                                                      String loggedInUserCurrency,
                                                                      String type){
        List<SubWorkstreamOtherCost> subWorkStreamOtherCosts = new ArrayList<>();
        List<SubWorkstreamOtherCost> subWorkStreamOtherCostList = subWorkstreamOtherCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalInd
                        (subWorkstreamId,subWorkstreamName,scenario, PortfolioConstants.TRUE,
                                type, PortfolioConstants.TRUE);
        subWorkStreamOtherCostList.forEach(subWorkStreamSoftwareCost->{
            if(PortfolioConstants.OPEX.equalsIgnoreCase(subWorkStreamSoftwareCost.getGlCategory()) || PortfolioConstants.CAPEX.equalsIgnoreCase(subWorkStreamSoftwareCost.getGlCategory())){
                subWorkStreamOtherCosts.add(subWorkStreamSoftwareCost);
            }
        });
        return costSettingOtherMapper.
                mapSubWorkStreamOtherCostEntityToResource(subWorkStreamOtherCosts, workStreamId, loggedInUserCurrency);
    }

    public List<List<SubWorkStreamOtherCostHolder>> convertOtherResourceToEntityForCreate(FinancialDetailsResource financialDetailsResource,
                                                                                    List<SubWorkStreamOtherCostResource> createOtherList,
                                                                                    List<String> currentYearMonthBetweenDates,
                                                                                    String type, String costSettings){
        List<List<SubWorkStreamOtherCostHolder>> subWorkStreamOtherCostHolderBasedOnGLCategories = new ArrayList<>();
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(financialDetailsResource.getWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamName(), PortfolioConstants.TRUE, financialDetailsResource.getScenario());

        createOtherList.forEach(otherCost->{
            List<SubWorkStreamOtherCostHolder> subWorkStreamOtherCostHolders = new ArrayList<>();
            List<String> glCategories= new ArrayList<>();
            getGLCategoriesList(otherCost, glCategories);

            for(String glCategory: glCategories) {
                Map<String, Object> dateDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategories(financialDetailsResource.getWorkStreamId(),financialDetailsResource.getSubWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamName(), financialDetailsResource.getScenario(), glCategory, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
                List<String> monthBetweenDates = (List<String>) dateDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);

                calculateCostPerMonthForITDepreciation(glCategory, financialDetailsResource, otherCost, monthBetweenDates);

                SubWorkStreamOtherCostHolder subWorkStreamOtherCostHolder = new SubWorkStreamOtherCostHolder();
                monthBetweenDates.forEach(monthYearDate -> {
                    if (subWorkStreamOtherCostHolder.getSubWorkstreamOtherCost() == null) {
                        subWorkStreamOtherCostHolder.setSubWorkstreamOtherCost(populateSubWorkStreamOtherCostForCreate(
                                otherCost, financialDetailsResource, monthBetweenDates.size(),
                                getCurrentPeriodAsMonthYear(), type, costSettings, Boolean.TRUE, glCategory));
                    }
                    subWorkStreamOtherCostHolder.getSubWorkstreamOtherCosts().add(populateSubWorkStreamOtherCostForCreate(
                            otherCost, financialDetailsResource, monthBetweenDates.size(), monthYearDate,
                            type, costSettings, Boolean.FALSE, glCategory));

                });
                if(PortfolioConstants.OPEX.equalsIgnoreCase(glCategory)){
                    getCapexAndOpexDefaultMonthsData(financialDetailsResource, otherCost,
                            costSettings, PortfolioConstants.OPEX, subWorkStreamOtherCostHolder,type);
                }
                if(PortfolioConstants.CAPEX.equalsIgnoreCase(glCategory)){
                    getCapexAndOpexDefaultMonthsData(financialDetailsResource, otherCost,
                            costSettings, PortfolioConstants.CAPEX, subWorkStreamOtherCostHolder,  type);
                }
                if(PortfolioConstants.OWNERSHIP.equalsIgnoreCase(glCategory)) {
                    try {
                        DateFormat formatter = new SimpleDateFormat("yyyyMM");
                        java.util.Date goLiveDate = subWorkStreamKeyDatesEntity.getGoLiveDate();
                        for (SubWorkstreamOtherCost subWorkStreamOtherCost: subWorkStreamOtherCostHolder.getSubWorkstreamOtherCosts()) {
                            java.util.Date monthYear = formatter.parse(subWorkStreamOtherCost.getPeriod());
                            if (monthYear.compareTo(goLiveDate) > 0 && "false".equalsIgnoreCase(subWorkStreamOtherCost.getOriginalInd())) {
                                subWorkStreamOtherCost.setGroupCcyVal(BigDecimal.ZERO);
                                subWorkStreamOtherCost.setLocalCcyVal(BigDecimal.ZERO);
                            }
                        }
                    } catch (Exception e) {
                        log.error("Date parsing error in CostSettingOtherService: convertOtherResourceToEntityForCreate");
                    }
                }
                subWorkStreamOtherCostHolders.add(subWorkStreamOtherCostHolder);
            }
            subWorkStreamOtherCostHolderBasedOnGLCategories.add(subWorkStreamOtherCostHolders);
        });
        return subWorkStreamOtherCostHolderBasedOnGLCategories;
    }

    private void getCapexAndOpexDefaultMonthsData(FinancialDetailsResource financialDetailsResource, SubWorkStreamOtherCostResource other,
                                                  String costSettings, String glCategory, SubWorkStreamOtherCostHolder subWorkStreamOtherCostHolder, String type){
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(financialDetailsResource.getWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamId(), financialDetailsResource.getSubWorkStreamName(), PortfolioConstants.TRUE,
                        financialDetailsResource.getScenario());
        Map<String, Object> monthDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategories(financialDetailsResource.getWorkStreamId(),
                financialDetailsResource.getSubWorkStreamId(), financialDetailsResource.getSubWorkStreamName(), financialDetailsResource.getScenario(),
                glCategory, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
        List<String> monthBetweenDates = (List<String>) monthDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);
        SubWorkStreamOtherCostResource otherCost = buildSubWorkStreamSoftwareCostResource(other);

        List<String> monthBetweenDatesCurrentmonthTOStartMonth = getCurrentYearMonthBetweenDatesDefault(getCurrentPeriodAsMonthYear(), monthBetweenDates.get(0));
        monthBetweenDatesCurrentmonthTOStartMonth.remove(monthBetweenDatesCurrentmonthTOStartMonth.size()-1);
        monthBetweenDatesCurrentmonthTOStartMonth.forEach(monthYearDate -> {
            SubWorkstreamOtherCost subWorkstreamOtherCost =
                    populateSubWorkStreamOtherCostForCreate(otherCost, financialDetailsResource,
                             monthBetweenDatesCurrentmonthTOStartMonth.size(),monthYearDate, type, costSettings, Boolean.FALSE,glCategory);
            subWorkStreamOtherCostHolder.getSubWorkstreamOtherCosts().add(subWorkstreamOtherCost);
        });
        Date depreStartDate = getDepreDate(financialDetailsResource.getWorkStreamId(), subWorkStreamKeyDatesEntity);
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        List<String> monthBetweenDatesEndMonthToDepreStartDatefiveYears = getCurrentYearMonthBetweenDatesDefault(monthBetweenDates.get(monthBetweenDates.size()-1),
                getMonths(df.format(depreStartDate).substring(0, 7), 59).replaceAll("-", ""));
        monthBetweenDatesEndMonthToDepreStartDatefiveYears.remove(0);
        monthBetweenDatesEndMonthToDepreStartDatefiveYears.forEach(monthYearDate -> {
            SubWorkstreamOtherCost subWorkstreamOtherCost =
                    populateSubWorkStreamOtherCostForCreate(otherCost, financialDetailsResource,
                            monthBetweenDatesCurrentmonthTOStartMonth.size(),monthYearDate, type, costSettings, Boolean.FALSE,glCategory);
            subWorkStreamOtherCostHolder.getSubWorkstreamOtherCosts().add(subWorkstreamOtherCost);
        });
    }

    private Date getDepreDate(String workStreamId, SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity) {
        WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(workStreamId);
        PortfolioEntity portfolioId = portfolioRepo.findByPortfolioId(workStreamEntity.getPortfolioId());
        Date depreStartDate = subWorkStreamKeyDatesEntity.getDepreStartDate();
        if(depreStartDate == null){
            depreStartDate = calculateDepreStartDate(subWorkStreamKeyDatesEntity.getGoLiveDate(),portfolioId.getAgileWaterFall());
        }
        log.info("calculated Depre start date:"+depreStartDate);
        return depreStartDate;
    }

    private SubWorkStreamOtherCostResource  buildSubWorkStreamSoftwareCostResource(SubWorkStreamOtherCostResource other){
        SubWorkStreamOtherCostResource otherCost= new SubWorkStreamOtherCostResource();
        otherCost.setCost(BigDecimal.ZERO);
        otherCost.setCurrency(other.getCurrency());
        otherCost.setVendor(other.getVendor());
        otherCost.setDescription(other.getDescription());
        otherCost.setActiveInd(other.getActiveInd());
        otherCost.setCurrency(other.getCurrency());
        return otherCost;
    }

    private void getGLCategoriesList(SubWorkStreamOtherCostResource otherCost, List<String> glCategories){
        if(PortfolioConstants.OPEX.equalsIgnoreCase(otherCost.getCapexOrOpex())){
            glCategories.add(PortfolioConstants.OPEX);
            glCategories.add(PortfolioConstants.OWNERSHIP);
        }else if(PortfolioConstants.CAPEX.equalsIgnoreCase(otherCost.getCapexOrOpex())){
            glCategories.add(PortfolioConstants.CAPEX);
            glCategories.add(PortfolioConstants.ITDEPRECIATION);
        }
    }

    private void calculateCostPerMonthForITDepreciation(String glCategory, FinancialDetailsResource financialDetailsResource,
                                                        SubWorkStreamOtherCostResource otherCost,List<String> monthBetweenDates){
        if(PortfolioConstants.ITDEPRECIATION.equalsIgnoreCase(glCategory)){
            Map<String, Object> capexMonthDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategories(financialDetailsResource.getWorkStreamId(), financialDetailsResource.getSubWorkStreamId(),
                    financialDetailsResource.getSubWorkStreamName(), financialDetailsResource.getScenario(), PortfolioConstants.CAPEX, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
            List<String> capexMonthBetweenDates = (List<String>) capexMonthDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);
            BigDecimal CostPerMonthTotal= otherCost.getCost().multiply(BigDecimal.valueOf(capexMonthBetweenDates.size()));
            otherCost.setCost(CostPerMonthTotal.divide(BigDecimal.valueOf(monthBetweenDates.size()), 9, RoundingMode.HALF_UP));
        }
    }

    private SubWorkstreamOtherCost populateSubWorkStreamOtherCostForCreate(SubWorkStreamOtherCostResource otherCost,
                                                                           FinancialDetailsResource financialDetails,
                                                                           int noOfMonths,
                                                                           String monthYearDate, String type,
                                                                           String costSettings, Boolean original, String glCategory){
        SubWorkstreamOtherCost subWorkstreamOtherCost = new SubWorkstreamOtherCost();
        subWorkstreamOtherCost.setWorkStreamId(financialDetails.getWorkStreamId());
        subWorkstreamOtherCost.setSubWorkStreamId(financialDetails.getSubWorkStreamId());
        subWorkstreamOtherCost.setSubWorkStreamName(financialDetails.getSubWorkStreamName());
        subWorkstreamOtherCost.setScenario(financialDetails.getScenario());
        subWorkstreamOtherCost.setCostSettings(costSettings);
        subWorkstreamOtherCost.setCostTypeDetail(financialDetails.getScenario());
        subWorkstreamOtherCost.setVendorName(otherCost.getVendor());
        subWorkstreamOtherCost.setOtherDesc(otherCost.getDescription());
        subWorkstreamOtherCost.setActiveInd(otherCost.getActiveInd());
        subWorkstreamOtherCost.setType(type);
        subWorkstreamOtherCost.setAddOther(getAddOther(type));
        subWorkstreamOtherCost.setGlCategory(glCategory);
        subWorkstreamOtherCost.setEffectiveStartDate(new Timestamp(financialDetails.getStartDate().getTime()));
        subWorkstreamOtherCost.setEffectiveEndDate(new Timestamp(financialDetails.getGoLiveDate().getTime()));
        subWorkstreamOtherCost.setPeriod(monthYearDate);

        if(original){
            subWorkstreamOtherCost.setOriginalInd(PortfolioConstants.TRUE);
        }else{
            subWorkstreamOtherCost.setOriginalInd(PortfolioConstants.FALSE);
        }
        updateCurrencyValuesForOthers(subWorkstreamOtherCost,otherCost.getCurrency(), otherCost.getCost(),
                financialDetails);
        //Monthly Split
        if(!original){
            subWorkstreamOtherCost.setLocalCcyVal(subWorkstreamOtherCost.getLocalCcyVal());
            subWorkstreamOtherCost.setGroupCcyVal(subWorkstreamOtherCost.getGroupCcyVal());
        }
        return subWorkstreamOtherCost;
    }

    private void updateCurrencyValuesForOthers(SubWorkstreamOtherCost subWorkstreamOtherCost,
                                                 String loggedInCurrencyCode, BigDecimal cost,
                                               FinancialDetailsResource financialDetails){
        if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(loggedInCurrencyCode)) {
            subWorkstreamOtherCost.setLocalCcy(loggedInCurrencyCode);
            subWorkstreamOtherCost.setLocalCcyVal(cost);
            subWorkstreamOtherCost.setGroupCcy(loggedInCurrencyCode);
            subWorkstreamOtherCost.setGroupCcyVal(cost);

        }else{
            subWorkstreamOtherCost.setLocalCcy(loggedInCurrencyCode);
            subWorkstreamOtherCost.setLocalCcyVal(cost);
            subWorkstreamOtherCost.setGroupCcy(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD);
            BigDecimal rateValue = financialDetailsService.getExchangeRatesEntity(subWorkstreamOtherCost.getPeriod(),
                    loggedInCurrencyCode, financialDetails.getWorkStreamId()).getRateValue();
            subWorkstreamOtherCost.setGroupCcyVal(cost.multiply(rateValue));
        }
    }

    private String getAddOther(String type){
        String addOther=null;
        switch(type)
        {
            case PortfolioConstants.SOFTWARE_TYPE:
                addOther = PortfolioConstants.ADD_OTHER_SOFTWARE;
                break;
            case PortfolioConstants.HARDWARE_TYPE:
                addOther = PortfolioConstants.ADD_OTHER_HARDWARE;
                break;
            case PortfolioConstants.RESOURCE_TYPE:
                addOther = PortfolioConstants.ADD_OTHER_RESOURCE;
                break;
            case PortfolioConstants.OTHERS_TYPE:
                addOther = PortfolioConstants.ADD_OTHER_OTHERS;
                break;
        }
        return addOther;
    }

    public List<SubWorkStreamOtherCostHolder> convertOtherResourceToEntityForUpdate(
            FinancialDetailsResource financialDetailsResource,
            List<SubWorkStreamOtherCostResource> updateOtherList,
            List<String> currentYearMonthBetweenDates,
            String type,
            Map<Integer, List<SubWorkstreamOtherCost>>
                    entitiesPerRefSwsOtherSurrId){
        List<SubWorkStreamOtherCostHolder> subWorkStreamOtherCostHolders = new ArrayList<>();
        updateOtherList.forEach(updateOtherCostResource->{
            SubWorkStreamOtherCostHolder subWorkStreamOtherCostHolder = new SubWorkStreamOtherCostHolder();
            SubWorkstreamOtherCost subWorkstreamOtherCost =
                    populateOtherCostOriginalResourceToEntity(updateOtherCostResource,
                            financialDetailsResource, type);
            List<SubWorkstreamOtherCost> subWorkstreamOtherCosts = entitiesPerRefSwsOtherSurrId.get(updateOtherCostResource.getSurrId());
            populateOtherCostResourceToEntityForUpdate(updateOtherCostResource, subWorkstreamOtherCosts,
                    currentYearMonthBetweenDates.size(), financialDetailsResource, type);
            subWorkStreamOtherCostHolder.setSubWorkstreamOtherCost(subWorkstreamOtherCost);
            subWorkStreamOtherCostHolder.setSubWorkstreamOtherCosts(subWorkstreamOtherCosts);
            subWorkStreamOtherCostHolders.add(subWorkStreamOtherCostHolder);
        });
        return subWorkStreamOtherCostHolders;
    }

    private SubWorkstreamOtherCost populateOtherCostOriginalResourceToEntity(SubWorkStreamOtherCostResource otherCostResource
            , FinancialDetailsResource financialDetails, String type){
        SubWorkstreamOtherCost subWorkstreamOtherCost = new SubWorkstreamOtherCost();
        SubWorkstreamOtherCost subWorkstreamOtherCostDetails = subWorkstreamOtherCostRepo.findAllBySwsOtherSurrId(otherCostResource.getSurrId());
        subWorkstreamOtherCost.setSwsOtherSurrId(otherCostResource.getSurrId());
        subWorkstreamOtherCost.setWorkStreamId(financialDetails.getWorkStreamId());
        subWorkstreamOtherCost.setSubWorkStreamId(financialDetails.getSubWorkStreamId());
        subWorkstreamOtherCost.setSubWorkStreamName(financialDetails.getSubWorkStreamName());
        subWorkstreamOtherCost.setScenario(financialDetails.getScenario());
        subWorkstreamOtherCost.setActiveInd(otherCostResource.getActiveInd());
        subWorkstreamOtherCost.setGlCategory(subWorkstreamOtherCostDetails.getGlCategory());
        subWorkstreamOtherCost.setEffectiveStartDate(new Timestamp(financialDetails.getStartDate().getTime()));
        subWorkstreamOtherCost.setEffectiveEndDate(new Timestamp(financialDetails.getGoLiveDate().getTime()));
        subWorkstreamOtherCost.setScenario(financialDetails.getScenario());
        subWorkstreamOtherCost.setVendorName(otherCostResource.getVendor());
        subWorkstreamOtherCost.setType(type);
        subWorkstreamOtherCost.setAddOther(getAddOther(type));
        subWorkstreamOtherCost.setOtherDesc(otherCostResource.getDescription());
        subWorkstreamOtherCost.setOriginalInd(PortfolioConstants.TRUE);
        updateCurrencyValuesForOthers(subWorkstreamOtherCost,otherCostResource.getCurrency(),
                otherCostResource.getCost(), financialDetails);
        return subWorkstreamOtherCost;
    }

    private void populateOtherCostResourceToEntityForUpdate(SubWorkStreamOtherCostResource otherCostResource,
                                                            List<SubWorkstreamOtherCost> subWorkstreamOtherCosts,
                                                            int noOfMonths, FinancialDetailsResource financialDetails,
                                                            String type) {
        subWorkstreamOtherCosts.forEach(subWorkstreamOtherCost -> {
            subWorkstreamOtherCost.setWorkStreamId(financialDetails.getWorkStreamId());
            subWorkstreamOtherCost.setSubWorkStreamId(financialDetails.getSubWorkStreamId());
            subWorkstreamOtherCost.setSubWorkStreamName(financialDetails.getSubWorkStreamName());
            subWorkstreamOtherCost.setScenario(financialDetails.getScenario());
            subWorkstreamOtherCost.setActiveInd(otherCostResource.getActiveInd());
            subWorkstreamOtherCost.setGlCategory(subWorkstreamOtherCost.getGlCategory());
            subWorkstreamOtherCost.setEffectiveStartDate(new Timestamp(financialDetails.getStartDate().getTime()));
            subWorkstreamOtherCost.setEffectiveEndDate(new Timestamp(financialDetails.getGoLiveDate().getTime()));
            subWorkstreamOtherCost.setScenario(financialDetails.getScenario());
            subWorkstreamOtherCost.setVendorName(otherCostResource.getVendor());
            subWorkstreamOtherCost.setType(type);
            subWorkstreamOtherCost.setAddOther(getAddOther(type));
            subWorkstreamOtherCost.setOtherDesc(otherCostResource.getDescription());

            subWorkstreamOtherCost.setOriginalInd(PortfolioConstants.FALSE);
            updateCurrencyValuesForOthers(subWorkstreamOtherCost,otherCostResource.getCurrency(),
                    otherCostResource.getCost(), financialDetails);
            //Monthly Split
            subWorkstreamOtherCost.setLocalCcyVal(subWorkstreamOtherCost.getLocalCcyVal());
            subWorkstreamOtherCost.setGroupCcyVal(subWorkstreamOtherCost.getGroupCcyVal());

        });
    }
}
