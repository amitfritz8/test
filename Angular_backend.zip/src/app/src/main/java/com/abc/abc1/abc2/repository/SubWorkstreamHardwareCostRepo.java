package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Repository
public interface SubWorkstreamHardwareCostRepo extends JpaRepository<SubWorkstreamHardwareCost, Integer> {


    List<SubWorkstreamHardwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndPeriodIn(
            String subWorkStreamId, String subWorkStreamName, String scenario, String activeInd, List<String> periods);

    List<SubWorkstreamHardwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndTowerAndScenarioAndActiveIndAndOriginalInd(
            String subWorkStreamId, String subWorkStreamName, String towerName, String scenario, String aTrue,String originalInd);

    List<SubWorkstreamHardwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndTowerAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotIn(
            String subWorkStreamId, String subWorkStreamName, String towerName, String scenario, String aTrue,String originalInd, List<String> glCategories);

    List<SubWorkstreamHardwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndPeriodContainingAndOriginalInd(
            String subWorkStreamId, String subWorkStreamName, String scenario, String aTrue, String periods,String originalInd);

    List<SubWorkstreamHardwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndPeriodContainingAndOriginalIndAndGlCategoryNotIn(
            String subWorkStreamId, String subWorkStreamName, String scenario, String aTrue, String periods,String originalInd, List<String> glCategories);

    @Query(value = "SELECT DISTINCT substring(e.period,1,4) FROM SubWorkstreamHardwareCost e where " +
            "e.subWorkStreamId = :subWorkStreamId and e.subWorkStreamName = :subWorkStreamName and e.scenario = :scenario")
    List<String> findDistinctOfPeriods(String subWorkStreamId, String subWorkStreamName, String scenario);

    List<SubWorkstreamHardwareCost> findAllByRefSwsHwSurrIdIn(List<Integer> refSurrIds);

    List<SubWorkstreamHardwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalInd(
            String subWorkStreamId, String subWorkStreamName, String scenario, String activeInd, String originalInd);

    List<SubWorkstreamHardwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotIn(
            String subWorkStreamId, String subWorkStreamName, String scenario, String activeInd, String originalInd, List<String> glCategories);

    @Query(value = "FROM SubWorkstreamHardwareCost e where " +
            "e.swsHwSurrId IN (:swsHwSurrId) or e.capexOpexSurrId IN (:capexOpexSurrId)")
    List<SubWorkstreamHardwareCost> findAllByParentOrChildIdIn(Set<Integer> swsHwSurrId, Set<Integer> capexOpexSurrId);

    @Query(value = "SELECT DISTINCT substring(e.period,1,4) FROM SubWorkstreamHardwareCost e where " +
            "e.subWorkStreamId = :subWorkStreamId and e.subWorkStreamName = :subWorkStreamName and e.scenario = :scenario and e.glCategory not in :glCategories and e.originalInd ='false' and e.period is not null")
    List<String> findDistinctOfYears(@Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName, @Param("scenario") String scenario, @Param("glCategories")  List<String> glCategories);

    List<SubWorkstreamHardwareCost> findAllByWorkStreamIdAndSubWorkStreamIdInAndScenario(
            String workStreamId, List<String> subWorkStreamIds, String scenario);

    Integer deleteAllByWorkStreamIdAndSubWorkStreamIdAndScenarioIn(
            String workStreamId, String subWorkStreamId, List<String> scenarios);

    @Query(value = "select coalesce (sum(cost_per_month_gcy),0) from sub_workstream_hardware_cost where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name =:subWorkStreamName and scenario = :scenario and tower = :tower and active_ind = 'true' and original_ind='false' and gl_Category not in :glCategories" ,
            nativeQuery = true)
    BigDecimal getTotalHardwareCostByTypeAndGrpCcy(String subWorkStreamId, String subWorkStreamName, String scenario, String tower, List<String> glCategories);

    @Query(value = "select coalesce (sum(cost_per_month_lcy),0) from sub_workstream_hardware_cost where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name =:subWorkStreamName and scenario = :scenario and tower = :tower and active_ind = 'true' and original_ind='false' and gl_Category not in :glCategories" ,
            nativeQuery = true)
    BigDecimal getTotalHardwareCostByTypeAndLocalCcy(String subWorkStreamId, String subWorkStreamName, String scenario, String tower, List<String> glCategories);

    SubWorkstreamHardwareCost findAllBySwsHwSurrId(Integer swsHwSurrId);

    SubWorkstreamHardwareCost findByScenarioAndCapexOpexSurrIdAndGlCategoryAndOriginalIndAndActiveInd(String scenario,Integer refSurrId, String ownership, String originalInd, String activeInd);

    List<SubWorkstreamHardwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndGlCategoryAndRefSwsHwSurrIdAndPeriodInAndActiveIndAndOriginalInd(String subWorkstreamId, String subWorkstreamName, String scenario, String ownership, Integer refSurrId, List<String> ownerShipPeriods, String aTrue, String aFalse);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update SubWorkstreamHardwareCost hwCost set hwCost.scenario =:approvalScenario " +
            "where hwCost.workStreamId in (:workStreamIds) and hwCost.scenario=:scenario")
    Integer updateApprovalScenarioForWorkStreamsAndScenario(@Param("workStreamIds") List<String> workStreamIds,
                                                            @Param("scenario") String scenario,
                                                            @Param("approvalScenario") String approvalScenario);
}
