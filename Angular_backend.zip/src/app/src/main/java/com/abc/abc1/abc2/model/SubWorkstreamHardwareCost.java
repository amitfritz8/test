package com.dbs.genesis.portfolio.model;

import com.dbs.genesis.portfolio.resources.SubWorkStreamHardwareCostResource;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@Entity
@Table(name = "sub_workstream_hardware_cost")
@EntityListeners(AuditingEntityListener.class)
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Audited(withModifiedFlag = true)
public class SubWorkstreamHardwareCost extends CommonEntity<String>{

    @Id
    @Column(name = "sws_hw_surr_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer swsHwSurrId;
    @Column(name = "workstream_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "workstream_id_MOD")
    private String workStreamId;
    @Column(name = "sub_workstream_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_id_MOD")
    private String subWorkStreamId;
    @Column(name = "sub_workstream_name")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_name_MOD")
    private String subWorkStreamName;
    @Column(name = "scenario")
    @Audited (withModifiedFlag = true, modifiedColumnName = "scenario_MOD")
    private String scenario;
    @Column(name = "tower")
    @Audited (withModifiedFlag = true, modifiedColumnName = "tower_MOD")
    private String tower;
    @Column(name = "driver_detail")
    @Audited (withModifiedFlag = true, modifiedColumnName = "driver_detail_MOD")
    private String driverDetail;
    @Column(name = "uom")
    @Audited (withModifiedFlag = true, modifiedColumnName = "uom_MOD")
    private String uom;
    @Column(name = "local_ccy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "local_ccy_MOD")
    private String localCcy;
    @Column(name = "hw_descr")
    @Audited (withModifiedFlag = true, modifiedColumnName = "hw_descr_MOD")
    private String hardwareDesc;
    @Column(name = "hw_cost")
    @Audited (withModifiedFlag = true, modifiedColumnName = "hw_cost_MOD")
    private BigDecimal hardwareCost = BigDecimal.ZERO;
    @Column(name = "quantity")
    @Audited (withModifiedFlag = true, modifiedColumnName = "quantity_MOD")
    private BigDecimal quantity = BigDecimal.ZERO;
    @Column(name = "gl_category")
    @Audited (withModifiedFlag = true, modifiedColumnName = "gl_category_MOD")
    private String glCategory;
    @Column(name = "effective_start_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "effective_start_date_MOD")
    private Timestamp effectiveStartDate;
    @Column(name = "effective_end_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "effective_end_date_MOD")
    private Timestamp effectiveEndDate;
    @Column(name = "itc_rate")
    @Audited (withModifiedFlag = true, modifiedColumnName = "itc_rate_MOD")
    private BigDecimal itcRate = BigDecimal.ZERO;
    @Column(name = "cost_per_month_lcy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "cost_per_month_lcy_MOD")
    private BigDecimal costPerMonthLcy = BigDecimal.ZERO;
    @Column(name = "cost_per_month_gcy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "cost_per_month_gcy_MOD")
    private BigDecimal costPerMonthGcy = BigDecimal.ZERO;
    @Column(name = "group_ccy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "group_ccy_MOD")
    private String groupCcy;
    @Column(name = "active_ind")
    @Audited (withModifiedFlag = true, modifiedColumnName = "active_ind_MOD")
    private String activeInd;
    @Column(name = "period")
    @Audited (withModifiedFlag = true, modifiedColumnName = "period_MOD")
    private String period;
    @Column(name = "original_ind")
    @Audited (withModifiedFlag = true, modifiedColumnName = "original_ind_MOD")
    private String originalInd;
    @Column(name = "ref_hw_cost_surr_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "ref_hw_cost_surr_id_MOD")
    private Integer refSwsHwSurrId;
    @Column(name = "cost_settings")
    @Audited (withModifiedFlag = true, modifiedColumnName = "cost_settings_MOD")
    private String costSettings;
    @Column(name = "add_hardware")
    @Audited (withModifiedFlag = true, modifiedColumnName = "add_hardware_MOD")
    private String addHardware;
    @Column(name = "capex_opex_surr_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "capex_opex_surr_id_MOD")
    private Integer capexOpexSurrId;
    @Column(name = "cost_type_detail")
    @Audited (withModifiedFlag = true, modifiedColumnName = "cost_type_detail_MOD")
    private String costTypeDetail;



    public SubWorkStreamHardwareCostResource toSubWorkStreamHardwareCostResource() {
        SubWorkStreamHardwareCostResource subWorkStreamHardwareCostResource = new SubWorkStreamHardwareCostResource();
        subWorkStreamHardwareCostResource.setTower(getTower());
        subWorkStreamHardwareCostResource.setDriverDetails(getDriverDetail());
        subWorkStreamHardwareCostResource.setUom(getUom());
        subWorkStreamHardwareCostResource.setQty(getQuantity());
        subWorkStreamHardwareCostResource.setCurrency(getLocalCcy());
        subWorkStreamHardwareCostResource.setCostInCurrency(getGroupCcy());
        subWorkStreamHardwareCostResource.setActiveInd(getActiveInd());
        subWorkStreamHardwareCostResource.setSurrId(getSwsHwSurrId());
        subWorkStreamHardwareCostResource.setItcRate(getItcRate());
        subWorkStreamHardwareCostResource.setCostPerMonth(getCostPerMonthLcy());
        return subWorkStreamHardwareCostResource;
    }
}
