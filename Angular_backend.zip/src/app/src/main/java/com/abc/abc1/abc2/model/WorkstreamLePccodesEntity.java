package com.dbs.genesis.portfolio.model;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Data
@Entity
@Table(name = "workstream_le_pccodes")
@EntityListeners(AuditingEntityListener.class)
public class WorkstreamLePccodesEntity extends CommonEntity<String> {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ws_pccode_surr_id")
    private int workstreamPccodeSurrId;

    @Column(name = "portfolio_id")
    private String portfolioId;

    @Column(name = "workstream_id")
    private String workStreamId;

    @Column(name = "workstream_name")
    private String workStreamName;

    @Column(name = "le_pccode")
    private String lePCCode;

    @Column(name = "build_operate")
    private String buildOperate;

    @Column(name = "allocation_pct")
    private String allocationPercent;

    @Column(name = "ws_lepccodes_ref_id")
    private String wsLepccodesRefId;

    @Column(name = "active_ind")
    private String activeInd;
}
