package com.dbs.genesis.portfolio.model;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Date;

@Data
@Entity
@Table(name = "xref_scenario_config")
@EntityListeners(value = AuditingEntityListener.class)
public class XrefScenarioConfigEntity extends CommonEntity<String>{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "scenario_surr_id")
    private Integer scenarioSurrId;

    @Column(name = "scenario_name", nullable = false)
    private String scenarioName;

    @Column(name = "ws_item")
    private String wsItem;

    @Column(name = "active_ind")
    private String activeInd;

    @Column(name = "scenario_keydate")
    private String scenarioKeydate;

    @Column(name = "level_keydate")
    private String levelKeydate;

    @Column(name = "order_display_key")
    private Integer orderDisplayKey;

    @Column(name = "sws_function")
    private String swsFunction;

    @Column(name = "lock_ind")
    private String lockInd;

    @Column(name = "activity_version")
    private String activityVersion;

    @Column(name = "snapshot_date")
    private Date snapshotDate;

    @Column(name = "scenario_report")
    private String scenarioReport;

    @Column(name = "link_to_report")
    private String linkToReport;

    @Column(name = "copy_function")
    private String copyFunction;

    @Column(name = "remarks")
    private String remarks;

    
}