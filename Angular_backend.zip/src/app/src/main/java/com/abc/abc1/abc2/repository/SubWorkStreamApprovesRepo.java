package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.SubWorkStreamApprovers;
import com.dbs.genesis.portfolio.model.SubWorkStreamKeyDatesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface SubWorkStreamApprovesRepo extends JpaRepository<SubWorkStreamApprovers,Integer> {
    List<SubWorkStreamApprovers> findBySubWorkStreamIdAndActiveIndAndSubWorkStreamName(String subWorkStreamId, String
            activeInd,String subWorkStreamName);

    List<SubWorkStreamApprovers> findByWorkStreamIdAndActiveInd(String workStreamId, String activeInd);
    List<SubWorkStreamApprovers> findAllByWorkStreamIdAndSubWorkStreamIdInAndScenario(
            String workStreamId, List<String> subWorkStreamIds, String scenario);
    Integer deleteAllByWorkStreamIdInAndScenarioIn(List<String> workStreamIds, List<String> scenarios);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update SubWorkStreamApprovers approvers set approvers.scenario =:approvalScenario " +
            "where approvers.workStreamId in (:workStreamIds) and approvers.scenario=:scenario")
    Integer updateApprovalScenarioForWorkStreamsAndScenario(@Param("workStreamIds") List<String> workStreamIds,
                                                            @Param("scenario") String scenario,
                                                            @Param("approvalScenario") String approvalScenario);
}
