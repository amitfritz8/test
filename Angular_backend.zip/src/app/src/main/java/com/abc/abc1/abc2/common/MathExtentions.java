package com.dbs.genesis.portfolio.common;

import java.math.BigDecimal;
import java.math.RoundingMode;

public interface MathExtentions {

    int DB_SCALE = 9;

    default BigDecimal divideWithScaleHalfUp(BigDecimal quantity, int divisor) {
        return quantity.divide(BigDecimal.valueOf(divisor), DB_SCALE, RoundingMode.HALF_UP);
    }

    default BigDecimal divideWithScaleHalfUp(BigDecimal quantity, BigDecimal divisor) {
        return quantity.divide(divisor, DB_SCALE, RoundingMode.HALF_UP);
    }

}
