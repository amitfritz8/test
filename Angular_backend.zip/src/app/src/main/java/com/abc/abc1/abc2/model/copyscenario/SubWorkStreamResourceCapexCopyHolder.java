package com.dbs.genesis.portfolio.model.copyscenario;

import com.dbs.genesis.portfolio.model.SubWorkStreamResourceCost;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class SubWorkStreamResourceCapexCopyHolder {

    private SubWorkStreamResourceCost subWorkStreamResourceCapexCostParent;
    private List<SubWorkStreamResourceCost> subWorkStreamResourceCapexCostChildren =
            new ArrayList<>();

    private SubWorkStreamResourceCost subWorkStreamResourceITDepreciationCostParent;
    private List<SubWorkStreamResourceCost> subWorkStreamResourceITDepreciationCostChildren =
            new ArrayList<>();
}
