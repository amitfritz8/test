package com.dbs.genesis.portfolio.model;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Data
@Entity
@Table(name = "xref_sub_platform_master")
@EntityListeners(AuditingEntityListener.class)
public class XrefSubPlatformMasterEntity extends CommonEntity<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sub_platform_id")
    private Integer subPlatformId;

    @Column(name = "sub_platform_name")
    private String subPlatformName;

    @Column(name = "platform_index")
    private String platformIndex;

    @Column(name = "sub_platform_code")
    private String subPlatformCode;

    @Column(name = "platform_name")
    private String platformName;

    @Column(name = "le_pccode")
    private String lePCCode;

    @Column(name = "status")
    private String status;

    @Column(name = "effective_start_date")
    private String effectiveStartDate;

    @Column(name = "effective_end_date")
    private String effectiveEndDate;


}
