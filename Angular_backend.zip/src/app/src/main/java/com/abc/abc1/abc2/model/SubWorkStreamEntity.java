package com.dbs.genesis.portfolio.model;

import com.dbs.genesis.portfolio.resources.SubWorkStreamListingSource;
import lombok.Data;
import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;


@SqlResultSetMappings({
        @SqlResultSetMapping(name = "mapSubWorkStreamListing",
                classes = {
                        @ConstructorResult(targetClass = SubWorkStreamListingSource.class,
                                columns = {
                                        @ColumnResult(name = "portfolioId"),
                                        @ColumnResult(name = "portfolioName"),
                                        @ColumnResult(name = "workStreamId"),
                                        @ColumnResult(name = "workStreamName"),
                                        @ColumnResult(name = "subWorkStreamId"),
                                        @ColumnResult(name = "subWorkStreamName"),
                                        @ColumnResult(name = "platformName"),
                                        @ColumnResult(name = "workType"),
                                        @ColumnResult(name = "appCode")
                                })
                })
})


@NamedNativeQueries({
        @NamedNativeQuery(
                name = "subWorkStreamListingByOneBankId",
                query = "select  distinct p.portfolio_id as portfolioId, p.portfolio_name as portfolioName, w.workstream_id as workStreamId, w.workstream_name as workStreamName,c.sub_workstream_id as subWorkStreamId, c.sub_workstream_name as subWorkStreamName,"+
                        " c.delivery_unit as platformName, c.work_type as workType, c.app_code as appCode "+
                        " from sub_workstream_dates a,workstream_profile w,sub_workstream_profile c, portfolio_managers m,portfolio_profile p " +
                        "       where a.scenario_name = ?1 and a.sub_workstream_id = c.sub_workstream_id and w.workstream_id = c.workstream_id and  m.portfolio_id = w.portfolio_id and w.portfolio_id = p.portfolio_id " +
                        "       and ((p.primary_platform_index in (?2) and p.reporting_flag in (?3) and w.country in (?4) and m.1bank_id = ?5 and m.active_ind = 'true') or (m.1bank_id = ?5 and m.active_ind = 'true'))" +
                        "UNION " +
                        "select  distinct p.portfolio_id as portfolioId, p.portfolio_name as portfolioName, w.workstream_id as workStreamId, w.workstream_name as workStreamName,c.sub_workstream_id as subWorkStreamId, c.sub_workstream_name as subWorkStreamName,"+
                        " c.delivery_unit as platformName, c.work_type as workType, c.app_code as appCode "+
                        " from sub_workstream_dates a,workstream_profile w,sub_workstream_profile c, workstream_managers m,portfolio_profile p" +
                        "         where a.scenario_name = ?1 and a.sub_workstream_id = c.sub_workstream_id and w.workstream_id = c.workstream_id and  m.workstream_id = w.workstream_id and w.portfolio_id = p.portfolio_id" +
                        "         and ((p.primary_platform_index in (?2) and p.reporting_flag in (?3) and w.country in (?4) and m.1bank_id = ?5 and m.active_ind = 'true') or (m.1bank_id = ?5 and m.active_ind = 'true'))" +
                        "UNION " +
                        "select  distinct c.portfolio_id as portfolioId, c.portfolio_name as portfolioName, w.workstream_id as workStreamId, w.workstream_name as workStreamName,b.sub_workstream_id as subWorkStreamId, b.sub_workstream_name as subWorkStreamName,"+
                        " b.delivery_unit as platformName, b.work_type as workType, b.app_code as appCode "+
                        " from sub_workstream_dates a,sub_workstream_profile b,portfolio_profile c, sub_workstream_managers m,workstream_profile w " +
                        "          where a.scenario_name = ?1 and a.sub_workstream_id = b.sub_workstream_id and w.workstream_id = b.workstream_id and w.portfolio_id = c.portfolio_id and m.sub_workstream_id = b.sub_workstream_id " +
                        "           and ((c.primary_platform_index in (?2) and c.reporting_flag in (?3) and b.country in (?4) and m.1bank_id = ?5 and m.active_ind='true') or (m.1bank_id = ?5 and m.active_ind = 'true'))",
                resultSetMapping = "mapSubWorkStreamListing"
        ),
        @NamedNativeQuery(
                name = "subWorkStreamListingAll",
                query = "select  distinct c.portfolio_id as portfolioId, c.portfolio_name as portfolioName, b.workstream_id as workStreamId, b.workstream_name as workStreamName,s.sub_workstream_id as subWorkStreamId, s.sub_workstream_name as subWorkStreamName,"+
                        " s.delivery_unit as platformName, s.work_type as workType, s.app_code as appCode "+
                        " from sub_workstream_dates a,workstream_profile b,portfolio_profile c, sub_workstream_profile s "+
                        " where a.scenario_name = ?1 and a.sub_workstream_id = s.sub_workstream_id and b.portfolio_id = c.portfolio_id and b.workstream_id=s.workstream_id" +
                        "    and c.primary_platform_index in (?2) and c.reporting_flag in (?3) and b.country in (?4) ",
                resultSetMapping = "mapSubWorkStreamListing"
        )
})


@Data
@Entity
@Table(name = "sub_workstream_profile")
@EntityListeners(AuditingEntityListener.class)
@Audited(withModifiedFlag = true)
public class SubWorkStreamEntity extends CommonEntity<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "subws_surr_id")
    private int subWorkStreamSurrId;

    @Column(name = "workstream_ref_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "workstream_ref_id_MOD")
    private int workStreamRefId;

    @Column(name = "sub_workstream_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_id_MOD")
    private String subWorkStreamId;

    @Column(name = "workstream_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "workstream_id_MOD")
    private String workStreamId;

    @Column(name = "sub_workstream_name")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_name_MOD")
    private String subWorkStreamName;

    @Column(name = "sub_workstream_desc")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_desc_MOD")
    private String subWorkStreamDesc;

    @Column(name = "country")
    @Audited (withModifiedFlag = true, modifiedColumnName = "country_MOD")
    private String country;

    @Column(name = "platform_unit")
    @Audited (withModifiedFlag = true, modifiedColumnName = "platform_unit_MOD")
    private String platformUnit;

    @Column(name = "sub_platform_name")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_platform_name_MOD")
    private String subPlatformName;

    @Column(name = "delivery_unit")
    @Audited (withModifiedFlag = true, modifiedColumnName = "delivery_unit_MOD")
    private String deliveryUnit;

    @Column(name = "category")
    @Audited (withModifiedFlag = true, modifiedColumnName = "category_MOD")
    private String category;

    @Column(name = "app_code")
    @Audited (withModifiedFlag = true, modifiedColumnName = "app_code_MOD")
    private String appCode;

    @Column(name = "app_code_desc")
    @Audited (withModifiedFlag = true, modifiedColumnName = "app_code_desc_MOD")
    private String appCodeDesc;

    @Column(name = "sub_workstream_ref")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_ref_MOD")
    private String subWorkStreamRef;

    @Column(name = "product_code")
    @Audited (withModifiedFlag = true, modifiedColumnName = "product_code_MOD")
    private String productCode;

    @Column(name = "product_code_desc")
    @Audited (withModifiedFlag = true, modifiedColumnName = "product_code_desc_MOD")
    private String productCodeDesc;

    @Column (name = "work_type")
    @Audited (withModifiedFlag = true, modifiedColumnName = "work_type_MOD")
    private String workType;

    @Transient
    private String editable;

    @Transient
    private String staffName;

}
