package com.dbs.genesis.portfolio;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Delete5 {

    private String name;
    private int year;
    private String month;

    public Integer getNumericMonth() {
        return Integer.parseInt(month);
    }
}
