package com.dbs.genesis.portfolio.event;

import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.resources.CostSettingsUpdateEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;

@Component
@Slf4j
class FinanceScreenUpdateEventAsyncListener {

	private final PortfolioRepository portfolioRepository;

	FinanceScreenUpdateEventAsyncListener(PortfolioRepository portfolioRepository) {
		this.portfolioRepository = portfolioRepository;
	}

	@Async
	@EventListener
	void handleAsyncEvent(CostSettingsUpdateEvent event) {
		log.info("Received Async event: "+event);
		processBackEndFinancialTable(event.getSubWorkStreamId(),event.getSubWorkStreamName(),
				event.getCurrentYear(),event.getEventSource());
	}

	private void processBackEndFinancialTable(String subWorkStreamId,String subWorkStreamName,
											  String rptPeriod,String costComponent){
		log.info("process backend financial data started...");
		Instant start = Instant.now();
		portfolioRepository.callBackEndFinancialProcedure(subWorkStreamId,subWorkStreamName,rptPeriod,costComponent);
		log.info("process backend financial data completed...");
		Instant finish = Instant.now();
		long timeElapsed = Duration.between(start, finish).toMillis();
		log.info("Total time SubWorkStreamListing in Millis: "+timeElapsed);
	}

}
