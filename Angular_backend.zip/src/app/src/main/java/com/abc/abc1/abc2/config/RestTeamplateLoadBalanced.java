package com.dbs.genesis.portfolio.config;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class RestTeamplateLoadBalanced {

    @LoadBalanced
    public RestTemplate getRestTemplate() {
        return new RestTemplate();

    }
}
