package com.dbs.genesis.portfolio.common;

import com.dbs.genesis.portfolio.resources.FinancialSummaryResource;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

public interface CommonFinancialTypes {

    default List<BigDecimal> getCostSettingMonthlyData(List<FinancialSummaryResource> finSummaryForCostInput) {
        BigDecimal[] defaultVales = new BigDecimal[12];
        Arrays.fill(defaultVales, BigDecimal.ZERO);

        for (FinancialSummaryResource summaryResource : finSummaryForCostInput) {
            String reportingMonth = summaryResource.getPeriod().substring(4, 6);
            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                defaultVales[Integer.parseInt(reportingMonth) - 1] = summaryResource.getCurrencyValue();
            }
        }
        return Arrays.asList(defaultVales);
    }
}
