package com.dbs.genesis.portfolio.model.copyscenario;

import com.dbs.genesis.portfolio.model.SubWorkstreamOtherCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class SubWorkStreamOtherCapexCopyHolder {

    private SubWorkstreamOtherCost subWorkStreamOtherCapexCostParent;
    private List<SubWorkstreamOtherCost> subWorkStreamOtherCapexCostChildren =
            new ArrayList<>();

    private SubWorkstreamOtherCost subWorkStreamOtherITDepreciationCostParent;
    private List<SubWorkstreamOtherCost> subWorkStreamOtherITDepreciationCostChildren =
            new ArrayList<>();
}
