package com.dbs.genesis.portfolio.resources;

import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class CostSettingSoftwares {
    List<SubWorkstreamSoftwareCost> software;
}
