package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.XrefSubPlatformMasterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface XrefSubPlatformMasterRepo extends JpaRepository<XrefSubPlatformMasterEntity,String> {

    List<XrefSubPlatformMasterEntity> findByPlatformIndex(String platformIndex);
}
