package com.dbs.genesis.portfolio.controller;



import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.AppCodeMaster;
import com.dbs.genesis.portfolio.repository.AppCodeRepo;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;


@Slf4j
@RestController
@Api(value="Language API", description="Operations pertaining to Application Codes")
@RequestMapping("/data/appCode")
public class AppCodeMasterController extends GenericDataController<AppCodeMaster, String> {

    private AppCodeRepo repo;

    @Autowired
    public AppCodeMasterController(AppCodeRepo repo) {
        super(repo);
        this.repo = repo;
    }

    @GetMapping("/list")
    public List<AppCodeMaster> getAppCodeDesc() {
        List<AppCodeMaster> appCodes = this.repo.findByAppCodeIncluded(PortfolioConstants.YES);
        appCodes.removeIf(Objects::isNull);
        return appCodes;
    }


}
