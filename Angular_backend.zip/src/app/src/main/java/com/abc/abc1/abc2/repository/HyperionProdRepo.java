package com.dbs.genesis.portfolio.repository;


import com.dbs.genesis.portfolio.resources.HyperionProductResource;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
public class HyperionProdRepo {

    @PersistenceContext
    private EntityManager entityManager;
    public List<HyperionProductResource> findHyperionProductResource() {
        Query query = entityManager.createNamedQuery("getHyperionProductTree");
        List<HyperionProductResource> r = query.getResultList();

        return r;
    }


}
