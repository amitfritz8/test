package com.dbs.genesis.portfolio.service.costsettings;

import com.amazonaws.util.CollectionUtils;
import com.dbs.genesis.portfolio.common.DateExtensions;
import com.dbs.genesis.portfolio.common.MathExtentions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.mapper.CostSettingsResourceMapper;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.PortfolioRepo;
import com.dbs.genesis.portfolio.repository.SubWorkStreamKeyDatesRepo;
import com.dbs.genesis.portfolio.repository.SubWorkStreamResourceCostRepo;
import com.dbs.genesis.portfolio.repository.WorkStreamRepo;
import com.dbs.genesis.portfolio.resources.FinancialDetailsResource;
import com.dbs.genesis.portfolio.resources.SubWorkStreamResourceCostHolder;
import com.dbs.genesis.portfolio.resources.SubWorkStreamResourceCostResource;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import com.dbs.genesis.portfolio.service.SubWorkStreamService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
@Service
public class ResourceService implements MathExtentions, DateExtensions{

    @Autowired
    private FinancialDetailsService financialDetailsService;
    @Autowired
    private SubWorkStreamResourceCostRepo subWorkStreamResourceCostRepo;
    @Autowired
    private CostSettingsResourceMapper costSettingsResourceMapper;
    @Autowired
    private SubWorkStreamService subWorkStreamService;
    @Autowired
    private DataSummaryService dataSummaryService;
    @Autowired
    private SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    @Autowired
    private WorkStreamRepo workStreamRepo;
    @Autowired
    private PortfolioRepo portfolioRepo;


    public List<SubWorkStreamResourceCostResource> getCostSettingDetails(String workStreamId,
                                                                               String subWorkStreamId,
                                                                               String subWorkStreamName,
                                                                               String scenario,
                                                                               String loggedInUserCurrency) {
        List<SubWorkStreamResourceCost> subWorkStreamResourceCosts = new ArrayList<>();
        List<SubWorkStreamResourceCost> subWorkstreamHardwareCostList = subWorkStreamResourceCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndResourceTypeAndActiveIndAndOriginalInd
                        (subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.RESOURCE_TYPE_IC,
                                PortfolioConstants.TRUE, PortfolioConstants.TRUE);
        subWorkstreamHardwareCostList.forEach(subWorkStreamSoftwareCost->{
            if(PortfolioConstants.CAPEX.equalsIgnoreCase(subWorkStreamSoftwareCost.getGlCategory())){
                subWorkStreamResourceCosts.add(subWorkStreamSoftwareCost);
            }
        });
        List<SubWorkStreamResourceCostResource> subWorkStreamResourceCostResources = costSettingsResourceMapper.
                mapSubWorkStreamResourceCostEntityToResource(subWorkStreamResourceCosts, workStreamId,
                        loggedInUserCurrency);
        /*
        if(!CollectionUtils.isNullOrEmpty(subWorkStreamResourceCostResources)){
            subWorkStreamResourceCostResources.forEach(subWorkStreamResourceCostResource->{
                updateLocationLongNameByShortCode(subWorkStreamResourceCostResource);
            });

        }
        */
        subWorkStreamResourceCostResources.sort(Comparator.comparing(SubWorkStreamResourceCostResource::getRole));
        return subWorkStreamResourceCostResources;
    }

    public Map<String, List<SubWorkStreamResourceCostHolder>>
    processCostSetting(FinancialDetailsResource financialDetailsResource,
                       List<String> currentYearMonthBetweenDates) {
        Map<String, List<SubWorkStreamResourceCostHolder>> dbOpTypeAndResourceCostHoldersMap =
                new HashMap<>();
        List<SubWorkStreamResourceCostResource> createResourceList = new ArrayList<>();
        List<SubWorkStreamResourceCostResource> updateResourceList = new ArrayList<>();
        List<SubWorkStreamResourceCostResource> inactiveResourceList = new ArrayList<>();

        financialDetailsResource.getIndividualContributors().stream().filter(SubWorkStreamResourceCostResource::validate).forEach(resource -> {
                //updateLocationShortCodeByLongName(resource);
                if (resource.getSurrId() == null || resource.getSurrId() == 0) {
                    createResourceList.add(resource);
                } else if (resource.getActiveInd().equals(PortfolioConstants.FALSE)) {
                    inactiveResourceList.add(resource);
                } else {
                    createResourceList.add(resource);
                    inactiveResourceList.add(resource);
                }
        });
        //Delete all records exist in db for this wsi+swsi+swn+scenario
        subWorkStreamResourceCostRepo.deleteAllByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndScenario(
                financialDetailsResource.getWorkStreamId(),
                financialDetailsResource.getSubWorkStreamId(),
                financialDetailsResource.getSubWorkStreamName(),
                financialDetailsResource.getScenario());

        if (createResourceList.size() > 0) {
            List<Map<String, SubWorkStreamResourceCostHolder>> glCategoryBasedRecordsForResourceList =
                    convertResourceToEntityForCreate(financialDetailsResource,
                            createResourceList, currentYearMonthBetweenDates,
                            PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
            alignICParentChildRecords(glCategoryBasedRecordsForResourceList);
        }
        return dbOpTypeAndResourceCostHoldersMap;
    }

    private void updateLocationShortCodeByLongName(SubWorkStreamResourceCostResource resource){
        DataValues dataValues = dataSummaryService.getDataValuesByValue(resource.getLocation(), PortfolioConstants.COUNTRY);
        if(dataValues != null){
            resource.setLocation(dataValues.getDesc());
        }
    }

    private void updateLocationLongNameByShortCode(SubWorkStreamResourceCostResource resource){
        DataValues dataValues = dataSummaryService.getDataValuesByDesc(resource.getLocation(), PortfolioConstants.COUNTRY);
        if(dataValues != null){
            resource.setLocation(dataValues.getValue());
        }
    }

    private void alignICParentChildRecords(List<Map<String, SubWorkStreamResourceCostHolder>> glCategoryBasedRecordsForResourceList){
        if(!CollectionUtils.isNullOrEmpty(glCategoryBasedRecordsForResourceList)){
            glCategoryBasedRecordsForResourceList.forEach(glCategoryBasedRecord->{
                alignGlCategoryWithResource(glCategoryBasedRecord);
            });
        }
    }

    private void alignGlCategoryWithResource(Map<String, SubWorkStreamResourceCostHolder> glCategoryBasedRecords){
        if(glCategoryBasedRecords != null){
            SubWorkStreamResourceCostHolder subWorkStreamCapexCostHolder =
                    glCategoryBasedRecords.get(PortfolioConstants.CAPEX);
            SubWorkStreamResourceCostHolder subWorkStreamDepriCostHolder =
                    glCategoryBasedRecords.get(PortfolioConstants.ITDEPRECIATION);
            SubWorkStreamResourceCostHolder subWorkStreamOpexCostHolder =
                    glCategoryBasedRecords.get(PortfolioConstants.OPEX);
            SubWorkStreamResourceCostHolder subWorkStreamOwnershipCostHolder =
                    glCategoryBasedRecords.get(PortfolioConstants.OWNERSHIP);

            Integer capexRefId = calculateResourceCapexOrOpex(subWorkStreamCapexCostHolder);
            calculateResourceOwnershipOrItDeprication(capexRefId,subWorkStreamDepriCostHolder);

            Integer opexRefId = calculateResourceCapexOrOpex(subWorkStreamOpexCostHolder);
            calculateResourceOwnershipOrItDeprication(opexRefId, subWorkStreamOwnershipCostHolder);
        }


    }

    private void calculateResourceOwnershipOrItDeprication(Integer capexRefId, SubWorkStreamResourceCostHolder subWorkStreamResourceCostHolder){
        SubWorkStreamResourceCost resourceCostTrueIndicator = subWorkStreamResourceCostHolder.getSubWorkStreamResourceCost();
        resourceCostTrueIndicator.setCapexOpexSurrId(capexRefId);
        SubWorkStreamResourceCost resourceCostTrueIndicatorPersisted =
                subWorkStreamResourceCostRepo.save(resourceCostTrueIndicator);
        List<SubWorkStreamResourceCost> subWorkStreamResourceCosts =
                subWorkStreamResourceCostHolder.getSubWorkStreamResourceCosts();
        if(!CollectionUtils.isNullOrEmpty(subWorkStreamResourceCosts)){
            subWorkStreamResourceCosts.forEach(subWorkStreamResourceCost->{
                subWorkStreamResourceCost.setRefSwsResourceSurrId(resourceCostTrueIndicatorPersisted.getSwsResourceSurrId());
                subWorkStreamResourceCost.setCapexOpexSurrId(capexRefId);
            });
            subWorkStreamResourceCostRepo.saveAll(subWorkStreamResourceCosts);
        }
    }

    private Integer calculateResourceCapexOrOpex(SubWorkStreamResourceCostHolder subWorkStreamResourceCostHolder){
        SubWorkStreamResourceCost resourceCostTrueIndicator = subWorkStreamResourceCostHolder.getSubWorkStreamResourceCost();
        SubWorkStreamResourceCost resourceCostTrueIndicatorPersisted =
                subWorkStreamResourceCostRepo.save(resourceCostTrueIndicator);
        List<SubWorkStreamResourceCost> subWorkStreamResourceCosts =
                subWorkStreamResourceCostHolder.getSubWorkStreamResourceCosts();
        if(!CollectionUtils.isNullOrEmpty(subWorkStreamResourceCosts)){
            subWorkStreamResourceCosts.forEach(subWorkStreamCapexCost->{
                subWorkStreamCapexCost.setRefSwsResourceSurrId(resourceCostTrueIndicatorPersisted.getSwsResourceSurrId());
                subWorkStreamCapexCost.setCapexOpexSurrId(resourceCostTrueIndicatorPersisted.getSwsResourceSurrId());
            });
            subWorkStreamResourceCostRepo.saveAll(subWorkStreamResourceCosts);
        }
        return resourceCostTrueIndicatorPersisted.getSwsResourceSurrId();
    }

    private void populateResourceCostResourceToEntityForUpdate(SubWorkStreamResourceCostResource resource,
                                                               List<SubWorkStreamResourceCost> subWorkStreamResourceCosts,
                                                               int noOfMonths,
                                                               FinancialDetailsResource financialDetails) {
        subWorkStreamResourceCosts.forEach(subWorkStreamResourceCost -> {
            subWorkStreamResourceCost.setWorkStreamId(financialDetails.getWorkStreamId());
            subWorkStreamResourceCost.setSubWorkStreamId(financialDetails.getSubWorkStreamId());
            subWorkStreamResourceCost.setSubWorkStreamName(financialDetails.getSubWorkStreamName());
            subWorkStreamResourceCost.setOriginalInd(PortfolioConstants.FALSE);
            subWorkStreamResourceCost.setScenario(financialDetails.getScenario());
            subWorkStreamResourceCost.setActiveInd(resource.getActiveInd());
            subWorkStreamResourceCost.setAddResource(PortfolioConstants.ADD_RESOURCE);
            subWorkStreamResourceCost.setGlCategory(PortfolioConstants.OPEX);
            subWorkStreamResourceCost.setEffectiveStartDate(new Timestamp(financialDetails.getStartDate().getTime()));
            subWorkStreamResourceCost.setEffectiveEndDate(new Timestamp(financialDetails.getGoLiveDate().getTime()));
            if(resource.getCostPerDay() != null && resource.getFdManDaysPerMonth() != null) {
                resource.setCostPerMonth(resource.getCostPerDay().multiply(resource.getFdManDaysPerMonth()));
                updateCurrencyValuesForResource(subWorkStreamResourceCost, resource.getCurrency(),
                        resource.getCostPerMonth(), financialDetails);
            }
        });
    }

    private SubWorkStreamResourceCost populateResourceCostOriginalResourceToEntityForUpdate(
            SubWorkStreamResourceCostResource resource
            , FinancialDetailsResource financialDetails, List<String> currentYearMonthBetweenDates){
        SubWorkStreamResourceCost subWorkStreamResourceCost = new SubWorkStreamResourceCost();
        subWorkStreamResourceCost.setSwsResourceSurrId(resource.getSurrId());
        subWorkStreamResourceCost.setOriginalInd(PortfolioConstants.TRUE);
        subWorkStreamResourceCost.setWorkStreamId(financialDetails.getWorkStreamId());
        subWorkStreamResourceCost.setSubWorkStreamId(financialDetails.getSubWorkStreamId());
        subWorkStreamResourceCost.setSubWorkStreamName(financialDetails.getSubWorkStreamName());
        subWorkStreamResourceCost.setScenario(financialDetails.getScenario());
        subWorkStreamResourceCost.setActiveInd(resource.getActiveInd());
        subWorkStreamResourceCost.setEffectiveStartDate(new Timestamp(financialDetails.getStartDate().getTime()));
        subWorkStreamResourceCost.setEffectiveEndDate(new Timestamp(financialDetails.getGoLiveDate().getTime()));
        subWorkStreamResourceCost.setPeriod(getCurrentPeriodAsMonthYear());
        subWorkStreamResourceCost.setAddResource(PortfolioConstants.ADD_RESOURCE);
        //subWorkStreamResourceCost.setGlCategory(PortfolioConstants.OPEX);
        subWorkStreamResourceCost.setTeamRole(resource.getRole());
        subWorkStreamResourceCost.setAllocationPercentage(BigDecimal.valueOf(100));
        subWorkStreamResourceCost.setLocation(resource.getLocation());
        subWorkStreamResourceCost.setRateSource(resource.getRateSource());
        subWorkStreamResourceCost.setResourceType(PortfolioConstants.RESOURCE_TYPE_IC);
        subWorkStreamResourceCost.setStaffLevel(resource.getLevel());
        subWorkStreamResourceCost.setStaffType(resource.getStaffType());
        subWorkStreamResourceCost.setVendor(resource.getVendor());
        subWorkStreamResourceCost.setFte(resource.getFte());

        if(resource.getCostPerDay() != null && resource.getFdManDaysPerMonth() != null) {
            resource.setCostPerMonth(resource.getCostPerDay().multiply(resource.getFdManDaysPerMonth()));
            updateCurrencyValuesForResource(subWorkStreamResourceCost, resource.getCurrency(),
                    resource.getCostPerMonth(), financialDetails);
        }
        return subWorkStreamResourceCost;
    }

    private  List<Map<String, SubWorkStreamResourceCostHolder>>
    convertResourceToEntityForCreate(FinancialDetailsResource financialDetailsResource,
                                   List<SubWorkStreamResourceCostResource> createResourceList,
                                   List<String> currentYearMonthBetweenDates,
                                   String costSettings) {
        List<Map<String, SubWorkStreamResourceCostHolder>> glCategoryBasedRecordsForResourceList = new ArrayList<>();
        List<SubWorkStreamResourceCostHolder> subWorkStreamResourceCostHolders = new ArrayList<>();

        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(financialDetailsResource.getWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamName(), PortfolioConstants.TRUE, financialDetailsResource.getScenario());


        createResourceList.forEach(resource -> {
            List<String> glCategories = getResourceGlCategories();
            Map<String, SubWorkStreamResourceCostHolder> glCategoryBasedRecords = new HashMap();
            for(String glCategory: glCategories) {
                Map<String, Object> dateDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategoriesForResourcesIndividualContributorAndHLE(
                        financialDetailsResource.getWorkStreamId(), financialDetailsResource.getSubWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamName(),financialDetailsResource.getScenario(),
                        glCategory, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
                List<String> monthBetweenDates = (List<String>) dateDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);
                calculateCostPerMonth(glCategory, financialDetailsResource, resource, monthBetweenDates);
                SubWorkStreamResourceCostHolder subWorkStreamResourceCostHolder = new SubWorkStreamResourceCostHolder();
                monthBetweenDates.forEach(monthYearDate -> {
                if (subWorkStreamResourceCostHolder.getSubWorkStreamResourceCost() == null) {
                    subWorkStreamResourceCostHolder.setSubWorkStreamResourceCost(
                            populateSubWorkstreamResourceCostForCreate(financialDetailsResource,
                                    monthBetweenDates.size(),
                                    resource, getCurrentPeriodAsMonthYear(), costSettings, Boolean.TRUE, glCategory));
                }
                subWorkStreamResourceCostHolder.getSubWorkStreamResourceCosts().add
                        (populateSubWorkstreamResourceCostForCreate(financialDetailsResource,
                                monthBetweenDates.size(),
                                resource, monthYearDate, costSettings, Boolean.FALSE, glCategory));

            });

            if(PortfolioConstants.OPEX.equalsIgnoreCase(glCategory)){
                getCapexAndOpexDefaultMonthsData(financialDetailsResource, resource,
                        costSettings, PortfolioConstants.OPEX, subWorkStreamResourceCostHolder);
            }

            if(PortfolioConstants.OWNERSHIP.equalsIgnoreCase(glCategory)) {
                try {
                    DateFormat formatter = new SimpleDateFormat("yyyyMM");
                    for (SubWorkStreamResourceCost subWorkStreamResourceCost: subWorkStreamResourceCostHolder.getSubWorkStreamResourceCosts()) {
                        java.util.Date monthYear = formatter.parse(subWorkStreamResourceCost.getPeriod());
                        if (monthYear.compareTo(subWorkStreamKeyDatesEntity.getGoLiveDate()) > 0 && "false".equalsIgnoreCase(subWorkStreamResourceCost.getOriginalInd())) {
                            subWorkStreamResourceCost.setBlendedCostGroupCcy(BigDecimal.ZERO);
                            subWorkStreamResourceCost.setBlendedCostLocalCcy(BigDecimal.ZERO);
                        }

                    }
                } catch (Exception e) {
                    log.info("convertResourceToEntityForCreate date parsing error",e);
                }
            }

            subWorkStreamResourceCostHolders.add(subWorkStreamResourceCostHolder);
                glCategoryBasedRecords.put(glCategory, subWorkStreamResourceCostHolder);

            }
            glCategoryBasedRecordsForResourceList.add(glCategoryBasedRecords);
        });
        //return subWorkStreamResourceCostHolders;
        return glCategoryBasedRecordsForResourceList;
    }

    private void getCapexAndOpexDefaultMonthsData(FinancialDetailsResource financialDetailsResource, SubWorkStreamResourceCostResource resource,
                                                  String costSettings, String glCategory, SubWorkStreamResourceCostHolder subWorkStreamResourceCostHolder){
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(financialDetailsResource.getWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamId(), financialDetailsResource.getSubWorkStreamName(), PortfolioConstants.TRUE,
                        financialDetailsResource.getScenario());
        Map<String, Object> monthDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategoriesForResourcesIndividualContributorAndHLE
                (financialDetailsResource.getWorkStreamId(),
                financialDetailsResource.getSubWorkStreamId(), financialDetailsResource.getSubWorkStreamName(), financialDetailsResource.getScenario(),
                glCategory, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
        List<String> monthBetweenDates = (List<String>) monthDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);
        SubWorkStreamResourceCostResource resourceCost = buildSubWorkStreamResourceCostResource(resource);

        List<String> monthBetweenDatesCurrentmonthTOStartMonth = getCurrentYearMonthBetweenDatesDefault(getCurrentPeriodAsMonthYear(), monthBetweenDates.get(0));
        monthBetweenDatesCurrentmonthTOStartMonth.remove(monthBetweenDatesCurrentmonthTOStartMonth.size()-1);
        monthBetweenDatesCurrentmonthTOStartMonth.forEach(monthYearDate -> {
            SubWorkStreamResourceCost subWorkstreamResourceCost =
                    populateSubWorkstreamResourceCostForCreate(financialDetailsResource,
                            monthBetweenDatesCurrentmonthTOStartMonth.size(),
                            resourceCost, monthYearDate, costSettings, Boolean.FALSE, glCategory);
            subWorkStreamResourceCostHolder.getSubWorkStreamResourceCosts().add(subWorkstreamResourceCost);
        });

        WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(financialDetailsResource.getWorkStreamId());
        PortfolioEntity portfolioId = portfolioRepo.findByPortfolioId(workStreamEntity.getPortfolioId());
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date depreStartDate = subWorkStreamKeyDatesEntity.getDepreStartDate();
        if(depreStartDate == null){
            depreStartDate = calculateDepreStartDate(subWorkStreamKeyDatesEntity.getGoLiveDate(),portfolioId.getAgileWaterFall());
        }
        log.info("calculated Depre start date:"+depreStartDate);
        List<String> monthBetweenDatesEndMonthToDepreStartDatefiveYears = getCurrentYearMonthBetweenDatesDefault(monthBetweenDates.get(monthBetweenDates.size()-1),
                getMonths(df.format(depreStartDate).substring(0, 7), 59).replaceAll("-", ""));
        monthBetweenDatesEndMonthToDepreStartDatefiveYears.remove(0);
        monthBetweenDatesEndMonthToDepreStartDatefiveYears.forEach(monthYearDate -> {
            SubWorkStreamResourceCost subWorkstreamResourceCost =
                    populateSubWorkstreamResourceCostForCreate(financialDetailsResource,
                            monthBetweenDatesCurrentmonthTOStartMonth.size(),
                            resourceCost, monthYearDate, costSettings, Boolean.FALSE, glCategory);
            subWorkStreamResourceCostHolder.getSubWorkStreamResourceCosts().add(subWorkstreamResourceCost);
        });
    }

    private SubWorkStreamResourceCostResource  buildSubWorkStreamResourceCostResource(SubWorkStreamResourceCostResource resource){
        SubWorkStreamResourceCostResource resourceCost= new SubWorkStreamResourceCostResource();
        resourceCost.setCostPerMonth(BigDecimal.ZERO);
        resourceCost.setCostPerDay(BigDecimal.ZERO);
        resourceCost.setLocation(resource.getLocation());
        resourceCost.setActiveInd(resource.getActiveInd());
        resourceCost.setCurrency(resource.getCurrency());
        resourceCost.setFdManDaysPerMonth(resource.getFdManDaysPerMonth());
        resourceCost.setFte(BigDecimal.ZERO);
        resourceCost.setLevel(resource.getLevel());
        resourceCost.setRateSource(resource.getRateSource());
        resourceCost.setRole(resource.getRole());
        resourceCost.setStaffType(resource.getStaffType());
        resourceCost.setVendor(resource.getVendor());
        return resourceCost;
    }

    private List<String> getResourceGlCategories(){
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.OPEX);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        glCategories.add(PortfolioConstants.CAPEX);
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        return glCategories;
    }

    private void calculateCostPerMonth(String glCategory, FinancialDetailsResource financialDetailsResource,
                                                        SubWorkStreamResourceCostResource costResource,List<String> monthBetweenDates){
        if(PortfolioConstants.ITDEPRECIATION.equalsIgnoreCase(glCategory)){
            Map<String, Object> capexMonthDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategoriesForResourcesIndividualContributorAndHLE(financialDetailsResource.getWorkStreamId(),
                    financialDetailsResource.getSubWorkStreamId(), financialDetailsResource.getSubWorkStreamName(), financialDetailsResource.getScenario(),
                    PortfolioConstants.CAPEX, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
            List<String> capexMonthBetweenDates = (List<String>) capexMonthDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);
            BigDecimal CostPerMonthTotal= costResource.getCostPerDay().multiply(costResource.getFdManDaysPerMonth()).multiply(BigDecimal.valueOf(capexMonthBetweenDates.size()));
            costResource.setCostPerMonth(CostPerMonthTotal.divide(BigDecimal.valueOf(monthBetweenDates.size()), 9, RoundingMode.HALF_UP));
        } else {
            costResource.setCostPerMonth(costResource.getCostPerDay().multiply(costResource.getFdManDaysPerMonth()));
        }
    }

    private SubWorkStreamResourceCost populateSubWorkstreamResourceCostForCreate
            (FinancialDetailsResource financialDetails,
             int noOfMonths,
             SubWorkStreamResourceCostResource resource,
             String currentYearMonth, String costSettings,
             Boolean original,
             String glCategory) {
        SubWorkStreamResourceCost subWorkStreamResourceCost = new SubWorkStreamResourceCost();
        subWorkStreamResourceCost.setWorkStreamId(financialDetails.getWorkStreamId());
        subWorkStreamResourceCost.setSubWorkStreamId(financialDetails.getSubWorkStreamId());
        subWorkStreamResourceCost.setSubWorkStreamName(financialDetails.getSubWorkStreamName());
        subWorkStreamResourceCost.setCostSettings(costSettings);
        subWorkStreamResourceCost.setScenario(financialDetails.getScenario());
        subWorkStreamResourceCost.setActiveInd(resource.getActiveInd());
        subWorkStreamResourceCost.setAddResource(PortfolioConstants.ADD_RESOURCE);
        subWorkStreamResourceCost.setEffectiveStartDate(new Timestamp(financialDetails.getStartDate().getTime()));
        subWorkStreamResourceCost.setEffectiveEndDate(new Timestamp(financialDetails.getGoLiveDate().getTime()));
        subWorkStreamResourceCost.setGlCategory(glCategory);
        subWorkStreamResourceCost.setPeriod(currentYearMonth);
        subWorkStreamResourceCost.setTeamRole(resource.getRole());
        subWorkStreamResourceCost.setAllocationPercentage(BigDecimal.valueOf(100));
        subWorkStreamResourceCost.setLocation(resource.getLocation());
        subWorkStreamResourceCost.setRateSource(resource.getRateSource());
        subWorkStreamResourceCost.setResourceType(PortfolioConstants.RESOURCE_TYPE_IC);
        subWorkStreamResourceCost.setStaffLevel(resource.getLevel());
        subWorkStreamResourceCost.setStaffType(resource.getStaffType());
        subWorkStreamResourceCost.setVendor(resource.getVendor());
        subWorkStreamResourceCost.setFte(resource.getFte());

        if(original){
            subWorkStreamResourceCost.setOriginalInd(PortfolioConstants.TRUE);
        }else{
            subWorkStreamResourceCost.setOriginalInd(PortfolioConstants.FALSE);
        }
        if(resource.getCostPerDay() != null && resource.getFdManDaysPerMonth() != null) {
            updateCurrencyValuesForResource(subWorkStreamResourceCost, resource.getCurrency(),
                    resource.getCostPerMonth(), financialDetails);
        }
        return subWorkStreamResourceCost;
    }

    private void updateCurrencyValuesForResource(SubWorkStreamResourceCost subWorkStreamResourceCost,
                                                 String currencyCode, BigDecimal costPerMonth,
                                                 FinancialDetailsResource financialDetails){
        if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)) {
            subWorkStreamResourceCost.setLocalCcy(currencyCode);
            subWorkStreamResourceCost.setBlendedCostLocalCcy(costPerMonth);
            subWorkStreamResourceCost.setGroupCcy(currencyCode);
            subWorkStreamResourceCost.setBlendedCostGroupCcy(costPerMonth);

        }else{
            subWorkStreamResourceCost.setLocalCcy(currencyCode);
            subWorkStreamResourceCost.setBlendedCostLocalCcy(costPerMonth);
            subWorkStreamResourceCost.setGroupCcy(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD);
            subWorkStreamResourceCost.setBlendedCostGroupCcy(costPerMonth.multiply(
                    financialDetailsService.getExchangeRatesEntity(subWorkStreamResourceCost.getPeriod(),
                            currencyCode, financialDetails.getWorkStreamId()).getRateValue()));
        }
    }
}
