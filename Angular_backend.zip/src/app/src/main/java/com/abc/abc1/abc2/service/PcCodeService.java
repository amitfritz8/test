package com.dbs.genesis.portfolio.service;


import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.PcCodeTree;
import com.dbs.genesis.portfolio.repository.PcCodeTreeRepo;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.function.Supplier;

@Service
@Transactional
public class PcCodeService {

    private final PcCodeTreeRepo pcCodeTreeRepo;

    @Autowired
    public PcCodeService(PcCodeTreeRepo pcCodeTreeRepo) {
        this.pcCodeTreeRepo = pcCodeTreeRepo;
    }

    public List<PcCodeTree> getPcCodesTreeListByPlatform(String platformIndex) {
        Supplier<List<PcCodeTree>> commandSupplier = () -> pcCodeTreeRepo.findByPlatformIndex(platformIndex);
        Supplier<List<PcCodeTree>> defaultSupplier = Lists::newArrayList;
        return ResiliencyDecorators.ofSupplier(commandSupplier, defaultSupplier).get();
    }

    public List<String> getPcCodeListByCountryCode(String countryCode) {
        return pcCodeTreeRepo.findByCountryCode(countryCode);
    }

    public List<PcCodeTree> getPcCodesTreeList() {
        Supplier<List<PcCodeTree>> commandSupplier = () -> pcCodeTreeRepo.findByPlatformIndexIsNot(PortfolioConstants.PTFM_NP);
        Supplier<List<PcCodeTree>> defaultSupplier = Lists::newArrayList;
        return ResiliencyDecorators.ofSupplier(commandSupplier,defaultSupplier).get();
    }
}
