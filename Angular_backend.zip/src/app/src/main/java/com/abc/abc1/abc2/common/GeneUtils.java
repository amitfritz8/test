package com.dbs.genesis.portfolio.common;

import com.dbs.genesis.portfolio.model.EditLog;
import com.dbs.genesis.portfolio.model.PortfolioEntity;
import com.dbs.genesis.portfolio.model.SubWorkStreamEntity;
import com.dbs.genesis.portfolio.model.WorkStreamEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class GeneUtils {

    public static void populateStaffNameAndEditFlag(ResponseEntity responseEntity, EditLog editLog, String portfolioType,String staffName) {

        String editable = !StringUtils.isEmpty(staffName) && staffName.equalsIgnoreCase(editLog.getStaffDisplayName()) ? "OK" : "NO";

        if(PortfolioConstants.PORTFOLIONAME.equalsIgnoreCase(portfolioType)){
            PortfolioEntity entity = (PortfolioEntity) responseEntity.getBody();
            entity.setStaffName(editLog.getStaffDisplayName());
            entity.setEditable(editable);
        } else if(PortfolioConstants.WORKSTREAMNAME.equalsIgnoreCase(portfolioType)){
            WorkStreamEntity entity = (WorkStreamEntity) responseEntity.getBody();
            entity.setStaffName(editLog.getStaffDisplayName());
            entity.setEditable(editable);

        } else {
            SubWorkStreamEntity entity = (SubWorkStreamEntity) responseEntity.getBody();
            entity.setStaffName(editLog.getStaffDisplayName());
            entity.setEditable(editable);
        }
    }

    public static List<String> getGlCategoriesNotInclude () {
        List <String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        return glCategories;
    }
}
