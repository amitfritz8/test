package com.dbs.genesis.portfolio.common;

import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public interface DateExtensions {
    Logger log = LoggerFactory.getLogger(DateExtensions.class);

    default String getCurrentYear(){
        int year = LocalDate.now().getYear();
        return String.valueOf(year);
    }


    default java.sql.Date calculateDepreStartDate(java.sql.Date goLiveDate, String agileWaterFall) {
        if (PortfolioConstants.AGILE.equalsIgnoreCase(agileWaterFall) && goLiveDate != null) {
            Date subWorkStreamDataSourceGoLiveDate = getDateAfterNoOfMonths(goLiveDate, 3);
            return new java.sql.Date(subWorkStreamDataSourceGoLiveDate.getTime());
        }
        return goLiveDate;
    }


    default List<String> getMonthYearListByStartDateAndEndDate(Date startDate, Date endDate) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String startDateString = df.format(startDate);
        String endDateString = df.format(endDate);
        return getCurrentYearMonthBetweenDates(
                startDateString.substring(0, 7), endDateString.substring(0, 7));
    }

    default List<String> getCurrentYearMonthBetweenDates(String startDate, String endDate) {

        List<String> list = new ArrayList<>();
        DateFormat format = new SimpleDateFormat("yyyy-MM");
        Calendar beginCalendar = Calendar.getInstance();
        Calendar finishCalendar = Calendar.getInstance();
        try {
            beginCalendar.setTime(format.parse(startDate));
            finishCalendar.setTime(format.parse(endDate));
        } catch (ParseException e) {
            log.error("Following exception thrown when getting months between dates: ",e);
        }
        DateFormat formatterYd = new SimpleDateFormat("yyyy-MM");
        while (beginCalendar.before(finishCalendar)) {
            String date = formatterYd.format(beginCalendar.getTime());
            beginCalendar.add(Calendar.MONTH, 1);
            list.add(date.replaceAll("-",""));
        }
        list.add(endDate.replaceAll("-",""));
        Collections.sort(list);
        return list;
    }

    default Timestamp convertStrToTimestamp(String timestamp) {
        SimpleDateFormat sfdate = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        try {
            Date date = sfdate.parse(timestamp);
            return new Timestamp(date.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    default String getCurrentPeriodAsMonthYear() {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String startDateString = df.format(Date.from(Instant.now()));
        return startDateString.substring(0, 7).replaceAll("-", "");
    }

    default List<String> getMonthYearListByAddingMonths(Date date,int numOfMonths) {
        DateFormat formatter = new SimpleDateFormat("yyyyMM");

        try {
            Date yearMonth = formatter.parse(formatter.format(date));
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(yearMonth);

            List<String> yearMonths = IntStream.range(0, numOfMonths).mapToObj(i -> {
                calendar.add(Calendar.MONTH, i>0?1:0);
                return formatter.format(calendar.getTime());
            }).collect(Collectors.toList());

            return yearMonths;
        } catch (ParseException e) {
            log.error("Following exception thrown when getting months year list by adding months : ",e);
        }

        return Lists.newArrayList();

    }

    default String getDecMonthOfTheDate(Date date){
        DateFormat df = new SimpleDateFormat("yyyy-12-dd");
        String startDateString = df.format(date);
        return startDateString.substring(0, 7);
    }

    default String getMonths(String date, Integer number) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM");
        Calendar cal = Calendar.getInstance();
        try {
            cal.setTime(format.parse(date));
        } catch (ParseException e) {
            log.error("Following exception thrown while getting months: ",e);
        }
        cal.add(Calendar.MONTH, number);
      return format.format(cal.getTime());
    }

    default Date getDateAfterNoOfMonths(Date date, Integer number) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.MONTH, number);
        return cal.getTime();
    }

    default List<String> getYearsBetweenDates(String startDate, String endDate) {

        List<String> list = new ArrayList<>();
        DateFormat format = new SimpleDateFormat("yyyy");
        Calendar beginCalendar = Calendar.getInstance();
        Calendar finishCalendar = Calendar.getInstance();
        try {
            beginCalendar.setTime(format.parse(startDate));
            finishCalendar.setTime(format.parse(endDate));
        } catch (ParseException e) {
            log.error("Following exception thrown when getting months between dates: ",e);
        }
        DateFormat formatterYd = new SimpleDateFormat("yyyy");
        while (beginCalendar.before(finishCalendar)) {
            String date = formatterYd.format(beginCalendar.getTime());
            beginCalendar.add(Calendar.YEAR, 1);
            list.add(date);
        }
        list.add(endDate);
        Collections.sort(list);
        return list;
    }

    default List<String> getCurrentYearMonthBetweenDatesDefault(String startDate, String endDate) {

        List<String> list = new ArrayList<>();
        DateFormat format = new SimpleDateFormat("yyyyMM");
        Calendar beginCalendar = Calendar.getInstance();
        Calendar finishCalendar = Calendar.getInstance();
        try {
            beginCalendar.setTime(format.parse(startDate));
            finishCalendar.setTime(format.parse(endDate));
        } catch (ParseException e) {
            log.error("Following exception thrown when getting months between dates: ",e);
        }
        DateFormat formatterYd = new SimpleDateFormat("yyyyMM");
        while (beginCalendar.before(finishCalendar)) {
            String date = formatterYd.format(beginCalendar.getTime());
            beginCalendar.add(Calendar.MONTH, 1);
            list.add(date);
        }
        list.add(endDate);
        Collections.sort(list);
        return list;
    }
}
