package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HyperionProductResource {

     String l0Node;
    String l0Desc;


    public HyperionProductResource(String l0Node, String l0Desc) {
        this.l0Node = l0Node;
        this.l0Desc = l0Desc;

    }

}
