package com.dbs.genesis.portfolio.controller;


import com.dbs.genesis.portfolio.exception.MappingException;
import com.dbs.genesis.portfolio.model.SubWorkStreamApprovers;
import com.dbs.genesis.portfolio.model.SubWorkStreamEntity;
import com.dbs.genesis.portfolio.model.SubWorkStreamKeyDatesEntity;
import com.dbs.genesis.portfolio.model.WorkStreamKeyDatesEntity;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.service.SubWorkStreamService;
import com.dbs.genesis.portfolio.service.WorkStreamService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/data/subworkstream")
public class SubWorkStreamController {

    @Autowired
    private SubWorkStreamService subWorkStreamService;
    @Autowired
    private WorkStreamService workStreamService;

    @PostMapping("/generation")
    private ResponseEntity getSubWorkStreamData(@RequestBody SubWorkStreamDataSource subWorkStreamDataSource) {
        SubWorkStreamEntity workStreamEntity = subWorkStreamService.saveSubWorkStreamData(subWorkStreamDataSource);
        return ResponseEntity.ok().body(workStreamEntity);
    }

    @PostMapping("/generation/isExistsWorkStreamId")
    boolean isExistsWorkStreamIdWithDeliveryUnit(@RequestBody SubWorkStreamDataSource subWorkStreamDataSource) {
        String deliveryUnit = subWorkStreamDataSource.getPortFolioSubWorkStreamEntity().getDeliveryUnit();
        boolean value = subWorkStreamService.existsWorkStreamIdWithDeliveryUnit(subWorkStreamDataSource.
                        getWorkStreamId(),
                deliveryUnit.substring(0, deliveryUnit.indexOf("-")).trim());
        return value;
    }

    @PostMapping("/edit/updateSubWorkstream")
    public ResponseEntity updateSubWorkStream(@RequestBody SubWorkStreamDataSource subWorkStreamDataSource) {
        log.info("Incoming request for updateSubWorkStream: "+subWorkStreamDataSource);
        try {
            SubWorkStreamEntity subWorkStreamEntity = subWorkStreamService.updateSubWorkStreamData(subWorkStreamDataSource);
            return ResponseEntity.ok().body(subWorkStreamEntity);
        } catch (MappingException err){
            log.error("Update Sub Stream : ", err);
            return ResponseEntity.status(HttpStatus.FAILED_DEPENDENCY).body(err.getMessage());
        } catch (Exception e) {
            log.error("Update Sub Workstream : ", e);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error editing Subworkstream");
    }

    @GetMapping("/getworkmanagers/{subWorkStreamId}/{subWorkStreamName}")
    public ResponseEntity getListOfWorkManagers(@PathVariable String subWorkStreamId, @PathVariable String
            subWorkStreamName) {
        List<Map> mapList = subWorkStreamService.getListOfWorkMangers(subWorkStreamId, subWorkStreamName);
        return ResponseEntity.ok().body(mapList);
    }

    @GetMapping("/listOfKeyDates/{subWorkStreamId}/{subWorkStreamName}")
    public ResponseEntity getListOfKeyDates(@PathVariable String subWorkStreamId, @PathVariable String
            subWorkStreamName) {
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamService.
                getSubWorkStreamKeyDates(subWorkStreamId, subWorkStreamName);
        return ResponseEntity.ok().body(subWorkStreamKeyDatesEntity);
    }

    @GetMapping("/listOfKeyDates/{subWorkStreamId}/{subWorkStreamName}/{scenarioName}")
    public ResponseEntity getListOfKeyDatesBasedOnScenario(@PathVariable String subWorkStreamId, @PathVariable String
            subWorkStreamName, @PathVariable String scenarioName) {
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamService.
                getSubWorkStreamKeyDatesBasedonScenario(subWorkStreamId, subWorkStreamName, scenarioName);
        return ResponseEntity.ok().body(subWorkStreamKeyDatesEntity);
    }

    @GetMapping("/keyDatesList/{workStreamId}/{subWorkStreamId}/{subWorkStreamName}")
    public ResponseEntity getKeyDates(@PathVariable String workStreamId, @PathVariable String subWorkStreamId, @PathVariable String
            subWorkStreamName) {
        List<SubWorkStreamKeyDatesEntity> subWorkStreamKeyDatesEntity = subWorkStreamService.
                getSubWorkStreamKeyDatesList(subWorkStreamId, subWorkStreamName);
        List<WorkStreamKeyDatesEntity> workStreamKeyDatesEntities = workStreamService.getWorkStreamForeCastKeyDates(workStreamId);
        return ResponseEntity.ok().body(new WSAndSWSKeyDatesResource(subWorkStreamKeyDatesEntity,workStreamKeyDatesEntities));
    }


    @GetMapping("/getApprovals/{subWorkStreamId}/{subWorkStreamName}")
    public ResponseEntity getApprovesData(@PathVariable String subWorkStreamId, @PathVariable String subWorkStreamName) {
        List<SubWorkStreamApprovers> subWorkStreamApproversList = subWorkStreamService.
                getSubWorkStreamApprovesList(subWorkStreamId, subWorkStreamName);
        return ResponseEntity.ok().body(subWorkStreamApproversList);
    }

    @PostMapping("/listing")
    public ResponseEntity getSubWorkStreamListing(@RequestBody IdAndRoles idAndRoles) {
        Instant start = Instant.now();
        List<SubWorkStreamListingSource> subWorkStreamListingSources = subWorkStreamService.getSubWorkStreamListing(idAndRoles);
        Instant finish = Instant.now();
        long timeElapsed = Duration.between(start, finish).toMillis();
        log.info("Total time SubWorkStreamListing in Millis: "+timeElapsed);
        return ResponseEntity.ok().body(subWorkStreamListingSources);
    }

    @PostMapping("/pccodes/view")
    public ResponseEntity getSubWorkstreamPccodes(@RequestBody SubWorkStreamIdAndName subWorkStreamIdAndName) {
        return ResponseEntity.ok().body(subWorkStreamService.getSubWorkStreamPccodes(subWorkStreamIdAndName));
    }

    @PostMapping("/pccodes/edit")
    public ResponseEntity getSubWorkstreamPccodesEdit(@RequestBody SubWorkStreamIdAndName subWorkStreamIdAndName) {
        return ResponseEntity.ok().body(subWorkStreamService.getSubWorkStreamPccodesforEdit(subWorkStreamIdAndName));
    }


    @GetMapping("/checkForecastExistsForSWS/{subWorkStreamId}/{subWorkStreamName}")
    public ResponseEntity checkForecastExistsForSWS(@PathVariable String subWorkStreamId, @PathVariable String
            subWorkStreamName) {
        boolean isExist = subWorkStreamService.checkForecastExistsForSWS(subWorkStreamId, subWorkStreamName);
        return ResponseEntity.ok().body(isExist);
    }

}
