package com.dbs.genesis.portfolio.model;

import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Date;

@Data
@Entity
@Table(name = "sub_workstream_approvers")
@EntityListeners(AuditingEntityListener.class)
@ToString
public class SubWorkStreamApprovers extends CommonEntity<String>{

    @Id
    @Column(name = "sws_approver_surr_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer swsApproveSurrId;
    @Column(name = "workstream_id")
    private String workStreamId;
    @Column(name = "sub_workstream_id")
    private String subWorkStreamId;
    @Column(name = "1bank_id")
    private String oneBankId;
    @Column(name = "staff_name")
    private String staffName;
    @Column(name = "role")
    private String role;
    @Column(name = "delegate_ind")
    private String delegateInd;
    @Column(name = "active_ind")
    private String activeInd;
    @Column(name = "scenario")
    private String scenario;
    @Column(name = "action")
    private String action;
    @Column(name = "notify_ind")
    private String notifyInd;
    @Column(name = "effective_start_date")
    private Date effectiveStartDate;
    @Column(name = "effective_end_date")
    private Date effectiveEndDate;
    @Column(name = "sub_workstream_name")
    private String subWorkStreamName;
}
