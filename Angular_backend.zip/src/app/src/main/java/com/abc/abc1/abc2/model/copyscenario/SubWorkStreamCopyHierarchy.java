package com.dbs.genesis.portfolio.model.copyscenario;

import lombok.Data;

@Data
public class SubWorkStreamCopyHierarchy {

    private ScenarioCopyHierarchy scenarioCopyHierarchy;

}
