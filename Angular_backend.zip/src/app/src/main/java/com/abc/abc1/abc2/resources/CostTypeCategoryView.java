package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class CostTypeCategoryView {

    String name;


    List<BigDecimal> monthlyCostTypes;
    List<List<BigDecimal>> monthlyCostTypesResource;


    Map<String, BigDecimal> yearlyCostType;

    Map<String, BigDecimal> yearlyFTEType;
    Map<String, BigDecimal> yearlyMandaysType;


    BigDecimal costTypeTotal = BigDecimal.ZERO;
    List<BigDecimal> costTypeTotalResource = new ArrayList<>();


    BigDecimal costTypeOverAllTotal = BigDecimal.ZERO;
    List<BigDecimal> costTypeOverAllTotalResource = new ArrayList<>();


    Map<String, BigDecimal> individualYearSummaryForQuarterly;
    Map<String, List<BigDecimal>> individualYearSummaryForQuarterlyForResource;


    Map<String, List<BigDecimal>> quarterlyCostType;
    Map<String, List<BigDecimal>> quarterlyMandaysType;
    Map<String, List<BigDecimal>> quarterlyAllocationType;
    Map<String, List<BigDecimal>> quarterlyFTEType;


    Map<String, List<BigDecimal>> monthlyCostSummary;
    Map<String, List<BigDecimal>> quarterlyCostSummary;
    Map<String, List<BigDecimal>> yearlyCostSummary;

    //For BreakDownCost
    List<UnitCostMappingView> monthlyUnitCostList;
    Map<String, List<UnitCostMappingView>> quarterlyUnitCostList;
    Map<String, List<UnitCostMappingView>> yearlyUnitCostList;

    List<MonthlyResource> monthlyResources;

}
