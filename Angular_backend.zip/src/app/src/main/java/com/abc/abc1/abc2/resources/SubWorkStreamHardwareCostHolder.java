package com.dbs.genesis.portfolio.resources;

import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class SubWorkStreamHardwareCostHolder {

    SubWorkstreamHardwareCost subWorkstreamHardwareCost;
    List<SubWorkstreamHardwareCost> subWorkstreamHardwareCosts = new ArrayList<>();
}
