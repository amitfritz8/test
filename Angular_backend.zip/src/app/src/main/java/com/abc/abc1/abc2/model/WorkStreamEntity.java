package com.dbs.genesis.portfolio.model;

import com.dbs.genesis.portfolio.resources.WorkStreamListingSource;
import lombok.Data;
import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import javax.persistence.*;
import java.math.BigInteger;
import java.sql.Date;
import java.util.List;

import static org.hibernate.envers.RelationTargetAuditMode.NOT_AUDITED;


@NamedStoredProcedureQuery(name = "workStreamSequence",
        procedureName = "sp_workstream_sequence",
        parameters = {
                @StoredProcedureParameter(mode = ParameterMode.OUT, name = "outmaxid", type = BigInteger.class)
        })

@SqlResultSetMappings({
        @SqlResultSetMapping(name = "mapWorkStreamListing",
                classes = {
                        @ConstructorResult(targetClass = WorkStreamListingSource.class,
                                columns = {
                                        @ColumnResult(name = "portfolioId"),
                                        @ColumnResult(name = "portfolioName"),
                                        @ColumnResult(name = "workStreamId"),
                                        @ColumnResult(name = "workStreamName"),
                                        @ColumnResult(name = "platformName"),
                                        @ColumnResult(name = "location"),
                                        @ColumnResult(name = "lePCCodeBuild"),
                                        @ColumnResult(name = "workStatus"),
                                        @ColumnResult(name = "subPlatformName")
                                })
                })
})

@NamedNativeQueries({
        @NamedNativeQuery(
                name = "workStreamListingByOneBankId",
                query = "select distinct  c.portfolio_id as portfolioId, c.portfolio_name as portfolioName, b.workstream_id as workStreamId, b.workstream_name as workStreamName, c.primary_platform_name as platformName, \n" +
                        " b.country as location, b.le_pccode_build as lePCCodeBuild, b.work_status as workStatus, b.sub_platform_name as subPlatformName \n"+
                        " from sub_workstream_dates a,workstream_profile b,portfolio_profile c, portfolio_managers m \n" +
                        " where a.scenario_name = ?1 and a.workstream_id = b.workstream_id and b.portfolio_id = c.portfolio_id and m.portfolio_id = b.portfolio_id \n" +
                        "       and ((c.primary_platform_index in (?2) and c.reporting_flag in (?3) and b.country in (?4) and m.1bank_id = ?5 and m.active_ind='true') or (m.1bank_id=?5 and m.active_ind='true')) \n" +
                        "UNION \n" +
                        "select distinct  c.portfolio_id as portfolioId, c.portfolio_name as portfolioName, b.workstream_id as workStreamId, b.workstream_name as workStreamName, c.primary_platform_name as platformName, \n" +
                        " b.country as location, b.le_pccode_build as lePCCodeBuild, b.work_status as workStatus, b.sub_platform_name as subPlatformName \n"+
                        "  from sub_workstream_dates a,workstream_profile b,portfolio_profile c, workstream_managers w \n" +
                        " where a.scenario_name = ?1 and a.workstream_id = b.workstream_id and b.portfolio_id = c.portfolio_id and w.portfolio_id = b.portfolio_id \n" +
                        " and((c.primary_platform_index in (?2) and c.reporting_flag in (?3) and b.country in (?4) and w.1bank_id = ?5 and w.active_ind = 'true') or (w.1bank_id = ?5 and w.active_ind = 'true'))\n",
                resultSetMapping = "mapWorkStreamListing"
        ),
        @NamedNativeQuery(
                name = "workStreamListingAll",
                query = "select distinct  c.portfolio_id as portfolioId, c.portfolio_name as portfolioName, b.workstream_id as workStreamId, b.workstream_name as workStreamName, c.primary_platform_name as platformName, \n" +
                        " b.country as location, b.le_pccode_build as lePCCodeBuild, b.work_status as workStatus, b.sub_platform_name as subPlatformName \n"+
                        " from sub_workstream_dates a,workstream_profile b,portfolio_profile c, sub_workstream_profile s \n"+
                        " where a.scenario_name = ?1 and a.sub_workstream_id = s.sub_workstream_id and b.portfolio_id = c.portfolio_id and b.workstream_id=s.workstream_id \n" +
                        "    and c.primary_platform_index in (?2) and c.reporting_flag in (?3) and b.country in (?4) ",
                resultSetMapping = "mapWorkStreamListing"
        )
})

@Data
@Entity
@Table(name = "workstream_profile")
@EntityListeners(AuditingEntityListener.class)
@Audited(withModifiedFlag = true)
public class WorkStreamEntity extends CommonEntity<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ws_surr_id")
    private int workStreamSurrId;

    @Column(name = "portfolio_id")
    @Audited(withModifiedFlag = true, modifiedColumnName = "portfolio_id_MOD")
    private String portfolioId;

    @Column(name = "workstream_id")
    @Audited(withModifiedFlag = true, modifiedColumnName = "workstream_id_MOD")
    private String workStreamId;

    @Column(name = "workstream_name")
    @Audited(withModifiedFlag = true, modifiedColumnName = "workstream_name_MOD")
    private String workStreamName;

    @Column(name = "workstream_desc")
    @Audited(withModifiedFlag = true, modifiedColumnName = "workstream_desc_MOD")
    private String workStreamDesc;

    @Column(name = "country")
    @Audited(withModifiedFlag = true, modifiedColumnName = "country_MOD")
    private String country;

    @Column(name = "sub_platform_name")
    @Audited(withModifiedFlag = true, modifiedColumnName = "sub_platform_name_MOD")
    private String subPlatFormName;

    @Column(name = "biz_segment")
    @Audited(withModifiedFlag = true, modifiedColumnName = "biz_segment_MOD")
    private String bizSegment;

    @Column(name = "value_benefit")
    @Audited(withModifiedFlag = true, modifiedColumnName = "value_benefit_MOD")
    private String valueBenefit;

    @Column(name = "value_benefit_start_date")
    @Audited(withModifiedFlag = true, modifiedColumnName = "value_benefit_start_date_MOD")
    private Date valueBenefitStartDate;

    @Column(name = "work_status")
    @Audited(withModifiedFlag = true, modifiedColumnName = "work_status_MOD")
    private String workStatus;

    @Column(name = "work_phase")
    @Audited(withModifiedFlag = true, modifiedColumnName = "work_phase_MOD")
    private String workPhase;

    @Column(name = "thematic")
    @Audited(withModifiedFlag = true, modifiedColumnName = "thematic_MOD")
    private String thematic;

    @Column(name = "horizon")
    @Audited(withModifiedFlag = true, modifiedColumnName = "horizon_MOD")
    private String horizon;

    @Column(name = "agile_waterfall_ind")
    @Audited(withModifiedFlag = true, modifiedColumnName = "agile_waterfall_ind_MOD")
    private String agileWaterFallIndicator;

    @Column(name = "category")
    @Audited(withModifiedFlag = true, modifiedColumnName = "category_MOD")
    private String category;

    @Column(name = "le_pccode_build")
    @Audited(withModifiedFlag = true, modifiedColumnName = "le_pccode_build_MOD")
    private String lePCCodeBuild;

    @Column(name = "le_pccode_operate")
    @Audited(withModifiedFlag = true, modifiedColumnName = "le_pccode_operate_MOD")
    private String lePCCodeOperate;

    @Column(name = "workstream_ref")
    @Audited(withModifiedFlag = true, modifiedColumnName = "workstream_ref_MOD")
    private String workStreamRef;

    @Column(name = "overall_risk_level")
    @Audited(withModifiedFlag = true, modifiedColumnName = "overall_risk_level_MOD")
    private String overallRiskLevel;


    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "workstream_ref_id",updatable = false)
    @Audited(withModifiedFlag = true, modifiedColumnName = "sub_work_stream_entities_MOD")
    private List<SubWorkStreamEntity> subWorkStreamEntities;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "ws_lepccodes_ref_id",updatable = false)
    @Audited(targetAuditMode = NOT_AUDITED)
    private List<WorkstreamLePccodesEntity> workstreamLePccodesEntities;

    @Transient
    private String editable;

    @Transient
    private String staffName;

}
