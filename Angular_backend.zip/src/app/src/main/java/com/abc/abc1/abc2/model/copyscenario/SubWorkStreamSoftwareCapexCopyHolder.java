package com.dbs.genesis.portfolio.model.copyscenario;

import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class SubWorkStreamSoftwareCapexCopyHolder {

    private SubWorkstreamSoftwareCost subWorkStreamSoftwareCapexCostParent;
    private List<SubWorkstreamSoftwareCost> subWorkStreamSoftwareCapexCostChildren =
            new ArrayList<>();

    private SubWorkstreamSoftwareCost subWorkStreamSoftwareITDepreciationCostParent;
    private List<SubWorkstreamSoftwareCost> subWorkStreamSoftwareITDepreciationCostChildren =
            new ArrayList<>();
}
