package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.SubWorkstreamFinDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Repository
public interface SubWorkstreamFinDetailsRepo extends JpaRepository<SubWorkstreamFinDetailsEntity,Integer> {

    List<SubWorkstreamFinDetailsEntity>
    findByScenarioAndWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndGlCategoryAndPeriodContainingAndOrgInd(
            String scenario, String workStreamId, String subWorkStreamId, String subWorkStreamName,
            String category,String period,String orgInd);

    List<SubWorkstreamFinDetailsEntity>
    findByScenarioAndWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndAndCostSettingAndPeriodContainingAndOrgInd
            (String scenario, String workStreamId, String subWorkStreamId, String subWorkStreamName,String costSettings,String period,String orgInd);

    List<SubWorkstreamFinDetailsEntity>
    findByCostSettingAndWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndCostTypeAndOrgIndAndPeriodContainingAndScenario(
            String costSetting, String workStreamId, String subWorkStreamId, String subWorkStreamName,
            String costType,String aTrue,String period,String scenario);

    @Query(value = "select distinct substring(s.period,1,4) from sub_workstream_fin_details s where " +
            "workstream_id= :workStreamId and sub_workstream_id= :subWorkStreamId and scenario= :scenario and " +
            "sub_workstream_name= :subWorkStreamName ", nativeQuery = true)
    List<String> getListOfFinancialYears(@Param("workStreamId") String workStreamId, @Param("subWorkStreamId") String
            subWorkStreamId, @Param("scenario") String scenario, @Param("subWorkStreamName") String subWorkStreamName);

    /*@Query(value ="select COALESCE(sum(group_ccy_val),0) from sub_workstream_fin_details where  workstream_id= :workStreamId and " +
            "sub_workstream_id= :subWorkStreamId and scenario= :scenario and sub_workstream_name= :subWorkStreamName and " +
            "gl_category= :glCategory",nativeQuery = true)
    BigDecimal getSumOfOverAllScenario(@Param("workStreamId") String workStreamId, @Param("subWorkStreamId") String
            subWorkStreamId, @Param("scenario") String scenario, @Param("subWorkStreamName") String subWorkStreamName,
                                       @Param("glCategory") String glCategory);*/

    @Query(value = "select COALESCE(sum(group_ccy_val),0) from sub_workstream_fin_details where gl_category in :glCategories and   " +
            "workstream_id= :workStreamId and sub_workstream_id= :subWorkStreamId\n" +
            "and sub_workstream_name= :subWorkStreamName and org_ind = :originalIndicatorFalse",
            nativeQuery = true)
    BigDecimal getGlCategoryTotalAmountByGrpCcy(@Param("glCategories") Set<String> glCategories, @Param("workStreamId")
            String workStreamId, @Param("subWorkStreamId") String subWorkStreamId,
                                        @Param("subWorkStreamName") String subWorkStreamName, @Param("originalIndicatorFalse")String originalIndicatorFalse);

    @Query(value = "select COALESCE(sum(local_ccy_val),0) from sub_workstream_fin_details where gl_category in :glCategories and   " +
            "workstream_id= :workStreamId and sub_workstream_id= :subWorkStreamId\n" +
            "and sub_workstream_name= :subWorkStreamName and org_ind = :originalIndicatorFalse",
            nativeQuery = true)
    BigDecimal getGlCategoryTotalAmountByLocalCcy(@Param("glCategories") Set<String> glCategories, @Param("workStreamId")
            String workStreamId, @Param("subWorkStreamId") String subWorkStreamId,
                                        @Param("subWorkStreamName") String subWorkStreamName, @Param("originalIndicatorFalse")String originalIndicatorFalse);

   /* List<SubWorkstreamFinDetailsEntity>
    findByWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndCostSettingAndPeriodInAndScenario(
            String workStreamId,String subWorkStreamId,String subWorkStreamName,String costSetting,List<String> periods,
            String scenario);*/

    List<SubWorkstreamFinDetailsEntity>
    findByWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndCostSettingAndScenarioAndOrgIndAndCostTypeIn(
            String workStreamId,String subWorkStreamId,String subWorkStreamName,String costSetting, String scenario,
            String orgInd, List<String> costTypes);

    /*@Query(value = "select sws_fd_surr_id from sub_workstream_fin_details where workstream_id= :workStreamId and " +
            "sub_workstream_id= :subWorkStreamId and " +
            "sub_workstream_name= :subWorkStreamName and scenario= :scenario and gl_category= :glCategory and " +
            "cost_type= :costType and period= :period and local_ccy= :localCurrency and cost_settings= :costSetting",
            nativeQuery = true)
    String getSubWorkStreamFinDetailsFinSurrId(@Param("workStreamId") String workStreamId,
                                                       @Param("subWorkStreamId") String subWorkStreamId,
                                                       @Param("subWorkStreamName") String subWorkStreamName,
                                                       @Param("scenario") String scenario,
                                                       @Param("glCategory") String glCategory, @Param("costType")
                                                               String costType, @Param("period") String period,
                                                       @Param("localCurrency") String localCurrency,
                                                       @Param("costSetting") String costSetting);*/

    /*SubWorkstreamFinDetailsEntity
    findByWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndScenarioAndCostSettingAndGlCategoryAndCostTypeAndPeriodAndLocalCcy(
            String workStreamId, String subWorkStreamId, String subWorkStreamName, String scenario, String costSetting,
            String glCategory, String costType, String period, String localCurrency);*/


    @Query(value = "select COALESCE(sum(group_ccy_val),0) from sub_workstream_fin_details where workstream_id= :workStreamId and " +
            "sub_workstream_id= :subWorkStreamId and sub_workstream_name= :subWorkStreamName and scenario= :scenario " +
            "and gl_category= :glCategory and cost_type= :costType and cost_settings= :costSetting and org_ind='false' ",nativeQuery = true)
    BigDecimal getCostTypeOverAllSumByGrpCcy(@Param("workStreamId") String workStreamId,
                                     @Param("subWorkStreamId") String subWorkStreamId,
                                     @Param("subWorkStreamName") String subWorkStreamName,
                                     @Param("scenario") String scenario,
                                     @Param("glCategory") String glCategory, @Param("costType")
                                             String costType, @Param("costSetting")
                                             String costSetting);

    @Query(value = "select COALESCE(sum(local_ccy_val),0) from sub_workstream_fin_details where workstream_id= :workStreamId and " +
            "sub_workstream_id= :subWorkStreamId and sub_workstream_name= :subWorkStreamName and scenario= :scenario " +
            "and gl_category= :glCategory and cost_type= :costType and cost_settings= :costSetting  and org_ind='false' ",nativeQuery = true)
    BigDecimal getCostTypeOverAllSumByLocalCcy(@Param("workStreamId") String workStreamId,
                                     @Param("subWorkStreamId") String subWorkStreamId,
                                     @Param("subWorkStreamName") String subWorkStreamName,
                                     @Param("scenario") String scenario,
                                     @Param("glCategory") String glCategory, @Param("costType")
                                             String costType, @Param("costSetting")
                                             String costSetting);

    @Query(value = "select COALESCE(sum(group_ccy_val),0) from sub_workstream_fin_details where workstream_id= :workStreamId and " +
            "sub_workstream_id= :subWorkStreamId and sub_workstream_name= :subWorkStreamName and scenario= :scenario " +
            "and cost_settings= :costSetting and org_ind='false' ",nativeQuery = true)
    BigDecimal getCostSettingsOverAllSumByGrpCcy(@Param("workStreamId") String workStreamId,
                                         @Param("subWorkStreamId") String subWorkStreamId,
                                         @Param("subWorkStreamName") String subWorkStreamName,
                                         @Param("scenario") String scenario, @Param("costSetting") String costSetting);

    @Query(value = "select COALESCE(sum(local_ccy_val),0) from sub_workstream_fin_details where workstream_id= :workStreamId and " +
            "sub_workstream_id= :subWorkStreamId and sub_workstream_name= :subWorkStreamName and scenario= :scenario " +
            "and cost_settings= :costSetting and org_ind='false' ",nativeQuery = true)
    BigDecimal getCostSettingsOverAllSumByLocalCcy(@Param("workStreamId") String workStreamId,
                                         @Param("subWorkStreamId") String subWorkStreamId,
                                         @Param("subWorkStreamName") String subWorkStreamName,
                                         @Param("scenario") String scenario, @Param("costSetting") String costSetting);

    @Query(value = "select distinct substring(s.period,1,4) from sub_workstream_fin_details s where " +
            "workstream_id= :workStreamId and sub_workstream_id= :subWorkStreamId  and " +
            "sub_workstream_name= :subWorkStreamName and scenario= :scenario and cost_settings= :costSetting ",
            nativeQuery = true)
    List<String> getListOfFinancialYearsByCostSetting(@Param("workStreamId") String workStreamId, @Param("subWorkStreamId") String subWorkStreamId,
                                                      @Param("subWorkStreamName") String subWorkStreamName, @Param("scenario") String scenario, @Param("costSetting") String costSetting);

    List<SubWorkstreamFinDetailsEntity> findByRefSwsFdSurrIdAndOrgIndIgnoreCase(Integer subWorkStreamFinSurrId, String orgInd);
    List<SubWorkstreamFinDetailsEntity> findByWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndScenarioAndCostTypeAndCostSettingAndOrgInd(
            String workstreamId, String subWorkstreamId, String subWorkstreamName, String scenario,String costType, String costSetting, String orgInd);

    List<SubWorkstreamFinDetailsEntity> findAllByWorkstreamIdAndSubWorkstreamIdInAndScenario(
            String workStreamId, List<String> subWorkStreamIds, String scenario);

    List<SubWorkstreamFinDetailsEntity> findAllByWorkstreamIdAndSubWorkstreamIdInAndCostSettingInAndScenario(
            String workStreamId, List<String> subWorkStreamIds, List<String> costSettings, String scenario);

    List<SubWorkstreamFinDetailsEntity> findAllByWorkstreamIdAndSubWorkstreamIdInAndScenarioAndCostTypeDetailIsContaining(
            String workStreamId, List<String> subWorkStreamIds, String scenario, String costTypeDetailActual);

    Integer deleteAllByWorkstreamIdAndSubWorkstreamIdAndScenario(
            String workStreamId, String subWorkStreamId, String scenario);

    Integer deleteAllByWorkstreamIdAndSubWorkstreamIdAndCostSettingInAndScenarioIn(
            String workStreamId, String subWorkStreamId, List<String> costSettings, List<String> scenarios);

    Integer deleteAllByWorkstreamIdAndSubWorkstreamIdAndScenarioInAndCostTypeDetailIsContaining(
            String workStreamId, String subWorkStreamId, List<String> scenarios, String costTypeDetailActual);


    List<SubWorkstreamFinDetailsEntity>
    findByScenarioAndWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndOrgInd(
            String scenario, String workStreamId, String subWorkStreamId, String subWorkStreamName,
           String orgInd);

    SubWorkstreamFinDetailsEntity findByScenarioAndWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndCostTypeAndGlCategoryAndPeriodAndOrgInd(
            String scenario, String workStreamId, String subWorkStreamId, String subWorkStreamName, String costType,
            String category,String period,String orgInd);

    Integer deleteAllByWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndScenarioAndAndCostTypeAndGlCategoryAndOrgIndAndCostTypeDetailAndAndCostSetting(
            String workStreamId, String subWorkStreamId, String subWorkStreamName, String scenario,  String costType,
            String category, String orgInd, String costTypeDetail,String costSetting);

    @Query(value = "select COALESCE(sum(group_ccy_val),0) from sub_workstream_fin_details where workstream_id= :workStreamId and " +
            "sub_workstream_id= :subWorkStreamId and sub_workstream_name= :subWorkStreamName and scenario= :scenario " +
            "and cost_settings= :costSetting and org_ind='false' and cost_type= :costType and gl_category= :glCategory " +
            "and  period < :period",nativeQuery = true)
    BigDecimal getCostSettingsSumForActualsByGrpCcy(@Param("workStreamId") String workStreamId,
                                                 @Param("subWorkStreamId") String subWorkStreamId,
                                                 @Param("subWorkStreamName") String subWorkStreamName,
                                                 @Param("scenario") String scenario, @Param("costSetting") String costSetting,
                                                 @Param("costType") String costType, @Param("glCategory") String glCategory,
                                                 @Param("period") String period);

    @Query(value = "select COALESCE(sum(local_ccy_val),0) from sub_workstream_fin_details where workstream_id= :workStreamId and " +
            "sub_workstream_id= :subWorkStreamId and sub_workstream_name= :subWorkStreamName and scenario= :scenario " +
            "and cost_settings= :costSetting and org_ind='false' and cost_type= :costType and gl_category= :glCategory " +
            "and  period < :period",nativeQuery = true)
    BigDecimal getCostSettingsSumForActualsByLocalCcy(@Param("workStreamId") String workStreamId,
                                                    @Param("subWorkStreamId") String subWorkStreamId,
                                                    @Param("subWorkStreamName") String subWorkStreamName,
                                                    @Param("scenario") String scenario, @Param("costSetting") String costSetting,
                                                    @Param("costType") String costType, @Param("glCategory") String glCategory,
                                                    @Param("period") String period);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update SubWorkstreamFinDetailsEntity finDetails set finDetails.scenario =:approvalScenario " +
            "where finDetails.scenario=:scenario and finDetails.workstreamId in (:workStreamIds) and  " +
            "finDetails.costSetting in (:costSettings)")
    Integer updateForcastApprovalScenarioForWorkStreamsAndScenario(@Param("workStreamIds") List<String> workStreamIds,
                                                            @Param("scenario") String scenario,
                                                            @Param("approvalScenario") String approvalScenario,
                                                            @Param("costSettings") List<String> costSettings);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update SubWorkstreamFinDetailsEntity finDetails set finDetails.scenario =:approvalScenario " +
            "where finDetails.scenario=:scenario  and finDetails.workstreamId in (:workStreamIds) and " +
            "finDetails.costTypeDetail LIKE :costTypeDetails% ")
    Integer updateActualApprovalScenarioForWorkStreamsAndScenario(@Param("workStreamIds") List<String> workStreamIds,
                                                            @Param("scenario") String scenario,
                                                            @Param("approvalScenario") String approvalScenario,
                                                            @Param("costTypeDetails") String costTypeDetails);
}
