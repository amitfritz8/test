package com.dbs.genesis.portfolio.service.financials;

import com.dbs.genesis.portfolio.common.GeneUtils;
import com.dbs.genesis.portfolio.model.SubWorkstreamOtherCost;
import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.repository.SubWorkstreamOtherCostRepo;
import com.dbs.genesis.portfolio.resources.FinancialSummaryResource;
import com.dbs.genesis.portfolio.resources.UnitCostMappingView;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.resources.UnitCostResource;
import com.google.common.collect.Lists;
import io.vavr.Tuple2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class BreakDownCostOthersService {



    private final SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo;
    private final PortfolioRepository portfolioRepository;

    @Autowired
    public BreakDownCostOthersService(SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo, PortfolioRepository portfolioRepository) {

        this.subWorkstreamOtherCostRepo = subWorkstreamOtherCostRepo;
        this.portfolioRepository= portfolioRepository;

    }

    public List<UnitCostMappingView> getOthersHardwareByMonthly(String subWorkStreamId,
                                                                String subWorkStreamName, String period, String scenario,String currencyCode) {
        List<UnitCostMappingView> costLists = Lists.newArrayList();
        Map<Integer,List<SubWorkstreamOtherCost>>  othersListMap= getSubWorkStreamOtherCostsListByPeriod(subWorkStreamId, subWorkStreamName,
                PortfolioConstants.HARDWARE_TYPE, period,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        othersListMap.forEach((refSurrId, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getRefSwsOtherSurrId());
            unitCostMappingView.setName(PortfolioConstants.OTHER_HARDWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
            populateUnitCostMappingForGivenVendorName(subWorkStreamOtherCostList, unitCostMappingView,currencyCode);
            // unitCostMappingView.setMonthlyResourcesCosts(getOthersMonthlyList(subWorkStreamOtherCostList,currencyCode));
//            unitCostMappingView.setCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
//                    subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId,subWorkStreamName,scenario,PortfolioConstants.HARDWARE_TYPE)
//                    :subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId,subWorkStreamName,scenario,PortfolioConstants.HARDWARE_TYPE));
            Tuple2<BigDecimal,BigDecimal> bigDecimalTuple2 = getUnitCostOverAllTotal(subWorkStreamId,subWorkStreamName,subWorkStreamOtherCostList.get(0).getVendorName(),scenario,currencyCode);
            unitCostMappingView.setYearlyCostOverAllTotal(bigDecimalTuple2._1);
            unitCostMappingView.setYearlyUnitOverAllTotal(null);
            costLists.add(unitCostMappingView);
        });
        return costLists;
    }

    public List<UnitCostMappingView> getOthersHardwareByQuarterly(String subWorkStreamId, String subWorkStreamName,String year,String scenario, String currencyCode) {

        List<UnitCostMappingView> costMappingViewList = Lists.newArrayList();
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        Map<Integer, List<SubWorkstreamOtherCost>> othersListByRefSurrIdByVendorName = getSubWorkStreamOtherCostsListByPeriod(
                subWorkStreamId, subWorkStreamName, PortfolioConstants.HARDWARE_TYPE, year,scenario).stream().collect(
                Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        othersListByRefSurrIdByVendorName.forEach((refSurrId, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setName(PortfolioConstants.OTHER_HARDWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.QUARTERLY);
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
            List<BigDecimal> othersQuarterlyList = getOthersQuarterlyList(subWorkStreamOtherCostList, currencyCode);
            unitCostMappingView.setQuarterlyCostTotal(othersQuarterlyList);
            unitCostMappingView.setQuarterlyUnitTotal(null);
            unitCostMappingView.setYearlyCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.HARDWARE_TYPE, glCategories)
                    : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.HARDWARE_TYPE, glCategories));
            costMappingViewList.add(unitCostMappingView);
        });
        return costMappingViewList;
    }

    public List<UnitCostMappingView> getOthersHardwareByYearly(String subWorkStreamId, String subWorkStreamName, String year, String scenario, String currencyCode) {

        List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        Map<Integer,List<SubWorkstreamOtherCost>> subWorkStreamOthersListMap = getSubWorkStreamOtherCostsListByPeriod(subWorkStreamId,
                subWorkStreamName, PortfolioConstants.HARDWARE_TYPE, year,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        subWorkStreamOthersListMap.forEach((integer, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setName(PortfolioConstants.OTHER_HARDWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            //TODO set currencytype, currencyvalue
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
            BigDecimal yearlyTotal = BigDecimal.ZERO;
            for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkStreamOtherCostList) {
                yearlyTotal = yearlyTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCost.getGroupCcyVal() : subWorkstreamOtherCost.getLocalCcyVal());
            }

            unitCostMappingView.addYearlyCostTotal(yearlyTotal);
            unitCostMappingView.setYearlyUnitTotal(null);
            //  unitCostMappingView.addYearlyUnitTotal(yearlyTotal);
            unitCostMappingView.setYearlyCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId, subWorkStreamName,
                            scenario, PortfolioConstants.HARDWARE_TYPE, glCategories) : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId, subWorkStreamName,
                    scenario, PortfolioConstants.HARDWARE_TYPE, glCategories));
            unitCostMappingViewArrayList.add(unitCostMappingView);
        });
        return unitCostMappingViewArrayList;
    }


    private List<UnitCostResource>
    getOthersMonthlyList(List<SubWorkstreamOtherCost> subWorkStreamOtherHardwareList, String currencyCode) {
        return subWorkStreamOtherHardwareList.stream().map(subWorkStreamOtherCost -> {
            String reportingMonth = subWorkStreamOtherCost.getPeriod().substring(4, 6);
            //int monthNumber = Integer.parseInt(reportingMonth) - 1;
            UnitCostResource unitResource = new UnitCostResource();
            unitResource.setSurrId(subWorkStreamOtherCost.getSwsOtherSurrId());
            unitResource.setMonthNumber(reportingMonth);
            unitResource.setValue(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkStreamOtherCost.getGroupCcyVal():subWorkStreamOtherCost.getLocalCcyVal());
            return unitResource;
        }).collect(Collectors.toList());
    }

    public  List<SubWorkstreamOtherCost> getSubWorkStreamOtherCostsListByPeriod(String subWorkStreamId, String subWorkStreamName,String type,
                                                                                String period,String scenario) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        return subWorkstreamOtherCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndGlCategoryNotInAndPeriodContaining(
                        subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, type,PortfolioConstants.FALSE,glCategories, period);
    }

    private Map<String, List<SubWorkstreamOtherCost>> getSubWorkStreamOthersMap(String subWorkStreamId, String subWorkStreamName, String type,
                                                                                String period, String scenario) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        return subWorkstreamOtherCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndGlCategoryNotInAndPeriodContaining(
                        subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, type,PortfolioConstants.FALSE, glCategories,period).
                stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getVendorName));
    }


    public List<UnitCostMappingView> getOtherSoftwareByMonthly(String subWorkStreamId, String subWorkStreamName,
                                                               String period,String scenario, String currencyCode) {
        List<UnitCostMappingView> costLists = Lists.newArrayList();
        Map<Integer,List<SubWorkstreamOtherCost>>  othersListMap= getSubWorkStreamOtherCostsListByPeriod(subWorkStreamId, subWorkStreamName,
                PortfolioConstants.SOFTWARE_TYPE, period,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        othersListMap.forEach((refSurrId, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getRefSwsOtherSurrId());
            unitCostMappingView.setName(PortfolioConstants.OTHER_SOFTWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
            populateUnitCostMappingForGivenVendorName(subWorkStreamOtherCostList, unitCostMappingView,currencyCode);
//            unitCostMappingView.setMonthlyResourcesCosts(getOthersMonthlyList(subWorkStreamOtherCostList,currencyCode));
//            unitCostMappingView.setCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
//                    subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId,subWorkStreamName,scenario,PortfolioConstants.SOFTWARE_TYPE)
//                    : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId,subWorkStreamName,scenario,PortfolioConstants.SOFTWARE_TYPE));
            Tuple2<BigDecimal,BigDecimal> bigDecimalTuple2 = getUnitCostOverAllTotal(subWorkStreamId,subWorkStreamName,subWorkStreamOtherCostList.get(0).getVendorName(),scenario,currencyCode);
            unitCostMappingView.setYearlyCostOverAllTotal(bigDecimalTuple2._1);
            unitCostMappingView.setYearlyUnitOverAllTotal(null);
            costLists.add(unitCostMappingView);
        });

        return costLists;
    }

    public List<UnitCostMappingView> getOtherResourceByMonthly(String subWorkStreamId, String subWorkStreamName,
                                                               String period,String scenario, String currencyCode) {
        List<UnitCostMappingView> costLists = Lists.newArrayList();
        Map<Integer,List<SubWorkstreamOtherCost>>  othersListMap= getSubWorkStreamOtherCostsListByPeriod(subWorkStreamId, subWorkStreamName,
                PortfolioConstants.RESOURCE_TYPE, period,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        othersListMap.forEach((refSurrId, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getRefSwsOtherSurrId());
            unitCostMappingView.setName(PortfolioConstants.OTHER_RESOURCE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
            populateUnitCostMappingForGivenVendorName(subWorkStreamOtherCostList, unitCostMappingView,currencyCode);
//            unitCostMappingView.setMonthlyResourcesCosts(getOthersMonthlyList(subWorkStreamOtherCostList,currencyCode));
//            unitCostMappingView.setCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
//                    subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId,subWorkStreamName,scenario,PortfolioConstants.SOFTWARE_TYPE)
//                    : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId,subWorkStreamName,scenario,PortfolioConstants.SOFTWARE_TYPE));
            Tuple2<BigDecimal,BigDecimal> bigDecimalTuple2 = getUnitCostOverAllTotal(subWorkStreamId,subWorkStreamName,subWorkStreamOtherCostList.get(0).getVendorName(),scenario,currencyCode);
            unitCostMappingView.setYearlyCostOverAllTotal(bigDecimalTuple2._1);
            unitCostMappingView.setCostOverAllTotal(bigDecimalTuple2._1);
            unitCostMappingView.setYearlyUnitOverAllTotal(null);
            costLists.add(unitCostMappingView);
        });

        return costLists;
    }

    public List<UnitCostMappingView> getOtherSoftwareByQuarterly(String subWorkStreamId, String subWorkStreamName,String year,String scenario,String currencyCode) {

        List<UnitCostMappingView> costMappingViewList = Lists.newArrayList();
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        Map<Integer, List<SubWorkstreamOtherCost>> othersListByRefSurrIdByVendorName = getSubWorkStreamOtherCostsListByPeriod(
                subWorkStreamId, subWorkStreamName, PortfolioConstants.SOFTWARE_TYPE, year,scenario).stream().collect(
                Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        othersListByRefSurrIdByVendorName.forEach((refSurrId, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setName(PortfolioConstants.OTHER_SOFTWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.QUARTERLY);
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
            List<BigDecimal> othersQuarterlyList = getOthersQuarterlyList(subWorkStreamOtherCostList,currencyCode);
            unitCostMappingView.setQuarterlyCostTotal(othersQuarterlyList);
            unitCostMappingView.setQuarterlyUnitTotal(null);
            unitCostMappingView.setYearlyCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.SOFTWARE_TYPE, glCategories)
                    : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.SOFTWARE_TYPE, glCategories));
            costMappingViewList.add(unitCostMappingView);
        });
        return costMappingViewList;
    }

    public List<UnitCostMappingView> getOtherResourceByQuarterly(String subWorkStreamId, String subWorkStreamName,String year,String scenario,String currencyCode) {

        List<UnitCostMappingView> costMappingViewList = Lists.newArrayList();
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        Map<Integer, List<SubWorkstreamOtherCost>> othersListByRefSurrIdByVendorName = getSubWorkStreamOtherCostsListByPeriod(
                subWorkStreamId, subWorkStreamName, PortfolioConstants.RESOURCE_TYPE, year,scenario).stream().collect(
                Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        othersListByRefSurrIdByVendorName.forEach((refSurrId, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setName(PortfolioConstants.OTHER_RESOURCE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.QUARTERLY);
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
            List<BigDecimal> othersQuarterlyList = getOthersQuarterlyList(subWorkStreamOtherCostList,currencyCode);
            unitCostMappingView.setQuarterlyCostTotal(othersQuarterlyList);
            unitCostMappingView.setQuarterlyUnitTotal(null);
            unitCostMappingView.setYearlyCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.RESOURCE_TYPE, glCategories)
                    : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.RESOURCE_TYPE, glCategories));
            costMappingViewList.add(unitCostMappingView);
        });
        return costMappingViewList;
    }

    private List<BigDecimal> getOthersQuarterlyList(List<SubWorkstreamOtherCost> subWorkStreamOtherCostList, String currencyCode) {

        BigDecimal firstQuarterCost = BigDecimal.ZERO;
        BigDecimal secondQuarterCost = BigDecimal.ZERO;
        BigDecimal thirdQuarterCost = BigDecimal.ZERO;
        BigDecimal fourthQuarterCost = BigDecimal.ZERO;

        for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkStreamOtherCostList) {
            String reportingMonth = subWorkstreamOtherCost.getPeriod().substring(4, 6);
            if(PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                firstQuarterCost = firstQuarterCost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCost.getGroupCcyVal() : subWorkstreamOtherCost.getLocalCcyVal());
            }
            if(PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                secondQuarterCost = secondQuarterCost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCost.getGroupCcyVal() : subWorkstreamOtherCost.getLocalCcyVal());
            }
            if(PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                thirdQuarterCost = thirdQuarterCost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCost.getGroupCcyVal() : subWorkstreamOtherCost.getLocalCcyVal());
            }
            if(PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                fourthQuarterCost = fourthQuarterCost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCost.getGroupCcyVal() : subWorkstreamOtherCost.getLocalCcyVal());
            }
        }
        return  Arrays.asList(firstQuarterCost,secondQuarterCost,thirdQuarterCost,fourthQuarterCost);
    }

    public List<UnitCostMappingView> getOthersSoftwareByYearly(String subWorkStreamId, String subWorkStreamName, String year, String scenario,String currencyCode) {

        List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        Map<Integer,List<SubWorkstreamOtherCost>> subWorkStreamOthersListMap = getSubWorkStreamOtherCostsListByPeriod(subWorkStreamId,
                subWorkStreamName, PortfolioConstants.SOFTWARE_TYPE, year,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        subWorkStreamOthersListMap.forEach((integer, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setName(PortfolioConstants.OTHER_SOFTWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            //TODO set currencytype, currencyvalue
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
            unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
            BigDecimal yearlyTotal = BigDecimal.ZERO;
            for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkStreamOtherCostList) {
                yearlyTotal = yearlyTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)
                        ? subWorkstreamOtherCost.getGroupCcyVal():subWorkstreamOtherCost.getLocalCcyVal());
            }

            unitCostMappingView.addYearlyCostTotal(yearlyTotal);
            unitCostMappingView.setYearlyUnitTotal(null);

            //unitCostMappingView.addYearlyUnitTotal(null);
            unitCostMappingView.setYearlyCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.SOFTWARE_TYPE, glCategories)
                    : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.SOFTWARE_TYPE, glCategories));
            unitCostMappingViewArrayList.add(unitCostMappingView);
        });
        return unitCostMappingViewArrayList;
    }

    public List<UnitCostMappingView> getOthersResourceByYearly(String subWorkStreamId, String subWorkStreamName, String year, String scenario,String currencyCode) {

        List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
        Map<Integer,List<SubWorkstreamOtherCost>> subWorkStreamOthersListMap = getSubWorkStreamOtherCostsListByPeriod(subWorkStreamId,
                subWorkStreamName, PortfolioConstants.RESOURCE_TYPE, year,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getRefSwsOtherSurrId));
        subWorkStreamOthersListMap.forEach((integer, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setName(PortfolioConstants.OTHER_RESOURCE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
            BigDecimal yearlyTotal = BigDecimal.ZERO;
            for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkStreamOtherCostList) {
                yearlyTotal = yearlyTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)
                        ? subWorkstreamOtherCost.getGroupCcyVal():subWorkstreamOtherCost.getLocalCcyVal());
            }

            unitCostMappingView.addYearlyCostTotal(yearlyTotal);
            unitCostMappingView.setYearlyUnitTotal(null);

            //unitCostMappingView.addYearlyUnitTotal(null);
            unitCostMappingView.setYearlyCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.RESOURCE_TYPE, GeneUtils.getGlCategoriesNotInclude())
                    : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.RESOURCE_TYPE, GeneUtils.getGlCategoriesNotInclude()));
            unitCostMappingViewArrayList.add(unitCostMappingView);
        });
        return unitCostMappingViewArrayList;
    }



    //others start
    public List<UnitCostMappingView> getOthersByMonthly(String subWorkStreamId, String subWorkStreamName, String period,String scenario, String currencyCode) {

        List<UnitCostMappingView> costLists = Lists.newArrayList();

        Map<String,List<SubWorkstreamOtherCost>>  othersListMap= getSubWorkStreamOthersMap(subWorkStreamId, subWorkStreamName,
                PortfolioConstants.OTHERS_TYPE, period,scenario);

        othersListMap.forEach((vendorName, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getRefSwsOtherSurrId());
            unitCostMappingView.setName(vendorName);
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
            populateUnitCostMappingForGivenVendorName(subWorkStreamOtherCostList, unitCostMappingView,currencyCode);
            //  unitCostMappingView.setMonthlyResourcesCosts(getOthersMonthlyList(subWorkStreamOtherCostList,currencyCode));
//                unitCostMappingView.setCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
//                        subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId,subWorkStreamName,scenario,PortfolioConstants.OTHERS_TYPE)
//                        : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId,subWorkStreamName,scenario,PortfolioConstants.OTHERS_TYPE));
            Tuple2<BigDecimal,BigDecimal> bigDecimalTuple2 = getUnitCostOverAllTotal(subWorkStreamId,subWorkStreamName,vendorName,scenario,currencyCode);
            unitCostMappingView.setYearlyCostOverAllTotal(bigDecimalTuple2._1);
            unitCostMappingView.setYearlyUnitOverAllTotal(null);
            costLists.add(unitCostMappingView);
        });

        return costLists;
    }

    private Tuple2<BigDecimal,BigDecimal> getUnitCostOverAllTotal(String subWorkStreamId, String subWorkStreamName, String vendorName,String scenario, String currencyCode) {
        List<SubWorkstreamOtherCost> subWorkstreamOtherCostList = subWorkstreamOtherCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndVendorNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotIn(subWorkStreamId,
                        subWorkStreamName, vendorName, scenario, PortfolioConstants.TRUE,PortfolioConstants.FALSE, GeneUtils.getGlCategoriesNotInclude());

        BigDecimal costOverAllTotal = BigDecimal.ZERO;
        BigDecimal unitOverAllTotal = BigDecimal.ZERO;
        for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkstreamOtherCostList) {
            costOverAllTotal = costOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamOtherCost.getGroupCcyVal() : subWorkstreamOtherCost.getLocalCcyVal());
            unitOverAllTotal = unitOverAllTotal.add(subWorkstreamOtherCost.getQuantity());
        }
        return new Tuple2<>(costOverAllTotal,unitOverAllTotal);
    }

    UnitCostMappingView populateUnitCostMappingForGivenVendorName(
            List<SubWorkstreamOtherCost> softwarePeriodList,
            UnitCostMappingView unitCostMappingView,String currencyCode) {

        List<UnitCostResource> costResourceList = Lists.newLinkedList();
        //List<UnitCostResource> unitResourceList = Lists.newLinkedList();

        BigDecimal unitOverAllTotal = BigDecimal.ZERO;
        BigDecimal costOverAllTotal = BigDecimal.ZERO;


        for (SubWorkstreamOtherCost subWorkstreamOtherCost : softwarePeriodList) {
            String reportingMonth = subWorkstreamOtherCost.getPeriod().substring(4, 6);
            UnitCostResource costResource = new UnitCostResource();
            BigDecimal costPerMonth = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamOtherCost.getGroupCcyVal():subWorkstreamOtherCost.getLocalCcyVal();
            BigDecimal quantity = subWorkstreamOtherCost.getQuantity();
            costResource.setSurrId(subWorkstreamOtherCost.getSwsOtherSurrId());
            costResource.setMonthNumber(reportingMonth);
            costResource.setValue(costPerMonth);
            costResource.setGlCategory(subWorkstreamOtherCost.getGlCategory());
            costResourceList.add(costResource);

            unitOverAllTotal = unitOverAllTotal.add(quantity);
            costOverAllTotal = costOverAllTotal.add(costPerMonth);
        }

        costResourceList = costResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(costResourceList) : costResourceList;
        costResourceList.sort(Comparator.comparing(UnitCostResource::getNumericMonthNumber));
        unitCostMappingView.setMonthlyResourcesCosts(costResourceList);
        unitCostMappingView.setUnitOverAllTotal(null);
        unitCostMappingView.setCostOverAllTotal(costOverAllTotal);
        return unitCostMappingView;
    }

    private List<UnitCostResource> getUnitAndCostResourceMonthlyList( List<UnitCostResource> unitAndCostResourceList){
        List<UnitCostResource> unitAndcostResourceMonthlyList = Lists.newLinkedList();
        if(unitAndCostResourceList.size() < 12) {
            for (int i = 1; i <= 12; i++) {
                UnitCostResource costResource = new UnitCostResource();
                costResource.setSurrId(0);
                costResource.setMonthNumber(i <= 9 ? "0" + i : String.valueOf(i));
                costResource.setValue(BigDecimal.ZERO);
                unitAndcostResourceMonthlyList.add(costResource);
            }
            for (int i = 0; i < unitAndcostResourceMonthlyList.size() ; i++) {
                for (int j = 0; j < unitAndCostResourceList.size(); j++) {
                    if(unitAndcostResourceMonthlyList.get(i).getMonthNumber().equalsIgnoreCase(unitAndCostResourceList.get(j).getMonthNumber())){
                        unitAndcostResourceMonthlyList.set(i,unitAndCostResourceList.get(j));
                        break;
                    }
                }
            }
        }
        return unitAndcostResourceMonthlyList;
    }

    public List<BigDecimal> getOthersHeaderByMonthly(String subWorkStreamId, String subWorkStreamName, String period,String scenario, String currencyCode) {
        List<FinancialSummaryResource> consolidatedFinancialSummary =
                PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        portfolioRepository.getSubworkstreamOtherHeaderRowByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, period, scenario,
                                "financialOtherHeaderSummaryByPeriodAndGroupCcy", PortfolioConstants.OTHERS)
                        : portfolioRepository.getSubworkstreamOtherHeaderRowByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, period, scenario,
                        "financialOtherHeaderSummaryByPeriodAndLocalCcy", PortfolioConstants.OTHERS);

        BigDecimal[] costValues = new BigDecimal[12];
        Arrays.fill(costValues, BigDecimal.ZERO);

        for (FinancialSummaryResource summaryResource : consolidatedFinancialSummary) {
            String reportingMonth = summaryResource.getPeriod().substring(4, 6);
            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                costValues[Integer.parseInt(reportingMonth) - 1] = summaryResource.getCurrencyValue();
            }
        }

        return Collections.unmodifiableList(Arrays.asList(costValues));
    }

    public BigDecimal getOthersHeaderTotal(String subWorkStreamId, String subWorkStreamName,String scenario, String currencyCode) {

        BigDecimal overAllTotal = BigDecimal.ZERO;

        List<SubWorkstreamOtherCost> subWorkStreamOtherCostList = getSubWorkStreamOtherCostsList(subWorkStreamId, subWorkStreamName,scenario);

        for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkStreamOtherCostList) {
            overAllTotal = overAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    subWorkstreamOtherCost.getGroupCcyVal() : subWorkstreamOtherCost.getLocalCcyVal());
        }
        return overAllTotal;
    }

    private List<SubWorkstreamOtherCost> getSubWorkStreamOtherCostsList(String subWorkStreamId, String subWorkStreamName,String scenario) {
        return subWorkstreamOtherCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndType(
                subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, PortfolioConstants.FALSE, PortfolioConstants.OTHERS_TYPE);
    }


    public Map<String, List<UnitCostMappingView>> getOthersByQuarterlyTotalSum(String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode) {

        Map<String,List<UnitCostMappingView>> quarterlyMap = new TreeMap<>();
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        List<String> listOfDistinctYears = subWorkstreamOtherCostRepo.findDistinctOfYears(subWorkStreamId,subWorkStreamName, scenario,PortfolioConstants.OTHERS_TYPE);
        listOfDistinctYears.stream().forEach(year -> {
            List<UnitCostMappingView> costMappingViewList = Lists.newArrayList();

            Map<Integer, List<SubWorkstreamOtherCost>> othersListByRefSurrIdByVendorName = getSubWorkStreamOtherCostsListByPeriod(
                    subWorkStreamId, subWorkStreamName, PortfolioConstants.OTHERS_TYPE, year,scenario).stream().collect(
                    Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));

            othersListByRefSurrIdByVendorName.forEach((refSurrId, subWorkStreamOtherCostList) -> {
                UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
                unitCostMappingView.setName(subWorkStreamOtherCostList.get(0).getVendorName());
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
                unitCostMappingView.setPeriodType(PortfolioConstants.QUARTERLY);
                unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
                List<BigDecimal> othersQuarterlyList = getOthersQuarterlyList(subWorkStreamOtherCostList, currencyCode);
                unitCostMappingView.setQuarterlyCostTotal(othersQuarterlyList);
                unitCostMappingView.setYearlyCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.OTHERS_TYPE,glCategories)
                        : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.OTHERS_TYPE, glCategories));
                costMappingViewList.add(unitCostMappingView);
            });
            quarterlyMap.put(year, costMappingViewList);

        });
        return quarterlyMap;
    }

    public Map<String, List<BigDecimal>> getOthersHeaderDataByQuarterly(String subWorkStreamId, String subWorkStreamName,String scenario,String currencyCode) {
        Map<String, List<BigDecimal>> quarterlySum = new TreeMap<>();
        List<FinancialSummaryResource> distinctOfPeriods = portfolioRepository.getSubworkstreamCostTypeOverAllTotalByGroupCurrency(subWorkStreamId, subWorkStreamName, scenario,
                "getDistinctfinancialOthersCostTypeOverAllTotal",PortfolioConstants.OTHERS_TYPE);
        List<BigDecimal> quarterlySummaryList;
        for (FinancialSummaryResource financialSummaryResource : distinctOfPeriods) {
            List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            portfolioRepository.getSubworkstreamOtherHeaderRowByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, financialSummaryResource.getPeriod(), scenario,
                                    "financialOtherHeaderSummaryByPeriodAndGroupCcy", PortfolioConstants.OTHERS)
                            : portfolioRepository.getSubworkstreamOtherHeaderRowByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, financialSummaryResource.getPeriod(), scenario,
                            "financialOtherHeaderSummaryByPeriodAndLocalCcy", PortfolioConstants.OTHERS);
            quarterlySummaryList = getOthersQuarterlyListForHeader(consolidatedFinancialSummary, currencyCode);
            quarterlySum.put(financialSummaryResource.getPeriod(), quarterlySummaryList);
        }
        return quarterlySum;
    }

    private List<BigDecimal> getOthersQuarterlyListForHeader(List<FinancialSummaryResource> consolidatedFinancialSummary, String currencyCode) {

        BigDecimal firstQuarterCost = BigDecimal.ZERO;
        BigDecimal secondQuarterCost = BigDecimal.ZERO;
        BigDecimal thirdQuarterCost = BigDecimal.ZERO;
        BigDecimal fourthQuarterCost = BigDecimal.ZERO;

        for (FinancialSummaryResource subWorkstreamOtherCost : consolidatedFinancialSummary) {
            String reportingMonth = subWorkstreamOtherCost.getPeriod().substring(4, 6);
            if(PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                firstQuarterCost = firstQuarterCost.add(
                        subWorkstreamOtherCost.getCurrencyValue() );
            }
            if(PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                secondQuarterCost = secondQuarterCost.add(
                        subWorkstreamOtherCost.getCurrencyValue());
            }
            if(PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                thirdQuarterCost = thirdQuarterCost.add(
                        subWorkstreamOtherCost.getCurrencyValue());
            }
            if(PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                fourthQuarterCost = fourthQuarterCost.add(
                        subWorkstreamOtherCost.getCurrencyValue());
            }
        }
        return  Arrays.asList(firstQuarterCost,secondQuarterCost,thirdQuarterCost,fourthQuarterCost);
    }


    public Map<String, List<UnitCostMappingView>> getYearlyOthersData(String subWorkStreamId, String subWorkStreamName,String scenario,String currencyCode) {

        Map<String, List<UnitCostMappingView>> yearlyCostUnitResource = new TreeMap<>();
        List<String> listOfYears = subWorkstreamOtherCostRepo.findDistinctOfYears(subWorkStreamId, subWorkStreamName,scenario,PortfolioConstants.OTHERS_TYPE);
        for (String year : listOfYears) {
            List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
            Map<Integer,List<SubWorkstreamOtherCost>> subWorkStreamOthersListMap = getSubWorkStreamOtherCostsListByPeriod(subWorkStreamId,
                    subWorkStreamName, PortfolioConstants.OTHERS_TYPE, year,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getRefSwsOtherSurrId));
            subWorkStreamOthersListMap.forEach((integer, subWorkStreamOtherCostList) -> {
                UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
                unitCostMappingView.setName(subWorkStreamOtherCostList.get(0).getVendorName());
                unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
                BigDecimal yearlyTotal = BigDecimal.ZERO;
                for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkStreamOtherCostList) {
                    yearlyTotal = yearlyTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                            subWorkstreamOtherCost.getGroupCcyVal():subWorkstreamOtherCost.getLocalCcyVal());
                }
                unitCostMappingView.setYearlyUnitTotal(null);
                unitCostMappingView.addYearlyCostTotal(yearlyTotal);
                unitCostMappingView.setYearlyCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId,subWorkStreamName, scenario,PortfolioConstants.OTHERS_TYPE, GeneUtils.getGlCategoriesNotInclude())
                        : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId,subWorkStreamName, scenario,PortfolioConstants.OTHERS_TYPE, GeneUtils.getGlCategoriesNotInclude()));
                unitCostMappingViewArrayList.add(unitCostMappingView);
            });
            yearlyCostUnitResource.put(year, unitCostMappingViewArrayList);
        }
        return yearlyCostUnitResource;
    }

    public Map<String, BigDecimal> getYearlySummaryData(String subWorkStreamId, String subWorkStreamName,String scenario,String currencyCode) {

        Map<String, BigDecimal> totalYearSumMap = new TreeMap<>();
        List<FinancialSummaryResource> listOfYears = portfolioRepository.getSubworkstreamCostTypeOverAllTotalByGroupCurrency(subWorkStreamId, subWorkStreamName, scenario,
                "getDistinctfinancialOthersCostTypeOverAllTotal",PortfolioConstants.OTHERS_TYPE);
        for (FinancialSummaryResource financialSummaryResource : listOfYears) {
            BigDecimal totalYearSum = BigDecimal.ZERO;
            List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            portfolioRepository.getSubworkstreamOtherHeaderRowByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, financialSummaryResource.getPeriod(), scenario,
                                    "financialOtherHeaderSummaryByPeriodAndGroupCcy", PortfolioConstants.OTHERS)
                            : portfolioRepository.getSubworkstreamOtherHeaderRowByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, financialSummaryResource.getPeriod(),  scenario,
                            "financialOtherHeaderSummaryByPeriodAndLocalCcy", PortfolioConstants.OTHERS);
            for (FinancialSummaryResource subWorkstreamOtherCost  : consolidatedFinancialSummary) {
                totalYearSum = totalYearSum.add(subWorkstreamOtherCost.getCurrencyValue());
            }
            totalYearSumMap.put(financialSummaryResource.getPeriod(), totalYearSum);
        }
        return totalYearSumMap;
    }


    public BigDecimal[] getOthersSummaryByMonthly(String subWorkStreamId, String subWorkStreamName, String period, String scenario, String type, String currencyCode) {

        Map<String, List<SubWorkstreamOtherCost>> softwareOthersList = getSubWorkStreamOtherCostsListByPeriod(subWorkStreamId,
                subWorkStreamName, type, period, scenario).stream().collect(
                Collectors.groupingBy(SubWorkstreamOtherCost::getPeriod));

        BigDecimal[] othersValuesByPeriod = new BigDecimal[12];
        Arrays.fill(othersValuesByPeriod, BigDecimal.ZERO);

        softwareOthersList.forEach((yearMonth, subWorkStreamOtherCostList) -> {
            BigDecimal individualMonthValue  = BigDecimal.ZERO;
            String reportingMonth = yearMonth.substring(4,6);
            for(SubWorkstreamOtherCost subWorkStreamOtherCost : subWorkStreamOtherCostList) {
                individualMonthValue = individualMonthValue.add(
                        PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                                subWorkStreamOtherCost.getGroupCcyVal() : subWorkStreamOtherCost.getLocalCcyVal());
            }
            othersValuesByPeriod[Integer.parseInt(reportingMonth) - 1] = individualMonthValue;
        });
        return othersValuesByPeriod;
    }

    public BigDecimal getOtherTotalSum(String subWorkStreamId, String subWorkStreamName, String scenario, String type,String currencyCode) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        return  PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                subWorkstreamOtherCostRepo.getSoftwareOthersTotalByGrpCcy(subWorkStreamId,subWorkStreamName,scenario,type, glCategories)
                : subWorkstreamOtherCostRepo.getSoftwareOthersTotalByLocalCcy(subWorkStreamId,subWorkStreamName,scenario,type, glCategories);
    }

    public BigDecimal getOthersByYearlySum(String subWorkStreamId, String subWorkStreamName, String scenario, String year, String type, String currencyCode) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        return  PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                subWorkstreamOtherCostRepo.getOthersTotalByYearAndGrpCcy(subWorkStreamId,subWorkStreamName,scenario,year,type, glCategories)
                : subWorkstreamOtherCostRepo.getOthersTotalByYearAndLocalCcy(subWorkStreamId,subWorkStreamName,scenario,year,type, glCategories);
    }

    public List<BigDecimal> getOthersByQuarterlyTotalSum(String subWorkStreamId, String subWorkStreamName, String scenario, String otherSoftwareType, String year,String currencyCode) {
        List<SubWorkstreamOtherCost> othersListByYear = getSubWorkStreamOtherCostsListByPeriod(subWorkStreamId, subWorkStreamName, otherSoftwareType, year,scenario);
        List<BigDecimal> othersQuarterlyList = getOthersQuarterlyList(othersListByYear, currencyCode);
        return othersQuarterlyList;
    }
}
