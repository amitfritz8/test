package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@ToString
public class GlCategory {
    String name;
    List<BigDecimal> monthlyFinance;
    Map<String,List<BigDecimal>> quarterlyFinance;
    Map<String,BigDecimal> yearlySummary;
    BigDecimal totalSum;
    BigDecimal overAllSum;
    Map<String,BigDecimal> individualYearSummaryForQuarterly;


}
