package com.dbs.genesis.portfolio.service.costsettings;

import com.dbs.genesis.portfolio.common.DateExtensions;
import com.dbs.genesis.portfolio.common.MathExtentions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.mapper.CostSettingHardwareMapper;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.PortfolioRepo;
import com.dbs.genesis.portfolio.repository.SubWorkStreamKeyDatesRepo;
import com.dbs.genesis.portfolio.repository.SubWorkstreamHardwareCostRepo;
import com.dbs.genesis.portfolio.repository.WorkStreamRepo;
import com.dbs.genesis.portfolio.resources.FinancialDetailsResource;
import com.dbs.genesis.portfolio.resources.SubWorkStreamHardwareCostHolder;
import com.dbs.genesis.portfolio.resources.SubWorkStreamHardwareCostResource;
import com.dbs.genesis.portfolio.resources.SubWorkStreamHardwareCostResourceHolder;
import com.dbs.genesis.portfolio.service.SubWorkStreamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class HardwareService implements MathExtentions, DateExtensions {

    @Autowired
    CostSettingHardwareMapper costSettingHardwareMapper;
    @Autowired
    SubWorkstreamHardwareCostRepo subWorkstreamHardwareCostRepo;
    @Autowired
    FinancialDetailsService financialDetailsService;
    @Autowired
    SubWorkStreamService subWorkStreamService;
    @Autowired
    private SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    @Autowired
    private WorkStreamRepo workStreamRepo;
    @Autowired
    private PortfolioRepo portfolioRepo;

    public Map<String, List<List<SubWorkStreamHardwareCostHolder>>>
    processCostSetting(FinancialDetailsResource financialDetailsResource,
                       List<String> currentYearMonthBetweenDates) {
        Map<String, List<List<SubWorkStreamHardwareCostHolder>>> dbOpTypeAndHardwareCostHoldersMap =
                new HashMap<>();
        List<SubWorkStreamHardwareCostResource> createHardwareList = new ArrayList<>();
        List<SubWorkStreamHardwareCostResource> inactiveHardwareList = new ArrayList<>();

        financialDetailsResource.getHardwares().forEach(hardWares -> {
            hardWares.getHardware().stream().filter(SubWorkStreamHardwareCostResource::validate).forEach(hardware -> {
                if (hardware.getSurrId() == null || hardware.getSurrId() == 0) {
                    createHardwareList.add(hardware);
                } else if (hardware.getActiveInd().equals(PortfolioConstants.FALSE)) {
                    inactiveHardwareList.add(hardware);
                } else {
                    inactiveHardwareList.add(hardware);
                    createHardwareList.add(hardware);
                }
            });
        });
        if (createHardwareList.size() > 0) {
            dbOpTypeAndHardwareCostHoldersMap.put(PortfolioConstants.CREATE,
                    convertHardwareResourceToEntityForCreate(financialDetailsResource,
                            createHardwareList, currentYearMonthBetweenDates,
                            PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS));
        }

        if (inactiveHardwareList.size() > 0) {
            List<List<SubWorkStreamHardwareCostHolder>> subWorkStreamHardwareCostHolderBasedOnGLCategories = new ArrayList<>();
            List<SubWorkStreamHardwareCostHolder> subWorkStreamHardwareCostHolders = new ArrayList<>();
            Set<Integer> surrIds = new HashSet<>();
            inactiveHardwareList.forEach(inactiveHardware -> {
                surrIds.add(inactiveHardware.getSurrId());
            });
            List<SubWorkstreamHardwareCost> subWorkStreamHardwareCostsForInactive =
                    subWorkstreamHardwareCostRepo.findAllByParentOrChildIdIn(surrIds, surrIds);
            SubWorkStreamHardwareCostHolder subWorkStreamHardwareCostHolder = new SubWorkStreamHardwareCostHolder();
            subWorkStreamHardwareCostHolder.setSubWorkstreamHardwareCosts(subWorkStreamHardwareCostsForInactive);
            subWorkStreamHardwareCostHolders.add(subWorkStreamHardwareCostHolder);
            subWorkStreamHardwareCostHolderBasedOnGLCategories.add(subWorkStreamHardwareCostHolders);
            dbOpTypeAndHardwareCostHoldersMap.put(PortfolioConstants.INACTIVE, subWorkStreamHardwareCostHolderBasedOnGLCategories);
        }
        return dbOpTypeAndHardwareCostHoldersMap;
    }

    public List<SubWorkStreamHardwareCostResourceHolder> getCostSettingDetails(String workStreamId,
                                                                               String subWorkStreamId,
                                                                               String subWorkStreamName,
                                                                               String scenario,
                                                                               String loggedInUserCurrency) {
        List<SubWorkstreamHardwareCost> subWorkStreamHardwareCosts = new ArrayList<>();
        List<SubWorkstreamHardwareCost> subWorkstreamHardwareCostList = subWorkstreamHardwareCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalInd
                        (subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, PortfolioConstants.TRUE);
        subWorkstreamHardwareCostList.forEach(subWorkStreamSoftwareCost->{
            if(PortfolioConstants.OPEX.equalsIgnoreCase(subWorkStreamSoftwareCost.getGlCategory()) || PortfolioConstants.CAPEX.equalsIgnoreCase(subWorkStreamSoftwareCost.getGlCategory())){
                subWorkStreamHardwareCosts.add(subWorkStreamSoftwareCost);
            }
        });
        List<SubWorkStreamHardwareCostResource> subWorkStreamSoftwareCostResources = costSettingHardwareMapper.
                mapSubWorkStreamHardwareCostEntityToResource(subWorkStreamHardwareCosts, workStreamId,
                        loggedInUserCurrency);
        return costSettingHardwareMapper.getSubWorkStreamHardwareCosts(subWorkStreamSoftwareCostResources);
    }

    private List<List<SubWorkStreamHardwareCostHolder>> convertHardwareResourceToEntityForCreate(FinancialDetailsResource financialDetailsResource,
                                                                                           List<SubWorkStreamHardwareCostResource> createHardwareList,
                                                                                           List<String> currentYearMonthBetweenDates,
                                                                                           String costSettings) {
        List<List<SubWorkStreamHardwareCostHolder>> subWorkStreamHardwareCostHolderBasedOnGLCategories = new ArrayList<>();

        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(financialDetailsResource.getWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamName(), PortfolioConstants.TRUE, financialDetailsResource.getScenario());


        createHardwareList.forEach(hardware -> {
            List<SubWorkStreamHardwareCostHolder> subWorkStreamHardwareCostHolders = new ArrayList<>();
            List<String> glCategories= new ArrayList<>();
            glCategories.add(PortfolioConstants.OPEX);
            glCategories.add(PortfolioConstants.OWNERSHIP);
            for(String glCategory: glCategories) {
                Map<String, Object> dateDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategories(financialDetailsResource.getWorkStreamId(), financialDetailsResource.getSubWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamName(),financialDetailsResource.getScenario(), glCategory, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
                List<String> monthBetweenDates = (List<String>) dateDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);

                SubWorkStreamHardwareCostHolder subWorkStreamHardwareCostHolder = new SubWorkStreamHardwareCostHolder();
                monthBetweenDates.forEach(monthYearDate -> {
                    if (subWorkStreamHardwareCostHolder.getSubWorkstreamHardwareCost() == null) {
                        subWorkStreamHardwareCostHolder.setSubWorkstreamHardwareCost(
                                populateSubWorkstreamHardwareCostForCreate(financialDetailsResource,
                                        monthBetweenDates.size(),
                                        hardware, getCurrentPeriodAsMonthYear(), costSettings, Boolean.TRUE, glCategory ));
                    }
                    subWorkStreamHardwareCostHolder.getSubWorkstreamHardwareCosts().add
                            (populateSubWorkstreamHardwareCostForCreate(financialDetailsResource,
                                    monthBetweenDates.size(),
                                    hardware, monthYearDate, costSettings, Boolean.FALSE, glCategory));
                });
                if(PortfolioConstants.OPEX.equalsIgnoreCase(glCategory)){
                    getCapexAndOpexDefaultMonthsData(financialDetailsResource, hardware,
                            costSettings, PortfolioConstants.OPEX, subWorkStreamHardwareCostHolder);
                }

                if(PortfolioConstants.OWNERSHIP.equalsIgnoreCase(glCategory)) {
                    try {
                        DateFormat formatter = new SimpleDateFormat("yyyyMM");
                        java.util.Date goLiveDate = subWorkStreamKeyDatesEntity.getGoLiveDate();
                        for (SubWorkstreamHardwareCost subWorkStreamHardwareCost: subWorkStreamHardwareCostHolder.getSubWorkstreamHardwareCosts()) {
                            java.util.Date monthYear = formatter.parse(subWorkStreamHardwareCost.getPeriod());
                            if (monthYear.compareTo(goLiveDate) > 0 && "false".equalsIgnoreCase(subWorkStreamHardwareCost.getOriginalInd())) {
                                subWorkStreamHardwareCost.setCostPerMonthGcy(BigDecimal.ZERO);
                                subWorkStreamHardwareCost.setCostPerMonthLcy(BigDecimal.ZERO);
                            }

                        }
                    } catch (Exception e) {
                        log.info("convertHardwareToEntityForCreate date parsing error",e);
                    }
                }
                subWorkStreamHardwareCostHolders.add(subWorkStreamHardwareCostHolder);
            }
            subWorkStreamHardwareCostHolderBasedOnGLCategories.add(subWorkStreamHardwareCostHolders);
        });
        return subWorkStreamHardwareCostHolderBasedOnGLCategories;
    }

    private void getCapexAndOpexDefaultMonthsData(FinancialDetailsResource financialDetailsResource, SubWorkStreamHardwareCostResource hardware,
                                                  String costSettings, String glCategory, SubWorkStreamHardwareCostHolder subWorkStreamHardwareCostHolder){
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(financialDetailsResource.getWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamId(), financialDetailsResource.getSubWorkStreamName(), PortfolioConstants.TRUE,
                        financialDetailsResource.getScenario());
        Map<String, Object> monthDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategories(financialDetailsResource.getWorkStreamId(),
                financialDetailsResource.getSubWorkStreamId(), financialDetailsResource.getSubWorkStreamName(), financialDetailsResource.getScenario(),
                glCategory, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
        List<String> monthBetweenDates = (List<String>) monthDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);
        SubWorkStreamHardwareCostResource hardwareCost = buildSubWorkStreamHardwareCostResource(hardware);

        List<String> monthBetweenDatesCurrentmonthTOStartMonth = getCurrentYearMonthBetweenDatesDefault(getCurrentPeriodAsMonthYear(), monthBetweenDates.get(0));
        monthBetweenDatesCurrentmonthTOStartMonth.remove(monthBetweenDatesCurrentmonthTOStartMonth.size()-1);
        monthBetweenDatesCurrentmonthTOStartMonth.forEach(monthYearDate -> {
            SubWorkstreamHardwareCost subWorkstreamHardwareCost =
            populateSubWorkstreamHardwareCostForCreate(financialDetailsResource,
                    monthBetweenDatesCurrentmonthTOStartMonth.size(),
                    hardwareCost, monthYearDate, costSettings, Boolean.FALSE, glCategory);
            subWorkStreamHardwareCostHolder.getSubWorkstreamHardwareCosts().add(subWorkstreamHardwareCost);
        });
        WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(financialDetailsResource.getWorkStreamId());
        PortfolioEntity portfolioId = portfolioRepo.findByPortfolioId(workStreamEntity.getPortfolioId());
        Date depreStartDate = subWorkStreamKeyDatesEntity.getDepreStartDate();
        if(depreStartDate == null){
            depreStartDate = calculateDepreStartDate(subWorkStreamKeyDatesEntity.getGoLiveDate(),portfolioId.getAgileWaterFall());
        }
        log.info("calculated Depre start date:"+depreStartDate);
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        List<String> monthBetweenDatesEndMonthToDepreStartDatefiveYears = getCurrentYearMonthBetweenDatesDefault(monthBetweenDates.get(monthBetweenDates.size()-1),
                getMonths(df.format(depreStartDate).substring(0, 7), 59).replaceAll("-", ""));
        monthBetweenDatesEndMonthToDepreStartDatefiveYears.remove(0);
        monthBetweenDatesEndMonthToDepreStartDatefiveYears.forEach(monthYearDate -> {
            SubWorkstreamHardwareCost subWorkstreamHardwareCost =
            populateSubWorkstreamHardwareCostForCreate(financialDetailsResource,
                    monthBetweenDatesCurrentmonthTOStartMonth.size(),
                    hardwareCost, monthYearDate, costSettings, Boolean.FALSE, glCategory);
            subWorkStreamHardwareCostHolder.getSubWorkstreamHardwareCosts().add(subWorkstreamHardwareCost);
        });
    }

    private SubWorkStreamHardwareCostResource  buildSubWorkStreamHardwareCostResource(SubWorkStreamHardwareCostResource hardware){
        SubWorkStreamHardwareCostResource hardwareCost= new SubWorkStreamHardwareCostResource();
        hardwareCost.setQty(BigDecimal.ZERO);
        hardwareCost.setItcRate(hardware.getItcRate());
        hardwareCost.setCostPerMonth(BigDecimal.ZERO);
        hardwareCost.setCurrency(hardware.getCurrency());
        hardwareCost.setTower(hardware.getTower());
        hardwareCost.setDriverDetails(hardware.getDriverDetails());
        hardwareCost.setUom(hardware.getUom());
        hardwareCost.setActiveInd(hardware.getActiveInd());
        hardwareCost.setCurrency(hardware.getCurrency());
        return hardwareCost;
    }

    private SubWorkstreamHardwareCost populateSubWorkstreamHardwareCostForCreate
            (FinancialDetailsResource financialDetails,
             int noOfMonths,
             SubWorkStreamHardwareCostResource hardware,
             String currentYearMonth, String costSettings,
             Boolean original, String glCategory) {
        SubWorkstreamHardwareCost subWorkstreamHardwareCost = new SubWorkstreamHardwareCost();
        subWorkstreamHardwareCost.setWorkStreamId(financialDetails.getWorkStreamId());
        subWorkstreamHardwareCost.setSubWorkStreamId(financialDetails.getSubWorkStreamId());
        subWorkstreamHardwareCost.setSubWorkStreamName(financialDetails.getSubWorkStreamName());
        subWorkstreamHardwareCost.setCostSettings(costSettings);
        subWorkstreamHardwareCost.setCostTypeDetail(financialDetails.getScenario());
        subWorkstreamHardwareCost.setTower(hardware.getTower());
        subWorkstreamHardwareCost.setDriverDetail(hardware.getDriverDetails());
        subWorkstreamHardwareCost.setUom(hardware.getUom());
        subWorkstreamHardwareCost.setScenario(financialDetails.getScenario());
        subWorkstreamHardwareCost.setActiveInd(hardware.getActiveInd());
        subWorkstreamHardwareCost.setAddHardware(PortfolioConstants.ADD_HARDWARE_PQ);
        subWorkstreamHardwareCost.setEffectiveStartDate(new Timestamp(financialDetails.getStartDate().getTime()));
        subWorkstreamHardwareCost.setEffectiveEndDate(new Timestamp(financialDetails.getGoLiveDate().getTime()));
        subWorkstreamHardwareCost.setGlCategory(glCategory);
        subWorkstreamHardwareCost.setPeriod(currentYearMonth);
        subWorkstreamHardwareCost.setQuantity(hardware.getQty());
        subWorkstreamHardwareCost.setItcRate(hardware.getItcRate());
        if(original){
            subWorkstreamHardwareCost.setOriginalInd(PortfolioConstants.TRUE);
            subWorkstreamHardwareCost.setHardwareCost(getHardwareCost(noOfMonths, hardware, Boolean.TRUE));
        }else{
            subWorkstreamHardwareCost.setOriginalInd(PortfolioConstants.FALSE);
            subWorkstreamHardwareCost.setHardwareCost(getHardwareCost(noOfMonths, hardware, Boolean.FALSE));
        }
        if(hardware.getItcRate() != null && hardware.getQty() != null) {
            updateCurrencyValuesForHardware(subWorkstreamHardwareCost, hardware.getCurrency(),
                    hardware.getItcRate(), hardware.getQty(), financialDetails);
            //Monthly Split
            if(!original){
                subWorkstreamHardwareCost.setQuantity(hardware.getQty());
                subWorkstreamHardwareCost.setCostPerMonthLcy(subWorkstreamHardwareCost.getCostPerMonthLcy());
                subWorkstreamHardwareCost.setCostPerMonthGcy(subWorkstreamHardwareCost.getCostPerMonthGcy());
            }
        }
        return subWorkstreamHardwareCost;
    }

    public List<SubWorkStreamHardwareCostHolder>
    convertHardwareResourceToEntityForUpdate(FinancialDetailsResource financialDetailsResource,
                                         List<SubWorkStreamHardwareCostResource> updateHardwareList,
                                         List<String> currentYearMonthBetweenDates,
                                         Map<Integer, List<SubWorkstreamHardwareCost>> entitiesPerRefSwsHwSurrId) {

        List<SubWorkStreamHardwareCostHolder> subWorkStreamHardwareCostHolders = new ArrayList<>();
        updateHardwareList.forEach(hardwareCostResource -> {

                SubWorkStreamHardwareCostHolder subWorkStreamHardwareCostHolder = new SubWorkStreamHardwareCostHolder();
                SubWorkstreamHardwareCost subWorkstreamHardwareCost =
                        populateHardwareCostOriginalResourceToEntityForUpdate(hardwareCostResource,
                                financialDetailsResource, currentYearMonthBetweenDates);
                subWorkStreamHardwareCostHolder.setSubWorkstreamHardwareCost(subWorkstreamHardwareCost);
                List<SubWorkstreamHardwareCost> subWorkstreamHardwareCosts = entitiesPerRefSwsHwSurrId.get(hardwareCostResource.getSurrId());
                populateHardwareCostResourceToEntityForUpdate(hardwareCostResource, subWorkstreamHardwareCosts,
                        currentYearMonthBetweenDates.size(), financialDetailsResource);

                subWorkStreamHardwareCostHolder.setSubWorkstreamHardwareCost(subWorkstreamHardwareCost);
                subWorkStreamHardwareCostHolder.setSubWorkstreamHardwareCosts(subWorkstreamHardwareCosts);
                subWorkStreamHardwareCostHolders.add(subWorkStreamHardwareCostHolder);
        });
        return subWorkStreamHardwareCostHolders;
    }

    private SubWorkstreamHardwareCost populateHardwareCostOriginalResourceToEntityForUpdate(
            SubWorkStreamHardwareCostResource hardware
            , FinancialDetailsResource financialDetails, List<String> currentYearMonthBetweenDates){
        SubWorkstreamHardwareCost subWorkstreamHardwareCostDetails = subWorkstreamHardwareCostRepo.findAllBySwsHwSurrId(hardware.getSurrId());
        SubWorkstreamHardwareCost subWorkstreamHardwareCost = new SubWorkstreamHardwareCost();
        subWorkstreamHardwareCost.setSwsHwSurrId(hardware.getSurrId());
        subWorkstreamHardwareCost.setOriginalInd(PortfolioConstants.TRUE);
        subWorkstreamHardwareCost.setWorkStreamId(financialDetails.getWorkStreamId());
        subWorkstreamHardwareCost.setSubWorkStreamId(financialDetails.getSubWorkStreamId());
        subWorkstreamHardwareCost.setSubWorkStreamName(financialDetails.getSubWorkStreamName());
        subWorkstreamHardwareCost.setTower(hardware.getTower());
        subWorkstreamHardwareCost.setDriverDetail(hardware.getDriverDetails());
        subWorkstreamHardwareCost.setUom(hardware.getUom());
        subWorkstreamHardwareCost.setScenario(financialDetails.getScenario());
        subWorkstreamHardwareCost.setActiveInd(hardware.getActiveInd());
        subWorkstreamHardwareCost.setCostSettings(PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
        subWorkstreamHardwareCost.setAddHardware(PortfolioConstants.ADD_HARDWARE_PQ);
        subWorkstreamHardwareCost.setGlCategory(subWorkstreamHardwareCostDetails.getGlCategory());
        subWorkstreamHardwareCost.setEffectiveStartDate(new Timestamp(financialDetails.getStartDate().getTime()));
        subWorkstreamHardwareCost.setEffectiveEndDate(new Timestamp(financialDetails.getGoLiveDate().getTime()));
        subWorkstreamHardwareCost.setHardwareCost(getHardwareCost(currentYearMonthBetweenDates.size(),
                hardware, Boolean.TRUE));
        subWorkstreamHardwareCost.setQuantity(hardware.getQty());
        subWorkstreamHardwareCost.setItcRate(hardware.getItcRate());
        subWorkstreamHardwareCost.setPeriod(getCurrentPeriodAsMonthYear());
        if(hardware.getItcRate() != null && hardware.getQty() != null) {
            updateCurrencyValuesForHardware(subWorkstreamHardwareCost, hardware.getCurrency(),
                    hardware.getItcRate(), hardware.getQty(), financialDetails);
        }
        return subWorkstreamHardwareCost;
    }

    private void populateHardwareCostResourceToEntityForUpdate(SubWorkStreamHardwareCostResource hardware,
                                                               List<SubWorkstreamHardwareCost> subWorkstreamHardwareCosts,
                                                               int noOfMonths,
                                                               FinancialDetailsResource financialDetails) {
        subWorkstreamHardwareCosts.forEach(subWorkstreamHardwareCost -> {
            subWorkstreamHardwareCost.setWorkStreamId(financialDetails.getWorkStreamId());
            subWorkstreamHardwareCost.setSubWorkStreamId(financialDetails.getSubWorkStreamId());
            subWorkstreamHardwareCost.setSubWorkStreamName(financialDetails.getSubWorkStreamName());
            subWorkstreamHardwareCost.setOriginalInd(PortfolioConstants.FALSE);
            subWorkstreamHardwareCost.setScenario(financialDetails.getScenario());
            subWorkstreamHardwareCost.setTower(hardware.getTower());
            subWorkstreamHardwareCost.setDriverDetail(hardware.getDriverDetails());
            subWorkstreamHardwareCost.setUom(hardware.getUom());
            subWorkstreamHardwareCost.setActiveInd(hardware.getActiveInd());
            subWorkstreamHardwareCost.setAddHardware(PortfolioConstants.ADD_HARDWARE_PQ);
            subWorkstreamHardwareCost.setGlCategory(subWorkstreamHardwareCost.getGlCategory());
            subWorkstreamHardwareCost.setEffectiveStartDate(new Timestamp(financialDetails.getStartDate().getTime()));
            subWorkstreamHardwareCost.setEffectiveEndDate(new Timestamp(financialDetails.getGoLiveDate().getTime()));
            subWorkstreamHardwareCost.setItcRate(hardware.getItcRate());
            subWorkstreamHardwareCost.setHardwareCost(getHardwareCost(noOfMonths,
                    hardware, Boolean.FALSE));
            if(hardware.getItcRate() != null && hardware.getQty() != null) {
                updateCurrencyValuesForHardware(subWorkstreamHardwareCost, hardware.getCurrency(),
                        hardware.getItcRate(), hardware.getQty(), financialDetails);
                //Monthly Split
                subWorkstreamHardwareCost.setQuantity(hardware.getQty());
                subWorkstreamHardwareCost.setCostPerMonthLcy(subWorkstreamHardwareCost.getCostPerMonthLcy());
                subWorkstreamHardwareCost.setCostPerMonthGcy(subWorkstreamHardwareCost.getCostPerMonthGcy());
            }
        });
    }

    private BigDecimal getHardwareCost(int noOfMonths,
                                       SubWorkStreamHardwareCostResource hardware, Boolean original) {
        if (hardware.getQty() == null || hardware.getItcRate() == null) return null;
        if(original){
            return hardware.getItcRate().multiply(hardware.getQty());
        }
        return hardware.getItcRate().multiply(hardware.getQty());
    }

    private void updateCurrencyValuesForHardware(SubWorkstreamHardwareCost subWorkStreamHoftwareCost,
                                                 String loggedInCurrencyCode, BigDecimal itcRate,
                                                 BigDecimal quantity, FinancialDetailsResource financialDetails){
        if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(loggedInCurrencyCode)) {
            subWorkStreamHoftwareCost.setLocalCcy(loggedInCurrencyCode);
            subWorkStreamHoftwareCost.setCostPerMonthLcy(quantity.multiply(itcRate));
            subWorkStreamHoftwareCost.setGroupCcy(loggedInCurrencyCode);
            subWorkStreamHoftwareCost.setCostPerMonthGcy(quantity.multiply(itcRate));

        }else{
            subWorkStreamHoftwareCost.setLocalCcy(loggedInCurrencyCode);
            subWorkStreamHoftwareCost.setCostPerMonthLcy(quantity.multiply(itcRate));
            subWorkStreamHoftwareCost.setGroupCcy(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD);
            subWorkStreamHoftwareCost.setCostPerMonthGcy((itcRate.multiply(quantity)).multiply(
                    financialDetailsService.getExchangeRatesEntity(subWorkStreamHoftwareCost.getPeriod(),
                            loggedInCurrencyCode, financialDetails.getWorkStreamId()).getRateValue()));
        }
    }

}
