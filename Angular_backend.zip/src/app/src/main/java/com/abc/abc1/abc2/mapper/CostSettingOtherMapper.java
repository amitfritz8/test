package com.dbs.genesis.portfolio.mapper;

import com.dbs.genesis.portfolio.common.MathExtentions;
import com.dbs.genesis.portfolio.model.SubWorkstreamOtherCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.service.costsettings.FinancialDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class CostSettingOtherMapper implements MathExtentions {

    @Autowired
    FinancialDetailsService financialDetailsService;

    public List<SubWorkStreamOtherCostResource> mapSubWorkStreamOtherCostEntityToResource(
            List<SubWorkstreamOtherCost> subWorkStreamOtherCosts, String workStreamId, String loggedInUserCurrency){
        List<SubWorkStreamOtherCostResource> subWorkStreamOtherCostResources = new ArrayList<>();
        subWorkStreamOtherCosts.forEach(otherCost->{
            SubWorkStreamOtherCostResource subWorkStreamOtherCostResource = new SubWorkStreamOtherCostResource();
            subWorkStreamOtherCostResource.setSurrId(otherCost.getSwsOtherSurrId());
            subWorkStreamOtherCostResource.setSurrId(otherCost.getSwsOtherSurrId());
            subWorkStreamOtherCostResource.setVendor(otherCost.getVendorName());
            subWorkStreamOtherCostResource.setActiveInd(otherCost.getActiveInd());
            subWorkStreamOtherCostResource.setCapexOrOpex(otherCost.getGlCategory());
            subWorkStreamOtherCostResource.setDescription(otherCost.getOtherDesc());

            convertCurrencyToLoggedInCurrencyForView(subWorkStreamOtherCostResource, loggedInUserCurrency,
                    workStreamId, otherCost);
            subWorkStreamOtherCostResources.add(subWorkStreamOtherCostResource);
        });
        return subWorkStreamOtherCostResources;
    }

    private void convertCurrencyToLoggedInCurrencyForView(
            SubWorkStreamOtherCostResource subWorkStreamOtherCostResource,
            String loggedInUserCurrency, String workStreamId, SubWorkstreamOtherCost otherCost){
        subWorkStreamOtherCostResource.setCurrency(loggedInUserCurrency);
        if(loggedInUserCurrency.equalsIgnoreCase(otherCost.getLocalCcy())) {
            //When loggedInCurrency is same to previous localCurrency
            subWorkStreamOtherCostResource.setCost(otherCost.getLocalCcyVal());
        }else if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(loggedInUserCurrency)){
            //When loggedInCurrency is also SGD
            subWorkStreamOtherCostResource.setCost(otherCost.getLocalCcyVal().multiply(
                    financialDetailsService.getExchangeRatesEntity(otherCost.getPeriod(),
                            otherCost.getLocalCcy(), workStreamId).getRateValue()));
        }else {
            // When loggedInCurrency is different from currnet localCcy/globalCcy in db
            BigDecimal rateValueLocalCcyValToSgd = financialDetailsService.getExchangeRatesEntity(otherCost.getPeriod(),
                    otherCost.getLocalCcy(), workStreamId).getRateValue();
            BigDecimal valueLocalCcyValToSgd = otherCost.getLocalCcyVal().multiply(rateValueLocalCcyValToSgd);
            BigDecimal rateValueLoggedInCurrencyToSgd = financialDetailsService.getExchangeRatesEntity(otherCost.getPeriod(),
                    loggedInUserCurrency, workStreamId).getRateValue();
            BigDecimal convertedValueForLoggedInCurrency = divideWithScaleHalfUp(valueLocalCcyValToSgd, rateValueLoggedInCurrencyToSgd);
            subWorkStreamOtherCostResource.setCost(convertedValueForLoggedInCurrency);
        }
    }
}
