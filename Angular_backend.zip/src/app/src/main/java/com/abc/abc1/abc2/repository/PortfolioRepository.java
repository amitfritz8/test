package com.dbs.genesis.portfolio.repository;


import com.dbs.genesis.portfolio.common.GeneUtils;
import com.dbs.genesis.portfolio.resources.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import java.util.List;
import java.util.Set;

@Slf4j
@Repository
public class PortfolioRepository {

    @PersistenceContext
    private EntityManager entityManager;

    public List<StageWorkdayData> getStageWorkDayData() {
        Query query = entityManager.createNamedQuery("getWorkDayLatestData");
        List<StageWorkdayData> r = query.getResultList();
        return r;
    }

    public List<WorkStreamKeyDatesResource> getListOfPortfolioKeyDates(String portfolioId) {
        Query query = entityManager.createNamedQuery("getPortfolioKeyDatesData");
        query.setParameter("portfolioId", portfolioId);
        List<WorkStreamKeyDatesResource> r = query.getResultList();
        return r;
    }

    public List<WorkStreamKeyDatesResource> getListOfWorkstreamKeyDates(String workStreamId) {
        Query query = entityManager.createNamedQuery("getWorkstreamKeyDatesData");
        query.setParameter("workStreamId", workStreamId);
        List<WorkStreamKeyDatesResource> r = query.getResultList();
        return r;
    }

    public List<SubWorkStreamKeyDatesResource> getListOfSubWorkStreamKeyDates(String subWorkStreamId) {
        Query query = entityManager.createNamedQuery("getSubWorkStreamKeyDatesData");
        query.setParameter("subWorkStreamId", subWorkStreamId);
        List<SubWorkStreamKeyDatesResource> r = query.getResultList();
        return r;
    }

    public String getPortfolioSequence() {
        StoredProcedureQuery query = entityManager.createNamedStoredProcedureQuery("portfolioSequence");
        query.execute();
        String outValue = (String) query.getResultList().get(0);
        log.info("portfolioSequence number is: " + outValue);
        return outValue;
    }

    public String getWorkStreamSequence() {
        StoredProcedureQuery query = entityManager.createNamedStoredProcedureQuery("workStreamSequence");
        query.execute();
        String outValue = (String) query.getResultList().get(0);
        log.info("portfolioSequence number is: " + outValue);
        return outValue;
    }

    public List<FinancialSummaryResource> getFinSummaryGroupByPeriodAndGroupCurrency(String workStreamId, String subWorkStreamId, String
            subWorkStreamName, String year, Set glCategorySet, String orgInd) {

        Query query = entityManager.createNamedQuery("financialGroupSummaryByPeriodAndGroupCcy");
        query.setParameter("workStreamId", workStreamId);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("glCategories", glCategorySet);
        query.setParameter("orgInd", orgInd);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getFinSummaryGroupByPeriodAndLocalCurrency(String workStreamId, String subWorkStreamId, String
            subWorkStreamName, String year, Set glCategorySet, String orgInd) {

        Query query = entityManager.createNamedQuery("financialGroupSummaryByPeriodAndLocalCcy");
        query.setParameter("workStreamId", workStreamId);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("glCategories", glCategorySet);
        query.setParameter("orgInd", orgInd);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getYearlySummaryDataByGroupCurrency(String workStreamId, String subWorkStreamId, String
            subWorkStreamName, String year, Set glCategorySet, String orgInd) {

        Query query = entityManager.createNamedQuery("financialYearlySummaryByGroupCcy");
        query.setParameter("workStreamId", workStreamId);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("glCategories", glCategorySet);
        query.setParameter("orgInd", orgInd);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getYearlySummaryDataByLocalCurrency(String workStreamId, String subWorkStreamId, String
            subWorkStreamName, String year, Set glCategorySet, String orgInd) {

        Query query = entityManager.createNamedQuery("financialYearlySummaryByLocalCcy");
        query.setParameter("workStreamId", workStreamId);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("glCategories", glCategorySet);
        query.setParameter("orgInd", orgInd);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getFinSummaryForCostSettingsByGroupCurrency(String workStreamId, String subWorkStreamId, String
            subWorkStreamName, String year, String costSetting, String scenario, String orgInd) {

        Query query = entityManager.createNamedQuery("financialCostInputByPeriodAndGroupCcy");
        query.setParameter("workStreamId", workStreamId);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("costSetting", costSetting);
        query.setParameter("scenario", scenario);
        query.setParameter("orgInd", orgInd);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getFinSummaryForCostSettingsByLocalCurrency(String workStreamId, String subWorkStreamId, String
            subWorkStreamName, String year, String costSetting, String scenario, String orgInd) {

        Query query = entityManager.createNamedQuery("financialCostInputByPeriodAndLocalCcy");
        query.setParameter("workStreamId", workStreamId);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("costSetting", costSetting);
        query.setParameter("scenario", scenario);
        query.setParameter("orgInd", orgInd);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getYearlySumForCostTypeByGroupCurrency(String workStreamId, String subWorkStreamId, String
            subWorkStreamName, String year, String costSetting, String scenario, String orgInd) {

        Query query = entityManager.createNamedQuery("finYearlySumForCostTypeByGroupCcy");
        query.setParameter("workStreamId", workStreamId);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("costSetting", costSetting);
        query.setParameter("scenario", scenario);
        query.setParameter("orgInd", orgInd);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getYearlySumForCostTypeByLocalCurrency(String workStreamId, String subWorkStreamId, String
            subWorkStreamName, String year, String costSetting, String scenario, String orgInd) {

        Query query = entityManager.createNamedQuery("finYearlySumForCostTypeByLocalCcy");
        query.setParameter("workStreamId", workStreamId);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("costSetting", costSetting);
        query.setParameter("scenario", scenario);
        query.setParameter("orgInd", orgInd);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getConsolidatedFinancialSummaryByPeriodAndGroupCurrency(String subWorkStreamId, String subWorkStreamName, String year, String scenario) {
        List<String> glCategories = getGlCategoriesToExcludeFromFD();
        Query query = entityManager.createNamedQuery("financialHeaderSummaryByPeriodAndGroupCcy");
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("scenario", scenario);
        query.setParameter("glCategories", glCategories);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getConsolidatedFinancialSummaryByPeriodAndLocalCurrency(String subWorkStreamId, String subWorkStreamName, String year, String scenario) {
        List<String> glCategories = getGlCategoriesToExcludeFromFD();
        Query query = entityManager.createNamedQuery("financialHeaderSummaryByPeriodAndLocalCcy");
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("scenario", scenario);
        query.setParameter("glCategories", glCategories);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getConsolidatedFinancialSummaryTotalByGroupCurrency(String subWorkStreamId, String subWorkStreamName, String scenario) {
        List<String> glCategories = getGlCategoriesToExcludeFromFD();
        Query query = entityManager.createNamedQuery("financialHeaderSummaryTotalByGroupCcy");
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("scenario", scenario);
        query.setParameter("glCategories", glCategories);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getConsolidatedFinancialSummaryTotalByLocalCurrency(String subWorkStreamId, String subWorkStreamName, String scenario) {
        List<String> glCategories = getGlCategoriesToExcludeFromFD();
        Query query = entityManager.createNamedQuery("financialHeaderSummaryTotalByLocalCcy");
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("scenario", scenario);
        query.setParameter("glCategories", glCategories);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    /*public List<FinancialSummaryResource> getCostForFinancialCaseSummryByLocalCcy(String subWorkStreamId, String subWorkStreamName, String year, String scenario,Set<String> glCategories) {

        Query  query = entityManager.createNamedQuery("getCostForFinancialCaseSummaryByLocalCcy");
        query.setParameter("glCategories",glCategories);
        query.setParameter("subWorkStreamId",subWorkStreamId);
        query.setParameter("subWorkStreamName",subWorkStreamName);
        query.setParameter("period",year);
        query.setParameter("scenario",scenario);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }*/

    public List<FinancialSummaryResource> getCostForFinancialCaseSummryByLocalCcy(String subWorkStreamId, String subWorkStreamName, String year, String scenario, Set<String> glCategories, Set<String> conditionalGlCategories) {

        Query query = entityManager.createNamedQuery("getCostForFinancialCaseSummaryByLocalCcy");
        query.setParameter("conditionalGlCategories", conditionalGlCategories);
        query.setParameter("glCategories", glCategories);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("scenario", scenario);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    /*public List<FinancialSummaryResource> getCostForFinancialCaseSummryByGroupCcy(String subWorkStreamId, String subWorkStreamName, String year, String scenario,Set<String> glCategories) {

        Query  query = entityManager.createNamedQuery("getCostForFinancialCaseSummaryByGroupCcy");
        query.setParameter("glCategories",glCategories);
        query.setParameter("subWorkStreamId",subWorkStreamId);
        query.setParameter("subWorkStreamName",subWorkStreamName);
        query.setParameter("period",year);
        query.setParameter("scenario",scenario);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }*/

    public List<FinancialSummaryResource> getCostForFinancialCaseSummryByGroupCcy(String subWorkStreamId, String subWorkStreamName, String year, String scenario, Set<String> glCategories, Set<String> conditionalGlCategories) {

        Query query = entityManager.createNamedQuery("getCostForFinancialCaseSummaryByGroupCcy");
        query.setParameter("conditionalGlCategories", conditionalGlCategories);
        query.setParameter("glCategories", glCategories);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("scenario", scenario);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

  /*  public List<FinancialSummaryResource> getCostForFinancialCaseSummryValueByLocalCcy(String subWorkStreamId, String subWorkStreamName, String scenario,Set<String> glCategories) {

        Query  query = entityManager.createNamedQuery("getCostForFinancialCaseSummaryValueByLocalCcy");
        query.setParameter("glCategories",glCategories);
        query.setParameter("subWorkStreamId",subWorkStreamId);
        query.setParameter("subWorkStreamName",subWorkStreamName);
        *//*query.setParameter("period",year);*//*
        query.setParameter("scenario",scenario);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }*/

    public List<FinancialSummaryResource> getCostForFinancialCaseSummryValueByLocalCcy(String subWorkStreamId, String subWorkStreamName, String scenario, Set<String> glCategories, Set<String> conditionalGlCategories) {

        Query query = entityManager.createNamedQuery("getCostForFinancialCaseSummaryValueByLocalCcy");
        query.setParameter("conditionalGlCategories", conditionalGlCategories);
        query.setParameter("glCategories", glCategories);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        /*query.setParameter("period",year);*/
        query.setParameter("scenario", scenario);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    /* public List<FinancialSummaryResource> getCostForFinancialCaseSummryValueByGroupCcy(String subWorkStreamId, String subWorkStreamName, String scenario,Set<String> glCategories) {

         Query  query = entityManager.createNamedQuery("getCostForFinancialCaseSummaryValueByGroupCcy");
         query.setParameter("glCategories",glCategories);
         query.setParameter("subWorkStreamId",subWorkStreamId);
         query.setParameter("subWorkStreamName",subWorkStreamName);
         *//*query.setParameter("period",year);*//*
        query.setParameter("scenario",scenario);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }*/
    public List<FinancialSummaryResource> getCostForFinancialCaseSummryValueByGroupCcy(String subWorkStreamId, String subWorkStreamName, String scenario, Set<String> glCategories, Set<String> conditionalGlCategories) {

        Query query = entityManager.createNamedQuery("getCostForFinancialCaseSummaryValueByGroupCcy");
        query.setParameter("conditionalGlCategories", conditionalGlCategories);
        query.setParameter("glCategories", glCategories);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        /*query.setParameter("period",year);*/
        query.setParameter("scenario", scenario);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<SubWorkStreamIdAndName> getSubWorkStreamIdAndSubWorkStreamNameByWorkStreamId(String workStreamId) {
        Query query = entityManager.createNamedQuery("getSubWorkStreamIdAndSubWorkStreamName");
        query.setParameter("workStreamId", workStreamId);
        List<SubWorkStreamIdAndName> r = query.getResultList();
        return r;
    }

    public void callBackEndFinancialProcedure(String subWorkStreamId, String subWorkStreamName, String rptPeriod, String costComponent) {
        StoredProcedureQuery query = entityManager.createNamedStoredProcedureQuery("sp_sws_backend_fin_details");
        query.setParameter("subwkstream_id", subWorkStreamId);
        query.setParameter("subwkstream_name", subWorkStreamName);
        query.setParameter("rptyear", rptPeriod);
        query.setParameter("cost_component", costComponent);
        query.execute();
    }

    public List<FinancialSummaryResource> getSubworkstreamIndividualHeaderRowByPeriodAndGroupCurrency(String subWorkStreamId, String subWorkStreamName, String year, String scenario,
                                                                                                      String createNamedQueryName, String costType) {
        List<String> glCategories = getGlCategoriesToExcludeFromFD();
        Query query = entityManager.createNamedQuery(createNamedQueryName);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("scenario", scenario);
        query.setParameter("glCategories", glCategories);
//        query.setParameter("costType",costType);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getSubworkstreamIndividualHeaderRowByPeriodAndLocalCurrency(String subWorkStreamId, String subWorkStreamName, String year, String scenario,
                                                                                                      String createNamedQueryName, String costType) {
        List<String> glCategories = getGlCategoriesToExcludeFromFD();
        Query query = entityManager.createNamedQuery(createNamedQueryName);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("scenario", scenario);
        query.setParameter("glCategories", glCategories);
//        query.setParameter(" costType",costType);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getSubworkstreamOtherHeaderRowByPeriodAndGroupCurrency(String subWorkStreamId, String subWorkStreamName, String year, String scenario,
                                                                                                 String createNamedQueryName, String costType) {
        List<String> glCategories = getGlCategoriesToExcludeFromFD();
        Query query = entityManager.createNamedQuery(createNamedQueryName);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("scenario", scenario);
        query.setParameter("costType", costType);
        query.setParameter("glCategories", glCategories);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getSubworkstreamOtherHeaderRowByPeriodAndLocalCurrency(String subWorkStreamId, String subWorkStreamName, String year, String scenario,
                                                                                                 String createNamedQueryName, String costType) {
        List<String> glCategories = getGlCategoriesToExcludeFromFD();
        Query query = entityManager.createNamedQuery(createNamedQueryName);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("scenario", scenario);
        query.setParameter("costType", costType);
        query.setParameter("glCategories", glCategories);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getSubworkstreamCostTypeOverAllTotalByGroupCurrency(String subWorkStreamId, String subWorkStreamName, String scenario,
                                                                                              String createNamedQueryName, String costType) {
        List<String> glCategories = getGlCategoriesToExcludeFromFD();
        Query query = entityManager.createNamedQuery(createNamedQueryName);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("scenario", scenario);
        query.setParameter("costType", costType);
        query.setParameter("glCategories", glCategories);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getSubworkstreamCostTypeOverAllTotalByLocalCurrency(String subWorkStreamId, String subWorkStreamName, String scenario,
                                                                                              String createNamedQueryName, String costType) {
        List<String> glCategories = getGlCategoriesToExcludeFromFD();
        Query query = entityManager.createNamedQuery(createNamedQueryName);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("scenario", scenario);
        query.setParameter("costType", costType);
        query.setParameter("glCategories", glCategories);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }


    public List<FinancialSummaryResource> getSubworkstreamResourceHeaderRowByPeriodAndLocalCurrency(String subWorkStreamId, String subWorkStreamName, String year, String scenario,
                                                                                                    String createNamedQueryName, String costType) {
        List<String> glCategories = getGlCategoriesToExcludeFromFD();
        Query query = entityManager.createNamedQuery(createNamedQueryName);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("scenario", scenario);
        query.setParameter("costType", costType);
        query.setParameter("glCategories", glCategories);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    public List<FinancialSummaryResource> getSubworkstreamResourceHeaderRowByPeriodAndGroupCurrency(String subWorkStreamId, String subWorkStreamName, String year, String scenario,
                                                                                                    String createNamedQueryName, String costType) {
        List<String> glCategories = getGlCategoriesToExcludeFromFD();
        Query query = entityManager.createNamedQuery(createNamedQueryName);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("period", year);
        query.setParameter("scenario", scenario);
        query.setParameter("costType", costType);
        query.setParameter("glCategories", glCategories);
        List<FinancialSummaryResource> r = query.getResultList();
        return r;
    }

    private List<String> getGlCategoriesToExcludeFromFD() {
        return GeneUtils.getGlCategoriesNotInclude();
    }

    public List<StageWorkdayData> getStaffNameAndEmail(String userId) {
        Query query = entityManager.createNamedQuery("getStaffNameAndEmail");
        query.setParameter("userId", userId);
        List<StageWorkdayData> r = query.getResultList();
        return r;
    }

    public List<SubWorkstreamLePccodeResource> getSubWorkStreamLepccodes(String workStreamId, String subWorkStreamId, String subWorkStreamName) {
        Query query = entityManager.createNamedQuery("subWorkStreamLepccodes");
        query.setParameter("workStreamId", workStreamId);
        query.setParameter("subWorkStreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        List<SubWorkstreamLePccodeResource> r = query.getResultList();
        return r;
    }


    public void callSotredProcToRevisePreviousMonthsData(String subWorkStreamId, String subWorkStreamName) {
        log.info("Enter callSotredProcToRevisePreviousMonthsData");
        StoredProcedureQuery namedStoredProcedureQuery = entityManager.createNamedStoredProcedureQuery("updateAllPreviousMonthForecast");
        namedStoredProcedureQuery.setParameter("subworkstream_id", subWorkStreamId);
        namedStoredProcedureQuery.setParameter("subworkstream_name", subWorkStreamName);
        namedStoredProcedureQuery.execute();
        log.info("After callSotredProcToRevisePreviousMonthsData");

    }

    public List<FinancialSummaryResource> findGrandTotalOfResourceBasedOnUniqueIdentifierNative(
            String subWorkStreamId, String subWorkStreamName, String scenario, String teamRole, String location,
            String staffType, String vendor, String rateSource, String staffLevel
    ) {

        Query query = entityManager.createNamedQuery("findGrandTotalOfResourceBasedOnUniqueIdentifierNative");
        query.setParameter("subWorkstreamId", subWorkStreamId);
        query.setParameter("subWorkStreamName", subWorkStreamName);
        query.setParameter("scenario", scenario);
        query.setParameter("teamRole", teamRole);
        query.setParameter("location", location);
        query.setParameter("staffType", staffType);
        query.setParameter("vendor", vendor);
        query.setParameter("rateSource", rateSource);
        query.setParameter("staffLevel", staffLevel);
        return query.getResultList();
    }
}
