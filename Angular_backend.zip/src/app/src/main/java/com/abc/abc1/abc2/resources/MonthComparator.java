package com.dbs.genesis.portfolio.resources;

import java.util.Comparator;

public class MonthComparator implements Comparator<UnitCostResource> {


    @Override
    public int compare(UnitCostResource o1, UnitCostResource o2) {
        return Integer.parseInt(o1.getMonthNumber())-Integer.parseInt(o2.getMonthNumber());
    }
}
