package com.dbs.genesis.portfolio.repository;


import com.dbs.genesis.portfolio.model.HyperionProductTree;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HyperionProductRepository extends JpaRepository<HyperionProductTree, String> {

    List<HyperionProductTree> findAll();

}
