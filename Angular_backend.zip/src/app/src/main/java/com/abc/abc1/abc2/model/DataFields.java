package com.dbs.genesis.portfolio.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "xref_data_fieldnames")
@EntityListeners(AuditingEntityListener.class)
public class DataFields extends CommonEntity<String>{

    @Id
    @Column(name = "refdata_code")
    private Integer dataCode;
    @Column(name = "refdata_label1")
    private String dataLabel1;
    @Column(name = "refdata_label2")
    private String dataLabel2;
    @Column(name = "refdata_label3")
    private String dataLabel3;
    @Column(name = "refdata_label4")
    private String dataLabel4;
    @Column(name = "refdata_label5")
    private String dataLabel5;
    @Column(name = "refdata_label6")
    private String dataLabel6;
    @Column(name = "refdata_label7")
    private String dataLabel7;
    @Column(name = "refdata_label8")
    private String dataLabel8;
    @Column(name = "refdata_label9")
    private String dataLabel9;
    @Column(name = "refdata_label10")
    private String dataLabel10;
    @Column(name = "refdata_label11")
    private String dataLabel11;
    @Column(name = "refdata_label12")
    private String dataLabel12;
}
