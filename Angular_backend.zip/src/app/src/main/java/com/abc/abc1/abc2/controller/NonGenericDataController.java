package com.dbs.genesis.portfolio.controller;

import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.PlatformStakeHolders;
import com.dbs.genesis.portfolio.model.XrefSubPlatformMasterEntity;
import com.dbs.genesis.portfolio.repository.PlatformStakeHoldersRepository;
import com.dbs.genesis.portfolio.repository.PortfolioRepo;
import com.dbs.genesis.portfolio.repository.XrefScenarioConfigRepo;
import com.dbs.genesis.portfolio.repository.XrefSubPlatformMasterRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequestMapping("/data/non-generic")
public class NonGenericDataController {

    private final XrefSubPlatformMasterRepo xrefSubPlatformMasterRepo;
    private final XrefScenarioConfigRepo xrefScenarioConfigRepo;
    private final PortfolioRepo portfolioRepo;
    private final PlatformStakeHoldersRepository stakeHoldersRepository;


    @Autowired
    public NonGenericDataController(XrefSubPlatformMasterRepo xrefSubPlatformMasterRepo, XrefScenarioConfigRepo
            xrefScenarioConfigRepo, PortfolioRepo portfolioRepo, PlatformStakeHoldersRepository stakeHoldersRepository) {
        this.xrefSubPlatformMasterRepo = xrefSubPlatformMasterRepo;
        this.xrefScenarioConfigRepo = xrefScenarioConfigRepo;
        this.portfolioRepo = portfolioRepo;
        this.stakeHoldersRepository = stakeHoldersRepository;
    }

    @GetMapping("/subplatform/{platformIndex}")
    public ResponseEntity getScenarioList(@PathVariable("platformIndex") String platformIndex) {
        List<XrefSubPlatformMasterEntity> platformMasterEntityList = xrefSubPlatformMasterRepo.findByPlatformIndex(platformIndex);
        return ResponseEntity.ok().body(platformMasterEntityList);
    }

    @GetMapping("/scenario")
    public List<String> getScenarioList() {
        return this.xrefScenarioConfigRepo.findDistinctByActiveIndEqualsIgnoreCase(PortfolioConstants.ACTIVE_COPY_SCENARIO);
    }

    @GetMapping("/stakeholders/role")
    public Set<String> getRolesByPlatform(@RequestParam("platformIndex") String platformIndex) {
        return portfolioRepo.getRolesByPlatformIndex(platformIndex);
    }
    @GetMapping("/stakeholders/staffnames")
    public Map<String, String> getStaffNameByPlatform(@RequestParam("platformIndex") String platformIndex, @RequestParam("role") String role) {
        List<PlatformStakeHolders> staffNamesByPlatformIndexAndRole = stakeHoldersRepository.getStaffNamesByPlatformIndexAndRole(platformIndex, role);
        return staffNamesByPlatformIndexAndRole.stream().collect(Collectors.toMap(
                PlatformStakeHolders::getOneBankId, PlatformStakeHolders::getEmpName));

    }
}
