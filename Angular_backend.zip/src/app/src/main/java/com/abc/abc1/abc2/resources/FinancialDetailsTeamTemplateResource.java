package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class FinancialDetailsTeamTemplateResource {

    List<String> roles;
    List<String> countryCodes;
    List<String> staffTypes;
    List<String> vendorCodes;
    List<String> rateSources;
    List<String> rateLevels;
    List<String> currencyCodes;
    Integer fdManDaysPerMonth;

}
