package com.dbs.genesis.portfolio.resources;

import com.dbs.genesis.portfolio.model.WorkStreamEntity;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class FinSysProjectIdCreationEvent {
    WorkStreamEntity workStreamEntity;
    String loggedInUserBankid;
}
