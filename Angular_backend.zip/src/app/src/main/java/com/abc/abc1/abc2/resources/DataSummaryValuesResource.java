package com.dbs.genesis.portfolio.resources;

import com.dbs.genesis.portfolio.model.DataSummary;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class DataSummaryValuesResource {

    DataSummary dataSummary;
    List<DataFieldAtributeResource> attributes;
}
