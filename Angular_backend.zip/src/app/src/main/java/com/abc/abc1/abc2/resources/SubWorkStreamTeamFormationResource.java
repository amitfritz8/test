package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class SubWorkStreamTeamFormationResource {

    private String role;
    private String location;
    private String staffType;
    private String vendor;
    private String rateSource;
    private String level;
    private String fte;
    private String currency;
    private String costperday;
    private String activeInd;

}
