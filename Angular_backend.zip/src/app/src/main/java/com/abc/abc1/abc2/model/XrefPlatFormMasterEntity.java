package com.dbs.genesis.portfolio.model;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Data
@Table(name = "xref_platform_master")
@Entity
@EntityListeners(AuditingEntityListener.class)
public class XrefPlatFormMasterEntity extends CommonEntity<String> {

    @Id
    @Column(name = "platform_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int platformId;
    @Column(name = "platform_index")
    private String platformIndex;
    @Column(name = "platform_name")
    private String platformName;
    @Column(name = "tech_unit")
    private String techUnit;
    @Column(name = "tech_unit_name")
    private String techUnitName;
    @Column(name = "platform_group")
    private String platformGroup;
    @Column(name = "platform_unit")
    private String platformUnit;
    @Column(name = "platform_type")
    private String platformType;
    @Column(name = "tech_md")
    private String techMD;
    @Column(name = "effective_start_date")
    private Date effectiveStartDate;
    @Column(name = "effective_end_date")
    private String effectiveEndDate;

}
