package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class StaffRateResource {

    private String countryCode;
    private String currencyCode;
    private String staffType;
    private String vendorCode;
    private String rateResource;
    private String rateLevel;

}
