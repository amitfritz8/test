package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.XrefPlatFormMasterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface XrefPlatformMasterRepo extends JpaRepository<XrefPlatFormMasterEntity, String> {

    XrefPlatFormMasterEntity findByPlatformIndex(String primaryPlatformIndex);
}
