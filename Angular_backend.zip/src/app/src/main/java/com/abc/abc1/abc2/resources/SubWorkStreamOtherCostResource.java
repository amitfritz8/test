package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.apache.logging.log4j.util.Strings;

import java.math.BigDecimal;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class SubWorkStreamOtherCostResource {

    private String vendor;
    private String capexOrOpex;
    private String currency;
    private String description;
    private String activeInd;
    private BigDecimal cost;
    private Integer surrId;

    public boolean validate() {
        return Strings.isNotEmpty(vendor) && Strings.isNotEmpty(currency);
    }
    //private Set<Integer> surrIds = new HashSet<>();
}
