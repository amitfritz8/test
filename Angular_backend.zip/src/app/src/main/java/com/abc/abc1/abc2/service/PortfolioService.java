package com.dbs.genesis.portfolio.service;

import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.*;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.service.financials.FinancialService;
import com.dbs.genesis.portfolio.service.workstream.WorkStreamBreakDownCostService;
import com.dbs.genesis.portfolio.service.workstream.WorkStreamBreakDownFinancialService;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Transactional
@Service
public class PortfolioService {

    private final PortfolioRepo portfolioRepo;

    private final WorkHierarchyRepo workHierarchyRepo;

    private final WorkStreamRepo workStreamRepo;

    private final SubWorkStreamRepo subWorkStreamRepo;

    private final PortfolioManagersRepo portfolioManagerRepo;

    private final WorkStreamManagersRepo workStreamManagersRepo;

    private final PortfolioRepository portfolioRepository;

    private final BusinessSegmentMasterRepo businessSegmentMasterRepo;

    private final WorkStreamApproverRepo workStreamApproversRepository;

    private final WorkstreamLePccodesRepo workstreamLePccodesRepo;

    private final WorkStreamService workStreamService;

    private EditLogRepo editLogRepo;

    private final WorkStreamBreakDownFinancialService workStreamBreakDownFinancialService;


    private final DataSummaryService dataSummaryService;

    private final WorkStreamBreakDownCostService workStreamBreakDownCostService;
    private final FinancialService financialService;
    private final XrefPlatformMasterRepo xrefPlatformMasterRepo;

    public PortfolioService(PortfolioRepo portfolioRepo, WorkHierarchyRepo workHierarchyRepo, WorkStreamRepo workStreamRepo,
                            SubWorkStreamRepo subWorkStreamRepo, FinancialService financialService,
                            PortfolioManagersRepo portfolioManagerRepo, WorkStreamManagersRepo workStreamManagersRepo,
                            PortfolioRepository portfolioRepository, BusinessSegmentMasterRepo businessSegmentMasterRepo,
                            WorkStreamApproverRepo workStreamApproversRepository, WorkstreamLePccodesRepo workstreamLePccodesRepo,
                            EditLogRepo editLogRepo, WorkStreamBreakDownFinancialService workStreamBreakDownFinancialService,
                            WorkStreamService workStreamService, DataSummaryService dataSummaryService,
                            WorkStreamBreakDownCostService workStreamBreakDownCostService,
                            XrefPlatformMasterRepo xrefPlatformMasterRepo) {
        this.portfolioRepo = portfolioRepo;
        this.workHierarchyRepo = workHierarchyRepo;
        this.workStreamRepo = workStreamRepo;
        this.subWorkStreamRepo = subWorkStreamRepo;
        this.financialService = financialService;
        this.portfolioManagerRepo = portfolioManagerRepo;
        this.workStreamManagersRepo = workStreamManagersRepo;
        this.portfolioRepository = portfolioRepository;
        this.businessSegmentMasterRepo = businessSegmentMasterRepo;
        this.workStreamApproversRepository = workStreamApproversRepository;
        this.workstreamLePccodesRepo = workstreamLePccodesRepo;
        this.editLogRepo = editLogRepo;
        this.workStreamBreakDownFinancialService = workStreamBreakDownFinancialService;
        this.workStreamService = workStreamService;
        this.dataSummaryService = dataSummaryService;
        this.workStreamBreakDownCostService = workStreamBreakDownCostService;
        this.xrefPlatformMasterRepo = xrefPlatformMasterRepo;
    }

    private static PortfolioListingSource getPortfolioListingSource(PortfolioEntity portfolioEntity) {
        PortfolioListingSource listingSource = new PortfolioListingSource();
        listingSource.setPortfolioId(portfolioEntity.getPortfolioId());
        listingSource.setPortfolioName(portfolioEntity.getPortfolioName());
        if ("I".equalsIgnoreCase(portfolioEntity.getWorkType())) {
            listingSource.setWorkType("INI");
        } else {
            listingSource.setWorkType("ENH");
        }

        listingSource.setBudgetStatus(portfolioEntity.getBudgetStatus());
        listingSource.setBudgetSystemOwner(portfolioEntity.getBudgetSystemOwner());
        listingSource.setPlatformName(portfolioEntity.getPrimaryPlatformName());
        return listingSource;
    }

    public PortfolioEntity getListOfPortfolioData(String portfolioId) {
        PortfolioEntity byPortfolioId = portfolioRepo.findByPortfolioId(portfolioId);
        if (Objects.nonNull(byPortfolioId) && Strings.isNotBlank(byPortfolioId.getPrimaryPlatformIndex())) {
            XrefPlatFormMasterEntity byPlatformIndex = xrefPlatformMasterRepo.findByPlatformIndex(byPortfolioId.getPrimaryPlatformIndex());
            if (Objects.nonNull(byPlatformIndex) && Strings.isNotBlank(byPlatformIndex.getPlatformUnit())) {
                byPortfolioId.setPlatformName(byPlatformIndex.getPlatformUnit());
            }
        }
        return byPortfolioId;
    }

    public WorkStreamEntity getListOfWorkStreamData(String workStreamId) {
        return workStreamRepo.findByWorkStreamId(workStreamId);
    }


    public SubWorkStreamEntity getListOfSubWorkStreamData(String subWorkStreamId, String name) {
        SubWorkStreamEntity subWorkStreamEntity=subWorkStreamRepo.findBySubWorkStreamIdAndSubWorkStreamName(subWorkStreamId, name);
        if(subWorkStreamEntity!=null){
           subWorkStreamEntity.setWorkType(subWorkStreamRepo.findWorkType(subWorkStreamEntity.getSubWorkStreamId(),subWorkStreamEntity.getSubWorkStreamName()));
        }
        return subWorkStreamEntity;
    }


    public boolean isDataNameExists(DataTypeNameResource dataNamesResource) {
        try {
            if (PortfolioConstants.PORTFOLIONAME.equalsIgnoreCase(dataNamesResource.getDataType())) {
                return portfolioRepo.existsByPortfolioName(dataNamesResource.getDataName());
            } else if (PortfolioConstants.WORKSTREAMNAME.equalsIgnoreCase(dataNamesResource.getDataType())) {
                return workStreamRepo.existsByWorkStreamNameAndPortfolioId(dataNamesResource.getDataName(), dataNamesResource.getStreamId());
            } else if (PortfolioConstants.SUBWORKSTREAMNAME.equalsIgnoreCase(dataNamesResource.getDataType())) {
                return subWorkStreamRepo.existsBySubWorkStreamNameAndWorkStreamId(dataNamesResource.getDataName(), dataNamesResource.getStreamId());
            }
        } catch (Exception e) {
            log.error("Exception in portfolio service impl", e);
        }
        return false;
    }


    public PortfolioEntity updatePortfolioData(PortfolioEntity portfolioEntity) {
        PortfolioEntity entity = null;
        try {
            entity = portfolioRepo.save(portfolioEntity);
            WorkHierarchyEntity workHierarchyEntity = workHierarchyRepo.findByPortfolioId(portfolioEntity.getPortfolioId());
            workHierarchyEntity.setPortfolioName(portfolioEntity.getPortfolioName());
            workHierarchyRepo.save(workHierarchyEntity);
        } catch (Exception e) {
            log.info("error in portfolio edit save operation");
        }
        return entity;
    }


    public List<StageWorkdayData> getLatestRecordsFromWorkDay() {
        List<StageWorkdayData> stageWorkdaysData = null;
        try {
            stageWorkdaysData = portfolioRepository.getStageWorkDayData();
        } catch (Exception e) {
            e.printStackTrace();
            log.info("Exception in getLatestRecordsFromWorkDay");
        }
        return stageWorkdaysData;
    }


    public PortfolioEntity updatePortfolioDataSource(PortfolioEntityDataSource portfolioEntityDataSource) {
        PortfolioEntity entity = null;
        if (portfolioEntityDataSource.getPortfolioEntity() != null) {
            String primaryPlatformName = portfolioEntityDataSource.getPortfolioEntity().getPrimaryPlatformName();
            portfolioEntityDataSource.getPortfolioEntity().setPrimaryPlatformIndex(
                    getPrimaryIndex(primaryPlatformName));
            entity = updatePortfolioData(portfolioEntityDataSource.getPortfolioEntity());
        }
        if (!portfolioEntityDataSource.getWorkManagers().isEmpty()) {
            portfolioEntityDataSource.getWorkManagers().forEach(this::updatePortfolioManagerEntity);
        }
        if(!Objects.isNull(entity)){
            editLogRepo.deleteByPortfolioIdAndPortfolioNameAndPortfolioType(entity.getPortfolioId(),entity.getPortfolioName(),PortfolioConstants.PORTFOLIONAME);
        }

        return entity;
    }

    private String getPrimaryIndex(String primaryPlatformName) {
        return primaryPlatformName.substring(0, primaryPlatformName.indexOf("-")).trim();
    }


    public PortfolioMangersEntity updatePortfolioManagerEntity(PortfolioMangersEntity managersEntity) {
        managersEntity.setPlatformIndex(getPrimaryIndex(managersEntity.getPortfolioId()).substring(1));
        portfolioManagerRepo.save(managersEntity);
        return managersEntity;
    }

    public List<Map> getListOfWorkManagersData(String portfolioId) {
        Map<String, List<PortfolioMangersResource>> portfolioManagersMap;
        Map<String, List<WorkStreamManagersResource>> workStreamManagersMap;
        List<Map> mapList = new ArrayList<>();
        try {
            List<PortfolioMangersEntity> mangersEntityList = portfolioManagerRepo.findByPortfolioIdAndActiveInd(portfolioId, "true");
            List<PortfolioMangersResource> portfolioMangersResourceList = getListOfPortfolioMangers(mangersEntityList);
            portfolioManagersMap = portfolioMangersResourceList.stream().collect(Collectors.groupingBy(PortfolioMangersResource::getPortfolioName));
            mapList.add(portfolioManagersMap);
            List<WorkStreamManagersEntity> workStreamManagersEntityList = workStreamManagersRepo.findByPortfolioIdAndActiveInd(portfolioId, "true");
            List<WorkStreamManagersResource> workStreamManagersResourceList = getListOfWorkStreamMangersList(workStreamManagersEntityList);
            workStreamManagersMap = workStreamManagersResourceList.stream().collect(Collectors.groupingBy(WorkStreamManagersResource::getWorkStreamName));
            mapList.add(workStreamManagersMap);
        } catch (Exception e) {
            log.info("Exception in portfolio work managers", e);
        }
        return mapList;
    }


    private List<PortfolioMangersResource> getListOfPortfolioMangers(List<PortfolioMangersEntity> mangersEntityList) {
        return mangersEntityList.stream().map
                (this::getPortfolioMangersResource).collect(Collectors.toList());
    }

    private PortfolioMangersResource getPortfolioMangersResource(PortfolioMangersEntity portfolioMangersEntity) {
        PortfolioMangersResource portfolioMangersResource = portfolioMangersEntity.toPortfolioMangersResource();
        PortfolioEntity portfolioEntity = portfolioRepo.findByPortfolioId(portfolioMangersEntity.getPortfolioId());
        portfolioMangersResource.setPortfolioName(portfolioEntity.getPortfolioName());
        return portfolioMangersResource;
    }


    private List<WorkStreamManagersResource>
    getListOfWorkStreamMangersList(List<WorkStreamManagersEntity> workStreamManagersEntityList) {
        return workStreamManagersEntityList.stream().map(streamManagersEntity -> {
            WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(streamManagersEntity.
                    getWorkStreamId());
            WorkStreamManagersResource workStreamManagersResource =
                    streamManagersEntity.toWorkStreamManagersResource();
            workStreamManagersResource.setWorkStreamName(workStreamEntity.getWorkStreamName());
            return workStreamManagersResource;
        }).collect(Collectors.toList());
    }

    public List<BusinessSegmentMasterEntity> getBusinessSegmentMasterData(String platformIndex) {
        try {
            return businessSegmentMasterRepo.findByPlatformIndex(platformIndex);
        } catch (Exception e) {
            log.error("Error in Business Segment Master Table", e);
            return new ArrayList<>();
        }

    }

    public List<Map> getListOfWorkStreamApproves(String portfolioId) {
        Map<String, List<WorkStreamApproversResource>> listMap;
        List<Map> mapList = new ArrayList<>();
        List<WorkStreamApprovers> workStreamApproversList = workStreamApproversRepository.findByPortfolioIdAndActiveInd
                (portfolioId, "true");
        List<WorkStreamApproversResource> approversResources = workStreamService.getApproversResource(workStreamApproversList);
        listMap = approversResources.stream().collect(Collectors.groupingBy(WorkStreamApproversResource::
                getWorkStreamName, TreeMap::new, Collectors.toList()));
        mapList.add(listMap);
        return mapList;
    }

    public List<PortfolioListingSource> getAllPortfolioListing(IdAndRoles idAndRoles) {
        List<PortfolioEntity> portfolioEntities;
        if (!checkPortfolioRoles(idAndRoles.getRoles())) {
            portfolioEntities = portfolioRepo.findAllByOneBankId(idAndRoles.getScenario(), idAndRoles.getPlatform(), idAndRoles.getReportingFlag(), idAndRoles.getLocations(), idAndRoles.getOneBankId());
        } else {
            portfolioEntities = portfolioRepo.findAllByScenarioPlatformAndCountry(idAndRoles.getScenario(), idAndRoles.getPlatform(), idAndRoles.getReportingFlag(), idAndRoles.getLocations());
        }
        return portfolioEntities.stream().map(
                PortfolioService::getPortfolioListingSource).collect(Collectors.toList());

    }

    public List<WorkstreamLePccodesEntity> getListOfWorkStreamLepccodesData(String workStreamId) {
        List<WorkstreamLePccodesEntity> lePccodesEntityList = workstreamLePccodesRepo.findByWorkStreamIdAndActiveInd(workStreamId, "true");
        lePccodesEntityList.forEach(workstreamLePccodesEntity -> {
            if (Strings.isNotBlank(workstreamLePccodesEntity.getLePCCode()) && workstreamLePccodesEntity.getLePCCode().trim().length() > 8) {
                workstreamLePccodesEntity.setLePCCode(workstreamLePccodesEntity.getLePCCode().substring(0, workstreamLePccodesEntity.getLePCCode().indexOf("-")));
            }
        });
        return lePccodesEntityList;
    }

    public Map getBreakDownFinancialDataByScenario(String scenario, String portfolioId, String period, String currencyCode, String typeOfData) {
        List<SubWorkStreamIdAndName> subWorkStreamIdAndNames = getSubWorkStreamIdAndNames(portfolioId);
        return workStreamBreakDownFinancialService.getFinancialDataByScenario(scenario, currencyCode, subWorkStreamIdAndNames, period, typeOfData);
    }

    public Map getBreakDownCostDataByScenario(String scenario, String portfolioId, String period, String currencyCode, String typeOfData) {
        List<SubWorkStreamIdAndName> subWorkStreamIdAndNames = getSubWorkStreamIdAndNames(portfolioId);
        return workStreamBreakDownCostService.getBreakDownCostData(scenario, currencyCode, subWorkStreamIdAndNames, period, typeOfData);
    }

    public List<SubWorkStreamIdAndName> getSubWorkStreamIdAndNames(String portfolioId) {
        List<WorkHierarchyEntity> workHierarchyEntities = workHierarchyRepo.getByPortfolioId(portfolioId);
        return workStreamService.getSubWorkstreamIdAndNames(workHierarchyEntities);
    }

    private boolean checkPortfolioRoles(List<String> roles) {
        boolean status = false;
        DataValues dataValues = dataSummaryService.getDataValuesByValue(PortfolioConstants.PF_LIST_ROLES, PortfolioConstants.SYSTEM_CONFIGURATION);
        for (String role : roles) {
            status = dataValues != null && dataValues.getDesc().contains(role) ? true : false;
            if (status)
                break;
        }
        return status;
    }

    public List<String> getFinancialYearsByScenario(String portfolioId, String scenario) {
        List<SubWorkStreamIdAndName> subWorkStreamIdAndNames = getSubWorkStreamIdAndNames(portfolioId);
        return subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> {
            return financialService.getFinancialYearsByScenario(subWorkStreamIdAndName.getWorkStreamId(),
                    subWorkStreamIdAndName.getSubWorkStreamId(), scenario, subWorkStreamIdAndName.getSubWorkStreamName());
        }).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
    }
}
