package com.dbs.genesis.portfolio.controller;

import com.dbs.genesis.portfolio.model.SubWorkStreamOthersEntity;
import com.dbs.genesis.portfolio.model.WorkstreamOthersEntity;
import com.dbs.genesis.portfolio.service.S3StorageService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Slf4j
@RestController
@Api(value="File Upload and Download API", description="Operations to upload and download files using S3")
@RequestMapping("/file")
public class FileController {

    @Autowired
    private S3StorageService s3StorageService;

    @Autowired
    private ServletContext servletContext;



    @PostMapping("/upload")
    public boolean uploadData(@RequestParam("file") MultipartFile multipartFile ,
                              @RequestParam("workstreamOthersSurrId")Integer workstreamOthersSurrId,
                              @RequestParam("portfolioId")String portfolioId,
                              @RequestParam("workStreamId")String workStreamId,
                              @RequestParam("documentName")String documentName,
                              @RequestParam("documentType")String documentType,
                              @RequestParam("description")String description,
                              @RequestParam("activeInd")String activeInd,
                              @RequestParam("filePath")String filePath,
                              @RequestParam("createdBy")String createdBy,
                              @RequestParam("dateCreated")String dateCreated,
                              @RequestParam("modifiedBy")String modifiedBy,
                              @RequestParam("dateModified")String dateModified,
                              @RequestParam("workstreamName")String workstreamName
                              ) {
        boolean status = false;

        if(multipartFile != null) {
            try{
                log.info("invoking storage service to upload file");
                status = s3StorageService.uploadFile(multipartFile,  workstreamOthersSurrId, portfolioId, workStreamId, documentName, documentType, description,activeInd,
                        filePath, createdBy, dateCreated, modifiedBy, dateModified,workstreamName);
                log.info("File uploading status: " + status);

            }catch(Exception e) {
                log.error("Error while uploading file",e);
            }
        }else {
            log.error("Invlaid file to upload");
        }
        return status;
    }



    @GetMapping("/download/{id}/{filename}")
    public void downloadFile(@PathVariable("id") Integer id,@PathVariable("filename") String filename,
                             HttpServletResponse response){
        InputStream fileDataStream = s3StorageService.downloadFile(id);
        response.setHeader("Content-Disposition", "attachment;filename="+filename);
        response.setHeader("Content-Type", "application/octet-stream");
        try {
            IOUtils.copy(fileDataStream, response.getOutputStream());
            // response.getOutputStream().write(fileData);
            response.getOutputStream().flush();
            response.getOutputStream().close();
        } catch (IOException e) {
            log.error("Error while downloading file...",e);
        }


    }

    @GetMapping("/workstream/others/{workstreamId}")
    public List<WorkstreamOthersEntity> getWorkstreamOthers(@PathVariable("workstreamId") String workstreamId){
        return s3StorageService.getWorkstreamOthers(workstreamId);
    }

    @PostMapping(value = "/subworkstream/upload")
    public boolean uploadSubWorkStreamData(@RequestPart("file") final MultipartFile multipartFile,
                                           @RequestParam("subWorkStreamId")String subWorkStreamId,
                                           @RequestParam("workStreamId") String workStreamId,
                                           @RequestParam("subWorkStreamName") String subWorkStreamName,
                                           @RequestParam("documentType")String documentType,
                                           @RequestParam("description")String description,
                                           @RequestParam("activeInd")String activeInd,
                                           @RequestParam("filePath")String filePath,
                                           @RequestParam("createdBy")String createdBy,
                                           @RequestParam("dateCreated")String dateCreated,
                                           @RequestParam("modifiedBy")String modifiedBy,
                                           @RequestParam("dateModified")String dateModified,
                                           @RequestParam("documentName")String documentName,
                                           @RequestParam("swsOthersSurrId") Integer swsOthersSurrId
                                           ) {
        boolean status = false;
        if (multipartFile != null) {
            try {
                status = s3StorageService.uploadSubWorkStreamFile(multipartFile, subWorkStreamId,workStreamId,
                        subWorkStreamName,documentType,description,activeInd,filePath,createdBy,dateCreated,modifiedBy,
                        dateModified,documentName,swsOthersSurrId);
            } catch(Exception e) {
                log.error("Error while uploading file",e);
            }
        } else {
            log.error("Invalid file to upload");
        }
        return status;
    }


    @GetMapping("/others/subworkstreams/{subWorkStreamId}/{subWorkStreamName}")
    public List<SubWorkStreamOthersEntity> getWorkStreamOthers(@PathVariable("subWorkStreamId") String subWorkStreamId,
                                                               @PathVariable("subWorkStreamName") String
                                                                       subWorkStreamName) {
        return s3StorageService.getSubWorkStreamOthers(subWorkStreamId, subWorkStreamName);

    }

    @GetMapping("/download/subworkstream/{id}/{fileName}")
    public void downloadForSubWorkStreamData(@PathVariable("id") Integer id,@PathVariable("fileName") String fileName,
                                                                            HttpServletResponse response,
                                                                            HttpServletRequest request
                                                                            ) {
        InputStream fileDataStream;
        fileDataStream = s3StorageService.ForSubWorkStreamData(id,response,request,servletContext);
        response.setHeader("Content-Disposition", "attachment;filename="+fileName);
        response.setHeader("Content-Type", "application/octet-stream");
        try {
            IOUtils.copy(fileDataStream, response.getOutputStream());
            // response.getOutputStream().write(fileData);
            response.getOutputStream().flush();
            response.getOutputStream().close();
        } catch (IOException e) {
            log.error("Error while downloading file...",e);
        }

    }

}

