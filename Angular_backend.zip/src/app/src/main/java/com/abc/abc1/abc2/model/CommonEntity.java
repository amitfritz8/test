package com.dbs.genesis.portfolio.model;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;
import java.sql.Timestamp;

@Getter
@Setter
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class CommonEntity<U> implements Serializable {

    @Column(name = "created_by")
    @CreatedBy
    private U createdBy;
    @Column(name = "date_created")
    @CreationTimestamp
    private Timestamp dateCreated;
    @Column(name = "modified_by")
    @LastModifiedBy
    private U modifiedBy;
    @Column(name = "date_modified")
    @UpdateTimestamp
    private Timestamp dateModified;

}
