package com.dbs.genesis.portfolio.service.costsettings;

import com.dbs.genesis.portfolio.common.MathExtentions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.ExchangeRatesRepo;
import com.dbs.genesis.portfolio.repository.PortfolioRepo;
import com.dbs.genesis.portfolio.repository.WorkStreamRepo;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import com.netflix.discovery.converters.Auto;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@Slf4j
public class FinancialDetailsService implements MathExtentions {

    private final ExchangeRatesRepo exchangeRatesRepo;
    private final PortfolioRepo portfolioRepo;
    private final WorkStreamRepo workStreamRepo;
    private final DataSummaryService dataSummaryService;


    public FinancialDetailsService(ExchangeRatesRepo exchangeRatesRepo,
                                   PortfolioRepo portfolioRepo,
                                   WorkStreamRepo workStreamRepo, DataSummaryService dataSummaryService) {
        this.exchangeRatesRepo = exchangeRatesRepo;
        this.portfolioRepo = portfolioRepo;
        this.workStreamRepo = workStreamRepo;
        this.dataSummaryService = dataSummaryService;
    }

    public void
    updateCurrencyValuesMonthly(String currencyCode,
                                BigDecimal value, List<String> currentYearMonthBetweenDates,
                                SubWorkstreamFinDetailsEntity finDetailsEntity) {
        updateCurrencyValues(finDetailsEntity, currencyCode, value);
        finDetailsEntity.setGroupCcyVal(
                getMonthlyCurrencyValue(currentYearMonthBetweenDates.size(), finDetailsEntity.getGroupCcyVal()));
        finDetailsEntity.setLocalCcyVal(
                getMonthlyCurrencyValue(currentYearMonthBetweenDates.size(), finDetailsEntity.getLocalCcyVal()));
    }

    public void updateCurrencyValues(SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity,
                                     String loggedInCurrencyCode,
                                     BigDecimal currencyValue) {
        if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(loggedInCurrencyCode))
            updateCurrencyValuesForGroup(subWorkstreamFinDetailsEntity, loggedInCurrencyCode, currencyValue);
        else
            updateCurrencyValuesForLocal(subWorkstreamFinDetailsEntity, loggedInCurrencyCode, currencyValue);
    }

    private SubWorkstreamFinDetailsEntity
    updateCurrencyValuesForLocal(SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity,
                                 String loggedInCurrencyCode,
                                 BigDecimal currencyValue) {
        subWorkstreamFinDetailsEntity.setLocalCcyVal(currencyValue);
        subWorkstreamFinDetailsEntity.setLocalCcy(loggedInCurrencyCode);
        DataValues dataValues = dataSummaryService.getDataValuesByValue(PortfolioConstants.REF_DATA_GRP_CCY, PortfolioConstants.REF_DATA_SYSTEM_CONFIG);
        if (dataValues != null) {
            subWorkstreamFinDetailsEntity.setGroupCcy(dataValues.getDesc());
        } else {
            subWorkstreamFinDetailsEntity.setGroupCcy(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD);
        }
        subWorkstreamFinDetailsEntity.setGroupCcyVal(currencyValue.multiply(getExchangeValue(subWorkstreamFinDetailsEntity.getPeriod(), loggedInCurrencyCode, subWorkstreamFinDetailsEntity.getWorkstreamId())));

        return subWorkstreamFinDetailsEntity;
    }

    private SubWorkstreamFinDetailsEntity
    updateCurrencyValuesForGroup(SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity,
                                 String loggedInCurrencyCode,
                                 BigDecimal value) {
        subWorkstreamFinDetailsEntity.setGroupCcyVal(value);
        subWorkstreamFinDetailsEntity.setGroupCcy(loggedInCurrencyCode);
        subWorkstreamFinDetailsEntity.setLocalCcy(loggedInCurrencyCode);
        subWorkstreamFinDetailsEntity.setLocalCcyVal(value);
        return subWorkstreamFinDetailsEntity;
    }

    public BigDecimal
    getExchangeValue(String period, String currencyCode, String workStreamId) {
        ExchangeRatesEntity exchangeRatesForGrp =
                getExchangeRatesEntityByPeriod(period, currencyCode, workStreamId);
        return exchangeRatesForGrp != null ? exchangeRatesForGrp.getRateValue() : BigDecimal.ZERO;
    }

    private ExchangeRatesEntity
    getExchangeRatesEntityByPeriod(String period, String currencyCode, String workStreamId) {
        return getExchangeRatesEntity(period, currencyCode, workStreamId);
    }

    public BigDecimal getMonthlyCurrencyValue(int months, BigDecimal value) {
        return divideWithScaleHalfUp(value, months);
    }

    public ExchangeRatesEntity
    getExchangeRatesEntity(String yearMonth,
                           String loggedInLocalCurrencyCode,
                           String workStreamId) {
        String statusOfBudget = getBudgetStatus(workStreamId);
        return exchangeRatesRepo.
                findByCurrencyFromAndCurrencyToAndRateTypeAndBudgetStatusAndRatePeriod(loggedInLocalCurrencyCode,
                        PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD, PortfolioConstants.defaultRateType,
                        statusOfBudget, yearMonth);
    }

    private String getBudgetStatus(String workStreamId) {
        PortfolioEntity portfolioEntity = getPortfolioEntityByPassingWorkStreamId(workStreamId);
        String budgetStatus = portfolioEntity.getBudgetStatus();
        if (Strings.isNotEmpty(budgetStatus) && "B2020".equalsIgnoreCase(budgetStatus.substring(0, 5).trim())) {
            return budgetStatus.substring(0, 5).trim();
        }
        return PortfolioConstants.defaultBudgetStatus;
    }


    private PortfolioEntity getPortfolioEntityByPassingWorkStreamId(String workStreamId) {
        try {
            WorkStreamEntity byWorkStreamId = workStreamRepo.findByWorkStreamId(workStreamId);
            return portfolioRepo.findByPortfolioId(byWorkStreamId.getPortfolioId());
        } catch (Exception e) {
            log.error("Getting ", e);
            return new PortfolioEntity();
        }

    }

    public BigDecimal getCurrencyValue(String period, String currencyCode, String workStreamId, BigDecimal value) {
        BigDecimal exChangeValue = getExchangeValue(period, currencyCode, workStreamId);
        return divideWithScaleHalfUp(value, exChangeValue);
    }

}
