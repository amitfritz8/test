package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.resources.CopyScenarioRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

@Slf4j
@Repository
public class CopyRepository {

    @PersistenceContext
    private EntityManager entityManager;

    public void callBackEndFinancialProcedureCopySnapshot(CopyScenarioRequest copyScenarioRequest) {
        log.info("Start callBackEndFinancialProcedureCopySnapshot");
        StoredProcedureQuery query = entityManager.createNamedStoredProcedureQuery("sp_create_snapshot");
        query.setParameter("copyfrom",copyScenarioRequest.getScenarioFrom());
        query.setParameter("copyto",copyScenarioRequest.getScenarioTo());
        query.execute();
        log.info("End callBackEndFinancialProcedureCopySnapshot");
    }

}
