package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.apache.logging.log4j.util.Strings;

import java.math.BigDecimal;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class SubWorkStreamHardwareCostResource {

    private String tower;
    private String driverDetails;
    private String uom;
    private String currency;
    private BigDecimal itcRate;
    private BigDecimal qty;
    private String costInCurrency;
    private BigDecimal costPerMonth;
    private String activeInd;
    private Integer surrId;

    public boolean validate() {
        return Strings.isNotEmpty(tower) && Strings.isNotEmpty(driverDetails) && Strings.isNotEmpty(uom)
                && Strings.isNotEmpty(currency) && Strings.isNotEmpty(costInCurrency);
    }
}
