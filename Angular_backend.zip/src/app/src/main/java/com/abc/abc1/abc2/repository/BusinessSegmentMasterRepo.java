package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.BusinessSegmentMasterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BusinessSegmentMasterRepo extends JpaRepository<BusinessSegmentMasterEntity,Integer> {

    List<BusinessSegmentMasterEntity> findByPlatformIndex(String platformIndex);
}
