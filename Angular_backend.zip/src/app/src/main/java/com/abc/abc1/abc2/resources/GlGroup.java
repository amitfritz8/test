package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class GlGroup {
    String name;
    List<GlCategory> glCategories;
    List<BigDecimal> monthlyFinanceTotal;
    Map<String,List<BigDecimal>> quarterlySummary;
    Map<String,BigDecimal> yearlySummary;
    BigDecimal totalSum;
    BigDecimal overAllSum;
    Map<String,BigDecimal> individualYearSummaryForQuarterly;
}
