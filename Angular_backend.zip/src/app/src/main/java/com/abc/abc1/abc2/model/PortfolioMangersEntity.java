package com.dbs.genesis.portfolio.model;

import com.dbs.genesis.portfolio.resources.PortfolioMangersResource;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Date;

@Data
@Entity
@Table(name = "portfolio_managers")
@EntityListeners(AuditingEntityListener.class)
@ToString
public class PortfolioMangersEntity extends CommonEntity<String> {


    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "port_mgr_surr_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int portMgrSurrId;
    @Column(name = "portfolio_id")
    private String portfolioId;
    @Column(name = "1bank_id")
    private String oneBankId;
    @Column(name = "staff_name")
    private String staffName;
    @Column(name = "role")
    private String role;
    @Column(name = "platform_index")
    private String platformIndex;
    @Column(name = "email_address")
    private String emailAddress;
    @Column(name = "effective_start_date")
    private Date effectiveStartDate;
    @Column(name = "effective_end_date")
    private Date effectiveEndDate;
    @Column(name = "delegate_ind")
    private String delegateInd;
    @Column(name = "active_ind")
    private String activeInd;

    public PortfolioMangersResource toPortfolioMangersResource() {
        PortfolioMangersResource portfolioMangersResource = new PortfolioMangersResource();
        portfolioMangersResource.setPortMgrSurrId(getPortMgrSurrId());
        portfolioMangersResource.setPortfolioId(getPortfolioId());
        portfolioMangersResource.setEmailAddress(getEmailAddress());
        portfolioMangersResource.setEffectiveStartDate(getEffectiveStartDate());
        portfolioMangersResource.setEffectiveEndDate(getEffectiveEndDate());
        portfolioMangersResource.setOneBankId(getOneBankId());
        portfolioMangersResource.setDelegateInd(getDelegateInd().toLowerCase());
        portfolioMangersResource.setPlatformIndex(getPlatformIndex());
        portfolioMangersResource.setRole(getRole());
        portfolioMangersResource.setStaffName(getStaffName());
        return portfolioMangersResource;
    }
}
