package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.PortfolioMangersEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PortfolioManagersRepo extends JpaRepository<PortfolioMangersEntity,String> {

    List<PortfolioMangersEntity> findByPortfolioIdAndActiveInd(String portfolioId, String activeInd);

    @Query(value = "select DISTINCT `1bank_id` from portfolio_managers where portfolio_id=:portfolioId and active_ind='true'",nativeQuery = true)
    List<String> getAllDistinctPortfolioManagers(@Param("portfolioId") String portfolioId);
}
