package com.dbs.genesis.portfolio.repository;


import com.dbs.genesis.portfolio.model.SubWorkStreamEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface SubWorkStreamRepo extends JpaRepository<SubWorkStreamEntity, String> {

    SubWorkStreamEntity findBySubWorkStreamId(String workStreamId);

    SubWorkStreamEntity findBySubWorkStreamIdAndSubWorkStreamName(String workStreamId,String name);

    boolean existsBySubWorkStreamNameAndWorkStreamId(String subWorkStreamName, String workStreamId);

    boolean existsByWorkStreamIdAndDeliveryUnit(String workStreamId, String deliveryUnit);

    List<SubWorkStreamEntity> findByWorkStreamId(String workStreamId);

    @Query(value = "select * from sub_workstream_profile where sub_workstream_id in(select distinct sub_workstream_id from sub_workstream_fin_details where scenario = ?1)",nativeQuery = true)
    List<SubWorkStreamEntity> findAllByScenarioEquals(String Category);

     /*@Query("select a from SubWorkStreamEntity a,PortfolioMangersEntity b  where b.oneBankId = :oneBankId and a.portfolioId = b.portfolioId ")
    List<WorkStreamEntity> findAllByOneBankIdAndPortfolio(String oneBankId);*/

    @Query(value = "select distinct c.* from sub_workstream_dates a,workstream_profile w,sub_workstream_profile c, workstream_managers m,portfolio_profile p\n" +
            "where a.scenario_name = ?1 and a.sub_workstream_id = c.sub_workstream_id and w.workstream_id = c.workstream_id and  m.workstream_id = w.workstream_id and w.portfolio_id = p.portfolio_id\n" +
            "      and ((p.primary_platform_index in (?2) and w.country in (?3) and m.1bank_id = ?4 and m.active_ind = 'true') or (m.1bank_id = ?4 and m.active_ind = 'true'))",nativeQuery = true)
    List<SubWorkStreamEntity> findAllByOneBankIdAndWorkStream(String scenario, List<String> platform, List<String> locations, String oneBankId);

    @Query(value = "select distinct b.* from sub_workstream_dates a,sub_workstream_profile b,portfolio_profile c, sub_workstream_managers m,workstream_profile w " +
            "where a.scenario_name = ?1 and a.sub_workstream_id = b.sub_workstream_id and w.workstream_id = b.workstream_id and w.portfolio_id = c.portfolio_id and m.sub_workstream_id = b.sub_workstream_id " +
            "and ((c.primary_platform_index in (?2) and b.country in (?3) and m.1bank_id = ?4 and m.active_ind='true') or (m.1bank_id = ?4 and m.active_ind = 'true'))",nativeQuery = true)
    List<SubWorkStreamEntity> findAllByOneBankIdAndSubWorkStream(String scenario, List<String> platform, List<String> locations, String oneBankId);


    @Query(value="select  distinct c.* from sub_workstream_dates a,workstream_profile w,sub_workstream_profile c, portfolio_managers m,portfolio_profile p " +
            "where a.scenario_name = ?1 and a.sub_workstream_id = c.sub_workstream_id and w.workstream_id = c.workstream_id and  m.portfolio_id = w.portfolio_id and w.portfolio_id = p.portfolio_id " +
            "and ((p.primary_platform_index in (?2) and w.country in (?3) and m.1bank_id = ?4 and m.active_ind = 'true') or (m.1bank_id = ?4 and m.active_ind = 'true'))",nativeQuery = true)
    List<SubWorkStreamEntity> findAllByOneBankIdAndPortfolio(String scenario, List<String> platform, List<String> locations, String oneBankId);

    @Query(value = "select distinct s.* from sub_workstream_dates a,workstream_profile b,portfolio_profile c, sub_workstream_profile s\n" +
            "where a.scenario_name = ?1 and a.sub_workstream_id = s.sub_workstream_id and b.portfolio_id = c.portfolio_id and b.workstream_id=s.workstream_id\n" +
            "    and c.primary_platform_index in (?2) and b.country in (?3) ",nativeQuery = true)
    List<SubWorkStreamEntity> findAllByScenarioPlatformAndCountry(String scenario, List<String> platform, List<String> locations);

    @Query(value = "select if(primary_platform_index = substring(delivery_unit,1,locate('-',delivery_unit)-1),'A-Work','B-Work') as work\n" +
            "FROM sub_workstream_profile a,workstream_profile b,portfolio_profile c where a.workstream_id = b.workstream_id and b.portfolio_id = c.portfolio_id and a.sub_workstream_id = ?1 and a.sub_workstream_name=?2",nativeQuery = true)
    String findWorkType(String subWorkStreamId, String subWorkStreamName);

    @Query(value = "select sum (totalNo) from ( \n" +
            "(select count (*) as totalNo from sub_workstream_software_cost where sub_workstream_id = ?1 and active_ind = 'true' \n" +
            "                                                                 and sub_workstream_name = ?2 ) \n" +
            "union (select count (*) as totalNo from sub_workstream_resource_cost where sub_workstream_id = ?1 and active_ind = 'true' \n" +
            "                                                                       and sub_workstream_name = ?2 ) \n" +
            "union (select count (*) as totalNo from sub_workstream_other_cost where sub_workstream_id = ?1 and active_ind = 'true' \n" +
            "                                                                    and sub_workstream_name = ?2 ) \n" +
            "union (select count (*) as totalNo from sub_workstream_hardware_cost where sub_workstream_id = ?1 and active_ind = 'true' \n" +
            "                                                                       and sub_workstream_name =  ?2 )) \n" +
            "as total",nativeQuery = true)
    int countBySubWorkStreamIdAndWorkStreamName(String subWorkStreamId, String subWorkStreamName);

    @Query(value="select  distinct c.* from sub_workstream_dates a,workstream_profile w,sub_workstream_profile c, portfolio_managers m,portfolio_profile p " +
            "where a.scenario_name = ?1 and a.sub_workstream_id = c.sub_workstream_id and w.workstream_id = c.workstream_id and  m.portfolio_id = w.portfolio_id and w.portfolio_id = p.portfolio_id " +
            "and ((p.primary_platform_index in (?2) and w.country in (?3) and m.1bank_id = ?4 and m.active_ind = 'true') or (m.1bank_id = ?4 and m.active_ind = 'true'))" +
            "UNION " +
            "select distinct c.* from sub_workstream_dates a,workstream_profile w,sub_workstream_profile c, workstream_managers m,portfolio_profile p" +
            "         where a.scenario_name = ?1 and a.sub_workstream_id = c.sub_workstream_id and w.workstream_id = c.workstream_id and  m.workstream_id = w.workstream_id and w.portfolio_id = p.portfolio_id" +
            "         and ((p.primary_platform_index in (?2) and w.country in (?3) and m.1bank_id = ?4 and m.active_ind = 'true') or (m.1bank_id = ?4 and m.active_ind = 'true'))" +
            "UNION " +
            "select distinct b.* from sub_workstream_dates a,sub_workstream_profile b,portfolio_profile c, sub_workstream_managers m,workstream_profile w " +
            "           where a.scenario_name = ?1 and a.sub_workstream_id = b.sub_workstream_id and w.workstream_id = b.workstream_id and w.portfolio_id = c.portfolio_id and m.sub_workstream_id = b.sub_workstream_id " +
            "            and ((c.primary_platform_index in (?2) and b.country in (?3) and m.1bank_id = ?4 and m.active_ind='true') or (m.1bank_id = ?4 and m.active_ind = 'true'))",nativeQuery = true)
    List<SubWorkStreamEntity> findAllByOneBankIdListing(String scenario, List<String> platform, List<String> locations, String oneBankId);
}
