package com.dbs.genesis.portfolio.service;

import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.DataValues;
import com.dbs.genesis.portfolio.repository.EmployeeRateCardRepo;
import com.dbs.genesis.portfolio.resources.StaffRateResource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@Slf4j
public class EmployeeRateCardService {

    private final DataSummaryService dataSummaryService;
    private final EmployeeRateCardRepo employeeRateCardRepo;

    public EmployeeRateCardService(DataSummaryService dataSummaryService, EmployeeRateCardRepo employeeRateCardRepo) {
        this.dataSummaryService = dataSummaryService;
        this.employeeRateCardRepo = employeeRateCardRepo;
    }

//    public BigDecimal getStaffRate(StaffRateResource staffRateResource){
//        log.info("Request for StaffRate using: "+staffRateResource.toString());
//        DataValues dataValues = dataSummaryService.getDataValuesByDesc(staffRateResource.getCountryCode(),
//                PortfolioConstants.COUNTRY);
//
//        if(dataValues != null){
//            return employeeRateCardRepo.getStaffRate(
//                    dataValues.getValue(), staffRateResource.getCurrencyCode(),
//                    staffRateResource.getStaffType(), staffRateResource.getVendorCode(),
//                    staffRateResource.getRateResource(), staffRateResource.getRateLevel(), PortfolioConstants.RATE_INDICATOR_BLENDED);
//        }
//        return null;
//    }


    public BigDecimal getStaffRate(StaffRateResource staffRateResource){
        log.info("Request for StaffRate using: "+staffRateResource.toString());

            return employeeRateCardRepo.getStaffRate(
                    staffRateResource.getCountryCode(), staffRateResource.getCurrencyCode(),
                    staffRateResource.getStaffType(), staffRateResource.getVendorCode(),
                    staffRateResource.getRateResource(), staffRateResource.getRateLevel(), PortfolioConstants.RATE_INDICATOR_BLENDED);
            }
}
