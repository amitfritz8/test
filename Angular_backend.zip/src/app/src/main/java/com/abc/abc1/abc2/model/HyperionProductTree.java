package com.dbs.genesis.portfolio.model;


import com.dbs.genesis.portfolio.resources.HyperionProductResource;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;


@NamedNativeQueries({
        @NamedNativeQuery(name = "getHyperionProductTree",
                query = "SELECT DISTINCT l4_desc AS l0Desc,l4_node AS l0Node from xref_hyperion_product_tree",
                resultSetMapping = "mapHyperionProductTree")
})

@SqlResultSetMappings(
        {
                @SqlResultSetMapping(name = "mapHyperionProductTree",
                        classes = {
                                @ConstructorResult(targetClass = HyperionProductResource.class,
                                        columns = {
                                                @ColumnResult(name = "l0Node"),
                                                @ColumnResult(name = "l0Desc")
                                        })
                        }),
        }
)
@Data
@Entity
@Table(name = "xref_hyperion_product_tree")
@EntityListeners(AuditingEntityListener.class)
public class HyperionProductTree extends CommonEntity<String> {

    @Id
    @Column(name = "l4_node")
    private String l0Node;
    @Column(name = "l4_desc")
    private String l0Desc;


}
