package com.dbs.genesis.portfolio.resources;


import com.dbs.genesis.portfolio.model.*;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SubWorkStreamDataSource {

    SubWorkStreamEntity portFolioSubWorkStreamEntity;
    String workStreamId;
    String workStreamName;
    String portfolioId;
    String portfolioName;
    String currencyCode;
    List<SubWorkStreamManagersEntity> workManagers;
    List<SubWorkStreamKeyDatesEntity> keyDates;
    List<SubWorkStreamApprovers> subWorkStreamApproves;
    MonthlyFinancialResource monthlyFinancialResource;
    List<MapWorkToPccode> lePcodesMapping;
    List<MapWorkToPccode> deletedLePcodesMapping;

}
