package com.dbs.genesis.portfolio.resources;

import com.dbs.genesis.portfolio.model.WorkstreamOthersEntity;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkStreamOthers{

    WorkstreamOthersEntity othersEntity;
    MultipartFile file;
}
