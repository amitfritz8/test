package com.dbs.genesis.portfolio.controller;


import com.dbs.genesis.portfolio.model.WorkStreamEntity;
import com.dbs.genesis.portfolio.model.WorkstreamOclaw;
import com.dbs.genesis.portfolio.resources.CopyScenarioRequest;
import com.dbs.genesis.portfolio.resources.IdAndRoles;
import com.dbs.genesis.portfolio.resources.WorkStreamDataSource;
import com.dbs.genesis.portfolio.resources.WorkStreamListingSource;
import com.dbs.genesis.portfolio.service.PortFolioWorkStreamCopyScenarioService;
import com.dbs.genesis.portfolio.service.WorkStreamService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Slf4j
@RestController
@RequestMapping("/data/workstream")
public class WorkStreamController {
    private final WorkStreamService workStreamService;
    private final PortFolioWorkStreamCopyScenarioService copyScenarioService;

    public WorkStreamController(WorkStreamService workStreamService, PortFolioWorkStreamCopyScenarioService copyScenarioService) {
        this.workStreamService = workStreamService;
        this.copyScenarioService = copyScenarioService;
    }

    @PostMapping("/generation")
    private ResponseEntity<WorkStreamEntity> getWorkStreamData(@RequestBody WorkStreamDataSource workStreamDataSource) {
        WorkStreamEntity workStreamEntity = workStreamService.saveWorkStreamData(workStreamDataSource.getPortfolioId(),
                workStreamDataSource.getPortfolioName(), workStreamDataSource.getPortFolioWorkStreamEntity(),workStreamDataSource.getLoggedInUserBankid());
        return ResponseEntity.ok().body(workStreamEntity);
    }

    @PostMapping("/getportfolioid/{portfolioId}")
    private WorkStreamEntity getWorkStreamEntityData(@PathVariable String portfolioId) {
        List<WorkStreamEntity> list = workStreamService.getWorkStreamEntityData(portfolioId);
        return list.get(0);
    }

    @PostMapping("/edit/updateWorkstream")
    public ResponseEntity updateWorkStream(@RequestBody WorkStreamDataSource workStreamDataSource) {
        WorkStreamEntity portFolioWorkStreamEntity = workStreamService.updateWorkStreamData(workStreamDataSource);
        return ResponseEntity.ok(portFolioWorkStreamEntity);
    }

    @GetMapping("/getworkmanagers/{workstreamid}")
    public ResponseEntity getWorkManagersData(@PathVariable(value = "workstreamid") String workStreamId) {
        List<Map> workManagerData = workStreamService.getListOfWorkManagersData(workStreamId);
        return ResponseEntity.ok().body(workManagerData);
    }

    @GetMapping("/listOfKeyDatesPortfolio/{portfolioId}")
    public ResponseEntity getListOfPortfolioKeyDates(@PathVariable String portfolioId) {
        List<Map> workStreamKeyDatesData = workStreamService.getPortfolioKeyDatesData(portfolioId);
        return ResponseEntity.ok().body(workStreamKeyDatesData);
    }

    @GetMapping("/listOfKeyDatesWorkstream/{workStreamId}")
    public ResponseEntity getListOfWorkStreamKeyDates(@PathVariable String workStreamId) {
        List<Map> workStreamKeyDatesData = workStreamService.getWorkStreamKeyDatesData(workStreamId);
        return ResponseEntity.ok().body(workStreamKeyDatesData);
    }

    @GetMapping("/approvers/{workStreamId}")
    public ResponseEntity getListOfWorkStreamApproves(@PathVariable String workStreamId) {
        List<Map> map = workStreamService.getListOfWorkStreamApproves(workStreamId);
        return ResponseEntity.ok().body(map);
    }

    @PostMapping("/listing")
    public ResponseEntity getWorkStreamListing(@RequestBody IdAndRoles idAndRoles) {
        Instant start = Instant.now();
        List<WorkStreamListingSource> workStreamListing = workStreamService.getWorkStreamListing(idAndRoles);
        Instant finish = Instant.now();
        long timeElapsed = Duration.between(start, finish).toMillis();
        log.info("Total time WorkStreamListing in Millis: " + timeElapsed);
        return ResponseEntity.ok().body(workStreamListing);
    }

    @GetMapping("/scenarios")
    public ResponseEntity scenarios(String requestType) {
        Set<String> scenarios = copyScenarioService.getScenarios(requestType);
        return ResponseEntity.ok().body(scenarios);
    }

    @GetMapping("/scenariosForCopyApproval")
    public ResponseEntity scenariosForApproval(
            @RequestParam("requestType") String requestType, @RequestParam("id") String id) {
        Set<String> pendingScenarios = copyScenarioService.getScenariosForApproval(requestType, id);
        return ResponseEntity.ok().body(pendingScenarios);
    }

    @PostMapping("/copyScenario")
    public ResponseEntity copyScenario(@RequestBody CopyScenarioRequest copyScenarioRequest) {
        return ResponseEntity.ok().body(copyScenarioService.copyScenario(copyScenarioRequest));
    }

    @GetMapping("/breakdown-financial-data")
    public Map getBreakDownFinancialData(@RequestParam("scenario") String scenario,
                                         @RequestParam("workStreamId") String workStreamId,
                                         @RequestParam("period")
                                                 String period, @RequestParam("ccyCode") String currencyCode, @RequestParam("typeOfData") String typeOfData) {
        return workStreamService.getBreakDownFinancialDataByScenario(scenario, workStreamId,
                period, currencyCode, typeOfData);
    }

    @GetMapping("/breakdown-cost-data")
    public Map getBreakDownCostData(@RequestParam("scenario") String scenario,
                                    @RequestParam("workStreamId") String workStreamId,
                                    @RequestParam("period")
                                            String period, @RequestParam("ccyCode") String currencyCode, @RequestParam("typeOfData") String typeOfData) {
        return workStreamService.getBreakDownCostDataByScenario(scenario, workStreamId,
                period, currencyCode, typeOfData);
    }

    @PostMapping("/approveCopyScenario")
    public Boolean approveCopyScenario(@RequestParam("file") MultipartFile[] multipartFiles,
                                       @RequestParam("description") String description,
                                       @RequestParam("portfolioId") String portfolioId,
                                       @RequestParam("workStreamId") String workStreamId,
                                       @RequestParam("workStreamName") String workStreamName,
                                       @RequestParam("scenarioTo") String scenarioTo,
                                       @RequestParam("approvalDate") String approvalDate,
                                       @RequestParam("createdBy") String createdBy
    ) {
        return copyScenarioService.approveCopyScenario(multipartFiles, portfolioId, workStreamId,
                scenarioTo, approvalDate, description, createdBy);
    }

    @GetMapping("/listOfFinYears")
    public ResponseEntity getListOfFinanceYears(@RequestParam("workStreamId") String workStreamId,
                                                @RequestParam("scenario") String scenario) {
        List<String> listOfYears = workStreamService.getFinancialYearsByScenario(workStreamId, scenario);
        return ResponseEntity.ok().body(listOfYears);
    }

    @GetMapping("/pccodes")
    public ResponseEntity getWorkstreamPccodes(@PathVariable String workStreamId) {
        return ResponseEntity.ok().body(workStreamService.getWorkstreamPccodes(workStreamId));
    }

    @PostMapping("/oclaw")
    public ResponseEntity postToOCLAW(@RequestBody WorkstreamOclaw workstreamOclaw) {
        return ResponseEntity.ok().body(workStreamService.postToOCLAW(workstreamOclaw));
    }
}
