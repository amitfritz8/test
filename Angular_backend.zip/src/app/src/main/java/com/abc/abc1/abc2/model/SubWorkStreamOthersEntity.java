package com.dbs.genesis.portfolio.model;


import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Data
@Entity
@Table(name = "sub_workstream_others")
@EntityListeners(AuditingEntityListener.class)
@ToString
public class SubWorkStreamOthersEntity extends CommonEntity<String>{

    @Id
    @Column(name = "sws_others_surr_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer swsOthersSurrId;
    @Column(name = "workstream_id")
    private String workStreamId;
    @Column(name = "sub_workstream_id")
    private String subWorkStreamId;
    @Column(name = "sub_workstream_name")
    private String subWorkStreamName;
    @Column(name = "document_type")
    private String documentType;
    @Column(name = "document_name")
    private String documentName;
    @Column(name = "description")
    private String description;
    @Column(name = "file_path")
    private String filePath;
    @Column(name = "active_ind")
    private String activeInd;

}
