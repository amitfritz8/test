package com.dbs.genesis.portfolio.service.costsettings;

import com.dbs.genesis.portfolio.common.DateExtensions;
import com.dbs.genesis.portfolio.common.MathExtentions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.mapper.CostSettingsMapper;
import com.dbs.genesis.portfolio.model.DataValues;
import com.dbs.genesis.portfolio.model.SubWorkStreamKeyDatesEntity;
import com.dbs.genesis.portfolio.model.SubWorkstreamFinDetailsEntity;
import com.dbs.genesis.portfolio.repository.SubWorkStreamKeyDatesRepo;
import com.dbs.genesis.portfolio.repository.SubWorkstreamFinDetailsRepo;
import com.dbs.genesis.portfolio.resources.CostSettingsUpdateEvent;
import com.dbs.genesis.portfolio.resources.HLECostType;
import com.dbs.genesis.portfolio.resources.HLERefDataResource;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import com.dbs.genesis.portfolio.service.SubWorkStreamService;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@Transactional
public class HLEService implements MathExtentions, DateExtensions {


    private final SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo;
    private final DataSummaryService dataSummaryService;
    private SubWorkStreamService subWorkStreamService;
    private final CostSettingsMapper costSettingsMapper;
    private final FinancialDetailsService financialDetailsService;
    private final SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    private final ApplicationEventPublisher publisher;

    @Autowired
    public HLEService(DataSummaryService dataSummaryService,
                      SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo,
                      CostSettingsMapper costSettingsMapper,
                      FinancialDetailsService financialDetailsService,
                      SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo,
                      ApplicationEventPublisher publisher) {
        this.dataSummaryService = dataSummaryService;
        this.subWorkstreamFinDetailsRepo = subWorkstreamFinDetailsRepo;
        this.costSettingsMapper = costSettingsMapper;
        this.financialDetailsService = financialDetailsService;
        this.subWorkStreamKeyDatesRepo = subWorkStreamKeyDatesRepo;
        this.publisher = publisher;
    }

    @Autowired
    public void setSubWorkStreamService(SubWorkStreamService subWorkStreamService) {
        this.subWorkStreamService = subWorkStreamService;
    }


    public HLERefDataResource getHLECostData(String workStreamId, String subWorkStreamId,
                                         String subWorkStreamName, String currencyCodeType, String scenario) {
        List<String> glCategories = getDataValues(PortfolioConstants.GL_CATEGORY_REF_DATA);
        List<String> costTypes = getDataValues(PortfolioConstants.COST_TYPE);
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = getSubWorkStreamKeyDatesEntity(workStreamId, subWorkStreamId,
                subWorkStreamName, scenario);
        log.info("subWorkStreamKeyDatesEntity Object : "+subWorkStreamKeyDatesEntity);
        List<SubWorkstreamFinDetailsEntity> finDetailsEntities = subWorkstreamFinDetailsRepo.
                findByWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndCostSettingAndScenarioAndOrgIndAndCostTypeIn(
                        workStreamId, subWorkStreamId, subWorkStreamName, PortfolioConstants.COST_SETTING_TYPE_HLE,
                        scenario, PortfolioConstants.ORIGINAL_INDICATOR_TRUE, costTypes);
        Map<String, List<SubWorkstreamFinDetailsEntity>> entitiesPerCostType = finDetailsEntities.stream()
                .collect(Collectors.groupingBy(SubWorkstreamFinDetailsEntity::getCostType));
        return costSettingsMapper.mapHLEEntityToResource(
                subWorkStreamKeyDatesEntity.getStartDate(), subWorkStreamKeyDatesEntity.getGoLiveDate(),
                entitiesPerCostType, currencyCodeType, scenario, glCategories, costTypes);
    }

    private List<String> getDataValues(String name) {
        List<DataValues> dataValuesList = dataSummaryService.getDataValuesBySummary(name);
        dataValuesList.sort(Comparator.comparing(DataValues::getAttr1));
        return dataValuesList.stream().map(DataValues::getValue).collect(Collectors.toList());
    }

    private SubWorkStreamKeyDatesEntity getSubWorkStreamKeyDatesEntity(String workStreamId, String subWorkStreamId, String
            subWorkStreamName, String scenario) {
        log.info("workStreamId : "+workStreamId);
        log.info("subWorkStreamId : "+subWorkStreamId);
        log.info("subWorkStreamName : "+subWorkStreamName);
        log.info("scenario : "+scenario);
        return subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(workStreamId,
                        subWorkStreamId, subWorkStreamName.trim(), "true", scenario.trim());
    }

    public List<SubWorkstreamFinDetailsEntity>
    saveHLEOperationCost(HLERefDataResource hleRefDataResource) {
        List<SubWorkstreamFinDetailsEntity> subWorkStreamFinDetailsEntities = Lists.newArrayList();
        List<HLECostType> hleCostTypes = getHleCostTypes(hleRefDataResource);
        for (HLECostType hleCostType : hleCostTypes) {
            subWorkStreamFinDetailsEntities.addAll(saveHLEOperationCostByYearMonth(hleRefDataResource,
                    hleCostType));
        }
        publisher.publishEvent(new CostSettingsUpdateEvent(hleRefDataResource.getSubWorkStreamId(),hleRefDataResource.getSubWorkStreamName()
                ,getCurrentYear(),PortfolioConstants.PROC_COST_COMP_HLE_FD));
        return subWorkStreamFinDetailsEntities;
    }

    public List<HLECostType> getHleCostTypes(HLERefDataResource hleRefDataResource){
        List<HLECostType> hleCostTypes = new ArrayList<>();
        hleRefDataResource.getFinancialInputGroup().forEach(financialInputGroupResource -> {
            hleCostTypes.addAll(financialInputGroupResource.getDynamicData());
        });
        return hleCostTypes;
    }

    private List<SubWorkstreamFinDetailsEntity>
    saveHLEOperationCostByYearMonth(
            HLERefDataResource hleRefDataResource,
            HLECostType hleCostType) {

        Optional<SubWorkstreamFinDetailsEntity> subWorkStreamFinDetailsEntityOptional =
                subWorkstreamFinDetailsRepo.findById(hleCostType.getHleSurrId());
        SubWorkstreamFinDetailsEntity finDetails = subWorkStreamFinDetailsEntityOptional.map(
                subWorkStreamFinDetailsEntity ->
                        updateHLEFundingOperationCost(hleRefDataResource, hleCostType,
                                subWorkStreamFinDetailsEntity)).orElseGet(
                () -> createNewHLEOperationCost(hleRefDataResource, hleCostType));
        List<SubWorkstreamFinDetailsEntity> subWorkStreamFinDetailsEntities = subWorkstreamFinDetailsRepo
                .findByRefSwsFdSurrIdAndOrgIndIgnoreCase(finDetails.getSubWorkStreamFinSurrId(), PortfolioConstants.FALSE);
        Map<String, Object> dateDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategoriesForResourcesIndividualContributorAndHLE(finDetails.getWorkstreamId(), finDetails.getSubWorkstreamId(), finDetails.getSubWorkstreamName(),
                finDetails.getScenario(),finDetails.getGlCategory(), PortfolioConstants.COST_SETTING_TYPE_HLE);
        String period = String.valueOf(dateDetails.get(PortfolioConstants.ACTUAL_PERIOD));
        List<String> monthBetweenDates = (List<String>) dateDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);

        return subWorkStreamFinDetailsEntities.isEmpty() ? createOperationCostsWithOriginalIndicatorFalse(hleRefDataResource.getCurrencyCodeType(),
                hleCostType.getValue(),
                monthBetweenDates,
                finDetails) :
                updateOperationCostsWithOriginalIndicatorFalse(monthBetweenDates, hleRefDataResource.getCurrencyCodeType(), period, finDetails,
                        hleCostType);
    }

    private SubWorkstreamFinDetailsEntity
    createNewHLEOperationCost(HLERefDataResource hleRefDataResource,
                                      HLECostType seedFundingCostType) {
        SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity = SubWorkstreamFinDetailsEntity.build(
                hleRefDataResource.getWorkStreamId(), hleRefDataResource.getSubWorkStreamId(),
                hleRefDataResource.getSubWorkStreamName(), seedFundingCostType.getGlCategoryName(),
                seedFundingCostType.getCostType(), getCurrentPeriod(),
                PortfolioConstants.COST_SETTING_TYPE_HLE,
                hleRefDataResource.getScenario(),
                PortfolioConstants.ORIGINAL_INDICATOR_TRUE, null);
        financialDetailsService.updateCurrencyValues(subWorkstreamFinDetailsEntity,hleRefDataResource.getCurrencyCodeType()
                , seedFundingCostType.getValue());
        return subWorkstreamFinDetailsRepo.save(subWorkstreamFinDetailsEntity);
    }

    private List<SubWorkstreamFinDetailsEntity>
    createOperationCostsWithOriginalIndicatorFalse(String hleRefDataResourceCurrencyCodeType,
                                                   BigDecimal hleCostTypeValue,
                                                   List<String> currentYearMonthBetweenDates,
                                                   SubWorkstreamFinDetailsEntity finDetails) {
        if (!currentYearMonthBetweenDates.isEmpty()) {
            List<SubWorkstreamFinDetailsEntity> finDetailsEntityList = currentYearMonthBetweenDates.stream().map(
                    yearMonth -> {
                        SubWorkstreamFinDetailsEntity finDetailsEntity = SubWorkstreamFinDetailsEntity.build(finDetails.getWorkstreamId(),
                                finDetails.getSubWorkstreamId(), finDetails.getSubWorkstreamName(),
                                finDetails.getGlCategory(), finDetails.getCostType(), yearMonth,
                                finDetails.getCostSetting(), finDetails.getScenario(),
                                PortfolioConstants.ORIGINAL_INDICATOR_FALSE,
                                finDetails.getSubWorkStreamFinSurrId());
                        financialDetailsService.updateCurrencyValuesMonthly(
                                hleRefDataResourceCurrencyCodeType,
                                hleCostTypeValue,
                                currentYearMonthBetweenDates, finDetailsEntity);
                        return finDetailsEntity;
                    }).collect(Collectors.toList());
            return subWorkstreamFinDetailsRepo.saveAll(finDetailsEntityList);
        }
        return Lists.newArrayList();
    }

    private SubWorkstreamFinDetailsEntity
    updateHLEFundingOperationCost(HLERefDataResource hleRefDataResource,
                                  HLECostType hleCostType,
                                  SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity) {
        financialDetailsService.updateCurrencyValues(subWorkstreamFinDetailsEntity,hleRefDataResource.getCurrencyCodeType()
                , hleCostType.getValue());
        return subWorkstreamFinDetailsRepo.save(subWorkstreamFinDetailsEntity);
    }

    private String getCurrentPeriod() {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String startDateString = df.format(Date.from(Instant.now()));
        return startDateString.substring(0, 7).replaceAll("-", "");
    }

    public void updateHLEDataForRevisedKeyDates(SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity, String currencyCode){
        try {
                List<SubWorkstreamFinDetailsEntity> subWorkstreamFinDetailsEntityList =
                        subWorkstreamFinDetailsRepo.findByScenarioAndWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndOrgInd(
                                subWorkStreamKeyDatesEntity.getScenarioName(), subWorkStreamKeyDatesEntity.getWorkStreamId(),
                                subWorkStreamKeyDatesEntity.getSubWorkStreamId(),
                                subWorkStreamKeyDatesEntity.getSubWorkStreamName(), PortfolioConstants.TRUE);

                if(subWorkstreamFinDetailsEntityList.size() > 0 ) {
                    subWorkstreamFinDetailsEntityList.forEach(subWorkstreamFinDetailsEntity->{
                    Map<String, Object> dateDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategoriesForResourcesIndividualContributorAndHLE(subWorkStreamKeyDatesEntity.getWorkStreamId(),
                            subWorkStreamKeyDatesEntity.getSubWorkStreamId(), subWorkStreamKeyDatesEntity.getSubWorkStreamName(), subWorkStreamKeyDatesEntity.getScenarioName(),
                            subWorkstreamFinDetailsEntity.getGlCategory(), PortfolioConstants.COST_SETTING_TYPE_HLE);
                    String period = String.valueOf(dateDetails.get(PortfolioConstants.ACTUAL_PERIOD));
                    List<String> monthBetweenDates = (List<String>) dateDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);
                    updateOperationCostsWithOriginalIndicatorFalse(monthBetweenDates, currencyCode, period, subWorkstreamFinDetailsEntity,
                            null);
                    });
                }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private List<SubWorkstreamFinDetailsEntity>
    updateOperationCostsWithOriginalIndicatorFalse(List<String> monthBetweenDates,
                                                   String currencyCode,
                                                   String period,
                                                   SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity,
                                                   HLECostType hleCostType){
        List<SubWorkstreamFinDetailsEntity> subWorkStreamFinDetailsEntities = Lists.newArrayList();
//        BigDecimal currencyAddedForSplit;
//        if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)) {
//            currencyAddedForSplit = subWorkstreamFinDetailsRepo.getCostSettingsSumForActualsByGrpCcy(subWorkstreamFinDetailsEntity.getWorkstreamId(),
//                    subWorkstreamFinDetailsEntity.getSubWorkstreamId(), subWorkstreamFinDetailsEntity.getSubWorkstreamName(),
//                    subWorkstreamFinDetailsEntity.getScenario(), PortfolioConstants.COST_SETTING_TYPE_HLE,
//                    subWorkstreamFinDetailsEntity.getCostType(), subWorkstreamFinDetailsEntity.getGlCategory(), period);
//        }else {
//            currencyAddedForSplit = subWorkstreamFinDetailsRepo.getCostSettingsSumForActualsByLocalCcy(subWorkstreamFinDetailsEntity.getWorkstreamId(),
//                    subWorkstreamFinDetailsEntity.getSubWorkstreamId(), subWorkstreamFinDetailsEntity.getSubWorkstreamName(),
//                    subWorkstreamFinDetailsEntity.getScenario(), PortfolioConstants.COST_SETTING_TYPE_HLE,
//                    subWorkstreamFinDetailsEntity.getCostType(), subWorkstreamFinDetailsEntity.getGlCategory(), period);
//        }
//        BigDecimal currencySubtracted;
//        if(hleCostType!=null && hleCostType.getValue() != null){ //Update from HLE tab
//            if(!BigDecimal.ZERO.equals(currencyAddedForSplit))
//                currencySubtracted =  hleCostType.getValue().subtract(currencyAddedForSplit);
//            else currencySubtracted = hleCostType.getValue();
//        } else{ // edit from sub workstream keydates
//            if(!BigDecimal.ZERO.equals(currencyAddedForSplit))
//                currencySubtracted = (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
//                        subWorkstreamFinDetailsEntity.getGroupCcyVal(): subWorkstreamFinDetailsEntity.getLocalCcyVal()).subtract(currencyAddedForSplit);
//            else currencySubtracted = (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
//                    subWorkstreamFinDetailsEntity.getGroupCcyVal(): subWorkstreamFinDetailsEntity.getLocalCcyVal());
//        }
        BigDecimal currencySubtracted;
        if(hleCostType!=null && hleCostType.getValue() != null){ //Update from HLE tab
                currencySubtracted =  hleCostType.getValue();
        } else{ // edit from sub workstream keydates
                currencySubtracted = (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    subWorkstreamFinDetailsEntity.getGroupCcyVal(): subWorkstreamFinDetailsEntity.getLocalCcyVal());
        }
        subWorkstreamFinDetailsRepo.deleteAllByWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndScenarioAndAndCostTypeAndGlCategoryAndOrgIndAndCostTypeDetailAndAndCostSetting(
                subWorkstreamFinDetailsEntity.getWorkstreamId(), subWorkstreamFinDetailsEntity.getSubWorkstreamId(),subWorkstreamFinDetailsEntity.getSubWorkstreamName(),
                subWorkstreamFinDetailsEntity.getScenario(), subWorkstreamFinDetailsEntity.getCostType(),
                subWorkstreamFinDetailsEntity.getGlCategory(), PortfolioConstants.FALSE, subWorkstreamFinDetailsEntity.getScenario(), PortfolioConstants.COST_SETTING_TYPE_HLE);

        subWorkStreamFinDetailsEntities.addAll(createOperationCostsWithOriginalIndicatorFalse(
                (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        subWorkstreamFinDetailsEntity.getGroupCcy(): subWorkstreamFinDetailsEntity.getLocalCcy()) , currencySubtracted,
                monthBetweenDates, subWorkstreamFinDetailsEntity));
        return subWorkStreamFinDetailsEntities;
    }

}
