package com.dbs.genesis.portfolio.model;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Data
@Table(name = "work_hierarchy")
@Entity
@EntityListeners(AuditingEntityListener.class)
public class WorkHierarchyEntity extends CommonEntity<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "work_hier_surr_id")
    private int workHierarchySurrId;

    @Column(name = "portfolio_id")
    private String portfolioId;

    @Column(name = "portfolio_name")
    private String portfolioName;

    @Column(name = "workstream_id")
    private String workStreamId;

    @Column(name = "workstream_name")
    private String workStreamName;

    @Column(name = "sub_workstream_id")
    private String subWorkStreamId;

    @Column(name = "sub_workstream_name")
    private String subWorkStreamName;



}
