package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.EditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.sql.Timestamp;

@Repository
public interface EditLogRepo extends JpaRepository<EditLog ,Long> {

    EditLog findByPortfolioIdAndPortfolioNameAndPortfolioType(String portfolioId,String portfolioName,String portfolioType);

    void deleteByPortfolioIdAndPortfolioNameAndPortfolioType(String portfolioId,String portfolioName,String portfolioType);

    @Transactional
    void deleteByDateModifiedBefore(Timestamp dateCreted);
}
