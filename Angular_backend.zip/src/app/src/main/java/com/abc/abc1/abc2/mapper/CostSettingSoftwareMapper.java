package com.dbs.genesis.portfolio.mapper;

import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import com.dbs.genesis.portfolio.resources.SubWorkStreamSoftwareCostResource;
import com.dbs.genesis.portfolio.resources.SubWorkStreamSoftwareCostResourceHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Component
public class CostSettingSoftwareMapper {

    public List<SubWorkStreamSoftwareCostResourceHolder> getVendorNameWithSoftwareList(
            List<SubWorkStreamSoftwareCostResource> subWorkStreamSoftwareCostResources){
        List<SubWorkStreamSoftwareCostResourceHolder> subWorkStreamHardwareCostResourceHolders = new ArrayList<>();
        Map<String, List<SubWorkStreamSoftwareCostResource>> entitiesPerVendor = subWorkStreamSoftwareCostResources.stream()
                .collect(Collectors.groupingBy(SubWorkStreamSoftwareCostResource::getVendor));
        entitiesPerVendor.forEach((name, values)->{
            SubWorkStreamSoftwareCostResourceHolder subWorkStreamSoftwareCostResourceHolder = new SubWorkStreamSoftwareCostResourceHolder();
            subWorkStreamSoftwareCostResourceHolder.setVendorName(name);
            subWorkStreamSoftwareCostResourceHolder.setSoftware(values);
            subWorkStreamHardwareCostResourceHolders.add(subWorkStreamSoftwareCostResourceHolder);
        });
        return subWorkStreamHardwareCostResourceHolders;
    }
}