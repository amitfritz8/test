package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.PcCodeTree;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PcCodeTreeRepo extends JpaRepository<PcCodeTree, String> {
    List<PcCodeTree> findByPlatformIndex(String platformIndex);


    @Query(value = "SELECT DISTINCT le_pccode FROM xref_le_pccode_tree WHERE country_code=:countryCode AND platform_index!='NP'", nativeQuery = true)
    List<String> findByCountryCode(@Param("countryCode") String countryCode);

    List<PcCodeTree> findByPlatformIndexIsNot(String platformIndex);

}

