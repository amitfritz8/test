package com.dbs.genesis.portfolio.model.copyscenario;

import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamOtherCost;
import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class SubWorkStreamOtherCostCopyHolder {

//    private Map<SubWorkstreamOtherCost, List<SubWorkstreamOtherCost>>
//            otherCostOriginalIndWithChildren = new HashMap<>();

    private List<SubWorkStreamOtherOpexCopyHolder> otherOpexCopyHolders =
            new ArrayList<>();

    private List<SubWorkStreamOtherCapexCopyHolder> otherCapexCopyHolders =
            new ArrayList<>();
}
