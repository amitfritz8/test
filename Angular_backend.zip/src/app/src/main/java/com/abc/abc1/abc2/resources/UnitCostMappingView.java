package com.dbs.genesis.portfolio.resources;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Lists;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class UnitCostMappingView {

    int refSurrId;
    String name;
    String currencyCode;
    String currencyValue;
    String unitPriceValue;
    String periodType;

    BigDecimal fdManDays;
    BigDecimal blendedCost;

    List<UnitCostResource> monthlyResourcesUnits;
    List<UnitCostResource> monthlyResourcesCosts;

    List<UnitCostResource> monthlyResourcesFTEs;
    List<UnitCostResource> monthlyResourcesManDays;
    List<UnitCostResource> monthlyResourcesAllocations;


    List<BigDecimal> quarterlyUnitTotal = Lists.newArrayList();
    List<BigDecimal> quarterlyCostTotal = Lists.newArrayList();

    List<BigDecimal> quarterlyFTETotal = new ArrayList<>();
    List<BigDecimal> quarterlyAllocationTotal = new ArrayList<>();
    List<BigDecimal> quarterlyMandaysTotal = new ArrayList<>();


    List<BigDecimal> yearlyUnitTotal = Lists.newArrayList();
    List<BigDecimal> yearlyCostTotal = Lists.newArrayList();

    List<BigDecimal> yearlyFTETotal = Lists.newArrayList();
    List<BigDecimal> yearlyAllocationTotal = Lists.newArrayList();
    List<BigDecimal> yearlyMandaysTotal = Lists.newArrayList();


    BigDecimal unitOverAllTotal = BigDecimal.ZERO;
    BigDecimal costOverAllTotal = BigDecimal.ZERO;
    BigDecimal fteOverAllTotal = BigDecimal.ZERO;
    BigDecimal manDaysOverAllTotal = BigDecimal.ZERO;
    BigDecimal alloCOverAllTotal = BigDecimal.ZERO;


    BigDecimal yearlyCostOverAllTotal = BigDecimal.ZERO;
    BigDecimal yearlyUnitOverAllTotal = BigDecimal.ZERO;

    BigDecimal yearlyFTEOverAllTotal = BigDecimal.ZERO;
    BigDecimal yearlyAllocationOverAllTotal = BigDecimal.ZERO;
    BigDecimal yearlyMandaysOverAllTotal = BigDecimal.ZERO;


    public void addYearlyUnitTotal(BigDecimal yearlyUnit) {
        yearlyUnitTotal.add(yearlyUnit);
    }

    public void addYearlyCostTotal(BigDecimal yearlyCost) {
        yearlyCostTotal.add(yearlyCost);
    }

    public void addYearlyFTETotal(BigDecimal yearlyFTE) {
        yearlyFTETotal.add(yearlyFTE);
    }

    public void addyearlyAllocationTotal(BigDecimal yearlyAllocation) {
        yearlyAllocationTotal.add(yearlyAllocation);
    }

    public void addYearlyMandaysTotal(BigDecimal yearlyManDays) {
        yearlyMandaysTotal.add(yearlyManDays);
    }


}
