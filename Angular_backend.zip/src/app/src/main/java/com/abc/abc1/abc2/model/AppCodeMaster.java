package com.dbs.genesis.portfolio.model;


import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Data
@Entity
@Table(name = "xref_app_code_master")
@EntityListeners(AuditingEntityListener.class)
public class AppCodeMaster extends CommonEntity<String> {

    @Id
    @Column(name = "app_code_id")
    private int appCodeSurrId;
    @Column(name = "app_code_name")
    private String appCodeName;
    @Column(name = "app_code")
    private String appCode;
    @Column(name = "host_country")
    private String hostCountry;
    @Column(name = "lobt")
    private String lobt;
    @Column(name = "host_app_code")
    private String hostAppCode;
    @Column(name = "platform_name")
    private String platformName;
    @Column(name = "category")
    private String category;
    @Column(name = "app_owner")
    private String appOwner;
    @Column(name = "primary_app_mgr")
    private String primaryAppManager;
    @Column(name = "secondary_app_mgr")
    private String secondaryAppManager;
    @Column(name = "app_code_desc")
    private String appCodeDescription;
    @Column(name = "used_in_country")
    private String usedInCountry;
    @Column(name = "status")
    private String status;
    @Column(name = "system_type")
    private String systemType;
    @Column(name = "requestor_name")
    private String requestorName;
    @Column(name = "appcode_and_name")
    private String appcodeAndName;
    @Column(name = "appcode_included")
    private String appCodeIncluded;



}
