package com.dbs.genesis.portfolio.controller;

import com.dbs.genesis.portfolio.resources.CopyScenarioRequest;
import com.dbs.genesis.portfolio.service.PortFolioWorkStreamCopyScenarioService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Set;

@Slf4j
@RestController
@RequestMapping("/data/copy")
public class CopyController {

    private final PortFolioWorkStreamCopyScenarioService copyScenarioService;

    public CopyController(PortFolioWorkStreamCopyScenarioService copyScenarioService) {
        this.copyScenarioService = copyScenarioService;
    }

    @GetMapping("/scenarios")
    public ResponseEntity scenarios(String requestType) {
        Set<String> scenarios = copyScenarioService.getScenarios(requestType);
        return ResponseEntity.ok().body(scenarios);
    }

    @GetMapping("/scenariosForCopyApproval")
    public ResponseEntity scenariosForApproval(
            @RequestParam("requestType") String requestType, @RequestParam("id") String id) {
        Set<String> pendingScenarios = copyScenarioService.getScenariosForApproval(requestType, id);
        return ResponseEntity.ok().body(pendingScenarios);
    }

    @PostMapping("/copyScenario")
    public ResponseEntity copyScenario(@RequestBody CopyScenarioRequest copyScenarioRequest){
        return ResponseEntity.ok().body(copyScenarioService.copyScenario(copyScenarioRequest));
    }

    @PostMapping("/approveCopyScenario")
    public Boolean approveCopyScenario(@RequestParam("file") MultipartFile[] multipartFiles,
                                       @RequestParam("description")String description,
                                       @RequestParam("portfolioId")String portfolioId,
                                       @RequestParam("workStreamId")String workStreamId,
                                       @RequestParam("workStreamName")String workStreamName,
                                       @RequestParam("scenarioTo")String scenarioTo,
                                       @RequestParam("approvalDate")String approvalDate,
                                       @RequestParam("createdBy")String createdBy
    ) {
        return copyScenarioService.approveCopyScenario(multipartFiles , portfolioId, workStreamId,
                scenarioTo, approvalDate, description, createdBy);
    }

    @GetMapping("/copySnapshotFromScenarios")
    public ResponseEntity getCopySnapshotFromScenarios() {
        List<String> scenarios = copyScenarioService.getCopySnapshotFromScenarios();
        return ResponseEntity.ok().body(scenarios);
    }

    @GetMapping("/copySnapshotToScenarios/{scenarioName}")
    public ResponseEntity getCopySnapshotToScenarios(@PathVariable("scenarioName") String scenarioName) {
        List<String> scenarios = copyScenarioService.getCopySnapshotToScenarios(scenarioName);
        return ResponseEntity.ok().body(scenarios);
    }

    @PostMapping("/copySnapshot")
    public ResponseEntity copySnapshot(@RequestBody CopyScenarioRequest copyScenarioRequest) {
        copyScenarioService.copySnapshot(copyScenarioRequest);
        return ResponseEntity.ok().body("Success");
    }


}
