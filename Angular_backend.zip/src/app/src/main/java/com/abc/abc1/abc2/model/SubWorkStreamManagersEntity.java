package com.dbs.genesis.portfolio.model;

import com.dbs.genesis.portfolio.resources.SubWorkStreamManagerResource;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Date;

@Data
@Table(name = "sub_workstream_managers")
@Entity
@EntityListeners(AuditingEntityListener.class)
@ToString
public class SubWorkStreamManagersEntity extends CommonEntity<String> {


    @Id
    @Column(name = "subws_mgr_surr_id")
    private int subWsMgrSurrId;
    @Column(name = "workstream_id")
    private String workStreamId;
    @Column(name = "sub_workstream_id")
    private String subWorkStreamId;
    @Column(name = "1bank_id")
    private String oneBankId;
    @Column(name = "staff_name")
    private String staffName;
    @Column(name = "role")
    private String role;
    @Column(name = "platform_index")
    private String platformIndex;
    @Column(name = "email_address")
    private String emailAddress;
    @Column(name = "effective_start_date")
    private Date effectiveStartDate;
    @Column(name = "effective_end_date")
    private Date effectiveEndDate;
    @Column(name = "delegate_ind")
    private String delegateInd;
    @Column(name = "active_ind")
    private String activeInd;
    @Column(name = "sub_workstream_name")
    private String subWorkStreamName;

    public SubWorkStreamManagerResource toSubWorkStreamManagerResource() {
        SubWorkStreamManagerResource subWorkStreamManagerResource = new SubWorkStreamManagerResource();
        subWorkStreamManagerResource.setSubWsMgrSurrId(getSubWsMgrSurrId());
        subWorkStreamManagerResource.setWorkStreamId(getWorkStreamId());
        subWorkStreamManagerResource.setSubWorkStreamId(getSubWorkStreamId());
        subWorkStreamManagerResource.setOneBankId(getOneBankId());
        subWorkStreamManagerResource.setStaffName(getStaffName());
        subWorkStreamManagerResource.setRole(getRole());
        subWorkStreamManagerResource.setPlatformIndex(getPlatformIndex());
        subWorkStreamManagerResource.setEmailAddress(getEmailAddress());
        subWorkStreamManagerResource.setEffectiveStartDate(getEffectiveStartDate());
        subWorkStreamManagerResource.setEffectiveEndDate(getEffectiveEndDate());
        subWorkStreamManagerResource.setDelegateInd(getDelegateInd());
        return subWorkStreamManagerResource;
    }
}




