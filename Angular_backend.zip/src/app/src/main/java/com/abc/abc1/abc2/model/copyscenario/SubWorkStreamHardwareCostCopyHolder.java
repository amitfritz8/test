package com.dbs.genesis.portfolio.model.copyscenario;

import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class SubWorkStreamHardwareCostCopyHolder {

//    private Map<SubWorkstreamHardwareCost, List<SubWorkstreamHardwareCost>>
//            hardwareCostOriginalIndWithChildren = new HashMap<>();

    private List<SubWorkStreamHardwareOpexCopyHolder> hardwareOpexCopyHolders =
            new ArrayList<>();
}
