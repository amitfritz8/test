package com.dbs.genesis.portfolio.resources;

import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamOtherCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.codehaus.jackson.annotate.JsonIgnore;

import java.sql.Date;
import java.util.List;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class FinancialDetailsResource {
    private String workStreamId;
    private String subWorkStreamId;
    private String subWorkStreamName;
    //private String userLoggedInCountry;
    private String scenario;
    private Date startDate;
    private Date goLiveDate;
    private String addSoftware;
    private String addHardware;
    private String team;

    private List<SubWorkStreamTeamFormationResourceHolder> teams;
    private List<SubWorkStreamResourceCostResource> individualContributors;
    private List<SubWorkStreamSoftwareCostResourceHolder> softwares;
    private List<SubWorkStreamHardwareCostResourceHolder> hardwares;
    private List<SubWorkStreamOtherCostResource> otherSoftware;
    private List<SubWorkStreamOtherCostResource> otherHardware;
    private List<SubWorkStreamOtherCostResource> otherResource;
    private List<SubWorkStreamOtherCostResource> others;

}
