package com.dbs.genesis.portfolio.service;

import com.amazonaws.util.CollectionUtils;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.enums.ScenarioConfigType;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.model.copyscenario.*;
import com.dbs.genesis.portfolio.repository.*;
import com.dbs.genesis.portfolio.resources.CopyScenarioKeyDatesApproveDataHolder;
import com.dbs.genesis.portfolio.resources.CopyScenarioRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@Transactional
public class PortFolioWorkStreamCopyScenarioService {

    @Autowired
    private SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo;
    @Autowired
    private SubWorkstreamSoftwareCostRepo subWorkstreamSoftwareCostRepo;
    @Autowired
    private SubWorkstreamHardwareCostRepo subWorkstreamHardwareCostRepo;
    @Autowired
    private SubWorkStreamResourceCostRepo subWorkStreamResourceCostRepo;
    @Autowired
    private SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo;
    @Autowired
    private WorkHierarchyRepo workHierarchyRepo;
    @Autowired
    private XrefScenarioConfigRepo xrefScenarioConfigRepo;
    @Autowired
    private WorkStreamKeyDatesRepo workStreamKeyDatesRepo;
    @Autowired
    private SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    @Autowired
    private WorkStreamApproverRepo workStreamApproverRepo;
    @Autowired
    private SubWorkStreamApprovesRepo subWorkStreamApproverRepo;
    @Autowired
    private S3StorageService s3StorageService;

    @Autowired
    private CopyRepository copyRepository;

    private static List<String> getForecastCostSettings() {

        List<String> costSettings = new ArrayList<>();
        costSettings.add(PortfolioConstants.COST_SETTING_TYPE_HLE);
        costSettings.add(PortfolioConstants.COST_SETTING_TYPE_SEED_FUNDING);
        return costSettings;
    }

    List<WorkHierarchyEntity> getWorkHierarchy(String portfolioId, String workStreamId) {
        if (StringUtils.isEmpty(workStreamId)) {
            return workHierarchyRepo.getByPortfolioId(portfolioId);
        }
        return workHierarchyRepo.findByPortfolioIdAndWorkStreamId(portfolioId, workStreamId);
    }

    public Boolean approveCopyScenario(MultipartFile[] multipartFiles, String portfolioId,
                                       String workStreamId, String scenarioTo, String approvalDate,
                                       String description, String createdBy) {
        Boolean status = false;
        List<WorkHierarchyEntity> workHierarchyList = getWorkHierarchy(portfolioId, workStreamId);
        List<String> workStreamIds = workHierarchyList.stream().map(WorkHierarchyEntity::getWorkStreamId).distinct().collect(Collectors.toList());
        if (multipartFiles != null) {
            log.info("Total files for upload:- " + multipartFiles.length);
        } else {
            log.info("No file found for upload ");
        }

        if (uploadCopyScenarioFiles(multipartFiles, workHierarchyList, description, createdBy, approvalDate)) {
            log.info("File uploading completed, proceeding for copy scenario approval for WorkStreamIds:- " + workStreamIds);
            String approvalScenarioName = getScenarioForApproval(scenarioTo);
            updatePendingCopyScenarioFinancialsByApprove(scenarioTo, approvalScenarioName, workStreamIds);
            Integer updatedWorkStreamRecords = workStreamKeyDatesRepo.updateApprovalDateAndScenarioForWorkStreamsAndScenario(workStreamIds,
                    scenarioTo, convertStrToDate(approvalDate), approvalScenarioName);
            log.info("CopyScenario WorkStream records approved for WorkStreams: " + updatedWorkStreamRecords);
            Integer updatedSubWorkStreamRecords = subWorkStreamKeyDatesRepo.updateApprovalDateAndScenarioForWorkStreamsAndScenario(workStreamIds,
                    scenarioTo, convertStrToDate(approvalDate), approvalScenarioName);
            log.info("CopyScenario SubWorkStream records approved for WorkStreams: " + updatedSubWorkStreamRecords);
            workStreamApproverRepo.updateApprovalScenarioForWorkStreamsAndScenario(
                    workStreamIds, scenarioTo, approvalScenarioName);
            subWorkStreamApproverRepo.updateApprovalScenarioForWorkStreamsAndScenario(
                    workStreamIds, scenarioTo, approvalScenarioName);
            log.info("Copy Scenario approval done for WorkStreamIds:- " + workStreamIds);
            status = true;
        }
        return status;
    }

    private void updatePendingCopyScenarioFinancialsByApprove(String scenarioTo,
                                                              String approvalScenarioName, List<String> workStreamIds){
        //Update scenario for forecast
        subWorkstreamFinDetailsRepo.updateForcastApprovalScenarioForWorkStreamsAndScenario(
                workStreamIds, scenarioTo, approvalScenarioName, getForecastCostSettings());
        //Update scenario for Actuals
        subWorkstreamFinDetailsRepo.updateActualApprovalScenarioForWorkStreamsAndScenario(
                workStreamIds, scenarioTo, approvalScenarioName, PortfolioConstants.COST_TYPE_DETAIL_ACTUAL);
        subWorkstreamSoftwareCostRepo.updateApprovalScenarioForWorkStreamsAndScenario(
                workStreamIds, scenarioTo, approvalScenarioName);
        subWorkstreamHardwareCostRepo.updateApprovalScenarioForWorkStreamsAndScenario(
                workStreamIds, scenarioTo, approvalScenarioName);
        subWorkStreamResourceCostRepo.updateApprovalScenarioForWorkStreamsAndScenario(
                workStreamIds, scenarioTo, approvalScenarioName);
        subWorkstreamOtherCostRepo.updateApprovalScenarioForWorkStreamsAndScenario(
                workStreamIds, scenarioTo, approvalScenarioName);
    }


    private Boolean uploadCopyScenarioFiles(MultipartFile[] multipartFiles, List<WorkHierarchyEntity> workHierarchyList,
                                            String description, String createdBy, String dateCreated) {
        Map<String, List<WorkHierarchyEntity>> workHierarchyMapByWorkStreamId = workHierarchyList.stream()
                .collect(Collectors.groupingBy(WorkHierarchyEntity::getWorkStreamId));
        workHierarchyMapByWorkStreamId.entrySet().forEach(workHierarchy -> {
            for (MultipartFile multipartFile : multipartFiles) {
                if (multipartFile.getSize() > 0) {
                    log.info("File uploading process initiated for file:- " + multipartFile.getOriginalFilename());
                    s3StorageService.uploadFile(multipartFile, 0, workHierarchy.getValue().get(0).getPortfolioId(),
                            workHierarchy.getValue().get(0).getWorkStreamId(), multipartFile.getOriginalFilename(),
                            PortfolioConstants.COPY_SCENARIO_FILE_UPLOAD_TYPE_OTHERS, description, PortfolioConstants.TRUE,
                            null, createdBy, dateCreated, createdBy,
                            dateCreated, workHierarchy.getValue().get(0).getWorkStreamName());
                } else {
                    log.info("File size is 0, uploading not initiated.");
                }
            }
        });
        return true;
    }

    private Date convertStrToDate(String dateString) {
        SimpleDateFormat sfdate = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sfdate.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Map<String, List<String>> copyScenario(CopyScenarioRequest copyScenarioRequest) {
        List<WorkHierarchyEntity> workHierarchyList = getWorkHierarchy(
                copyScenarioRequest.getPortFolioId(), copyScenarioRequest.getWorkStreamId());
        Map<String, List<String>> workStreamIdAndSubWorkStreamIdsMap = new HashMap<>();
        Map<String, List<WorkHierarchyEntity>> workStreamAndSubWorkStreamsMap = workHierarchyList.stream()
                .collect(Collectors.groupingBy(WorkHierarchyEntity::getWorkStreamId));

        workStreamAndSubWorkStreamsMap.forEach((key, value) -> {
            List<String> subWorkStreams = value.stream().map(WorkHierarchyEntity::getSubWorkStreamId).collect(Collectors.toList());
            workStreamIdAndSubWorkStreamIdsMap.put(key, subWorkStreams);
        });
        PortFolioCopyHierarchy portFolioCopyHierarchy = fetchDbDataForCopyScenario(workStreamIdAndSubWorkStreamIdsMap,
                copyScenarioRequest);
        CopyScenarioKeyDatesApproveDataHolder keyDatesApproveDataHolder =
                fetchDbDataForKeyDatesAndApprovers(workStreamIdAndSubWorkStreamIdsMap, copyScenarioRequest);
        String scenarioTo = copyScenarioRequest.getScenarioTo();
        //Persisting to DB
        List<WorkStreamCopyHierarchy> workStreamCopyHierarchies = portFolioCopyHierarchy.getWorkStreamCopyHierarchies();
        if (!CollectionUtils.isNullOrEmpty(workStreamCopyHierarchies)) {
            workStreamCopyHierarchies.forEach(workStreamCopyHierarchy -> {
                List<SubWorkStreamCopyHierarchy> subWorkStreamCopyHierarchies =
                        workStreamCopyHierarchy.getSubWorkStreamCopyHierarchies();
                if (!CollectionUtils.isNullOrEmpty(subWorkStreamCopyHierarchies)) {
                    subWorkStreamCopyHierarchies.forEach(subWorkStreamCopyHierarchy -> {
                        ScenarioCopyHierarchy scenarioCopyHierarchy = subWorkStreamCopyHierarchy.getScenarioCopyHierarchy();
                        copyForcastFinDetails(scenarioTo, scenarioCopyHierarchy);
                        copyActualsFinDetails(scenarioTo, scenarioCopyHierarchy);
                        copySoftware(scenarioTo, scenarioCopyHierarchy);
                        copyHardware(scenarioTo, scenarioCopyHierarchy);
                        copyResource(scenarioTo, scenarioCopyHierarchy);
                        copyOthers(scenarioTo, scenarioCopyHierarchy);
                    });
                }
            });
        }
        //Persisting KeyDates/Approvers to db
        if (!CollectionUtils.isNullOrEmpty(keyDatesApproveDataHolder.getWorkStreamApprovers())) {
            copyWorkStreamApprovers(scenarioTo, keyDatesApproveDataHolder.getWorkStreamApprovers());
        }
        if (!CollectionUtils.isNullOrEmpty(keyDatesApproveDataHolder.getWorkStreamKeyDatesEntities())) {
            copyWorkStreamKeyDates(scenarioTo, keyDatesApproveDataHolder.getWorkStreamKeyDatesEntities());
        }
        if (!CollectionUtils.isNullOrEmpty(keyDatesApproveDataHolder.getSubWorkStreamApprovers())) {
            copySubWorkStreamApprovers(scenarioTo, keyDatesApproveDataHolder.getSubWorkStreamApprovers());
        }
        if (!CollectionUtils.isNullOrEmpty(keyDatesApproveDataHolder.getSubWorkStreamKeyDatesEntities())) {
            copySubWorkStreamKeyDates(scenarioTo, keyDatesApproveDataHolder.getSubWorkStreamKeyDatesEntities());
        }
        return workStreamIdAndSubWorkStreamIdsMap;
    }

    private void copyOthers(String scenarioTo, ScenarioCopyHierarchy scenarioCopyHierarchy) {
        SubWorkStreamOtherCostCopyHolder otherCostCopyHolder =
                scenarioCopyHierarchy.getOtherCostCopyHolder();
        if (otherCostCopyHolder == null ||
                (CollectionUtils.isNullOrEmpty(otherCostCopyHolder.getOtherCapexCopyHolders()) &&
                        (CollectionUtils.isNullOrEmpty(otherCostCopyHolder.getOtherOpexCopyHolders())))) {
            log.warn("No OtherCost records to copy to Scenario: "+scenarioTo);
            return;
        }
        List<String> deletableScenarios = getDeletableScenariosForCopy(scenarioTo);
        subWorkstreamOtherCostRepo.deleteAllByWorkStreamIdAndSubWorkStreamIdAndScenarioIn(
                scenarioCopyHierarchy.getWorkStreamId(),
                scenarioCopyHierarchy.getSubWorkStreamId(), deletableScenarios);

        //Opex/Ownership
        List<SubWorkStreamOtherOpexCopyHolder>
                otherOpexCopyHolders = otherCostCopyHolder.getOtherOpexCopyHolders();
        otherOpexCopyHolders.forEach(otherOpexCopyHolder->{
            //Opex cost data
            Integer opexId = 0;
            SubWorkstreamOtherCost otherOpexParentEntity = (SubWorkstreamOtherCost)
                    SerializationUtils.clone(otherOpexCopyHolder.getSubWorkStreamOtherOpexCostParent());
            otherOpexParentEntity.setSwsOtherSurrId(null);
            otherOpexParentEntity.setScenario(scenarioTo);
            SubWorkstreamOtherCost clonedOtherOpexParentEntity = subWorkstreamOtherCostRepo.save(otherOpexParentEntity);
            opexId = clonedOtherOpexParentEntity.getSwsOtherSurrId();
            List<SubWorkstreamOtherCost> opexChildrenEntitiesCloned =
                    alignOtherCostChildrenWithParent(clonedOtherOpexParentEntity,
                            otherOpexCopyHolder.getSubWorkStreamOtherOpexCostChildren(),
                            opexId);
            subWorkstreamOtherCostRepo.saveAll(opexChildrenEntitiesCloned);

            //Ownership Cost data
            SubWorkstreamOtherCost otherOwnershipParentEntity = (SubWorkstreamOtherCost)
                    SerializationUtils.clone(otherOpexCopyHolder.getSubWorkStreamOtherOwnershipCostParent());
            otherOwnershipParentEntity.setSwsOtherSurrId(null);
            otherOwnershipParentEntity.setScenario(scenarioTo);
            otherOwnershipParentEntity.setCapexOpexSurrId(opexId);

            SubWorkstreamOtherCost clonedOtherOwnershipParentEntity = subWorkstreamOtherCostRepo.save(otherOwnershipParentEntity);
            List<SubWorkstreamOtherCost> ownershipChildrenEntitiesCloned =
                    alignOtherCostChildrenWithParent(clonedOtherOwnershipParentEntity,
                            otherOpexCopyHolder.getSubWorkStreamOtherOwnershipCostChildren(),
                            opexId);
            subWorkstreamOtherCostRepo.saveAll(ownershipChildrenEntitiesCloned);
        });

        //Capex/ITDepreciation
        List<SubWorkStreamOtherCapexCopyHolder>
                otherCapexCopyHolders = otherCostCopyHolder.getOtherCapexCopyHolders();
        otherCapexCopyHolders.forEach(otherCapexCopyHolder->{
            //Capex cost data
            Integer capexId = 0;
            SubWorkstreamOtherCost otherCapexParentEntity = (SubWorkstreamOtherCost)
                    SerializationUtils.clone(otherCapexCopyHolder.getSubWorkStreamOtherCapexCostParent());
            otherCapexParentEntity.setSwsOtherSurrId(null);
            otherCapexParentEntity.setScenario(scenarioTo);
            SubWorkstreamOtherCost clonedOtherCapexParentEntity = subWorkstreamOtherCostRepo.save(otherCapexParentEntity);
            capexId = clonedOtherCapexParentEntity.getSwsOtherSurrId();
            List<SubWorkstreamOtherCost> capexChildrenEntitiesCloned =
                    alignOtherCostChildrenWithParent(clonedOtherCapexParentEntity,
                            otherCapexCopyHolder.getSubWorkStreamOtherCapexCostChildren(),
                            capexId);
            subWorkstreamOtherCostRepo.saveAll(capexChildrenEntitiesCloned);

            //IT Depreciation Cost data
            SubWorkstreamOtherCost otherITDepreParentEntity = (SubWorkstreamOtherCost)
                    SerializationUtils.clone(otherCapexCopyHolder.getSubWorkStreamOtherITDepreciationCostParent());
            otherITDepreParentEntity.setSwsOtherSurrId(null);
            otherITDepreParentEntity.setScenario(scenarioTo);
            otherITDepreParentEntity.setCapexOpexSurrId(capexId);

            SubWorkstreamOtherCost clonedOtherITDepreParentEntity = subWorkstreamOtherCostRepo.save(otherITDepreParentEntity);
            List<SubWorkstreamOtherCost> iTDepreChildrenEntitiesCloned =
                    alignOtherCostChildrenWithParent(clonedOtherITDepreParentEntity,
                            otherCapexCopyHolder.getSubWorkStreamOtherITDepreciationCostChildren(),
                            capexId);
            subWorkstreamOtherCostRepo.saveAll(iTDepreChildrenEntitiesCloned);
        });
    }


    private void copyHardware(String scenarioTo , ScenarioCopyHierarchy scenarioCopyHierarchy) {
        SubWorkStreamHardwareCostCopyHolder hardwareCostCopyHolder =
                scenarioCopyHierarchy.getHardwareCostCopyHolder();
        if (hardwareCostCopyHolder == null ||
                (CollectionUtils.isNullOrEmpty(hardwareCostCopyHolder.getHardwareOpexCopyHolders()))) {
            log.warn("No hardware records to copy to Scenario: "+scenarioTo);
            return;
        }
        List<SubWorkStreamHardwareOpexCopyHolder>
                hardwareOpexCopyHolders = hardwareCostCopyHolder.getHardwareOpexCopyHolders();
        List<String> deletableScenarios = getDeletableScenariosForCopy(scenarioTo);
        subWorkstreamHardwareCostRepo.deleteAllByWorkStreamIdAndSubWorkStreamIdAndScenarioIn(
                scenarioCopyHierarchy.getWorkStreamId(),
                scenarioCopyHierarchy.getSubWorkStreamId(), deletableScenarios);

        hardwareOpexCopyHolders.forEach(hardwareOpexCopyHolder->{
            //Opex cost data
            Integer capexOpexId = 0;
            SubWorkstreamHardwareCost hardwareOpexParentEntity = (SubWorkstreamHardwareCost)
                    SerializationUtils.clone(hardwareOpexCopyHolder.getSubWorkStreamHardwareOpexCostParent());
            hardwareOpexParentEntity.setSwsHwSurrId(null);
            hardwareOpexParentEntity.setScenario(scenarioTo);
            SubWorkstreamHardwareCost clonedHardwareOpexParentEntity = subWorkstreamHardwareCostRepo.save(hardwareOpexParentEntity);
            capexOpexId = clonedHardwareOpexParentEntity.getSwsHwSurrId();
            List<SubWorkstreamHardwareCost> opexChildrenEntitiesCloned =
                    allignFinDetailsChildrenWithParent(clonedHardwareOpexParentEntity,
                            hardwareOpexCopyHolder.getSubWorkStreamHardwareOpexCostChildren(),
                            capexOpexId);
            subWorkstreamHardwareCostRepo.saveAll(opexChildrenEntitiesCloned);

            //Ownership Cost data
            SubWorkstreamHardwareCost hardwareOwnershipParentEntity = (SubWorkstreamHardwareCost)
                    SerializationUtils.clone(hardwareOpexCopyHolder.getSubWorkStreamHardwareOwnershipCostParent());
            hardwareOwnershipParentEntity.setSwsHwSurrId(null);
            hardwareOwnershipParentEntity.setScenario(scenarioTo);
            hardwareOwnershipParentEntity.setCapexOpexSurrId(capexOpexId);

            SubWorkstreamHardwareCost clonedHardwareOwnershipParentEntity = subWorkstreamHardwareCostRepo.save(hardwareOwnershipParentEntity);
            List<SubWorkstreamHardwareCost> ownershipChildrenEntitiesCloned =
                    allignFinDetailsChildrenWithParent(clonedHardwareOwnershipParentEntity,
                            hardwareOpexCopyHolder.getSubWorkStreamHardwareOwnershipCostChildren(),
                            capexOpexId);
            subWorkstreamHardwareCostRepo.saveAll(ownershipChildrenEntitiesCloned);
        });
    }

    private void copySoftware(String scenarioTo, ScenarioCopyHierarchy scenarioCopyHierarchy) {
        SubWorkStreamSoftwareCostCopyHolder softwareCostCopyHolder =
                scenarioCopyHierarchy.getSoftwareCostCopyHolder();
        if (softwareCostCopyHolder == null ||
                (CollectionUtils.isNullOrEmpty(softwareCostCopyHolder.getSoftwareCapexCopyHolders()) &&
                        (CollectionUtils.isNullOrEmpty(softwareCostCopyHolder.getSoftwareOpexCopyHolders())))) {
            log.warn("No software records to copy to Scenario: "+scenarioTo);
            return;
        }
        List<String> deletableScenarios = getDeletableScenariosForCopy(scenarioTo);
        subWorkstreamSoftwareCostRepo.deleteAllByWorkStreamIdAndSubWorkStreamIdAndScenarioIn(
                scenarioCopyHierarchy.getWorkStreamId(),
                scenarioCopyHierarchy.getSubWorkStreamId(), deletableScenarios);

        //Opex/Ownership
        List<SubWorkStreamSoftwareOpexCopyHolder>
                softwareOpexCopyHolders = softwareCostCopyHolder.getSoftwareOpexCopyHolders();
        softwareOpexCopyHolders.forEach(softwareOpexCopyHolder->{
            //Opex cost data
            Integer opexId = 0;
            SubWorkstreamSoftwareCost softwareOpexParentEntity = (SubWorkstreamSoftwareCost)
                    SerializationUtils.clone(softwareOpexCopyHolder.getSubWorkStreamSoftwareOpexCostParent());
            softwareOpexParentEntity.setSwsSwSurrId(null);
            softwareOpexParentEntity.setScenario(scenarioTo);
            SubWorkstreamSoftwareCost clonedSoftwareOpexParentEntity = subWorkstreamSoftwareCostRepo.save(softwareOpexParentEntity);
            opexId = clonedSoftwareOpexParentEntity.getSwsSwSurrId();
            List<SubWorkstreamSoftwareCost> opexChildrenEntitiesCloned =
                    allignSoftwareCostChildrenWithParent(clonedSoftwareOpexParentEntity,
                            softwareOpexCopyHolder.getSubWorkStreamSoftwareOpexCostChildren(),
                            opexId);
            subWorkstreamSoftwareCostRepo.saveAll(opexChildrenEntitiesCloned);

            //Ownership Cost data
            SubWorkstreamSoftwareCost softwareOwnershipParentEntity = (SubWorkstreamSoftwareCost)
                    SerializationUtils.clone(softwareOpexCopyHolder.getSubWorkStreamSoftwareOwnershipCostParent());
            softwareOwnershipParentEntity.setSwsSwSurrId(null);
            softwareOwnershipParentEntity.setScenario(scenarioTo);
            softwareOwnershipParentEntity.setCapexOpexSurrId(opexId);

            SubWorkstreamSoftwareCost clonedSoftwareOwnershipParentEntity = subWorkstreamSoftwareCostRepo.save(softwareOwnershipParentEntity);
            List<SubWorkstreamSoftwareCost> ownershipChildrenEntitiesCloned =
                    allignSoftwareCostChildrenWithParent(clonedSoftwareOwnershipParentEntity,
                            softwareOpexCopyHolder.getSubWorkStreamSoftwareOwnershipCostChildren(),
                            opexId);
            subWorkstreamSoftwareCostRepo.saveAll(ownershipChildrenEntitiesCloned);
        });

        //Capex/ITDepreciation
        List<SubWorkStreamSoftwareCapexCopyHolder>
                softwareCapexCopyHolders = softwareCostCopyHolder.getSoftwareCapexCopyHolders();
        softwareCapexCopyHolders.forEach(softwareCapexCopyHolder->{
            //Capex cost data
            Integer capexId = 0;
            SubWorkstreamSoftwareCost softwareCapexParentEntity = (SubWorkstreamSoftwareCost)
                    SerializationUtils.clone(softwareCapexCopyHolder.getSubWorkStreamSoftwareCapexCostParent());
            softwareCapexParentEntity.setSwsSwSurrId(null);
            softwareCapexParentEntity.setScenario(scenarioTo);
            SubWorkstreamSoftwareCost clonedSoftwareCapexParentEntity = subWorkstreamSoftwareCostRepo.save(softwareCapexParentEntity);
            capexId = clonedSoftwareCapexParentEntity.getSwsSwSurrId();
            List<SubWorkstreamSoftwareCost> capexChildrenEntitiesCloned =
                    allignSoftwareCostChildrenWithParent(clonedSoftwareCapexParentEntity,
                            softwareCapexCopyHolder.getSubWorkStreamSoftwareCapexCostChildren(),
                            capexId);
            subWorkstreamSoftwareCostRepo.saveAll(capexChildrenEntitiesCloned);

            //IT Depreciation Cost data
            SubWorkstreamSoftwareCost softwareITDepreParentEntity = (SubWorkstreamSoftwareCost)
                    SerializationUtils.clone(softwareCapexCopyHolder.getSubWorkStreamSoftwareITDepreciationCostParent());
            softwareITDepreParentEntity.setSwsSwSurrId(null);
            softwareITDepreParentEntity.setScenario(scenarioTo);
            softwareITDepreParentEntity.setCapexOpexSurrId(capexId);

            SubWorkstreamSoftwareCost clonedSoftwareITDepreParentEntity = subWorkstreamSoftwareCostRepo.save(softwareITDepreParentEntity);
            List<SubWorkstreamSoftwareCost> iTDepreChildrenEntitiesCloned =
                    allignSoftwareCostChildrenWithParent(clonedSoftwareITDepreParentEntity,
                            softwareCapexCopyHolder.getSubWorkStreamSoftwareITDepreciationCostChildren(),
                            capexId);
            subWorkstreamSoftwareCostRepo.saveAll(iTDepreChildrenEntitiesCloned);
        });

    }


    private void copyResource(String scenarioTo, ScenarioCopyHierarchy scenarioCopyHierarchy) {
        SubWorkStreamResourceCostCopyHolder resourceCostCopyHolder =
                scenarioCopyHierarchy.getResourceCostCopyHolder();
        if (resourceCostCopyHolder == null ||
                (CollectionUtils.isNullOrEmpty(resourceCostCopyHolder.getResourceCapexCopyHolders()) &&
                        (CollectionUtils.isNullOrEmpty(resourceCostCopyHolder.getResourceOpexCopyHolders())))) {
            log.warn("No resource records to copy to Scenario: "+scenarioTo);
            return;
        }
        List<String> deletableScenarios = getDeletableScenariosForCopy(scenarioTo);
        subWorkStreamResourceCostRepo.deleteAllByWorkStreamIdAndSubWorkStreamIdAndScenarioIn(
                scenarioCopyHierarchy.getWorkStreamId(), scenarioCopyHierarchy.getSubWorkStreamId(), deletableScenarios);

        //Opex/Ownership
        List<SubWorkStreamResourceOpexCopyHolder>
                resourceOpexCopyHolders = resourceCostCopyHolder.getResourceOpexCopyHolders();
        resourceOpexCopyHolders.forEach(resourceOpexCopyHolder->{
            //Opex cost data
            Integer opexId = 0;
            SubWorkStreamResourceCost resourceOpexParentEntity = (SubWorkStreamResourceCost)
                    SerializationUtils.clone(resourceOpexCopyHolder.getSubWorkStreamResourceOpexCostParent());
            resourceOpexParentEntity.setSwsResourceSurrId(null);
            resourceOpexParentEntity.setScenario(scenarioTo);
            SubWorkStreamResourceCost clonedResourceOpexParentEntity = subWorkStreamResourceCostRepo.save(resourceOpexParentEntity);
            opexId = clonedResourceOpexParentEntity.getSwsResourceSurrId();
            List<SubWorkStreamResourceCost> opexChildrenEntitiesCloned =
                    alignResourceCostChildrenWithParent(clonedResourceOpexParentEntity,
                            resourceOpexCopyHolder.getSubWorkStreamResourceOpexCostChildren(),
                            opexId);
            subWorkStreamResourceCostRepo.saveAll(opexChildrenEntitiesCloned);

            //Ownership Cost data
            SubWorkStreamResourceCost resourceOwnershipParentEntity = (SubWorkStreamResourceCost)
                    SerializationUtils.clone(resourceOpexCopyHolder.getSubWorkStreamResourceOwnershipCostParent());
            resourceOwnershipParentEntity.setSwsResourceSurrId(null);
            resourceOwnershipParentEntity.setScenario(scenarioTo);
            resourceOwnershipParentEntity.setCapexOpexSurrId(opexId);

            SubWorkStreamResourceCost clonedResourceOwnershipParentEntity = subWorkStreamResourceCostRepo.save(resourceOwnershipParentEntity);
            List<SubWorkStreamResourceCost> ownershipChildrenEntitiesCloned =
                    alignResourceCostChildrenWithParent(clonedResourceOwnershipParentEntity,
                            resourceOpexCopyHolder.getSubWorkStreamResourceOwnershipCostChildren(),
                            opexId);
            subWorkStreamResourceCostRepo.saveAll(ownershipChildrenEntitiesCloned);
        });

        //Capex/ITDepreciation
        List<SubWorkStreamResourceCapexCopyHolder>
                resourceCapexCopyHolders = resourceCostCopyHolder.getResourceCapexCopyHolders();
        resourceCapexCopyHolders.forEach(resourceCapexCopyHolder->{
            //Capex cost data
            Integer capexId = 0;
            SubWorkStreamResourceCost resourceCapexParentEntity = (SubWorkStreamResourceCost)
                    SerializationUtils.clone(resourceCapexCopyHolder.getSubWorkStreamResourceCapexCostParent());
            resourceCapexParentEntity.setSwsResourceSurrId(null);
            resourceCapexParentEntity.setScenario(scenarioTo);
            SubWorkStreamResourceCost clonedResourceCapexParentEntity = subWorkStreamResourceCostRepo.save(resourceCapexParentEntity);
            capexId = clonedResourceCapexParentEntity.getSwsResourceSurrId();
            List<SubWorkStreamResourceCost> capexChildrenEntitiesCloned =
                    alignResourceCostChildrenWithParent(clonedResourceCapexParentEntity,
                            resourceCapexCopyHolder.getSubWorkStreamResourceCapexCostChildren(),
                            capexId);
            subWorkStreamResourceCostRepo.saveAll(capexChildrenEntitiesCloned);

            //IT Depreciation Cost data
            SubWorkStreamResourceCost resourceITDepreParentEntity = (SubWorkStreamResourceCost)
                    SerializationUtils.clone(resourceCapexCopyHolder.getSubWorkStreamResourceITDepreciationCostParent());
            resourceITDepreParentEntity.setSwsResourceSurrId(null);
            resourceITDepreParentEntity.setScenario(scenarioTo);
            resourceITDepreParentEntity.setCapexOpexSurrId(capexId);

            SubWorkStreamResourceCost clonedResourceITDepreParentEntity = subWorkStreamResourceCostRepo.save(resourceITDepreParentEntity);
            List<SubWorkStreamResourceCost> iTDepreChildrenEntitiesCloned =
                    alignResourceCostChildrenWithParent(clonedResourceITDepreParentEntity,
                            resourceCapexCopyHolder.getSubWorkStreamResourceITDepreciationCostChildren(),
                            capexId);
            subWorkStreamResourceCostRepo.saveAll(iTDepreChildrenEntitiesCloned);
        });
    }

    private void copyWorkStreamApprovers(String scenarioTo, List<WorkStreamApprovers> workStreamApprovers) {
        List<String> workStreamIds = workStreamApprovers.stream().map(WorkStreamApprovers::getWorkStreamId).collect(Collectors.toList());
        List<String> deletableScenarios = getDeletableScenariosForCopy(scenarioTo);
        workStreamApproverRepo.deleteAllByWorkStreamIdInAndScenarioIn(workStreamIds, deletableScenarios);
        List<WorkStreamApprovers> clonedWorkStreamApprovers = new ArrayList<>();
        workStreamApprovers.forEach(workStreamApprover -> {
            WorkStreamApprovers clonedWorkStreamApprover =
                    (WorkStreamApprovers) SerializationUtils.clone(workStreamApprover);
            clonedWorkStreamApprover.setWsApproverSurrId(null);
            clonedWorkStreamApprover.setScenario(scenarioTo);
            clonedWorkStreamApprovers.add(clonedWorkStreamApprover);
        });
        workStreamApproverRepo.saveAll(clonedWorkStreamApprovers);
    }

    private void copySubWorkStreamApprovers(String scenarioTo, List<SubWorkStreamApprovers> subWorkStreamApprovers) {
        List<String> workStreamIds = subWorkStreamApprovers.stream().map(SubWorkStreamApprovers::getWorkStreamId).collect(Collectors.toList());
        List<String> deletableScenarios = getDeletableScenariosForCopy(scenarioTo);
        subWorkStreamApproverRepo.deleteAllByWorkStreamIdInAndScenarioIn(workStreamIds, deletableScenarios);
        List<SubWorkStreamApprovers> clonedSubWorkStreamApprovers = new ArrayList<>();
        subWorkStreamApprovers.forEach(subWorkStreamApprover -> {
            SubWorkStreamApprovers clonedSubWorkStreamApprover =
                    (SubWorkStreamApprovers) SerializationUtils.clone(subWorkStreamApprover);
            clonedSubWorkStreamApprover.setSwsApproveSurrId(null);
            clonedSubWorkStreamApprover.setScenario(scenarioTo);
            clonedSubWorkStreamApprovers.add(clonedSubWorkStreamApprover);
        });
        subWorkStreamApproverRepo.saveAll(clonedSubWorkStreamApprovers);
    }

    private void copyWorkStreamKeyDates(String scenarioTo, List<WorkStreamKeyDatesEntity> workStreamKeyDates) {
        List<String> workStreamIds = workStreamKeyDates.stream().map(WorkStreamKeyDatesEntity::getWorkStreamId).collect(Collectors.toList());
        List<String> deletableScenarios = getDeletableScenariosForCopy(scenarioTo);
        workStreamKeyDatesRepo.deleteAllByWorkStreamIdInAndScenarioNameIn(workStreamIds, deletableScenarios);
        List<WorkStreamKeyDatesEntity> clonedWorkStreamKeyDatesList = new ArrayList<>();
        workStreamKeyDates.forEach(workStreamKeyDatesEntity -> {
            WorkStreamKeyDatesEntity clonedWorkStreamKeyDatesEntity =
                    (WorkStreamKeyDatesEntity) SerializationUtils.clone(workStreamKeyDatesEntity);
            clonedWorkStreamKeyDatesEntity.setWsDateSurrId(0);
            clonedWorkStreamKeyDatesEntity.setScenarioName(scenarioTo);
            clonedWorkStreamKeyDatesEntity.setApprovedDate(null);
            clonedWorkStreamKeyDatesList.add(clonedWorkStreamKeyDatesEntity);
        });
        workStreamKeyDatesRepo.saveAll(clonedWorkStreamKeyDatesList);
    }

    private void copySubWorkStreamKeyDates(String scenarioTo, List<SubWorkStreamKeyDatesEntity> subWorkStreamKeyDatesEntities) {
        List<String> workStreamIds = subWorkStreamKeyDatesEntities.stream().map(SubWorkStreamKeyDatesEntity::getWorkStreamId).collect(Collectors.toList());
        List<String> deletableScenarios = getDeletableScenariosForCopy(scenarioTo);
        subWorkStreamKeyDatesRepo.deleteAllByWorkStreamIdInAndScenarioNameIn(workStreamIds, deletableScenarios);
        List<SubWorkStreamKeyDatesEntity> clonedSubWorkStreamKeyDatesList = new ArrayList<>();
        subWorkStreamKeyDatesEntities.forEach(subWorkStreamKeyDatesEntity -> {
            SubWorkStreamKeyDatesEntity clonedSubWorkStreamKeyDatesEntity =
                    (SubWorkStreamKeyDatesEntity) SerializationUtils.clone(subWorkStreamKeyDatesEntity);
            clonedSubWorkStreamKeyDatesEntity.setSwsDateSurrId(0);
            clonedSubWorkStreamKeyDatesEntity.setScenarioName(scenarioTo);
            clonedSubWorkStreamKeyDatesEntity.setApprovalDate(null);
            clonedSubWorkStreamKeyDatesList.add(clonedSubWorkStreamKeyDatesEntity);
        });
        subWorkStreamKeyDatesRepo.saveAll(clonedSubWorkStreamKeyDatesList);
    }

    private void copyForcastFinDetails(String scenarioTo, ScenarioCopyHierarchy scenarioCopyHierarchy) {
        SubWorkStreamFinDetailsEntityCopyHolder finDetailsEntityCopyHolder =
                scenarioCopyHierarchy.getFinDetailsEntityForcastsCopyHolder();
        if (finDetailsEntityCopyHolder == null ||
                (finDetailsEntityCopyHolder.getFinDetailsOriginalIndWithChildren() == null)) {
            log.warn("No Forecast FinDetails records found for copy to Scenario: " + scenarioTo);
            return;
        }
        Map<SubWorkstreamFinDetailsEntity, List<SubWorkstreamFinDetailsEntity>>
                finDetailsParentChildren = finDetailsEntityCopyHolder.getFinDetailsOriginalIndWithChildren();
        List<String> deletableScenarios = getDeletableScenariosForCopy(scenarioTo);
        subWorkstreamFinDetailsRepo.deleteAllByWorkstreamIdAndSubWorkstreamIdAndCostSettingInAndScenarioIn(
                scenarioCopyHierarchy.getWorkStreamId(), scenarioCopyHierarchy.getSubWorkStreamId(),
                getForecastCostSettings(), deletableScenarios);
        finDetailsParentChildren.forEach((parentEntity, childrenEntities) -> {
            SubWorkstreamFinDetailsEntity parentEntityCopy =
                    (SubWorkstreamFinDetailsEntity) SerializationUtils.clone(parentEntity);
            parentEntityCopy.setSubWorkStreamFinSurrId(null);
            parentEntityCopy.setScenario(scenarioTo);
            SubWorkstreamFinDetailsEntity clonedParentEntity = subWorkstreamFinDetailsRepo.save(parentEntityCopy);
            List<SubWorkstreamFinDetailsEntity> childrenEntitiesCloned =
                    alignForecastFinDetailsChildrenWithParent(clonedParentEntity, childrenEntities);
            subWorkstreamFinDetailsRepo.saveAll(childrenEntitiesCloned);
        });
    }

    private void copyActualsFinDetails(String scenarioTo, ScenarioCopyHierarchy scenarioCopyHierarchy) {
        SubWorkStreamFinDetailsEntityActualsCopyHolder finDetailsActualsCopyHolder =
                scenarioCopyHierarchy.getFinDetailsEntityActualsCopyHolder();
        if (finDetailsActualsCopyHolder == null ||
                (CollectionUtils.isNullOrEmpty(finDetailsActualsCopyHolder.getFinDetailsEntityActuals()))) {
            log.warn("No Actuals FinDetails records found for copy to Scenario: " + scenarioTo);
            return;
        }
        List<SubWorkstreamFinDetailsEntity>
                finDetailsActuals = finDetailsActualsCopyHolder.getFinDetailsEntityActuals();
        List<String> deletableScenarios = getDeletableScenariosForCopy(scenarioTo);
        subWorkstreamFinDetailsRepo.deleteAllByWorkstreamIdAndSubWorkstreamIdAndScenarioInAndCostTypeDetailIsContaining(
                scenarioCopyHierarchy.getWorkStreamId(), scenarioCopyHierarchy.getSubWorkStreamId(),
                deletableScenarios, PortfolioConstants.COST_TYPE_DETAIL_ACTUAL);
        List<SubWorkstreamFinDetailsEntity> clonedFinDetailsEntities = new ArrayList<>();
        finDetailsActuals.forEach(finDetailActual -> {
            SubWorkstreamFinDetailsEntity clonedFinDetailActual =
                    (SubWorkstreamFinDetailsEntity) SerializationUtils.clone(finDetailActual);
            clonedFinDetailActual.setSubWorkStreamFinSurrId(null);
            clonedFinDetailActual.setScenario(scenarioTo);
            clonedFinDetailsEntities.add(clonedFinDetailActual);
        });
        if (clonedFinDetailsEntities.size() > 0) {
            subWorkstreamFinDetailsRepo.saveAll(clonedFinDetailsEntities);
        }
    }

    private List<SubWorkstreamFinDetailsEntity> alignForecastFinDetailsChildrenWithParent(SubWorkstreamFinDetailsEntity clonedParentEntity,
                                                                                          List<SubWorkstreamFinDetailsEntity> finDetailsChildren) {
        List<SubWorkstreamFinDetailsEntity> clonedEntities = new ArrayList<>();
        finDetailsChildren.forEach(child -> {
            SubWorkstreamFinDetailsEntity childClone = (SubWorkstreamFinDetailsEntity)
                    SerializationUtils.clone(child);
            childClone.setSubWorkStreamFinSurrId(0);
            childClone.setRefSwsFdSurrId(clonedParentEntity.getSubWorkStreamFinSurrId());
            childClone.setScenario(clonedParentEntity.getScenario());
            clonedEntities.add(childClone);
        });
        return clonedEntities;
    }

    private List<SubWorkstreamSoftwareCost> allignSoftwareCostChildrenWithParent(SubWorkstreamSoftwareCost clonedParentEntity,
                                                                                 List<SubWorkstreamSoftwareCost> softwareCosts,
                                                                                 Integer capexOpexId) {
        List<SubWorkstreamSoftwareCost> clonedEntities = new ArrayList<>();
        softwareCosts.forEach(child -> {
            SubWorkstreamSoftwareCost childClone = (SubWorkstreamSoftwareCost)
                    SerializationUtils.clone(child);
            childClone.setSwsSwSurrId(0);
            childClone.setRefSwsSwSurrId(clonedParentEntity.getSwsSwSurrId());
            childClone.setScenario(clonedParentEntity.getScenario());
            childClone.setCapexOpexSurrId(capexOpexId);
            clonedEntities.add(childClone);
        });
        return clonedEntities;
    }

    private List<SubWorkStreamResourceCost> alignResourceCostChildrenWithParent(SubWorkStreamResourceCost clonedParentEntity,
                                                                                 List<SubWorkStreamResourceCost> resourceCosts,
                                                                                 Integer capexOpexId) {
        List<SubWorkStreamResourceCost> clonedEntities = new ArrayList<>();
        resourceCosts.forEach(child -> {
            SubWorkStreamResourceCost childClone = (SubWorkStreamResourceCost)
                    SerializationUtils.clone(child);
            childClone.setSwsResourceSurrId(0);
            childClone.setRefSwsResourceSurrId(clonedParentEntity.getSwsResourceSurrId());
            childClone.setScenario(clonedParentEntity.getScenario());
            childClone.setCapexOpexSurrId(capexOpexId);
            clonedEntities.add(childClone);
        });
        return clonedEntities;
    }

    private List<SubWorkstreamHardwareCost> allignFinDetailsChildrenWithParent(SubWorkstreamHardwareCost clonedParentEntity,
                                                                               List<SubWorkstreamHardwareCost> finDetailsChildren,
                                                                               Integer capexOpexId) {
        List<SubWorkstreamHardwareCost> clonedEntities = new ArrayList<>();
        finDetailsChildren.forEach(child -> {
            SubWorkstreamHardwareCost childClone = (SubWorkstreamHardwareCost)
                    SerializationUtils.clone(child);
            childClone.setSwsHwSurrId(0);
            childClone.setRefSwsHwSurrId(clonedParentEntity.getSwsHwSurrId());
            childClone.setScenario(clonedParentEntity.getScenario());
            childClone.setCapexOpexSurrId(capexOpexId);
            clonedEntities.add(childClone);
        });
        return clonedEntities;
    }

    private List<SubWorkstreamOtherCost> alignOtherCostChildrenWithParent(SubWorkstreamOtherCost clonedParentEntity,
                                                                            List<SubWorkstreamOtherCost> otherCostChildren,
                                                                           Integer capexOpexId) {
        List<SubWorkstreamOtherCost> clonedEntities = new ArrayList<>();
        otherCostChildren.forEach(child -> {
            SubWorkstreamOtherCost childClone = (SubWorkstreamOtherCost)
                    SerializationUtils.clone(child);
            childClone.setSwsOtherSurrId(0);
            childClone.setRefSwsOtherSurrId(clonedParentEntity.getSwsOtherSurrId());
            childClone.setScenario(clonedParentEntity.getScenario());
            childClone.setCapexOpexSurrId(capexOpexId);
            clonedEntities.add(childClone);
        });
        return clonedEntities;
    }

    private CopyScenarioKeyDatesApproveDataHolder fetchDbDataForKeyDatesAndApprovers(
            Map<String, List<String>> workStreamIdAndSubWorkStreamIdsMap, CopyScenarioRequest copyScenarioRequest) {
        CopyScenarioKeyDatesApproveDataHolder copyScenarioKeyDatesApproveDataHolder =
                new CopyScenarioKeyDatesApproveDataHolder();
        if ((workStreamIdAndSubWorkStreamIdsMap != null) && (workStreamIdAndSubWorkStreamIdsMap.size() > 0)) {
            workStreamIdAndSubWorkStreamIdsMap.forEach((key, value) -> {
                //SubWorkStreamDates data based on the WorkStream, SubWorkStream and ScenarioFrom
                List<SubWorkStreamKeyDatesEntity> subWorkStreamKeyDatesEntities =
                        subWorkStreamKeyDatesRepo.findAllByWorkStreamIdAndSubWorkStreamIdInAndScenarioName
                                (key, value, copyScenarioRequest.getScenarioFrom());
                copyScenarioKeyDatesApproveDataHolder.getSubWorkStreamKeyDatesEntities().addAll((subWorkStreamKeyDatesEntities));
                //SubWorkStreamApprovers data based on the WorkStream, SubWorkStream and ScenarioFrom
                List<SubWorkStreamApprovers> subWorkStreamApprovers =
                        subWorkStreamApproverRepo.findAllByWorkStreamIdAndSubWorkStreamIdInAndScenario(
                                key, value, copyScenarioRequest.getScenarioFrom());
                copyScenarioKeyDatesApproveDataHolder.getSubWorkStreamApprovers().addAll((subWorkStreamApprovers));
            });
            //WorkStreamDates data based on the WorkStream and ScenarioFrom
            Set<String> workStreamIds = workStreamIdAndSubWorkStreamIdsMap.keySet();
            List<WorkStreamKeyDatesEntity> workStreamKeyDatesEntities =
                    workStreamKeyDatesRepo.findAllByWorkStreamIdInAndScenarioName(
                            workStreamIds, copyScenarioRequest.getScenarioFrom());
            copyScenarioKeyDatesApproveDataHolder.setWorkStreamKeyDatesEntities(workStreamKeyDatesEntities);
            List<WorkStreamApprovers> workStreamApprovers =
                    workStreamApproverRepo.findAllByWorkStreamIdInAndScenario(
                            workStreamIds, copyScenarioRequest.getScenarioFrom());
            copyScenarioKeyDatesApproveDataHolder.setWorkStreamApprovers(workStreamApprovers);
        }
        return copyScenarioKeyDatesApproveDataHolder;
    }

    private PortFolioCopyHierarchy fetchDbDataForCopyScenario(Map<String, List<String>> workStreamIdAndSubWorkStreamIdsMap,
                                                              CopyScenarioRequest copyScenarioRequest) {
        PortFolioCopyHierarchy portFolioCopyHierarchy = new PortFolioCopyHierarchy();
        portFolioCopyHierarchy.setPortFolioId(copyScenarioRequest.getPortFolioId());


        List<WorkStreamCopyHierarchy> workStreamCopyHierarchies = new ArrayList<>();
        workStreamIdAndSubWorkStreamIdsMap.forEach((key, value) -> {
            WorkStreamCopyHierarchy workStreamCopyHierarchy = new WorkStreamCopyHierarchy();
            workStreamCopyHierarchy.setWorkStreamId(key);
            workStreamCopyHierarchy.setPortFolioId(copyScenarioRequest.getPortFolioId());

            //Fetch Forecast (HLE/Seed Funding) FinDetails data based on WorkStream/SubWorkStream and ScenarioFrom
            List<SubWorkstreamFinDetailsEntity> subWorkstreamFinDetailsEntitiesForForecast =
                    subWorkstreamFinDetailsRepo.findAllByWorkstreamIdAndSubWorkstreamIdInAndCostSettingInAndScenario(
                            key, value, getForecastCostSettings(), copyScenarioRequest.getScenarioFrom());

            List<SubWorkstreamFinDetailsEntity> subWorkstreamFinDetailsEntitiesForActuals =
                    subWorkstreamFinDetailsRepo.findAllByWorkstreamIdAndSubWorkstreamIdInAndScenarioAndCostTypeDetailIsContaining(
                            key, value, copyScenarioRequest.getScenarioFrom(), PortfolioConstants.COST_TYPE_DETAIL_ACTUAL);

            //Fetch  SoftwareCostData based on WorkStream/SubWorkStream and ScenarioFrom
            List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCosts =
                    subWorkstreamSoftwareCostRepo.findAllByWorkStreamIdAndSubWorkStreamIdInAndScenario(
                            key, value, copyScenarioRequest.getScenarioFrom());

            //Fetch HwardwareCost based on WorkStream/SubWorkStream and ScenarioFrom
            List<SubWorkstreamHardwareCost> subWorkstreamHardwareCosts =
                    subWorkstreamHardwareCostRepo.findAllByWorkStreamIdAndSubWorkStreamIdInAndScenario(
                            key, value, copyScenarioRequest.getScenarioFrom());

            List<SubWorkStreamResourceCost> subWorkStreamResourceCosts =
                    subWorkStreamResourceCostRepo.findAllByWorkStreamIdAndSubWorkStreamIdInAndScenario(
                            key, value, copyScenarioRequest.getScenarioFrom());

            //Fetch OtherCost based on WorkStream/SubWorkStream and ScenarioFrom
            List<SubWorkstreamOtherCost> subWorkstreamOtherCosts =
                    subWorkstreamOtherCostRepo.
                            findAllByWorkStreamIdAndSubWorkStreamIdInAndScenario(key, value, copyScenarioRequest.getScenarioFrom());

            collectDbDataForAllEntities(copyScenarioRequest,
                    subWorkstreamFinDetailsEntitiesForForecast, subWorkstreamFinDetailsEntitiesForActuals,
                    subWorkstreamSoftwareCosts, subWorkstreamHardwareCosts, subWorkstreamOtherCosts,
                    subWorkStreamResourceCosts, workStreamCopyHierarchy);
            workStreamCopyHierarchies.add(workStreamCopyHierarchy);
        });
        portFolioCopyHierarchy.setWorkStreamCopyHierarchies(workStreamCopyHierarchies);
        return portFolioCopyHierarchy;
    }

    private void collectDbDataForAllEntities(
            CopyScenarioRequest copyScenarioRequest,
            List<SubWorkstreamFinDetailsEntity> finDetailsEntitiesForForcast,
            List<SubWorkstreamFinDetailsEntity> finDetailsEntitiesForActuals,
            List<SubWorkstreamSoftwareCost> softwareCosts,
            List<SubWorkstreamHardwareCost> hardwareCosts,
            List<SubWorkstreamOtherCost> otherCosts,
            List<SubWorkStreamResourceCost> resourceCosts,
            WorkStreamCopyHierarchy workStreamCopyHierarchy) {
        List<String> allSubWorkStreams = new ArrayList<>();

        Map<String, List<SubWorkstreamFinDetailsEntity>> finDetailsEntityForForcastPerSubWorkStreamId =
                finDetailsEntitiesForForcast.stream().collect(Collectors.groupingBy(
                        SubWorkstreamFinDetailsEntity::getSubWorkstreamId));
        allSubWorkStreams.addAll(finDetailsEntityForForcastPerSubWorkStreamId.keySet());

        Map<String, List<SubWorkstreamFinDetailsEntity>> finDetailsEntityForActualsPerSubWorkStreamId =
                finDetailsEntitiesForActuals.stream().collect(Collectors.groupingBy(
                        SubWorkstreamFinDetailsEntity::getSubWorkstreamId));
        allSubWorkStreams.addAll(finDetailsEntityForActualsPerSubWorkStreamId.keySet());

        Map<String, List<SubWorkstreamSoftwareCost>> softwareCostsPerSubWorkStreamId =
                softwareCosts.stream().collect(Collectors.groupingBy(
                        SubWorkstreamSoftwareCost::getSubWorkStreamId));
        allSubWorkStreams.addAll(softwareCostsPerSubWorkStreamId.keySet());

        Map<String, List<SubWorkstreamHardwareCost>> hardwareCostsPerSubWorkStreamId =
                hardwareCosts.stream().collect(Collectors.groupingBy(
                        SubWorkstreamHardwareCost::getSubWorkStreamId));
        allSubWorkStreams.addAll(hardwareCostsPerSubWorkStreamId.keySet());

        Map<String, List<SubWorkStreamResourceCost>> resourceCostsPerSubWorkStreamId =
                resourceCosts.stream().collect(Collectors.groupingBy(
                        SubWorkStreamResourceCost::getSubWorkStreamId));
        allSubWorkStreams.addAll(resourceCostsPerSubWorkStreamId.keySet());

        Map<String, List<SubWorkstreamOtherCost>> otherCostsPerSubWorkStreamId =
                otherCosts.stream().collect(Collectors.groupingBy(
                        SubWorkstreamOtherCost::getSubWorkStreamId));
        allSubWorkStreams.addAll(otherCostsPerSubWorkStreamId.keySet());

        List<String> allDistinctSubWorkStreamIds = allSubWorkStreams.stream().distinct().collect(Collectors.toList());
        workStreamCopyHierarchy.setSubWorkStreamIds(allDistinctSubWorkStreamIds);
        workStreamCopyHierarchy.setSubWorkStreamCopyHierarchies(getScenarioCopyHierarchies(
                workStreamCopyHierarchy.getWorkStreamId(),
                allDistinctSubWorkStreamIds,
                copyScenarioRequest,
                finDetailsEntityForForcastPerSubWorkStreamId,
                finDetailsEntityForActualsPerSubWorkStreamId,
                softwareCostsPerSubWorkStreamId,
                hardwareCostsPerSubWorkStreamId,
                resourceCostsPerSubWorkStreamId,
                otherCostsPerSubWorkStreamId));
    }

    private List<SubWorkStreamCopyHierarchy> getScenarioCopyHierarchies(
            String workStreamId,
            List<String> allDistinctSubWorkStreamIds,
            CopyScenarioRequest copyScenarioRequest,
            Map<String, List<SubWorkstreamFinDetailsEntity>> finDetailsForcastPerSubWorkStreamId,
            Map<String, List<SubWorkstreamFinDetailsEntity>> finDetailsActualsPerSubWorkStreamId,
            Map<String, List<SubWorkstreamSoftwareCost>> softwareCostsPerSubWorkStreamId,
            Map<String, List<SubWorkstreamHardwareCost>> hardwareCostsPerSubWorkStreamId,
            Map<String, List<SubWorkStreamResourceCost>> resourceCostsPerSubWorkStreamId,
            Map<String, List<SubWorkstreamOtherCost>> otherCostsPerSubWorkStreamId) {

        List<SubWorkStreamCopyHierarchy> subWorkStreamCopyHierarchies = new ArrayList();
        allDistinctSubWorkStreamIds.forEach(subWorkStreamId -> {

            SubWorkStreamCopyHierarchy subWorkStreamCopyHierarchy = new SubWorkStreamCopyHierarchy();
            ScenarioCopyHierarchy scenarioCopyHierarchy = new ScenarioCopyHierarchy();
            scenarioCopyHierarchy.setPortFolioId(copyScenarioRequest.getPortFolioId());
            scenarioCopyHierarchy.setWorkStreamId(workStreamId);
            scenarioCopyHierarchy.setSubWorkStreamId(subWorkStreamId);
            scenarioCopyHierarchy.setScenarioFrom(copyScenarioRequest.getScenarioFrom());
            scenarioCopyHierarchy.setScenarioTo(copyScenarioRequest.getScenarioTo());

            SubWorkStreamFinDetailsEntityCopyHolder finDetailEntityForForcastCopyHolder =
                    new SubWorkStreamFinDetailsEntityCopyHolder();
            finDetailEntityForForcastCopyHolder.setFinDetailsOriginalIndWithChildren(
                    getFinDetailsParentChildren(finDetailsForcastPerSubWorkStreamId.get(subWorkStreamId)));
            scenarioCopyHierarchy.setFinDetailsEntityForcastsCopyHolder(finDetailEntityForForcastCopyHolder);

            SubWorkStreamFinDetailsEntityActualsCopyHolder subWorkStreamFinDetailsEntityActualsCopyHolder =
                    new SubWorkStreamFinDetailsEntityActualsCopyHolder();
            subWorkStreamFinDetailsEntityActualsCopyHolder.setFinDetailsEntityActuals(
                    finDetailsActualsPerSubWorkStreamId.get(subWorkStreamId));
            scenarioCopyHierarchy.setFinDetailsEntityActualsCopyHolder(subWorkStreamFinDetailsEntityActualsCopyHolder);

            SubWorkStreamSoftwareCostCopyHolder softwareCostCopyHolder =
                    getSoftwareCostParentChildren(softwareCostsPerSubWorkStreamId.get(subWorkStreamId));
            scenarioCopyHierarchy.setSoftwareCostCopyHolder(softwareCostCopyHolder);

            SubWorkStreamResourceCostCopyHolder resourceCostCopyHolder =
                    getResourceCostParentChildren(resourceCostsPerSubWorkStreamId.get(subWorkStreamId));
            scenarioCopyHierarchy.setResourceCostCopyHolder(resourceCostCopyHolder);

            SubWorkStreamHardwareCostCopyHolder hardwareCostCopyHolder =
                    new SubWorkStreamHardwareCostCopyHolder();
            hardwareCostCopyHolder.setHardwareOpexCopyHolders(
                    getHardwareCostParentChildren(hardwareCostsPerSubWorkStreamId.get(subWorkStreamId)));
            scenarioCopyHierarchy.setHardwareCostCopyHolder(hardwareCostCopyHolder);


            SubWorkStreamOtherCostCopyHolder subWorkStreamOtherCostCopyHolder =
                    getOtherCostParentChildren(otherCostsPerSubWorkStreamId.get(subWorkStreamId));
            scenarioCopyHierarchy.setOtherCostCopyHolder(subWorkStreamOtherCostCopyHolder);

            subWorkStreamCopyHierarchy.setScenarioCopyHierarchy(scenarioCopyHierarchy);
            subWorkStreamCopyHierarchies.add(subWorkStreamCopyHierarchy);
        });

        return subWorkStreamCopyHierarchies;
    }

    private Map<SubWorkstreamFinDetailsEntity, List<SubWorkstreamFinDetailsEntity>>
    getFinDetailsParentChildren(List<SubWorkstreamFinDetailsEntity> finDetailsEntities) {
        Map<SubWorkstreamFinDetailsEntity, List<SubWorkstreamFinDetailsEntity>>
                finDetailsParentChilderen = new HashMap<>();
        if (CollectionUtils.isNullOrEmpty(finDetailsEntities))
            return finDetailsParentChilderen;

        List<SubWorkstreamFinDetailsEntity> finDetailsParentEntities =
                finDetailsEntities.stream().filter(entity -> entity.getOrgInd().equals("true"))
                        .collect(Collectors.toList());

        List<SubWorkstreamFinDetailsEntity> finDetailsChildrenEntities =
                finDetailsEntities.stream().filter(entity -> entity.getOrgInd().equals("false"))
                        .collect(Collectors.toList());

        finDetailsParentEntities.forEach(parentEntity -> {
            List<SubWorkstreamFinDetailsEntity> finDetailsEntityList =
                    finDetailsChildrenEntities.stream().filter(childEntity -> childEntity.getRefSwsFdSurrId().equals(
                            parentEntity.getSubWorkStreamFinSurrId())).collect(Collectors.toList());
            finDetailsParentChilderen.put(parentEntity, finDetailsEntityList);
        });
        return finDetailsParentChilderen;
    }

    private SubWorkStreamSoftwareCostCopyHolder
    getSoftwareCostParentChildren(List<SubWorkstreamSoftwareCost> softwareCostsEntities) {
        SubWorkStreamSoftwareCostCopyHolder softwareCostCopyHolder =
                new SubWorkStreamSoftwareCostCopyHolder();
        Map<SubWorkstreamSoftwareCost, List<SubWorkstreamSoftwareCost>>
                softwareCostParentChilderen = new HashMap<>();
        if (CollectionUtils.isNullOrEmpty(softwareCostsEntities))
            return softwareCostCopyHolder;

        List<SubWorkstreamSoftwareCost> softwareCostParent =
                softwareCostsEntities.stream().filter(entity -> entity.getOriginalInd().equals("true"))
                        .collect(Collectors.toList());

        List<SubWorkstreamSoftwareCost> softwareCostChildren =
                softwareCostsEntities.stream().filter(entity -> entity.getOriginalInd().equals("false"))
                        .collect(Collectors.toList());

        softwareCostParent.forEach(parentEntity -> {
            List<SubWorkstreamSoftwareCost> softwareCosts =
                    softwareCostChildren.stream().filter(childEntity -> childEntity.getRefSwsSwSurrId().equals(
                            parentEntity.getSwsSwSurrId())).collect(Collectors.toList());
            softwareCostParentChilderen.put(parentEntity, softwareCosts);
        });
        return alignSoftwareOpexCapexCost(softwareCostParentChilderen);
    }

    private SubWorkStreamSoftwareCostCopyHolder alignSoftwareOpexCapexCost(Map<SubWorkstreamSoftwareCost, List<SubWorkstreamSoftwareCost>>
                                                                                   softwareCostParentChildren){
        SubWorkStreamSoftwareCostCopyHolder softwareCostCopyHolder = new SubWorkStreamSoftwareCostCopyHolder();
        //Software Opex
        List<SubWorkStreamSoftwareOpexCopyHolder> subWorkStreamSoftwareOpexCopyHolders = new ArrayList<>();
        Map<SubWorkstreamSoftwareCost, List<SubWorkstreamSoftwareCost>> opexSoftwareCosts =
                softwareCostParentChildren.entrySet()
                        .stream()
                        .filter(map -> map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_OPEX))
                        .collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));

        Map<SubWorkstreamSoftwareCost, List<SubWorkstreamSoftwareCost>> ownershipSoftwareCosts =
                softwareCostParentChildren.entrySet()
                        .stream()
                        .filter(map -> map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_OWNERSHIP))
                        .collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));

        opexSoftwareCosts.forEach((opexSoftwareCostParent, opexSoftwareCostChildren)->{
            ownershipSoftwareCosts.forEach((ownershipHardwareCostParent, ownershipHardwareCostChildren)->{
                if(opexSoftwareCostParent.getSwsSwSurrId().equals(ownershipHardwareCostParent.getCapexOpexSurrId())){
                    SubWorkStreamSoftwareOpexCopyHolder softwareOpexCopyHolder = new SubWorkStreamSoftwareOpexCopyHolder();
                    softwareOpexCopyHolder.setSubWorkStreamSoftwareOpexCostParent(opexSoftwareCostParent);
                    softwareOpexCopyHolder.setSubWorkStreamSoftwareOpexCostChildren(opexSoftwareCostChildren);
                    softwareOpexCopyHolder.setSubWorkStreamSoftwareOwnershipCostParent(ownershipHardwareCostParent);
                    softwareOpexCopyHolder.setSubWorkStreamSoftwareOwnershipCostChildren(ownershipHardwareCostChildren);
                    subWorkStreamSoftwareOpexCopyHolders.add(softwareOpexCopyHolder);
                }
            });
        });
        softwareCostCopyHolder.setSoftwareOpexCopyHolders(subWorkStreamSoftwareOpexCopyHolders);


        //Software Capex
        List<SubWorkStreamSoftwareCapexCopyHolder> subWorkStreamSoftwareCapexCopyHolders = new ArrayList<>();
        Map<SubWorkstreamSoftwareCost, List<SubWorkstreamSoftwareCost>> capexSoftwareCosts =
                softwareCostParentChildren.entrySet()
                        .stream()
                        .filter(map -> map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_CAPEX))
                        .collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));

        Map<SubWorkstreamSoftwareCost, List<SubWorkstreamSoftwareCost>> itDepreciationSoftwareCosts =
                softwareCostParentChildren.entrySet()
                        .stream()
                        .filter(map -> map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_ITDEPRECIATION))
                        .collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));

        capexSoftwareCosts.forEach((capexSoftwareCostParent, capexSoftwareCostChildren)->{
            itDepreciationSoftwareCosts.forEach((itDepreciationSoftwareCostParent, itDepreciationSoftwareChildren)->{
                if(capexSoftwareCostParent.getSwsSwSurrId().equals(itDepreciationSoftwareCostParent.getCapexOpexSurrId())){
                    SubWorkStreamSoftwareCapexCopyHolder softwareCapexCopyHolder = new SubWorkStreamSoftwareCapexCopyHolder();
                    softwareCapexCopyHolder.setSubWorkStreamSoftwareCapexCostParent(capexSoftwareCostParent);
                    softwareCapexCopyHolder.setSubWorkStreamSoftwareCapexCostChildren(capexSoftwareCostChildren);
                    softwareCapexCopyHolder.setSubWorkStreamSoftwareITDepreciationCostParent(itDepreciationSoftwareCostParent);
                    softwareCapexCopyHolder.setSubWorkStreamSoftwareITDepreciationCostChildren(itDepreciationSoftwareChildren);
                    subWorkStreamSoftwareCapexCopyHolders.add(softwareCapexCopyHolder);
                }
            });
        });
        softwareCostCopyHolder.setSoftwareCapexCopyHolders(subWorkStreamSoftwareCapexCopyHolders);
        return softwareCostCopyHolder;
    }

    private SubWorkStreamResourceCostCopyHolder
    getResourceCostParentChildren(List<SubWorkStreamResourceCost> resourceCostsEntities) {
        SubWorkStreamResourceCostCopyHolder resourceCostCopyHolder =
                new SubWorkStreamResourceCostCopyHolder();
        Map<SubWorkStreamResourceCost, List<SubWorkStreamResourceCost>>
                resourceCostParentChilderen = new HashMap<>();
        if (CollectionUtils.isNullOrEmpty(resourceCostsEntities))
            return resourceCostCopyHolder;

        List<SubWorkStreamResourceCost> resourceCostParent =
                resourceCostsEntities.stream().filter(entity -> entity.getOriginalInd().equals("true"))
                        .collect(Collectors.toList());

        List<SubWorkStreamResourceCost> resourceCostChildren =
                resourceCostsEntities.stream().filter(entity -> entity.getOriginalInd().equals("false"))
                        .collect(Collectors.toList());

        resourceCostParent.forEach(parentEntity -> {
            List<SubWorkStreamResourceCost> resourceCosts =
                    resourceCostChildren.stream().filter(childEntity -> childEntity.getRefSwsResourceSurrId().equals(
                            parentEntity.getSwsResourceSurrId())).collect(Collectors.toList());
            resourceCostParentChilderen.put(parentEntity, resourceCosts);
        });
        return alignResourceOpexCapexCost(resourceCostParentChilderen);
    }


    private SubWorkStreamResourceCostCopyHolder alignResourceOpexCapexCost(
            Map<SubWorkStreamResourceCost, List<SubWorkStreamResourceCost>> resourceCostParentChildren){
        SubWorkStreamResourceCostCopyHolder resourceCostCopyHolder = new SubWorkStreamResourceCostCopyHolder();
        //Resource Opex
        List<SubWorkStreamResourceOpexCopyHolder> subWorkStreamResourceOpexCopyHolders = new ArrayList<>();

        Map<SubWorkStreamResourceCost, List<SubWorkStreamResourceCost>> opexResourceCosts = new HashMap<>();
        Map<SubWorkStreamResourceCost, List<SubWorkStreamResourceCost>> ownershipResourceCosts = new HashMap<>();

        resourceCostParentChildren.entrySet().stream()
                .forEach(
                        map -> {
                            if (map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_OPEX)) {
                                opexResourceCosts.put(map.getKey(), map.getValue());
                            } else if(map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_OWNERSHIP)) {
                                ownershipResourceCosts.put(map.getKey(), map.getValue());
                            }
                        }
                );

        opexResourceCosts.forEach((opexResourceCostParent, opexResourceCostChildren)->{
            ownershipResourceCosts.forEach((ownershipResourceCostParent, ownershipResourceCostChildren)->{
                if(opexResourceCostParent.getSwsResourceSurrId().equals(ownershipResourceCostParent.getCapexOpexSurrId())){
                    SubWorkStreamResourceOpexCopyHolder resourceOpexCopyHolder = new SubWorkStreamResourceOpexCopyHolder();
                    resourceOpexCopyHolder.setSubWorkStreamResourceOpexCostParent(opexResourceCostParent);
                    resourceOpexCopyHolder.setSubWorkStreamResourceOpexCostChildren(opexResourceCostChildren);
                    resourceOpexCopyHolder.setSubWorkStreamResourceOwnershipCostParent(ownershipResourceCostParent);
                    resourceOpexCopyHolder.setSubWorkStreamResourceOwnershipCostChildren(ownershipResourceCostChildren);
                    subWorkStreamResourceOpexCopyHolders.add(resourceOpexCopyHolder);
                }
            });
        });
        resourceCostCopyHolder.setResourceOpexCopyHolders(subWorkStreamResourceOpexCopyHolders);

        //Resource Capex
        List<SubWorkStreamResourceCapexCopyHolder> subWorkStreamResourceCapexCopyHolders = new ArrayList<>();
        Map<SubWorkStreamResourceCost, List<SubWorkStreamResourceCost>> capexResourceCosts = new HashMap<>();
        Map<SubWorkStreamResourceCost, List<SubWorkStreamResourceCost>> itDepreciationResourceCosts = new HashMap<>();

        resourceCostParentChildren.entrySet().stream()
                .forEach(
                        map -> {
                            if (map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_CAPEX)) {
                                capexResourceCosts.put(map.getKey(), map.getValue());
                            } else if(map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_ITDEPRECIATION)) {
                                itDepreciationResourceCosts.put(map.getKey(), map.getValue());
                            }
                        }
                );


        capexResourceCosts.forEach((capexResourceCostParent, capexResourceCostChildren)->{
            itDepreciationResourceCosts.forEach((itDepreciationResourceCostParent, itDepreciationResourceChildren)->{
                if(capexResourceCostParent.getSwsResourceSurrId().equals(itDepreciationResourceCostParent.getCapexOpexSurrId())){
                    SubWorkStreamResourceCapexCopyHolder resourceCapexCopyHolder = new SubWorkStreamResourceCapexCopyHolder();
                    resourceCapexCopyHolder.setSubWorkStreamResourceCapexCostParent(capexResourceCostParent);
                    resourceCapexCopyHolder.setSubWorkStreamResourceCapexCostChildren(capexResourceCostChildren);
                    resourceCapexCopyHolder.setSubWorkStreamResourceITDepreciationCostParent(itDepreciationResourceCostParent);
                    resourceCapexCopyHolder.setSubWorkStreamResourceITDepreciationCostChildren(itDepreciationResourceChildren);
                    subWorkStreamResourceCapexCopyHolders.add(resourceCapexCopyHolder);
                }
            });
        });
        resourceCostCopyHolder.setResourceCapexCopyHolders(subWorkStreamResourceCapexCopyHolders);
        return resourceCostCopyHolder;
    }


    private List<SubWorkStreamHardwareOpexCopyHolder>
    getHardwareCostParentChildren(List<SubWorkstreamHardwareCost> hardwareCostsEntities) {

        List<SubWorkStreamHardwareOpexCopyHolder> hardwareOpexCopyHolders =
                new ArrayList<>();
        Map<SubWorkstreamHardwareCost, List<SubWorkstreamHardwareCost>>
                hardwareCostParentChilderen = new HashMap<>();
        if (CollectionUtils.isNullOrEmpty(hardwareCostsEntities))
            return hardwareOpexCopyHolders;

        List<SubWorkstreamHardwareCost> hardwareCostParent =
                hardwareCostsEntities.stream().filter(entity -> entity.getOriginalInd().equals("true"))
                        .collect(Collectors.toList());

        List<SubWorkstreamHardwareCost> hardwareCostChildren =
                hardwareCostsEntities.stream().filter(entity -> entity.getOriginalInd().equals("false"))
                        .collect(Collectors.toList());

        hardwareCostParent.forEach(parentEntity -> {
            List<SubWorkstreamHardwareCost> softwareCosts =
                    hardwareCostChildren.stream().filter(childEntity -> childEntity.getRefSwsHwSurrId().equals(
                            parentEntity.getSwsHwSurrId())).collect(Collectors.toList());
            hardwareCostParentChilderen.put(parentEntity, softwareCosts);
        });
        return alignHardwareOpexCost(hardwareCostParentChilderen);
    }

    private List<SubWorkStreamHardwareOpexCopyHolder> alignHardwareOpexCost(Map<SubWorkstreamHardwareCost, List<SubWorkstreamHardwareCost>>
                                                                                    hardwareCostParentChildren){
        List<SubWorkStreamHardwareOpexCopyHolder> subWorkStreamHardwareOpexCopyHolders = new ArrayList<>();
        Map<SubWorkstreamHardwareCost, List<SubWorkstreamHardwareCost>> opexHardwareCosts =
                hardwareCostParentChildren.entrySet()
                        .stream()
                        .filter(map -> map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_OPEX))
                        .collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));

        Map<SubWorkstreamHardwareCost, List<SubWorkstreamHardwareCost>> ownershipHardwareCosts =
                hardwareCostParentChildren.entrySet()
                        .stream()
                        .filter(map -> map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_OWNERSHIP))
                        .collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));

        opexHardwareCosts.forEach((opexHardwareCostParent, opexHardwareCostChildren)->{
            ownershipHardwareCosts.forEach((ownershipHardwareCostParent, ownershipHardwareCostChildren)->{
                if(opexHardwareCostParent.getSwsHwSurrId().equals(ownershipHardwareCostParent.getCapexOpexSurrId())){
                    SubWorkStreamHardwareOpexCopyHolder hardwareOpexCopyHolder = new SubWorkStreamHardwareOpexCopyHolder();
                    hardwareOpexCopyHolder.setSubWorkStreamHardwareOpexCostParent(opexHardwareCostParent);
                    hardwareOpexCopyHolder.setSubWorkStreamHardwareOpexCostChildren(opexHardwareCostChildren);
                    hardwareOpexCopyHolder.setSubWorkStreamHardwareOwnershipCostParent(ownershipHardwareCostParent);
                    hardwareOpexCopyHolder.setSubWorkStreamHardwareOwnershipCostChildren(ownershipHardwareCostChildren);
                    subWorkStreamHardwareOpexCopyHolders.add(hardwareOpexCopyHolder);
                }
            });
        });
        return subWorkStreamHardwareOpexCopyHolders;
    }

    private SubWorkStreamOtherCostCopyHolder
    getOtherCostParentChildren(List<SubWorkstreamOtherCost> otherCostsEntities) {
        SubWorkStreamOtherCostCopyHolder subWorkStreamOtherCostCopyHolder =
                new SubWorkStreamOtherCostCopyHolder();
        Map<SubWorkstreamOtherCost, List<SubWorkstreamOtherCost>>
                otherCostParentChilderen = new HashMap<>();
        if (CollectionUtils.isNullOrEmpty(otherCostsEntities))
            return subWorkStreamOtherCostCopyHolder;

        List<SubWorkstreamOtherCost> otherCostParent =
                otherCostsEntities.stream().filter(entity -> entity.getOriginalInd().equals("true"))
                        .collect(Collectors.toList());

        List<SubWorkstreamOtherCost> otherCostChildren =
                otherCostsEntities.stream().filter(entity -> entity.getOriginalInd().equals("false"))
                        .collect(Collectors.toList());

        otherCostParent.forEach(parentEntity -> {
            List<SubWorkstreamOtherCost> otherCosts =
                    otherCostChildren.stream().filter(childEntity -> childEntity.getRefSwsOtherSurrId().equals(
                            parentEntity.getSwsOtherSurrId())).collect(Collectors.toList());
            otherCostParentChilderen.put(parentEntity, otherCosts);
        });
        return alignOtherOpexCapexCost(otherCostParentChilderen);
    }

    private SubWorkStreamOtherCostCopyHolder alignOtherOpexCapexCost(Map<SubWorkstreamOtherCost, List<SubWorkstreamOtherCost>>
                                                                                   otherCostParentChildren){
        SubWorkStreamOtherCostCopyHolder otherCostCopyHolder = new SubWorkStreamOtherCostCopyHolder();
        //Other Opex
        List<SubWorkStreamOtherOpexCopyHolder> subWorkStreamOtherOpexCopyHolders = new ArrayList<>();
        Map<SubWorkstreamOtherCost, List<SubWorkstreamOtherCost>> opexOtherCosts =
                otherCostParentChildren.entrySet()
                        .stream()
                        .filter(map -> map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_OPEX))
                        .collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));

        Map<SubWorkstreamOtherCost, List<SubWorkstreamOtherCost>> ownershipOtherCosts =
                otherCostParentChildren.entrySet()
                        .stream()
                        .filter(map -> map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_OWNERSHIP))
                        .collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));

        opexOtherCosts.forEach((opexOtherCostParent, opexOtherCostChildren)->{
            ownershipOtherCosts.forEach((ownershipOtherCostParent, ownershipOtherCostChildren)->{
                if(opexOtherCostParent.getSwsOtherSurrId().equals(ownershipOtherCostParent.getCapexOpexSurrId())){
                    SubWorkStreamOtherOpexCopyHolder otherOpexCopyHolder = new SubWorkStreamOtherOpexCopyHolder();
                    otherOpexCopyHolder.setSubWorkStreamOtherOpexCostParent(opexOtherCostParent);
                    otherOpexCopyHolder.setSubWorkStreamOtherOpexCostChildren(opexOtherCostChildren);
                    otherOpexCopyHolder.setSubWorkStreamOtherOwnershipCostParent(ownershipOtherCostParent);
                    otherOpexCopyHolder.setSubWorkStreamOtherOwnershipCostChildren(ownershipOtherCostChildren);
                    subWorkStreamOtherOpexCopyHolders.add(otherOpexCopyHolder);
                }
            });
        });
        otherCostCopyHolder.setOtherOpexCopyHolders(subWorkStreamOtherOpexCopyHolders);


        //Other Capex
        List<SubWorkStreamOtherCapexCopyHolder> subWorkStreamOtherCapexCopyHolders = new ArrayList<>();
        Map<SubWorkstreamOtherCost, List<SubWorkstreamOtherCost>> capexOtherCosts =
                otherCostParentChildren.entrySet()
                        .stream()
                        .filter(map -> map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_CAPEX))
                        .collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));

        Map<SubWorkstreamOtherCost, List<SubWorkstreamOtherCost>> itDepreciationOtherCosts =
                otherCostParentChildren.entrySet()
                        .stream()
                        .filter(map -> map.getKey().getGlCategory().equalsIgnoreCase(PortfolioConstants.GL_CATEGORY_ITDEPRECIATION))
                        .collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));

        capexOtherCosts.forEach((capexOtherCostParent, capexOtherCostChildren)->{
            itDepreciationOtherCosts.forEach((itDepreciationOtherCostParent, itDepreciationOtherChildren)->{
                if(capexOtherCostParent.getSwsOtherSurrId().equals(itDepreciationOtherCostParent.getCapexOpexSurrId())){
                    SubWorkStreamOtherCapexCopyHolder otherCapexCopyHolder = new SubWorkStreamOtherCapexCopyHolder();
                    otherCapexCopyHolder.setSubWorkStreamOtherCapexCostParent(capexOtherCostParent);
                    otherCapexCopyHolder.setSubWorkStreamOtherCapexCostChildren(capexOtherCostChildren);
                    otherCapexCopyHolder.setSubWorkStreamOtherITDepreciationCostParent(itDepreciationOtherCostParent);
                    otherCapexCopyHolder.setSubWorkStreamOtherITDepreciationCostChildren(itDepreciationOtherChildren);
                    subWorkStreamOtherCapexCopyHolders.add(otherCapexCopyHolder);
                }
            });
        });
        otherCostCopyHolder.setOtherCapexCopyHolders(subWorkStreamOtherCapexCopyHolders);
        return otherCostCopyHolder;
    }

    public Set<String> getScenarios(String requestType) {
        if (PortfolioConstants.PORTFOLIO_COPY_SCENARIO.equals(requestType)) {
            return getScenariosByCopyFunction(ScenarioConfigType.COPY_TO_PORTFOLIO.getScenarioConfigType());
        } else if (PortfolioConstants.WORKSTREAM_COPY_SCENARIO.equals(requestType)) {
            return getScenariosByCopyFunction(ScenarioConfigType.COPY_TO_WORKSTREAM.getScenarioConfigType());
        }
        return Collections.emptySet();
    }

    public Set<String> getScenariosForApproval(String requestType, String id) {
        Set<String> scenarios = null;
        if (PortfolioConstants.PORTFOLIO_COPY_SCENARIO.equals(requestType)) {
            scenarios = getAllPendingCopyScenariosUnderPortfolio(id);
        } else if (PortfolioConstants.WORKSTREAM_COPY_SCENARIO.equals(requestType)) {
            scenarios = getAllPendingCopyScenariosUnderWorkStream(id);
        }
        if(!CollectionUtils.isNullOrEmpty(scenarios)) {
            scenarios.remove(PortfolioConstants.COPY_SCENARIO_BUDGET_NEXTYEAR);
            return scenarios;
        }
        return Collections.emptySet();
    }

    private Set<String> getAllPendingCopyScenariosUnderPortfolio(String portfolioId) {
        List<WorkHierarchyEntity> workHierarchyList = getWorkHierarchy(portfolioId, null);
        List<String> workStreamIds = workHierarchyList.stream().map(WorkHierarchyEntity::getWorkStreamId).collect(Collectors.toList());
        Set<String> configScenariosForPortfolio = getScenariosByCopyFunction(ScenarioConfigType.COPY_TO_PORTFOLIO.getScenarioConfigType());
        if (CollectionUtils.isNullOrEmpty(configScenariosForPortfolio))
            return Collections.emptySet();
//        return workStreamKeyDatesRepo.findAllDistinctByWorkStreamIdInAndScenarioNameInAndApprovalDateIsNull(
//                workStreamIds, configScenariosForPortfolio);
        return subWorkStreamKeyDatesRepo.findAllDistinctByWorkStreamIdInAndScenarioNameInAndApprovalDateIsNull(
                workStreamIds, configScenariosForPortfolio);
    }

    private Set<String> getAllPendingCopyScenariosUnderWorkStream(String workStreamId) {
        List<String> workStreamIds = Arrays.asList(workStreamId);
        Set<String> configScenariosForWorkStream = getScenariosByCopyFunction(ScenarioConfigType.COPY_TO_WORKSTREAM.getScenarioConfigType());
        if (CollectionUtils.isNullOrEmpty(configScenariosForWorkStream))
            return Collections.emptySet();
//        return workStreamKeyDatesRepo.findAllDistinctByWorkStreamIdInAndScenarioNameInAndApprovalDateIsNull(
//                workStreamIds, configScenariosForWorkStream);
        return subWorkStreamKeyDatesRepo.findAllDistinctByWorkStreamIdInAndScenarioNameInAndApprovalDateIsNull(
                workStreamIds, configScenariosForWorkStream);
    }

    public List<String> getCopySnapshotFromScenarios() {
        return xrefScenarioConfigRepo.getCopySnapshotFromScenarios();
    }

    public List<String> getCopySnapshotToScenarios(String scenarioName) {
        return xrefScenarioConfigRepo.getCopySnapshotToScenarios(scenarioName);
    }

    public Set<String> getScenariosByCopyFunction(String copyFunction) {
        return xrefScenarioConfigRepo.findAllActiveScenariosForCopyByCopyFunction(copyFunction);
    }

    public void copySnapshot(CopyScenarioRequest copyScenarioRequest) {
        log.info(String.format("CopySnapshot executed for fromScenario: %s ,  and toScenario: %s ",
                copyScenarioRequest.getScenarioFrom() , copyScenarioRequest.getScenarioTo()));
        copyRepository.callBackEndFinancialProcedureCopySnapshot(copyScenarioRequest);
    }

    private List<String> getDeletableScenariosForCopy(String scenario){
        List<String> deletableScenarios = new ArrayList<>();
        deletableScenarios.add(scenario);
        if(scenario.contains(PortfolioConstants.COPY_SCENARIO_PENDING_APPROVAL_POSTFIX)){
            deletableScenarios.add(scenario.replace(
                    PortfolioConstants.COPY_SCENARIO_PENDING_APPROVAL_POSTFIX, PortfolioConstants.COPY_SCENARIO_APPROVED_POSTFIX));
        }
        return deletableScenarios;
    }

    private String getScenarioForApproval(String scenario){
        if(scenario.contains(PortfolioConstants.COPY_SCENARIO_PENDING_APPROVAL_POSTFIX)){
            scenario = scenario.replace(
                    PortfolioConstants.COPY_SCENARIO_PENDING_APPROVAL_POSTFIX, PortfolioConstants.COPY_SCENARIO_APPROVED_POSTFIX);
        }
        return scenario;
    }
}
