package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.ITCRateEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ITCRateRepo extends JpaRepository<ITCRateEntity,Integer> {


    @Query("SELECT DISTINCT e.tower FROM ITCRateEntity e order by e.tower")
    List<String> findDistinctTowers();

    @Query("SELECT DISTINCT e.uom FROM ITCRateEntity e order by e.uom")
    List<String> findDistinctUOM();

    @Query("SELECT DISTINCT e.driverDetail FROM ITCRateEntity e order by e.driverDetail")
    List<String> findDistinctDriverDetails();


}
