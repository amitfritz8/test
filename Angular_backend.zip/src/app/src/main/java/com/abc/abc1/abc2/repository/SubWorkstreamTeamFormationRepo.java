package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamTeamFormation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SubWorkstreamTeamFormationRepo extends JpaRepository<SubWorkstreamTeamFormation, Integer> {
}
