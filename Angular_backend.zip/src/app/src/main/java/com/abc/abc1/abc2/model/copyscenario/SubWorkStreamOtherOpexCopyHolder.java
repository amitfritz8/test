package com.dbs.genesis.portfolio.model.copyscenario;

import com.dbs.genesis.portfolio.model.SubWorkstreamOtherCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class SubWorkStreamOtherOpexCopyHolder {

    private SubWorkstreamOtherCost subWorkStreamOtherOpexCostParent;
    private List<SubWorkstreamOtherCost> subWorkStreamOtherOpexCostChildren =
            new ArrayList<>();

    private SubWorkstreamOtherCost subWorkStreamOtherOwnershipCostParent;
    private List<SubWorkstreamOtherCost> subWorkStreamOtherOwnershipCostChildren =
            new ArrayList<>();
}

