package com.dbs.genesis.portfolio.model;


import lombok.Data;
import lombok.ToString;
import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Date;

@Data
@Entity
@Table(name = "sub_workstream_dates")
@EntityListeners(AuditingEntityListener.class)
@ToString
@Audited(withModifiedFlag = true)
public class SubWorkStreamKeyDatesEntity extends CommonEntity<String> {

    @Id
    @Column(name = "sws_dt_surr_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int swsDateSurrId;
    @Column(name = "workstream_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "workstream_id_MOD")
    private String workStreamId;
    @Column(name = "sub_workstream_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_id_MOD")
    private String subWorkStreamId;
    @Column(name = "scenario_name")
    @Audited (withModifiedFlag = true, modifiedColumnName = "scenario_name_MOD")
    private String scenarioName;
    @Column(name = "date_type")
    @Audited (withModifiedFlag = true, modifiedColumnName = "date_type_MOD")
    private String dateType;
    @Column(name = "approval_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "approval_date_MOD")
    private Date approvalDate;
    @Column(name = "start_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "start_date_MOD")
    private Date startDate;
    @Column(name = "sw_eng_start_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sw_eng_start_date_MOD")
    private Date swEngStartDate;
    @Column(name = "depre_start_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "depre_start_date_MOD")
    private Date depreStartDate;
    @Column(name = "go_live_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "go_live_date_MOD")
    private Date goLiveDate;
    @Column(name = "end_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "end_date_MOD")
    private Date endDate;
    @Column(name = "active_ind")
    @Audited (withModifiedFlag = true, modifiedColumnName = "active_ind_MOD")
    private String activeInd;
    @Column(name = "sub_workstream_name")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_name_MOD")
    private String subWorkStreamName;


}
