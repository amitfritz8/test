package com.dbs.genesis.portfolio.service.workstream;

import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.DataValues;
import com.dbs.genesis.portfolio.model.SubWorkstreamFinDetailsEntity;
import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.repository.SubWorkstreamFinDetailsRepo;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import com.dbs.genesis.portfolio.service.costsettings.FinancialDetailsService;
import com.dbs.genesis.portfolio.service.financials.FinancialService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class WorkStreamBreakDownFinancialService {

    private final DataSummaryService dataSummaryService;
    private final FinancialService financialService;
    private final PortfolioRepository portfolioRepository;
    private final SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo;

    public WorkStreamBreakDownFinancialService(DataSummaryService dataSummaryService, FinancialService financialService, PortfolioRepository portfolioRepository, SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo, FinancialDetailsService financialDetailsService) {
        this.dataSummaryService = dataSummaryService;
        this.financialService = financialService;
        this.portfolioRepository = portfolioRepository;
        this.subWorkstreamFinDetailsRepo = subWorkstreamFinDetailsRepo;
    }

    public Map getFinancialDataByScenario(String scenario, String currencyCode, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String period, String typeOfData){
        List<DataValues> glCategoryValues =  getGlCategoryValues();
        LinkedHashSet<String> glGroups = financialService.getUniqueGlGroups(glCategoryValues);
        FinanceSummaryView financeSummaryView = new FinanceSummaryView();
        financeSummaryView.setName(PortfolioConstants.FINANCIAL_SUMMARY);
        financeSummaryView.setGlGroups(getGlGroupsWithCategoriesMap(glGroups,glCategoryValues,
                subWorkStreamIdAndNames,scenario,period,typeOfData, currencyCode));
        Map<String,Object> map = new TreeMap<>();
        map.put(scenario,financeSummaryView);
        return map;
    }

    List<GlGroup> getGlGroupsWithCategoriesMap(LinkedHashSet<String> glGroups, List<DataValues> glCategoryValues,
                                               List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                               String scenario, String period, String typeOfData,String currencyCode){
        List<GlGroup> glGroups1 = new ArrayList<>();
        glGroups.forEach(glGrp ->{
            GlGroup glGroup = new GlGroup();
            LinkedHashSet<String> glCategorySet = new LinkedHashSet<>();
            glCategoryValues.forEach(glCategoryValue ->{
                if(glCategoryValue.getDesc().contains(glGrp)){
                    glCategorySet.add(glCategoryValue.getValue());
                }
            });
            List<GlCategory> glCategories = new ArrayList<>();

            if(PortfolioConstants.MONTHLY.equalsIgnoreCase(typeOfData)) {
                glCategorySet.forEach(glCategory->{
                    glCategories.add(getGlCategory(glCategory,
                            subWorkStreamIdAndNames,scenario,period,currencyCode));
                });
                List<FinancialSummaryResource> financialSummaryResourceList =  subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> getSubWorkStreamGlCategoryValues(
                        glCategorySet, subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),
                        scenario, period,currencyCode)).flatMap(List::stream).collect(Collectors.toList());
                List<BigDecimal> monthlyGlGroupLevel = financialService.getMonthlyGlGroupLevel(financialSummaryResourceList);
                glGroup.setMonthlyFinanceTotal(monthlyGlGroupLevel);
                glGroup.setTotalSum(monthlyGlGroupLevel.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));

                BigDecimal glCategoryTotalSum = getGlCategoryTotalSum(scenario, subWorkStreamIdAndNames, glCategorySet,currencyCode);
                glGroup.setOverAllSum(glCategoryTotalSum);

            }

            List<String> financialYearsByScenario = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                            subWorkstreamFinDetailsRepo.getListOfFinancialYears(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),scenario,
                subWorkStreamIdAndName.getSubWorkStreamName())
                    ).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());

            if(PortfolioConstants.QUARTERLY.equalsIgnoreCase(typeOfData)) {
                Map<String,List<BigDecimal>> quarterlySummaryMap = new HashMap<>();
                Map<String,BigDecimal> individualYearSummaryForQuarterlyData = new HashMap<>();

                List<List<BigDecimal>> consolidatedQuarterlyOverAllSum = new ArrayList<>();
                BigDecimal totalOverAllQuarterlySum = BigDecimal.ZERO;
                List<BigDecimal> quarterlySummaryList = new ArrayList<>();
                for (String year : financialYearsByScenario) {
                    List<FinancialSummaryResource> financialSummaryResourceList =
                            subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> getSubWorkStreamGlCategoryValues(
                                    glCategorySet, subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, year,currencyCode))
                                    .flatMap(List::stream).collect(Collectors.toList());

                    quarterlySummaryList = financialService.getQuarterlySummaryListData(financialSummaryResourceList);
                    quarterlySummaryMap.put(year,quarterlySummaryList);
                    consolidatedQuarterlyOverAllSum.add(quarterlySummaryList);
                }
                glCategorySet.forEach(glCategory -> {
                    glCategories.add(getGlCategoryQuarterly(glCategory, subWorkStreamIdAndNames,
                            scenario,currencyCode));
                });
                glGroup.setQuarterlySummary(quarterlySummaryMap);
                quarterlySummaryMap.forEach((year, bigDecimals) -> {
                    individualYearSummaryForQuarterlyData.put(year,bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                });
                glGroup.setIndividualYearSummaryForQuarterly(individualYearSummaryForQuarterlyData);
                if (quarterlySummaryList != null && !quarterlySummaryList.isEmpty()) {
                    for (List<BigDecimal> list: consolidatedQuarterlyOverAllSum){
                        totalOverAllQuarterlySum = totalOverAllQuarterlySum.add(list.stream().reduce(BigDecimal::add)
                                .orElse(BigDecimal.ZERO));
                    }
                    glGroup.setOverAllSum(totalOverAllQuarterlySum);
                }
            }
            if (PortfolioConstants.YEARLY.equalsIgnoreCase(typeOfData)) {

                Map<String,BigDecimal> yearlyFinSummary = new HashMap<>();
                BigDecimal completeTotalYearsAmount = BigDecimal.ZERO;
                List<BigDecimal> yearlySum = new ArrayList<>();

                for (String year : financialYearsByScenario) {
                    BigDecimal yearlyFinSummarySum =BigDecimal.ZERO;
                    List<FinancialSummaryResource> yearlySummaryData = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                            getSubWorkStreamGlCategoryValues(glCategorySet, subWorkStreamIdAndName.getSubWorkStreamId(),
                                    subWorkStreamIdAndName.getSubWorkStreamName(), scenario, year,currencyCode))
                            .flatMap(List::stream).collect(Collectors.toList());
                    for(FinancialSummaryResource financialSummaryResource: yearlySummaryData){
                        yearlyFinSummarySum= yearlyFinSummarySum.add(new BigDecimal(financialSummaryResource.getCurrencyValue().doubleValue()));
                    }

                    yearlySum.add(yearlyFinSummarySum);
                    yearlyFinSummary.put(year,yearlyFinSummarySum);
                }

                completeTotalYearsAmount = completeTotalYearsAmount.add(yearlySum.stream().reduce(BigDecimal::add)
                        .orElse(BigDecimal.ZERO));
                glGroup.setYearlySummary(yearlyFinSummary);
                glGroup.setOverAllSum(completeTotalYearsAmount);
                glCategorySet.forEach(glCategory -> glCategories.add(getGlCategoryByYearly(glCategory, subWorkStreamIdAndNames,
                        scenario,currencyCode)));
            }

            glGroup.setName(glGrp);
            glGroup.setGlCategories(glCategories);
            glGroups1.add(glGroup);
        });
        return glGroups1;
    }



    private GlCategory getGlCategoryByYearly(String category, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario, String currencyCode) {

        Map<String,BigDecimal> yearlyFinanceSummary = new HashMap<>();

        List<BigDecimal> overAllTotal = new ArrayList<>();
        BigDecimal overAllYearsTotal = BigDecimal.ZERO;
        List<String> financialYearsByScenario = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamFinDetailsRepo.getListOfFinancialYears(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),scenario,
                        subWorkStreamIdAndName.getSubWorkStreamName())).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());;

        Set<String> glCategories = new HashSet<>();
        glCategories.add(category);
        for (String year : financialYearsByScenario) {
            BigDecimal calculateTotalAmount = BigDecimal.ZERO;
            List<FinancialSummaryResource> financialSummaryResources = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                    getSubWorkStreamGlCategoryValues(
                            glCategories, subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, year,currencyCode)
                    ).flatMap(List::stream).collect(Collectors.toList());
            List<BigDecimal> bigDecimalList = new ArrayList<>();

            for (FinancialSummaryResource financialSummaryResource : financialSummaryResources) {
                bigDecimalList.add(financialSummaryResource.getCurrencyValue());
            }
            if (!bigDecimalList.isEmpty()) {
                calculateTotalAmount = calculateTotalAmount.add(bigDecimalList.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
            }
            yearlyFinanceSummary.put(year,calculateTotalAmount);
            overAllTotal.add(calculateTotalAmount);
        }
        if (!overAllTotal.isEmpty()) {
            overAllYearsTotal = overAllYearsTotal.add(overAllTotal.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        }

        GlCategory glCategory = getDefaultGlCategory(category, new ArrayList<>(),new HashMap<>(), yearlyFinanceSummary,
                BigDecimal.ZERO, overAllYearsTotal);

        return glCategory;
    }

    GlCategory getGlCategory(String category,
                             List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario, String period,String currencyCode){
        Set<String> glCategories = new HashSet<>();
        glCategories.add(category);
        List<FinancialSummaryResource> financialSummaryResources = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> getSubWorkStreamGlCategoryValues(
                glCategories, subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, period,currencyCode))
                .flatMap(List::stream).collect(Collectors.toList());
        List<BigDecimal> monthlyValues = getMonthlyDataFromResource(financialSummaryResources, currencyCode);
        BigDecimal monthlySum = BigDecimal.ZERO;
        if (!monthlyValues.isEmpty()) {
            monthlySum = monthlyValues.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        }
        List<FinancialSummaryResource> financialSummaryResourceTotal =  PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> {
                    return portfolioRepository.getCostForFinancialCaseSummryValueByGroupCcy(subWorkStreamIdAndName.getSubWorkStreamId(),
                            subWorkStreamIdAndName.getSubWorkStreamName(),scenario,glCategories,financialService.getConditionalGlCategories());
                }).flatMap(List::stream).collect(Collectors.toList())
                : subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> {
            return portfolioRepository.getCostForFinancialCaseSummryValueByLocalCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),
                    scenario, glCategories,financialService.getConditionalGlCategories());
              }).flatMap(List::stream).collect(Collectors.toList());
        BigDecimal overAllSum = BigDecimal.ZERO;
        for (FinancialSummaryResource financialSummaryResource:financialSummaryResourceTotal){
            overAllSum = overAllSum.add(BigDecimal.valueOf(financialSummaryResource.getCurrencyValue().doubleValue()));
        }
        GlCategory glCategory = getDefaultGlCategory(category, monthlyValues,new HashMap<>(), new HashMap(),monthlySum,
                overAllSum);
        return glCategory;
    }

    private BigDecimal getGlCategoryTotalSum(String scenario, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, Set<String> glCategorySet,String currencyCode) {
        List<FinancialSummaryResource> financialSummaryResources = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                subWorkStreamIdAndNames.stream().map(workStreamIdAndName ->
                        portfolioRepository.getCostForFinancialCaseSummryValueByGroupCcy(workStreamIdAndName.getSubWorkStreamId(),workStreamIdAndName.getSubWorkStreamName(),
                                scenario,glCategorySet,financialService.getConditionalGlCategories())).flatMap(List::stream).collect(Collectors.toList())
                : subWorkStreamIdAndNames.stream().map(workStreamIdAndName -> portfolioRepository.getCostForFinancialCaseSummryValueByLocalCcy(workStreamIdAndName.getSubWorkStreamId()
                ,workStreamIdAndName.getSubWorkStreamName(),scenario,glCategorySet,financialService.getConditionalGlCategories())).flatMap(List::stream).collect(Collectors.toList());
        BigDecimal totalSum =BigDecimal.ZERO;
        for(FinancialSummaryResource financialSummaryResource : financialSummaryResources){
            totalSum = totalSum.add(financialSummaryResource.getCurrencyValue());
        }
        return totalSum;
    }

    GlCategory getGlCategoryQuarterly(String category, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario,String currencyCode){

        List<String> financialYearsByScenario = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamFinDetailsRepo.getListOfFinancialYears(subWorkStreamIdAndName.getWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamId(),scenario,
                        subWorkStreamIdAndName.getSubWorkStreamName())
        ).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());

        Map<String, List<BigDecimal>> quarterlyMap = new HashMap<>();
        BigDecimal totalQuarterlySum = BigDecimal.ZERO;
        List<BigDecimal> quarterlyValues;
        List<List<BigDecimal>> consolidatedQuarterlySum = new ArrayList<>();
        Map<String,BigDecimal> individualYearSummaryForQuarterlyData = new HashMap<>();
        Set<String> glCategories = new HashSet<>();
        glCategories.add(category);

        for (String year : financialYearsByScenario) {
            List<FinancialSummaryResource> financialSummaryResources =
                    subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> getSubWorkStreamGlCategoryValues(
                            glCategories, subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, year,currencyCode)).flatMap(List::stream).collect(Collectors.toList());
            quarterlyValues = financialService.getQuarterlyDataFromResource(year, financialSummaryResources,currencyCode);
            quarterlyMap.put(year, quarterlyValues);
            consolidatedQuarterlySum.add(quarterlyValues);
        }
        for (List<BigDecimal> list: consolidatedQuarterlySum){
            totalQuarterlySum = totalQuarterlySum.add(list.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        }
        quarterlyMap.forEach((year, bigDecimals) -> {
            individualYearSummaryForQuarterlyData.put(year,bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        });

        GlCategory glCategory = new GlCategory();
        glCategory.setName(category);
        glCategory.setQuarterlyFinance(quarterlyMap);
        glCategory.setOverAllSum(totalQuarterlySum);
        glCategory.setIndividualYearSummaryForQuarterly(individualYearSummaryForQuarterlyData);

        return glCategory;
    }

    private GlCategory getDefaultGlCategory(String category, List<BigDecimal> monthlyValues,Map<String,List<BigDecimal>>
            quarterlyFinance,Map yearlySum,BigDecimal monthlySum, BigDecimal overAllSum) {
        return getGlCategory(category, monthlyValues, quarterlyFinance, yearlySum, monthlySum, overAllSum);
    }

    static GlCategory getGlCategory(String category, List<BigDecimal> monthlyValues, Map<String, List<BigDecimal>> quarterlyFinance, Map yearlySum, BigDecimal monthlySum, BigDecimal overAllSum) {
        GlCategory glCategory = new GlCategory();
        glCategory.setName(category);
        glCategory.setMonthlyFinance(monthlyValues);
        glCategory.setTotalSum(monthlySum);
        glCategory.setQuarterlyFinance(quarterlyFinance);
        glCategory.setYearlySummary(yearlySum);
        glCategory.setOverAllSum(overAllSum);
        return glCategory;
    }

    private List<FinancialSummaryResource> getSubWorkStreamGlCategoryValues(Set<String> glCategories, String subWorkStreamId, String subWorkStreamName, String scenario, String period, String currencyCode) {

        return PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                portfolioRepository.getCostForFinancialCaseSummryByGroupCcy(subWorkStreamId,subWorkStreamName,period,scenario,glCategories,financialService.getConditionalGlCategories()) :
                portfolioRepository.getCostForFinancialCaseSummryByLocalCcy(subWorkStreamId,subWorkStreamName,period,scenario,glCategories,financialService.getConditionalGlCategories());
    }

    public  List<BigDecimal> getMonthlyDataFromResource(List<FinancialSummaryResource> financialSummaryResources, String currencyCode) {
        BigDecimal[] defaultVales = new BigDecimal[12];
        Arrays.fill(defaultVales, BigDecimal.ZERO);
        for (FinancialSummaryResource financialSummaryResource : financialSummaryResources) {
            String reportingMonth = financialSummaryResource.getPeriod().substring(4, 6);
            if(PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                defaultVales[Integer.parseInt(reportingMonth) - 1] = defaultVales[Integer.parseInt(reportingMonth) - 1].add(financialSummaryResource.getCurrencyValue());
            }
        }
        return Arrays.asList(defaultVales);
    }

    private List<DataValues> getGlCategoryValues() {
        List<DataValues> dataValuesList = dataSummaryService.getDataValuesBySummaryId(PortfolioConstants.
                GL_CATEGORY_REF_DATA);
        dataValuesList.sort(Comparator.comparing(DataValues::getAttr1));
        return dataValuesList;
    }
}
