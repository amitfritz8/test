package com.dbs.genesis.portfolio;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class Delete2 {
    public static void main(String[] args) {

        List<String> list = new ArrayList();

        list.add("201901"); //"100$"


        list.add("201904");

        list.add("201906");

        list.add("201907");
        list.add("201908");
        list.add("201909");

        list.add("201910");
        list.add("201911");
        list.add("201912");
        System.out.println(getFirstQuarterlyPosition("2019",list));
        System.out.println(getSecondQuarterlyPosition("2019",list));
        System.out.println(getThirdQuarterlyPosition("2019",list).size());
        System.out.println(getFourthQuarterlyPosition("2019",list).size());

        BigDecimal bigDecimal = new BigDecimal(BigInteger.ZERO);
        BigDecimal b = BigDecimal.valueOf(8);
        System.out.println(bigDecimal.add(b));
        String s = "P19-20001-I";
        System.out.println("*************  "+s.substring(s.indexOf("-")+1).substring(0,2)+"-");
        System.out.println("*************  "+s.substring(s.length()-1));



    }

    private static List getFirstQuarterlyPosition(String year, List<String> period) {

        List list = new ArrayList();

        for (String s : period) {
            if("2019".equalsIgnoreCase(year) && "01".equalsIgnoreCase(s.substring(4,6))) {
                list.add(s);
            } if ("2019".equalsIgnoreCase(year) && "02".equalsIgnoreCase(s.substring(4,6))) {
                list.add(s);
            } if ("2019".equalsIgnoreCase(year) &&  "03".equalsIgnoreCase(s.substring(4,6))) {
                list.add(s);
            }
        }

        return list;
    }

    private static List getSecondQuarterlyPosition(String year, List<String> period) {

        List list = new ArrayList();

        for (String s : period) {
            if("2019".equalsIgnoreCase(year) && "04".equalsIgnoreCase(s.substring(4,6))) {
                list.add(s);
            } if ("2019".equalsIgnoreCase(year) && "05".equalsIgnoreCase(s.substring(4,6))) {
                list.add(s);
            } if ("2019".equalsIgnoreCase(year) &&  "06".equalsIgnoreCase(s.substring(4,6))) {
                list.add(s);
            }
        }
        return list;
    }

    private static List getThirdQuarterlyPosition(String year, List<String> period) {

        List list = new ArrayList();
        for (String s : period) {
            if("2019".equalsIgnoreCase(year) && "07".equalsIgnoreCase(s.substring(4,6))) {
                list.add(s);
            } if ("2019".equalsIgnoreCase(year) && "08".equalsIgnoreCase(s.substring(4,6))) {
                list.add(s);
            } if ("2019".equalsIgnoreCase(year) &&  "09".equalsIgnoreCase(s.substring(4,6))) {
                list.add(s);
            }
        }
        return list;
    }


    private static List getFourthQuarterlyPosition(String year, List<String> period) {

        List list = new ArrayList();
        for (String s : period) {
            if("2019".equalsIgnoreCase(year) && "10".equalsIgnoreCase(s.substring(4,6))) {
                list.add(s);
            } if ("2019".equalsIgnoreCase(year) && "11".equalsIgnoreCase(s.substring(4,6))) {
                list.add(s);
            } if ("2019".equalsIgnoreCase(year) &&  "12".equalsIgnoreCase(s.substring(4,6))) {
                list.add(s);
            }
        }
        return list;
    }

}
