

package com.dbs.genesis.portfolio.client;


import com.dbs.genesis.portfolio.config.RestTeamplateLoadBalanced;
import com.dbs.genesis.portfolio.model.WorkstreamOclaw;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriUtils;


@Component
public class WorkStreamOCLAClient {

    @Value("${oclaw.url}")
    String oclawUrl;

    @Value("${oclaw.token}")
    String oclawToken;

    @Autowired
    RestTeamplateLoadBalanced restTeamplateLoadBalanced;


    public ResponseEntity<Object> postOclawData(WorkstreamOclaw workstreamOclaw) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer " + oclawToken);
        headers.add("Content-type","application/json");
        HttpEntity entity = new HttpEntity(workstreamOclaw, headers);
        String result = UriUtils.encodeFragment(oclawUrl , "UTF-8");
        RestTemplate rt=restTeamplateLoadBalanced.getRestTemplate();

        ResponseEntity<Object> response = rt.exchange(
                result,
                HttpMethod.POST,
                entity,
                new ParameterizedTypeReference<Object>() {
                });
        return response;

    }
}