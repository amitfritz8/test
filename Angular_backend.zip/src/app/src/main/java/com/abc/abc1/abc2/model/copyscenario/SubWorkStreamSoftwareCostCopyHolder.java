package com.dbs.genesis.portfolio.model.copyscenario;

import com.dbs.genesis.portfolio.model.SubWorkstreamFinDetailsEntity;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class SubWorkStreamSoftwareCostCopyHolder {

    private List<SubWorkStreamSoftwareOpexCopyHolder> softwareOpexCopyHolders =
            new ArrayList<>();

    private List<SubWorkStreamSoftwareCapexCopyHolder> softwareCapexCopyHolders =
            new ArrayList<>();

}
