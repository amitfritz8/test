package com.dbs.genesis.portfolio.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.util.ArrayList;
import java.util.List;

@Data
@FieldDefaults(level = AccessLevel.PUBLIC)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class NavItem {

    public NavItem(String displayName, String displayID) {
        this.displayName = displayName;
        this.displayID = displayID;
    }

    public NavItem() {

    }

    String displayName;
    String displayID;
    String isShow;
    List<NavItem> children = new ArrayList<>(0);
}
