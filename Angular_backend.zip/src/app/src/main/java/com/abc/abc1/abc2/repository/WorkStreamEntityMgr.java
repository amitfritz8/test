package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.resources.WorkStreamListingSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Slf4j
@Repository
public class WorkStreamEntityMgr {

    @PersistenceContext
    private EntityManager entityManager;

    public List<WorkStreamListingSource> getWorkStreamListingByOneBankId(String scenario, List<String> platform, List<String> reportingFlag, List<String> locations, String oneBankId) {
        Query namedQuery = entityManager.createNamedQuery("workStreamListingByOneBankId");
        namedQuery.setParameter(1,scenario);
        namedQuery.setParameter(2,platform);
        namedQuery.setParameter(3,reportingFlag);
        namedQuery.setParameter(4,locations);
        namedQuery.setParameter(5,oneBankId);
        return namedQuery.getResultList();
    }

    public List<WorkStreamListingSource> getAllWorkStreamListings(String scenario, List<String> platform,  List<String> reportingFlag, List<String> locations) {
        Query namedQuery = entityManager.createNamedQuery("workStreamListingAll");
        namedQuery.setParameter(1,scenario);
        namedQuery.setParameter(2,platform);
        namedQuery.setParameter(3,reportingFlag);
        namedQuery.setParameter(4,locations);
        return namedQuery.getResultList();
    }
}
