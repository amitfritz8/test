package com.dbs.genesis.portfolio.model;

import com.dbs.genesis.portfolio.resources.FinancialSummaryResource;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@SqlResultSetMappings({
        @SqlResultSetMapping(name = "financialSummaryResourceResult",classes = {
                @ConstructorResult(targetClass = FinancialSummaryResource.class,
                        columns = {
                            @ColumnResult(name = "currencyValue",type = BigDecimal.class),
                            @ColumnResult(name = "period")
                })
        }),
        @SqlResultSetMapping(name = "financialSummaryResourceResultValue",classes = {
                @ConstructorResult(targetClass = FinancialSummaryResource.class,
                        columns = {
                                @ColumnResult(name = "currencyValue",type = BigDecimal.class)
                        })
        }),
        @SqlResultSetMapping(name = "financialSummaryResourcePeriodResult",classes = {
                @ConstructorResult(targetClass = FinancialSummaryResource.class,
                        columns = {
                                @ColumnResult(name = "period")
                        })
        }),
        @SqlResultSetMapping(name = "financialSummaryResourceResultWithFte",classes = {
                @ConstructorResult(targetClass = FinancialSummaryResource.class,
                        columns = {
                                @ColumnResult(name = "currencyValue",type = BigDecimal.class),
                                @ColumnResult(name = "period"),
                                @ColumnResult(name = "fte",type = BigDecimal.class)

                        })
        }),
        @SqlResultSetMapping(name = "finSummaryResourceCostOverAllGroupTotal",classes = {
                @ConstructorResult(targetClass = FinancialSummaryResource.class,
                        columns = {
                                @ColumnResult(name = "currencyValue",type = BigDecimal.class)
                        })
        }),
        @SqlResultSetMapping(name = "finSummaryResourceCostOverAllLocalTotal",classes = {
                @ConstructorResult(targetClass = FinancialSummaryResource.class,
                        columns = {
                                @ColumnResult(name = "currencyValue",type = BigDecimal.class)
                        })
        }),
})

@NamedNativeQueries({
        @NamedNativeQuery(name = "financialHeaderSummaryByPeriodAndGroupCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue,coalesce(period,'') as period  from\n" +
                        "(select coalesce(sum(cost_per_month_gcy),0) as currencyValue,period from vw_sws_software_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and substr(period,1,4)= :period and gl_category not in :glCategories and period is not null group by period\n" +
                        "union\n" +
                        "select coalesce(sum(group_ccy_val),0) as currencyValue,period from vw_sws_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName \n" +
                        "and scenario= :scenario and substr(period,1,4)= :period and gl_category not in :glCategories and period is not null group by period\n" +
                        "union\n" +
                        "select coalesce(sum(cost_per_month_gcy),0) as currencyValue,period from vw_sws_hardware_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and period is not null group by period " +
                        "UNION\n" +
                        " select coalesce(sum(blended_cost_gcy),0) as currencyValue,period from vw_sws_resource_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        " and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and period is not null group by period" +
                        ") as total_cost group by period;",
                resultSetMapping = "financialSummaryResourceResult"),
        @NamedNativeQuery(name = "financialHeaderSummaryByPeriodAndLocalCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue,coalesce(period,'') as period  from\n" +
                        "(select coalesce(sum(cost_per_month_lcy),0) as currencyValue,period from vw_sws_software_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and substr(period,1,4)= :period and gl_category not in :glCategories and period is not null group by period\n" +
                        "union\n" +
                        "select coalesce(sum(local_ccy_val),0) as currencyValue,period from vw_sws_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName \n" +
                        "and scenario= :scenario and substr(period,1,4)= :period and gl_category not in :glCategories and period is not null group by period\n" +
                        "union\n" +
                        "select coalesce(sum(cost_per_month_lcy),0) as currencyValue,period from vw_sws_hardware_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario  and substr(period,1,4)= :period and gl_category not in :glCategories and period is not null group by period " +
                        "UNION\n" +
                        " select coalesce(sum(blended_cost_lcy),0) as currencyValue,period from vw_sws_resource_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        " and scenario= :scenario  and substr(period,1,4)= :period and gl_category not in :glCategories  and period is not null group by period" +
                        ") as total_cost group by period;",
                resultSetMapping = "financialSummaryResourceResult"),
        @NamedNativeQuery(name = "financialHeaderSummaryTotalByGroupCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue  from\n" +
                        "(select coalesce(sum(cost_per_month_gcy),0) as currencyValue,period from vw_sws_software_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario  and gl_category not in :glCategories and period is not null group by period\n" +
                        "union\n" +
                        "select coalesce(sum(group_ccy_val),0) as currencyValue,period from vw_sws_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName \n" +
                        "and scenario= :scenario  and gl_category not in :glCategories and period is not null group by period\n" +
                        "union\n" +
                        "select coalesce(sum(cost_per_month_gcy),0) as currencyValue,period from vw_sws_hardware_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario  and gl_category not in :glCategories and period is not null group by period " +
                        "UNION \n" +
                        "select coalesce(sum(blended_cost_gcy),0) as currencyValue,period from vw_sws_resource_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario  and gl_category not in :glCategories and period is not null group by period) as totalCost;",
                resultSetMapping = "financialSummaryResourceResultValue"),
        @NamedNativeQuery(name = "financialHeaderSummaryTotalByLocalCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue  from\n" +
                        "(select coalesce(sum(cost_per_month_lcy),0) as currencyValue,period from vw_sws_software_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario  and gl_category not in :glCategories and period is not null group by period\n" +
                        "union\n" +
                        "select coalesce(sum(local_ccy_val),0) as currencyValue,period from vw_sws_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName \n" +
                        "and scenario= :scenario  and gl_category not in :glCategories and period is not null group by period\n" +
                        "union\n" +
                        "select coalesce(sum(cost_per_month_lcy),0) as currencyValue,period from vw_sws_hardware_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario  and gl_category not in :glCategories and period is not null group by period " +
                        "UNION \n" +
                        "select coalesce(sum(blended_cost_lcy),0) as currencyValue,period from vw_sws_resource_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario  and gl_category not in :glCategories and period is not null group by period) as totalCost;",
                resultSetMapping = "financialSummaryResourceResultValue"),
        @NamedNativeQuery(name = "financialSoftwareHeaderSummaryByPeriodAndGroupCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue,coalesce(period,'') as period  from\n" +
                        "(select coalesce(sum(cost_per_month_gcy),0) as currencyValue,period from vw_sws_software_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and period is not null group by period" +
                        " /*union select coalesce(sum(group_ccy_val),0) as currencyValue,period from vw_sws_other_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName" +
                        " and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and cost_type =:costType and period is not null group by period*/) as total_cost group by period;",
                resultSetMapping = "financialSummaryResourceResult"),
        @NamedNativeQuery(name = "financialSoftwareHeaderSummaryByPeriodAndLocalCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue,coalesce(period,'') as period  from\n" +
                        "(select coalesce(sum(cost_per_month_lcy),0) as currencyValue,period from vw_sws_software_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        " and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and period is not null group by period" +
                        " /*union select coalesce(sum(local_ccy_val),0) as currencyValue,period from vw_sws_other_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                        " and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and cost_type =:costType and period is not null group by period*/) as total_cost group by period;",
                resultSetMapping = "financialSummaryResourceResult"),
        @NamedNativeQuery(name = "financialHardwareHeaderSummaryByPeriodAndGroupCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue,coalesce(period,'') as period  from\n" +
                        "(select coalesce(sum(cost_per_month_gcy),0) as currencyValue,period from vw_sws_hardware_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and period is not null group by period" +
                        " /*union select coalesce(sum(group_ccy_val),0) as currencyValue,period from vw_sws_other_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName" +
                        " and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and cost_type =:costType and period is not null group by period*/) as total_cost group by period;",
                resultSetMapping = "financialSummaryResourceResult"),
        @NamedNativeQuery(name = "financialHardwareHeaderSummaryByPeriodAndLocalCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue,coalesce(period,'') as period  from\n" +
                        "(select coalesce(sum(cost_per_month_lcy),0) as currencyValue,period from vw_sws_hardware_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and period is not null group by period " +
                        " /*union select coalesce(sum(local_ccy_val),0) as currencyValue,period from vw_sws_other_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                        " and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and cost_type =:costType and period is not null group by period*/) as total_cost group by period;",
                resultSetMapping = "financialSummaryResourceResult"),
        @NamedNativeQuery(name = "financialResourceHeaderSummaryByPeriodAndGroupCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue,coalesce(period,'') as period, coalesce(sum(fte),0) as fte  from\n" +
                        "(select coalesce(sum(blended_cost_gcy),0) as currencyValue,period, coalesce(sum(fte),0) as fte from vw_sws_resource_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and cost_type= :costType and period is not null group by period" +
                        " union select coalesce(sum(group_ccy_val),0) as currencyValue,period, '0' as fte from vw_sws_other_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                        "  and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and cost_type =:costType and period is not null group by period) as total_cost group by period order by period;",
                resultSetMapping = "financialSummaryResourceResultWithFte"),

        @NamedNativeQuery(name = "financialResourceHeaderSummaryByPeriodAndLocalCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue,coalesce(period,'') as period, coalesce(sum(fte),0) as fte  from\n" +
                        "(select coalesce(sum(blended_cost_lcy),0) as currencyValue,period, coalesce(sum(fte),0) as fte from vw_sws_resource_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and cost_type= :costType  and period is not null group by period" +
                        " union select coalesce(sum(local_ccy_val),0) as currencyValue,period,'0' as fte from vw_sws_other_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName " +
                        "  and scenario= :scenario and substr(period,1,4)= :period  and gl_category not in :glCategories and cost_type =:costType and period is not null group by period ) as total_cost group by period order by period;",
                resultSetMapping = "financialSummaryResourceResultWithFte"),


        @NamedNativeQuery(name = "financialResourceCostTypeOverAllTotalByGroupCurrency",
                query = "select coalesce(sum(currencyValue),0) as currencyValue  from\n" +
                        "(select coalesce(sum(blended_cost_gcy),0) as currencyValue from vw_sws_Resource_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null\n" +
                        "union\n" +
                        "select coalesce(sum(group_ccy_val),0) as currencyValue from vw_sws_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName \n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null) as totalCost;",
                resultSetMapping = "finSummaryResourceCostOverAllGroupTotal"),


        @NamedNativeQuery(name = "financialResourceCostTypeOverAllTotalByLocalCurrency",
                query ="select coalesce(sum(currencyValue),0) as currencyValue  from\n" +
                        "(select coalesce(sum(blended_cost_lcy),0) as currencyValue from vw_sws_Resource_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null\n" +
                        "union\n" +
                        "select coalesce(sum(local_ccy_val),0) as currencyValue from vw_sws_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName \n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null) as totalCost;",
                resultSetMapping = "finSummaryResourceCostOverAllLocalTotal"),



        @NamedNativeQuery(name = "financialOtherHeaderSummaryByPeriodAndGroupCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue,coalesce(period,'') as period  from\n" +
                        "(select coalesce(sum(group_ccy_val),0) as currencyValue,period from vw_sws_other_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and substr(period,1,4)= :period and period is not null group by period" +
                        ") as total_cost group by period;",
                resultSetMapping = "financialSummaryResourceResult"),
        @NamedNativeQuery(name = "financialOtherHeaderSummaryByPeriodAndLocalCcy",
                query = "select coalesce(sum(currencyValue),0) as currencyValue,coalesce(period,'') as period  from\n" +
                        "(select coalesce(sum(local_ccy_val),0) as currencyValue,period from vw_sws_other_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and substr(period,1,4)= :period and period is not null group by period" +
                        ") as total_cost group by period;",
                resultSetMapping = "financialSummaryResourceResult"),
        @NamedNativeQuery(name = "financialSoftwareCostTypeOverAllTotalByGroupCurrency",
                query = "select coalesce(sum(currencyValue),0) as currencyValue  from\n" +
                        "(select coalesce(sum(cost_per_month_gcy),0) as currencyValue,period from vw_sws_software_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null group by period\n" +
                        "union\n" +
                        "select coalesce(sum(group_ccy_val),0) as currencyValue,period from vw_sws_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName \n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null group by period) as totalCost;",
                resultSetMapping = "financialSummaryResourceResultValue"),
        @NamedNativeQuery(name = "financialSoftwareCostTypeOverAllTotalByLocalCurrency",
                query ="select coalesce(sum(currencyValue),0) as currencyValue  from\n" +
                        "(select coalesce(sum(cost_per_month_lcy),0) as currencyValue,period from vw_sws_software_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null group by period\n" +
                        "union\n" +
                        "select coalesce(sum(local_ccy_val),0) as currencyValue,period from vw_sws_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName \n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null group by period) as totalCost;",
                resultSetMapping = "financialSummaryResourceResultValue"),
        @NamedNativeQuery(name = "financialHardwareCostTypeOverAllTotalByGroupCurrency",
                query = "select coalesce(sum(currencyValue),0) as currencyValue  from\n" +
                        "(select coalesce(sum(cost_per_month_gcy),0) as currencyValue,period from vw_sws_hardware_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null group by period\n" +
                        "union\n" +
                        "select coalesce(sum(group_ccy_val),0) as currencyValue,period from vw_sws_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName \n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null group by period) as totalCost;",
                resultSetMapping = "financialSummaryResourceResultValue"),
        @NamedNativeQuery(name = "financialHardwareCostTypeOverAllTotalByLocalCurrency",
                query ="select coalesce(sum(currencyValue),0) as currencyValue  from\n" +
                        "(select coalesce(sum(cost_per_month_lcy),0) as currencyValue,period from vw_sws_hardware_cost where  sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName\n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null group by period\n" +
                        "union\n" +
                        "select coalesce(sum(local_ccy_val),0) as currencyValue,period from vw_sws_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName \n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null group by period) as totalCost;",
                resultSetMapping = "financialSummaryResourceResultValue"),
        @NamedNativeQuery(name = "financialOthersCostTypeOverAllTotalByGroupCurrency",
                query = "select coalesce(sum(currencyValue),0) as currencyValue  from\n" +
                        "(select coalesce(sum(group_ccy_val),0) as currencyValue,period from vw_sws_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName \n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null group by period) as totalCost;",
                resultSetMapping = "financialSummaryResourceResultValue"),
        @NamedNativeQuery(name = "financialOthersCostTypeOverAllTotalByLocalCurrency",
                query ="select coalesce(sum(currencyValue),0) as currencyValue  from\n" +
                        "(select coalesce(sum(local_ccy_val),0) as currencyValue,period from vw_sws_other_cost where sub_workstream_id= :subWorkStreamId  and sub_workstream_name= :subWorkStreamName \n" +
                        "and scenario= :scenario and cost_type= :costType  and gl_category not in :glCategories and period is not null group by period) as totalCost;",
                resultSetMapping = "financialSummaryResourceResultValue"),
        @NamedNativeQuery(name = "getDistinctfinancialSoftwareCostTypeOverAllTotal",
                query = "select coalesce(period,'') as period from\n" +
                        "(SELECT DISTINCT substring(e.period,1,4) as period FROM vw_sws_software_cost e where e.sub_workstream_id = :subWorkStreamId and e.sub_workstream_name = :subWorkStreamName and \n" +
                        " scenario = :scenario  and e.gl_category not in :glCategories and period is not null \n" +
                        " union SELECT DISTINCT substring(e.period,1,4) as period FROM vw_sws_other_cost e where e.sub_workstream_id = :subWorkStreamId and e.sub_workstream_name = :subWorkStreamName and \n" +
                        " e.scenario = :scenario and e.cost_type = :costType  and e.gl_category not in :glCategories and period is not null) as totalPeriods;",
                resultSetMapping = "financialSummaryResourcePeriodResult"),
        @NamedNativeQuery(name = "getDistinctfinancialHardwareCostTypeOverAllTotal",
                query = "select coalesce(period,'') as period from\n" +
                        "(SELECT DISTINCT substring(e.period,1,4) as period FROM vw_sws_hardware_cost e where e.sub_workstream_id = :subWorkStreamId and e.sub_workstream_name = :subWorkStreamName and \n" +
                        " scenario = :scenario and e.gl_category not in :glCategories and period is not null \n" +
                        " union SELECT DISTINCT substring(e.period,1,4) as period FROM vw_sws_other_cost e where e.sub_workstream_id = :subWorkStreamId and e.sub_workstream_name = :subWorkStreamName and \n" +
                        " e.scenario = :scenario and e.gl_category not in :glCategories and e.cost_type = :costType  and period is not null) as totalPeriods;",
                resultSetMapping = "financialSummaryResourcePeriodResult"),
        @NamedNativeQuery(name = "getDistinctfinancialOthersCostTypeOverAllTotal",
                query = "select coalesce(period,'') as period from\n" +
                        "(SELECT DISTINCT substring(e.period,1,4) as period FROM vw_sws_other_cost e where e.sub_workstream_id = :subWorkStreamId and e.sub_workstream_name = :subWorkStreamName and \n" +
                        " e.scenario = :scenario and e.gl_category not in :glCategories and e.cost_type = :costType and period is not null) as totalPeriods;",
                resultSetMapping = "financialSummaryResourcePeriodResult"),


})


@Data
@Entity
@Table(name = "sub_workstream_software_cost")
@EntityListeners(AuditingEntityListener.class)
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Audited(withModifiedFlag = true)
public class SubWorkstreamSoftwareCost extends CommonEntity<String>{

    @Id
    @Column(name = "sw_cost_surr_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer swsSwSurrId;
    @Column(name = "workstream_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "workstream_id_MOD")
    private String workStreamId;
    @Column(name = "sub_workstream_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_id_MOD")
    private String subWorkStreamId;
    @Column(name = "sub_workstream_name")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_name_MOD")
    private String subWorkStreamName;
    @Column(name = "scenario")
    @Audited (withModifiedFlag = true, modifiedColumnName = "scenario_MOD")
    private String scenario;
    @Column(name = "software_name")
    @Audited (withModifiedFlag = true, modifiedColumnName = "software_name_MOD")
    private String softwareName;
    @Column(name = "vendor_name")
    @Audited (withModifiedFlag = true, modifiedColumnName = "vendor_name_MOD")
    private String vendorName;
    @Column(name = "software_type")
    @Audited (withModifiedFlag = true, modifiedColumnName = "software_type_MOD")
    private String softwareType;
    @Column(name = "quantity")
    @Audited (withModifiedFlag = true, modifiedColumnName = "quantity_MOD")
    private BigDecimal quantity = BigDecimal.ZERO;
    @Column(name = "gl_category")
    @Audited (withModifiedFlag = true, modifiedColumnName = "gl_category_MOD")
    private String glCategory;
    @Column(name = "software_desc")
    @Audited (withModifiedFlag = true, modifiedColumnName = "software_desc_MOD")
    private String softwareDesc;
    @Column(name = "local_ccy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "local_ccy_MOD")
    private String localCcy;
    @Column(name = "group_ccy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "group_ccy_MOD")
    private String groupCcy;
    @Column(name = "unit_price")
    @Audited (withModifiedFlag = true, modifiedColumnName = "unit_price_MOD")
    private BigDecimal unitPrice = BigDecimal.ZERO;
    @Column(name = "cost_per_month_lcy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "cost_per_month_lcy_MOD")
    private BigDecimal costPerMonthLcy = BigDecimal.ZERO;
    @Column(name = "cost_per_month_gcy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "cost_per_month_gcy_MOD")
    private BigDecimal costPerMonthGcy = BigDecimal.ZERO;
    @Column(name = "effective_start_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "effective_start_date_MOD")
    private Timestamp effectiveStartDate;
    @Column(name = "effective_end_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "effective_end_date_MOD")
    private Timestamp effectiveEndDate;
    @Column(name = "period")
    @Audited (withModifiedFlag = true, modifiedColumnName = "period_MOD")
    private String period;
    @Column(name = "active_ind")
    @Audited (withModifiedFlag = true, modifiedColumnName = "active_ind_MOD")
    private String activeInd;
    @Column(name = "original_ind")
    @Audited (withModifiedFlag = true, modifiedColumnName = "original_ind_MOD")
    private String originalInd;
    @Column(name = "ref_sw_cost_surr_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "ref_sw_cost_surr_id_MOD")
    private Integer refSwsSwSurrId;
    @Column(name = "cost_settings")
    @Audited (withModifiedFlag = true, modifiedColumnName = "cost_settings_MOD")
    private String costSettings;
    @Column(name = "add_software")
    @Audited (withModifiedFlag = true, modifiedColumnName = "add_software_MOD")
    private String add_software;
    @Column(name = "capex_opex_surr_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "capex_opex_surr_id_MOD")
    private Integer capexOpexSurrId;
    @Column(name = "cost_type_detail")
    @Audited (withModifiedFlag = true, modifiedColumnName = "cost_type_detail_MOD")
    private String costTypeDetail;

}
