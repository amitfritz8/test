package com.dbs.genesis.portfolio.service;

import com.amazonaws.util.CollectionUtils;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.*;
import com.dbs.genesis.portfolio.resources.FinSysProjectIdCreationEvent;
import com.dbs.genesis.portfolio.resources.PortfolioCreationEvent;
import com.dbs.genesis.portfolio.resources.StageWorkdayData;
import com.dbs.genesis.portfolio.resources.SubWorkStream;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import javax.validation.constraints.NotNull;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Transactional
@Service
public class PortFolioWorkStreamAndSubWorkStreamGenerator {

    public static final String YES = "Yes";
    @Autowired
    private PortfolioRepo portfolioRepo;
    @Autowired
    private WorkHierarchyRepo workHierarchyRepo;
    @Autowired
    private WorkStreamRepo workStreamRepo;
    @Autowired
    private PortfolioRepository portfolioNativeRepository;
    @Autowired
    private SequenceGeneratorRepo sequenceGeneratorRepo;
    @Autowired
    private DataSummaryService dataSummaryService;
    @Autowired
    private SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    @Autowired
    private PortfolioManagersRepo portfolioManagersRepo;

    @Autowired
    private ApplicationEventPublisher publisher;


    public List<WorkHierarchyEntity> generate(PortfolioCreationEvent portfolioCreationEvent, String userId) {
        log.info("Generate portfolio using request: " + portfolioCreationEvent);
        PortfolioEntity portfolioEntity = createPortfolio(portfolioCreationEvent);
        setNewPortfolioManager(userId, portfolioEntity);
        List<WorkStreamEntity> workStreamEntities = createWorkStream(portfolioCreationEvent, portfolioEntity);
        List<SubWorkStreamKeyDatesEntity> subWorkStreamKeyDatesEntities =
                workStreamEntities.stream().filter(workStreamEntity -> workStreamEntity.getWorkStreamName().contains(PortfolioConstants.DEFAULT_WS))
                        .map(workStreamEntity -> workStreamEntity.getSubWorkStreamEntities().stream()
                                .filter(subWorkStreamEntity -> subWorkStreamEntity.getSubWorkStreamName().contains(PortfolioConstants.DEFAULT_SWS))
                                .map(this::createDefaultKeyDates).collect(Collectors.toList()))
                        .flatMap(List::stream).collect(Collectors.toList());
        portfolioRepo.save(portfolioEntity);
        workStreamRepo.saveAll(workStreamEntities);

        if (portfolioEntity.getPortfolioId().endsWith("I")) {
            workStreamEntities.forEach(workStreamEntity -> {
                publisher.publishEvent(new FinSysProjectIdCreationEvent(workStreamEntity, userId));
            });
        }

        List<WorkHierarchyEntity> portfolioWorkHierarchyEntities = getPortfolioWorkHierarchyEntities(portfolioEntity, workStreamEntities);
        workHierarchyRepo.saveAll(portfolioWorkHierarchyEntities);
        subWorkStreamKeyDatesRepo.saveAll(subWorkStreamKeyDatesEntities);
        return portfolioWorkHierarchyEntities;
    }

    private void setNewPortfolioManager(String userId, PortfolioEntity portfolioEntity) {
        PortfolioMangersEntity portfolioMangersEntity = new PortfolioMangersEntity();
        portfolioMangersEntity.setPlatformIndex(portfolioEntity.getPrimaryPlatformIndex());
        portfolioMangersEntity.setDelegateInd(PortfolioConstants.NO);
        portfolioMangersEntity.setOneBankId(userId);
        portfolioMangersEntity.setPortfolioId(portfolioEntity.getPortfolioId());
        portfolioMangersEntity.setActiveInd(PortfolioConstants.TRUE);
        portfolioMangersEntity.setRole(PortfolioConstants.TECH);
        List<StageWorkdayData> stageWorkdayData = portfolioNativeRepository.getStaffNameAndEmail(userId);
        if (!CollectionUtils.isNullOrEmpty(stageWorkdayData)) {
            portfolioMangersEntity.setEmailAddress(stageWorkdayData.get(0).getEmailAddress());
            portfolioMangersEntity.setStaffName(stageWorkdayData.get(0).getStaffName());
        }
        portfolioManagersRepo.save(portfolioMangersEntity);
    }

    public SubWorkStreamKeyDatesEntity createDefaultKeyDates(SubWorkStreamEntity subWorkStreamEntity) {
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = new SubWorkStreamKeyDatesEntity();
        subWorkStreamKeyDatesEntity.setWorkStreamId(subWorkStreamEntity.getWorkStreamId());
        subWorkStreamKeyDatesEntity.setSubWorkStreamId(subWorkStreamEntity.getSubWorkStreamId());
        subWorkStreamKeyDatesEntity.setSubWorkStreamName(subWorkStreamEntity.getSubWorkStreamName());
        subWorkStreamKeyDatesEntity.setActiveInd(PortfolioConstants.TRUE);
        subWorkStreamKeyDatesEntity.setScenarioName(PortfolioConstants.SCENARIO_FORECAST);
        return subWorkStreamKeyDatesEntity;
    }


    List<WorkHierarchyEntity> getPortfolioWorkHierarchyEntities(PortfolioEntity portfolioEntity, List<WorkStreamEntity> workStreamEntities) {
        return workStreamEntities.stream()
                .map(workStreamEntity -> workStreamEntity.getSubWorkStreamEntities().stream().map(swStream -> {
                    WorkHierarchyEntity workHierarchyEntity = new WorkHierarchyEntity();
                    workHierarchyEntity.setPortfolioId(portfolioEntity.getPortfolioId());
                    workHierarchyEntity.setPortfolioName(portfolioEntity.getPortfolioName());
                    workHierarchyEntity.setWorkStreamName(workStreamEntity.getWorkStreamName());
                    workHierarchyEntity.setWorkStreamId(workStreamEntity.getWorkStreamId());
                    workHierarchyEntity.setSubWorkStreamName(swStream.getSubWorkStreamName());
                    workHierarchyEntity.setSubWorkStreamId(swStream.getSubWorkStreamId());
                    return workHierarchyEntity;
                }).collect(Collectors.toList()))
                .flatMap(List::stream)
                .collect(Collectors.toList());
    }

    List<WorkStreamEntity> createWorkStream(PortfolioCreationEvent portfolioCreationEvent,
                                            PortfolioEntity portfolioEntity) {
        return portfolioCreationEvent.getWorkStreams().stream()
                .map(workStream -> {
                    WorkStreamEntity workStreamEntity = new WorkStreamEntity();
                    workStreamEntity.setWorkStreamId(getWorkStreamPortfolioID(portfolioEntity, workStream.getCountry(),
                            portfolioCreationEvent.getInitiationYear(), portfolioCreationEvent.getWorkType()));
                    workStreamEntity.setPortfolioId(portfolioEntity.getPortfolioId());
                    workStreamEntity.setWorkStreamName(workStream.getWorkStreamName());
                    workStreamEntity.setCountry(workStream.getCountry());
                    workStreamEntity.setSubWorkStreamEntities(
                            createSubWorkStream(workStreamEntity, workStream.getSubWorkStreams(), portfolioCreationEvent));

                    return workStreamEntity;
                })
                .collect(Collectors.toList());
    }

    List<SubWorkStreamEntity> createSubWorkStream(WorkStreamEntity workStream,
                                                  @NotNull List<SubWorkStream> subWorkStreams, PortfolioCreationEvent
                                                          portfolioCreationEvent) {
        return subWorkStreams.stream()
                .map(subWorkStream -> getSubWorkStreamEntity(workStream, portfolioCreationEvent, subWorkStream))
                .collect(Collectors.toList());
    }

    public SubWorkStreamEntity getSubWorkStreamEntity(WorkStreamEntity workStream, PortfolioCreationEvent portfolioCreationEvent,
                                                      SubWorkStream subWorkStream) {
        SubWorkStreamEntity subWorkStreamEntity = new SubWorkStreamEntity();
        subWorkStreamEntity.setWorkStreamId(workStream.getWorkStreamId());
        String deliveryUnit = getDeliveryUnit(subWorkStream.getDeliveryPlatformUnit());
        subWorkStreamEntity.setSubWorkStreamId(getSubWorkStreamPortfolioID(workStream, deliveryUnit,
                portfolioCreationEvent));
        subWorkStreamEntity.setSubWorkStreamName(subWorkStream.getSubWorkStreamName());
        subWorkStreamEntity.setCountry(workStream.getCountry());
        subWorkStreamEntity.setDeliveryUnit(subWorkStream.getDeliveryPlatformUnit());
        String primaryPlatformUnit = getDeliveryUnit(portfolioCreationEvent.getPrimaryPlatformName());
        if (deliveryUnit.equalsIgnoreCase(primaryPlatformUnit)) {
            subWorkStreamEntity.setWorkType("A-Work");
        } else {
            subWorkStreamEntity.setWorkType("B-Work");
        }
        log.info("subWorkStreamEntity : " + subWorkStreamEntity);
        return subWorkStreamEntity;
    }

    String getDeliveryUnit(String platformName) {
        return platformName.substring(0, platformName.indexOf("-")).trim();
    }

    public String getSubWorkStreamPortfolioID(WorkStreamEntity workStream, String deliveryUnit, PortfolioCreationEvent
            portfolioCreationEvent) {

        String platformIndex = workStream.getPortfolioId().substring(1, workStream.getPortfolioId().indexOf("-")).trim();
        SequenceGeneratorEntity sequenceGeneratorEntity;
        String countryDescription = getCountryDescription(workStream.getCountry());
        List<SequenceGeneratorEntity> listSequenceGenerator = getListOfPortFolioSequenceGenerator(PortfolioConstants.
                        SUBWORKSTREAMNAME, platformIndex, portfolioCreationEvent.getInitiationYear(), countryDescription,
                portfolioCreationEvent.getWorkType());
        String subWorkStreamId = null;
        String seqNoGeneratorForSubWorkStream;
        if (listSequenceGenerator.size() != 0) {
            sequenceGeneratorEntity = listSequenceGenerator.get(0);
            if (Strings.isNotEmpty(String.valueOf(sequenceGeneratorEntity.getMaxCounter()))) {
                seqNoGeneratorForSubWorkStream = String.valueOf(sequenceGeneratorEntity.getMaxCounter() + 1);
                subWorkStreamId = workStream.getWorkStreamId() + "-P" + deliveryUnit;
                sequenceGeneratorEntity.setGeneratedId(subWorkStreamId);
                sequenceGeneratorEntity.setMaxCounter(Integer.parseInt(seqNoGeneratorForSubWorkStream));
                sequenceGeneratorRepo.save(sequenceGeneratorEntity);
            }
        } else {
            seqNoGeneratorForSubWorkStream = "1";
            subWorkStreamId = workStream.getWorkStreamId() + "-P" + deliveryUnit;
            String initiationYear = portfolioCreationEvent.getInitiationYear();
            String year;
            if (initiationYear.length() > 3) {
                year = initiationYear.substring(2, 4);
            } else {
                year = initiationYear;
            }
            saveSequenceGenerator(platformIndex, portfolioCreationEvent.getWorkType(), year, seqNoGeneratorForSubWorkStream, subWorkStreamId,
                    PortfolioConstants.SUBWORKSTREAMNAME, countryDescription, deliveryUnit);
        }


        return subWorkStreamId;
    }

    private String getWorkStreamPortfolioID(PortfolioEntity portfolioEntity, String country, String year,
                                            String workType) {
        return generateWorkStreamID(portfolioEntity.getPortfolioId(), country, year, workType);
    }

    private PortfolioEntity createPortfolio(PortfolioCreationEvent portfolioCreationEvent) {
        String portfolioName = portfolioCreationEvent.getPortfolioName();
        String platformIndex = getPlatformIndex(portfolioCreationEvent.getPrimaryPlatformName());
        String costType = portfolioCreationEvent.getWorkType();
        String year = portfolioCreationEvent.getInitiationYear();
        String countryDescription = getCountryDescription(portfolioCreationEvent.getWorkStreams().get(0).getCountry());
        String portfolioID = generatePortfolioID(platformIndex, costType, year.substring(2, 4), countryDescription);

        PortfolioEntity portfolioEntity = new PortfolioEntity();
        log.info("Generated Portfolio ID is: " + portfolioID);
        portfolioEntity.setPortfolioId(portfolioID);
        portfolioEntity.setPortfolioName(portfolioName);
        portfolioEntity.setInitiationYear(year);
        portfolioEntity.setWorkType(portfolioCreationEvent.getWorkType());
        portfolioEntity.setPrimaryPlatformIndex(platformIndex);
        portfolioEntity.setPlatformName(getPlatformName(portfolioCreationEvent));
        portfolioEntity.setPrimaryPlatformName(portfolioCreationEvent.getPrimaryPlatformName());
        portfolioEntity.setReportingFlag(YES);
        portfolioEntity.setAgileWaterFall(PortfolioConstants.AGILE);
        return portfolioEntity;
    }

    private String getCountryDescription(@NotNull String countryValue) {
        DataValues dataValuesByValue = dataSummaryService.getDataValuesByValue(countryValue, PortfolioConstants.country);
        return dataValuesByValue.getDesc();
    }


    private String getPlatformName(PortfolioCreationEvent portfolioCreationEvent) {
        String primaryPlatformName = portfolioCreationEvent.getPrimaryPlatformName();
        return primaryPlatformName.substring(primaryPlatformName.indexOf("-") + 1).trim();
    }

    String generatePortfolioID(String platformIndex, String costType, String year, String country) {
        SequenceGeneratorEntity sequenceGeneratorEntity;
        String seqNoGenerator;
        String portfolioID = null;
        List<SequenceGeneratorEntity> listSequenceGenerator = getListOfPortFolioSequenceGenerator(PortfolioConstants.
                PORTFOLIONAME, platformIndex, year, country, costType);

        if (listSequenceGenerator.size() != 0) {
            sequenceGeneratorEntity = listSequenceGenerator.get(0);
            if (Strings.isNotEmpty(String.valueOf(sequenceGeneratorEntity.getMaxCounter()))) {
                int incrementValue = Integer.parseInt(String.valueOf(sequenceGeneratorEntity.getMaxCounter())) + 1;
                seqNoGenerator = String.format("%03d", incrementValue);
                portfolioID = "P" + platformIndex + "-" + year + seqNoGenerator + "-" + costType;
                sequenceGeneratorEntity.setGeneratedId(portfolioID);
                sequenceGeneratorEntity.setMaxCounter(Integer.parseInt(seqNoGenerator));
                sequenceGeneratorRepo.save(sequenceGeneratorEntity);
            }
        } else {
            seqNoGenerator = "001";
            portfolioID = "P" + platformIndex + "-" + year + seqNoGenerator + "-" + costType;
            saveSequenceGenerator(platformIndex, costType, year, seqNoGenerator, portfolioID,
                    PortfolioConstants.PORTFOLIONAME, "", "");
        }
        //String portfolioSequenceNumber = getPortfolioSequenceNumber();

        return portfolioID;
    }

    private void saveSequenceGenerator(String platformIndex, String costType, String year,
                                       String seqNoGenerator, String generateID, String portfolioType, String country, String
                                               deliveryUnit) {
        SequenceGeneratorEntity sequenceGeneratorEntity = new SequenceGeneratorEntity();
        sequenceGeneratorEntity.setPortFolioIdType(portfolioType);
        sequenceGeneratorEntity.setKey1(platformIndex);
        sequenceGeneratorEntity.setKey2(year);
        sequenceGeneratorEntity.setKey3(country);
        sequenceGeneratorEntity.setKey4(costType);
        sequenceGeneratorEntity.setKey5(deliveryUnit);
        sequenceGeneratorEntity.setMaxCounter(Integer.parseInt(seqNoGenerator));
        sequenceGeneratorEntity.setGeneratedId(generateID);

        sequenceGeneratorRepo.save(sequenceGeneratorEntity);

    }

    private String getPortfolioSequenceNumber() {
        return portfolioNativeRepository.getPortfolioSequence();
    }

    public String generateWorkStreamID(String portfolioId, String country, String year, String workType) {

        String platformIndex = portfolioId.substring(1, portfolioId.indexOf("-")).trim();
        List<SequenceGeneratorEntity> listSequenceGenerator = getListOfPortFolioSequenceGenerator(PortfolioConstants.
                WORKSTREAMNAME, platformIndex, year, country, workType);
        String countryDescription = getCountryDescription(country);
        String workStreamId = null;
        SequenceGeneratorEntity sequenceGeneratorEntity;
        String seqNoGeneratorForWorkStream = null;
        if (!listSequenceGenerator.isEmpty()) {
            sequenceGeneratorEntity = listSequenceGenerator.get(0);
            if (Strings.isNotEmpty(String.valueOf(sequenceGeneratorEntity.getMaxCounter()))) {
                int incrementValue = sequenceGeneratorEntity.getMaxCounter() + 1;
                seqNoGeneratorForWorkStream = String.format("%04d", incrementValue);
                workStreamId = portfolioId.substring(0, portfolioId.indexOf("-")).trim() + countryDescription + portfolioId.
                        substring(portfolioId.indexOf("-")) + seqNoGeneratorForWorkStream;
                sequenceGeneratorEntity.setGeneratedId(workStreamId);
                sequenceGeneratorEntity.setMaxCounter(Integer.parseInt(seqNoGeneratorForWorkStream));
                sequenceGeneratorRepo.save(sequenceGeneratorEntity);
            }
        } else {
            seqNoGeneratorForWorkStream = "0001";
            workStreamId = portfolioId.substring(0, portfolioId.indexOf("-")).trim() + countryDescription + portfolioId.
                    substring(portfolioId.indexOf("-")) + seqNoGeneratorForWorkStream;

            saveSequenceGenerator(platformIndex, workType, year.substring(2, 4), seqNoGeneratorForWorkStream,
                    workStreamId, PortfolioConstants.WORKSTREAMNAME, countryDescription, "");
        }

        //String workStreamSequenceNumber = getWorkStreamSequenceNumber();


        return workStreamId;
    }

    private String getWorkStreamSequenceNumber() {
        return portfolioNativeRepository.getWorkStreamSequence();
    }

    String getPlatformIndex(String primaryPlatformName) {
        return primaryPlatformName.substring(0, primaryPlatformName.indexOf("-")).trim();
    }

    public List<SequenceGeneratorEntity> getListOfPortFolioSequenceGenerator(String portfolioType, String platformIndex,
                                                                             String year, String country,
                                                                             String costType) {
        List<SequenceGeneratorEntity> generatorEntityList = null;
        if (PortfolioConstants.WORKSTREAMNAME.equalsIgnoreCase(portfolioType)) {
            generatorEntityList = sequenceGeneratorRepo.findByPortFolioIdTypeAndKey1AndKey2(portfolioType,
                    platformIndex, year);
        }
        if (PortfolioConstants.PORTFOLIONAME.equalsIgnoreCase(portfolioType)) {
            generatorEntityList = sequenceGeneratorRepo.findByPortFolioIdTypeAndKey1AndKey2AndKey4(portfolioType,
                    platformIndex, year, costType);
        }
        if (PortfolioConstants.SUBWORKSTREAMNAME.equalsIgnoreCase(portfolioType)) {
            generatorEntityList = sequenceGeneratorRepo.findByPortFolioIdTypeAndKey1AndKey2AndKey3AndKey4(portfolioType,
                    platformIndex, year, country, costType);
        }
        return generatorEntityList;
    }
}