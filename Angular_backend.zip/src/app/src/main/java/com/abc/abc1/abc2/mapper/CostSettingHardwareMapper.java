package com.dbs.genesis.portfolio.mapper;

import com.amazonaws.util.CollectionUtils;
import com.dbs.genesis.portfolio.common.MathExtentions;
import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.service.costsettings.FinancialDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
public class CostSettingHardwareMapper implements MathExtentions {

    @Autowired
    FinancialDetailsService financialDetailsService;

    public List<SubWorkStreamHardwareCostResource> mapSubWorkStreamHardwareCostEntityToResource(
            List<SubWorkstreamHardwareCost> subWorkStreamHardwareCosts, String workStreamId, String loggedInUserCurrency) {
        return subWorkStreamHardwareCosts.stream().map(hardwareCost -> updateHardwareCurrency(hardwareCost,
                workStreamId, loggedInUserCurrency)).collect(Collectors.toList());
    }

    private SubWorkStreamHardwareCostResource updateHardwareCurrency(SubWorkstreamHardwareCost hardwareCost,
    String workStreamId, String loggedInUserCurrency){
        SubWorkStreamHardwareCostResource subWorkStreamHardwareCostResource = new SubWorkStreamHardwareCostResource();
        subWorkStreamHardwareCostResource.setTower(hardwareCost.getTower());
        subWorkStreamHardwareCostResource.setDriverDetails(hardwareCost.getDriverDetail());
        subWorkStreamHardwareCostResource.setUom(hardwareCost.getUom());
        subWorkStreamHardwareCostResource.setQty(hardwareCost.getQuantity());
        subWorkStreamHardwareCostResource.setActiveInd(hardwareCost.getActiveInd());
        subWorkStreamHardwareCostResource.setSurrId(hardwareCost.getSwsHwSurrId());
        subWorkStreamHardwareCostResource.setItcRate(hardwareCost.getItcRate());
        subWorkStreamHardwareCostResource.setCostPerMonth(hardwareCost.getCostPerMonthLcy());

        convertCurrencyToLoggedInCurrencyForView(subWorkStreamHardwareCostResource, loggedInUserCurrency,
                                                    workStreamId, hardwareCost);
        return subWorkStreamHardwareCostResource;
    }

    private void convertCurrencyToLoggedInCurrencyForView(
                                SubWorkStreamHardwareCostResource subWorkStreamHardwareCostResource,
                                String loggedInUserCurrency, String workStreamId, SubWorkstreamHardwareCost hardwareCost){
        subWorkStreamHardwareCostResource.setCurrency(loggedInUserCurrency);
        subWorkStreamHardwareCostResource.setCostInCurrency(loggedInUserCurrency);
        if(loggedInUserCurrency.equalsIgnoreCase(hardwareCost.getLocalCcy())) {
            //When loggedInCurrency is same to previous localCurrency
            subWorkStreamHardwareCostResource.setItcRate(hardwareCost.getItcRate());
        }else if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(loggedInUserCurrency)){
            //When loggedInCurrency is also SGD
            subWorkStreamHardwareCostResource.setItcRate(hardwareCost.getItcRate().multiply(
                    financialDetailsService.getExchangeRatesEntity(hardwareCost.getPeriod(),
                            hardwareCost.getLocalCcy(), workStreamId).getRateValue()));
        }else {
            // When loggedInCurrency is different from currnet localCcy/globalCcy in db
            BigDecimal rateValueLocalCcyValToSgd = financialDetailsService.getExchangeRatesEntity(hardwareCost.getPeriod(),
                    hardwareCost.getLocalCcy(), workStreamId).getRateValue();
            BigDecimal valueLocalCcyValToSgd = hardwareCost.getItcRate().multiply(rateValueLocalCcyValToSgd);
            BigDecimal rateValueLoggedInCurrencyToSgd = financialDetailsService.getExchangeRatesEntity(hardwareCost.getPeriod(),
                    loggedInUserCurrency, workStreamId).getRateValue();
            BigDecimal convertedValueForLoggedInCurrency = divideWithScaleHalfUp(valueLocalCcyValToSgd, rateValueLoggedInCurrencyToSgd);
            subWorkStreamHardwareCostResource.setItcRate(convertedValueForLoggedInCurrency);
        }
        subWorkStreamHardwareCostResource.setCostPerMonth(subWorkStreamHardwareCostResource.getItcRate().
                multiply(hardwareCost.getQuantity()));
    }

    public List<SubWorkStreamHardwareCostResourceHolder> getSubWorkStreamHardwareCosts(
            List<SubWorkStreamHardwareCostResource> subWorkStreamHardwareCostResources) {
        List<SubWorkStreamHardwareCostResourceHolder> subWorkStreamHardwareCostResourceHolders = new ArrayList<>();
        SubWorkStreamHardwareCostResourceHolder subWorkStreamHardwareCostResourceHolder = new SubWorkStreamHardwareCostResourceHolder();
        if(!CollectionUtils.isNullOrEmpty(subWorkStreamHardwareCostResources)){
            subWorkStreamHardwareCostResourceHolder.getHardware().addAll(subWorkStreamHardwareCostResources);
            subWorkStreamHardwareCostResourceHolders.add(subWorkStreamHardwareCostResourceHolder);
        }
        return subWorkStreamHardwareCostResourceHolders;
    }
}
