package com.dbs.genesis.portfolio.exception;

public class MappingException extends RuntimeException {
    private static final long serialVersionUID = 2610477518423283258L;

    public MappingException(String msg) {
        super(msg);
    }
}
