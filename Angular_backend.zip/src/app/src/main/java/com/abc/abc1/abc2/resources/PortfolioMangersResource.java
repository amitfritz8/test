package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.sql.Date;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PortfolioMangersResource {

    int portMgrSurrId;

    String portfolioId;

    String oneBankId;

    String staffName;

    String role;

    String platformIndex;

    String emailAddress;

    Date effectiveStartDate;

    Date effectiveEndDate;

    String delegateInd;

    String portfolioName;

    String activeInd;

}
