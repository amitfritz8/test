package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.WorkstreamLePccodesEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

@Repository
public interface WorkstreamLePccodesRepo extends JpaRepository<WorkstreamLePccodesEntity, String>{

    List<WorkstreamLePccodesEntity> findByWorkStreamIdAndActiveInd(String workStreamId, String activeInd);

    List<WorkstreamLePccodesEntity> findByActiveIndAndBuildOperateEqualsIgnoreCase(String activeInd, String buildOperate);

    List<WorkstreamLePccodesEntity> findByPortfolioIdAndWorkStreamIdAndActiveIndAndBuildOperateEqualsIgnoreCase(String portfolioId,
                                                                                                                String workStreamId,
                                                                                                                String activeInd,String buildOperate);
    @Query(value = "SELECT * FROM workstream_le_pccodes WHERE workstream_id=:workStreamId and active_ind=:activeInd " +
            "AND le_pccode IN (SELECT le_pccode FROM map_work_to_pccode WHERE sub_workstream_id=:subWorkStreamId and sub_workstream_name=:subWorkstreamName)",
            nativeQuery = true)
    List<WorkstreamLePccodesEntity> getSubWorkStreamPccodes(@Param("workStreamId") String workStreamId,
                                                            @Param("subWorkStreamId") String subWorkStreamId,
                                                            @Param("activeInd") String activeInd,
                                                            @Param("subWorkstreamName") String subWorkstreamName);

}