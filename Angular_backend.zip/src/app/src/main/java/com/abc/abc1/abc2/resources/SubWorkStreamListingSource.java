package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SubWorkStreamListingSource {

    String portfolioId;
    String portfolioName;
    String workStreamId;
    String workStreamName;
    String subWorkStreamId;
    String subWorkStreamName;
    String platformName;
    String workType;
    String appCode;
}
