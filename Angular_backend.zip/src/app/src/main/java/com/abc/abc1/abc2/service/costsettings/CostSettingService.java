package com.dbs.genesis.portfolio.service.costsettings;

import com.amazonaws.util.CollectionUtils;
import com.dbs.genesis.portfolio.common.DateExtensions;
import com.dbs.genesis.portfolio.common.MathExtentions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.*;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@Transactional
public class CostSettingService implements MathExtentions, DateExtensions {


    private final SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo;
    private final DataSummaryService dataSummaryService;
    private final SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo;
    private final SubWorkstreamHardwareCostRepo subWorkstreamHardwareCostRepo;
    private final SubWorkstreamSoftwareCostRepo subWorkstreamSoftwareCostRepo;
    private final SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    private final EmployeeRateCardRepo employeeRateCardRepo;
    private final ITCRateRepo itcRateRepo;
    private final SoftwareService softwareService;
    private final HardwareService hardwareService;
    private final CostSettingOtherService costSettingOtherService;
    private final FinancialDetailsService financialDetailsService;
    private final WorkStreamRepo workStreamRepo;
    private final ResourceService resourceService;
    private final SubWorkStreamResourceCostRepo subWorkStreamResourceCostRepo;
    private final SeedFundingOperationCostService seedFundingOperationCostService;

    private final ApplicationEventPublisher publisher;
    private final PortfolioRepository portfolioRepository;

    @Autowired
    public CostSettingService(DataSummaryService dataSummaryService,
                              SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo,
                              SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo,
                              SubWorkstreamHardwareCostRepo subWorkstreamHardwareCostRepo,
                              SubWorkstreamSoftwareCostRepo subWorkstreamSoftwareCostRepo,
                              SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo,
                              EmployeeRateCardRepo employeeRateCardRepo,
                              ITCRateRepo itcRateRepo,
                              SoftwareService softwareService,
                              HardwareService hardwareService,
                              CostSettingOtherService costSettingOtherService,
                              FinancialDetailsService financialDetailsService,
                              WorkStreamRepo workStreamRepo, ResourceService resourceService,
                              ApplicationEventPublisher publisher, SubWorkStreamResourceCostRepo
                                          subWorkStreamResourceCostRepo, SeedFundingOperationCostService seedFundingOperationCostService,
                              PortfolioRepository portfolioRepository) {

        this.dataSummaryService = dataSummaryService;
        this.subWorkstreamFinDetailsRepo = subWorkstreamFinDetailsRepo;
        this.subWorkstreamOtherCostRepo = subWorkstreamOtherCostRepo;
        this.subWorkstreamHardwareCostRepo = subWorkstreamHardwareCostRepo;
        this.subWorkstreamSoftwareCostRepo = subWorkstreamSoftwareCostRepo;
        this.subWorkStreamKeyDatesRepo = subWorkStreamKeyDatesRepo;
        this.employeeRateCardRepo = employeeRateCardRepo;
        this.itcRateRepo = itcRateRepo;
        this.softwareService = softwareService;
        this.hardwareService = hardwareService;
        this.costSettingOtherService = costSettingOtherService;
        this.financialDetailsService = financialDetailsService;
        this.workStreamRepo = workStreamRepo;
        this.resourceService = resourceService;
        this.publisher = publisher;
        this.subWorkStreamResourceCostRepo = subWorkStreamResourceCostRepo;
        this.seedFundingOperationCostService = seedFundingOperationCostService;
        this.portfolioRepository = portfolioRepository;
    }

    public FinancialDetailsTemplateResource getFinancialDetailsTemplate(String currencyCodeType) {
        FinancialDetailsTemplateResource financialDetailsTemplateResource = new FinancialDetailsTemplateResource();
        financialDetailsTemplateResource.setCountryCodes(employeeRateCardRepo.findDistinctCountryCodes());
        financialDetailsTemplateResource.setCurrencyCodes(Collections.singletonList(currencyCodeType));
        financialDetailsTemplateResource.setRateLevels(employeeRateCardRepo.findDistinctRateLevels());
        financialDetailsTemplateResource.setRateSources(employeeRateCardRepo.findDistinctRateSources());
        financialDetailsTemplateResource.setStaffTypes(employeeRateCardRepo.findDistinctStaffTypes());
        financialDetailsTemplateResource.setVendorCodes(employeeRateCardRepo.findDistinctVendorCodes());
        financialDetailsTemplateResource.setTowerDetails(itcRateRepo.findDistinctTowers());
        financialDetailsTemplateResource.setDriverDetails(itcRateRepo.findDistinctDriverDetails());
        financialDetailsTemplateResource.setUomDetails(itcRateRepo.findDistinctUOM());
        return financialDetailsTemplateResource;
    }

    public FinancialDetailsTeamTemplateResource getFinancialDetailsTeamTemplate(String workStreamId) {
        FinancialDetailsTeamTemplateResource financialDetailsTeamTemplateResource = new FinancialDetailsTeamTemplateResource();
        financialDetailsTeamTemplateResource.setRateLevels(employeeRateCardRepo.findDistinctRateLevels());
        financialDetailsTeamTemplateResource.setRateSources(employeeRateCardRepo.findDistinctRateSources());
        financialDetailsTeamTemplateResource.setStaffTypes(employeeRateCardRepo.findDistinctStaffTypes());
        financialDetailsTeamTemplateResource.setVendorCodes(employeeRateCardRepo.findDistinctVendorCodes());
        financialDetailsTeamTemplateResource.setRoles(getTeamRoles());
        financialDetailsTeamTemplateResource.setFdManDaysPerMonth(getFDManDaysPerMonth());

        WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(workStreamId);
        DataValues dataValues = dataSummaryService.getDataValuesByValue(workStreamEntity.getCountry(),PortfolioConstants.COUNTRY);
        if(dataValues != null){
            financialDetailsTeamTemplateResource.setCountryCodes(Collections.singletonList(dataValues.getValue()));
            financialDetailsTeamTemplateResource.setCurrencyCodes(Collections.singletonList(dataValues.getAttr3()));
        }
        return financialDetailsTeamTemplateResource;
    }

    private List<String> getTeamRoles() {
        List<DataValues> dataValuesList = dataSummaryService.getDataValuesBySummary(PortfolioConstants.TEAM_ROLE);
        return dataValuesList.stream().map(DataValues::getValue).collect(Collectors.toList());
    }

    public Integer getFDManDaysPerMonth(){
        List<DataValues> dataValuesList = dataSummaryService.getDataValuesBySummary(PortfolioConstants.FD_MAN_DAYS_PER_MONTH);
        if(!CollectionUtils.isNullOrEmpty(dataValuesList)){
            return Integer.parseInt(dataValuesList.get(0).getValue());
        }
        return null;
    }

    public FinancialDetailsResource getCostSettingFinancialDetails(String workStreamId, String subWorkstreamId,
                                                                   String subWorkstreamName,
                                                                   String scenario, String loggedInUserCurrency) {
        FinancialDetailsResource financialDetailsResource = new FinancialDetailsResource();
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity =
                subWorkStreamKeyDatesRepo.findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(workStreamId,
                        subWorkstreamId, subWorkstreamName, "true", scenario);
        if (subWorkStreamKeyDatesEntity == null) {
            log.error("Keydates are empty for this scenerio...");
            return null;
        }
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String startDateFormatted = df.format(subWorkStreamKeyDatesEntity.getStartDate());
        String endDateFormatted = df.format(subWorkStreamKeyDatesEntity.getGoLiveDate());
        List<String> currentYearMonthBetweenDates = getCurrentYearMonthBetweenDates(
                startDateFormatted.substring(0, 7), endDateFormatted.substring(0, 7));
        financialDetailsResource.setWorkStreamId(workStreamId);
        financialDetailsResource.setSubWorkStreamId(subWorkstreamId);
        financialDetailsResource.setSubWorkStreamName(subWorkstreamName);
        financialDetailsResource.setStartDate(subWorkStreamKeyDatesEntity.getStartDate());
        financialDetailsResource.setGoLiveDate(subWorkStreamKeyDatesEntity.getGoLiveDate());
        financialDetailsResource.setScenario(scenario);

        financialDetailsResource.setSoftwares(softwareService.getCostSettingDetails(workStreamId, subWorkstreamId,
                subWorkstreamName, scenario, loggedInUserCurrency));

        financialDetailsResource.setHardwares(hardwareService.getCostSettingDetails(workStreamId, subWorkstreamId,
                subWorkstreamName, scenario, loggedInUserCurrency));

        financialDetailsResource.setIndividualContributors(resourceService.getCostSettingDetails(workStreamId, subWorkstreamId,
                subWorkstreamName, scenario, loggedInUserCurrency));

        financialDetailsResource.setOtherSoftware(costSettingOtherService.getCostSettingDetails(workStreamId,
                subWorkstreamId, subWorkstreamName, scenario, currentYearMonthBetweenDates,loggedInUserCurrency,
                PortfolioConstants.SOFTWARE_TYPE));

        financialDetailsResource.setOtherHardware(costSettingOtherService.getCostSettingDetails(workStreamId,
                subWorkstreamId, subWorkstreamName, scenario, currentYearMonthBetweenDates,loggedInUserCurrency,
                PortfolioConstants.HARDWARE_TYPE));

        financialDetailsResource.setOtherResource(costSettingOtherService.getCostSettingDetails(workStreamId,
                subWorkstreamId, subWorkstreamName, scenario, currentYearMonthBetweenDates,loggedInUserCurrency,
                PortfolioConstants.RESOURCE_TYPE));

        financialDetailsResource.setOthers(costSettingOtherService.getCostSettingDetails(workStreamId,
                subWorkstreamId, subWorkstreamName, scenario, currentYearMonthBetweenDates,
                loggedInUserCurrency, PortfolioConstants.OTHERS_TYPE));

        return financialDetailsResource;
    }

    public void saveCostSettingFinancialDetails(FinancialDetailsResource financialDetailsResource) {
        List<String> currentYearMonthBetweenDates = getMonthYearListByStartDateAndEndDate(financialDetailsResource.getStartDate(),
                financialDetailsResource.getGoLiveDate());
        List<SubWorkstreamSoftwareCost> persistableSoftwareCosts = new ArrayList<>();
        List<SubWorkstreamSoftwareCost> deletableSoftwareCosts = new ArrayList<>();
        List<SubWorkstreamHardwareCost> persistableHardwareCosts = new ArrayList<>();
        List<SubWorkstreamHardwareCost> deletableHardwareCosts = new ArrayList<>();
        List<SubWorkStreamResourceCost> deletableResourceCosts = new ArrayList<>();
        List<SubWorkstreamOtherCost> persistableOtherCosts = new ArrayList<>();
        List<SubWorkstreamOtherCost> deletableOtherCosts = new ArrayList<>();

        Map<String, List<List<SubWorkStreamSoftwareCostHolder>>> dbOpTypeAndSoftwareCostHoldersMap =
                processCostSettingForSoftwares(financialDetailsResource, currentYearMonthBetweenDates);
        if (dbOpTypeAndSoftwareCostHoldersMap != null) {
            List<List<SubWorkStreamSoftwareCostHolder>> softwareCostHoldersForCreate = dbOpTypeAndSoftwareCostHoldersMap.
                    get(PortfolioConstants.CREATE);
            if (!CollectionUtils.isNullOrEmpty(softwareCostHoldersForCreate)) {
                softwareCostHoldersForCreate.forEach(subWorkStreamSoftwareCostHolders -> {
                    subWorkStreamSoftwareCostHolders.forEach(subWorkStreamSoftwareCostHolder -> {
                        SubWorkstreamSoftwareCost subWorkstreamSoftwareCostDbObject = subWorkstreamSoftwareCostRepo.
                                save(subWorkStreamSoftwareCostHolder.getSubWorkstreamSoftwareCost());
                        subWorkStreamSoftwareCostHolder.getSubWorkstreamSoftwareCosts().forEach(subWorkstreamSoftwareCost -> {
                            subWorkstreamSoftwareCost.setRefSwsSwSurrId(subWorkstreamSoftwareCostDbObject.getSwsSwSurrId());
                            });
                    });
                });
                softwareCostHoldersForCreate.forEach(subWorkStreamSoftwareCostHolders -> {
                    for (int i = 0; i < subWorkStreamSoftwareCostHolders.size() ; i++) {
                        Integer capexOpexSurrId = subWorkStreamSoftwareCostHolders.get(0).getSubWorkstreamSoftwareCost().getSwsSwSurrId();
                        subWorkStreamSoftwareCostHolders.get(1).getSubWorkstreamSoftwareCost().setCapexOpexSurrId(capexOpexSurrId);
                        subWorkStreamSoftwareCostHolders.forEach(subWorkStreamSoftwareCostHolder -> {
                            subWorkStreamSoftwareCostHolder.getSubWorkstreamSoftwareCosts().forEach(subWorkstreamSoftwareCost -> {
                                subWorkstreamSoftwareCost.setCapexOpexSurrId(capexOpexSurrId);
                                persistableSoftwareCosts.add(subWorkstreamSoftwareCost);
                            });
                        });
                    }
                });
            }
            populatePersistableSoftwareCostForUpdate(persistableSoftwareCosts, dbOpTypeAndSoftwareCostHoldersMap);
            if (!CollectionUtils.isNullOrEmpty(persistableSoftwareCosts)) {
                subWorkstreamSoftwareCostRepo.saveAll(persistableSoftwareCosts);
            }
            populateDeletableSoftwareCost(deletableSoftwareCosts, dbOpTypeAndSoftwareCostHoldersMap);
            if (!CollectionUtils.isNullOrEmpty(deletableSoftwareCosts)) {
                subWorkstreamSoftwareCostRepo.deleteAll(deletableSoftwareCosts);
            }

            publisher.publishEvent(new CostSettingsUpdateEvent(financialDetailsResource.getSubWorkStreamId(),
                    financialDetailsResource.getSubWorkStreamName(),getCurrentYear(),
                    PortfolioConstants.PROC_COST_COMP_SOFTWARE));
        }
        //Hardware section
        Map<String, List<List<SubWorkStreamHardwareCostHolder>>> dbOpTypeAndHardwareCostHoldersMap =
                processCostSettingForHardwares(financialDetailsResource, currentYearMonthBetweenDates);
        if (dbOpTypeAndHardwareCostHoldersMap != null) {
            List<List<SubWorkStreamHardwareCostHolder>> subWorkStreamSoftwareCostHoldersForCreate = dbOpTypeAndHardwareCostHoldersMap
                    .get(PortfolioConstants.CREATE);
            if (!CollectionUtils.isNullOrEmpty(subWorkStreamSoftwareCostHoldersForCreate)) {
                subWorkStreamSoftwareCostHoldersForCreate.forEach(subWorkStreamHardwareCostHolders -> {
                    subWorkStreamHardwareCostHolders.forEach(subWorkStreamHardwareCostHolder -> {
                        SubWorkstreamHardwareCost subWorkstreamHardwareCostDbObject = subWorkstreamHardwareCostRepo.
                                save(subWorkStreamHardwareCostHolder.getSubWorkstreamHardwareCost());
                        subWorkStreamHardwareCostHolder.getSubWorkstreamHardwareCosts().forEach(subWorkstreamHardwareCost -> {
                            subWorkstreamHardwareCost.setRefSwsHwSurrId(subWorkstreamHardwareCostDbObject.getSwsHwSurrId());
                        });
                    });
                });
                subWorkStreamSoftwareCostHoldersForCreate.forEach(subWorkStreamHardwareCostHolders -> {
                    for (int i = 0; i < subWorkStreamHardwareCostHolders.size() ; i++) {
                        Integer capexOpexSurrId = subWorkStreamHardwareCostHolders.get(0).getSubWorkstreamHardwareCost().getSwsHwSurrId();
                        subWorkStreamHardwareCostHolders.get(1).getSubWorkstreamHardwareCost().setCapexOpexSurrId(capexOpexSurrId);
                        subWorkStreamHardwareCostHolders.forEach(subWorkStreamHardwareCostHolder -> {
                            subWorkStreamHardwareCostHolder.getSubWorkstreamHardwareCosts().forEach(subWorkstreamHardwareCost -> {
                                subWorkstreamHardwareCost.setCapexOpexSurrId(capexOpexSurrId);
                                persistableHardwareCosts.add(subWorkstreamHardwareCost);
                            });
                        });
                    }
                });
            }
            populatePersistableHardwareCostForUpdate(persistableHardwareCosts, dbOpTypeAndHardwareCostHoldersMap);
            if (!CollectionUtils.isNullOrEmpty(persistableHardwareCosts)) {
                subWorkstreamHardwareCostRepo.saveAll(persistableHardwareCosts);
            }
            populateDeletableHardwareCost(deletableHardwareCosts, dbOpTypeAndHardwareCostHoldersMap);
            if (!CollectionUtils.isNullOrEmpty(deletableHardwareCosts)) {
                subWorkstreamHardwareCostRepo.deleteAll(deletableHardwareCosts);
            }

            publisher.publishEvent(new CostSettingsUpdateEvent(financialDetailsResource.getSubWorkStreamId(),
                    financialDetailsResource.getSubWorkStreamName(),getCurrentYear(),
                    PortfolioConstants.PROC_COST_COMP_HARDWARE));
        }
        //Resource-IC section
        Map<String, List<SubWorkStreamResourceCostHolder>> dbOpTypeAndResourceCostHoldersMap =
                processCostSettingForResource(financialDetailsResource, currentYearMonthBetweenDates);

        if (dbOpTypeAndResourceCostHoldersMap != null) {
            populateDeletableResourceCost(deletableResourceCosts, dbOpTypeAndResourceCostHoldersMap);
            if (!CollectionUtils.isNullOrEmpty(deletableResourceCosts)) {
                subWorkStreamResourceCostRepo.deleteAll(deletableResourceCosts);
            }
        }
        //Other section
        Map<String, List<List<SubWorkStreamOtherCostHolder>>> dbOpTypeAndOtherCostHoldersMap =
                processCostSettingForAllOthers(financialDetailsResource, currentYearMonthBetweenDates);
        if (dbOpTypeAndOtherCostHoldersMap != null) {
            List<List<SubWorkStreamOtherCostHolder>> subWorkStreamOtherCostHoldersForCreate = dbOpTypeAndOtherCostHoldersMap
                    .get(PortfolioConstants.CREATE);
            if (!CollectionUtils.isNullOrEmpty(subWorkStreamOtherCostHoldersForCreate)) {
                subWorkStreamOtherCostHoldersForCreate.forEach(subWorkStreamOtherCostHolders -> {
                subWorkStreamOtherCostHolders.forEach(subWorkStreamOtherCostHolder -> {
                    SubWorkstreamOtherCost subWorkstreamOtherCostDbObject = subWorkstreamOtherCostRepo.
                            save(subWorkStreamOtherCostHolder.getSubWorkstreamOtherCost());
                    subWorkStreamOtherCostHolder.getSubWorkstreamOtherCosts().forEach(subWorkstreamOtherCost -> {
                        subWorkstreamOtherCost.setRefSwsOtherSurrId(subWorkstreamOtherCostDbObject.getSwsOtherSurrId());
                    });
                });
            });
                subWorkStreamOtherCostHoldersForCreate.forEach(subWorkStreamOtherCostHolders -> {
                    for (int i = 0; i < subWorkStreamOtherCostHolders.size() ; i++) {
                        Integer capexOpexSurrId = subWorkStreamOtherCostHolders.get(0).getSubWorkstreamOtherCost().getSwsOtherSurrId();
                        subWorkStreamOtherCostHolders.get(1).getSubWorkstreamOtherCost().setCapexOpexSurrId(capexOpexSurrId);
                        subWorkStreamOtherCostHolders.forEach(subWorkStreamOtherCostHolder -> {
                            subWorkStreamOtherCostHolder.getSubWorkstreamOtherCosts().forEach(subWorkstreamOtherCost -> {
                                subWorkstreamOtherCost.setCapexOpexSurrId(capexOpexSurrId);
                                persistableOtherCosts.add(subWorkstreamOtherCost);
                            });
                        });
                    }
                });
            }
            populatePersistableOtherCostForUpdate(persistableOtherCosts, dbOpTypeAndOtherCostHoldersMap);
            if (!CollectionUtils.isNullOrEmpty(persistableOtherCosts)) {
                subWorkstreamOtherCostRepo.saveAll(persistableOtherCosts);
            }
            populateDeletableOtherCost(deletableOtherCosts, dbOpTypeAndOtherCostHoldersMap);
            if (!CollectionUtils.isNullOrEmpty(deletableOtherCosts)) {
                subWorkstreamOtherCostRepo.deleteAll(deletableOtherCosts);
            }
            publisher.publishEvent(new CostSettingsUpdateEvent(financialDetailsResource.getSubWorkStreamId(),
                    financialDetailsResource.getSubWorkStreamName(),getCurrentYear(),
                    PortfolioConstants.PROC_COST_COMP_OTHER));
        }
        portfolioRepository.callSotredProcToRevisePreviousMonthsData(financialDetailsResource.getSubWorkStreamId(),
                financialDetailsResource.getSubWorkStreamName());
    }

    private Map<String, List<List<SubWorkStreamSoftwareCostHolder>>> processCostSettingForSoftwares(
            FinancialDetailsResource financialDetailsResource,
            List<String> currentYearMonthBetweenDates) {
        Map<String, List<List<SubWorkStreamSoftwareCostHolder>>> dbOpTypeAndSoftwareCostHoldersMap = null;
        if (!CollectionUtils.isNullOrEmpty(financialDetailsResource.getSoftwares())) {
            dbOpTypeAndSoftwareCostHoldersMap = softwareService.processCostSetting(
                    financialDetailsResource, currentYearMonthBetweenDates);
        }
        return dbOpTypeAndSoftwareCostHoldersMap;
    }

    private Map<String, List<List<SubWorkStreamHardwareCostHolder>>> processCostSettingForHardwares(FinancialDetailsResource financialDetailsResource,
                                                                                              List<String> currentYearMonthBetweenDates) {
        Map<String, List<List<SubWorkStreamHardwareCostHolder>>> dbOpTypeAndHardwareCostHoldersMap = null;
        if (!CollectionUtils.isNullOrEmpty(financialDetailsResource.getHardwares())) {
            dbOpTypeAndHardwareCostHoldersMap =
                    hardwareService.processCostSetting(financialDetailsResource, currentYearMonthBetweenDates);
        }
        return dbOpTypeAndHardwareCostHoldersMap;
    }


    private Map<String, List<SubWorkStreamResourceCostHolder>> processCostSettingForResource(FinancialDetailsResource financialDetailsResource,
                                                                                              List<String> currentYearMonthBetweenDates) {
        Map<String, List<SubWorkStreamResourceCostHolder>> dbOpTypeAndResourceCostHoldersMap = null;
        if (!CollectionUtils.isNullOrEmpty(financialDetailsResource.getIndividualContributors())) {
            dbOpTypeAndResourceCostHoldersMap =
                    resourceService.processCostSetting(financialDetailsResource, currentYearMonthBetweenDates);
        }
        return dbOpTypeAndResourceCostHoldersMap;
    }

    private Map<String, List<List<SubWorkStreamOtherCostHolder>>> processCostSettingForAllOthers(FinancialDetailsResource financialDetailsResource,
                                                                                           List<String> currentYearMonthBetweenDates) {
        return costSettingOtherService.processCostSetting(financialDetailsResource, currentYearMonthBetweenDates);
    }

    private void populatePersistableSoftwareCostForUpdate(List<SubWorkstreamSoftwareCost> persistableSoftwareCosts,
                                                          Map<String, List<List<SubWorkStreamSoftwareCostHolder>>>
                                                                  dbOpTypeAndSoftwareCostHoldersMap
    ) {
        List<List<SubWorkStreamSoftwareCostHolder>> softwareCostHoldersForUpdate = dbOpTypeAndSoftwareCostHoldersMap.get(PortfolioConstants.UPDATE);
        if (!CollectionUtils.isNullOrEmpty(softwareCostHoldersForUpdate)) {
            softwareCostHoldersForUpdate.forEach(subWorkStreamSoftwareCostHolders -> {
                subWorkStreamSoftwareCostHolders.forEach(subWorkStreamSoftwareCostHolder -> {
                    persistableSoftwareCosts.add(subWorkStreamSoftwareCostHolder.getSubWorkstreamSoftwareCost());
                    persistableSoftwareCosts.addAll(subWorkStreamSoftwareCostHolder.getSubWorkstreamSoftwareCosts());
                });
            });
        }
    }

    private void populatePersistableHardwareCostForUpdate(List<SubWorkstreamHardwareCost> persistableHardwareCosts,
                                                          Map<String, List<List<SubWorkStreamHardwareCostHolder>>>
                                                                  dbOpTypeAndHardwareCostHoldersMap) {
        List<List<SubWorkStreamHardwareCostHolder>> hardwareCostHoldersForUpdate = dbOpTypeAndHardwareCostHoldersMap.get(PortfolioConstants.UPDATE);
        if (!CollectionUtils.isNullOrEmpty(hardwareCostHoldersForUpdate)) {
            hardwareCostHoldersForUpdate.forEach(subWorkStreamHardwareCostHolders -> {
                subWorkStreamHardwareCostHolders.forEach(subWorkStreamHardwareCostHolder -> {
                    persistableHardwareCosts.add(subWorkStreamHardwareCostHolder.getSubWorkstreamHardwareCost());
                    persistableHardwareCosts.addAll(subWorkStreamHardwareCostHolder.getSubWorkstreamHardwareCosts());
                });
            });
        }

    }

    private void populateDeletableSoftwareCost(List<SubWorkstreamSoftwareCost> deletableSoftwareCosts,
                                               Map<String, List<List<SubWorkStreamSoftwareCostHolder>>>
                                                       dbOpTypeAndSoftwareCostHoldersMap) {
        List<List<SubWorkStreamSoftwareCostHolder>> softwareCostHoldersForDelete =
                dbOpTypeAndSoftwareCostHoldersMap.get(PortfolioConstants.INACTIVE);
        if (!CollectionUtils.isNullOrEmpty(softwareCostHoldersForDelete)) {
            softwareCostHoldersForDelete.forEach(softwareCostHolders -> {
                softwareCostHolders.forEach(softwareCostHolder -> {
                    deletableSoftwareCosts.addAll(softwareCostHolder.getSubWorkstreamSoftwareCosts());
                });
            });
        }
    }

    private void populateDeletableHardwareCost(List<SubWorkstreamHardwareCost> deletableHardwareCosts,
                                               Map<String, List<List<SubWorkStreamHardwareCostHolder>>>
                                                       dbOpTypeAndHardwareCostHoldersMap) {
        List<List<SubWorkStreamHardwareCostHolder>> hardwareCostHoldersForDelete =
                dbOpTypeAndHardwareCostHoldersMap.get(PortfolioConstants.INACTIVE);
        if (!CollectionUtils.isNullOrEmpty(hardwareCostHoldersForDelete)) {
            hardwareCostHoldersForDelete.forEach(hardwareCostHolders -> {
                hardwareCostHolders.forEach(hardwareCostHolder -> {
                    deletableHardwareCosts.addAll(hardwareCostHolder.getSubWorkstreamHardwareCosts());
                });
            });
        }
    }

    private void populateDeletableResourceCost(List<SubWorkStreamResourceCost> deletableResourceCosts,
                                               Map<String, List<SubWorkStreamResourceCostHolder>>
                                                       dbOpTypeAndResourceCostHoldersMap) {
        List<SubWorkStreamResourceCostHolder> resourceCostHoldersForDelete =
                dbOpTypeAndResourceCostHoldersMap.get(PortfolioConstants.INACTIVE);
        if (!CollectionUtils.isNullOrEmpty(resourceCostHoldersForDelete)) {
            resourceCostHoldersForDelete.forEach(resourceCostHolder ->
                    deletableResourceCosts.addAll(resourceCostHolder.getSubWorkStreamResourceCosts()));
        }
    }

    private void populatePersistableOtherCostForUpdate(List<SubWorkstreamOtherCost> subWorkstreamOtherCosts,
                                                       Map<String, List<List<SubWorkStreamOtherCostHolder>>>
                                                               dbOpTypeAndOtherCostHoldersMap) {
        List<List<SubWorkStreamOtherCostHolder>> otherCostHoldersForUpdate = dbOpTypeAndOtherCostHoldersMap.get(PortfolioConstants.UPDATE);
        if (!CollectionUtils.isNullOrEmpty(otherCostHoldersForUpdate)) {
            otherCostHoldersForUpdate.forEach(subWorkStreamOtherCostHolders -> {
                subWorkStreamOtherCostHolders.forEach(subWorkStreamOtherCostHolder -> {
                    subWorkstreamOtherCosts.add(subWorkStreamOtherCostHolder.getSubWorkstreamOtherCost());
                    subWorkstreamOtherCosts.addAll(subWorkStreamOtherCostHolder.getSubWorkstreamOtherCosts());
                });
            });
        }
    }

    private void populateDeletableOtherCost(List<SubWorkstreamOtherCost> deletableOtherCosts,
                                            Map<String, List<List<SubWorkStreamOtherCostHolder>>>
                                                    dbOpTypeAndOtherCostHoldersMap) {
        List<List<SubWorkStreamOtherCostHolder>> otherCostHoldersForDelete =
                dbOpTypeAndOtherCostHoldersMap.get(PortfolioConstants.INACTIVE);
        if (!CollectionUtils.isNullOrEmpty(otherCostHoldersForDelete)) {
            otherCostHoldersForDelete.forEach(otherCostHolders ->
                    otherCostHolders.forEach(otherCostHolder ->
                            deletableOtherCosts.addAll(otherCostHolder.getSubWorkstreamOtherCosts())));
        }
    }

    public SeedFundingOperationCostResource getSeedFundingData(String workStreamId, String subWorkStreamId,
                                                               String subWorkStreamName, String currencyCodeType,
                                                               String scenario) {
        List<String> costTypes = getCostTypes();
        List<SeedFundingCostType> seedFundingCostTypes = costTypes.stream()
                .map(costType -> {
                    List<SubWorkstreamFinDetailsEntity> subWorkstreamFinDetailsEntity = subWorkstreamFinDetailsRepo
                            .findByWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndScenarioAndCostTypeAndCostSettingAndOrgInd(
                                    workStreamId, subWorkStreamId, subWorkStreamName, scenario, costType, PortfolioConstants.COST_SETTING_TYPE_SEED_FUNDING, PortfolioConstants.TRUE);
                    return subWorkstreamFinDetailsEntity.size() > 0 ? getSeedFundingCostType(currencyCodeType, subWorkstreamFinDetailsEntity.get(0)) : getDefaultSeedFundingCostType(costType);
                }).collect(Collectors.toList());
        return getSeedFundingDataResource(workStreamId, subWorkStreamId, subWorkStreamName, scenario,
                seedFundingCostTypes, currencyCodeType);
    }

    private SeedFundingOperationCostResource
    getSeedFundingDataResource(String workStreamId, String subWorkStreamId, String subWorkStreamName,
                               String scenario, List<SeedFundingCostType> seedFundingCostTypes,
                               String currencyCode) {
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = seedFundingOperationCostService.getKeyDates(workStreamId,subWorkStreamId,subWorkStreamName, scenario);
        SeedFundingOperationCostResource seedFundingOperationCostResource = new SeedFundingOperationCostResource();
        seedFundingOperationCostResource.setSeedFundingCostTypes(seedFundingCostTypes);
        seedFundingOperationCostResource.setWorkStreamId(workStreamId);
        seedFundingOperationCostResource.setSubWorkStreamId(subWorkStreamId);
        seedFundingOperationCostResource.setSubWorkStreamName(subWorkStreamName);
        seedFundingOperationCostResource.setScenario(scenario);
        seedFundingOperationCostResource.setStartDate(subWorkStreamKeyDatesEntity.getStartDate());
        seedFundingOperationCostResource.setGoLiveDate(subWorkStreamKeyDatesEntity.getGoLiveDate());
        seedFundingOperationCostResource.setCurrencyCode(currencyCode);
        return seedFundingOperationCostResource;
    }



    private SeedFundingCostType getSeedFundingCostType(String currencyCode, SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity) {
        SeedFundingCostType seedFundingCostType = new SeedFundingCostType();
        seedFundingCostType.setSfSurrId(subWorkstreamFinDetailsEntity.getSubWorkStreamFinSurrId());
        seedFundingCostType.setGlCategoryName(subWorkstreamFinDetailsEntity.getGlCategory());
        seedFundingCostType.setCostType(subWorkstreamFinDetailsEntity.getCostType());
        seedFundingCostType.setValue(
                PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        subWorkstreamFinDetailsEntity.getGroupCcyVal() :subWorkstreamFinDetailsEntity.getLocalCcyVal());
        return seedFundingCostType;
    }

    private SeedFundingCostType getDefaultSeedFundingCostType(String costType) {
        SeedFundingCostType seedFundingCostType = new SeedFundingCostType();
        seedFundingCostType.setSfSurrId(0);
        seedFundingCostType.setGlCategoryName(PortfolioConstants.DEFAULT_SEED_FUNDING_CATEGORY);
        seedFundingCostType.setCostType(costType);
        seedFundingCostType.setValue(BigDecimal.ZERO);
        return seedFundingCostType;
    }

    private List<String> getCostTypes() {
        List<DataValues> dataValuesList = dataSummaryService.getDataValuesBySummary(PortfolioConstants.COST_TYPE);
        dataValuesList.sort(Comparator.comparing(DataValues::getAttr1));
        return dataValuesList.stream().map(DataValues::getValue).collect(Collectors.toList());
    }
}
