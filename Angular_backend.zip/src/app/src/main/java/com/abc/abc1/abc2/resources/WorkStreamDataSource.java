package com.dbs.genesis.portfolio.resources;


import com.dbs.genesis.portfolio.model.WorkStreamApprovers;
import com.dbs.genesis.portfolio.model.WorkStreamEntity;
import com.dbs.genesis.portfolio.model.WorkStreamKeyDatesEntity;
import com.dbs.genesis.portfolio.model.WorkStreamManagersEntity;
import com.dbs.genesis.portfolio.model.WorkstreamLePccodesEntity;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkStreamDataSource {

    WorkStreamEntity portFolioWorkStreamEntity;
    String portfolioId;
    String portfolioName;
    List<WorkStreamManagersEntity> workManagers;
    List<WorkStreamKeyDatesEntity> keyDates;
    List<WorkStreamApprovers> workStreamApprovers;
	List<WorkstreamLePccodesEntity> workstreamLePccodesEntities;
	String loggedInUserBankid;
}
