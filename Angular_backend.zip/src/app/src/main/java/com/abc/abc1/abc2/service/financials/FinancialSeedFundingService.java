package com.dbs.genesis.portfolio.service.financials;

import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.SubWorkstreamFinDetailsEntity;
import com.dbs.genesis.portfolio.repository.SubWorkstreamFinDetailsRepo;
import com.dbs.genesis.portfolio.resources.MonthlyData;
import com.dbs.genesis.portfolio.resources.MonthlyFinancialResource;
import com.dbs.genesis.portfolio.resources.MonthlySeedFundingData;
import com.dbs.genesis.portfolio.service.costsettings.FinancialDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
public class FinancialSeedFundingService {

    private final
    SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo;

    private final FinancialDetailsService financialDetailsService;

    public FinancialSeedFundingService(SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo, FinancialDetailsService financialDetailsService) {
        this.subWorkstreamFinDetailsRepo = subWorkstreamFinDetailsRepo;
        this.financialDetailsService = financialDetailsService;
    }

    public List<SubWorkstreamFinDetailsEntity> getSeedFundingDataByYearMonth(
            MonthlyFinancialResource monthlyFinancialResource,
            MonthlySeedFundingData monthlySeedFundingData, String year) {
        List<SubWorkstreamFinDetailsEntity> subWorkstreamFinDetailsEntityWithIndTrue = subWorkstreamFinDetailsRepo.
                findByWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndScenarioAndCostTypeAndCostSettingAndOrgInd(monthlyFinancialResource.getWorkStreamId(),
                        monthlyFinancialResource.getSubWorkStreamId(), monthlyFinancialResource.getSubWorkStreamName(), monthlyFinancialResource.getScenario(),
                        monthlySeedFundingData.getCostType(), PortfolioConstants.COST_SETTING_TYPE_SEED_FUNDING, PortfolioConstants.ORIGINAL_INDICATOR_TRUE);
        return monthlySeedFundingData.getMonthlyData().stream().map(monthlyData -> {
            Optional<SubWorkstreamFinDetailsEntity> subWorkstreamFinDetailsEntityOptional = subWorkstreamFinDetailsRepo.findById(monthlyData.getSurrId());
            if(subWorkstreamFinDetailsEntityOptional != null && subWorkstreamFinDetailsEntityOptional.isPresent()){
               return updateExistingFinDetails(monthlyFinancialResource, monthlyData, subWorkstreamFinDetailsEntityOptional.get());
            }else{
               return getNewSubWorkStreamFinDetailsEntity(monthlyFinancialResource, monthlySeedFundingData,
                        year, subWorkstreamFinDetailsEntityWithIndTrue.get(0), monthlyData);
            }
        }).collect(Collectors.toList());
    }

    private SubWorkstreamFinDetailsEntity
    getNewSubWorkStreamFinDetailsEntity(MonthlyFinancialResource monthlyFinancialResource,
                                        MonthlySeedFundingData monthlySeedFundingData,
                                        String year,
                                        SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntityWithIndTrue,
                                        MonthlyData monthlyData) {
        SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity =
                SubWorkstreamFinDetailsEntity.build(monthlyFinancialResource.getWorkStreamId(),
                        monthlyFinancialResource.getSubWorkStreamId(), monthlyFinancialResource.getSubWorkStreamName(),
                        PortfolioConstants.DEFAULT_SEED_FUNDING_CATEGORY, monthlySeedFundingData.getCostType(),
                        year + monthlyData.getMonthNumber(), PortfolioConstants.COST_SETTING_TYPE_SEED_FUNDING
                        , monthlyFinancialResource.getScenario(), PortfolioConstants.ORIGINAL_INDICATOR_FALSE,
                        subWorkstreamFinDetailsEntityWithIndTrue.getSubWorkStreamFinSurrId());
        updateCurrencyValues(subWorkstreamFinDetailsEntity,
                monthlyFinancialResource.getCurrencyCode(), monthlyData.getValue(),
                monthlyFinancialResource.getCurrencyCodes());
        return subWorkstreamFinDetailsEntity;
    }

    private SubWorkstreamFinDetailsEntity
    updateExistingFinDetails(MonthlyFinancialResource monthlyFinancialResource,
                             MonthlyData monthlyData,
                             SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity) {
        updateCurrencyValues(subWorkstreamFinDetailsEntity,
                monthlyFinancialResource.getCurrencyCode(), monthlyData.getValue(),
                monthlyFinancialResource.getCurrencyCodes());
        return subWorkstreamFinDetailsEntity;
    }

    public void updateCurrencyValues(SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity,
                                     String loggedInCurrencyCode,
                                     BigDecimal currencyValue, HashSet<String> currencyCodes) {
        if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(loggedInCurrencyCode))
            updateCurrencyValuesForGroup(subWorkstreamFinDetailsEntity, loggedInCurrencyCode, currencyValue, currencyCodes);
        else
            updateCurrencyValuesForLocal(subWorkstreamFinDetailsEntity, loggedInCurrencyCode, currencyValue, currencyCodes);
    }

    private SubWorkstreamFinDetailsEntity
    updateCurrencyValuesForLocal(SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity,
                                 String loggedInCurrencyCode,
                                 BigDecimal currencyValue,
                                 Set<String> currencyCodes) {
        subWorkstreamFinDetailsEntity.setLocalCcyVal(currencyValue);
        subWorkstreamFinDetailsEntity.setLocalCcy(loggedInCurrencyCode);
        currencyCodes.remove(loggedInCurrencyCode);
        if(!currencyCodes.isEmpty()){
            subWorkstreamFinDetailsEntity.setGroupCcy(currencyCodes.iterator().next());
            subWorkstreamFinDetailsEntity.setGroupCcyVal(currencyValue.multiply(financialDetailsService.
                    getExchangeValue(subWorkstreamFinDetailsEntity.getPeriod(), loggedInCurrencyCode, subWorkstreamFinDetailsEntity.getWorkstreamId())));
        }else{
            subWorkstreamFinDetailsEntity.setGroupCcy(loggedInCurrencyCode);
            subWorkstreamFinDetailsEntity.setLocalCcyVal(currencyValue);
        }

        return subWorkstreamFinDetailsEntity;
    }

    private SubWorkstreamFinDetailsEntity
    updateCurrencyValuesForGroup(SubWorkstreamFinDetailsEntity subWorkstreamFinDetailsEntity,
                                 String loggedInCurrencyCode,
                                 BigDecimal value,
                                 Set<String> currencyCodes) {
        subWorkstreamFinDetailsEntity.setGroupCcyVal(value);
        subWorkstreamFinDetailsEntity.setGroupCcy(loggedInCurrencyCode);
        currencyCodes.remove(loggedInCurrencyCode);
        if(!currencyCodes.isEmpty()){
            subWorkstreamFinDetailsEntity.setLocalCcy(currencyCodes.iterator().next());
            BigDecimal exchangedValue = financialDetailsService.getExchangeValue
                    (subWorkstreamFinDetailsEntity.getPeriod(), subWorkstreamFinDetailsEntity.getLocalCcy(),subWorkstreamFinDetailsEntity.getWorkstreamId());
            subWorkstreamFinDetailsEntity.setLocalCcyVal(value.divide(exchangedValue, 9, RoundingMode.HALF_UP));
        }else{
            subWorkstreamFinDetailsEntity.setLocalCcy(loggedInCurrencyCode);
            subWorkstreamFinDetailsEntity.setLocalCcyVal(value);
        }
        return subWorkstreamFinDetailsEntity;
    }
}
