package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.sql.Date;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SubWorkStreamApproversResource {

    private String subWorkStreamName;
    private String role;
    private String delegateInd;
    private String staffName;
    private String scenario;
    private String action;
    private String notifyInd;
    private String oneBankId;
    private String subWorkStreamId;
    private Integer swsApproveSurrId;
    private String activeInd;
    private Date effectiveStartDate;
    private Date effectiveEndDate;
}
