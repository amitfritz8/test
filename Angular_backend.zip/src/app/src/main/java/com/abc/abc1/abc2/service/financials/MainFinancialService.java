package com.dbs.genesis.portfolio.service.financials;

import com.dbs.genesis.portfolio.common.DateExtensions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.mapper.BuildAPIResponse;
import com.dbs.genesis.portfolio.model.SubWorkstreamFinDetailsEntity;
import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.repository.SubWorkstreamFinDetailsRepo;
import com.dbs.genesis.portfolio.resources.CostSettingsUpdateEvent;
import com.dbs.genesis.portfolio.resources.FinancialSummaryResource;
import com.dbs.genesis.portfolio.resources.MonthlyFinancialResource;
import com.dbs.genesis.portfolio.resources.MonthlySeedFundingData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
public class MainFinancialService implements DateExtensions {

    private final SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo;
    private final FinancialSeedFundingService financialSeedFundingService;
    private final FinancialSoftwareService financialSoftwareService;
    private final FinancialOthersService financialOthersService;
    private final FinancialHardwareService financialHardwareService;
    private final FinancialResourceService financialResourceService;
    private final ApplicationEventPublisher publisher;
    @Autowired
    private PortfolioRepository portfolioRepository;


    public MainFinancialService(SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo,
                                FinancialSeedFundingService financialSeedFundingService,
                                FinancialSoftwareService financialSoftwareService,
                                FinancialOthersService financialOthersService,
                                FinancialHardwareService financialHardwareService,
                                FinancialResourceService financialResourceService,
                                ApplicationEventPublisher publisher) {
        this.subWorkstreamFinDetailsRepo = subWorkstreamFinDetailsRepo;
        this.financialSeedFundingService = financialSeedFundingService;
        this.financialSoftwareService = financialSoftwareService;
        this.financialOthersService = financialOthersService;
        this.financialHardwareService = financialHardwareService;
        this.financialResourceService = financialResourceService;
        this.publisher = publisher;
    }

    public BuildAPIResponse saveMonthlySeedFundingData(MonthlyFinancialResource monthlyFinancialResource) {

        try {
            List<SubWorkstreamFinDetailsEntity> finDetailsEntityList =
                    monthlyFinancialResource.getMonthlySeedFundingData().entrySet().stream().map(monthlySeedFundingEntry -> {
                        List<MonthlySeedFundingData> monthlySeedFundingDataList = monthlySeedFundingEntry.getValue();
                        return monthlySeedFundingDataList.stream().
                                map(seedFundingDataSourceType -> financialSeedFundingService.getSeedFundingDataByYearMonth(monthlyFinancialResource,
                                        seedFundingDataSourceType, monthlySeedFundingEntry.getKey()))
                                .flatMap(List::stream).collect(Collectors.toList());
                    }).flatMap(List::stream).collect(Collectors.toList());
            subWorkstreamFinDetailsRepo.saveAll(finDetailsEntityList);
            publisher.publishEvent(new CostSettingsUpdateEvent(monthlyFinancialResource.getSubWorkStreamId(), monthlyFinancialResource.getSubWorkStreamName()
                    , getCurrentYear(), PortfolioConstants.PROC_COST_COMP_HLE_FD));
            return new BuildAPIResponse("success", HttpStatus.OK, "0", new Date(), null);
        } catch (Exception e) {
            log.error("Error while saving seed funding monthly data : ", e);
            return new BuildAPIResponse("success", HttpStatus.OK, "0", new Date(), null);
        }
    }

    public void validateOpexTotal(MonthlyFinancialResource monthlyFinancialResource, String year, List<SubWorkstreamFinDetailsEntity> finDetailsEntityListToSave) {
        Set<String> glCategories = new HashSet();
        glCategories.add(PortfolioConstants.DEFAULT_SEED_FUNDING_CATEGORY);

        List<FinancialSummaryResource> opexTotal = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(monthlyFinancialResource.getCurrencyCode()) ?
                portfolioRepository.getFinSummaryGroupByPeriodAndGroupCurrency(monthlyFinancialResource.getWorkStreamId(),
                        monthlyFinancialResource.getSubWorkStreamId(), monthlyFinancialResource.getSubWorkStreamName(), year, glCategories, PortfolioConstants.ORIGINAL_INDICATOR_FALSE)
                : portfolioRepository.getFinSummaryGroupByPeriodAndLocalCurrency(monthlyFinancialResource.getWorkStreamId(),
                monthlyFinancialResource.getSubWorkStreamId(), monthlyFinancialResource.getSubWorkStreamName(), year, glCategories, PortfolioConstants.ORIGINAL_INDICATOR_FALSE);

        List<SubWorkstreamFinDetailsEntity> subWorkstreamFinDetailsEntities = subWorkstreamFinDetailsRepo.findByScenarioAndWorkstreamIdAndSubWorkstreamIdAndSubWorkstreamNameAndAndCostSettingAndPeriodContainingAndOrgInd
                (monthlyFinancialResource.getScenario(), monthlyFinancialResource.getWorkStreamId(), monthlyFinancialResource.getSubWorkStreamId(), monthlyFinancialResource.getSubWorkStreamName(), PortfolioConstants.COST_SETTING_TYPE_SEED_FUNDING, year, PortfolioConstants.ORIGINAL_INDICATOR_TRUE);
        Integer totalOpex = finDetailsEntityListToSave.stream()
                .mapToInt(x -> x.getGroupCcyVal().intValue())
                .sum();
    }

    public BuildAPIResponse saveFinancialOperationCost(MonthlyFinancialResource monthlyFinancialResource) {
        try {
            monthlyFinancialResource.getMonthlyFinancialDetailsResources()
                    .forEach((key, value) -> value.forEach(
                            financialDetail -> {
                                switch (financialDetail.getCostType()) {
                                    case PortfolioConstants.RESOURCE:
                                        financialResourceService.persistResource(monthlyFinancialResource, financialDetail, key);
                                        publisher.publishEvent(new CostSettingsUpdateEvent(monthlyFinancialResource.getSubWorkStreamId(),
                                                monthlyFinancialResource.getSubWorkStreamName()
                                                , getCurrentYear(), PortfolioConstants.PROC_COST_COMP_RESOURCE));
                                        break;
                                    case PortfolioConstants.SOFTWARE:
                                        financialSoftwareService.persistSoftware(monthlyFinancialResource, financialDetail, key);
                                        publisher.publishEvent(new CostSettingsUpdateEvent(monthlyFinancialResource.getSubWorkStreamId(),
                                                monthlyFinancialResource.getSubWorkStreamName()
                                                , getCurrentYear(), PortfolioConstants.PROC_COST_COMP_SOFTWARE));
                                        break;
                                    case PortfolioConstants.HARDWARE:
                                        financialHardwareService.persistHardware(monthlyFinancialResource, financialDetail, key);
                                        publisher.publishEvent(new CostSettingsUpdateEvent(monthlyFinancialResource.getSubWorkStreamId(),
                                                monthlyFinancialResource.getSubWorkStreamName()
                                                , getCurrentYear(), PortfolioConstants.PROC_COST_COMP_HARDWARE));
                                        break;
                                    case PortfolioConstants.OTHERS:
                                        financialOthersService.persistOthers(monthlyFinancialResource, financialDetail, key);
                                        publisher.publishEvent(new CostSettingsUpdateEvent(monthlyFinancialResource.getSubWorkStreamId(),
                                                monthlyFinancialResource.getSubWorkStreamName()
                                                , getCurrentYear(), PortfolioConstants.PROC_COST_COMP_OTHER));
                                        break;
                                    default:
                                        log.info("No type found");
                                        break;
                                }
                            }));
            return new BuildAPIResponse("success", HttpStatus.OK, "0", new Date(), null);
        } catch (Exception e) {
            log.error("Error while saving seed funding monthly data : ", e);
            return new BuildAPIResponse(e.toString(), HttpStatus.OK, "0", new Date(), null);
        }
    }

}
