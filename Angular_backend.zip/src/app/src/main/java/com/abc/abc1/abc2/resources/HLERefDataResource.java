package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class HLERefDataResource {

	 Date startDate;
	 Date goLiveDate;
	 String currencyCodeType;
	 String workStreamId;
	 String subWorkStreamId;
	 String subWorkStreamName;
	 String dateCreated;
	 String createdBy;
	 String modifiedBy;
	 String scenario;
	 List<FinancialInputGroupResource> financialInputGroup;
	
	
}
