package com.dbs.genesis.portfolio.model;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;

@Data
@Entity
@Table(name = "exchange_rates")
@EntityListeners(AuditingEntityListener.class)
public class ExchangeRatesEntity extends CommonEntity<String> {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ex_rates_surr_id")
    private Integer exRatesSurrId;
    @Column(name = "ccy_from")
    private String currencyFrom;
    @Column(name = "ccy_to")
    private String currencyTo;
    @Column(name = "rate_type")
    private String rateType;
    @Column(name = "budget_status")
    private String budgetStatus;
    @Column(name = "rate_period")
    private String ratePeriod;
    @Column(name = "rate_val")
    private BigDecimal rateValue;


}
