package com.dbs.genesis.portfolio.service;

import com.dbs.genesis.portfolio.model.WorkHierarchyEntity;
import com.dbs.genesis.portfolio.repository.WorkHierarchyRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WorkHierarchyService {

    @Autowired
    WorkHierarchyRepo portFolioWorkHierarchyRepo;


    public List<WorkHierarchyEntity> getWorkHierarchy(String portfolioId) {
        return portFolioWorkHierarchyRepo.getByPortfolioId(portfolioId);
    }
}