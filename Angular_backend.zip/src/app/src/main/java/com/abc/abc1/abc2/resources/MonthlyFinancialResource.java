package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MonthlyFinancialResource {

    String workStreamId;
    String subWorkStreamId;
    String subWorkStreamName;
    String scenario;
    String currencyCode;
    HashSet<String> currencyCodes;
    Map<String,List<MonthlySeedFundingData>> monthlySeedFundingData;
    Map<String,List<MonthlyFinancialDetailsResource>> monthlyFinancialDetailsResources;
    Timestamp dateCreated;
    Timestamp modifiedDate;
    String createdBy;
    String modifiedBy;
}
