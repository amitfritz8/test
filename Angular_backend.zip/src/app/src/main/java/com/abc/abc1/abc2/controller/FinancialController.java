package com.dbs.genesis.portfolio.controller;

import com.dbs.genesis.portfolio.model.SubWorkstreamFinDetailsEntity;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.service.EmployeeRateCardService;
import com.dbs.genesis.portfolio.service.costsettings.CostSettingService;
import com.dbs.genesis.portfolio.service.costsettings.HLEService;
import com.dbs.genesis.portfolio.service.costsettings.SeedFundingOperationCostService;
import com.dbs.genesis.portfolio.service.financials.FinancialBreakDownCostService;
import com.dbs.genesis.portfolio.service.financials.FinancialService;
import com.dbs.genesis.portfolio.service.financials.MainFinancialService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Slf4j
@RestController
@RequestMapping("/financial")
public class FinancialController {

    private final FinancialService financialService;
    private final CostSettingService costSettingService;
    private final FinancialBreakDownCostService financialBreakDownCostService;
    private final MainFinancialService mainFinancialService;
    private final SeedFundingOperationCostService seedFundingOperationCost;
    private final HLEService hleService;
    private final EmployeeRateCardService employeeRateCardService;

    public FinancialController(FinancialService financialService, CostSettingService costSettingService,
                               FinancialBreakDownCostService financialBreakDownCostService,
                               MainFinancialService mainFinancialService,
                               SeedFundingOperationCostService seedFundingOperationCost,
                               HLEService hleService, EmployeeRateCardService employeeRateCardService) {
        this.financialService = financialService;
        this.costSettingService = costSettingService;
        this.financialBreakDownCostService = financialBreakDownCostService;
        this.mainFinancialService = mainFinancialService;
        this.seedFundingOperationCost = seedFundingOperationCost;
        this.hleService = hleService;
        this.employeeRateCardService = employeeRateCardService;
    }

    @GetMapping("/data")
    public Map getFinancialData(@RequestParam("scenario") String scenario,
                                @RequestParam("ccyCode") String ccyCode, @RequestParam("workStreamId") String workStreamId,
                                @RequestParam("subWorkStreamId") String subWorkStreamId,
                                @RequestParam("subWorkStreamName") String subWorkStreamName, @RequestParam("period")
                                        String period, @RequestParam("typeOfData") String typeOfData) {
        return financialService.getFinancialDataByScenario(scenario, ccyCode, workStreamId, subWorkStreamId,
                subWorkStreamName, period, typeOfData);
    }

    @GetMapping("/view-seed-funding")
    public ResponseEntity getSeedData(@RequestParam("workStreamId") String workStreamId,
                                      @RequestParam("subWorkStreamId") String subWorkStreamId,
                                      @RequestParam("subWorkStreamName") String subWorkStreamName,
                                      @RequestParam("currencyCodeType") String currencyCodeType,
                                      @RequestParam("scenario") String scenario) {

        SeedFundingOperationCostResource seedFundingData = costSettingService.getSeedFundingData(workStreamId,
                subWorkStreamId, subWorkStreamName, currencyCodeType, scenario);
        return ResponseEntity.ok().body(seedFundingData);
    }


    @PostMapping("/save-seed-funding")
    public ResponseEntity
    saveSeedFundingData(
            @RequestBody SeedFundingOperationCostResource seedFundingOperationCostResource) {
        List<String> list = new ArrayList<>();
        try {
            List<SubWorkstreamFinDetailsEntity> finDetailsEntities =
                    seedFundingOperationCost.saveSeedFundingOperationCost(seedFundingOperationCostResource);
            list.add("Success in persisting Operation Cost: total:" + finDetailsEntities.size());
        } catch (Exception ex) {
            log.error("error in SeedFundingOperationCostResource", ex);
            list.add("Failed to save seed funding");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(list);
        }
        return ResponseEntity.ok().body(list);
    }

    @PostMapping("/save-seed-funding/monthly")
    public ResponseEntity saveMonthlySeedFundingData(@RequestBody MonthlyFinancialResource monthlyFinancialResource) {
        List<String> list = new ArrayList<>();
        try {
            mainFinancialService.saveMonthlySeedFundingData(monthlyFinancialResource);
            list.add("success");
        } catch (Exception ex) {
            log.error("error in save seed funding monthly ", ex);
            list.add("Failed to save monthly seed funding");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(list);
        }

        return ResponseEntity.ok().body(list);
    }

    @PostMapping("/save-financial-detail/monthly")
    public ResponseEntity
    saveFinancialDetail(
            @RequestBody MonthlyFinancialResource monthlyFinancialResource) {
        List<String> list = new ArrayList<>();
        try {
            mainFinancialService.saveFinancialOperationCost(monthlyFinancialResource);
        } catch (Exception ex) {
            log.error("error in save financial detail monthly ", ex);
            list.add("Failed to save monthly financial details");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(list);
        }
        return ResponseEntity.ok().body(list);
    }

    @GetMapping("/listOfFinYears")
    public ResponseEntity getListOfFinanceYears(@RequestParam("workStreamId") String workStreamId, @RequestParam
            ("subWorkStreamId") String subWorkStreamId, @RequestParam("scenario") String scenario,
                                                @RequestParam("subWorkStreamName") String subWorkStreamName) {
        List<String> listOfYears = financialService.getFinancialYearsByScenario(workStreamId, subWorkStreamId, scenario,
                subWorkStreamName);
        return ResponseEntity.ok().body(listOfYears);
    }

    @GetMapping("/hleData")
    public ResponseEntity getHLEData(
            @RequestParam("workStreamId") String workStreamId,
            @RequestParam("subWorkStreamId") String subWorkStreamId,
            @RequestParam("subWorkStreamName") String subWorkStreamName,
            @RequestParam("currencyCodeType") String currencyCodeType,
            @RequestParam("scenario") String scenario) {
        HLERefDataResource hleRefDataResource = hleService.getHLECostData(workStreamId,
                subWorkStreamId, subWorkStreamName, currencyCodeType, scenario);
        return ResponseEntity.ok().body(hleRefDataResource);
    }

    @PostMapping("/saveHleData")
    public ResponseEntity saveHLEData(@RequestBody HLERefDataResource hleRefDataResource) {
        List<String> list = new ArrayList<>();
        try {
            List<SubWorkstreamFinDetailsEntity> finDetailsEntities =
                    hleService.saveHLEOperationCost(hleRefDataResource);
            list.add("Success in persisting HLE Operation Cost: total:" + finDetailsEntities.size());
        } catch (Exception ex) {
            log.error("error in HLEOperationCostResource", ex);
            list.add("failed to save HLE");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(list);
        }
        return ResponseEntity.ok().body(list);
    }


    @GetMapping("cost-settings/financialDetails")
    public CostSettingsFinancialDetailsResource getCostSettingFinancialDetails(
            @RequestParam("workStreamId") String workStreamId,
            @RequestParam("subWorkstreamId") String subWorkstreamId,
            @RequestParam("subWorkstreamName") String subWorkstreamName,
            @RequestParam("scenario") String scenario,
            @RequestParam("currencyCodeType") String loggedInUserCurrency) {
        CostSettingsFinancialDetailsResource costSettingsFinancialDetailsResource = new CostSettingsFinancialDetailsResource();
        costSettingsFinancialDetailsResource.setFinancialDetaildatesFormEntity
                (costSettingService.getCostSettingFinancialDetails(workStreamId, subWorkstreamId, subWorkstreamName,
                        scenario, loggedInUserCurrency));
        return costSettingsFinancialDetailsResource;
    }

    @GetMapping("cost-settings/financialDetailsTemplate")
    public FinancialDetailsTemplateResource getFinancialDetailsTemplate(@RequestParam("currencyCodeType") String currencyCodeType) {
        return costSettingService.getFinancialDetailsTemplate(currencyCodeType);
    }

    @GetMapping("cost-settings/financialDetailsTeamTemplate")
    public FinancialDetailsTeamTemplateResource getFinancialDetailsTeamTemplate(@RequestParam("workStreamId") String workStreamId) {
        return costSettingService.getFinancialDetailsTeamTemplate(workStreamId);
    }

    @PostMapping("cost-settings/staffRate")
    public ResponseEntity getStaffRate(@RequestBody StaffRateResource staffRateResource) {
        return ResponseEntity.ok().body(employeeRateCardService.getStaffRate(staffRateResource));
    }

    @PostMapping("cost-settings/financialDetails")
    public void saveCostSettingFinancialDetails(@RequestBody CostSettingsFinancialDetailsResource resource) {
        costSettingService.saveCostSettingFinancialDetails(resource.getFinancialDetaildatesFormEntity());
    }

    @GetMapping("/breakDownCostData")
    public ResponseEntity getFinancialBreakDownCostData(@RequestParam("scenario") String scenario,
                                                        @RequestParam("ccyCode") String ccyCode, @RequestParam("workStreamId") String workStreamId,
                                                        @RequestParam("subWorkStreamId") String subWorkStreamId,
                                                        @RequestParam("subWorkStreamName") String subWorkStreamName, @RequestParam("period")
                                                                String period, @RequestParam("periodType") String periodType) {
        try {
            Map<String, FinancialBreakDownCostView> breakDownCostData = financialBreakDownCostService.getBreakDownCostData
                    (scenario, ccyCode, workStreamId, subWorkStreamId, subWorkStreamName,
                            period, periodType);
            return ResponseEntity.ok().body(breakDownCostData);
        } catch (Exception e) {
            log.error("Failed to get response in breakdown cost view response", e);
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(Collections.singletonMap("failure", "Loading Financial BreakDown Cost Data unsuccessful"));
        }

    }

    @GetMapping("/currency-codes")
    public ResponseEntity getCurrencyCodes(@RequestParam("workStreamId") String workStreamId) {
        return ResponseEntity.ok(financialService.getCurrencyCodes(workStreamId));
    }

    @GetMapping("/report/currency-codes")
    public ResponseEntity getCurrencyCodesForReports() {
        return ResponseEntity.ok(financialService.getCurrencyCodesFromWorkStream());
    }

    @PostMapping("/currency-code")
    public ResponseEntity getCurrencyCode(@RequestParam("workStreamId") String workStreamId) {
        return ResponseEntity.ok(Arrays.asList(financialService.getCurrencyCode(workStreamId)));
    }

    @GetMapping("/psglLoad")
    public ResponseEntity callBackEndPsglProcedure() {
        try {
            return ResponseEntity.ok(Collections.singletonMap("success", financialService.callBackEndPsglProcedure()));
        } catch (Exception e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(Collections.singletonMap("failure", "Data loading unsuccessful"));
        }
    }

    @GetMapping("/hyperionLoad")
    public ResponseEntity callBackEndHyperionProcedure() {
        try {
            return ResponseEntity.ok(Collections.singletonMap("success", financialService.callBackEndHyperionProcedure()));
        } catch (Exception e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(Collections.singletonMap("failure", "Data loading unsuccessful"));
        }
    }

    @GetMapping("/getCurrenciesBasedOnUam")
    public List<String> getCurrenciesBasedOnUam(@RequestParam("loggedInUserId") String loggedInUserId){
        return  financialService.getCurrenciesBasedOnUam(loggedInUserId);
    }
}
