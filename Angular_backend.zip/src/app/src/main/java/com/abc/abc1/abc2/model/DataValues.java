package com.dbs.genesis.portfolio.model;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Data
@Entity
@Table(name = "xref_data_values")
@EntityListeners(AuditingEntityListener.class)
public class DataValues extends CommonEntity<String> {

    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    @Column(name = "refdata_id")
    private Integer id;
    @Column(name = "refdata_code")
    private Integer code;
    @Column(name = "refdata_value")
    private String value;
    @Column(name = "refdata_desc")
    private String desc;
    @Column(name = "status")
    private String status;
    @Column(name = "refdata_attr1")
    private String attr1;
    @Column(name = "refdata_attr2")
    private String attr2;
    @Column(name = "refdata_attr3")
    private String attr3;
    @Column(name = "refdata_attr4")
    private String attr4;
    @Column(name = "refdata_attr5")
    private String attr5;
    @Column(name = "refdata_attr6")
    private String attr6;
    @Column(name = "refdata_attr7")
    private String attr7;
    @Column(name = "refdata_attr8")
    private String attr8;
    @Column(name = "refdata_attr9")
    private String attr9;
    @Column(name = "refdata_attr10")
    private String attr10;
}
