package com.dbs.genesis.portfolio.model;

import com.dbs.genesis.portfolio.resources.WorkStreamManagersResource;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Date;

@Data
@Entity
@Table(name = "workstream_managers")
@EntityListeners(AuditingEntityListener.class)
@ToString
public class WorkStreamManagersEntity extends CommonEntity<String> {


    @Id
    @Column(name = "ws_mgr_surr_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int wsMgrSurrId;
    @Column(name = "workstream_id")
    private String workStreamId;
    @Column(name = "portfolio_id")
    private String portfolioId;
    @Column(name = "1bank_id")
    private String oneBankId;
    @Column(name = "staff_name")
    private String staffName;
    @Column(name = "role")
    private String role;
    @Column(name = "platform_index")
    private String platformIndex;
    @Column(name = "email_address")
    private String emailAddress;
    @Column(name = "effective_start_date")
    private Date effectiveStartDate;
    @Column(name = "effective_end_date")
    private Date effectiveEndDate;
    @Column(name = "delegate_ind")
    private String delegateInd;
    @Column(name = "active_ind")
    private String activeInd;

    public WorkStreamManagersResource toWorkStreamManagersResource() {
        WorkStreamManagersResource workStreamManagersResource = new WorkStreamManagersResource();
        workStreamManagersResource.setWsMgrSurrId(getWsMgrSurrId());
        workStreamManagersResource.setPortfolioId(getPortfolioId());
        workStreamManagersResource.setWorkStreamId(getWorkStreamId());
        workStreamManagersResource.setEmailAddress(getEmailAddress());
        workStreamManagersResource.setEffectiveStartDate(getEffectiveStartDate());
        workStreamManagersResource.setEffectiveEndDate(getEffectiveEndDate());
        workStreamManagersResource.setOneBankId(getOneBankId());
        workStreamManagersResource.setDelegateInd(getDelegateInd().toLowerCase());
        workStreamManagersResource.setPlatformIndex(getPlatformIndex());
        workStreamManagersResource.setRole(getRole());
        workStreamManagersResource.setStaffName(getStaffName());
        return workStreamManagersResource;
    }
}
