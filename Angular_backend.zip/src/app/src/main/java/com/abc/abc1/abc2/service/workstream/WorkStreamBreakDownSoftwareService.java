package com.dbs.genesis.portfolio.service.workstream;

import com.dbs.genesis.portfolio.common.CombineTwoArrayValues;
import com.dbs.genesis.portfolio.common.CommonFinancialTypes;
import com.dbs.genesis.portfolio.common.GeneUtils;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.repository.SubWorkstreamSoftwareCostRepo;
import com.dbs.genesis.portfolio.resources.FinancialSummaryResource;
import com.dbs.genesis.portfolio.resources.SubWorkStreamIdAndName;
import com.dbs.genesis.portfolio.resources.UnitCostMappingView;
import com.dbs.genesis.portfolio.resources.UnitCostResource;
import com.google.common.collect.Lists;
import io.vavr.Tuple2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class WorkStreamBreakDownSoftwareService implements CombineTwoArrayValues, CommonFinancialTypes {

    public static final String FINANCIAL_SOFTWARE_HEADER_SUMMARY_BY_PERIOD_AND_GROUP_CCY = "financialSoftwareHeaderSummaryByPeriodAndGroupCcy";
    public static final String FINANCIAL_SOFTWARE_HEADER_SUMMARY_BY_PERIOD_AND_LOCAL_CCY = "financialSoftwareHeaderSummaryByPeriodAndLocalCcy";
    public static final String FINANCIAL_SOFTWARE_HEADER_SUMMARY_BY_PERIOD_AND_GROUP_CCY1 = "financialSoftwareHeaderSummaryByPeriodAndGroupCcy";
    public static final String FINANCIAL_SOFTWARE_HEADER_SUMMARY_BY_PERIOD_AND_LOCAL_CCY1 = "financialSoftwareHeaderSummaryByPeriodAndLocalCcy";
    private final SubWorkstreamSoftwareCostRepo subWorkstreamSoftwareCostRepo;
    private final WorkStreamBreakDownOthersService workStreamBreakDownOthersService;
    @Autowired
    private PortfolioRepository portfolioRepository;


    @Autowired
    public WorkStreamBreakDownSoftwareService(SubWorkstreamSoftwareCostRepo subWorkstreamSoftwareCostRepo,
                                              WorkStreamBreakDownOthersService workStreamBreakDownOthersService) {
        this.subWorkstreamSoftwareCostRepo = subWorkstreamSoftwareCostRepo;
        this.workStreamBreakDownOthersService = workStreamBreakDownOthersService;
    }

    public List<BigDecimal> getListOfMonthlyValuesBySoftwareTotal(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                                                  String period,String scenario,String currencyCode,String costType) {

        /*Map<String, List<SubWorkstreamSoftwareCost>> softwareListByPeriod =
                subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> subWorkstreamSoftwareCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndPeriodContaining(
                        subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.TRUE,PortfolioConstants.FALSE ,period)).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList()).stream().collect(
                Collectors.groupingBy(SubWorkstreamSoftwareCost::getPeriod));*/


        List<FinancialSummaryResource> consolidatedFinancialSummary =
                PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->{
                            return portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndGroupCurrency(
                                    subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), period,
                                    scenario,"financialSoftwareHeaderSummaryByPeriodAndGroupCcy",costType);
                                }).flatMap(List::stream).collect(Collectors.toList())
                        : subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->{
                    return portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndLocalCurrency(
                            subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), period,
                            scenario,"financialSoftwareHeaderSummaryByPeriodAndGroupCcy",costType);
                }).flatMap(List::stream).collect(Collectors.toList()) ;

        BigDecimal[] monthlyValues = new BigDecimal[12];
        Arrays.fill(monthlyValues, BigDecimal.ZERO);

        for (FinancialSummaryResource summaryResource : consolidatedFinancialSummary) {
            String reportingMonth = summaryResource.getPeriod().substring(4, 6);
            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                monthlyValues[Integer.parseInt(reportingMonth) - 1] = summaryResource.getCurrencyValue();
            }
        }
        BigDecimal[] othersSoftwareByMonthly = workStreamBreakDownOthersService.getOthersSummaryByMonthly(subWorkStreamIdAndNames,period,scenario,PortfolioConstants.SOFTWARE_TYPE,currencyCode);
        BigDecimal[] combineMonthlyValuesBySoftware = getCombineMonthlyValues(monthlyValues, othersSoftwareByMonthly);
        return Arrays.asList(combineMonthlyValuesBySoftware);
    }


    public Tuple2<BigDecimal,BigDecimal> getCostTypeOverAllTotal(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String scenario,String currencyCode) {
        List<SubWorkstreamSoftwareCost> subWorkStreamNameAndScenario = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamSoftwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotIn(
                subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.TRUE,PortfolioConstants.FALSE, GeneUtils.getGlCategoriesNotInclude()))
                .flatMap(List::stream).collect(Collectors.toList());

        BigDecimal costOverAllTotal = BigDecimal.ZERO;
        BigDecimal unitOverAllTotal = BigDecimal.ZERO;

        for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
            costOverAllTotal = costOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    portfolioRepository.getSubworkstreamCostTypeOverAllTotalByGroupCurrency(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario,
                            "financialSoftwareCostTypeOverAllTotalByGroupCurrency",  PortfolioConstants.SOFTWARE_TYPE).get(0).getCurrencyValue()
                    : portfolioRepository.getSubworkstreamCostTypeOverAllTotalByLocalCurrency(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario,
                    "financialSoftwareCostTypeOverAllTotalByLocalCurrency",  PortfolioConstants.SOFTWARE_TYPE).get(0).getCurrencyValue());
        }

//        for (SubWorkstreamSoftwareCost subWorkStreamSoftwareCost : subWorkStreamNameAndScenario) {
//
//            /*costOverAllTotal = costOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
//                    subWorkStreamSoftwareCost.getCostPerMonthGcy() : subWorkStreamSoftwareCost.getCostPerMonthLcy());
//            unitOverAllTotal = unitOverAllTotal.add(subWorkStreamSoftwareCost.getQuantity());*/
//        }
        return new Tuple2<>(costOverAllTotal,unitOverAllTotal);
    }


    public List<UnitCostMappingView> getSoftwareUnitCostMapByMonthly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                                                      String period,String scenario,String currencyCode) {
        Map<String, Map<String, List<SubWorkstreamSoftwareCost>>> vendorPeriodMap = getSubWorkStreamSoftwareMap(subWorkStreamIdAndNames, period,scenario);
        List<UnitCostMappingView> unitCostList = Lists.newArrayList();

        vendorPeriodMap.forEach((vendorName, softwareNameListMap) -> {
            softwareNameListMap.forEach((softwareName, subWorkStreamSoftwareCostList) -> {
                UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
                unitCostMappingView.setRefSurrId(subWorkStreamSoftwareCostList.get(0).getRefSwsSwSurrId());
                unitCostMappingView.setName(vendorName +" - "+softwareName);
                //Todo need to get from db
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
                unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
                populateUnitCostMappingForGivenSoftware(subWorkStreamSoftwareCostList, unitCostMappingView,currencyCode);
                Tuple2<BigDecimal,BigDecimal> unitCostOverAllTotal = getUnitCostOverAllTotal(subWorkStreamIdAndNames,vendorName,scenario,currencyCode);
                unitCostMappingView.setYearlyCostOverAllTotal(unitCostOverAllTotal._1);
                unitCostMappingView.setYearlyUnitOverAllTotal(unitCostOverAllTotal._2);
                unitCostList.add(unitCostMappingView);
            });
        });
        List<UnitCostMappingView> otherSoftwareResource = workStreamBreakDownOthersService.getOtherSoftwareByMonthly(subWorkStreamIdAndNames, period,scenario,currencyCode);
        unitCostList.addAll(otherSoftwareResource);

        return unitCostList;
    }

    private Map<String, Map<String, List<SubWorkstreamSoftwareCost>>> getVendorNamePeriodAndSoftwareCostList(
            List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String year,String scenario) {
        return subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> subWorkstreamSoftwareCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotInAndPeriodContaining(
                        subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario,
                        PortfolioConstants.TRUE,PortfolioConstants.FALSE ,GeneUtils.getGlCategoriesNotInclude(), year)).flatMap(List::stream).collect(
                Collectors.groupingBy(SubWorkstreamSoftwareCost::getVendorName, Collectors.groupingBy(SubWorkstreamSoftwareCost::getSoftwareName)));
    }

    private Map<String, Map<String, List<SubWorkstreamSoftwareCost>>> getSubWorkStreamSoftwareMap(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                                                                                  String period,String scenario) {
        return subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> subWorkstreamSoftwareCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotInAndPeriodContaining(
                        subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario,
                        PortfolioConstants.TRUE,PortfolioConstants.FALSE ,GeneUtils.getGlCategoriesNotInclude(), period)).flatMap(List::stream)
                .collect(Collectors.groupingBy(SubWorkstreamSoftwareCost::getVendorName, Collectors.groupingBy(SubWorkstreamSoftwareCost::getSoftwareName
                        )));
    }

    private UnitCostMappingView populateUnitCostMappingForGivenSoftware(List<SubWorkstreamSoftwareCost> softwarePeriodList,
                                                                        UnitCostMappingView unitCostMappingView, String currencyCode) {
        List<UnitCostResource> costResourceList = Lists.newLinkedList();
        List<UnitCostResource> unitResourceList = Lists.newLinkedList();

        BigDecimal unitOverAllTotal = BigDecimal.ZERO;
        BigDecimal costOverAllTotal = BigDecimal.ZERO;

        for (SubWorkstreamSoftwareCost subWorkStreamSoftwareCost : softwarePeriodList) {
            String reportingMonth = subWorkStreamSoftwareCost.getPeriod().substring(4, 6);
            UnitCostResource costResource = new UnitCostResource();
            // int monthNumber = Integer.parseInt(reportingMonth);
            BigDecimal costPerMonth = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkStreamSoftwareCost.getCostPerMonthGcy() : subWorkStreamSoftwareCost.getCostPerMonthLcy();
            BigDecimal quantity = subWorkStreamSoftwareCost.getQuantity();

            costResource.setSurrId(subWorkStreamSoftwareCost.getSwsSwSurrId());
            costResource.setMonthNumber(reportingMonth);
            costResource.setValue(costPerMonth);
            costResourceList.add(costResource);
            unitOverAllTotal = unitOverAllTotal.add(quantity);
            costOverAllTotal = costOverAllTotal.add(costPerMonth);

            UnitCostResource unitResource = new UnitCostResource();
            unitResource.setSurrId(subWorkStreamSoftwareCost.getSwsSwSurrId());
            unitResource.setMonthNumber(reportingMonth);
            unitResource.setValue(quantity);
            unitResourceList.add(unitResource);
        }

        costResourceList = costResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(costResourceList) : costResourceList;
        unitResourceList = unitResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(unitResourceList) : unitResourceList;

        unitCostMappingView.setMonthlyResourcesCosts(costResourceList);
        unitCostMappingView.setMonthlyResourcesUnits(unitResourceList);
        unitCostMappingView.setUnitOverAllTotal(unitOverAllTotal);
        unitCostMappingView.setCostOverAllTotal(costOverAllTotal);

        return unitCostMappingView;
    }

    private List<UnitCostResource> getUnitAndCostResourceMonthlyList( List<UnitCostResource> unitAndCostResourceList){
        List<UnitCostResource> unitAndcostResourceMonthlyList = Lists.newLinkedList();
        if(unitAndCostResourceList.size() < 12) {
            for (int i = 1; i <= 12; i++) {
                UnitCostResource costResource = new UnitCostResource();
                costResource.setSurrId(0);
                costResource.setMonthNumber(i <= 9 ? "0" + i : String.valueOf(i));
                costResource.setValue(BigDecimal.ZERO);
                unitAndcostResourceMonthlyList.add(costResource);
            }
            for (int i = 0; i < unitAndcostResourceMonthlyList.size() ; i++) {
                for (int j = 0; j < unitAndCostResourceList.size(); j++) {
                    if(unitAndcostResourceMonthlyList.get(i).getMonthNumber().equalsIgnoreCase(unitAndCostResourceList.get(j).getMonthNumber())){
                        unitAndcostResourceMonthlyList.set(i,unitAndCostResourceList.get(j));
                        break;
                    }
                }
            }
        }
        return unitAndcostResourceMonthlyList;
    }

    private Tuple2<BigDecimal,BigDecimal> getUnitCostOverAllTotal(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String vendorName, String scenario, String currencyCode) {
        List<SubWorkstreamSoftwareCost> subWorkStreamNameAndScenario = subWorkStreamIdAndNames.stream()
                .map(subWorkStreamIdAndName -> subWorkstreamSoftwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndVendorNameAndActiveIndAndOriginalIndAndGlCategoryNotIn(
                subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),
                        scenario, vendorName, PortfolioConstants.TRUE,PortfolioConstants.FALSE, GeneUtils.getGlCategoriesNotInclude())).flatMap(List::stream).collect(Collectors.toList());

        BigDecimal costOverAllTotal = BigDecimal.ZERO;
        BigDecimal unitOverAllTotal = BigDecimal.ZERO;
        for (SubWorkstreamSoftwareCost subWorkStreamSoftwareCost : subWorkStreamNameAndScenario) {
            costOverAllTotal = costOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkStreamSoftwareCost.getCostPerMonthGcy() : subWorkStreamSoftwareCost.getCostPerMonthLcy());
            unitOverAllTotal = unitOverAllTotal.add(subWorkStreamSoftwareCost.getQuantity());
        }
        return new Tuple2<>(costOverAllTotal,unitOverAllTotal);
    }

    public Map<String, List<BigDecimal>> getSoftwareQuarterlyListMap(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                                                     String scenario,String currencyCode,String costType) {
        Map<String, List<BigDecimal>> quarterlySum = new TreeMap<>();
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        List<String> distinctOfPeriods =
                subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                        subWorkstreamSoftwareCostRepo.findDistinctOfPeriodsFromSoftwareCostAndOtherSoftwareCost(
                                subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario,glCategories)
                ).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
        List<BigDecimal> quarterlySummaryList;
        for (String year : distinctOfPeriods) {
            List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                            portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndGroupCurrency(subWorkStreamIdAndName.getSubWorkStreamId(),
                                    subWorkStreamIdAndName.getSubWorkStreamName(), year, scenario, FINANCIAL_SOFTWARE_HEADER_SUMMARY_BY_PERIOD_AND_GROUP_CCY,costType))
                                    .flatMap(List::stream).collect(Collectors.toList())
                    : subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                            portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndLocalCurrency(subWorkStreamIdAndName.getSubWorkStreamId(),
                                    subWorkStreamIdAndName.getSubWorkStreamName(), year, scenario, FINANCIAL_SOFTWARE_HEADER_SUMMARY_BY_PERIOD_AND_LOCAL_CCY,costType))
                            .flatMap(List::stream).collect(Collectors.toList());

            quarterlySummaryList = getQuarterlySummaryList(consolidatedFinancialSummary, year, subWorkStreamIdAndNames, scenario, currencyCode);
            quarterlySum.put(year, quarterlySummaryList);
        }
        return quarterlySum;
    }

    private List<BigDecimal> getQuarterlySummaryList(List<FinancialSummaryResource> consolidatedFinancialSummary, String year,
                                                     List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario, String currencyCode) {

        BigDecimal firstQuarter = BigDecimal.ZERO;
        BigDecimal secondQuarter = BigDecimal.ZERO;
        BigDecimal thirdQuarter = BigDecimal.ZERO;
        BigDecimal fourthQuarter = BigDecimal.ZERO;

        for (FinancialSummaryResource financialSummaryResource : consolidatedFinancialSummary) {
            String reportingYear = financialSummaryResource.getPeriod().substring(0, 4);
            if (year.equalsIgnoreCase(reportingYear)) {
                String reportingMonth = financialSummaryResource.getPeriod().substring(4, 6);
                if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                    firstQuarter = getCurrencyValueForQuarterly(currencyCode, firstQuarter, financialSummaryResource.getCurrencyValue());
                }
                if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                    secondQuarter = getCurrencyValueForQuarterly(currencyCode, secondQuarter, financialSummaryResource.getCurrencyValue());
                }
                if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                    thirdQuarter = getCurrencyValueForQuarterly(currencyCode, thirdQuarter, financialSummaryResource.getCurrencyValue());
                }
                if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                    fourthQuarter = getCurrencyValueForQuarterly(currencyCode, fourthQuarter, financialSummaryResource.getCurrencyValue());
                }
            }
        }
        List<BigDecimal> othersByQuarterlyTotalSum = workStreamBreakDownOthersService.getOthersByQuarterlyTotalSum(subWorkStreamIdAndNames, scenario, PortfolioConstants.SOFTWARE_TYPE, year, currencyCode);

        return Arrays.asList(firstQuarter.add(othersByQuarterlyTotalSum.get(0)), secondQuarter.add(othersByQuarterlyTotalSum.get(1)),
                thirdQuarter.add(othersByQuarterlyTotalSum.get(2)), fourthQuarter.add(othersByQuarterlyTotalSum.get(3)));
    }


    private BigDecimal getCurrencyValueForQuarterly(String currencyCode, BigDecimal firstQuarter, BigDecimal ccyValue) {
        if ( ccyValue != null && ccyValue.intValue() != 0) {
            firstQuarter = firstQuarter.add(ccyValue);
        }
        return firstQuarter;
    }


    public Map<String, List<UnitCostMappingView>> getSoftwareUnitCostMapQuarterly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String scenario,String currencyCode) {

        Map<String, List<UnitCostMappingView>> quarterlyUnitCostMapByPeriod = new TreeMap<>();
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        List<String> listOfSoftwareYears = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamSoftwareCostRepo.findDistinctOfPeriodsFromSoftwareCostAndOtherSoftwareCost
                (subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),scenario,glCategories))
                .flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
        for (String year : listOfSoftwareYears) {
            Map<String, Map<String, List<SubWorkstreamSoftwareCost>>> vendorPeriodMap = getVendorNamePeriodAndSoftwareCostList(subWorkStreamIdAndNames, year,scenario);
            List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
            vendorPeriodMap.forEach((vendorName, softwareNameListMap) -> softwareNameListMap.forEach((softwareName, subWorkStreamSoftwareCostList) -> {
                UnitCostMappingView unitCostMappingView = getUnitCostMappingResourceByQuarterly(subWorkStreamSoftwareCostList, subWorkStreamIdAndNames,scenario,currencyCode);
                unitCostMappingView.setName(vendorName+" - "+softwareName);
                unitCostMappingView.setRefSurrId(subWorkStreamSoftwareCostList.get(0).getCapexOpexSurrId());
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
                unitCostMappingViewArrayList.add(unitCostMappingView);
            }));
            unitCostMappingViewArrayList.addAll(workStreamBreakDownOthersService.getOtherSoftwareByQuarterly(subWorkStreamIdAndNames,year,scenario,currencyCode));
            quarterlyUnitCostMapByPeriod.put(year, unitCostMappingViewArrayList);
        }
        return quarterlyUnitCostMapByPeriod;
    }

    private UnitCostMappingView getUnitCostMappingResourceByQuarterly(List<SubWorkstreamSoftwareCost> subWorkStreamSoftwareCostList,
                                                                      List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario, String currencyCode) {

        BigDecimal firstQuarterUnitTotal = BigDecimal.ZERO;
        BigDecimal secondQuarterUnitTotal = BigDecimal.ZERO;
        BigDecimal thirdQuarterUnitTotal = BigDecimal.ZERO;
        BigDecimal fourthQuarterUnitTotal = BigDecimal.ZERO;

        BigDecimal firstQuarterCostTotal = BigDecimal.ZERO;
        BigDecimal secondQuarterCostTotal = BigDecimal.ZERO;
        BigDecimal thirdQuarterCostTotal = BigDecimal.ZERO;
        BigDecimal fourthQuarterCostTotal = BigDecimal.ZERO;

        UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
        unitCostMappingView.setPeriodType(PortfolioConstants.QUARTERLY);
        for (SubWorkstreamSoftwareCost softwareCost : subWorkStreamSoftwareCostList){
            String reportingMonth = softwareCost.getPeriod().substring(4, 6);
            if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                Tuple2<BigDecimal, BigDecimal> costUnitTotal = getCostUnitTotalForGivenReportingMonth(softwareCost,currencyCode);
                firstQuarterCostTotal = firstQuarterCostTotal.add(costUnitTotal._1);
                firstQuarterUnitTotal = firstQuarterUnitTotal.add(costUnitTotal._2);
            } else if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                Tuple2<BigDecimal, BigDecimal> costUnitTotal = getCostUnitTotalForGivenReportingMonth(softwareCost, currencyCode);
                secondQuarterCostTotal = secondQuarterCostTotal.add(costUnitTotal._1);
                secondQuarterUnitTotal = secondQuarterUnitTotal.add(costUnitTotal._2);
            } else if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                Tuple2<BigDecimal, BigDecimal> costUnitTotal = getCostUnitTotalForGivenReportingMonth(softwareCost, currencyCode);
                thirdQuarterCostTotal = thirdQuarterCostTotal.add(costUnitTotal._1);
                thirdQuarterUnitTotal = thirdQuarterUnitTotal.add(costUnitTotal._2);
            } else if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                Tuple2<BigDecimal, BigDecimal> costUnitTotal = getCostUnitTotalForGivenReportingMonth(softwareCost, currencyCode);
                fourthQuarterCostTotal = fourthQuarterCostTotal.add(costUnitTotal._1);
                fourthQuarterUnitTotal = fourthQuarterUnitTotal.add(costUnitTotal._2);
            }
        }
        unitCostMappingView.setQuarterlyCostTotal(Arrays.asList(firstQuarterCostTotal,secondQuarterCostTotal,thirdQuarterCostTotal,fourthQuarterCostTotal));
        unitCostMappingView.setQuarterlyUnitTotal(Arrays.asList(firstQuarterUnitTotal,secondQuarterUnitTotal,thirdQuarterUnitTotal,fourthQuarterUnitTotal));
        Tuple2<BigDecimal, BigDecimal> costTypeOverAllTotal = getCostTypeOverAllTotal(subWorkStreamIdAndNames,scenario,currencyCode);
        unitCostMappingView.setYearlyCostOverAllTotal(costTypeOverAllTotal._1);
        unitCostMappingView.setYearlyUnitOverAllTotal(costTypeOverAllTotal._2);

        return unitCostMappingView;
    }

    private Tuple2<BigDecimal,BigDecimal> getCostUnitTotalForGivenReportingMonth(SubWorkstreamSoftwareCost softwareCost, String currencyCode) {
        BigDecimal quarterTotalCost = new BigDecimal(BigInteger.ZERO);
        BigDecimal quarterTotalUnit = new BigDecimal(BigInteger.ZERO);
        quarterTotalUnit = quarterTotalUnit.add(softwareCost.getQuantity());
        quarterTotalCost = quarterTotalCost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                softwareCost.getCostPerMonthGcy() : softwareCost.getCostPerMonthLcy());
        return new Tuple2<>(quarterTotalCost, quarterTotalUnit);
    }



    public Map<String,  List<UnitCostMappingView>> getYearlySoftwareData(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String scenario,String currencyCode) {
        Map<String,  List<UnitCostMappingView>> yearlyCostUnitResource = new TreeMap<>();
        List<String> listOfYears = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamSoftwareCostRepo.findDistinctOfPeriodsFromSoftwareCost(subWorkStreamIdAndName.getSubWorkStreamId(),
                        subWorkStreamIdAndName.getSubWorkStreamName(),scenario)).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
        for (String year : listOfYears) {
            Map<String, Map<String, List<SubWorkstreamSoftwareCost>>> vendorAndSoftwareMap = getVendorNamePeriodAndSoftwareCostList(subWorkStreamIdAndNames, year,scenario);
            List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
            vendorAndSoftwareMap.forEach((vendorName, softwareNameMap) -> softwareNameMap.forEach((softwareName, subWorkStreamSoftwareCostList) -> {
                UnitCostMappingView unitCostMappingView = getUnitCostMappingResourceByYearly(subWorkStreamSoftwareCostList,currencyCode);
                unitCostMappingView.setName(vendorName + " - " + softwareName);
                //TODO set currencytype, currencyvalue
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
                unitCostMappingViewArrayList.add(unitCostMappingView);
            }));
            unitCostMappingViewArrayList.addAll(workStreamBreakDownOthersService.getOthersSoftwareByYearly(subWorkStreamIdAndNames,year,scenario,currencyCode));
            yearlyCostUnitResource.put(year, unitCostMappingViewArrayList);
        }
        return yearlyCostUnitResource;
    }

    private UnitCostMappingView getUnitCostMappingResourceByYearly(List<SubWorkstreamSoftwareCost> softwarePeriodList, String currencyCode) {

        BigDecimal unitTotal = BigDecimal.ZERO;
        BigDecimal costTotal = BigDecimal.ZERO;
        UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
        unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
        for (SubWorkstreamSoftwareCost subWorkStreamSoftwareCost : softwarePeriodList) {
            unitTotal = unitTotal.add(subWorkStreamSoftwareCost.getQuantity());
            costTotal = costTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkStreamSoftwareCost.getCostPerMonthGcy() : subWorkStreamSoftwareCost.getCostPerMonthLcy());
        }
        unitCostMappingView.setRefSurrId(softwarePeriodList.get(0).getCapexOpexSurrId());
        unitCostMappingView.addYearlyUnitTotal(unitTotal);
        unitCostMappingView.addYearlyCostTotal(costTotal);
        return unitCostMappingView;
    }

    public Map<String, BigDecimal> getYearlySoftwareSummary(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                                            String scenario,String currencyCode,String costType) {
        Map<String, BigDecimal> totalYearSumMap = new TreeMap<>();
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        List<String> listOfYears = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamSoftwareCostRepo.findDistinctOfPeriodsFromSoftwareCostAndOtherSoftwareCost(
                        subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, glCategories))
                        .flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
        for (String year : listOfYears) {
            BigDecimal totalYearSum = BigDecimal.ZERO;
            List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> {
                            return portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndGroupCurrency(
                    subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), year,
                    scenario, FINANCIAL_SOFTWARE_HEADER_SUMMARY_BY_PERIOD_AND_GROUP_CCY1,costType);})
                                    .flatMap(List::stream).collect(Collectors.toList())
                            : subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> {
                        return portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndLocalCurrency(
                                subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), year,
                                scenario, FINANCIAL_SOFTWARE_HEADER_SUMMARY_BY_PERIOD_AND_LOCAL_CCY1,costType);})
                            .flatMap(List::stream).collect(Collectors.toList());


            for (FinancialSummaryResource subWorkStreamSoftwareCost : consolidatedFinancialSummary) {
                totalYearSum = totalYearSum.add(subWorkStreamSoftwareCost.getCurrencyValue());
            }
            BigDecimal softwareYearlySum = workStreamBreakDownOthersService.getOthersByYearlySum(subWorkStreamIdAndNames, scenario, year, PortfolioConstants.SOFTWARE_TYPE, currencyCode);
            totalYearSum = totalYearSum.add(softwareYearlySum);
            totalYearSumMap.put(year, totalYearSum);
        }
        return totalYearSumMap;
    }

}
