package com.dbs.genesis.portfolio.controller;


import com.dbs.genesis.portfolio.model.PcCodeTree;
import com.dbs.genesis.portfolio.repository.PcCodeTreeRepo;
import com.dbs.genesis.portfolio.service.PcCodeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/pccodes")
public class PcCodeTreeController {

    @Autowired
    private PcCodeService pcCodeService;


    @GetMapping("/{platformIndex}")
    public List<PcCodeTree> getPcCodeListByPlatform(@PathVariable String platformIndex) {
        return pcCodeService.getPcCodesTreeListByPlatform(platformIndex);
    }

    @GetMapping
    public ResponseEntity getPcCodeList() {
        return ResponseEntity.ok(pcCodeService.getPcCodesTreeList());
    }

    @GetMapping("/countryCode/{countryCode}")
    public List<String> getPcCodeListByCountryCode(@PathVariable String countryCode) {
        return pcCodeService.getPcCodeListByCountryCode(countryCode);
    }

}
