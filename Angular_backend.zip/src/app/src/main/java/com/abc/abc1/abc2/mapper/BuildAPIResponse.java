package com.dbs.genesis.portfolio.mapper;

import lombok.Data;
import org.springframework.http.HttpStatus;

import java.util.*;


@Data
public class BuildAPIResponse {
    private final String message;
    private final HttpStatus httpStatus;
    private final String statusCode;
    private final Date timestamp;
    private final Object object;


    public BuildAPIResponse(String message, HttpStatus httpStatus, Date timestamp, Object object) {
        this.message = message;
        this.httpStatus = httpStatus;
        this.statusCode = ""+httpStatus.value();
        this.timestamp = timestamp;
        this.object = object;
    }

    public BuildAPIResponse(String message, HttpStatus httpStatus, String statusCode, Date timestamp, Object object) {
        this.message = message;
        this.httpStatus = httpStatus;
        this.statusCode = statusCode;
        this.timestamp = timestamp;
        this.object = object;
    }


}
