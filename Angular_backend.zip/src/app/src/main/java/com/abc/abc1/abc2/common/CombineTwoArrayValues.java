package com.dbs.genesis.portfolio.common;

import java.math.BigDecimal;

public interface CombineTwoArrayValues {

    default BigDecimal[] getCombineMonthlyValues(BigDecimal[] first, BigDecimal[] second) {

        int length = first.length < second.length ? first.length : second.length;

        BigDecimal[] result = new BigDecimal[length];
        for (int i = 0; i < length; i++) {
            result[i] = first[i].add(second[i]);
        }
        return result;
    }

}
