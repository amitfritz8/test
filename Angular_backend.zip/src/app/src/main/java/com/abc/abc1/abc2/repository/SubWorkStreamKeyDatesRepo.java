package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.SubWorkStreamKeyDatesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Repository
public interface SubWorkStreamKeyDatesRepo extends JpaRepository<SubWorkStreamKeyDatesEntity, String> {
    List<SubWorkStreamKeyDatesEntity> findByWorkStreamIdAndActiveInd(String workStreamId, String aTrue);

    SubWorkStreamKeyDatesEntity findBySubWorkStreamIdAndActiveIndAndSubWorkStreamName(String subWorkStreamId,
                                                                                      String aTrue,
                                                                                      String subWorkStreamName);

    SubWorkStreamKeyDatesEntity findBySubWorkStreamIdAndActiveIndAndSubWorkStreamNameAndScenarioName(String subWorkStreamId,
                                                                                                     String aTrue,
                                                                                                     String subWorkStreamName,
                                                                                                     String scenarionName);

    List<SubWorkStreamKeyDatesEntity> findBySubWorkStreamIdAndSubWorkStreamNameAndActiveInd(String subWorkStreamId,
                                                                                            String subWorkStreamName, String activeIndicator);


    SubWorkStreamKeyDatesEntity findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(String workStreamId,
                                                                                                                    String subWorkStreamId, String subWorkStreamName, String aTrue, String scenarioName);


    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update SubWorkStreamKeyDatesEntity keyDates set keyDates.approvalDate =:approvalDate ," +
            " keyDates.scenarioName =:approvalScenario  " +
            "where keyDates.workStreamId in (:workStreamIds) and keyDates.scenarioName=:scenarioName")
    Integer updateApprovalDateAndScenarioForWorkStreamsAndScenario(@Param("workStreamIds") List<String> workStreamIds,
                                                        @Param("scenarioName") String scenarioName,
                                                        @Param("approvalDate") Date approvalDate,
                                                        @Param("approvalScenario") String approvalScenario);

    List<SubWorkStreamKeyDatesEntity> findAllByWorkStreamIdAndSubWorkStreamIdInAndScenarioName(
            String workStreamId, List<String> subWorkStreamIds, String scenario);

    Integer deleteAllByWorkStreamIdInAndScenarioNameIn(List<String> workStreamIds, List<String> scenarios);

    @Query("SELECT DISTINCT keyDates.scenarioName FROM SubWorkStreamKeyDatesEntity keyDates " +
            "where keyDates.workStreamId in (:workStreamIds) and keyDates.scenarioName in (:scenarios) and " +
            "keyDates.approvalDate IS NULL  order by keyDates.scenarioName ASC")
    Set<String> findAllDistinctByWorkStreamIdInAndScenarioNameInAndApprovalDateIsNull(
            @Param("workStreamIds") List<String> workStreamIds, @Param("scenarios") Set<String> scenarios);
    SubWorkStreamKeyDatesEntity findBySubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(String subWorkStreamId, String subWorkStreamName, String aTrue, String scenario);
}
