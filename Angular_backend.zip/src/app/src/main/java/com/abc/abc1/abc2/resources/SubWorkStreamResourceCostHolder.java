package com.dbs.genesis.portfolio.resources;

import com.dbs.genesis.portfolio.model.SubWorkStreamResourceCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class SubWorkStreamResourceCostHolder {

    SubWorkStreamResourceCost subWorkStreamResourceCost;
    List<SubWorkStreamResourceCost> subWorkStreamResourceCosts = new ArrayList<>();
}
