package com.dbs.genesis.portfolio.model.copyscenario;

import lombok.Data;

@Data
public class ScenarioCopyHierarchy {

    private String portFolioId;
    private String workStreamId;
    private String subWorkStreamId;
    private String scenarioFrom;
    private String scenarioTo;

    private SubWorkStreamFinDetailsEntityCopyHolder finDetailsEntityForcastsCopyHolder;
    private SubWorkStreamFinDetailsEntityActualsCopyHolder finDetailsEntityActualsCopyHolder;
    private SubWorkStreamSoftwareCostCopyHolder softwareCostCopyHolder;
    private SubWorkStreamHardwareCostCopyHolder hardwareCostCopyHolder;
    private SubWorkStreamResourceCostCopyHolder resourceCostCopyHolder;
    private SubWorkStreamOtherCostCopyHolder otherCostCopyHolder;


}
