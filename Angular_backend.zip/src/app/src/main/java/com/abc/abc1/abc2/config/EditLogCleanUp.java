package com.dbs.genesis.portfolio.config;

import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.DataValues;
import com.dbs.genesis.portfolio.repository.EditLogRepo;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.sql.Timestamp;
import java.util.Calendar;

@Configuration
@EnableScheduling
@Slf4j
public class EditLogCleanUp {

    @Autowired
    EditLogRepo editLogRepo;

    @Autowired
    DataSummaryService dataSummaryService;

    @Scheduled(fixedDelay = 900000,initialDelay = 60000)
    public void deleteEditLog() {

        int timeOutMins = 0;
        DataValues dataValues = dataSummaryService.getDataValuesByValue(PortfolioConstants.REF_DATA_EDIT_TIME_OUT,PortfolioConstants.REF_DATA_SYSTEM_CONFIG);

        if(dataValues != null) {
            timeOutMins = Integer.parseInt(dataValues.getDesc());
            log.info("Configured EDIT Log Timeout mins:"+timeOutMins);
        }else{
            timeOutMins = 60;
            log.info("Default Edit Log Timeout mins:"+timeOutMins);
        }

        long currentTimeMillis = System.currentTimeMillis();
        Timestamp original = new Timestamp(currentTimeMillis);
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(original.getTime());
        cal.add(Calendar.MINUTE, -1*timeOutMins);
        Timestamp before = new Timestamp(cal.getTime().getTime());

        log.info("Deleting Edit Log records created before:"+before);

        editLogRepo.deleteByDateModifiedBefore(before);

    }
}
