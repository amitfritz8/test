package com.dbs.genesis.portfolio.model;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Data
@Table(name = "sequence_generator")
@Entity
@EntityListeners(AuditingEntityListener.class)
public class SequenceGeneratorEntity extends CommonEntity<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seq_surr_id")
    private int seqSurrId;

    @Column(name = "id_type")
    private String portFolioIdType;

    @Column(name = "key1")
    private String key1;

    @Column(name = "key2")
    private String key2;

    @Column(name = "key3")
    private String key3;

    @Column(name = "key4")
    private String key4;

    @Column(name = "key5")
    private String key5;


    @Column(name = "max_counter")
    private int maxCounter;

    @Column(name = "generated_id")
    private String generatedId;


}
