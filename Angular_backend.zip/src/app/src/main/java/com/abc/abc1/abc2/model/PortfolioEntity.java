package com.dbs.genesis.portfolio.model;

import com.dbs.genesis.portfolio.resources.StageWorkdayData;
import lombok.Data;
import lombok.ToString;
import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigInteger;


@SqlResultSetMappings(
        {
                @SqlResultSetMapping(name = "mapWorkDayLatestData",
                        classes = {
                                @ConstructorResult(targetClass = StageWorkdayData.class,
                                        columns = {
                                                @ColumnResult(name = "staffName"),
                                                @ColumnResult(name = "emailAddress"),
                                        })
                        })

        })
@NamedNativeQueries({
        @NamedNativeQuery(name = "getWorkDayLatestData",
                query = "(select  distinct trim(email_address) as emailAddress, trim(staff_name) as staffName from employee where staff_type not in ('DBS','SEED') and (email_address is not null or email_address != '') and staff_status = 'Active' GROUP BY emailAddress)" +
                        "UNION\n" +
                        "(select distinct trim(email_address) as emailAddress, trim(staff_name) as staffName from stg_workday where staff_type in ('Employee','SEED') and  (email_address is not null or email_address != ''))",
                resultSetMapping = "mapWorkDayLatestData"),
        @NamedNativeQuery(name = "getStaffNameAndEmail",
                query = "(select  distinct trim(email_address) as emailAddress, trim(staff_name) as staffName from employee where  `1bank_id`=:userId ORDER BY rpt_period desc)\n" +
                        "  UNION\n" +
                        "(select distinct trim(email_address) as emailAddress, trim(staff_name) as staffName from stg_workday where 1bank_id = :userId ) limit 1",
                resultSetMapping = "mapWorkDayLatestData")

})
@NamedStoredProcedureQuery(name = "portfolioSequence",
        procedureName = "sp_portfolio_sequence",
        parameters = {
                @StoredProcedureParameter(mode = ParameterMode.OUT, name = "outmaxid", type = BigInteger.class)
        })

@Data
@Entity
@Table(name = "portfolio_profile")
@EntityListeners(AuditingEntityListener.class)
@ToString
@Audited(withModifiedFlag = true)
public class PortfolioEntity extends CommonEntity<String> {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "port_surr_id")
    private int portSurrId;
    @Column(name = "portfolio_id")
    @Audited(withModifiedFlag = true, modifiedColumnName = "portfolio_id_MOD")
    private String portfolioId;
    @Column(name = "portfolio_name")
    @Audited(withModifiedFlag = true, modifiedColumnName = "portfolio_name_MOD")
    private String portfolioName;
    @Column(name = "portfolio_desc")
    @Audited(withModifiedFlag = true, modifiedColumnName = "portfolio_desc_MOD")
    private String portfolioDesc;
    @Column(name = "initiation_year")
    @Audited(withModifiedFlag = true, modifiedColumnName = "initiation_year_MOD")
    private String initiationYear;
    @Column(name = "work_type")
    @Audited(withModifiedFlag = true, modifiedColumnName = "work_type_MOD")
    private String workType;
    @Column(name = "primary_platform_index")
    @Audited(withModifiedFlag = true, modifiedColumnName = "primary_platform_index_MOD")
    private String primaryPlatformIndex;
    @Column(name = "primary_platform_name")
    @Audited(withModifiedFlag = true, modifiedColumnName = "primary_platform_name_MOD")
    private String primaryPlatformName;
    @Column(name = "platform_name")
    @Audited(withModifiedFlag = true, modifiedColumnName = "platform_name_MOD")
    private String platformName;
    @Column(name = "requestor_1bank_id")
    @Audited(withModifiedFlag = true, modifiedColumnName = "requestor_1bank_id_MOD")
    private String requestor1bankId;
    @Column(name = "requestor_name")
    @Audited(withModifiedFlag = true, modifiedColumnName = "requestor_name_MOD")
    private String requestorName;
    @Column(name = "portfolio_reference_id")
    @Audited(withModifiedFlag = true, modifiedColumnName = "portfolio_reference_id_MOD")
    private String portfolioRefId;
    @Column(name = "budget_status")
    @Audited(withModifiedFlag = true, modifiedColumnName = "budget_status_MOD")
    private String budgetStatus;
    @Column(name = "budget_system_owner")
    @Audited(withModifiedFlag = true, modifiedColumnName = "budget_system_owner_MOD")
    private String budgetSystemOwner;
    @Column(name = "planning_cycle")
    @Audited(withModifiedFlag = true, modifiedColumnName = "planning_cycle_MOD")
    private String planningCycle;
    @Column(name = "thematic")
    @Audited(withModifiedFlag = true, modifiedColumnName = "thematic_MOD")
    private String thematic;
    @Column(name = "horizon")
    @Audited(withModifiedFlag = true, modifiedColumnName = "horizon_MOD")
    private String horizon;
    @Column(name = "biz_segment")
    @Audited(withModifiedFlag = true, modifiedColumnName = "biz_segment_MOD")
    private String bizSegment;

    @Column(name = "agile_waterfall")
    @Audited(withModifiedFlag = true, modifiedColumnName = "agile_waterfall_MOD")
    private String agileWaterFall;

    @Column(name = "reporting_flag")
    @Audited(withModifiedFlag = true, modifiedColumnName = "reporting_flag_MOD")
    private String reportingFlag;

    @Transient
    private String editable;

    @Transient
    private String staffName;


}
