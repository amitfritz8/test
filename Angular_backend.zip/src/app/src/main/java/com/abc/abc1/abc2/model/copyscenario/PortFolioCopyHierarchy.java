package com.dbs.genesis.portfolio.model.copyscenario;

import lombok.Data;

import java.util.List;

@Data
public class PortFolioCopyHierarchy {
    private String portFolioId;
    private List<WorkStreamCopyHierarchy> workStreamCopyHierarchies;
}
