package com.dbs.genesis.portfolio.service.financials;

import com.dbs.genesis.portfolio.common.CombineTwoArrayValues;
import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.repository.SubWorkstreamHardwareCostRepo;
import com.dbs.genesis.portfolio.resources.FinancialSummaryResource;
import com.dbs.genesis.portfolio.resources.UnitCostMappingView;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.resources.UnitCostResource;
import com.google.common.collect.Lists;
import io.vavr.Tuple2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class BreakDownCostHardwareService implements CombineTwoArrayValues {

    private final SubWorkstreamHardwareCostRepo subWorkstreamHardwareCostRepo;
    private final BreakDownCostOthersService breakDownCostOthersService;
    private final PortfolioRepository portfolioRepository;


    @Autowired
    public BreakDownCostHardwareService(SubWorkstreamHardwareCostRepo subWorkstreamHardwareCostRepo,BreakDownCostOthersService breakDownCostOthersService,
                                        PortfolioRepository portfolioRepository) {
        this.subWorkstreamHardwareCostRepo = subWorkstreamHardwareCostRepo;
        this.breakDownCostOthersService = breakDownCostOthersService;
        this.portfolioRepository = portfolioRepository;
    }

    public List<BigDecimal> getListOfMonthlyValuesByHardwareTotal(String subWorkStreamId, String subWorkStreamName,
                                                                   String period,String scenario,String currencyCode,String costType) {
        List<FinancialSummaryResource> consolidatedFinancialSummary =
                PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, period,
                                scenario,"financialHardwareHeaderSummaryByPeriodAndGroupCcy",costType)
                        : portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, period,
                        scenario,"financialHardwareHeaderSummaryByPeriodAndLocalCcy",costType);

        BigDecimal[] hardwareMonthlyValues = new BigDecimal[12];
        Arrays.fill(hardwareMonthlyValues, BigDecimal.ZERO);

        for (FinancialSummaryResource summaryResource : consolidatedFinancialSummary) {
            String reportingMonth = summaryResource.getPeriod().substring(4, 6);
            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                hardwareMonthlyValues[Integer.parseInt(reportingMonth) - 1] = summaryResource.getCurrencyValue();
            }
        }
        BigDecimal[] othersHardwareByMonthly = breakDownCostOthersService.getOthersSummaryByMonthly(subWorkStreamId,subWorkStreamName,period,scenario,PortfolioConstants.HARDWARE_TYPE, currencyCode);
        BigDecimal[] combineMonthlyValues = getCombineMonthlyValues(hardwareMonthlyValues, othersHardwareByMonthly);
        return Arrays.asList(combineMonthlyValues);
    }

    public Tuple2<BigDecimal,BigDecimal> getCostTypeOverAllTotal(String subWorkStreamId, String subWorkStreamName,String scenario, String currencyCode) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        List<SubWorkstreamHardwareCost> subWorkStreamNameAndScenario =
                subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotIn(
                        subWorkStreamId, subWorkStreamName, scenario,PortfolioConstants.TRUE,PortfolioConstants.FALSE,glCategories);
        BigDecimal costOverAllTotal = BigDecimal.ZERO;
        BigDecimal unitOverAllTotal = BigDecimal.ZERO;
        for (SubWorkstreamHardwareCost subWorkstreamHardwareCost : subWorkStreamNameAndScenario) {
            costOverAllTotal = costOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamHardwareCost.getCostPerMonthGcy():subWorkstreamHardwareCost.getCostPerMonthLcy());
            unitOverAllTotal = unitOverAllTotal.add(subWorkstreamHardwareCost.getQuantity());
        }
        return new Tuple2<>(costOverAllTotal,unitOverAllTotal);
    }


    //monthly
    public List<UnitCostMappingView> getHardwareUnitCostMapByMonthly(String subWorkStreamId, String subWorkStreamName, String period,String scenario, String currencyCode) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        List<UnitCostMappingView> unitCostList = Lists.newArrayList();
        List<SubWorkstreamHardwareCost> subWorkstreamHardwareCostWithOrigIndTrue= subWorkstreamHardwareCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotIn(
                        subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE,PortfolioConstants.TRUE,glCategories );

        Map<String, Map<String, List<SubWorkstreamHardwareCost>>> hardwareMapByTowerAndPeriod = getSubWorkStreamHardwareMap(subWorkStreamId, subWorkStreamName, period,scenario);

        hardwareMapByTowerAndPeriod.forEach((towerName, hardwareDriverDetailsMap) ->  hardwareDriverDetailsMap.forEach((driverName, subWorkStreamHardwareCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setRefSurrId(subWorkStreamHardwareCostList.get(0).getRefSwsHwSurrId());
            unitCostMappingView.setName(towerName +" - "+ driverName);
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setUnitPriceValue(subWorkStreamHardwareCostList.get(0).getItcRate().toString());
            unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
            populateUnitCostMappingForGivenTower(subWorkStreamHardwareCostList, unitCostMappingView,currencyCode);
            Tuple2<BigDecimal,BigDecimal> bigDecimalTuple2 = getUnitCostOverAllTotal(subWorkStreamId,subWorkStreamName,towerName,scenario,currencyCode);
            unitCostMappingView.setYearlyCostOverAllTotal(bigDecimalTuple2._1);
            unitCostMappingView.setYearlyUnitOverAllTotal(bigDecimalTuple2._2);
            unitCostList.add(unitCostMappingView);
        }));
        List<UnitCostMappingView> otherHardwareResource = breakDownCostOthersService.getOthersHardwareByMonthly(subWorkStreamId, subWorkStreamName, period,scenario,currencyCode);
        unitCostList.addAll(otherHardwareResource);
        return unitCostList;
    }

    UnitCostMappingView populateUnitCostMappingForGivenTower(
            List<SubWorkstreamHardwareCost> softwarePeriodList,
            UnitCostMappingView unitCostMappingView, String currencyCode) {

        List<UnitCostResource> costResourceList = Lists.newLinkedList();
        List<UnitCostResource> unitResourceList = Lists.newLinkedList();
        BigDecimal unitOverAllTotal = BigDecimal.ZERO;
        BigDecimal costOverAllTotal = BigDecimal.ZERO;

        for (SubWorkstreamHardwareCost subWorkStreamSoftwareCost : softwarePeriodList) {
            String reportingMonth = subWorkStreamSoftwareCost.getPeriod().substring(4, 6);
            UnitCostResource costResource = new UnitCostResource();
            BigDecimal costPerMonth = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkStreamSoftwareCost.getCostPerMonthGcy() : subWorkStreamSoftwareCost.getCostPerMonthLcy();
            BigDecimal quantity = subWorkStreamSoftwareCost.getQuantity();

            costResource.setSurrId(subWorkStreamSoftwareCost.getSwsHwSurrId());
            costResource.setMonthNumber(reportingMonth);
            costResource.setValue(costPerMonth);
            costResourceList.add(costResource);
            unitOverAllTotal = unitOverAllTotal.add(quantity);
            costOverAllTotal = costOverAllTotal.add(costPerMonth);

            UnitCostResource unitResource = new UnitCostResource();
            unitResource.setSurrId(subWorkStreamSoftwareCost.getSwsHwSurrId());
            unitResource.setMonthNumber(reportingMonth);
            unitResource.setValue(quantity);
            unitResource.setGlCategory(subWorkStreamSoftwareCost.getGlCategory());
            unitResourceList.add(unitResource);
        }
        costResourceList = costResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(costResourceList) : costResourceList;
        unitResourceList = unitResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(unitResourceList) : unitResourceList;

        unitCostMappingView.setMonthlyResourcesCosts(costResourceList);
        unitCostMappingView.setMonthlyResourcesUnits(unitResourceList);
        unitCostMappingView.setUnitOverAllTotal(unitOverAllTotal);
        unitCostMappingView.setCostOverAllTotal(costOverAllTotal);
        return unitCostMappingView;
    }

    private List<UnitCostResource> getUnitAndCostResourceMonthlyList( List<UnitCostResource> unitAndCostResourceList){
        List<UnitCostResource> unitAndcostResourceMonthlyList = Lists.newLinkedList();
        if(unitAndCostResourceList.size() < 12) {
            for (int i = 1; i <= 12; i++) {
                UnitCostResource costResource = new UnitCostResource();
                costResource.setSurrId(0);
                costResource.setMonthNumber(i <= 9 ? "0" + i : String.valueOf(i));
                costResource.setValue(BigDecimal.ZERO);
                unitAndcostResourceMonthlyList.add(costResource);
            }
            for (int i = 0; i < unitAndcostResourceMonthlyList.size() ; i++) {
                for (int j = 0; j < unitAndCostResourceList.size(); j++) {
                    if(unitAndcostResourceMonthlyList.get(i).getMonthNumber().equalsIgnoreCase(unitAndCostResourceList.get(j).getMonthNumber())){
                        unitAndcostResourceMonthlyList.set(i,unitAndCostResourceList.get(j));
                        break;
                    }
                }
            }
        }
        return unitAndcostResourceMonthlyList;
    }

    private Map<String, Map<String, List<SubWorkstreamHardwareCost>>> getSubWorkStreamHardwareMap(String subWorkStreamId,
                                                                                                  String subWorkStreamName,
                                                                                                  String period,String scenario) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        return subWorkstreamHardwareCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndPeriodContainingAndOriginalIndAndGlCategoryNotIn(
                            subWorkStreamId, subWorkStreamName, scenario, PortfolioConstants.TRUE, period,PortfolioConstants.FALSE, glCategories).
                    stream().collect(Collectors.groupingBy(SubWorkstreamHardwareCost::getTower, Collectors.groupingBy(
                    SubWorkstreamHardwareCost::getDriverDetail)));
    }

    private Tuple2<BigDecimal,BigDecimal> getUnitCostOverAllTotal(String subWorkStreamId, String subWorkStreamName, String towerName,String scenario, String currencyCode) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        List<SubWorkstreamHardwareCost> subWorkStreamHardwareCostList = subWorkstreamHardwareCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndTowerAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotIn(subWorkStreamId,
                        subWorkStreamName, towerName, scenario, PortfolioConstants.TRUE,PortfolioConstants.FALSE, glCategories);

        BigDecimal costOverAllTotal = BigDecimal.ZERO;
        BigDecimal unitOverAllTotal = BigDecimal.ZERO;
        for (SubWorkstreamHardwareCost subWorkstreamHardwareCost : subWorkStreamHardwareCostList) {
            costOverAllTotal = costOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamHardwareCost.getCostPerMonthGcy() : subWorkstreamHardwareCost.getCostPerMonthLcy());
            unitOverAllTotal = unitOverAllTotal.add(subWorkstreamHardwareCost.getQuantity());
        }
        return new Tuple2<>(costOverAllTotal,unitOverAllTotal);
    }

    //quarterly

    public Map<String, List<UnitCostMappingView>> getHardwareUnitCostMapQuarterly(String subWorkStreamId, String subWorkStreamName,String scenario, String currencyCode) {

        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        Map<String, List<UnitCostMappingView>> quarterlyUnitCostMapByPeriod = new TreeMap<>();
        List<String> distinctOfPeriods = subWorkstreamHardwareCostRepo.findDistinctOfYears(subWorkStreamId, subWorkStreamName, scenario, glCategories);
        for (String year : distinctOfPeriods) {
            Map<String, Map<String, List<SubWorkstreamHardwareCost>>> towerPeriodMap = getSubWorkStreamHardwareMap(subWorkStreamId, subWorkStreamName, year,scenario);
            List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
            towerPeriodMap.forEach((vendorName, hardwareDriverMap) -> hardwareDriverMap.forEach((driverName, subWorkStreamHardwareCostList) -> {
                UnitCostMappingView unitCostMappingView = getUnitCostMappingResourceByQuarterly(subWorkStreamHardwareCostList, subWorkStreamId, subWorkStreamName,scenario,currencyCode);
                unitCostMappingView.setName(vendorName+" - "+driverName);
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
                unitCostMappingView.setRefSurrId(subWorkStreamHardwareCostList.get(0).getCapexOpexSurrId());
                unitCostMappingViewArrayList.add(unitCostMappingView);
            }));
            unitCostMappingViewArrayList.addAll(breakDownCostOthersService.getOthersHardwareByQuarterly(subWorkStreamId,subWorkStreamName,year,scenario,currencyCode));
            quarterlyUnitCostMapByPeriod.put(year,unitCostMappingViewArrayList);
        }
        return quarterlyUnitCostMapByPeriod;
    }


    private UnitCostMappingView getUnitCostMappingResourceByQuarterly(List<SubWorkstreamHardwareCost> hardwarePeriodList, String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode) {
        UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
        unitCostMappingView.setPeriodType(PortfolioConstants.QUARTERLY);

        BigDecimal firstQuarterUnitTotal = BigDecimal.ZERO;
        BigDecimal secondQuarterUnitTotal = BigDecimal.ZERO;
        BigDecimal thirdQuarterUnitTotal = BigDecimal.ZERO;
        BigDecimal fourthQuarterUnitTotal = BigDecimal.ZERO;

        BigDecimal firstQuarterCostTotal = BigDecimal.ZERO;
        BigDecimal secondQuarterCostTotal = BigDecimal.ZERO;
        BigDecimal thirdQuarterCostTotal = BigDecimal.ZERO;
        BigDecimal fourthQuarterCostTotal = BigDecimal.ZERO;

        for (SubWorkstreamHardwareCost subWorkStreamHardwareCost : hardwarePeriodList) {
            String reportingMonth = subWorkStreamHardwareCost.getPeriod().substring(4, 6);
            if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                Tuple2<BigDecimal, BigDecimal> costUnitTotal = getCostUnitTotalForGivenReportingMonth(subWorkStreamHardwareCost,currencyCode);
                firstQuarterCostTotal = firstQuarterCostTotal.add(costUnitTotal._1);
                firstQuarterUnitTotal = firstQuarterUnitTotal.add(costUnitTotal._2);
            } else if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                Tuple2<BigDecimal, BigDecimal> costUnitTotal = getCostUnitTotalForGivenReportingMonth(subWorkStreamHardwareCost, currencyCode);
                secondQuarterCostTotal = secondQuarterCostTotal.add(costUnitTotal._1);
                secondQuarterUnitTotal = secondQuarterUnitTotal.add(costUnitTotal._2);
             } else if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                Tuple2<BigDecimal, BigDecimal> costUnitTotal = getCostUnitTotalForGivenReportingMonth(subWorkStreamHardwareCost, currencyCode);
                thirdQuarterCostTotal = thirdQuarterCostTotal.add(costUnitTotal._1);
                thirdQuarterUnitTotal = thirdQuarterUnitTotal.add(costUnitTotal._2);
             } else if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                Tuple2<BigDecimal, BigDecimal> costUnitTotal = getCostUnitTotalForGivenReportingMonth(subWorkStreamHardwareCost, currencyCode);
                fourthQuarterCostTotal = fourthQuarterCostTotal.add(costUnitTotal._1);
                fourthQuarterUnitTotal = fourthQuarterUnitTotal.add(costUnitTotal._2);
             }
        }
        unitCostMappingView.setQuarterlyCostTotal(Arrays.asList(firstQuarterCostTotal,secondQuarterCostTotal,thirdQuarterCostTotal,fourthQuarterCostTotal));
        unitCostMappingView.setQuarterlyUnitTotal(Arrays.asList(firstQuarterUnitTotal,secondQuarterUnitTotal,thirdQuarterUnitTotal,fourthQuarterUnitTotal));
        Tuple2<BigDecimal, BigDecimal> costTypeOverAllTotal = getCostTypeOverAllTotal(subWorkStreamId, subWorkStreamName,scenario,currencyCode);
        unitCostMappingView.setYearlyCostOverAllTotal(costTypeOverAllTotal._1);
        unitCostMappingView.setYearlyUnitOverAllTotal(costTypeOverAllTotal._2);
        return unitCostMappingView;
    }


    private Tuple2<BigDecimal,BigDecimal> getCostUnitTotalForGivenReportingMonth(SubWorkstreamHardwareCost hardwareCost, String currencyCode) {
        BigDecimal quarterTotalCost = new BigDecimal(BigInteger.ZERO);
        BigDecimal quarterTotalUnit = new BigDecimal(BigInteger.ZERO);

        quarterTotalUnit = quarterTotalUnit.add(hardwareCost.getQuantity());
        quarterTotalCost = quarterTotalCost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                hardwareCost.getCostPerMonthGcy():hardwareCost.getCostPerMonthLcy());

        return new Tuple2<>(quarterTotalCost, quarterTotalUnit);
    }


    public Map<String, List<BigDecimal>> getHardwareQuarterlyListMap(String subWorkStreamId, String subWorkStreamName,String scenario,
                                                                     String currencyCode,String costType) {
        Map<String, List<BigDecimal>> quarterlySum = new TreeMap<>();
        List<FinancialSummaryResource> distinctOfPeriods = portfolioRepository.getSubworkstreamCostTypeOverAllTotalByGroupCurrency(subWorkStreamId, subWorkStreamName, scenario,
                "getDistinctfinancialHardwareCostTypeOverAllTotal",PortfolioConstants.HARDWARE_TYPE);
        List<BigDecimal> quarterlySummaryList;
        for (FinancialSummaryResource financialSummaryResource  : distinctOfPeriods) {
            List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, financialSummaryResource.getPeriod(),
                                    scenario,"financialHardwareHeaderSummaryByPeriodAndGroupCcy",costType)
                            : portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName, financialSummaryResource.getPeriod(),
                            scenario,"financialHardwareHeaderSummaryByPeriodAndLocalCcy",costType);

            quarterlySummaryList = getQuarterlySummaryList(consolidatedFinancialSummary, financialSummaryResource.getPeriod(),subWorkStreamId,subWorkStreamName,scenario,currencyCode);
            quarterlySum.put(financialSummaryResource.getPeriod(), quarterlySummaryList);
        }
        return quarterlySum;
    }
    private List<BigDecimal> getQuarterlySummaryList(List<FinancialSummaryResource> consolidatedFinancialSummary,
                                                     String year, String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode) {
        BigDecimal bigDecimal = BigDecimal.ZERO;
        BigDecimal bigDecimal1 = BigDecimal.ZERO;
        BigDecimal bigDecimal2 = BigDecimal.ZERO;
        BigDecimal bigDecimal3 = BigDecimal.ZERO;
        for (FinancialSummaryResource subWorkStreamHardwareCost : consolidatedFinancialSummary) {
            if (year.equalsIgnoreCase(subWorkStreamHardwareCost.getPeriod().substring(0, 4))) {
                String reportingMonth = subWorkStreamHardwareCost.getPeriod().substring(4, 6);
                if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                    bigDecimal = getCurrencyValueForQuarterSummary(currencyCode, bigDecimal, subWorkStreamHardwareCost.getCurrencyValue());
                }
                if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                        bigDecimal1 = getCurrencyValueForQuarterSummary(currencyCode, bigDecimal1, subWorkStreamHardwareCost.getCurrencyValue());
                }
                if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                        bigDecimal2 = getCurrencyValueForQuarterSummary(currencyCode, bigDecimal2, subWorkStreamHardwareCost.getCurrencyValue());
                }
                if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                        bigDecimal3 = getCurrencyValueForQuarterSummary(currencyCode, bigDecimal3, subWorkStreamHardwareCost.getCurrencyValue());
                }
            }
        }
        List<BigDecimal> othersByQuarterlyTotalSum = breakDownCostOthersService.getOthersByQuarterlyTotalSum(subWorkStreamId,
                subWorkStreamName, scenario, PortfolioConstants.HARDWARE_TYPE, year,currencyCode);
        return Arrays.asList(bigDecimal.add(othersByQuarterlyTotalSum.get(0)), bigDecimal1.add(othersByQuarterlyTotalSum.get(1)), bigDecimal2.add(othersByQuarterlyTotalSum.get(2)),
                bigDecimal3.add(othersByQuarterlyTotalSum.get(3)));
    }

    private BigDecimal getCurrencyValueForQuarterSummary(String currencyCode, BigDecimal bigDecimal, BigDecimal grpCcyValue ) {
            if (grpCcyValue != null && grpCcyValue.intValue() != 0) {
                bigDecimal = bigDecimal.add(grpCcyValue);
            }
        return bigDecimal;
    }

    //yearly

    public Map<String, BigDecimal> getYearlyHardwareSummary(String subWorkStreamId, String subWorkStreamName,String scenario,String currencyCode,String costType) {
        Map<String, BigDecimal> totalYearSumMap = new TreeMap<>();
        List<FinancialSummaryResource> listOfYears = portfolioRepository.getSubworkstreamCostTypeOverAllTotalByGroupCurrency(subWorkStreamId, subWorkStreamName, scenario,
                "getDistinctfinancialHardwareCostTypeOverAllTotal",PortfolioConstants.HARDWARE_TYPE);
        for (FinancialSummaryResource financialSummaryResource : listOfYears) {
            BigDecimal totalYearSum = BigDecimal.ZERO;
            List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndGroupCurrency(subWorkStreamId, subWorkStreamName, financialSummaryResource.getPeriod(),
                                    scenario,"financialHardwareHeaderSummaryByPeriodAndGroupCcy",costType)
                            : portfolioRepository.getSubworkstreamIndividualHeaderRowByPeriodAndLocalCurrency(subWorkStreamId, subWorkStreamName,
                            financialSummaryResource.getPeriod(), scenario,"financialHardwareHeaderSummaryByPeriodAndLocalCcy",costType);

            for (FinancialSummaryResource subWorkStreamSoftwareCost : consolidatedFinancialSummary) {
                totalYearSum = totalYearSum.add(subWorkStreamSoftwareCost.getCurrencyValue());
            }
            BigDecimal othersByYearlySummary = breakDownCostOthersService.getOthersByYearlySum(subWorkStreamId, subWorkStreamName, scenario, financialSummaryResource.getPeriod(), PortfolioConstants.HARDWARE_TYPE, currencyCode);
            totalYearSumMap.put(financialSummaryResource.getPeriod(), totalYearSum.add(othersByYearlySummary));
        }
        return totalYearSumMap;
    }

    public Map<String, List<UnitCostMappingView>> getYearlyHardwareData(String subWorkStreamId,
                                                                                     String subWorkStreamName,String scenario,String currencyCode) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        Map<String, List<UnitCostMappingView>> yearlyCostUnitResource = new TreeMap<>();
        List<String> listOfYears = subWorkstreamHardwareCostRepo.findDistinctOfYears(subWorkStreamId,
                subWorkStreamName,scenario, glCategories);
        for (String year : listOfYears) {
            Map<String, Map<String, List<SubWorkstreamHardwareCost>>> towerAndDriverDetailsMap =
                    getSubWorkStreamHardwareMap(subWorkStreamId, subWorkStreamName, year,scenario);
            List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
            towerAndDriverDetailsMap.forEach((towerName, hardwareDriverDetailsMap) -> hardwareDriverDetailsMap.forEach((driverName, subWorkStreamHardwareCostList) -> {
                UnitCostMappingView unitCostMappingView = getUnitCostMappingResourceByYearly(subWorkStreamHardwareCostList,currencyCode);
                unitCostMappingView.setName(towerName+" - "+driverName);
                unitCostMappingView.setRefSurrId(subWorkStreamHardwareCostList.get(0).getCapexOpexSurrId());
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
                unitCostMappingView.setYearlyCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamHardwareCostRepo.getTotalHardwareCostByTypeAndGrpCcy(subWorkStreamId,subWorkStreamName, scenario,towerName, glCategories)
                        : subWorkstreamHardwareCostRepo.getTotalHardwareCostByTypeAndLocalCcy(subWorkStreamId,subWorkStreamName, scenario,towerName, glCategories));
                unitCostMappingViewArrayList.add(unitCostMappingView);
            }));
            unitCostMappingViewArrayList.addAll(breakDownCostOthersService.getOthersHardwareByYearly(subWorkStreamId,subWorkStreamName,year,scenario,currencyCode));
            yearlyCostUnitResource.put(year, unitCostMappingViewArrayList);
        }
        return yearlyCostUnitResource;
    }

    private UnitCostMappingView getUnitCostMappingResourceByYearly(List<SubWorkstreamHardwareCost> subWorkstreamHardwareCostList, String currencyCode) {

        UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
        BigDecimal unitTotal = BigDecimal.ZERO;
        BigDecimal costTotal = BigDecimal.ZERO;

        for (SubWorkstreamHardwareCost subWorkstreamHardwareCost : subWorkstreamHardwareCostList) {
            unitTotal = unitTotal.add(subWorkstreamHardwareCost.getQuantity());
            costTotal = costTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamHardwareCost.getCostPerMonthGcy():subWorkstreamHardwareCost.getCostPerMonthLcy());
        }
        unitCostMappingView.addYearlyUnitTotal(unitTotal);
        unitCostMappingView.addYearlyCostTotal(costTotal);

        return unitCostMappingView;
    }

}
