package com.dbs.genesis.portfolio.model;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@Entity
@Table(name = "employee_rate_card")
@EntityListeners(AuditingEntityListener.class)
public class EmployeeRateCardEntity extends CommonEntity<String>{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "rate_card_surr_id")
    private int rateCardSurrId;

    @Column(name = "rate_card_code")
    private String rateCardCode;

    @Column(name = "country_code")
    private String countryCode;

    @Column(name = "staff_type_gene")
    private String staffTypeGene;

    @Column(name = "vendor_code")
    private String vendorCode;

    @Column(name = "rate_source")
    private String rateSource;

    @Column(name = "rate_card_ref")
    private String rateCardRef;

    @Column(name = "ccy_code")
    private String ccyCode;

    @Column(name = "rate_ind")
    private String rateInd;

    @Column(name = "rate_level")
    private String rateLevel;

    @Column(name = "staff_rate")
    private BigDecimal staffRate;

    @Column(name = "effective_start_date")
    private Timestamp effectiveStartDate;

    @Column(name = "effective_end_date")
    private Timestamp effectiveEndDate;

    @Column(name = "staff_rank")
    private String staffRank;

    @Column(name = "staff_exp")
    private String staffExp;

}
