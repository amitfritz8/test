package com.dbs.genesis.portfolio.enums;

public enum ScenarioConfigType {

    COPY_TO_PORTFOLIO("Copy Scenario to Portfolio"),COPY_TO_WORKSTREAM("Copy Scenario to Workstream");

    private ScenarioConfigType(String scenarioConfigType){
        this.scenarioConfigType = scenarioConfigType;
    }
    private String scenarioConfigType;

    public String getScenarioConfigType(){
        return this.scenarioConfigType;
    }
}
