package com.dbs.genesis.portfolio.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Date;

@Data
@Entity
@Table(name = "sub_workstream_team_formation")
@EntityListeners(AuditingEntityListener.class)
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class SubWorkstreamTeamFormation extends CommonEntity<String>{
    @Id
    @Column(name = "dummy_team_surr_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer dummyTeamSurrId;
    @Column(name = "sub_workstream_id")
    private String subWorkStreamId;
    @Column(name = "sub_workstream_name")
    private String subWorkstreamName;
    @Column(name = "team_name")
    private String teamName;
    @Column(name = "team_code")
    private String teamCode;
    @Column(name = "team_role")
    private String teamRole;
    @Column(name = "allocation_pct")
    private String allocationPct;
    @Column(name = "vendor_name")
    private String vendorName;
    @Column(name = "skill_level")
    private String skillLevel;
    @Column(name = "rate_source")
    private String rateSource;
    @Column(name = "ic_ind")
    private String icInd;
    @Column(name = "blended_cost")
    private String blendedCost;
    @Column(name = "scenario")
    private String scenario;
    @Column(name = "effective_start_date")
    private Date effectiveStartDate;
    @Column(name = "effective_end_date")
    private Date effectiveEndDate;

}
