package com.dbs.genesis.portfolio.event;

import com.dbs.genesis.portfolio.client.WorkStreamOCLAClient;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.DataValues;
import com.dbs.genesis.portfolio.model.WorkStreamEntity;
import com.dbs.genesis.portfolio.model.WorkstreamOclaw;
import com.dbs.genesis.portfolio.repository.PortfolioManagersRepo;
import com.dbs.genesis.portfolio.repository.WorkStreamManagersRepo;
import com.dbs.genesis.portfolio.repository.WorkstreamOclawRepo;
import com.dbs.genesis.portfolio.resources.FinSysProjectIdCreationEvent;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
@Slf4j
public class FinSysProjectIdCreationEventAsyncListener {

    @Autowired
    DataSummaryService dataSummaryService;

    @Autowired
    PortfolioManagersRepo portfolioManagersRepo;

    @Autowired
    WorkStreamManagersRepo workStreamManagersRepo;

    @Autowired
    WorkstreamOclawRepo workstreamOclawRepo;

    @Autowired
    WorkStreamOCLAClient workStreamOCLAClient;

    @Async
    @EventListener
    void handleAsyncEvent(FinSysProjectIdCreationEvent event) {
        log.info("Received Async event: " + event);
        log.info("WorksTream name: " + event.getWorkStreamEntity().getWorkStreamName() + " Workstream Id : " + event.getWorkStreamEntity().getWorkStreamId());

        pushNotificationToOCLAW(event);
    }

    void pushNotificationToOCLAW(FinSysProjectIdCreationEvent finSysProjectIdCreationEvent) {
        log.info("Project id : " + finSysProjectIdCreationEvent.getWorkStreamEntity().getWorkStreamId().substring(finSysProjectIdCreationEvent.getWorkStreamEntity().getWorkStreamId().length() - 11));
        WorkstreamOclaw workstreamOclaw = new WorkstreamOclaw();

        WorkStreamEntity workStreamEntity = finSysProjectIdCreationEvent.getWorkStreamEntity();
        /*String projectId = getCountryDescription(workStreamEntity.getCountry())
                + workStreamEntity.getWorkStreamId().substring(workStreamEntity.getWorkStreamId().length() - 12);
        workstreamOclaw.setProjectId(projectId);

        workstreamOclaw.setRegion(workStreamEntity.getCountry());

        workstreamOclaw.setCountryCode(getCountryDescription(workStreamEntity.getCountry()));*/
        String countryCode = getCountryDescription(workStreamEntity.getCountry());
        if (countryCode.equalsIgnoreCase("REG")) {
            workstreamOclaw.setProjectId(countryCode + workStreamEntity.getWorkStreamId().substring(workStreamEntity.getWorkStreamId().length() - 12));
            workstreamOclaw.setRegion("Singapore");
            workstreamOclaw.setCountryCode("SG");
        } else if (countryCode.equalsIgnoreCase("dah2")) {
            workstreamOclaw.setProjectId("DA2" + workStreamEntity.getWorkStreamId().substring(workStreamEntity.getWorkStreamId().length() - 12));
            workstreamOclaw.setRegion("India");
            workstreamOclaw.setCountryCode("IN");
        } else {
            workstreamOclaw.setProjectId(countryCode + workStreamEntity.getWorkStreamId().substring(workStreamEntity.getWorkStreamId().length() - 12));
            workstreamOclaw.setRegion(workStreamEntity.getCountry());
            workstreamOclaw.setCountryCode(getCountryDescription(workStreamEntity.getCountry()));
        }

        String todayDate = new SimpleDateFormat("MM-dd-yyyy").format(new Date());

        workstreamOclaw.setEffectiveDate(todayDate);
        workstreamOclaw.setStartDate(todayDate);
        workstreamOclaw.setEndDate(todayDate);
        workstreamOclaw.setProjectDescription(workStreamEntity.getWorkStreamName());

        List<String> workManagers = new ArrayList<>();
        workManagers.add(finSysProjectIdCreationEvent.getLoggedInUserBankid());

        List<String> portfolioManageres = portfolioManagersRepo.getAllDistinctPortfolioManagers(workStreamEntity.getPortfolioId());
        portfolioManageres.addAll(workStreamManagersRepo.getAllDistinctWorkStreamManagersBasedOnPortfolio(workStreamEntity.getPortfolioId()));
        portfolioManageres.forEach(portfolioManager -> {
            if (!workManagers.contains(portfolioManager)) {
                workManagers.add(portfolioManager);
            }
        });
        StringBuilder managers = new StringBuilder("");
        for (String work : workManagers) {
            if (!Strings.isEmpty(managers)) {
                managers.append(";");
            }
            managers.append(work);
        }
        workstreamOclaw.setProjectManagers(managers.toString());

        workstreamOclaw.setOperation("create");
        workstreamOclaw.setReason("New project");

        workstreamOclawRepo.save(workstreamOclaw);

        log.info("Saving OCLAW Response object to Database");

        ResponseEntity<Object> res = workStreamOCLAClient.postOclawData(workstreamOclaw);

        log.info("Pushed Notification to OCLAW : " + res.getStatusCode());

    }


    private String getCountryDescription(@NotNull String countryValue) {
        DataValues dataValuesByValue = dataSummaryService.getDataValuesByValue(countryValue, PortfolioConstants.country);
        return dataValuesByValue.getDesc();
    }
}
