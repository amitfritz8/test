package com.dbs.genesis.portfolio.service.financials;

import com.dbs.genesis.portfolio.common.DateExtensions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.DataValues;
import com.dbs.genesis.portfolio.model.SubWorkStreamKeyDatesEntity;
import com.dbs.genesis.portfolio.model.SubWorkstreamFinDetailsEntity;
import com.dbs.genesis.portfolio.model.WorkStreamEntity;
import com.dbs.genesis.portfolio.repository.*;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import com.dbs.genesis.portfolio.service.costsettings.FinancialDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;


@Service
public class FinancialService implements DateExtensions {

    public static final String FINANCIAL_SUMMARY = "FINANCIAL SUMMARY";
    private final DataSummaryService dataSummaryService;
    private final SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo;
    private final PortfolioRepository portfolioRepository;
    private final FinancialDetailsService financialDetailsService;
    private final WorkStreamRepo workStreamRepo;
    private final SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    private final SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo;
    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    public FinancialService(DataSummaryService dataSummaryService,
                            SubWorkstreamFinDetailsRepo subWorkstreamFinDetailsRepo,
                            PortfolioRepository portfolioRepository,
                            FinancialDetailsService financialDetailsService,
                            WorkStreamRepo workStreamRepo,
                            SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo,
                            SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo) {
        this.dataSummaryService = dataSummaryService;
        this.subWorkstreamFinDetailsRepo = subWorkstreamFinDetailsRepo;
        this.portfolioRepository = portfolioRepository;
        this.financialDetailsService = financialDetailsService;
        this.workStreamRepo = workStreamRepo;
        this.subWorkStreamKeyDatesRepo = subWorkStreamKeyDatesRepo;
        this.subWorkstreamOtherCostRepo = subWorkstreamOtherCostRepo;
    }

    public Map getFinancialDataByScenario(String scenario, String currencyCode, String workStreamId, String
            subWorkStreamId, String subWorkStreamName, String period, String typeOfData) {
        List<DataValues> glCategoryValues = getGlCategoryValues();
        LinkedHashSet<String> glGroups = getUniqueGlGroups(glCategoryValues);
        FinanceSummaryView financeSummaryView = new FinanceSummaryView();
        financeSummaryView.setName(FINANCIAL_SUMMARY);
        financeSummaryView.setGlGroups(getGlGroupsWithCategoriesMap(glGroups, glCategoryValues, workStreamId,
                subWorkStreamId, subWorkStreamName, scenario, period, typeOfData, currencyCode));
        Map<String, Object> map = new TreeMap<>();
        map.put(scenario, financeSummaryView);
        return map;
    }

    public LinkedHashSet<String> getUniqueGlGroups(List<DataValues> glCategoryValues) {
        LinkedHashSet<String> glGroups = new LinkedHashSet<>();
        glCategoryValues.forEach(categoryValue -> {
            String[] categoryArray = categoryValue.getDesc().split(",");
            glGroups.addAll(Arrays.asList(categoryArray));
        });
        return glGroups;
    }


    List<GlGroup> getGlGroupsWithCategoriesMap(LinkedHashSet<String> glGroups, List<DataValues> glCategoryValues,
                                               String workStreamId, String subWorkStreamId, String subWorkStreamName,
                                               String scenario, String period, String typeOfData, String currencyCode) {
        List<GlGroup> glGroups1 = new ArrayList<>();
        glGroups.forEach(glGrp -> {
            GlGroup glGroup = new GlGroup();
            LinkedHashSet<String> glCategorySet = new LinkedHashSet<>();
            glCategoryValues.forEach(glCategoryValue -> {
                if (glCategoryValue.getDesc().contains(glGrp)) {
                    glCategorySet.add(glCategoryValue.getValue());
                }
            });
            List<GlCategory> glCategories = new ArrayList<>();

            if (PortfolioConstants.MONTHLY.equalsIgnoreCase(typeOfData)) {
                glCategorySet.forEach(glCategory -> glCategories.add(getDefaultGlCategory(glCategory,
                        subWorkStreamId, subWorkStreamName, scenario, period, currencyCode, getConditionalGlCategories())));
                List<FinancialSummaryResource> financialSummaryResourceList = getSubWorkStreamGlCategoryValues(
                        glCategorySet, subWorkStreamId, subWorkStreamName, scenario, period, currencyCode,getConditionalGlCategories());

                List<BigDecimal> monthlyGlGroupLevel = getMonthlyGlGroupLevel(financialSummaryResourceList);
                glGroup.setMonthlyFinanceTotal(monthlyGlGroupLevel);
                glGroup.setTotalSum(monthlyGlGroupLevel.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));

                BigDecimal glCategoryTotalSum = getGlCategoryTotalSum(scenario, subWorkStreamId,
                        subWorkStreamName, glCategorySet, currencyCode,getConditionalGlCategories());
                glGroup.setOverAllSum(glCategoryTotalSum);

            }

            List<String> financialYearsByScenario = getFinancialYearsByScenario(workStreamId, subWorkStreamId,
                    scenario, subWorkStreamName);

            if (PortfolioConstants.QUARTERLY.equalsIgnoreCase(typeOfData)) {
                Map<String, List<BigDecimal>> quarterlySummaryMap = new HashMap<>();
                Map<String, BigDecimal> individualYearSummaryForQuarterlyData = new HashMap<>();

                List<List<BigDecimal>> consolidatedQuarterlyOverAllSum = new ArrayList<>();
                BigDecimal totalOverAllQuarterlySum = BigDecimal.ZERO;
                List<BigDecimal> quarterlySummaryList = null;
                for (String year : financialYearsByScenario) {
                    List<FinancialSummaryResource> financialSummaryResourceList = getSubWorkStreamGlCategoryValues(
                            glCategorySet, subWorkStreamId, subWorkStreamName, scenario, year, currencyCode,getConditionalGlCategories());
                    quarterlySummaryList = getQuarterlySummaryListData(financialSummaryResourceList);
                    quarterlySummaryMap.put(year, quarterlySummaryList);
                    consolidatedQuarterlyOverAllSum.add(quarterlySummaryList);
                }
                glCategorySet.forEach(glCategory -> {
                    glCategories.add(getGlCategoryQuarterly(glCategory, workStreamId, subWorkStreamId, subWorkStreamName,
                            scenario, currencyCode));
                });

                glGroup.setQuarterlySummary(quarterlySummaryMap);
                quarterlySummaryMap.forEach((year, bigDecimals) -> {
                    individualYearSummaryForQuarterlyData.put(year, bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                });
                glGroup.setIndividualYearSummaryForQuarterly(individualYearSummaryForQuarterlyData);
                if (quarterlySummaryList != null && !quarterlySummaryList.isEmpty()) {
                    for (List<BigDecimal> list : consolidatedQuarterlyOverAllSum) {
                        totalOverAllQuarterlySum = totalOverAllQuarterlySum.add(list.stream().reduce(BigDecimal::add)
                                .orElse(BigDecimal.ZERO));
                    }
                    glGroup.setOverAllSum(totalOverAllQuarterlySum);
                }
            }
            if (PortfolioConstants.YEARLY.equalsIgnoreCase(typeOfData)) {

                Map<String, BigDecimal> yearlyFinSummary = new HashMap<>();
                BigDecimal completeTotalYearsAmount = BigDecimal.ZERO;
                List<BigDecimal> yearlySumList = new ArrayList<>();

                for (String year : financialYearsByScenario) {
                    BigDecimal yearlyFinSummarySum = BigDecimal.ZERO;
                    List<FinancialSummaryResource> yearlySummaryData = getSubWorkStreamGlCategoryValues(
                            glCategorySet, subWorkStreamId, subWorkStreamName, scenario, year, currencyCode,getConditionalGlCategories());
                    for (FinancialSummaryResource financialSummaryResource : yearlySummaryData) {
                        yearlyFinSummarySum = yearlyFinSummarySum.add(financialSummaryResource.getCurrencyValue());
                    }
                    yearlySumList.add(yearlyFinSummarySum);
                    yearlyFinSummary.put(year, yearlyFinSummarySum);
                }
                completeTotalYearsAmount = completeTotalYearsAmount.add(yearlySumList.stream().reduce(BigDecimal::add)
                        .orElse(BigDecimal.ZERO));
                glGroup.setYearlySummary(yearlyFinSummary);
                glGroup.setOverAllSum(completeTotalYearsAmount);
                glCategorySet.forEach(glCategory -> glCategories.add(getGlCategoryByYearly(glCategory, workStreamId, subWorkStreamId, subWorkStreamName,
                        scenario, currencyCode)));
            }

            glGroup.setName(glGrp);
            glGroup.setGlCategories(glCategories);
            glGroups1.add(glGroup);
        });
        return glGroups1;
    }

    public Set<String> getConditionalGlCategories() {
        Set<String> conditionalGlCategories = new HashSet<>();
        conditionalGlCategories.add(PortfolioConstants.DEFAULT_SEED_FUNDING_CATEGORY);
        return conditionalGlCategories;
    }

    public List<BigDecimal> getMonthlyGlGroupLevel(List<FinancialSummaryResource> financialSummaryResourceList) {

        BigDecimal[] defaultVales = new BigDecimal[12];
        Arrays.fill(defaultVales, BigDecimal.ZERO);
        for (FinancialSummaryResource summaryResource : financialSummaryResourceList) {
            String reportingMonth = summaryResource.getPeriod().substring(4, 6);
            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                defaultVales[Integer.parseInt(reportingMonth) - 1] = defaultVales[Integer.parseInt(reportingMonth) - 1].add(summaryResource.getCurrencyValue());
            }
        }
        return Arrays.asList(defaultVales);

    }

    private GlCategory getGlCategoryByYearly(String category, String workStreamId, String subWorkStreamId,
                                             String subWorkStreamName, String scenario, String currencyCode) {

        Map<String, BigDecimal> yearlyFinanceSummary = new HashMap<>();

        List<BigDecimal> overAllTotal = new ArrayList<>();
        BigDecimal overAllYearsTotal = BigDecimal.ZERO;
        List<String> financialYearsByScenario = getFinancialYearsByScenario(workStreamId, subWorkStreamId,
                scenario, subWorkStreamName);

        Set<String> glCategories = new HashSet<>();
        glCategories.add(category);
        for (String year : financialYearsByScenario) {
            BigDecimal calculateTotalAmount = BigDecimal.ZERO;
            List<BigDecimal> bigDecimalList = new ArrayList<>();
            List<FinancialSummaryResource> financialSummaryResources = getSubWorkStreamGlCategoryValues(glCategories, subWorkStreamId, subWorkStreamName, scenario, year, currencyCode,getConditionalGlCategories());

           /* if (PortfolioConstants.OPEX.equalsIgnoreCase(category)) {
                List<FinancialSummaryResource> finSummaryResourceList = financialSummaryResources.stream().filter(
                        financialSummaryResource -> checkGoLiveEndDate(goLiveEndDate, financialSummaryResource.getPeriod())).map(financialSummaryResource -> {
                    FinancialSummaryResource financialSummaryResource1 = new FinancialSummaryResource();
                    financialSummaryResource1.setCurrencyValue(financialSummaryResource.getCurrencyValue());
                    return financialSummaryResource1;
                }).collect(Collectors.toList());
                for (FinancialSummaryResource financialSummaryResource : finSummaryResourceList) {
                    bigDecimalList.add(financialSummaryResource.getCurrencyValue());
                }

            } else {
                for (FinancialSummaryResource financialSummaryResource : financialSummaryResources) {
                    bigDecimalList.add(financialSummaryResource.getCurrencyValue());
                }
            }*/

            for (FinancialSummaryResource financialSummaryResource : financialSummaryResources) {
                bigDecimalList.add(financialSummaryResource.getCurrencyValue());
            }


            if (!bigDecimalList.isEmpty()) {
                calculateTotalAmount = calculateTotalAmount.add(bigDecimalList.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
            }
            yearlyFinanceSummary.put(year, calculateTotalAmount);
            overAllTotal.add(calculateTotalAmount);
        }
        if (!overAllTotal.isEmpty()) {
            overAllYearsTotal = overAllYearsTotal.add(overAllTotal.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        }

        GlCategory glCategory = getDefaultGlCategory(category, new ArrayList<>(), new HashMap<>(), yearlyFinanceSummary,
                BigDecimal.ZERO, overAllYearsTotal);

        return glCategory;
    }

    public List<BigDecimal> getQuarterlySummaryListData(List<FinancialSummaryResource> financialSummaryResourceList) {
        BigDecimal bigDecimal = new BigDecimal(BigInteger.ZERO);
        BigDecimal bigDecimal1 = BigDecimal.ZERO;
        BigDecimal bigDecimal2 = BigDecimal.ZERO;
        BigDecimal bigDecimal3 = BigDecimal.ZERO;

        for (FinancialSummaryResource summaryResource : financialSummaryResourceList) {
            String reportingMonth = summaryResource.getPeriod().substring(4, 6);
            if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                bigDecimal = bigDecimal.add(summaryResource.getCurrencyValue());
            }
            if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                bigDecimal1 = bigDecimal1.add(summaryResource.getCurrencyValue());
            }
            if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                bigDecimal2 = bigDecimal2.add(summaryResource.getCurrencyValue());
            }
            if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                bigDecimal3 = bigDecimal3.add(summaryResource.getCurrencyValue());
            }
        }
        return Arrays.asList(bigDecimal, bigDecimal1, bigDecimal2, bigDecimal3);
    }

    private BigDecimal getGlCategoryTotalSum(String scenario, String subWorkStreamId, String
            subWorkStreamName, Set<String> glCategorySet, String currencyCode,Set<String> conditionalGlCategories) {
        List<FinancialSummaryResource> financialSummaryResources = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                portfolioRepository.getCostForFinancialCaseSummryValueByGroupCcy(subWorkStreamId, subWorkStreamName, scenario, glCategorySet, conditionalGlCategories)
                : portfolioRepository.getCostForFinancialCaseSummryValueByLocalCcy(subWorkStreamId, subWorkStreamName, scenario, glCategorySet,conditionalGlCategories);
        BigDecimal totalSum = BigDecimal.ZERO;

        for (FinancialSummaryResource financialSummaryResource : financialSummaryResources) {
            totalSum = totalSum.add(financialSummaryResource.getCurrencyValue());
        }
        return totalSum;
    }


    GlCategory getDefaultGlCategory(String category,
                                    String subWorkStreamId,
                                    String subWorkStreamName,
                                    String scenario,
                                    String period,
                                    String currencyCode,Set<String> conditionalGlCategories) {
        BigDecimal overAllSum = BigDecimal.ZERO;
        Set<String> glCategories = new HashSet<>();
        glCategories.add(category);


        List<FinancialSummaryResource> financialSummaryResourcesList = getSubWorkStreamGlCategoryValues(glCategories,
                subWorkStreamId, subWorkStreamName, scenario, period, currencyCode,getConditionalGlCategories());

        List<BigDecimal> monthlyValues = getMonthlyDataFromResource(financialSummaryResourcesList);

        BigDecimal monthlySum = BigDecimal.ZERO;
        if (!monthlyValues.isEmpty()) {
            monthlySum = monthlyValues.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        }

        List<FinancialSummaryResource> financialSummaryResourceTotal = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                portfolioRepository.getCostForFinancialCaseSummryValueByGroupCcy(subWorkStreamId, subWorkStreamName, scenario, glCategories,conditionalGlCategories)
                : portfolioRepository.getCostForFinancialCaseSummryValueByLocalCcy(subWorkStreamId, subWorkStreamName, scenario, glCategories,conditionalGlCategories);
        for (FinancialSummaryResource financialSummaryResource : financialSummaryResourceTotal) {
            overAllSum = overAllSum.add(BigDecimal.valueOf(financialSummaryResource.getCurrencyValue().doubleValue()));
        }

        return getDefaultGlCategory(category, monthlyValues, new HashMap<>(), new HashMap<>(), monthlySum,
                overAllSum);
    }


    private List<FinancialSummaryResource> getSubWorkStreamGlCategoryValues(Set<String> glCategories, String subWorkStreamId, String subWorkStreamName, String scenario, String period, String currencyCode,Set<String> conditionalGlCategories) {

        return PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                portfolioRepository.getCostForFinancialCaseSummryByGroupCcy(subWorkStreamId, subWorkStreamName, period, scenario, glCategories,conditionalGlCategories) :
                portfolioRepository.getCostForFinancialCaseSummryByLocalCcy(subWorkStreamId, subWorkStreamName, period, scenario, glCategories,conditionalGlCategories);
    }

    private GlCategory getDefaultGlCategory(String category, List<BigDecimal> monthlyValues, Map<String, List<BigDecimal>>
            quarterlyFinance, Map yearlySum, BigDecimal monthlySum, BigDecimal overAllSum) {
        GlCategory glCategory = new GlCategory();
        glCategory.setName(category);
        glCategory.setMonthlyFinance(monthlyValues);
        glCategory.setTotalSum(monthlySum);
        glCategory.setQuarterlyFinance(quarterlyFinance);
        glCategory.setYearlySummary(yearlySum);
        glCategory.setOverAllSum(overAllSum);
        return glCategory;
    }

    GlCategory getGlCategoryQuarterly(String category, String workStreamId,
                                      String subWorkStreamId, String subWorkStreamName, String scenario, String currencyCode) {

        List<String> financialYearsByScenario = getFinancialYearsByScenario(workStreamId, subWorkStreamId, scenario,
                subWorkStreamName);

        Map<String, List<BigDecimal>> quarterlyMap = new HashMap<>();
        BigDecimal totalQuarterlySum = BigDecimal.ZERO;
        List<BigDecimal> quarterlyValues;
        List<List<BigDecimal>> consolidatedQuarterlySum = new ArrayList<>();
        Map<String, BigDecimal> individualYearSummaryForQuarterlyData = new HashMap<>();
        Set<String> glCategories = new HashSet<>();
        glCategories.add(category);


        for (String year : financialYearsByScenario) {
            List<FinancialSummaryResource> financialSummaryResources = getSubWorkStreamGlCategoryValues(glCategories, subWorkStreamId, subWorkStreamName, scenario, year, currencyCode,getConditionalGlCategories());
            quarterlyValues = getQuarterlyDataFromResource(year, financialSummaryResources, currencyCode);
            quarterlyMap.put(year, quarterlyValues);
            consolidatedQuarterlySum.add(quarterlyValues);
        }
        for (List<BigDecimal> list : consolidatedQuarterlySum) {
            totalQuarterlySum = totalQuarterlySum.add(list.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        }
        quarterlyMap.forEach((year, bigDecimals) -> {
            individualYearSummaryForQuarterlyData.put(year, bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        });

        GlCategory glCategory = new GlCategory();
        glCategory.setName(category);
        glCategory.setQuarterlyFinance(quarterlyMap);
        glCategory.setOverAllSum(totalQuarterlySum);
        glCategory.setIndividualYearSummaryForQuarterly(individualYearSummaryForQuarterlyData);

        return glCategory;
    }

    public List<String> getFinancialYearsByScenario(String workStreamId, String subWorkStreamId, String scenario,
                                                    String subWorkStreamName) {
        /*DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(workStreamId,
                        subWorkStreamId, subWorkStreamName, PortfolioConstants.TRUE, scenario);
        if (subWorkStreamKeyDatesEntity == null || subWorkStreamKeyDatesEntity.getStartDate() == null) {
            return new ArrayList<>();
        } else {
            if (subWorkStreamKeyDatesEntity.getStartDate() != null && subWorkStreamKeyDatesEntity.getGoLiveDate() != null &&
                    subWorkStreamKeyDatesEntity.getEndDate() != null && subWorkStreamKeyDatesEntity.getDepreStartDate() != null &&
                    subWorkStreamKeyDatesEntity.getSwEngStartDate() != null) {
                String depreStartDate = getMonths(df.format(subWorkStreamKeyDatesEntity.getDepreStartDate()).substring(0, 7), 59);
                return getYearsBetweenDates(df.format(subWorkStreamKeyDatesEntity.getStartDate()).substring(0, 4),
                        depreStartDate.substring(0, 4));
            } else {
                String startDateValue = getMonths(df.format(subWorkStreamKeyDatesEntity.getStartDate()).substring(0, 7), 3);
                return getYearsBetweenDates(df.format(subWorkStreamKeyDatesEntity.getStartDate()).substring(0, 4),
                        startDateValue.substring(0, 4));
            }
        }
        */
        return subWorkstreamOtherCostRepo.getDistinctOfPeriodFromFinancialTables(subWorkStreamId,subWorkStreamName,scenario);
    }

    public List<BigDecimal> getQuarterlyData(String year, List<SubWorkstreamFinDetailsEntity>
            subWorkStreamFinDetailsEntities, String currencyCode) {
        BigDecimal firstQuarterAdder = BigDecimal.ZERO;
        BigDecimal secondQuarterAdder = BigDecimal.ZERO;
        BigDecimal thirdQuarterAdder = BigDecimal.ZERO;
        BigDecimal fourthQuarterAdder = BigDecimal.ZERO;
        for (SubWorkstreamFinDetailsEntity finDetailsEntity : subWorkStreamFinDetailsEntities) {
            if (year.equalsIgnoreCase(finDetailsEntity.getPeriod().substring(0, 4))) {
                String reportingMonth = finDetailsEntity.getPeriod().substring(4, 6);
                if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                    firstQuarterAdder = getCurrencyValue(currencyCode, firstQuarterAdder, finDetailsEntity.getGroupCcyVal(), finDetailsEntity.getLocalCcyVal());
                }
                if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                    secondQuarterAdder = getCurrencyValue(currencyCode, secondQuarterAdder, finDetailsEntity.getGroupCcyVal(), finDetailsEntity.getLocalCcyVal());
                }
                if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                    thirdQuarterAdder = getCurrencyValue(currencyCode, thirdQuarterAdder, finDetailsEntity.getGroupCcyVal(), finDetailsEntity.getLocalCcyVal());
                }
                if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                    fourthQuarterAdder = getCurrencyValue(currencyCode, fourthQuarterAdder, finDetailsEntity.getGroupCcyVal(), finDetailsEntity.getLocalCcyVal());
                }
            }
        }
        return Arrays.asList(firstQuarterAdder, secondQuarterAdder, thirdQuarterAdder, fourthQuarterAdder);
    }

    public List<BigDecimal> getQuarterlyDataFromResource(String year, List<FinancialSummaryResource>
            financialSummaryResources, String currencyCode) {
        BigDecimal firstQuarterAdder = BigDecimal.ZERO;
        BigDecimal secondQuarterAdder = BigDecimal.ZERO;
        BigDecimal thirdQuarterAdder = BigDecimal.ZERO;
        BigDecimal fourthQuarterAdder = BigDecimal.ZERO;
        for (FinancialSummaryResource financialSummaryResource : financialSummaryResources) {
            if (year.equalsIgnoreCase(financialSummaryResource.getPeriod().substring(0, 4))) {
                String reportingMonth = financialSummaryResource.getPeriod().substring(4, 6);
                if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                    firstQuarterAdder = firstQuarterAdder.add(financialSummaryResource.getCurrencyValue());
                }
                if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                    secondQuarterAdder = secondQuarterAdder.add(financialSummaryResource.getCurrencyValue());
                }
                if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                    thirdQuarterAdder = thirdQuarterAdder.add(financialSummaryResource.getCurrencyValue());
                }
                if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                    fourthQuarterAdder = fourthQuarterAdder.add(financialSummaryResource.getCurrencyValue());
                }
            }
        }
        return Arrays.asList(firstQuarterAdder, secondQuarterAdder, thirdQuarterAdder, fourthQuarterAdder);
    }

    public BigDecimal getCurrencyValue(String currencyCode, BigDecimal bigDecimal, BigDecimal groupCcyVal, BigDecimal localCcyVal) {
        if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) && groupCcyVal != null
                && groupCcyVal.intValue()
                != 0) {
            bigDecimal = bigDecimal.add(groupCcyVal);
        } else {
            if (localCcyVal != null && localCcyVal.intValue() != 0) {
                bigDecimal = bigDecimal.add(localCcyVal);
            }
        }
        return bigDecimal;
    }

    public List<BigDecimal> getMonthlyData(List<SubWorkstreamFinDetailsEntity> subWorkStreamFinDetailsEntities, String currencyCode) {
        BigDecimal[] defaultVales = new BigDecimal[12];
        Arrays.fill(defaultVales, BigDecimal.ZERO);
        for (SubWorkstreamFinDetailsEntity finDetailsEntity : subWorkStreamFinDetailsEntities) {
            String reportingMonth = finDetailsEntity.getPeriod().substring(4, 6);
            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {

                if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) && finDetailsEntity.getGroupCcyVal() != null && finDetailsEntity.getGroupCcyVal().intValue() != 0) {
                    defaultVales[Integer.parseInt(reportingMonth) - 1] = defaultVales[Integer.parseInt(reportingMonth) - 1].add(finDetailsEntity.getGroupCcyVal());
                } else {
                    if (finDetailsEntity.getLocalCcyVal() != null && finDetailsEntity.getLocalCcyVal().intValue() != 0) {
                        defaultVales[Integer.parseInt(reportingMonth) - 1] = defaultVales[Integer.parseInt(reportingMonth) - 1].add(finDetailsEntity.getLocalCcyVal());
                    }
                }
            }
        }
        return Arrays.asList(defaultVales);
    }

    public List<BigDecimal> getMonthlyDataFromResource(List<FinancialSummaryResource> financialSummaryResources) {
        BigDecimal[] defaultVales = new BigDecimal[12];
        Arrays.fill(defaultVales, BigDecimal.ZERO);
        for (FinancialSummaryResource financialSummaryResource : financialSummaryResources) {
            String reportingMonth = financialSummaryResource.getPeriod().substring(4, 6);
            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                defaultVales[Integer.parseInt(reportingMonth) - 1] = defaultVales[Integer.parseInt(reportingMonth) - 1].add(financialSummaryResource.getCurrencyValue());
            }
        }
        return Arrays.asList(defaultVales);
    }

    public List<MonthlyResource> getMonthlyDataByObject(List<SubWorkstreamFinDetailsEntity> subWorkStreamFinDetailsEntities, String currencyCode) {

        List<MonthlyResource> monthlyList = new ArrayList<>();
        for (int i = 1; i <= 12; i++) {
            MonthlyResource monthlyResource = new MonthlyResource();
            monthlyResource.setSurrId(0);
            monthlyResource.setMonthNumber(i <= 9 ? "0" + i : String.valueOf(i));
            monthlyResource.setValue(BigDecimal.ZERO);
            monthlyList.add(monthlyResource);
        }

        List<MonthlyResource> monthlyResourceList = new ArrayList<>();
        for (SubWorkstreamFinDetailsEntity finDetailsEntity : subWorkStreamFinDetailsEntities) {
            String reportingMonth = finDetailsEntity.getPeriod().substring(4, 6);
            BigDecimal monthTotal = BigDecimal.ZERO;
            for (SubWorkstreamFinDetailsEntity finDetailsMonthly : subWorkStreamFinDetailsEntities) {
                if (reportingMonth.equalsIgnoreCase((finDetailsMonthly.getPeriod().substring(4, 6)))) {
                    monthTotal = monthTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)
                            ? finDetailsMonthly.getGroupCcyVal() : finDetailsMonthly.getLocalCcyVal());
                }
            }
            for (int i = 0; i < monthlyList.size(); i++) {
                if (monthlyList.get(i).getMonthNumber().equalsIgnoreCase(reportingMonth)) {
                    monthlyList.get(i).setSurrId(0);
                    monthlyList.get(i).setMonthNumber(reportingMonth);
                    monthlyList.get(i).setValue(monthTotal);
                    break;
                }
            }
            monthlyResourceList = monthlyList;
        }
        return monthlyResourceList;
    }


    public HashSet<String> getCurrencyCodes(String workStreamId) {
        String currencyCode = getCurrencyCode(workStreamId);
        HashSet<String> currencyCodes = new HashSet<>();
        if (currencyCode != null) {
            currencyCodes.add(currencyCode);
        }
        DataValues dataValues = dataSummaryService.getDataValuesByValue(PortfolioConstants.REF_DATA_GRP_CCY, PortfolioConstants.REF_DATA_SYSTEM_CONFIG);
        if (dataValues != null) {
            currencyCodes.add(dataValues.getDesc());
        }
        return currencyCodes;
    }

    public String getCurrencyCode(String workStreamId) {

        WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(workStreamId);
        log.info("workStreamEntity.getCountry() : "+workStreamEntity.getCountry());
        DataValues dataValues = dataSummaryService.getDataValuesByValue(workStreamEntity.getCountry(), PortfolioConstants.COUNTRY);
        return (dataValues != null && dataValues.getAttr3() != null) ? dataValues.getAttr3() : PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD;

    }

    public Set<String> getCurrencyCodesFromWorkStream() {
        List<String> countries = workStreamRepo.findAllCountryFromWorkStream();
        return countries.stream().map(country -> {
            DataValues dataValues = dataSummaryService.getDataValuesByValue(country, PortfolioConstants.COUNTRY);
            return (dataValues != null && dataValues.getAttr3() != null) ? dataValues.getAttr3() : PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD;
        }).collect(Collectors.toSet());
    }

    private List<DataValues> getGlCategoryValues() {
        List<DataValues> dataValuesList = dataSummaryService.getDataValuesBySummaryId(PortfolioConstants.
                GL_CATEGORY_REF_DATA);
        dataValuesList.sort(Comparator.comparing(DataValues::getAttr1));
        return dataValuesList;
    }

    public String callBackEndPsglProcedure() {
        StoredProcedureQuery query = entityManager.createNamedStoredProcedureQuery("sp_etl_psgl_to_sws_fin_details");
        query.execute();
        return "Data loading successful";
    }

    public String callBackEndHyperionProcedure() {
        StoredProcedureQuery query = entityManager.createNamedStoredProcedureQuery("sp_etl_hyperion_to_sws_fin_details");
        query.execute();
        return "Data loading successful";
    }

    public List<String> getCurrenciesBasedOnUam(String loggedInUserId) {
        return dataSummaryService.findCurrenciesBasedOnUam(loggedInUserId);
    }

    public Date startingOwnershipPeriod(String subWorkStreamId,String subWorkStreamName,String scenario){
        SubWorkStreamKeyDatesEntity keyDatesEntity = subWorkStreamKeyDatesRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(
                subWorkStreamId, subWorkStreamName, PortfolioConstants.TRUE, scenario);
        //return DateUtils.addMonths(keyDatesEntity.getGoLiveDate(),1);
        return keyDatesEntity.getGoLiveDate();
    }

    public boolean checkOwnershipDate(Date ownershipStartDate,String period){
        DateFormat df = new SimpleDateFormat("yyyyMM");
        try {
            Date date = df.parse(period);
            return date.compareTo(ownershipStartDate)>0 ? true :false;
        } catch (ParseException e) {
            log.error("Error while parsing date :",e);
            return false;
        }
    }
}
