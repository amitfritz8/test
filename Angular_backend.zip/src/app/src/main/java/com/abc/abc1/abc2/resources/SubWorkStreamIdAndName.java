package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class SubWorkStreamIdAndName {
    String workStreamId;
    String subWorkStreamId;
    String subWorkStreamName;

    public SubWorkStreamIdAndName(String workStreamId, String subWorkStreamId, String subWorkStreamName) {
        this.workStreamId = workStreamId;
        this.subWorkStreamId = subWorkStreamId;
        this.subWorkStreamName = subWorkStreamName;
    }

    public SubWorkStreamIdAndName(String subWorkStreamId, String subWorkStreamName) {
        this.subWorkStreamId = subWorkStreamId;
        this.subWorkStreamName = subWorkStreamName;
    }
}
