package com.dbs.genesis.portfolio.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@Entity
@Table(name = "sub_workstream_other_cost")
@EntityListeners(AuditingEntityListener.class)
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Audited(withModifiedFlag = true)
public class SubWorkstreamOtherCost extends CommonEntity<String>{

    @Id
    @Column(name = "sws_other_surr_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer swsOtherSurrId;
    @Column(name = "workstream_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "workstream_id_MOD")
    private String workStreamId;
    @Column(name = "sub_workstream_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_id_MOD")
    private String subWorkStreamId;
    @Column(name = "sub_workstream_name")
    @Audited (withModifiedFlag = true, modifiedColumnName = "sub_workstream_name_MOD")
    private String subWorkStreamName;
    @Column(name = "scenario")
    @Audited (withModifiedFlag = true, modifiedColumnName = "scenario_MOD")
    private String scenario;
    @Column(name = "vendor_name")
    @Audited (withModifiedFlag = true, modifiedColumnName = "vendor_name_MOD")
    private String vendorName;
    @Column(name = "gl_category")
    @Audited (withModifiedFlag = true, modifiedColumnName = "gl_category_MOD")
    private String glCategory;
    @Column(name = "other_descr")
    @Audited (withModifiedFlag = true, modifiedColumnName = "other_descr_MOD")
    private String otherDesc;
    @Column(name = "local_ccy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "local_ccy_MOD")
    private String localCcy;
    @Column(name = "group_ccy")
    @Audited (withModifiedFlag = true, modifiedColumnName = "group_ccy_MOD")
    private String groupCcy;
    @Column(name = "local_ccy_val")
    @Audited (withModifiedFlag = true, modifiedColumnName = "local_ccy_val_MOD")
    private BigDecimal localCcyVal = BigDecimal.ZERO;
    @Column(name = "group_ccy_val")
    @Audited (withModifiedFlag = true, modifiedColumnName = "group_ccy_val_MOD")
    private BigDecimal groupCcyVal = BigDecimal.ZERO;
    @Column(name = "quantity")
    @Audited (withModifiedFlag = true, modifiedColumnName = "quantity_MOD")
    private BigDecimal quantity = BigDecimal.ZERO;
    @Column(name = "effective_start_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "effective_start_date_MOD")
    private Timestamp effectiveStartDate;
    @Column(name = "effective_end_date")
    @Audited (withModifiedFlag = true, modifiedColumnName = "effective_end_date_MOD")
    private Timestamp effectiveEndDate;
    @Column(name = "active_ind")
    @Audited (withModifiedFlag = true, modifiedColumnName = "active_ind_MOD")
    private String activeInd;
    @Column(name = "period")
    @Audited (withModifiedFlag = true, modifiedColumnName = "period_MOD")
    private String period;
    @Column(name = "type")
    @Audited (withModifiedFlag = true, modifiedColumnName = "type_MOD")
    private String type;
    @Column(name = "original_ind")
    @Audited (withModifiedFlag = true, modifiedColumnName = "original_ind_MOD")
    private String originalInd;
    @Column(name = "ref_sws_other_surr_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "ref_sws_other_surr_id_MOD")
    private Integer refSwsOtherSurrId;
    @Column(name = "cost_settings")
    @Audited (withModifiedFlag = true, modifiedColumnName = "cost_settings_MOD")
    private String costSettings;
    @Column(name = "add_other")
    @Audited (withModifiedFlag = true, modifiedColumnName = "add_other_MOD")
    private String addOther;
    @Column(name = "capex_opex_surr_id")
    @Audited (withModifiedFlag = true, modifiedColumnName = "capex_opex_surr_id_MOD")
    private Integer capexOpexSurrId;
    @Column(name = "cost_type_detail")
    @Audited (withModifiedFlag = true, modifiedColumnName = "cost_type_detail_MOD")
    private String costTypeDetail;

}
