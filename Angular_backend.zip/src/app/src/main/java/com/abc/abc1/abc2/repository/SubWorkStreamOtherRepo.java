package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.SubWorkStreamOthersEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SubWorkStreamOtherRepo extends JpaRepository<SubWorkStreamOthersEntity, Integer> {


    List<SubWorkStreamOthersEntity> findBySubWorkStreamIdAndSubWorkStreamNameAndActiveIndIgnoreCase(
            String subWorkStreamId, String name,String activeInd);
}
