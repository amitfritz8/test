package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.math.BigInteger;

@AllArgsConstructor
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SubWorkstreamLePccodeResource {

    String workStreamId;
    String lePcCode;
    String buildOperate;
    String subWorkStreamLinked;
    BigInteger subWorkStreamMapSurrId;
}
