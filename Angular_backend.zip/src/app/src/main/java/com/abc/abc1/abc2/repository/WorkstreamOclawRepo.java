package com.dbs.genesis.portfolio.repository;


import com.dbs.genesis.portfolio.model.WorkstreamOclaw;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WorkstreamOclawRepo extends JpaRepository<WorkstreamOclaw, String> {

}
