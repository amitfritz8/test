package com.dbs.genesis.portfolio;

import org.apache.commons.lang.ArrayUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.IntUnaryOperator;
import java.util.stream.IntStream;

public class Delete3 {

    public static int[] add(int[] first, int[] second) {

        int length = first.length < second.length ? first.length : second.length;

        int[] result = new int[length];
        for (int i = 0; i < length; i++) {
            result[i] = first[i] + second[i];
        }
        return result;
    }


    public static void main(String[] args) {


//        HashSet<String> fruitsStore = new HashSet<String>();
//        LinkedHashSet<String> fruitMarket = new LinkedHashSet<String>();
//        TreeSet<String> fruitBuzz = new TreeSet<String>();
//
//        for(String fruit: Arrays.asList("opex", "ownership", "it depreciasion")){
//            fruitsStore.add(fruit);
//            fruitMarket.add(fruit);
//            fruitBuzz.add(fruit);
//        }
//
//        //no ordering in HashSet – elements stored in random order
//        System.out.println("Ordering in HashSet :" + fruitsStore);
//
//        //insertion order or elements – LinkedHashSet storeds elements as insertion
//        System.err.println("Order of element in LinkedHashSet :" + fruitMarket);
//
//        //should be sorted order – TreeSet stores element in sorted order
//        System.out.println("Order of objects in TreeSet :" + fruitBuzz);





        String s = "opex, ownership,it depreciasion";
        System.out.println(s.contains("opex"));

        int[] even = {2, 4, 6};
        int[] odd = {1, 3, 5};

        int[] result = add(even, odd);
        System.out.println("first array: " + Arrays.toString(even));
        System.out.println("second array: " + Arrays.toString(odd));
        System.out.println("sum of array: " + Arrays.toString(result));

        int [] first = {1,2,3, 4};
        int [] second = {5,6,7,8};

        // combine two arrays in Java using Apache commons ArrayUtils
        int [] combined = ArrayUtils.addAll(first, second);

        System.out.println("First array : " + Arrays.toString(first));
        System.out.println("Second array : " + Arrays.toString(second));
        System.out.println("Combined array : " + Arrays.toString(combined));

        System.out.println("*************"+arraysAddition_java8(first,second));

        List list = new ArrayList();
        list.add(1);
        list.add(1);
        list.add(1);
        list.add(1);


        List list2 = new ArrayList();
        list2.add(1);
        list2.add(1);
        list2.add(1);
        list2.add(1);

        List list3 = new ArrayList();

        for (int i = 0; i <= 12; i++) {
            for (int j = i; j <= 12 ;j++) {
                System.out.println(list3.add(i+" ******  "+j));
            }

        }

        System.out.println("007_0512 - T&O-MOT-FINANCE".substring(0,"007_0512 - T&O-MOT-FINANCE".indexOf("-")));
        System.out.println("071_223D - T&O-FC".substring(0,"071_223D - T&O-FC".indexOf("-")));


    }

    private static int[] arraysAddition_java8(int[] a, int b[]) {
        int startInclusive = 0, endExclusive = Math.max(a.length, b.length);
        IntUnaryOperator mapper = index -> (index < a.length ? a[index] : 0) + (index < b.length ? b[index] : 0);

        return IntStream.range(startInclusive, endExclusive).map(mapper).toArray();
    }
}
