package com.dbs.genesis.portfolio.model;

import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@Entity
@Table(name = "workstream_approvers")
@EntityListeners(AuditingEntityListener.class)
@ToString
public class WorkStreamApprovers extends CommonEntity<String>{

    @Id
    @Column(name = "ws_approver_surr_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer wsApproverSurrId;
    @Column(name = "workstream_id")
    private String workStreamId;
    @Column(name = "portfolio_id")
    private String portfolioId;
    @Column(name = "1bank_id")
    private String oneBankId;
    @Column(name = "staff_name")
    private String staffName;
    @Column(name = "role")
    private String role;
    @Column(name = "delegate_ind")
    private String delegateInd;
    @Column(name = "active_ind")
    private String activeInd;
    @Column(name = "action")
    private String action;
    @Column(name = "notify_ind")
    private String notifyInd;
    @Column(name = "effective_start_date")
    private Date effectiveStartDate;
    @Column(name = "effective_end_date")
    private Date effectiveEndDate;
    @Column(name = "scenario")
    private String scenario;


}
