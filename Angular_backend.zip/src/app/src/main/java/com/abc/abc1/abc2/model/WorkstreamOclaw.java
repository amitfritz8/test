

package com.dbs.genesis.portfolio.model;

import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Date;


@Data
@Entity
@Table(name = "workstream_oclaw")
@EntityListeners(AuditingEntityListener.class)
@ToString
public class WorkstreamOclaw extends CommonEntity<String> {

//    @Id
//    @Column(name = "ws_oclaw_surr_id")
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Integer wcOclawSurrId;

    @Id
    @Column(name = "serial_number")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer serialNo;

    @Column(name = "project_id")
    private String projectId;

    @Column(name = "region")
    private String region;

    @Column(name = "country_code")
    private String countryCode;

    @Column(name = "effective_date")
    private String effectiveDate;

    @Column(name = "start_date")
    private String startDate;

    @Column(name = "end_date")
    private String endDate;

    @Column(name = "project_desc")
    private String projectDescription;

    @Column(name = "project_managers")
    private String projectManagers;

    @Column(name = "operation")
    private String operation;

    @Column(name = "reason")
    private String reason;

}