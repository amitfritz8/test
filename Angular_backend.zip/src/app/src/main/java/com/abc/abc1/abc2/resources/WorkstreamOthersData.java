package com.dbs.genesis.portfolio.resources;

public class WorkstreamOthersData {
}
