package com.dbs.genesis.portfolio.service.workstream;

import com.dbs.genesis.portfolio.common.GeneUtils;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.SubWorkstreamOtherCost;
import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.repository.SubWorkstreamOtherCostRepo;
import com.dbs.genesis.portfolio.resources.FinancialSummaryResource;
import com.dbs.genesis.portfolio.resources.SubWorkStreamIdAndName;
import com.dbs.genesis.portfolio.resources.UnitCostMappingView;
import com.dbs.genesis.portfolio.resources.UnitCostResource;
import com.google.common.collect.Lists;
import io.vavr.Tuple2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class WorkStreamBreakDownOthersService {

    public static final String FINANCIAL_OTHER_HEADER_SUMMARY_BY_PERIOD_AND_GROUP_CCY = "financialOtherHeaderSummaryByPeriodAndGroupCcy";
    public static final String FINANCIAL_OTHER_HEADER_SUMMARY_BY_PERIOD_AND_LOCAL_CCY = "financialOtherHeaderSummaryByPeriodAndLocalCcy";
    public static final String FINANCIAL_OTHER_HEADER_SUMMARY_BY_PERIOD_AND_GROUP_CCY1 = "financialOtherHeaderSummaryByPeriodAndGroupCcy";
    public static final String FINANCIAL_OTHER_HEADER_SUMMARY_BY_PERIOD_AND_LOCAL_CCY1 = "financialOtherHeaderSummaryByPeriodAndLocalCcy";
    public static final String FINANCIAL_OTHER_HEADER_SUMMARY_BY_PERIOD_AND_GROUP_CCY2 = "financialOtherHeaderSummaryByPeriodAndGroupCcy";
    public static final String FINANCIAL_OTHER_HEADER_SUMMARY_BY_PERIOD_AND_LOCAL_CCY2 = "financialOtherHeaderSummaryByPeriodAndLocalCcy";
    private final SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo;

    @Autowired
    private PortfolioRepository portfolioRepository;

    public WorkStreamBreakDownOthersService(SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo) {
        this.subWorkstreamOtherCostRepo = subWorkstreamOtherCostRepo;
    }

    public BigDecimal[] getOthersSummaryByMonthly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String period, String scenario, String type,String currencyCode) {

        Map<String, List<SubWorkstreamOtherCost>> softwareOthersList = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> subWorkstreamOtherCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContainingAndGlCategoryNotIn(
                        subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario,
                        PortfolioConstants.TRUE, type,PortfolioConstants.FALSE, period, GeneUtils.getGlCategoriesNotInclude())).flatMap(List::stream).collect(
                Collectors.groupingBy(SubWorkstreamOtherCost::getPeriod));

        BigDecimal[] othersValuesByPeriod = new BigDecimal[12];
        Arrays.fill(othersValuesByPeriod, BigDecimal.ZERO);

        softwareOthersList.forEach((yearMonth, subWorkStreamOtherCostList) -> {
            BigDecimal individualMonthValue  = BigDecimal.ZERO;
            String reportingMonth = yearMonth.substring(4,6);
            for(SubWorkstreamOtherCost subWorkStreamOtherCost : subWorkStreamOtherCostList) {
                individualMonthValue = individualMonthValue.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkStreamOtherCost.getGroupCcyVal():subWorkStreamOtherCost.getLocalCcyVal());
            }
            othersValuesByPeriod[Integer.parseInt(reportingMonth) - 1] = individualMonthValue;
        });
        return othersValuesByPeriod;
    }

    public BigDecimal getOtherTotalSum(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario, String type,String currencyCode) {
        BigDecimal otherTotalSum = BigDecimal.ZERO;
        for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
            otherTotalSum = otherTotalSum.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    subWorkstreamOtherCostRepo.getSoftwareOthersTotalByGrpCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, type, GeneUtils.getGlCategoriesNotInclude())
                    : subWorkstreamOtherCostRepo.getSoftwareOthersTotalByLocalCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, type, GeneUtils.getGlCategoriesNotInclude()));
        }
        return otherTotalSum;
    }

    public List<UnitCostMappingView> getOthersHardwareByMonthly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String period, String scenario,String currencyCode) {
        List<UnitCostMappingView> costLists = Lists.newArrayList();
        Map<Integer,List<SubWorkstreamOtherCost>>  othersListMap= subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> subWorkstreamOtherCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContainingAndGlCategoryNotIn(
                        subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario,
                        PortfolioConstants.TRUE, PortfolioConstants.HARDWARE_TYPE,PortfolioConstants.FALSE, period, GeneUtils.getGlCategoriesNotInclude())).flatMap(List::stream)
                .collect(Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        othersListMap.forEach((refSurrId, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getRefSwsOtherSurrId());
            unitCostMappingView.setName(PortfolioConstants.OTHER_HARDWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
            populateUnitCostMappingForGivenVendorName(subWorkStreamOtherCostList, unitCostMappingView,currencyCode);
            Tuple2<BigDecimal,BigDecimal> bigDecimalTuple2 = getUnitCostOverAllTotal(subWorkStreamIdAndNames,subWorkStreamOtherCostList.get(0).getVendorName(),scenario,currencyCode);
            unitCostMappingView.setYearlyCostOverAllTotal(bigDecimalTuple2._1);
            unitCostMappingView.setYearlyUnitOverAllTotal(null);
            costLists.add(unitCostMappingView);
        });
        return costLists;
    }

    private List<UnitCostResource>
    getOthersMonthlyList(List<SubWorkstreamOtherCost> subWorkStreamOtherHardwareList, String currencyCode) {
        return subWorkStreamOtherHardwareList.stream().map(subWorkStreamOtherCost -> {
            String reportingMonth = subWorkStreamOtherCost.getPeriod().substring(4, 6);
            //int monthNumber = Integer.parseInt(reportingMonth) - 1;
            UnitCostResource unitResource = new UnitCostResource();
            unitResource.setSurrId(subWorkStreamOtherCost.getSwsOtherSurrId());
            unitResource.setMonthNumber(reportingMonth);
            unitResource.setValue(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkStreamOtherCost.getGroupCcyVal():subWorkStreamOtherCost.getLocalCcyVal());
            return unitResource;
        }).collect(Collectors.toList());
    }

    public List<UnitCostMappingView> getOthersByMonthly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String period,String scenario,String currencyCode) {

        List<UnitCostMappingView> costLists = Lists.newArrayList();

        Map<String,List<SubWorkstreamOtherCost>>  othersListMap= getSubWorkStreamOthersMap(subWorkStreamIdAndNames,
                PortfolioConstants.OTHERS_TYPE, period,scenario);

        othersListMap.forEach((vendorName, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getRefSwsOtherSurrId());
            unitCostMappingView.setName(vendorName);
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
            populateUnitCostMappingForGivenVendorName(subWorkStreamOtherCostList, unitCostMappingView,currencyCode);
            Tuple2<BigDecimal,BigDecimal> bigDecimalTuple2 = getUnitCostOverAllTotal(subWorkStreamIdAndNames,vendorName,scenario,currencyCode);
            unitCostMappingView.setYearlyCostOverAllTotal(bigDecimalTuple2._1);
            unitCostMappingView.setYearlyUnitOverAllTotal(null);
            costLists.add(unitCostMappingView);
        });

        return costLists;
    }

    private Map<String, List<SubWorkstreamOtherCost>> getSubWorkStreamOthersMap(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String type,
                                                                                String period, String scenario) {
        return subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> subWorkstreamOtherCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContainingAndGlCategoryNotIn(
                        subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.TRUE,
                        type,PortfolioConstants.FALSE, period, GeneUtils.getGlCategoriesNotInclude())).flatMap(List::stream).collect(Collectors.groupingBy(SubWorkstreamOtherCost::getVendorName));
    }

    UnitCostMappingView populateUnitCostMappingForGivenVendorName(
            List<SubWorkstreamOtherCost> softwarePeriodList,
            UnitCostMappingView unitCostMappingView, String currencyCode) {

        List<UnitCostResource> costResourceList = Lists.newLinkedList();
        List<UnitCostResource> unitResourceList = Lists.newLinkedList();

        BigDecimal unitOverAllTotal = BigDecimal.ZERO;
        BigDecimal costOverAllTotal = BigDecimal.ZERO;

        for (SubWorkstreamOtherCost subWorkstreamOtherCost : softwarePeriodList) {
            String reportingMonth = subWorkstreamOtherCost.getPeriod().substring(4, 6);
            UnitCostResource costResource = new UnitCostResource();
            // int monthNumber = Integer.parseInt(reportingMonth);
            BigDecimal costPerMonth = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamOtherCost.getGroupCcyVal():subWorkstreamOtherCost.getLocalCcyVal();
            BigDecimal quantity = subWorkstreamOtherCost.getQuantity();

            costResource.setSurrId(subWorkstreamOtherCost.getSwsOtherSurrId());
            costResource.setMonthNumber(reportingMonth);
            costResource.setValue(costPerMonth);
            costResourceList.add(costResource);
            unitOverAllTotal = unitOverAllTotal.add(quantity);
            costOverAllTotal = costOverAllTotal.add(costPerMonth);

            UnitCostResource unitResource = new UnitCostResource();
            unitResource.setSurrId(subWorkstreamOtherCost.getSwsOtherSurrId());
            unitResource.setMonthNumber(reportingMonth);
            unitResource.setValue(quantity);
            unitResourceList.add(unitResource);
        }

        costResourceList = costResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(costResourceList) : costResourceList;
        unitResourceList = unitResourceList.size() < 12 ? getUnitAndCostResourceMonthlyList(unitResourceList) : unitResourceList;

        unitCostMappingView.setMonthlyResourcesCosts(costResourceList);
        unitCostMappingView.setMonthlyResourcesUnits(unitResourceList);
        unitCostMappingView.setUnitOverAllTotal(unitOverAllTotal);
        unitCostMappingView.setCostOverAllTotal(costOverAllTotal);
        return unitCostMappingView;
    }

    private List<UnitCostResource> getUnitAndCostResourceMonthlyList( List<UnitCostResource> unitAndCostResourceList){
        List<UnitCostResource> unitAndcostResourceMonthlyList = Lists.newLinkedList();
        if(unitAndCostResourceList.size() < 12) {
            for (int i = 1; i <= 12; i++) {
                UnitCostResource costResource = new UnitCostResource();
                costResource.setSurrId(0);
                costResource.setMonthNumber(i <= 9 ? "0" + i : String.valueOf(i));
                costResource.setValue(BigDecimal.ZERO);
                unitAndcostResourceMonthlyList.add(costResource);
            }
            for (int i = 0; i < unitAndcostResourceMonthlyList.size() ; i++) {
                for (int j = 0; j < unitAndCostResourceList.size(); j++) {
                    if(unitAndcostResourceMonthlyList.get(i).getMonthNumber().equalsIgnoreCase(unitAndCostResourceList.get(j).getMonthNumber())){
                        unitAndcostResourceMonthlyList.set(i,unitAndCostResourceList.get(j));
                        break;
                    }
                }
            }
        }
        return unitAndcostResourceMonthlyList;
    }

    public List<BigDecimal> getOthersHeaderByMonthly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String period,String scenario,String currencyCode) {

        List<FinancialSummaryResource> consolidatedFinancialSummary =
                PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> {
                            return portfolioRepository.getSubworkstreamOtherHeaderRowByPeriodAndGroupCurrency(subWorkStreamIdAndName.getSubWorkStreamId(),
                                    subWorkStreamIdAndName.getSubWorkStreamName(), period, scenario,
                                    FINANCIAL_OTHER_HEADER_SUMMARY_BY_PERIOD_AND_GROUP_CCY, PortfolioConstants.OTHERS);
                        }).flatMap(List::stream).collect(Collectors.toList())
                        : subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> {
                    return portfolioRepository.getSubworkstreamOtherHeaderRowByPeriodAndLocalCurrency(subWorkStreamIdAndName.getSubWorkStreamId(),
                            subWorkStreamIdAndName.getSubWorkStreamName(), period, scenario,
                            FINANCIAL_OTHER_HEADER_SUMMARY_BY_PERIOD_AND_LOCAL_CCY, PortfolioConstants.OTHERS);
                }).flatMap(List::stream).collect(Collectors.toList());

        BigDecimal[] costValues = new BigDecimal[12];
        Arrays.fill(costValues, BigDecimal.ZERO);

        for (FinancialSummaryResource summaryResource : consolidatedFinancialSummary) {
            String reportingMonth = summaryResource.getPeriod().substring(4, 6);
            if (PortfolioConstants.defaultMonthValue.contains(reportingMonth)) {
                costValues[Integer.parseInt(reportingMonth) - 1] = summaryResource.getCurrencyValue();
            }
        }

        return Collections.unmodifiableList(Arrays.asList(costValues));
    }

    private  List<SubWorkstreamOtherCost> getSubWorkStreamOtherCostsListByPeriod(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String type,
                                                                                 String period,String scenario) {
        return subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> subWorkstreamOtherCostRepo.
                    findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndTypeAndOriginalIndAndPeriodContainingAndGlCategoryNotIn(
                        subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario,
                        PortfolioConstants.TRUE, type,PortfolioConstants.FALSE, period, GeneUtils.getGlCategoriesNotInclude())).
                flatMap(List::stream).collect(Collectors.toList());
    }

    public BigDecimal getOthersHeaderTotal(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String scenario,String currencyCode) {

        BigDecimal overAllTotal = BigDecimal.ZERO;

        List<SubWorkstreamOtherCost> subWorkStreamOtherCostList = getSubWorkStreamOtherCostsList(subWorkStreamIdAndNames,scenario);

        for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {

            overAllTotal = overAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    portfolioRepository.getSubworkstreamCostTypeOverAllTotalByGroupCurrency(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario,
                            "financialOthersCostTypeOverAllTotalByGroupCurrency",  PortfolioConstants.OTHERS_TYPE).get(0).getCurrencyValue()
                    : portfolioRepository.getSubworkstreamCostTypeOverAllTotalByLocalCurrency(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario,
                    "financialOthersCostTypeOverAllTotalByLocalCurrency",  PortfolioConstants.OTHERS_TYPE).get(0).getCurrencyValue());
        }

//        for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkStreamOtherCostList) {
//
//
////            overAllTotal = overAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
////                    subWorkstreamOtherCost.getGroupCcyVal() : subWorkstreamOtherCost.getLocalCcyVal());
//        }
        return overAllTotal;
    }

    private List<SubWorkstreamOtherCost> getSubWorkStreamOtherCostsList(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String scenario) {
        return subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamOtherCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndType(
                subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.TRUE,
                PortfolioConstants.FALSE, PortfolioConstants.OTHERS_TYPE)).flatMap(List::stream).collect(Collectors.toList());
    }

    public List<UnitCostMappingView> getOtherSoftwareByMonthly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                                               String period,String scenario,String currencyCode) {
        List<UnitCostMappingView> costLists = Lists.newArrayList();
        Map<Integer,List<SubWorkstreamOtherCost>>  othersListMap= getSubWorkStreamOtherCostsListByPeriod(subWorkStreamIdAndNames,
                PortfolioConstants.SOFTWARE_TYPE, period,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getRefSwsOtherSurrId));
        othersListMap.forEach((refSurrId, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getRefSwsOtherSurrId());
            unitCostMappingView.setName(PortfolioConstants.OTHER_SOFTWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
            populateUnitCostMappingForGivenVendorName(subWorkStreamOtherCostList, unitCostMappingView,currencyCode);
//            unitCostMappingView.setMonthlyResourcesCosts(getOthersMonthlyList(subWorkStreamOtherCostList,currencyCode));
//            unitCostMappingView.setCostOverAllTotal(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
//                    subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamId,subWorkStreamName,scenario,PortfolioConstants.SOFTWARE_TYPE)
//                    : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamId,subWorkStreamName,scenario,PortfolioConstants.SOFTWARE_TYPE));
            Tuple2<BigDecimal,BigDecimal> bigDecimalTuple2 = getUnitCostOverAllTotal(subWorkStreamIdAndNames,subWorkStreamOtherCostList.get(0).getVendorName(),scenario,currencyCode);
            unitCostMappingView.setYearlyCostOverAllTotal(bigDecimalTuple2._1);
            unitCostMappingView.setYearlyUnitOverAllTotal(null);
            costLists.add(unitCostMappingView);
        });

        return costLists;
    }

    private Tuple2<BigDecimal,BigDecimal> getUnitCostOverAllTotal(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String vendorName,String scenario, String currencyCode) {

        List<SubWorkstreamOtherCost> subWorkstreamOtherCostList = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName -> subWorkstreamOtherCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndVendorNameAndScenarioAndActiveIndAndOriginalInd(subWorkStreamIdAndName.getSubWorkStreamId(),
                        subWorkStreamIdAndName.getSubWorkStreamName(), vendorName, scenario, PortfolioConstants.TRUE,PortfolioConstants.FALSE)).flatMap(List::stream).collect(Collectors.toList());

        BigDecimal costOverAllTotal = BigDecimal.ZERO;
        BigDecimal unitOverAllTotal = BigDecimal.ZERO;
        for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkstreamOtherCostList) {
            costOverAllTotal = costOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    subWorkstreamOtherCost.getGroupCcyVal() : subWorkstreamOtherCost.getLocalCcyVal());
            unitOverAllTotal = unitOverAllTotal.add(subWorkstreamOtherCost.getQuantity());
        }
        return new Tuple2<>(costOverAllTotal,unitOverAllTotal);
    }

    public List<UnitCostMappingView> getOtherSoftwareByQuarterly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String year,String scenario,String currencyCode) {

        List<UnitCostMappingView> costMappingViewList = Lists.newArrayList();
        Map<Integer, List<SubWorkstreamOtherCost>> othersListByRefSurrIdByVendorName = getSubWorkStreamOtherCostsListByPeriod(
                subWorkStreamIdAndNames, PortfolioConstants.SOFTWARE_TYPE, year,scenario).stream().collect(
                Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        othersListByRefSurrIdByVendorName.forEach((refSurrId, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setName(PortfolioConstants.OTHER_SOFTWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.QUARTERLY);
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
            List<BigDecimal> othersQuarterlyList = getOthersQuarterlyList(subWorkStreamOtherCostList,currencyCode);
            unitCostMappingView.setQuarterlyCostTotal(othersQuarterlyList);
            unitCostMappingView.setQuarterlyUnitTotal(null);

            BigDecimal costOverAllTotal=BigDecimal.ZERO;
            for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                costOverAllTotal = costOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.SOFTWARE_TYPE, GeneUtils.getGlCategoriesNotInclude())
                        : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.SOFTWARE_TYPE, GeneUtils.getGlCategoriesNotInclude()));
            }
            unitCostMappingView.setCostOverAllTotal(costOverAllTotal);
            costMappingViewList.add(unitCostMappingView);
        });
        return costMappingViewList;
    }

    private List<BigDecimal> getOthersQuarterlyList(List<SubWorkstreamOtherCost> subWorkStreamOtherCostList, String currencyCode) {

        BigDecimal firstQuarterCost = BigDecimal.ZERO;
        BigDecimal secondQuarterCost = BigDecimal.ZERO;
        BigDecimal thirdQuarterCost = BigDecimal.ZERO;
        BigDecimal fourthQuarterCost = BigDecimal.ZERO;

        for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkStreamOtherCostList) {
            String reportingMonth = subWorkstreamOtherCost.getPeriod().substring(4, 6);
            if(PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                firstQuarterCost = firstQuarterCost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCost.getGroupCcyVal():subWorkstreamOtherCost.getLocalCcyVal());
            }
            if(PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                secondQuarterCost = secondQuarterCost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCost.getGroupCcyVal():subWorkstreamOtherCost.getLocalCcyVal());
            }
            if(PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                thirdQuarterCost = thirdQuarterCost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCost.getGroupCcyVal():subWorkstreamOtherCost.getLocalCcyVal());
            }
            if(PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                fourthQuarterCost = fourthQuarterCost.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCost.getGroupCcyVal():subWorkstreamOtherCost.getLocalCcyVal());
            }
        }
        return  Arrays.asList(firstQuarterCost,secondQuarterCost,thirdQuarterCost,fourthQuarterCost);
    }

    public List<BigDecimal> getOthersByQuarterlyTotalSum(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario, String otherSoftwareType, String year,String currencyCode) {
        List<SubWorkstreamOtherCost> othersListByYear = getSubWorkStreamOtherCostsListByPeriod(subWorkStreamIdAndNames, otherSoftwareType, year,scenario);
        List<BigDecimal> othersQuarterlyList = getOthersQuarterlyList(othersListByYear, currencyCode);
        return othersQuarterlyList;
    }

    public List<UnitCostMappingView> getOthersHardwareByQuarterly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String year,String scenario,String currencyCode) {

        List<UnitCostMappingView> costMappingViewList = Lists.newArrayList();
        Map<Integer, List<SubWorkstreamOtherCost>> othersListByRefSurrIdByVendorName = getSubWorkStreamOtherCostsListByPeriod(
                subWorkStreamIdAndNames, PortfolioConstants.HARDWARE_TYPE, year,scenario).stream().collect(
                Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        othersListByRefSurrIdByVendorName.forEach((refSurrId, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setName(PortfolioConstants.OTHER_HARDWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.QUARTERLY);
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
            List<BigDecimal> othersQuarterlyList = getOthersQuarterlyList(subWorkStreamOtherCostList, currencyCode);
            unitCostMappingView.setQuarterlyCostTotal(othersQuarterlyList);
            unitCostMappingView.setQuarterlyUnitTotal(null);
            BigDecimal costOverAllTotal =BigDecimal.ZERO;
            for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                costOverAllTotal = costOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.HARDWARE_TYPE, GeneUtils.getGlCategoriesNotInclude())
                        : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.HARDWARE_TYPE, GeneUtils.getGlCategoriesNotInclude()));
            }
            unitCostMappingView.setCostOverAllTotal(costOverAllTotal);
            costMappingViewList.add(unitCostMappingView);
        });
        return costMappingViewList;
    }

    public Map<String, List<UnitCostMappingView>> getOthersByQuarterlyTotalSum(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario,String currencyCode) {

        Map<String,List<UnitCostMappingView>> quarterlyMap = new TreeMap<>();

        List<String> listOfDistinctYears = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamOtherCostRepo.findDistinctOfYears(subWorkStreamIdAndName.getSubWorkStreamId(),subWorkStreamIdAndName.getSubWorkStreamName(),
                        scenario,PortfolioConstants.OTHERS_TYPE)).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
        listOfDistinctYears.stream().forEach(year -> {
            List<UnitCostMappingView> costMappingViewList = Lists.newArrayList();

            Map<Integer, List<SubWorkstreamOtherCost>> othersListByRefSurrIdByVendorName = getSubWorkStreamOtherCostsListByPeriod(
                    subWorkStreamIdAndNames, PortfolioConstants.OTHERS_TYPE, year,scenario).stream().collect(
                    Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));

            othersListByRefSurrIdByVendorName.forEach((refSurrId, subWorkStreamOtherCostList) -> {
                UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
                unitCostMappingView.setName(subWorkStreamOtherCostList.get(0).getVendorName());
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
                unitCostMappingView.setPeriodType(PortfolioConstants.QUARTERLY);
                unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
                List<BigDecimal> othersQuarterlyList = getOthersQuarterlyList(subWorkStreamOtherCostList, currencyCode);
                unitCostMappingView.setQuarterlyCostTotal(othersQuarterlyList);
                BigDecimal yearlyCostOverAllTotal =BigDecimal.ZERO;
                if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)) {
                    for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                        yearlyCostOverAllTotal = yearlyCostOverAllTotal.add(subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(
                                subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.OTHERS_TYPE, GeneUtils.getGlCategoriesNotInclude()));
                    }
                }else {
                    for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                        yearlyCostOverAllTotal = yearlyCostOverAllTotal.add(subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(
                                subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.OTHERS_TYPE, GeneUtils.getGlCategoriesNotInclude()));
                    }
                }
                unitCostMappingView.setYearlyCostOverAllTotal(yearlyCostOverAllTotal);
                costMappingViewList.add(unitCostMappingView);
            });
            quarterlyMap.put(year, costMappingViewList);

        });
        return quarterlyMap;

    }

    public Map<String, List<BigDecimal>> getOthersHeaderDataByQuarterly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String scenario, String currencyCode) {
        Map<String, List<BigDecimal>> quarterlySum = new TreeMap<>();
        List<String> distinctOfPeriods = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamOtherCostRepo.findDistinctOfYears(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),
                scenario,PortfolioConstants.OTHERS_TYPE)).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());

        List<BigDecimal> quarterlySummaryList;
        for (String year : distinctOfPeriods) {
            List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                            portfolioRepository.getSubworkstreamOtherHeaderRowByPeriodAndGroupCurrency(subWorkStreamIdAndName.getSubWorkStreamId(),
                                    subWorkStreamIdAndName.getSubWorkStreamName(), year, scenario,
                                    FINANCIAL_OTHER_HEADER_SUMMARY_BY_PERIOD_AND_GROUP_CCY1, PortfolioConstants.OTHERS)).flatMap(List::stream).collect(Collectors.toList())
                            : subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                            portfolioRepository.getSubworkstreamOtherHeaderRowByPeriodAndLocalCurrency(subWorkStreamIdAndName.getSubWorkStreamId(),
                                    subWorkStreamIdAndName.getSubWorkStreamName(), year, scenario,
                                    FINANCIAL_OTHER_HEADER_SUMMARY_BY_PERIOD_AND_LOCAL_CCY1, PortfolioConstants.OTHERS)).flatMap(List::stream).collect(Collectors.toList());
            quarterlySummaryList = getOthersQuarterlyListForHeader(consolidatedFinancialSummary, currencyCode);
            quarterlySum.put(year, quarterlySummaryList);
        }
        return quarterlySum;
    }

    private List<BigDecimal> getOthersQuarterlyListForHeader(List<FinancialSummaryResource> consolidatedFinancialSummary, String currencyCode) {

        BigDecimal firstQuarterCost = BigDecimal.ZERO;
        BigDecimal secondQuarterCost = BigDecimal.ZERO;
        BigDecimal thirdQuarterCost = BigDecimal.ZERO;
        BigDecimal fourthQuarterCost = BigDecimal.ZERO;

        for (FinancialSummaryResource subWorkstreamOtherCost : consolidatedFinancialSummary) {
            String reportingMonth = subWorkstreamOtherCost.getPeriod().substring(4, 6);
            if(PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                firstQuarterCost = firstQuarterCost.add(
                        subWorkstreamOtherCost.getCurrencyValue() );
            }
            if(PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                secondQuarterCost = secondQuarterCost.add(
                        subWorkstreamOtherCost.getCurrencyValue());
            }
            if(PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                thirdQuarterCost = thirdQuarterCost.add(
                        subWorkstreamOtherCost.getCurrencyValue());
            }
            if(PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                fourthQuarterCost = fourthQuarterCost.add(
                        subWorkstreamOtherCost.getCurrencyValue());
            }
        }
        return  Arrays.asList(firstQuarterCost,secondQuarterCost,thirdQuarterCost,fourthQuarterCost);
    }

    public List<UnitCostMappingView> getOthersResourceByYearly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String year, String scenario, String currencyCode) {

        List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
        Map<Integer,List<SubWorkstreamOtherCost>> subWorkStreamOthersListMap = getSubWorkStreamOtherCostsListByPeriod(subWorkStreamIdAndNames,
                PortfolioConstants.RESOURCE_TYPE, year,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getRefSwsOtherSurrId));
        subWorkStreamOthersListMap.forEach((integer, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setName(PortfolioConstants.OTHER_SOFTWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            //TODO set currencytype, currencyvalue
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
            BigDecimal yearlyTotal = BigDecimal.ZERO;
            for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkStreamOtherCostList) {
                yearlyTotal = yearlyTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCost.getGroupCcyVal() : subWorkstreamOtherCost.getLocalCcyVal());
            }
            unitCostMappingView.addYearlyCostTotal(yearlyTotal);
            unitCostMappingView.setYearlyUnitTotal(null);
            BigDecimal yearlyCostOverAllTotal =BigDecimal.ZERO;
            for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                yearlyCostOverAllTotal = yearlyCostOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),
                                scenario, PortfolioConstants.SOFTWARE_TYPE, GeneUtils.getGlCategoriesNotInclude())
                        : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),
                        scenario, PortfolioConstants.SOFTWARE_TYPE, GeneUtils.getGlCategoriesNotInclude()));
            }
            unitCostMappingView.setYearlyCostOverAllTotal(yearlyCostOverAllTotal);
            unitCostMappingViewArrayList.add(unitCostMappingView);
        });
        return unitCostMappingViewArrayList;
    }

    public List<UnitCostMappingView> getOthersHardwareByYearly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String year, String scenario, String currencyCode) {

        List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
        Map<Integer,List<SubWorkstreamOtherCost>> subWorkStreamOthersListMap = getSubWorkStreamOtherCostsListByPeriod(subWorkStreamIdAndNames,
                PortfolioConstants.HARDWARE_TYPE, year,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getRefSwsOtherSurrId));
        subWorkStreamOthersListMap.forEach((integer, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setName(PortfolioConstants.OTHER_HARDWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            //TODO set currencytype, currencyvalue
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
            BigDecimal yearlyTotal = BigDecimal.ZERO;
            for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkStreamOtherCostList) {
                yearlyTotal = yearlyTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        subWorkstreamOtherCost.getGroupCcyVal() : subWorkstreamOtherCost.getLocalCcyVal());
            }
            unitCostMappingView.addYearlyUnitTotal(yearlyTotal);
            BigDecimal yearlyCostOverAllTotal = BigDecimal.ZERO;
            for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                yearlyCostOverAllTotal = yearlyCostOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                        subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),
                                scenario, PortfolioConstants.HARDWARE_TYPE, GeneUtils.getGlCategoriesNotInclude())
                        : subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),
                        scenario, PortfolioConstants.HARDWARE_TYPE, GeneUtils.getGlCategoriesNotInclude()));
            }
            unitCostMappingView.setYearlyCostOverAllTotal(yearlyCostOverAllTotal);
            unitCostMappingViewArrayList.add(unitCostMappingView);
        });
        return unitCostMappingViewArrayList;
    }

    public BigDecimal getOthersByYearlySum(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario, String year, String type,String currencyCode) {
        BigDecimal totalByYear=BigDecimal.ZERO;
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
            totalByYear = totalByYear.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    subWorkstreamOtherCostRepo.getOthersTotalByYearAndGrpCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, year, type, glCategories)
                    : subWorkstreamOtherCostRepo.getOthersTotalByYearAndLocalCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario, year, type, glCategories));
        }
        return  totalByYear;
    }

    public Map<String, List<UnitCostMappingView>> getYearlyOthersData(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String scenario, String currencyCode) {

        Map<String, List<UnitCostMappingView>> yearlyCostUnitResource = new TreeMap<>();
        List<String> listOfYears = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamOtherCostRepo.findDistinctOfYears(subWorkStreamIdAndName.getSubWorkStreamId(),
                subWorkStreamIdAndName.getSubWorkStreamName(),scenario,PortfolioConstants.OTHERS_TYPE))
                .flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
        for (String year : listOfYears) {
            List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
            Map<Integer,List<SubWorkstreamOtherCost>> subWorkStreamOthersListMap = getSubWorkStreamOtherCostsListByPeriod(subWorkStreamIdAndNames,
                    PortfolioConstants.OTHERS_TYPE, year,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getRefSwsOtherSurrId));
            subWorkStreamOthersListMap.forEach((integer, subWorkStreamOtherCostList) -> {
                UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
                unitCostMappingView.setName(subWorkStreamOtherCostList.get(0).getVendorName());
                unitCostMappingView.setCurrencyCode(currencyCode);
                unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
                unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
                unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
                BigDecimal yearlyTotal = BigDecimal.ZERO;
                for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkStreamOtherCostList) {
                    yearlyTotal = yearlyTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                            subWorkstreamOtherCost.getGroupCcyVal() : subWorkstreamOtherCost.getLocalCcyVal());
                }
                unitCostMappingView.addYearlyUnitTotal(yearlyTotal);
                BigDecimal yearlyCostOverAllTotal = BigDecimal.ZERO;
                for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                    yearlyCostOverAllTotal = yearlyCostOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),
                                    scenario, PortfolioConstants.OTHERS_TYPE, GeneUtils.getGlCategoriesNotInclude()) :
                            subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),
                                    scenario, PortfolioConstants.OTHERS_TYPE, GeneUtils.getGlCategoriesNotInclude()));
                }
                unitCostMappingView.setYearlyCostOverAllTotal(yearlyCostOverAllTotal);
                unitCostMappingViewArrayList.add(unitCostMappingView);
            });
            yearlyCostUnitResource.put(year, unitCostMappingViewArrayList);
        }
        return yearlyCostUnitResource;
    }

    public Map<String, BigDecimal> getYearlySummaryData(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String scenario, String currencyCode) {
        Map<String, BigDecimal> totalYearSumMap = new TreeMap<>();
        List<String> listOfYears = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamOtherCostRepo.findDistinctOfYears(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(),scenario,PortfolioConstants.OTHERS_TYPE))
                .flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
        for (String year : listOfYears) {
            BigDecimal totalYearSum = BigDecimal.ZERO;
            List<FinancialSummaryResource> consolidatedFinancialSummary =
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                            subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                                    portfolioRepository.getSubworkstreamOtherHeaderRowByPeriodAndGroupCurrency(
                                            subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), year, scenario,
                                            FINANCIAL_OTHER_HEADER_SUMMARY_BY_PERIOD_AND_GROUP_CCY2, PortfolioConstants.OTHERS)).flatMap(List::stream).collect(Collectors.toList())
                            :
                            subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                                    portfolioRepository.getSubworkstreamOtherHeaderRowByPeriodAndLocalCurrency(
                                            subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), year, scenario,
                                            FINANCIAL_OTHER_HEADER_SUMMARY_BY_PERIOD_AND_LOCAL_CCY2, PortfolioConstants.OTHERS)).flatMap(List::stream).collect(Collectors.toList());

            for (FinancialSummaryResource subWorkstreamOtherCost  : consolidatedFinancialSummary) {
                totalYearSum = totalYearSum.add(subWorkstreamOtherCost.getCurrencyValue());
            }
            totalYearSumMap.put(year, totalYearSum);
        }
        return totalYearSumMap;
    }

    public List<UnitCostMappingView> getOtherResourceByMonthly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                                               String period,String scenario, String currencyCode) {
        List<UnitCostMappingView> costLists = Lists.newArrayList();
        Map<Integer,List<SubWorkstreamOtherCost>>  othersListMap= getSubWorkStreamOtherCostsListByPeriod(subWorkStreamIdAndNames,
                PortfolioConstants.RESOURCE_TYPE, period,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        othersListMap.forEach((refSurrId, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getRefSwsOtherSurrId());
            unitCostMappingView.setName(PortfolioConstants.OTHER_RESOURCE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.MONTHLY);
            populateUnitCostMappingForGivenVendorName(subWorkStreamOtherCostList, unitCostMappingView,currencyCode);
            Tuple2<BigDecimal,BigDecimal> bigDecimalTuple2 = getUnitCostOverAllTotal(subWorkStreamIdAndNames,subWorkStreamOtherCostList.get(0).getVendorName(),scenario,currencyCode);
            unitCostMappingView.setYearlyCostOverAllTotal(bigDecimalTuple2._1);
            unitCostMappingView.setCostOverAllTotal(bigDecimalTuple2._1);
            unitCostMappingView.setYearlyUnitOverAllTotal(null);
            costLists.add(unitCostMappingView);
        });

        return costLists;
    }

    public List<UnitCostMappingView> getOtherResourceByQuarterly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String year,String scenario,String currencyCode) {

        List<UnitCostMappingView> costMappingViewList = Lists.newArrayList();
        Map<Integer, List<SubWorkstreamOtherCost>> othersListByRefSurrIdByVendorName = getSubWorkStreamOtherCostsListByPeriod(
                subWorkStreamIdAndNames, PortfolioConstants.RESOURCE_TYPE, year,scenario).stream().collect(
                Collectors.groupingBy(SubWorkstreamOtherCost::getCapexOpexSurrId));
        othersListByRefSurrIdByVendorName.forEach((refSurrId, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setName(PortfolioConstants.OTHER_RESOURCE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setRefSurrId(subWorkStreamOtherCostList.get(0).getCapexOpexSurrId());
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.QUARTERLY);
            List<BigDecimal> othersQuarterlyList = getOthersQuarterlyList(subWorkStreamOtherCostList,currencyCode);
            unitCostMappingView.setQuarterlyCostTotal(othersQuarterlyList);
            unitCostMappingView.setQuarterlyUnitTotal(null);
            BigDecimal yearlyCostOverAllTotal = BigDecimal.ZERO;

                    if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)){
                        for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                            yearlyCostOverAllTotal = yearlyCostOverAllTotal.add(subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamIdAndName.getSubWorkStreamId(),
                                    subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.RESOURCE_TYPE, GeneUtils.getGlCategoriesNotInclude()));
                        }
                    }else{
                        for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                            yearlyCostOverAllTotal = yearlyCostOverAllTotal.add(subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamIdAndName.getSubWorkStreamId(),
                                    subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.RESOURCE_TYPE, GeneUtils.getGlCategoriesNotInclude()));
                        }
                    }
            unitCostMappingView.setCostOverAllTotal(yearlyCostOverAllTotal);
            unitCostMappingView.setYearlyCostOverAllTotal(yearlyCostOverAllTotal);

            costMappingViewList.add(unitCostMappingView);
        });
        return costMappingViewList;
    }

    public List<UnitCostMappingView> getOthersSoftwareByYearly(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String year, String scenario,String currencyCode) {

        List<UnitCostMappingView> unitCostMappingViewArrayList = new ArrayList<>();
        Map<Integer,List<SubWorkstreamOtherCost>> subWorkStreamOthersListMap = getSubWorkStreamOtherCostsListByPeriod(subWorkStreamIdAndNames,
                PortfolioConstants.SOFTWARE_TYPE, year,scenario).stream().collect(Collectors.groupingBy(SubWorkstreamOtherCost::getRefSwsOtherSurrId));
        subWorkStreamOthersListMap.forEach((integer, subWorkStreamOtherCostList) -> {
            UnitCostMappingView unitCostMappingView = new UnitCostMappingView();
            unitCostMappingView.setName(PortfolioConstants.OTHER_SOFTWARE +" "+ subWorkStreamOtherCostList.get(0).getVendorName());
            //TODO set currencytype, currencyvalue
            unitCostMappingView.setCurrencyCode(currencyCode);
            unitCostMappingView.setCurrencyValue(PortfolioConstants.DEFAULT_CCY_VALUE);
            unitCostMappingView.setPeriodType(PortfolioConstants.YEARLY);
            BigDecimal yearlyTotal = BigDecimal.ZERO;
            for (SubWorkstreamOtherCost subWorkstreamOtherCost : subWorkStreamOtherCostList) {
                yearlyTotal = yearlyTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)
                        ? subWorkstreamOtherCost.getGroupCcyVal():subWorkstreamOtherCost.getLocalCcyVal());
            }

            unitCostMappingView.addYearlyCostTotal(yearlyTotal);
            unitCostMappingView.setYearlyUnitTotal(null);
            BigDecimal yearlyCostOverAllTotal =BigDecimal.ZERO;

            //unitCostMappingView.addYearlyUnitTotal(null);
            if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)){
                for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                    yearlyCostOverAllTotal = yearlyCostOverAllTotal.add(subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndGrpCcy(subWorkStreamIdAndName.getSubWorkStreamId(),
                            subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.SOFTWARE_TYPE, GeneUtils.getGlCategoriesNotInclude()));
                }

            }else{
                for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
                    yearlyCostOverAllTotal = yearlyCostOverAllTotal.add(subWorkstreamOtherCostRepo.getTotalOthersCostByTypeAndLocalCcy(subWorkStreamIdAndName.getSubWorkStreamId(),
                            subWorkStreamIdAndName.getSubWorkStreamName(), scenario, PortfolioConstants.SOFTWARE_TYPE, GeneUtils.getGlCategoriesNotInclude()));
                }
            }

            unitCostMappingView.setYearlyCostOverAllTotal(yearlyCostOverAllTotal);
            unitCostMappingViewArrayList.add(unitCostMappingView);
        });
        return unitCostMappingViewArrayList;
    }

    public BigDecimal getOthersByYearlySum(String subWorkStreamId, String subWorkStreamName, String scenario, String year, String type,String currencyCode) {
        List<String> glCategories = new ArrayList<>();
        glCategories.add(PortfolioConstants.ITDEPRECIATION);
        glCategories.add(PortfolioConstants.OWNERSHIP);
        return  PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                subWorkstreamOtherCostRepo.getOthersTotalByYearAndGrpCcy(subWorkStreamId,subWorkStreamName,scenario,year,type,glCategories)
                : subWorkstreamOtherCostRepo.getOthersTotalByYearAndLocalCcy(subWorkStreamId,subWorkStreamName,scenario,year,type,glCategories);
    }
}
