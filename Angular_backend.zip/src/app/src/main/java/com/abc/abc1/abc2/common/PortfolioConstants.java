package com.dbs.genesis.portfolio.common;

public final class PortfolioConstants {


    public static final String PORTFOLIONAME = "Portfolio";
    public static final String WORKSTREAMNAME = "Workstream";
    public static final String SUBWORKSTREAMNAME = "SubWorkstream";
    public static final String COUNTRY = "country";
    public static final String GL_CATEGORY_REF_DATA = "GL Category";
    public static final String COST_SETTINGS = "Cost Settings";
    public static final String country = "country";
    public static final String DEFAULT_GROUP_CURRENCY_CODE_SGD = "SGD";
    public static final String defaultRateType = "budget";
    public static final String defaultBudgetStatus = "B2020";
    public static final String firstQuarterlyList = "01,02,03";
    public static final String secondQuarterlyList = "04,05,06";
    public static final String thirdQuarterlyList = "07,08,09";
    public static final String fourthQuarterlyList = "10,11,12";
    public static final String defaultMonthValue = "01,02,03,04,05,06,07,08,09,10,11,12";
    public static final String CURRENCY_CODE_TYPE_LOCAL = "local";
    public static final String CURRENCY_CODE_TYPE_GLOBAL = "global";
    public static final String COST_SETTING_TYPE_HLE = "HLE";
    public static final String COST_SETTING_TYPE_SEED_FUNDING = "Seed Funding";
    public static final String COST_TYPE = "Cost Type";
    public static final String TEAM_ROLE = "Team Role";
    public static final String FD_MAN_DAYS_PER_MONTH = "FD_Mandays per month";
    public static final String DEFAULT_SEED_FUNDING_CATEGORY = "OPEX";
    public static final String MONTHLY = "monthly";
    public static final String QUARTERLY = "quarterly";
    public static final String YEARLY = "yearly";
    public static final String SCENARIO = "Forecast/Actual";
    public static final String SCENARIO_FORECAST = "Forecast";
    public static final String YES = "YES";
    public static final String NO = "NO";
    public static final String OPEX = "OPEX";
    public static final String CAPEX = "CAPEX";
    public static final String OWNERSHIP = "Ownership";
    public static final String ITDEPRECIATION = "IT Depreciation";
    public static final String SOFTWARE_TYPE_PERPETUAL = "Perpetual";
    public static final String COST_SETTING_TYPE_FINANCIAL_DETAILS = "Financial Details";
    public static final String FALSE = "false";
    public static final String TRUE = "true";
    public static final String CREATE = "CREATE";
    public static final String UPDATE = "UPDATE";
    public static final String INACTIVE = "INACTIVE";
    public static final String SOFTWARE_TYPE = "Software";
    public static final String HARDWARE_TYPE = "Hardware";
    public static final String RESOURCE_TYPE = "Resource";
    public static final String OTHERS_TYPE = "Others";
    public static final String MON_01 = "01";
    public static final String MON_02 = "02";
    public static final String MON_03 = "03";
    public static final String MON_04 = "04";
    public static final String MON_05 = "05";
    public static final String MON_06 = "06";
    public static final String MON_07 = "07";
    public static final String MON_08 = "08";
    public static final String MON_09 = "09";
    public static final String MON_10 = "10";
    public static final String MON_11 = "11";
    public static final String MON_12 = "12";
    public static final String BUDGET_STATUS = "Budget Status";
    public static final String SYSTEM_CONFIGURATION = "System Configuration";
    public static final String OTHER_HARDWARE = "Other Hardware";
    public static final String OTHER_SOFTWARE = "Other Software";
    public static final String OTHER_RESOURCE = "Other Resource";
    public static final String ORIGINAL_INDICATOR_TRUE = "true";
    public static final String ORIGINAL_INDICATOR_FALSE = "false";
    public static final String ADD_SOFTWARE_PQ = "Software (PxQ)";
    public static final String ADD_HARDWARE_PQ = "Hardware (PxQ)";
    public static final String ADD_OTHER_SOFTWARE = "Other Software";
    public static final String ADD_OTHER_HARDWARE = "Other Hardware";
    public static final String ADD_OTHER_RESOURCE = "Other Resource";
    public static final String ADD_OTHER_OTHERS = "Others";
    public static final String ADD_RESOURCE = "Resource";


    public static final String REF_DATA_SYSTEM_CONFIG = "System Configuration";
    public static final String REF_DATA_GRP_CCY = "Group Currency";
    public static final String REF_DATA_EDIT_TIME_OUT = "Edit Log Timeout mins";
    public static final String RESOURCE = "Resource";
    public static final String SOFTWARE = "Software";
    public static final String HARDWARE = "Hardware";
    public static final String OTHERS = "Others";

    public static final String FINANCIAL_SUMMARY = "FINANCIAL SUMMARY";

    public static final String ACTIVE_COPY_SCENARIO = "Active";
    public static final String PORTFOLIO_COPY_SCENARIO = "Portfolio";
    public static final String WORKSTREAM_COPY_SCENARIO = "WorkStream";
    public static final String APPROVER_ACTION_APPROVAL = "Approval";
    public static final String APPROVER_ACTION_PENDING = "Pending";
    public static final String COPY_SCENARIO_FILE_UPLOAD_TYPE_OTHERS = "Others";
    public static final String ACTUAL_PERIOD = "actualPeriod";
    public static final String MONTHS_BETWEEN_DATES = "monthsBetweenDates";
    public static final String AGILE = "Agile";
    public static final String WATERFALL = "Waterfall";

    public static final String PROC_COST_COMP_HLE_FD = "HLE/FD";
    public static final String PROC_COST_COMP_RESOURCE = "Resource Cost";
    public static final String PROC_COST_COMP_SOFTWARE = "Software Cost";
    public static final String PROC_COST_COMP_HARDWARE = "Hardware Cost";
    public static final String PROC_COST_COMP_OTHER = "Other Cost";

    public static final String RATE_INDICATOR_BLENDED = "Blended";

    public static final String DEFAULT_CCY_VALUE = "0000";
    public static final String PF_LIST_ROLES = "Non Portfolio Listing Roles";

    public static final String GL_CATEGORY_OPEX = "Opex";
    public static final String GL_CATEGORY_CAPEX = "Capex";
    public static final String GL_CATEGORY_OWNERSHIP = "Ownership";
    public static final String GL_CATEGORY_ITDEPRECIATION = "IT Depreciation";
    public static final String RESOURCE_TYPE_IC = "IC";

    public static final String BUILD = "build";
    public static final String DEFAULT_SWS = "SWS0";
    public static final String DEFAULT_WS = "WS0";
    public static final String HYPHEN = "-";

    public static final String TECH = "Tech";
    public static final String PTFM_NP = "NP";
    public static String COST_TYPE_DETAIL_ACTUAL = "Actual";
    public static final String COPY_SCENARIO_BUDGET_NEXTYEAR = "Budget_NextYear";
    public static final String COPY_SCENARIO_PENDING_APPROVAL_POSTFIX = "_Pending Approval";
    public static final String COPY_SCENARIO_APPROVED_POSTFIX = "_Approved";
}
