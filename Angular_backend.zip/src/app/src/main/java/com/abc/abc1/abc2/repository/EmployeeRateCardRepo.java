package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.EmployeeRateCardEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface EmployeeRateCardRepo extends JpaRepository<EmployeeRateCardEntity, Integer> {

    @Query("SELECT DISTINCT e.countryCode FROM EmployeeRateCardEntity e order by e.countryCode")
    List<String> findDistinctCountryCodes();

    @Query("SELECT DISTINCT e.ccyCode FROM EmployeeRateCardEntity e order by e.ccyCode")
    List<String> findDistinctCurrencyCodes();

    @Query("SELECT DISTINCT e.staffTypeGene FROM EmployeeRateCardEntity e order by e.staffTypeGene")
    List<String> findDistinctStaffTypes();

    @Query("SELECT DISTINCT e.vendorCode FROM EmployeeRateCardEntity e order by e.vendorCode")
    List<String> findDistinctVendorCodes();

    @Query("SELECT DISTINCT e.rateSource FROM EmployeeRateCardEntity e order by e.rateSource")
    List<String> findDistinctRateSources();

    @Query("SELECT DISTINCT e.rateLevel FROM EmployeeRateCardEntity e order by e.rateLevel")
    List<String> findDistinctRateLevels();

    @Query("select erc.staffRate from EmployeeRateCardEntity erc where erc.countryCode = :countryCode and \n" +
            "erc.ccyCode = :ccyCode and erc.staffTypeGene = :staffTypeGene and erc.vendorCode = :vendorCode and \n" +
            "erc.rateSource = :rateSource and erc.rateLevel = :rateLevel and erc.rateInd = :rateInd")
    BigDecimal getStaffRate(@Param("countryCode") String countryCode, @Param("ccyCode") String ccyCode, @Param("staffTypeGene") String staffTypeGene,
                            @Param("vendorCode") String vendorCode, @Param("rateSource") String rateSource, @Param("rateLevel") String rateLevel, @Param("rateInd") String rateInd);

}
