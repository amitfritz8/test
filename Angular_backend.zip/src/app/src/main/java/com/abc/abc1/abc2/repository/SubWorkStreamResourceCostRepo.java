package com.dbs.genesis.portfolio.repository;


import com.dbs.genesis.portfolio.model.SubWorkStreamResourceCost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Set;

public interface SubWorkStreamResourceCostRepo extends JpaRepository<SubWorkStreamResourceCost, Integer> {

    List<SubWorkStreamResourceCost> findAllByRefSwsResourceSurrIdIn(List<Integer> refSurrIds);

    List<SubWorkStreamResourceCost>
    findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndResourceTypeAndActiveIndAndOriginalInd(
            String subWorkStreamId, String subWorkStreamName, String scenario, String resourceType,
            String activeInd, String originalInd);

    @Query(value = "FROM SubWorkStreamResourceCost e where " +
            "e.swsResourceSurrId IN (:swsResourceSurrId) or e.refSwsResourceSurrId IN (:refSwsResourceSurrId)")
    List<SubWorkStreamResourceCost> findAllByParentOrChildIdIn(
            @Param("swsResourceSurrId") Set<Integer> swsResourceSurrId,
            @Param("refSwsResourceSurrId") Set<Integer> refSwsResourceSurrId);


    @Query (value="select * " +
            " from sub_workstream_resource_cost a, sub_workstream_dates b \n" +
            " where a.sub_workstream_id=b.sub_workstream_id \n" +
            " and a.sub_workstream_name=b.sub_workstream_name \n" +
            " and a.scenario=b.scenario_name " +
            " and a.sub_workstream_id = :subWorkStreamId \n" +
            " and a.sub_workstream_name = :subWorkStreamName \n" +
            " and a.scenario = :scenario \n" +
            " and a.active_ind=:activeInd " +
            " and original_ind=:originalInd \n" +
            " and gl_category = if(period between date_format(start_date,'%Y%m') and " +
            " date_format(date_add(sw_eng_start_date,interval -1 month),'%Y%m'),'Opex', \n" +
            " if(period between date_format(sw_eng_start_date,'%Y%m') and date_format(go_live_date,'%Y%m')," +
            "'Capex','Opex')) and substr(period, 1, 4)=:period order by period", nativeQuery = true)
    List<SubWorkStreamResourceCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotInAndPeriodNative(
            @Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName,
            @Param("scenario") String scenario, @Param("activeInd") String activeInd,
            @Param("originalInd") String originalInd, @Param("period") String period);

    /*@Query (value="", nativeQuery = true)
    FinancialSummaryResource findGrandTotalOfResourceBasedOnUniqueIdentifierNative(
            @Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName,
            @Param("scenario") String scenario, @Param("teamRole") String teamRole,
            @Param("location") String location, @Param("staffType") String staffType,
            @Param("vendor") String company, @Param("rateSource") String rateSource, @Param("level") String level);

     */

    List<SubWorkStreamResourceCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotInAndPeriodContaining(
            String subWorkStreamId, String subWorkStreamName, String scenario,String activeInd,String originalInd, List<String> glCategory, String period);

    List<SubWorkStreamResourceCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalInd(
            String subWorkStreamId, String subWorkStreamName, String scenario, String activeInd, String originalInd);

//    List<SubWorkStreamResourceCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndResourceTypeAndActiveIndAndOriginalInd(
//            String subWorkStreamId, String subWorkStreamName, String scenario, String vendorName,String activeInd,String orgInd);

    @Query(value = " SELECT DISTINCT substring(e.period,1,4) FROM sub_workstream_resource_cost e where e.sub_workstream_id = :subWorkStreamId and e.sub_workstream_name = :subWorkStreamName and " +
            " scenario = :scenario and active_ind='true' and original_ind='false' and period is not null" +
            " union SELECT DISTINCT substring(e.period,1,4) FROM sub_workstream_other_cost e where e.sub_workstream_id = :subWorkStreamId and e.sub_workstream_name = :subWorkStreamName and " +
            " e.scenario = :scenario and e.type = 'resource' and period is not null and original_ind='false' and active_ind='true' " +
            " UNION SELECT DISTINCT substring (vwr.period,1,4) FROM VW_SWS_RESOURCE_COST vwr WHERE vwr.sub_workstream_id=:subWorkStreamId and vwr.sub_workstream_name= :subWorkStreamName " +
            " and vwr.scenario = :scenario and vwr.period is not null union " +
            "SELECT DISTINCT substring (vwso.period,1,4) FROM VW_SWS_OTHER_COST vwso WHERE vwso.sub_workstream_id=:subWorkStreamId and vwso.sub_workstream_name= :subWorkStreamName " +
            " and vwso.scenario = :scenario and vwso.period is not null" +
            " ",nativeQuery = true)
    List<String> findDistinctOfPeriodsFromSoftwareCostAndOtherSoftwareCost(@Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName,@Param("scenario")  String scenario);


    Integer deleteAllByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndScenario(
            String workStreamId, String subWorkStreamId, String SubWorkStreamName ,String scenario);

    @Query(value = " SELECT DISTINCT substring(e.period,1,4) FROM sub_workstream_resource_cost e where e.sub_workstream_id = :subWorkStreamId " +
            " and e.sub_workstream_name = :subWorkStreamName and scenario=:scenario and period is not null and active_ind='true' and original_ind='false' ",nativeQuery = true)
    List<String> findDistinctOfPeriodsFromResourceCost(@Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName, @Param("scenario") String scenario);

    SubWorkStreamResourceCost findByScenarioAndCapexOpexSurrIdAndGlCategoryAndOriginalIndAndActiveInd(String scenario,Integer refSurrId, String ownership, String originalInd, String activeInd);

    @Query(value = "select * from sub_workstream_resource_cost where sub_workstream_id = :subWorkstreamId and sub_workstream_name = :subWorkStreamName and resource_type =:resourceType" +
            " and scenario =:scenario and gl_category =:glCategory and location =:location and staff_type = :staffType and vendor=:vendor and rate_source =:rateSource " +
            "and staff_level = :staffLevel and team_role =:teamRole and original_ind = 'true' and active_ind = 'true' ",nativeQuery = true)
    SubWorkStreamResourceCost findParentOwnership(String subWorkstreamId,String subWorkStreamName,String resourceType,String scenario,String glCategory,String location,String staffType
            ,String vendor,String rateSource,String staffLevel,String teamRole);

    List<SubWorkStreamResourceCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndGlCategoryAndRefSwsResourceSurrIdAndPeriodInAndActiveIndAndOriginalInd(String subWorkstreamId, String subWorkstreamName, String scenario, String ownership, Integer refSurrId, List<String> ownerShipPeriods, String aTrue, String aFalse);

    List<SubWorkStreamResourceCost> findAllByWorkStreamIdAndSubWorkStreamIdInAndScenario(
            String workStreamId, List<String> subWorkStreamIds, String scenario);

    Integer deleteAllByWorkStreamIdAndSubWorkStreamIdAndScenarioIn(
            String workStreamId, String subWorkStreamId, List<String> scenarios);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update SubWorkStreamResourceCost rsCost set rsCost.scenario =:approvalScenario " +
            "where rsCost.workStreamId in (:workStreamIds) and rsCost.scenario=:scenario")
    Integer updateApprovalScenarioForWorkStreamsAndScenario(@Param("workStreamIds") List<String> workStreamIds,
                                                            @Param("scenario") String scenario,
                                                            @Param("approvalScenario") String approvalScenario);
}
