package com.dbs.genesis.portfolio.repository;


import com.dbs.genesis.portfolio.model.WorkStreamEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkStreamRepo extends JpaRepository<WorkStreamEntity, String> {

    List<WorkStreamEntity> findByOrderByPortfolioIdDesc();

    WorkStreamEntity findByWorkStreamId(String workStreamId);

    @Query("select distinct w.country from WorkStreamEntity w")
    List<String> findAllCountryFromWorkStream();

    boolean existsByWorkStreamNameAndPortfolioId(String workStreamName, String portfolioId);

    @Query(value = "select * from workstream_profile where workstream_id in (" +
            "select distinct a.workstream_id from workstream_profile a,work_hierarchy b,sub_workstream_fin_details c where" +
            "  c.scenario=?1 and" +
            "  c.sub_workstream_id=b.sub_workstream_id" +
            "  and b.workstream_id =a.workstream_id);",nativeQuery = true)
    List<WorkStreamEntity> findAllByCategory(String category);

    @Query(value = "select distinct  b.* from sub_workstream_dates a,workstream_profile b,portfolio_profile c, portfolio_managers m" +
            " where a.scenario_name = ?1 and a.workstream_id = b.workstream_id and b.portfolio_id = c.portfolio_id and m.portfolio_id = b.portfolio_id" +
            "       and ((c.primary_platform_index in (?2) and b.country in (?3) and m.1bank_id = ?4 and m.active_ind='true') or (m.1bank_id=?4 and m.active_ind='true')) ",nativeQuery = true)
    List<WorkStreamEntity> findAllByOneBankIdAndPortfolio(String scenario, List<String> platform, List<String> locations, String oneBankId);

    @Query(value = "select distinct b.* from sub_workstream_dates a,workstream_profile b,portfolio_profile c, workstream_managers w" +
            " where a.scenario_name = ?1 and a.workstream_id = b.workstream_id and b.portfolio_id = c.portfolio_id and w.portfolio_id = b.portfolio_id" +
            " and((c.primary_platform_index in (?2) and b.country in (?3) and w.1bank_id = ?4 and w.active_ind = 'true') or (w.1bank_id = ?4 and w.active_ind = 'true'))",nativeQuery = true)
    List<WorkStreamEntity> findAllByOneBankIdAndWorkStream(String scenario, List<String> platform, List<String> locations, String oneBankId);


    @Query(value = "select distinct b.* from sub_workstream_dates a,workstream_profile b,portfolio_profile c " +
            "where a.scenario_name = ?1 and a.workstream_id = b.workstream_id and b.portfolio_id = c.portfolio_id " +
            "and c.primary_platform_index in (?2) and b.country in (?3)",nativeQuery = true)
    List<WorkStreamEntity> findAllByScenarioPlatformAndCountry(String scenario, List<String> platform, List<String> locations);


    @Query(value = "select distinct  b.* from sub_workstream_dates a,workstream_profile b,portfolio_profile c, portfolio_managers m" +
            " where a.scenario_name = ?1 and a.workstream_id = b.workstream_id and b.portfolio_id = c.portfolio_id and m.portfolio_id = b.portfolio_id" +
            "       and ((c.primary_platform_index in (?2) and b.country in (?3) and m.1bank_id = ?4 and m.active_ind='true') or (m.1bank_id=?4 and m.active_ind='true'))" +
            "UNION " +
            "select distinct b.* from sub_workstream_dates a,workstream_profile b,portfolio_profile c, workstream_managers w" +
            " where a.scenario_name = ?1 and a.workstream_id = b.workstream_id and b.portfolio_id = c.portfolio_id and w.portfolio_id = b.portfolio_id" +
            " and((c.primary_platform_index in (?2) and b.country in (?3) and w.1bank_id = ?4 and w.active_ind = 'true') or (w.1bank_id = ?4 and w.active_ind = 'true'))",nativeQuery = true)
    List<WorkStreamEntity> findAllByOneBankIdAndPortfolioAndWorkstreamListing(String scenario, List<String> platform, List<String> locations, String oneBankId);
}
