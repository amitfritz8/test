package com.dbs.genesis.portfolio.model;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;


@Data
@Entity
@Table(name = "xref_platform_stakeholders")
@EntityListeners(AuditingEntityListener.class)
public class PlatformStakeHolders extends CommonEntity<String> {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ps_id")
	private Integer psId;
	@Column(name = "platform_index")
	private String platformIndex;
	@Column(name = "biz_tech_ind")
	private String bizTechInd;
	@Column(name = "country_code")
	private String countryCode;
	@Column(name = "platform_role")
	private String platformRole;
	@Column(name = "lead_delegate_ind")
	private String leadDelegateInd;
	@Column(name = "1bank_id")
	private String oneBankId;
	@Column(name = "emp_name")
	private String empName;
	@Column(name = "effective_end_date")
	private String effectiveEndDate;

}
