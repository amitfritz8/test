package com.dbs.genesis.portfolio.model.copyscenario;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class SubWorkStreamResourceCostCopyHolder {

    private List<SubWorkStreamResourceOpexCopyHolder> resourceOpexCopyHolders =
            new ArrayList<>();

    private List<SubWorkStreamResourceCapexCopyHolder> resourceCapexCopyHolders =
            new ArrayList<>();
}
