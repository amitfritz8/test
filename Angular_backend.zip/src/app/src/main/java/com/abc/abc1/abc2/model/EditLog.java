package com.dbs.genesis.portfolio.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@Table(name = "edit_log")
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EditLog extends CommonEntity<String>{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "edit_id")
    private Long editId;

    @Column(name = "portfolio_id")
    private String portfolioId;

    @Column(name = "portfolio_type")
    private String portfolioType;

    @Column(name = "portfolio_name")
    private String portfolioName;

    @Column(name = "staff_display_name")
    private String staffDisplayName;

    public EditLog(String portfolioId,String portfolioType,String portfolioName,String staffDisplayName){
        this.portfolioId = portfolioId;
        this.portfolioType = portfolioType;
        this.portfolioName = portfolioName;
        this.staffDisplayName = staffDisplayName;
    }


}
