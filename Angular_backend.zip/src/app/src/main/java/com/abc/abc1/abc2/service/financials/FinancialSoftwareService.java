package com.dbs.genesis.portfolio.service.financials;

import com.amazonaws.util.CollectionUtils;
import com.dbs.genesis.portfolio.common.DateExtensions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.repository.SubWorkStreamKeyDatesRepo;
import com.dbs.genesis.portfolio.repository.SubWorkstreamSoftwareCostRepo;
import com.dbs.genesis.portfolio.resources.MonthlyCostTypeData;
import com.dbs.genesis.portfolio.resources.MonthlyFinancialDetailsResource;
import com.dbs.genesis.portfolio.resources.MonthlyFinancialResource;
import com.dbs.genesis.portfolio.service.SubWorkStreamService;
import com.dbs.genesis.portfolio.service.costsettings.FinancialDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class FinancialSoftwareService implements DateExtensions {

    private final SubWorkstreamSoftwareCostRepo subWorkstreamSoftwareCostRepo;
    private final FinancialDetailsService financialDetailsService;
    private final FinancialOthersService financialOthersService;
    private SubWorkStreamService subWorkStreamService;
    private SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    private final PortfolioRepository portfolioRepository;
    private FinancialService financialService;

    public FinancialSoftwareService(SubWorkstreamSoftwareCostRepo subWorkstreamSoftwareCostRepo, FinancialDetailsService financialDetailsService, FinancialOthersService financialOthersService, SubWorkStreamService subWorkStreamService, SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo, PortfolioRepository portfolioRepository, FinancialService financialService) {
        this.subWorkstreamSoftwareCostRepo = subWorkstreamSoftwareCostRepo;
        this.financialDetailsService = financialDetailsService;
        this.financialOthersService = financialOthersService;
        this.subWorkStreamService = subWorkStreamService;
        this.subWorkStreamKeyDatesRepo = subWorkStreamKeyDatesRepo;
        this.portfolioRepository = portfolioRepository;
        this.financialService = financialService;
    }

    public void persistSoftware(MonthlyFinancialResource monthlyFinancialResource, MonthlyFinancialDetailsResource financialDetail, String year) {
         financialDetail.getMonthlyCostTypeDataList().stream().forEach(monthlySoftware -> {
            if(monthlySoftware.getName().startsWith(PortfolioConstants.OTHER_SOFTWARE)){
                 financialOthersService.persistOthersIndividual(monthlyFinancialResource, monthlySoftware, year);
            }else{
                SubWorkstreamSoftwareCost subWorkstreamSoftwareCost = subWorkstreamSoftwareCostRepo.findById(monthlySoftware.getSurrId()).get();
                List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCosts = getSoftwareCostEntity(subWorkstreamSoftwareCost,monthlyFinancialResource, monthlySoftware, year);
                subWorkstreamSoftwareCostRepo.saveAll(subWorkstreamSoftwareCosts);
                if(PortfolioConstants.OPEX.equalsIgnoreCase(subWorkstreamSoftwareCost.getGlCategory())){
                    List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCostOwnerships = createSubWorkstreamSoftwareCostsOwnershipForMonthly(
                            subWorkstreamSoftwareCosts,monthlyFinancialResource.getSubWorkStreamId(),
                            monthlyFinancialResource.getSubWorkStreamName(),monthlyFinancialResource.getScenario(),monthlySoftware.getSurrId());
                    subWorkstreamSoftwareCostRepo.saveAll(subWorkstreamSoftwareCostOwnerships);
                }else{
                    saveItDepreciation(monthlySoftware,monthlyFinancialResource.getCurrencyCode(),monthlyFinancialResource.getCurrencyCodes(),monthlyFinancialResource.getScenario());
                }
            }

        });
    }

    private List<SubWorkstreamSoftwareCost> getSoftwareCostEntity(SubWorkstreamSoftwareCost subWorkstreamSoftwareCostParent,MonthlyFinancialResource monthlyFinancialResource, MonthlyCostTypeData monthlySoftware, String year) {

        List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCosts = monthlySoftware.getMonthlyData().stream().map(monthlyData -> {
            if (monthlyData.getSurrId() == null || monthlyData.getSurrId().intValue() == 0) {
                SubWorkstreamSoftwareCost newSubWorkStreamSoftwareCost = getNewSoftwareMonthlyData(subWorkstreamSoftwareCostParent, monthlyFinancialResource.getScenario()
                        , PortfolioConstants.ORIGINAL_INDICATOR_FALSE, monthlyData.getMonthNumber(), year);
                updateCurrencyValuesForSoftware(newSubWorkStreamSoftwareCost, monthlyFinancialResource.getCurrencyCode(),
                        subWorkstreamSoftwareCostParent.getUnitPrice(), monthlyData.getUnit(), monthlyFinancialResource.getCurrencyCodes());
                return newSubWorkStreamSoftwareCost;
            } else {
                SubWorkstreamSoftwareCost existingSubWorkStreamSoftwareCost = subWorkstreamSoftwareCostRepo.findById(monthlyData.getSurrId()).get();
                updateCurrencyValuesForSoftware(existingSubWorkStreamSoftwareCost, monthlyFinancialResource.getCurrencyCode(),
                        subWorkstreamSoftwareCostParent.getUnitPrice(), monthlyData.getUnit(), monthlyFinancialResource.getCurrencyCodes());
                return existingSubWorkStreamSoftwareCost;
            }
        }).collect(Collectors.toList());
        return subWorkstreamSoftwareCosts;
    }

    private SubWorkstreamSoftwareCost getNewSoftwareMonthlyData(SubWorkstreamSoftwareCost subWorkstreamSoftwareCost, String scenario,
                                                                String orgInd, String month, String year) {
        SubWorkstreamSoftwareCost newSubWorkStreamSoftwareCost = new SubWorkstreamSoftwareCost();
        newSubWorkStreamSoftwareCost.setWorkStreamId(subWorkstreamSoftwareCost.getWorkStreamId());
        newSubWorkStreamSoftwareCost.setSubWorkStreamId(subWorkstreamSoftwareCost.getSubWorkStreamId());
        newSubWorkStreamSoftwareCost.setSubWorkStreamName(subWorkstreamSoftwareCost.getSubWorkStreamName());
        newSubWorkStreamSoftwareCost.setGlCategory(subWorkstreamSoftwareCost.getGlCategory());
        newSubWorkStreamSoftwareCost.setCostSettings(subWorkstreamSoftwareCost.getCostSettings());
        newSubWorkStreamSoftwareCost.setVendorName(subWorkstreamSoftwareCost.getVendorName());
        newSubWorkStreamSoftwareCost.setSoftwareName(subWorkstreamSoftwareCost.getSoftwareName());
        newSubWorkStreamSoftwareCost.setSoftwareType(subWorkstreamSoftwareCost.getSoftwareType());
        newSubWorkStreamSoftwareCost.setAdd_software(subWorkstreamSoftwareCost.getAdd_software());
        newSubWorkStreamSoftwareCost.setActiveInd(subWorkstreamSoftwareCost.getActiveInd());
        newSubWorkStreamSoftwareCost.setScenario(scenario);
        newSubWorkStreamSoftwareCost.setUnitPrice(subWorkstreamSoftwareCost.getUnitPrice());
        newSubWorkStreamSoftwareCost.setSoftwareDesc(subWorkstreamSoftwareCost.getSoftwareDesc());
        newSubWorkStreamSoftwareCost.setOriginalInd(orgInd);
        newSubWorkStreamSoftwareCost.setRefSwsSwSurrId(subWorkstreamSoftwareCost.getSwsSwSurrId());
        newSubWorkStreamSoftwareCost.setPeriod(year + month);
        return newSubWorkStreamSoftwareCost;
    }

    public void updateCurrencyValuesForSoftware(SubWorkstreamSoftwareCost subWorkstreamSoftwareCost,
                                                String currencyCode,
                                                BigDecimal unitPrice, BigDecimal quantity, HashSet<String> currencyCodes) {
        if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode))
            updateCurrencyValuesForGroupForSoftware(subWorkstreamSoftwareCost, currencyCode, unitPrice, quantity, currencyCodes);
        else
            updateCurrencyValuesForLocalForSoftware(subWorkstreamSoftwareCost, currencyCode, unitPrice, quantity, currencyCodes);
    }

    private SubWorkstreamSoftwareCost
    updateCurrencyValuesForLocalForSoftware(SubWorkstreamSoftwareCost subWorkstreamSoftwareCost,
                                            String currencyCode,
                                            BigDecimal unitPrice, BigDecimal quantity,
                                            HashSet<String> currencyCodes) {
        subWorkstreamSoftwareCost.setQuantity(quantity);
        subWorkstreamSoftwareCost.setCostPerMonthLcy(quantity.multiply(unitPrice));
        subWorkstreamSoftwareCost.setLocalCcy(currencyCode);
        currencyCodes.remove(currencyCode);
        if (!currencyCodes.isEmpty()) {
            subWorkstreamSoftwareCost.setGroupCcy(currencyCodes.iterator().next());
            subWorkstreamSoftwareCost.setCostPerMonthGcy(quantity.multiply(unitPrice.multiply(financialDetailsService.getExchangeValue
                    (subWorkstreamSoftwareCost.getPeriod(), currencyCode, subWorkstreamSoftwareCost.getWorkStreamId()))));
        } else {
            subWorkstreamSoftwareCost.setGroupCcy(currencyCode);
            subWorkstreamSoftwareCost.setCostPerMonthGcy(quantity.multiply(unitPrice));
        }
        return subWorkstreamSoftwareCost;
    }

    private SubWorkstreamSoftwareCost
    updateCurrencyValuesForGroupForSoftware(SubWorkstreamSoftwareCost subWorkstreamSoftwareCost,
                                            String loggedInCurrencyCode,
                                            BigDecimal unitPrice, BigDecimal quantity,
                                            HashSet<String> currencyCodes) {
        subWorkstreamSoftwareCost.setQuantity(quantity);
        subWorkstreamSoftwareCost.setCostPerMonthGcy(quantity.multiply(unitPrice));
        subWorkstreamSoftwareCost.setGroupCcy(loggedInCurrencyCode);
        currencyCodes.remove(loggedInCurrencyCode);
        if (!currencyCodes.isEmpty()) {
            subWorkstreamSoftwareCost.setLocalCcy(currencyCodes.iterator().next());
            BigDecimal exchangedValue = financialDetailsService.getExchangeValue
                    (subWorkstreamSoftwareCost.getPeriod(), subWorkstreamSoftwareCost.getLocalCcy(), subWorkstreamSoftwareCost.getWorkStreamId());
            subWorkstreamSoftwareCost.setCostPerMonthLcy(quantity.multiply(unitPrice.divide(exchangedValue, 9, RoundingMode.HALF_UP)));
        } else {
            subWorkstreamSoftwareCost.setLocalCcy(loggedInCurrencyCode);
            subWorkstreamSoftwareCost.setCostPerMonthLcy(quantity.multiply(unitPrice));
        }
        return subWorkstreamSoftwareCost;
    }

    public List<SubWorkstreamSoftwareCost> createSubWorkstreamSoftwareCostsOwnershipForMonthly(List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCosts,
                                                                                               String subWorkstreamId,String subWorkstreamName,String scenario,Integer refSurrId) {
        SubWorkstreamSoftwareCost subWorkstreamSoftwareCostOwnershipParent = subWorkstreamSoftwareCostRepo.findByScenarioAndCapexOpexSurrIdAndGlCategoryAndOriginalIndAndActiveInd(
                scenario,refSurrId,PortfolioConstants.OWNERSHIP,PortfolioConstants.TRUE,PortfolioConstants.TRUE);
        Date ownerShipDate = financialService.startingOwnershipPeriod(subWorkstreamId,subWorkstreamName,scenario);
        List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCostsToSave = subWorkstreamSoftwareCosts.stream().filter(subWorkstreamSoftwareCost ->
                financialService.checkOwnershipDate(ownerShipDate,subWorkstreamSoftwareCost.getPeriod()))
                .map(subWorkstreamSoftwareCost -> {
                    SubWorkstreamSoftwareCost subWorkstreamSoftwareCostOwnership = new SubWorkstreamSoftwareCost();
                    subWorkstreamSoftwareCostOwnership.setWorkStreamId(subWorkstreamSoftwareCost.getWorkStreamId());
                    subWorkstreamSoftwareCostOwnership.setSubWorkStreamId(subWorkstreamSoftwareCost.getSubWorkStreamId());
                    subWorkstreamSoftwareCostOwnership.setSubWorkStreamName(subWorkstreamSoftwareCost.getSubWorkStreamName());
                    subWorkstreamSoftwareCostOwnership.setActiveInd(PortfolioConstants.TRUE);
                    subWorkstreamSoftwareCostOwnership.setOriginalInd(PortfolioConstants.FALSE);
                    subWorkstreamSoftwareCostOwnership.setPeriod(subWorkstreamSoftwareCost.getPeriod());
                    subWorkstreamSoftwareCostOwnership.setCostPerMonthLcy(subWorkstreamSoftwareCost.getCostPerMonthLcy());
                    subWorkstreamSoftwareCostOwnership.setCostPerMonthGcy(subWorkstreamSoftwareCost.getCostPerMonthGcy());
                    subWorkstreamSoftwareCostOwnership.setGroupCcy(subWorkstreamSoftwareCost.getGroupCcy());
                    subWorkstreamSoftwareCostOwnership.setLocalCcy(subWorkstreamSoftwareCost.getLocalCcy());
                    subWorkstreamSoftwareCostOwnership.setSoftwareDesc(subWorkstreamSoftwareCost.getSoftwareDesc());
                    subWorkstreamSoftwareCostOwnership.setSoftwareName(subWorkstreamSoftwareCost.getSoftwareName());
                    subWorkstreamSoftwareCostOwnership.setSoftwareType(subWorkstreamSoftwareCost.getSoftwareType());
                    subWorkstreamSoftwareCostOwnership.setAdd_software(subWorkstreamSoftwareCost.getAdd_software());
                    subWorkstreamSoftwareCostOwnership.setVendorName(subWorkstreamSoftwareCost.getVendorName());
                    subWorkstreamSoftwareCostOwnership.setUnitPrice(subWorkstreamSoftwareCost.getUnitPrice());
                    subWorkstreamSoftwareCostOwnership.setCostTypeDetail(subWorkstreamSoftwareCost.getCostTypeDetail());
                    subWorkstreamSoftwareCostOwnership.setCostSettings(subWorkstreamSoftwareCost.getCostSettings());
                    subWorkstreamSoftwareCostOwnership.setScenario(subWorkstreamSoftwareCost.getScenario());
                    subWorkstreamSoftwareCostOwnership.setRefSwsSwSurrId(subWorkstreamSoftwareCostOwnershipParent.getSwsSwSurrId());
                    subWorkstreamSoftwareCostOwnership.setCapexOpexSurrId(refSurrId);
                    subWorkstreamSoftwareCostOwnership.setGlCategory(PortfolioConstants.OWNERSHIP);
                    return subWorkstreamSoftwareCostOwnership;
                }).collect(Collectors.toList());
        List<String> OwnerShipPeriods = subWorkstreamSoftwareCostsToSave.stream().map(subWorkstreamSoftwareCost -> subWorkstreamSoftwareCost.getPeriod()).collect(Collectors.toList());
        deleteOwnerships(subWorkstreamId, subWorkstreamName, scenario,subWorkstreamSoftwareCostOwnershipParent.getSwsSwSurrId(), OwnerShipPeriods);
        return subWorkstreamSoftwareCostsToSave;
    }

    public void deleteOwnerships(String subWorkstreamId, String subWorkstreamName, String scenario, Integer refSurrId, List<String> ownerShipPeriods) {
        List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCosts =subWorkstreamSoftwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndGlCategoryAndRefSwsSwSurrIdAndPeriodInAndActiveIndAndOriginalInd(
                subWorkstreamId,subWorkstreamName,scenario,PortfolioConstants.OWNERSHIP,refSurrId,ownerShipPeriods,PortfolioConstants.TRUE,PortfolioConstants.FALSE);
        subWorkstreamSoftwareCostRepo.deleteAll(subWorkstreamSoftwareCosts);
    }

    private void saveItDepreciation(MonthlyCostTypeData monthlyCostTypeData,String currencyCode, HashSet<String> currencyCodes,String scenario){
            Optional<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCostOptional = subWorkstreamSoftwareCostRepo.findById(monthlyCostTypeData.getSurrId());
            if(subWorkstreamSoftwareCostOptional.isPresent() && subWorkstreamSoftwareCostOptional.get().getGlCategory().equalsIgnoreCase(PortfolioConstants.CAPEX)){
                SubWorkstreamSoftwareCost subWorkstreamSoftwareCostItDepre = subWorkstreamSoftwareCostRepo.findByScenarioAndCapexOpexSurrIdAndGlCategoryAndOriginalIndAndActiveInd(scenario,
                        subWorkstreamSoftwareCostOptional.get().getSwsSwSurrId(),PortfolioConstants.ITDEPRECIATION,PortfolioConstants.TRUE,PortfolioConstants.TRUE);
                List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCostsWithCapex = createItDepreciation(subWorkstreamSoftwareCostOptional.get(),currencyCode,currencyCodes,subWorkstreamSoftwareCostItDepre.getSwsSwSurrId());
                if(!CollectionUtils.isNullOrEmpty(subWorkstreamSoftwareCostsWithCapex)) {
                    deleteItDepreRecords(subWorkstreamSoftwareCostItDepre.getSwsSwSurrId(), subWorkstreamSoftwareCostOptional.get().getSubWorkStreamId(),
                            subWorkstreamSoftwareCostOptional.get().getSubWorkStreamName(),subWorkstreamSoftwareCostOptional.get().getScenario());
                    subWorkstreamSoftwareCostRepo.saveAll(subWorkstreamSoftwareCostsWithCapex);
                }
            }

    }




    public void deleteItDepreRecords(Integer itDepreSurrId, String subWorkstreamId, String subWorkstreamName, String scenario) {
      List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCosts = subWorkstreamSoftwareCostRepo.
              findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndGlCategoryAndRefSwsSwSurrIdAndActiveIndAndOriginalInd
                (subWorkstreamId, subWorkstreamName, scenario, PortfolioConstants.ITDEPRECIATION, itDepreSurrId,PortfolioConstants.TRUE,PortfolioConstants.FALSE);
        subWorkstreamSoftwareCostRepo.deleteAll(subWorkstreamSoftwareCosts);
    }

    private List<SubWorkstreamSoftwareCost> createItDepreciation(SubWorkstreamSoftwareCost softwareCost,String currencyCode, HashSet<String> currencyCodes,Integer itDepreSurrId) {
        BigDecimal totalCapex = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                subWorkstreamSoftwareCostRepo.getTotalCapexForSoftwareByGrpCcy(softwareCost.getSubWorkStreamId(),softwareCost.getSubWorkStreamName(),
                softwareCost.getScenario(),PortfolioConstants.CAPEX,softwareCost.getSwsSwSurrId())
                : subWorkstreamSoftwareCostRepo.getTotalCapexForSoftwareByLocalCcy(softwareCost.getSubWorkStreamId(),softwareCost.getSubWorkStreamName(),
                softwareCost.getScenario(),PortfolioConstants.CAPEX,softwareCost.getSwsSwSurrId());

        Map<String, Object> dateDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategories(softwareCost.getWorkStreamId(),
                softwareCost.getSubWorkStreamId(), softwareCost.getSubWorkStreamName(), softwareCost.getScenario(),
                PortfolioConstants.GL_CATEGORY_ITDEPRECIATION, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
        List<String> monthBetweenDates = (List<String>) dateDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);
        return monthBetweenDates.stream().map(month -> {
            SubWorkstreamSoftwareCost subWorkstreamSoftwareCost = new SubWorkstreamSoftwareCost();
            subWorkstreamSoftwareCost.setWorkStreamId(softwareCost.getWorkStreamId());
            subWorkstreamSoftwareCost.setSubWorkStreamId(softwareCost.getSubWorkStreamId());
            subWorkstreamSoftwareCost.setSubWorkStreamName(softwareCost.getSubWorkStreamName());
            subWorkstreamSoftwareCost.setSoftwareType(softwareCost.getSoftwareType());
            subWorkstreamSoftwareCost.setSoftwareName(softwareCost.getSoftwareName());
            subWorkstreamSoftwareCost.setSoftwareDesc(softwareCost.getSoftwareDesc());
            subWorkstreamSoftwareCost.setUnitPrice(softwareCost.getUnitPrice());
            subWorkstreamSoftwareCost.setVendorName(softwareCost.getVendorName());
            subWorkstreamSoftwareCost.setScenario(softwareCost.getScenario());
            subWorkstreamSoftwareCost.setCostSettings(softwareCost.getCostSettings());
            subWorkstreamSoftwareCost.setCostTypeDetail(softwareCost.getCostTypeDetail());
            subWorkstreamSoftwareCost.setQuantity(softwareCost.getQuantity());
            subWorkstreamSoftwareCost.setOriginalInd(PortfolioConstants.FALSE);
            subWorkstreamSoftwareCost.setGlCategory(PortfolioConstants.ITDEPRECIATION);
            subWorkstreamSoftwareCost.setActiveInd(PortfolioConstants.TRUE);
            subWorkstreamSoftwareCost.setRefSwsSwSurrId(itDepreSurrId);
            subWorkstreamSoftwareCost.setCapexOpexSurrId(softwareCost.getSwsSwSurrId());
            subWorkstreamSoftwareCost.setPeriod(month);
            subWorkstreamSoftwareCost.setSwsSwSurrId(0);
            updateCurrencyValuesForDepreSoftware(subWorkstreamSoftwareCost,currencyCode,currencyCodes,totalCapex,monthBetweenDates.size());
            return subWorkstreamSoftwareCost;
        }).collect(Collectors.toList());
    }


    public void updateCurrencyValuesForDepreSoftware(SubWorkstreamSoftwareCost subWorkstreamSoftwareCost,
                                                     String currencyCode, HashSet<String> currencyCodes,BigDecimal totalCapex,int noOfMonths) {
        if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode))
            updateCurrencyValuesForGroupForSoftwareDepre(subWorkstreamSoftwareCost, currencyCode,  currencyCodes,totalCapex,noOfMonths);
        else
            updateCurrencyValuesForLocalForSoftwareDepre(subWorkstreamSoftwareCost, currencyCode, currencyCodes,totalCapex,noOfMonths);

    }

    private SubWorkstreamSoftwareCost
    updateCurrencyValuesForLocalForSoftwareDepre(SubWorkstreamSoftwareCost subWorkstreamSoftwareCost,
                                                 String currencyCode,
                                                 HashSet<String> currencyCodes, BigDecimal totalCapex,int noOfMonths) {
        BigDecimal costPerMonth = totalCapex.divide(BigDecimal.valueOf(noOfMonths), 9, RoundingMode.HALF_UP);
        subWorkstreamSoftwareCost.setCostPerMonthLcy(costPerMonth);
        subWorkstreamSoftwareCost.setLocalCcy(currencyCode);
        currencyCodes.remove(currencyCode);
        if (!currencyCodes.isEmpty()) {
            subWorkstreamSoftwareCost.setGroupCcy(currencyCodes.iterator().next());
            subWorkstreamSoftwareCost.setCostPerMonthGcy(costPerMonth.multiply(financialDetailsService.getExchangeValue
                    (subWorkstreamSoftwareCost.getPeriod(), currencyCode, subWorkstreamSoftwareCost.getWorkStreamId())));
        } else {
            subWorkstreamSoftwareCost.setGroupCcy(currencyCode);
            subWorkstreamSoftwareCost.setCostPerMonthGcy(costPerMonth);
        }

        return subWorkstreamSoftwareCost;
    }

    private SubWorkstreamSoftwareCost
    updateCurrencyValuesForGroupForSoftwareDepre(SubWorkstreamSoftwareCost subWorkstreamSoftwareCost,
                                                 String loggedInCurrencyCode,
                                                 HashSet<String> currencyCodes, BigDecimal totalCapex, int noOfMonths) {
        BigDecimal costPerMonth = totalCapex.divide(BigDecimal.valueOf(noOfMonths), 9, RoundingMode.HALF_UP);
        subWorkstreamSoftwareCost.setCostPerMonthGcy(costPerMonth);
        subWorkstreamSoftwareCost.setGroupCcy(loggedInCurrencyCode);
        currencyCodes.remove(loggedInCurrencyCode);
        if (!currencyCodes.isEmpty()) {
            subWorkstreamSoftwareCost.setLocalCcy(currencyCodes.iterator().next());
            BigDecimal exchangedValue = financialDetailsService.getExchangeValue
                    (subWorkstreamSoftwareCost.getPeriod(), subWorkstreamSoftwareCost.getLocalCcy(), subWorkstreamSoftwareCost.getWorkStreamId());
            subWorkstreamSoftwareCost.setCostPerMonthLcy(costPerMonth.divide(exchangedValue, 9, RoundingMode.HALF_UP));
        } else {
            subWorkstreamSoftwareCost.setLocalCcy(loggedInCurrencyCode);
            subWorkstreamSoftwareCost.setCostPerMonthLcy(costPerMonth);
        }

        return subWorkstreamSoftwareCost;
    }


}
