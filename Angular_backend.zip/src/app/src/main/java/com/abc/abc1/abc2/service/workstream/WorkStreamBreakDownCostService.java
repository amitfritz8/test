package com.dbs.genesis.portfolio.service.workstream;

import com.dbs.genesis.portfolio.common.CommonFinancialTypes;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.DataValues;
import com.dbs.genesis.portfolio.repository.PortfolioRepository;
import com.dbs.genesis.portfolio.repository.SubWorkstreamOtherCostRepo;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import com.dbs.genesis.portfolio.service.financials.FinancialService;
import io.vavr.Tuple2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Slf4j
@Service
public class WorkStreamBreakDownCostService  implements  CommonFinancialTypes {

    public static final String BREAKDOWN_BY_COST_TYPE = "Breakdown By Cost Type";
    private final WorkStreamBreakDownHleAndSeedService workStreamBreakDownHleAndSeedService;
    private final WorkStreamBreakDownSoftwareService workStreamBreakDownSoftwareService;
    private final WorkStreamBreakDownOthersService workStreamBreakDownOthersService;
    private final WorkStreamBreakDownHardwareService workStreamBreakDownHardwareService;
    private final SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo;
    private  final DataSummaryService dataSummaryService;
    private final PortfolioRepository portfolioRepository;
    private final FinancialService financialService;
    @Autowired
    private WorkStreamBreakdownResourceService workStreamBreakdownResourceService;

    @Autowired
    public WorkStreamBreakDownCostService(DataSummaryService dataSummaryService, PortfolioRepository portfolioRepository, WorkStreamBreakDownHleAndSeedService workStreamBreakDownHleAndSeedService, WorkStreamBreakDownSoftwareService workStreamBreakDownSoftwareService, WorkStreamBreakDownOthersService workStreamBreakDownOthersService, WorkStreamBreakDownHardwareService workStreamBreakDownHardwareService, SubWorkstreamOtherCostRepo subWorkstreamOtherCostRepo, FinancialService financialService) {
        this.dataSummaryService = dataSummaryService;
        this.portfolioRepository = portfolioRepository;
        this.workStreamBreakDownHleAndSeedService = workStreamBreakDownHleAndSeedService;
        this.workStreamBreakDownSoftwareService = workStreamBreakDownSoftwareService;
        this.workStreamBreakDownOthersService = workStreamBreakDownOthersService;
        this.workStreamBreakDownHardwareService = workStreamBreakDownHardwareService;
        this.subWorkstreamOtherCostRepo = subWorkstreamOtherCostRepo;
        this.financialService = financialService;
    }

    public Map<String, FinancialBreakDownCostView> getBreakDownCostData(String scenario, String currencyCode, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String period, String periodType) {

        Map<String,FinancialBreakDownCostView> financialBreakDownCostViewMap = new TreeMap<>();
        FinancialBreakDownCostView breakDownCostView = new FinancialBreakDownCostView();
        try{
            List<DataValues> costSettings =  dataSummaryService.getDataValuesBySummary(PortfolioConstants.COST_SETTINGS);
            List<String> costTypes = getCostTypes();
            List<CostSettingsView> individualCostTypeData = getIndividualCostTypeData(costSettings, costTypes,
                    subWorkStreamIdAndNames, period, periodType,scenario,currencyCode);
            breakDownCostView.setName(BREAKDOWN_BY_COST_TYPE);
            breakDownCostView.setCostSettingsViewList(individualCostTypeData);
            financialBreakDownCostViewMap.put(scenario,breakDownCostView);
        } catch (Exception ex) {
            log.error(" Exception in breakdown cost view ",ex);
        }
        return financialBreakDownCostViewMap;
    }

    private List<CostSettingsView> getIndividualCostTypeData(List<DataValues> costSettings, List<String>
            costTypes, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String period, String
                                                                     periodType, String scenario, String currencyCode) {

        List<CostSettingsView> costSettingsViewList = new ArrayList<>();
        costSettings.forEach(costSetting -> {
            String costSettingValue = costSetting.getValue();
            if (PortfolioConstants.COST_SETTING_TYPE_SEED_FUNDING.equalsIgnoreCase(costSettingValue)) {
                CostSettingsView costSettingForSeedFunding = workStreamBreakDownHleAndSeedService.getCostSettingForSeedFunding(costTypes,
                        subWorkStreamIdAndNames, period, periodType, scenario, costSettingValue,currencyCode);
                costSettingsViewList.add(costSettingForSeedFunding);
            } if (PortfolioConstants.COST_SETTING_TYPE_HLE.equalsIgnoreCase(costSettingValue)) {
                CostSettingsView costSettingForHLE = workStreamBreakDownHleAndSeedService.getCostSettingForHLE(costTypes,
                        subWorkStreamIdAndNames, period, periodType, scenario, costSettingValue,currencyCode);
                costSettingsViewList.add(costSettingForHLE);

            } if (PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS.equalsIgnoreCase(costSettingValue)) {
                CostSettingsView costSettingForFinancialDetails = getCostSettingForFinancialDetails(
                        costTypes, subWorkStreamIdAndNames, period, periodType, costSettingValue,scenario,currencyCode);
                costSettingsViewList.add(costSettingForFinancialDetails);
            }
        } );
        return costSettingsViewList;
    }

    private CostSettingsView getCostSettingForFinancialDetails(List<String> costTypes,
                                                              List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                                              String period, String periodType,
                                                              String costSettingValue,String scenario, String currencyCode) {
        CostSettingsView costSettingsView = null;

        if (PortfolioConstants.MONTHLY.equalsIgnoreCase(periodType)) {
            costSettingsView = getCostSettingsByMonthlyForFinancial(costTypes, subWorkStreamIdAndNames,
                    period, costSettingValue,scenario,currencyCode);
        }
        if (PortfolioConstants.QUARTERLY.equalsIgnoreCase(periodType)) {
            costSettingsView = getCostSettingsByQuarterlyForFinancial(costTypes, subWorkStreamIdAndNames,
                    costSettingValue,scenario,currencyCode);
        }
        if (PortfolioConstants.YEARLY.equalsIgnoreCase(periodType)) {
            costSettingsView = getCostSettingsByYearlyForFinancial(costTypes, subWorkStreamIdAndNames,
                    costSettingValue,scenario,currencyCode);
        }

        return costSettingsView;
    }

    private CostSettingsView getCostSettingsByMonthlyForFinancial(List<String> costTypes,
                                                                  List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                                                  String period, String costSettingValue,String scenario, String currencyCode) {
        CostSettingsView costSettingsView = new CostSettingsView();
        costSettingsView.setName(costSettingValue);
        List<FinancialSummaryResource> consolidatedFinancialSummary =
                subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                        PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                        portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndGroupCurrency(subWorkStreamIdAndName.getSubWorkStreamId(),
                                subWorkStreamIdAndName.getSubWorkStreamName(), period, scenario) :
                                portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndLocalCurrency(subWorkStreamIdAndName.getSubWorkStreamId(),
                                        subWorkStreamIdAndName.getSubWorkStreamName(), period, scenario))
                        .flatMap(List::stream).collect(Collectors.toList());

       // consolidatedFinancialSummary = PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)
        //       ? consolidatedFinancialSummary : financialService.getExChangedList(consolidatedFinancialSummary,workStreamId,currencyCode);
        List<BigDecimal> monthlyCostSettings = getCostSettingMonthlyData(consolidatedFinancialSummary);
        costSettingsView.setMonthlyCostSettings(monthlyCostSettings);
        costSettingsView.setCostSettingsTotal(monthlyCostSettings.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));


        List<CompletableFuture> cfstFutures = new ArrayList<>(subWorkStreamIdAndNames.size());

        subWorkStreamIdAndNames.forEach(swsIdNm -> {
            CompletableFuture<BigDecimal> cf = null;
            if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)){
                cf = CompletableFuture.supplyAsync(() -> portfolioRepository.getConsolidatedFinancialSummaryTotalByGroupCurrency(swsIdNm.getSubWorkStreamId(), swsIdNm.getSubWorkStreamName()
                        , scenario).get(0).getCurrencyValue());
            } else {
                cf = CompletableFuture.supplyAsync(() -> portfolioRepository.getConsolidatedFinancialSummaryTotalByLocalCurrency(swsIdNm.getSubWorkStreamId(), swsIdNm.getSubWorkStreamName()
                        , scenario).get(0).getCurrencyValue());
            }
            cfstFutures.add(cf);
        });

        List<BigDecimal> overAllTotalList = new ArrayList<>();
        CompletableFuture.allOf(cfstFutures.stream().toArray(CompletableFuture[]::new))
            .whenComplete((v,t) -> {
                cfstFutures.forEach(cf -> {
                    overAllTotalList.add((BigDecimal) cf.getNow(BigDecimal.ZERO));
                });
            }).join();
        BigDecimal overCostTotal = overAllTotalList.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        log.info("overCostTotal : "+overCostTotal);
        costSettingsView.setCostSettingsOverAllTotal(overCostTotal);

        /*for (SubWorkStreamIdAndName subWorkStreamIdAndName : subWorkStreamIdAndNames) {
            costSettingsOverAllTotal = costSettingsOverAllTotal.add(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode) ?
                    portfolioRepository.getConsolidatedFinancialSummaryTotalByGroupCurrency(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName()
                            , scenario).get(0).getCurrencyValue()
                    : portfolioRepository.getConsolidatedFinancialSummaryTotalByLocalCurrency(subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName()
                    , scenario).get(0).getCurrencyValue());
        }*/
        List<CostTypeCategoryView> costTypeCategoryViewList = new ArrayList<>();

        List<CompletableFuture> allFutures = new ArrayList<>(costTypes.size());

        costTypes.forEach(costType -> {
            CompletableFuture<CostTypeCategoryView> cf = CompletableFuture.supplyAsync(() -> getCostTypeForFinancialByMonthly(costType, subWorkStreamIdAndNames, period,scenario,currencyCode));
            allFutures.add(cf);
        });

        CompletableFuture.allOf(allFutures.stream().toArray(CompletableFuture[]::new))
                .whenComplete((v, th) -> {
                    allFutures.forEach(cf -> costTypeCategoryViewList.add((CostTypeCategoryView)cf.getNow(new CostTypeCategoryView())));
                }).join();

        costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);

        return costSettingsView;
    }

    private CostTypeCategoryView getCostTypeForFinancialByMonthly(String costType,
                                                                  List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                                                  String period,String scenario,String currencyCode) {
        CostTypeCategoryView costTypeCategoryView = new CostTypeCategoryView();
        switch (costType) {
            case PortfolioConstants.SOFTWARE:
                List<BigDecimal> monthlyValuesBySoftwareTotal = workStreamBreakDownSoftwareService.getListOfMonthlyValuesBySoftwareTotal(subWorkStreamIdAndNames, period,scenario,currencyCode,costType);
                Tuple2<BigDecimal,BigDecimal> softwareOverAllTotal = workStreamBreakDownSoftwareService.getCostTypeOverAllTotal(subWorkStreamIdAndNames,scenario,currencyCode);
                List<UnitCostMappingView> softwareUnitCostMapByMonthly = workStreamBreakDownSoftwareService.getSoftwareUnitCostMapByMonthly(subWorkStreamIdAndNames, period,scenario,currencyCode);
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setMonthlyCostTypes(monthlyValuesBySoftwareTotal);
                costTypeCategoryView.setCostTypeTotal(monthlyValuesBySoftwareTotal.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                BigDecimal totalOtherSoftwareValue = workStreamBreakDownOthersService.getOtherTotalSum(subWorkStreamIdAndNames,scenario,PortfolioConstants.SOFTWARE_TYPE,currencyCode);
                costTypeCategoryView.setCostTypeOverAllTotal(softwareOverAllTotal._1.add(totalOtherSoftwareValue));
                costTypeCategoryView.setMonthlyUnitCostList(softwareUnitCostMapByMonthly);
                break;
            case PortfolioConstants.HARDWARE:
                List<BigDecimal> monthlyValuesByHardwareTotal = workStreamBreakDownHardwareService.getListOfMonthlyValuesByHardwareTotal(subWorkStreamIdAndNames, period,scenario,currencyCode,costType);
                Tuple2<BigDecimal,BigDecimal> hardwareOverAllTotal = workStreamBreakDownHardwareService.getCostTypeOverAllTotal(subWorkStreamIdAndNames,scenario,currencyCode);
                List<UnitCostMappingView> hardwareUnitCostMapByMonthly = workStreamBreakDownHardwareService.getHardwareUnitCostMapByMonthly(subWorkStreamIdAndNames, period,scenario,currencyCode);
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setMonthlyCostTypes(monthlyValuesByHardwareTotal);
                costTypeCategoryView.setCostTypeTotal(monthlyValuesByHardwareTotal.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                BigDecimal totalOtherHardwareValue = workStreamBreakDownOthersService.getOtherTotalSum(subWorkStreamIdAndNames,scenario,PortfolioConstants.HARDWARE_TYPE,currencyCode);
                log.info("totalOtherHardwareValue : "+totalOtherHardwareValue);
                log.info("hardwareOverAllTotal : "+hardwareOverAllTotal._1);
                BigDecimal costOverAllTotal = hardwareOverAllTotal._1;
                costOverAllTotal = costOverAllTotal.add(totalOtherHardwareValue);
                log.info("costOverAllTotal : "+costOverAllTotal);
                costTypeCategoryView.setCostTypeOverAllTotal(costOverAllTotal);
                costTypeCategoryView.setMonthlyUnitCostList(hardwareUnitCostMapByMonthly);
                break;
            case PortfolioConstants.OTHERS:
                List<UnitCostMappingView> othersByMonthly = workStreamBreakDownOthersService.getOthersByMonthly(subWorkStreamIdAndNames, period,scenario,currencyCode);
                List<BigDecimal> monthlyValuesByOthersTotal =  workStreamBreakDownOthersService.getOthersHeaderByMonthly(subWorkStreamIdAndNames,period,scenario,currencyCode);
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setMonthlyCostTypes(monthlyValuesByOthersTotal);
                costTypeCategoryView.setCostTypeTotal(monthlyValuesByOthersTotal.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                costTypeCategoryView.setCostTypeOverAllTotal(workStreamBreakDownOthersService.getOthersHeaderTotal(subWorkStreamIdAndNames,scenario,currencyCode));
                costTypeCategoryView.setMonthlyUnitCostList(othersByMonthly);
                break;
            case PortfolioConstants.RESOURCE_TYPE:
                costTypeCategoryView.setName(costType);
                List<List<BigDecimal>> monthlyValuesByResouceTotal = workStreamBreakdownResourceService.getListOfMonthlyValuesByResourceTotal(subWorkStreamIdAndNames, period, scenario, currencyCode);

                List<BigDecimal> costTypeTotalResource = new ArrayList<>();
                List<BigDecimal> monthlyValues = monthlyValuesByResouceTotal.get(2);
                costTypeTotalResource.add(monthlyValuesByResouceTotal.get(0).stream().reduce(BigDecimal.ZERO, BigDecimal::add));
                //costTypeTotalResource.add(monthlyValuesByResouceTotal.get(1).stream().reduce(BigDecimal.ZERO, BigDecimal::add));
                costTypeTotalResource.add(BigDecimal.ZERO);
                costTypeTotalResource.add(monthlyValues.stream().reduce(BigDecimal.ZERO, BigDecimal::add));
                costTypeCategoryView.setCostTypeTotalResource(costTypeTotalResource);
                List<BigDecimal> resourceOverAllTotal = new ArrayList<>();
                monthlyValuesByResouceTotal.stream().forEach(monthlyValuesByResouceTotalTmp ->
                {
                    BigDecimal total = monthlyValuesByResouceTotalTmp.stream().reduce(BigDecimal.ZERO, BigDecimal::add);
                    resourceOverAllTotal.add(total);
                });
                /*List<BigDecimal> costTypeTotalResource = new ArrayList<>();
                for (List<BigDecimal> monthlyValues : monthlyValuesByResouceTotal) {
                    BigDecimal total = BigDecimal.ZERO;
                    for (BigDecimal value : monthlyValues) {
                        total = total.add(value);
                    }
                    costTypeTotalResource.add(total);
                }
                costTypeCategoryView.setCostTypeTotalResource(costTypeTotalResource);
                List<BigDecimal> resourceOverAllTotal = workStreamBreakdownResourceService.getCostTypeOverAllTotal(subWorkStreamIdAndNames, scenario, currencyCode);
                */
                List<BigDecimal> serviceResourceOverAllTotal = workStreamBreakdownResourceService.getResourceOverAllTotal(subWorkStreamIdAndNames, scenario, currencyCode);
//                costTypeCategoryView.setCostTypeOverAllTotal(serviceResourceOverAllTotal.get(0));
                costTypeCategoryView.setCostTypeOverAllTotalResource(serviceResourceOverAllTotal);
                costTypeCategoryView.setMonthlyCostTypesResource(monthlyValuesByResouceTotal);
                List<UnitCostMappingView> respourceUnitCostMapByMonthly = workStreamBreakdownResourceService.getResourceUnitCostMapByMonthly(subWorkStreamIdAndNames, period, scenario, currencyCode);
                costTypeCategoryView.setMonthlyUnitCostList(respourceUnitCostMapByMonthly);
                break;

            default:
                throw new IllegalStateException("Unexpected Cost Type: " + costType);

        }
        return costTypeCategoryView;
    }

    private CostSettingsView getCostSettingsByQuarterlyForFinancial(List<String> costTypes, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,
                                                                    String costSettingValue, String scenario, String currencyCode) {
        CostSettingsView costSettingsView = new CostSettingsView();
        costSettingsView.setName(costSettingValue);
        Map<String, List<BigDecimal>> costSettingQuarterlyMap = getCostSettingQuarterlyMap(subWorkStreamIdAndNames, scenario);
        costSettingsView.setQuarterlyCostSettings(costSettingQuarterlyMap);
        Map<String,BigDecimal> individualYearTotal = new TreeMap<>();
        BigDecimal overAllTotal = BigDecimal.ZERO;
        for (Map.Entry<String, List<BigDecimal>> entry : costSettingQuarterlyMap.entrySet()) {
            String year = entry.getKey();
            List<BigDecimal> bigDecimals = entry.getValue();
            individualYearTotal.put(year, bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
            overAllTotal = overAllTotal.add(bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        }
        costSettingsView.setIndividualYearSummaryForQuarterly(individualYearTotal);
        costSettingsView.setCostSettingsOverAllTotal(overAllTotal);
        List<CostTypeCategoryView> costTypeCategoryViewList = new ArrayList<>();
        log.info("scenario"+scenario);
        costTypes.forEach(costType -> {
            CostTypeCategoryView costTypeCategoryView = getCostTypeForFinancialByQuarterly(costType,
                    subWorkStreamIdAndNames,scenario,currencyCode);
            costTypeCategoryViewList.add(costTypeCategoryView);
            costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);
        });
        return costSettingsView;
    }

    private Map<String, List<BigDecimal>> getCostSettingQuarterlyMap(List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario) {
        Map<String,List<BigDecimal>> listMap = new TreeMap<>();
        List<String> ofPeriodFromFinancialTables = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamOtherCostRepo.getDistinctOfPeriodFromFinancialTables(subWorkStreamIdAndName.getSubWorkStreamId(),
                        subWorkStreamIdAndName.getSubWorkStreamName(), scenario)).flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
        ofPeriodFromFinancialTables.forEach(year -> {

            List<FinancialSummaryResource> consolidatedFinancialSummary = subWorkStreamIdAndNames.stream()
                    .map(subWorkStreamIdAndName ->
                            portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndGroupCurrency(subWorkStreamIdAndName.getSubWorkStreamId(),
                            subWorkStreamIdAndName.getSubWorkStreamName(),
                            year, scenario)).flatMap(List::stream).collect(Collectors.toList());
            BigDecimal firstQuarter = BigDecimal.ZERO;
            BigDecimal secondQuarter = BigDecimal.ZERO;
            BigDecimal thirdQuarter = BigDecimal.ZERO;
            BigDecimal fourthQuarter = BigDecimal.ZERO;
            for (FinancialSummaryResource financialSummaryResource : consolidatedFinancialSummary) {
                String reportingMonth = financialSummaryResource.getPeriod().substring(4, 6);
                if (PortfolioConstants.firstQuarterlyList.contains(reportingMonth)) {
                    if (financialSummaryResource.getCurrencyValue() != null) {
                        firstQuarter = firstQuarter.add(financialSummaryResource.getCurrencyValue());
                    }
                }
                if (PortfolioConstants.secondQuarterlyList.contains(reportingMonth)) {
                    if (financialSummaryResource.getCurrencyValue() != null && financialSummaryResource.
                            getCurrencyValue().intValue() != 0) {
                        secondQuarter = secondQuarter.add(financialSummaryResource.getCurrencyValue());
                    }
                }
                if (PortfolioConstants.thirdQuarterlyList.contains(reportingMonth)) {
                    if (financialSummaryResource.getCurrencyValue() != null && financialSummaryResource.
                            getCurrencyValue().intValue() != 0) {
                        thirdQuarter = thirdQuarter.add(financialSummaryResource.getCurrencyValue());
                    }
                }
                if (PortfolioConstants.fourthQuarterlyList.contains(reportingMonth)) {
                    if (financialSummaryResource.getCurrencyValue() != null && financialSummaryResource.
                            getCurrencyValue().intValue() != 0) {
                        fourthQuarter = fourthQuarter.add(financialSummaryResource.getCurrencyValue());
                    }
                }
            }
            listMap.put(year, Arrays.asList(firstQuarter,secondQuarter,thirdQuarter,fourthQuarter));
        });
        return listMap;
    }

    private CostTypeCategoryView getCostTypeForFinancialByQuarterly(String costType, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String scenario, String currencyCode) {

        CostTypeCategoryView costTypeCategoryView = new CostTypeCategoryView();

        switch (costType) {
            case PortfolioConstants.SOFTWARE:
                Map<String, BigDecimal> individualQuarterlySum = new TreeMap<>();
                BigDecimal totalOverAllSum = BigDecimal.ZERO;
                Map<String, List<UnitCostMappingView>> quarterlyUnitCostMapByYear = workStreamBreakDownSoftwareService.getSoftwareUnitCostMapQuarterly(subWorkStreamIdAndNames,scenario,currencyCode);
                Map<String, List<BigDecimal>> softwareQuarterlyListMap = workStreamBreakDownSoftwareService.getSoftwareQuarterlyListMap(subWorkStreamIdAndNames,scenario,currencyCode,costType);
                for (Map.Entry<String, List<BigDecimal>> entry : softwareQuarterlyListMap.entrySet()) {
                    String year = entry.getKey();
                    List<BigDecimal> bigDecimals = entry.getValue();
                    individualQuarterlySum.put(year, bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                    totalOverAllSum = totalOverAllSum.add(bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                }
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setQuarterlyUnitCostList(quarterlyUnitCostMapByYear);
                costTypeCategoryView.setIndividualYearSummaryForQuarterly(individualQuarterlySum);
                costTypeCategoryView.setCostTypeOverAllTotal(totalOverAllSum);
                costTypeCategoryView.setQuarterlyCostType(softwareQuarterlyListMap);
                break;
            case PortfolioConstants.HARDWARE:
                Map<String, BigDecimal> individualQuarterlySumForHardware = new TreeMap<>();
                BigDecimal totalOverAllSumForHardware = BigDecimal.ZERO;
                Map<String, List<UnitCostMappingView>> hardwareUnitCostMapQuarterly = workStreamBreakDownHardwareService.getHardwareUnitCostMapQuarterly(subWorkStreamIdAndNames,scenario,currencyCode);
                Map<String, List<BigDecimal>> hardwareQuarterlyListMap = workStreamBreakDownHardwareService.getHardwareQuarterlyListMap(subWorkStreamIdAndNames,scenario,currencyCode,costType);

                for (Map.Entry<String, List<BigDecimal>> entry : hardwareQuarterlyListMap.entrySet()) {
                    String year = entry.getKey();
                    List<BigDecimal> bigDecimals = entry.getValue();
                    individualQuarterlySumForHardware.put(year, bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                    totalOverAllSumForHardware = totalOverAllSumForHardware.add(bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                }
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setQuarterlyUnitCostList(hardwareUnitCostMapQuarterly);
                costTypeCategoryView.setIndividualYearSummaryForQuarterly(individualQuarterlySumForHardware);
                costTypeCategoryView.setCostTypeOverAllTotal(totalOverAllSumForHardware);
                costTypeCategoryView.setQuarterlyCostType(hardwareQuarterlyListMap);
                break;
            case PortfolioConstants.OTHERS:
                Map<String, BigDecimal> individualQuarterlySumForOthers = new TreeMap<>();
                BigDecimal totalOverAllSumForOthers = BigDecimal.ZERO;
                Map<String, List<UnitCostMappingView>> othersByQuarterly = workStreamBreakDownOthersService.getOthersByQuarterlyTotalSum(subWorkStreamIdAndNames,scenario,currencyCode);

                Map<String, List<BigDecimal>> othersQuarterlyListMap  = workStreamBreakDownOthersService.getOthersHeaderDataByQuarterly(subWorkStreamIdAndNames,scenario,currencyCode);
                for (Map.Entry<String, List<BigDecimal>> entry : othersQuarterlyListMap.entrySet()) {
                    String year = entry.getKey();
                    List<BigDecimal> bigDecimals = entry.getValue();
                    individualQuarterlySumForOthers.put(year, bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                    totalOverAllSumForOthers = totalOverAllSumForOthers.add(bigDecimals.stream().reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
                }
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setQuarterlyUnitCostList(othersByQuarterly);
                costTypeCategoryView.setQuarterlyCostType(othersQuarterlyListMap);
                costTypeCategoryView.setIndividualYearSummaryForQuarterly(individualQuarterlySumForOthers);
                costTypeCategoryView.setCostTypeOverAllTotal(totalOverAllSumForOthers);
                break;
            case PortfolioConstants.RESOURCE_TYPE:
                costTypeCategoryView.setName(costType);
                Map<String, List<UnitCostMappingView>> quarterlyUnitCostMapByYearResource = workStreamBreakdownResourceService.getResourceUnitCostMapQuarterly(subWorkStreamIdAndNames, scenario, currencyCode);
                costTypeCategoryView.setQuarterlyUnitCostList(quarterlyUnitCostMapByYearResource);
                workStreamBreakdownResourceService.getResourceQuarterlyListMap(subWorkStreamIdAndNames, scenario, currencyCode,costTypeCategoryView);
                break;

            default:
                throw new IllegalArgumentException("Unexpected Cost Type: "  + costType.toUpperCase());
        }
        return costTypeCategoryView;
    }

    private CostSettingsView getCostSettingsByYearlyForFinancial(List<String> costTypes, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames, String costSettingValue, String scenario, String currencyCode) {


        CostSettingsView costSettingsView = new CostSettingsView();
        costSettingsView.setName(costSettingValue);
        Map<String,BigDecimal> yearMap = new TreeMap<>();
        BigDecimal allYearsTotal = BigDecimal.ZERO;
        List<String> distinctOfPeriodFromFinancialTables = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                subWorkstreamOtherCostRepo.getDistinctOfPeriodFromFinancialTables(
                        subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), scenario))
                .flatMap(List::stream).collect(Collectors.toSet()).stream().collect(Collectors.toList());
        for (String year : distinctOfPeriodFromFinancialTables) {
            List<FinancialSummaryResource> consolidatedFinancialSummaryByPeriod = subWorkStreamIdAndNames.stream().map(subWorkStreamIdAndName ->
                    PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode)?
                    portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndGroupCurrency(
                            subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), year, scenario)
                    :  portfolioRepository.getConsolidatedFinancialSummaryByPeriodAndLocalCurrency(
                            subWorkStreamIdAndName.getSubWorkStreamId(), subWorkStreamIdAndName.getSubWorkStreamName(), year, scenario))
                    .flatMap(List::stream).collect(Collectors.toList());
            BigDecimal totalSumValue = BigDecimal.ZERO;
            for (FinancialSummaryResource financialSummaryResource : consolidatedFinancialSummaryByPeriod) {
                totalSumValue = totalSumValue.add(financialSummaryResource.getCurrencyValue());
            }
            yearMap.put(year, totalSumValue);
            allYearsTotal = allYearsTotal.add(totalSumValue);
        }
        costSettingsView.setYearlyCostSettings(yearMap);
        costSettingsView.setCostSettingsOverAllTotal(allYearsTotal);
        List<CostTypeCategoryView> costTypeCategoryViewList = new ArrayList<>();

        costTypes.forEach(costType -> {
            CostTypeCategoryView costTypeCategoryView = getCostTypeForFinancialByYearly(costType,
                    subWorkStreamIdAndNames,scenario,currencyCode);
            costTypeCategoryViewList.add(costTypeCategoryView);
            costSettingsView.setCostTypeCategoryViewList(costTypeCategoryViewList);
        });
        return costSettingsView;
    }

    private CostTypeCategoryView getCostTypeForFinancialByYearly(String costType, List<SubWorkStreamIdAndName> subWorkStreamIdAndNames,String scenario,String currencyCode) {

        CostTypeCategoryView costTypeCategoryView = new CostTypeCategoryView();
        switch (costType) {
            case PortfolioConstants.SOFTWARE:
                Map<String, List<UnitCostMappingView>> yearlySoftwareData = workStreamBreakDownSoftwareService.getYearlySoftwareData(subWorkStreamIdAndNames,scenario,currencyCode);
                Map<String, BigDecimal> totalYearSumMap = workStreamBreakDownSoftwareService.getYearlySoftwareSummary(subWorkStreamIdAndNames,scenario,currencyCode,costType);
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setYearlyCostType(totalYearSumMap);
                BigDecimal bigDecimal = BigDecimal.ZERO;
                for (Map.Entry<String, BigDecimal> totalValue : totalYearSumMap.entrySet()) {
                    bigDecimal = bigDecimal.add(totalValue.getValue());
                }
                costTypeCategoryView.setYearlyUnitCostList(yearlySoftwareData);
                costTypeCategoryView.setCostTypeOverAllTotal(bigDecimal);
                break;
            case PortfolioConstants.HARDWARE:
                Map<String, List<UnitCostMappingView>> yearlyHardwareData = workStreamBreakDownHardwareService.getYearlyHardwareData(subWorkStreamIdAndNames,scenario,currencyCode);
                Map<String, BigDecimal> totalHardwareSumMap = workStreamBreakDownHardwareService.getYearlyHardwareSummary(subWorkStreamIdAndNames,scenario,currencyCode,costType);
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setYearlyCostType(totalHardwareSumMap);
                costTypeCategoryView.setYearlyUnitCostList(yearlyHardwareData);
                BigDecimal totalSum = BigDecimal.ZERO;
                for (Map.Entry<String, BigDecimal> totalValue : totalHardwareSumMap.entrySet()) {
                    totalSum = totalSum.add(totalValue.getValue());
                }
                costTypeCategoryView.setCostTypeOverAllTotal(totalSum);
                break;
            case PortfolioConstants.OTHERS:
                Map<String, List<UnitCostMappingView>> yearlyOthersData = workStreamBreakDownOthersService.getYearlyOthersData(subWorkStreamIdAndNames,scenario,currencyCode);
                Map<String, BigDecimal> yearlySummaryData = workStreamBreakDownOthersService.getYearlySummaryData(subWorkStreamIdAndNames,scenario,currencyCode);
                costTypeCategoryView.setName(costType);
                costTypeCategoryView.setYearlyUnitCostList(yearlyOthersData);
                costTypeCategoryView.setYearlyCostType(yearlySummaryData);
                BigDecimal overAllSum = BigDecimal.ZERO;
                for (Map.Entry<String, BigDecimal> totalValue : yearlySummaryData.entrySet()) {
                    overAllSum = overAllSum.add(totalValue.getValue());
                }
                costTypeCategoryView.setCostTypeOverAllTotal(overAllSum);
                break;
            case PortfolioConstants.RESOURCE_TYPE:
                workStreamBreakdownResourceService.getYearlyResourceSummary(subWorkStreamIdAndNames, scenario, currencyCode,costTypeCategoryView);
                costTypeCategoryView.setName(costType);
                Map<String, List<UnitCostMappingView>> yearlyResourceData = workStreamBreakdownResourceService.getYearlyResourceData(subWorkStreamIdAndNames, scenario, currencyCode);
                costTypeCategoryView.setYearlyUnitCostList(yearlyResourceData);
                break;

            default:
                throw new IllegalStateException("Unexpected Cost Type: " + costType.toUpperCase());
        }
        return costTypeCategoryView;
    }

    private List<String> getCostTypes() {
        List<DataValues> dataValuesList = dataSummaryService.getDataValuesBySummary(PortfolioConstants.COST_TYPE);
        dataValuesList.sort(Comparator.comparing(DataValues::getAttr1));
        return dataValuesList.stream().map(DataValues::getValue).collect(Collectors.toList());
    }

}
