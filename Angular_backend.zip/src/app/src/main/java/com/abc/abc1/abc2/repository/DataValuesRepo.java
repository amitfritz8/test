package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.DataValues;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DataValuesRepo extends JpaRepository<DataValues, Integer> {
    List<DataValues> findByCodeAndStatusIgnoreCaseOrderByValue(int code, String status);

    List<DataValues> findByCodeAndStatusIgnoreCaseOrderById(int code, String status);

    DataValues findByCodeAndValueAndStatusIgnoreCaseOrderByValue(Integer dataCode, String value, String status);
    DataValues findByCodeAndDescAndStatusIgnoreCaseOrderByValue(Integer dataCode, String value, String status);

    @Query(value = "select distinct v.refdata_attr3 from xref_data_summary s , xref_data_values v\n" +
            "where s.refdata_code = v.refdata_code\n" +
            "and s.refdata_name = 'Country'\n" +
            "and v.refdata_attr3 IS NOT NULL\n" +
            "and v.refdata_value IN (\n" +
            "  select data.location from ((select distinct b.refdata_value as location\n" +
            "   from xref_data_summary a, xref_data_values b\n" +
            "   where a.refdata_name='Country'\n" +
            "         and b.status='Active'\n" +
            "         and a.refdata_code=b.refdata_code\n" +
            "         and exists (select location from uam_user_permission\n" +
            "   where 1bank_id= ?1\n" +
            "         and location='ALL')\n" +
            "   order by b.refdata_value)\n" +
            "  union\n" +
            "  (select distinct location\n" +
            "   from uam_user_permission\n" +
            "   where 1bank_id= ?1\n" +
            "         and not exists (select location from uam_user_permission\n" +
            "   where 1bank_id= ?1\n" +
            "         and location='ALL')\n" +
            "   order by location)) as data\n" +
            ");",nativeQuery = true)
    List<String> findCurrenciesBasedOnUam(String loggedInUserId);
}