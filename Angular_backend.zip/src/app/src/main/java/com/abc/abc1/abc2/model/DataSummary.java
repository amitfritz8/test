package com.dbs.genesis.portfolio.model;

import com.dbs.genesis.portfolio.resources.DataSummaryResource;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "xref_data_summary")
@EntityListeners(AuditingEntityListener.class)
public class DataSummary extends CommonEntity<String> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "refdata_code")
    private Integer dataCode;
    @Column(name = "refdata_name")
    private String dataName;
    @Column(name = "refdata_desc")
    private String dataDesc;
    @Column(name = "status")
    private String status;
    @Column(name = "golden_source")
    private String goldenSource;
    @Column(name = "interim_source")
    private String interimSource;
    @Column(name = "data_owner_1bankid")
    private String owner1Bankid;
    @Column(name = "data_owner_deptname")
    private String ownerDeptname;
    @Column(name = "update_method")
    private String updateMethod;
    @Column(name = "update_freq")
    private String updateFreq;

    public DataSummaryResource toDataSummaryResource() {
        DataSummaryResource resource = new DataSummaryResource();
        resource.setCode(getDataCode());
        resource.setName(getDataName());
        resource.setStatus(getStatus());
        resource.setGoldenSource(getGoldenSource());
        resource.setInterimSource(getInterimSource());
        resource.setOwner1Bankid(getOwner1Bankid());
        resource.setOwnerDeptname(getOwnerDeptname());
        resource.setUpdateFreq(getUpdateFreq());
        resource.setUpdateMethod(getUpdateMethod());
        return resource;
    }

}
