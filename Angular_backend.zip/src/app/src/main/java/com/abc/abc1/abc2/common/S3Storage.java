package com.dbs.genesis.portfolio.common;

import com.amazonaws.*;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.*;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.InputStream;
import java.io.PushbackInputStream;

@Slf4j
@Service
public class S3Storage {

    private static final Logger logger = LoggerFactory.getLogger(S3Storage.class);
    private static String slashDelimiter = "/";

    @Value("${bucketName}")
    private String bucketName;

    @Value("${accessKeyId}")
    private String accessKeyId;

    @Value("${cloud.aws.region.static}")
    private String signingRegion;

    @Value("${cloud.aws.endpoint.url}")
    private String serviceEndPoint;

    @Value("${serverAccessKey}")
    private String serverAccessKey;


    private AmazonS3 s3Client = null;
    private TransferManager transferManager = null;


    public void createConnection() {
        try {
            EndpointConfiguration endpoint = new EndpointConfiguration(serviceEndPoint, signingRegion);
            System.setProperty(SDKGlobalConfiguration.DISABLE_CERT_CHECKING_SYSTEM_PROPERTY, "true");
            BasicAWSCredentials awsCreds = new BasicAWSCredentials(accessKeyId, serverAccessKey);
            s3Client = AmazonS3ClientBuilder.standard()
                    .withCredentials(new AWSStaticCredentialsProvider(awsCreds))
                    .withClientConfiguration(new ClientConfiguration().withProtocol(Protocol.HTTP))
                    .withEndpointConfiguration(endpoint).build();
            transferManager = TransferManagerBuilder.standard().withS3Client(s3Client).build();
        } catch (SdkClientException e) {
            logger.error("Error: configuring the AWS S3: " + e.getMessage());
        }

	}


    public boolean upload(String path, File fileData) {
        logger.info("AWS S3: uploading to path: " + path);
        try {
            createConnection();
            if (s3Client != null) {
                transferManager.upload(new PutObjectRequest(bucketName, path, fileData)).waitForUploadResult();
                //s3Client.putObject(new PutObjectRequest(bucketName, path, fileData));
            } else {
                logger.info("Connection not established with s3");
                return false;
            }
        } catch (Exception e) {
            logger.error("Error uploading file: " + e.getMessage());
            return false;
        }

        s3Client.shutdown();
        return true;
    }


    public boolean delete(String key) {
        try {
            if (key == null) {
                logger.info("Invalid key for s3 deletion");
                return false;
            }
            createConnection();
            logger.info("AWS:S3 deleting file: " + key);
            s3Client.deleteObject(new DeleteObjectRequest(bucketName, key));
        } catch (Exception e) {
            logger.info("Error during deletion" + e.getMessage());
            return false;
        }

        s3Client.shutdown();
        return true;
    }

    public boolean uploadInputStream(String path, InputStream inputStream) {
        logger.info("AWS S3: uploading to path: " + path);
        try {
            createConnection();
            if (s3Client != null) {
                transferManager.upload(new PutObjectRequest(bucketName, path, inputStream, new ObjectMetadata())).
                        waitForUploadResult();
            } else {
                logger.info("Connection not established with s3");
                return false;
            }
        } catch (Exception e) {
            logger.error("Error uploading file: " + e.getMessage());
            return false;
        }

        s3Client.shutdown();
        return true;
    }


    public InputStream downloadFile(String key) {
        try {
            logger.info("AWS:S3 downloading file: " + key);
            createConnection();
            S3Object s3FileObject = s3Client.getObject(new GetObjectRequest(new S3ObjectId(bucketName, key)));
            InputStream inputStream = s3FileObject.getObjectContent();
            PushbackInputStream pushbackInputStream = new PushbackInputStream(inputStream);
            return pushbackInputStream;
        } catch (Exception e) {
            logger.info("Error downloading the file for key: " +key+" caused by: "+ e.getMessage());
            return null;
        }
    }


}
