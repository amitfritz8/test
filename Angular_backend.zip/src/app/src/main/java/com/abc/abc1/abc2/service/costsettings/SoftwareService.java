package com.dbs.genesis.portfolio.service.costsettings;

import com.dbs.genesis.portfolio.common.DateExtensions;
import com.dbs.genesis.portfolio.common.MathExtentions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.mapper.CostSettingSoftwareMapper;
import com.dbs.genesis.portfolio.model.*;
import com.dbs.genesis.portfolio.repository.PortfolioRepo;
import com.dbs.genesis.portfolio.repository.SubWorkStreamKeyDatesRepo;
import com.dbs.genesis.portfolio.repository.SubWorkstreamSoftwareCostRepo;
import com.dbs.genesis.portfolio.repository.WorkStreamRepo;
import com.dbs.genesis.portfolio.resources.FinancialDetailsResource;
import com.dbs.genesis.portfolio.resources.SubWorkStreamSoftwareCostHolder;
import com.dbs.genesis.portfolio.resources.SubWorkStreamSoftwareCostResource;
import com.dbs.genesis.portfolio.resources.SubWorkStreamSoftwareCostResourceHolder;
import com.dbs.genesis.portfolio.service.SubWorkStreamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


@Service
public class SoftwareService implements DateExtensions, MathExtentions {
    @Autowired
    CostSettingSoftwareMapper costSettingSoftwareMapper;
    @Autowired
    SubWorkstreamSoftwareCostRepo subWorkstreamSoftwareCostRepo;
    @Autowired
    FinancialDetailsService financialDetailsService;
    @Autowired
    SubWorkStreamService subWorkStreamService;

    @Autowired
    private SubWorkStreamKeyDatesRepo subWorkStreamKeyDatesRepo;
    @Autowired
    private WorkStreamRepo workStreamRepo;
    @Autowired
    private PortfolioRepo portfolioRepo;


    public List<SubWorkStreamSoftwareCostResourceHolder> getCostSettingDetails(String workStreamId,
                                                                               String subWorkstreamId,
                                                                               String subWorkstreamName,
                                                                               String scenario,
                                                                               String loggedInUserCurrency) {
        List<SubWorkstreamSoftwareCost> subWorkStreamSoftwareCosts = new ArrayList<>();
        List<SubWorkstreamSoftwareCost> subWorkStreamSoftwareCostList = subWorkstreamSoftwareCostRepo.
                findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalInd
                        (subWorkstreamId, subWorkstreamName, scenario, PortfolioConstants.TRUE, PortfolioConstants.TRUE);
        subWorkStreamSoftwareCostList.forEach(subWorkStreamSoftwareCost -> {
            if (PortfolioConstants.OPEX.equalsIgnoreCase(subWorkStreamSoftwareCost.getGlCategory()) || PortfolioConstants.CAPEX.equalsIgnoreCase(subWorkStreamSoftwareCost.getGlCategory())) {
                subWorkStreamSoftwareCosts.add(subWorkStreamSoftwareCost);
            }
        });
        List<SubWorkStreamSoftwareCostResource> subWorkStreamSoftwareCostResources =
                convertSubWorkStreamSoftwareCostEntityToResource(workStreamId, subWorkStreamSoftwareCosts, loggedInUserCurrency);
        return costSettingSoftwareMapper.getVendorNameWithSoftwareList(subWorkStreamSoftwareCostResources);
    }

    public Map<String, List<List<SubWorkStreamSoftwareCostHolder>>> processCostSetting(FinancialDetailsResource financialDetailsResource,
                                                                                       List<String> currentYearMonthBetweenDates) {
        List<SubWorkStreamSoftwareCostResource> createSoftwareList = new ArrayList<>();
        List<SubWorkStreamSoftwareCostResource> inactiveSoftwareList = new ArrayList<>();
        Map<String, List<List<SubWorkStreamSoftwareCostHolder>>> dbOpTypeAndSoftwareCostHoldersMap = new HashMap<>();

        financialDetailsResource.getSoftwares().forEach(softwares -> {
            softwares.getSoftware().stream().filter(SubWorkStreamSoftwareCostResource::validate).forEach(software -> {
                if ((software.getSurrId() == null) || (software.getSurrId() == 0)) {
                    createSoftwareList.add(software);
                } else if (software.getActiveInd().equals(PortfolioConstants.FALSE)) {
                    inactiveSoftwareList.add(software);
                } else {
                    inactiveSoftwareList.add(software);
                    createSoftwareList.add(software);
                }

            });
        });
        if (createSoftwareList.size() > 0) {
            dbOpTypeAndSoftwareCostHoldersMap.put(PortfolioConstants.CREATE,
                    convertSoftwareResourceToEntityForCreate(financialDetailsResource,
                            createSoftwareList, currentYearMonthBetweenDates,
                            PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS));
        }

        if (inactiveSoftwareList.size() > 0) {
            List<List<SubWorkStreamSoftwareCostHolder>> subWorkStreamSoftwareCostHolderBasedOnGLCategories = new ArrayList<>();
            List<SubWorkStreamSoftwareCostHolder> subWorkStreamSoftwareCostHolders = new ArrayList<>();
            Set<Integer> surrIds = new HashSet<>();
            inactiveSoftwareList.forEach(inactiveSoftware -> {
                surrIds.add(inactiveSoftware.getSurrId());
            });
            List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCostsForInactive =
                    subWorkstreamSoftwareCostRepo.findAllByParentOrChildIdIn(surrIds, surrIds);
            SubWorkStreamSoftwareCostHolder subWorkStreamSoftwareCostHolder = new SubWorkStreamSoftwareCostHolder();
            subWorkStreamSoftwareCostHolder.setSubWorkstreamSoftwareCosts(subWorkstreamSoftwareCostsForInactive);
            subWorkStreamSoftwareCostHolders.add(subWorkStreamSoftwareCostHolder);
            subWorkStreamSoftwareCostHolderBasedOnGLCategories.add(subWorkStreamSoftwareCostHolders);
            dbOpTypeAndSoftwareCostHoldersMap.put(PortfolioConstants.INACTIVE, subWorkStreamSoftwareCostHolderBasedOnGLCategories);
        }
        return dbOpTypeAndSoftwareCostHoldersMap;
    }

    private List<List<SubWorkStreamSoftwareCostHolder>> convertSoftwareResourceToEntityForCreate(FinancialDetailsResource financialDetailsResource,
                                                                                                 List<SubWorkStreamSoftwareCostResource> createSoftwareList,
                                                                                                 List<String> currentYearMonthBetweenDates,
                                                                                                 String costSettings) {
        List<List<SubWorkStreamSoftwareCostHolder>> subWorkStreamSoftwareCostHolderBasedOnGLCategories = new ArrayList<>();

        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(financialDetailsResource.getWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamName(), PortfolioConstants.TRUE, financialDetailsResource.getScenario());

        createSoftwareList.forEach(software -> {
            List<SubWorkStreamSoftwareCostHolder> subWorkstreamSoftwareCostsHolders = new ArrayList<>();
            List<String> glCategories = new ArrayList<>();
            getGLCategoriesList(financialDetailsResource, software, glCategories);

            for (String glCategory : glCategories) {
                Map<String, Object> dateDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategories(financialDetailsResource.getWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamId(), financialDetailsResource.getSubWorkStreamName(), financialDetailsResource.getScenario(), glCategory, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
                List<String> monthBetweenDates = (List<String>) dateDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);

                calculateCostPerMonthForITDepreciation(glCategory, financialDetailsResource, software, monthBetweenDates);

                SubWorkStreamSoftwareCostHolder subWorkStreamSoftwareCostHolder = new SubWorkStreamSoftwareCostHolder();
                monthBetweenDates.forEach(monthYearDate -> {
                    if (subWorkStreamSoftwareCostHolder.getSubWorkstreamSoftwareCost() == null)
                        subWorkStreamSoftwareCostHolder.setSubWorkstreamSoftwareCost(
                                populateSubWorkStreamSoftwareCostForCreate(software, financialDetailsResource,
                                        getCurrentPeriodAsMonthYear(), monthBetweenDates.size(), costSettings,
                                        Boolean.TRUE, glCategory));
                    SubWorkstreamSoftwareCost subWorkstreamSoftwareCost =
                            populateSubWorkStreamSoftwareCostForCreate(software, financialDetailsResource,
                                    monthYearDate, monthBetweenDates.size(), costSettings, Boolean.FALSE, glCategory);
                    subWorkStreamSoftwareCostHolder.getSubWorkstreamSoftwareCosts().add(subWorkstreamSoftwareCost);
                });
                if (PortfolioConstants.OPEX.equalsIgnoreCase(glCategory)) {
                    getCapexAndOpexDefaultMonthsData(financialDetailsResource, software,
                            costSettings, PortfolioConstants.OPEX, subWorkStreamSoftwareCostHolder);
                }
                if (PortfolioConstants.CAPEX.equalsIgnoreCase(glCategory)) {
                    getCapexAndOpexDefaultMonthsData(financialDetailsResource, software,
                            costSettings, PortfolioConstants.CAPEX, subWorkStreamSoftwareCostHolder);
                }

                if(PortfolioConstants.OWNERSHIP.equalsIgnoreCase(glCategory)) {
                    try {
                        DateFormat formatter = new SimpleDateFormat("yyyyMM");
                        java.util.Date goLiveDate = subWorkStreamKeyDatesEntity.getGoLiveDate();
                        for (SubWorkstreamSoftwareCost subWorkStreamSoftwareCost: subWorkStreamSoftwareCostHolder.getSubWorkstreamSoftwareCosts()) {
                            java.util.Date monthYear = formatter.parse(subWorkStreamSoftwareCost.getPeriod());
                            if (monthYear.compareTo(goLiveDate) > 0 && "false".equalsIgnoreCase(subWorkStreamSoftwareCost.getOriginalInd())) {
                                subWorkStreamSoftwareCost.setCostPerMonthGcy(BigDecimal.ZERO);
                                subWorkStreamSoftwareCost.setCostPerMonthLcy(BigDecimal.ZERO);
                            }

                        }
                    } catch (Exception e) {
                        log.info("convertSoftwareToEntityForCreate date parsing error",e);
                    }
                }

                subWorkstreamSoftwareCostsHolders.add(subWorkStreamSoftwareCostHolder);
            }
            subWorkStreamSoftwareCostHolderBasedOnGLCategories.add(subWorkstreamSoftwareCostsHolders);
        });
        return subWorkStreamSoftwareCostHolderBasedOnGLCategories;
    }

    private void getCapexAndOpexDefaultMonthsData(FinancialDetailsResource financialDetailsResource, SubWorkStreamSoftwareCostResource software,
                                                  String costSettings, String glCategory, SubWorkStreamSoftwareCostHolder subWorkStreamSoftwareCostHolder) {
        SubWorkStreamKeyDatesEntity subWorkStreamKeyDatesEntity = subWorkStreamKeyDatesRepo.
                findByWorkStreamIdAndSubWorkStreamIdAndSubWorkStreamNameAndActiveIndAndScenarioName(financialDetailsResource.getWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamId(), financialDetailsResource.getSubWorkStreamName(), PortfolioConstants.TRUE,
                        financialDetailsResource.getScenario());
        Map<String, Object> monthDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategories(financialDetailsResource.getWorkStreamId(),
                financialDetailsResource.getSubWorkStreamId(), financialDetailsResource.getSubWorkStreamName(), financialDetailsResource.getScenario(),
                glCategory, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
        List<String> monthBetweenDates = (List<String>) monthDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);
        SubWorkStreamSoftwareCostResource softwareCost = buildSubWorkStreamSoftwareCostResource(software);

        List<String> monthBetweenDatesCurrentmonthTOStartMonth = getCurrentYearMonthBetweenDatesDefault(getCurrentPeriodAsMonthYear(), monthBetweenDates.get(0));
        monthBetweenDatesCurrentmonthTOStartMonth.remove(monthBetweenDatesCurrentmonthTOStartMonth.size() - 1);
        monthBetweenDatesCurrentmonthTOStartMonth.forEach(monthYearDate -> {
            SubWorkstreamSoftwareCost subWorkstreamSoftwareCost =
                    populateSubWorkStreamSoftwareCostForCreate(softwareCost, financialDetailsResource,
                            monthYearDate, monthBetweenDatesCurrentmonthTOStartMonth.size(), costSettings, Boolean.FALSE, glCategory);
            subWorkStreamSoftwareCostHolder.getSubWorkstreamSoftwareCosts().add(subWorkstreamSoftwareCost);
        });
        WorkStreamEntity workStreamEntity = workStreamRepo.findByWorkStreamId(financialDetailsResource.getWorkStreamId());
        PortfolioEntity portfolioId = portfolioRepo.findByPortfolioId(workStreamEntity.getPortfolioId());
        Date depreStartDate = subWorkStreamKeyDatesEntity.getDepreStartDate();
        if(depreStartDate == null){
            depreStartDate = calculateDepreStartDate(subWorkStreamKeyDatesEntity.getGoLiveDate(),portfolioId.getAgileWaterFall());
        }
        log.info("calculated Depre start date:"+depreStartDate);
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        List<String> monthBetweenDatesEndMonthToDepreStartDatefiveYears = getCurrentYearMonthBetweenDatesDefault(monthBetweenDates.get(monthBetweenDates.size() - 1),
                getMonths(df.format(depreStartDate).substring(0, 7), 59).replaceAll("-", ""));
        monthBetweenDatesEndMonthToDepreStartDatefiveYears.remove(0);
        monthBetweenDatesEndMonthToDepreStartDatefiveYears.forEach(monthYearDate -> {
            SubWorkstreamSoftwareCost subWorkstreamSoftwareCost =
                    populateSubWorkStreamSoftwareCostForCreate(softwareCost, financialDetailsResource,
                            monthYearDate, monthBetweenDatesEndMonthToDepreStartDatefiveYears.size(), costSettings, Boolean.FALSE, glCategory);
            subWorkStreamSoftwareCostHolder.getSubWorkstreamSoftwareCosts().add(subWorkstreamSoftwareCost);
        });
    }

    private SubWorkStreamSoftwareCostResource buildSubWorkStreamSoftwareCostResource(SubWorkStreamSoftwareCostResource software) {
        SubWorkStreamSoftwareCostResource softwareCost = new SubWorkStreamSoftwareCostResource();
        softwareCost.setQty(BigDecimal.ZERO);
        softwareCost.setUnitPrice(software.getUnitPrice());
        softwareCost.setCostPerMonth(BigDecimal.ZERO);
        softwareCost.setCurrency(software.getCurrency());
        softwareCost.setSoftwareName(software.getSoftwareName());
        softwareCost.setSoftwareType(software.getSoftwareType());
        softwareCost.setVendor(software.getVendor());
        softwareCost.setActiveInd(software.getActiveInd());
        return softwareCost;
    }

    private void getGLCategoriesList(FinancialDetailsResource financialDetailsResource, SubWorkStreamSoftwareCostResource software,
                                     List<String> glCategories) {
        if (PortfolioConstants.OPEX.equalsIgnoreCase(calculateOpexCapexForSoftware(software.getSoftwareType(),
                financialDetailsResource.getAddSoftware(), software.getUnitPrice()))) {
            glCategories.add(PortfolioConstants.OPEX);
            glCategories.add(PortfolioConstants.OWNERSHIP);
        } else if (PortfolioConstants.CAPEX.equalsIgnoreCase(calculateOpexCapexForSoftware(software.getSoftwareType(),
                financialDetailsResource.getAddSoftware(), software.getUnitPrice()))) {
            glCategories.add(PortfolioConstants.CAPEX);
            glCategories.add(PortfolioConstants.ITDEPRECIATION);
        }
    }

    private void calculateCostPerMonthForITDepreciation(String glCategory, FinancialDetailsResource financialDetailsResource,
                                                        SubWorkStreamSoftwareCostResource software, List<String> monthBetweenDates) {
        if (PortfolioConstants.ITDEPRECIATION.equalsIgnoreCase(glCategory)) {
            Map<String, Object> capexMonthDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategories(financialDetailsResource.getWorkStreamId(),
                    financialDetailsResource.getSubWorkStreamId(), financialDetailsResource.getSubWorkStreamName(), financialDetailsResource.getScenario(),
                    PortfolioConstants.CAPEX, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
            List<String> capexMonthBetweenDates = (List<String>) capexMonthDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);
            BigDecimal CostPerMonthTotal = software.getCostPerMonth().multiply(BigDecimal.valueOf(capexMonthBetweenDates.size()));
            software.setCostPerMonth(CostPerMonthTotal.divide(BigDecimal.valueOf(monthBetweenDates.size()), 9, RoundingMode.HALF_UP));
        }
    }

    private SubWorkstreamSoftwareCost populateSubWorkStreamSoftwareCostForCreate(SubWorkStreamSoftwareCostResource softwareCost,
                                                                                 FinancialDetailsResource financialDetails,
                                                                                 String monthYearDate, int noOfMonths,
                                                                                 String costSettings, Boolean original, String glCategory) {
        SubWorkstreamSoftwareCost subWorkstreamSoftwareCost = new SubWorkstreamSoftwareCost();
        subWorkstreamSoftwareCost.setWorkStreamId(financialDetails.getWorkStreamId());
        subWorkstreamSoftwareCost.setSubWorkStreamId(financialDetails.getSubWorkStreamId());
        subWorkstreamSoftwareCost.setSubWorkStreamName(financialDetails.getSubWorkStreamName());
        subWorkstreamSoftwareCost.setScenario(financialDetails.getScenario());
        subWorkstreamSoftwareCost.setCostSettings(costSettings);
        subWorkstreamSoftwareCost.setCostTypeDetail(financialDetails.getScenario());
        subWorkstreamSoftwareCost.setSoftwareName(softwareCost.getSoftwareName());
        subWorkstreamSoftwareCost.setSoftwareType(softwareCost.getSoftwareType());
        subWorkstreamSoftwareCost.setVendorName(softwareCost.getVendor());
        subWorkstreamSoftwareCost.setEffectiveStartDate(new Timestamp(financialDetails.getStartDate().getTime()));
        subWorkstreamSoftwareCost.setEffectiveEndDate(new Timestamp(financialDetails.getGoLiveDate().getTime()));
        subWorkstreamSoftwareCost.setActiveInd(softwareCost.getActiveInd());
        subWorkstreamSoftwareCost.setAdd_software(PortfolioConstants.ADD_SOFTWARE_PQ);
        subWorkstreamSoftwareCost.setGlCategory(glCategory);
        subWorkstreamSoftwareCost.setUnitPrice(softwareCost.getUnitPrice());
        subWorkstreamSoftwareCost.setQuantity(softwareCost.getQty());
        subWorkstreamSoftwareCost.setPeriod(monthYearDate);
        if (original) {
            subWorkstreamSoftwareCost.setOriginalInd(PortfolioConstants.TRUE);
        } else {
            subWorkstreamSoftwareCost.setOriginalInd(PortfolioConstants.FALSE);
        }

        if (softwareCost.getUnitPrice() != null && softwareCost.getQty() != null) {
            updateCurrencyValuesForSoftware(subWorkstreamSoftwareCost, softwareCost.getCurrency(),
                    softwareCost.getCostPerMonth(), financialDetails);
            //Monthly Split
            if (!original) {
                subWorkstreamSoftwareCost.setQuantity(softwareCost.getQty());
                subWorkstreamSoftwareCost.setCostPerMonthLcy(subWorkstreamSoftwareCost.getCostPerMonthLcy());
                subWorkstreamSoftwareCost.setCostPerMonthGcy(subWorkstreamSoftwareCost.getCostPerMonthGcy());
            }
        }
        return subWorkstreamSoftwareCost;
    }

    public List<List<SubWorkStreamSoftwareCostHolder>> convertSoftwareResourceToEntityForUpdate(FinancialDetailsResource financialDetailsResource,
                                                                                                List<SubWorkStreamSoftwareCostResource> updateSoftwareList,
                                                                                                List<String> currentYearMonthBetweenDates,
                                                                                                Map<Integer, List<SubWorkstreamSoftwareCost>> entitiesPerRefSwsSwSurrId) {
        List<List<SubWorkStreamSoftwareCostHolder>> subWorkStreamSoftwareCostHolderBasedOnGLCategories = new ArrayList<>();

        updateSoftwareList.forEach(softwareCostResource -> {
            List<SubWorkStreamSoftwareCostHolder> subWorkstreamSoftwareCostsHolders = new ArrayList<>();

            List<String> glCategories = new ArrayList<>();
            getGLCategoriesList(financialDetailsResource, softwareCostResource, glCategories);

            for (String glCategory : glCategories) {
                Map<String, Object> dateDetails = subWorkStreamService.getSubWorkStreamKeyDatesBasedOnGLCategories(financialDetailsResource.getWorkStreamId(),
                        financialDetailsResource.getSubWorkStreamId(), financialDetailsResource.getSubWorkStreamName(), financialDetailsResource.getScenario(),
                        glCategory, PortfolioConstants.COST_SETTING_TYPE_FINANCIAL_DETAILS);
                List<String> monthBetweenDates = (List<String>) dateDetails.get(PortfolioConstants.MONTHS_BETWEEN_DATES);

                calculateCostPerMonthForITDepreciation(glCategory, financialDetailsResource, softwareCostResource, monthBetweenDates);

                SubWorkStreamSoftwareCostHolder subWorkStreamSoftwareCostHolder = new SubWorkStreamSoftwareCostHolder();
                monthBetweenDates.forEach(monthYearDate -> {
                    SubWorkstreamSoftwareCost subWorkstreamSoftwareCost =
                            populateSoftwareCostOriginalResourceToEntityForUpdate(softwareCostResource,
                                    financialDetailsResource);

                    List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCosts = entitiesPerRefSwsSwSurrId.get(softwareCostResource.getSurrId());
                    populateSoftwareCostResourceToEntityForUpdate(softwareCostResource, subWorkstreamSoftwareCosts,
                            monthBetweenDates.size(), financialDetailsResource);
                    subWorkStreamSoftwareCostHolder.setSubWorkstreamSoftwareCost(subWorkstreamSoftwareCost);
                    subWorkStreamSoftwareCostHolder.setSubWorkstreamSoftwareCosts(subWorkstreamSoftwareCosts);
                });
                subWorkstreamSoftwareCostsHolders.add(subWorkStreamSoftwareCostHolder);
            }
            subWorkStreamSoftwareCostHolderBasedOnGLCategories.add(subWorkstreamSoftwareCostsHolders);
        });
        return subWorkStreamSoftwareCostHolderBasedOnGLCategories;
    }

    private SubWorkstreamSoftwareCost populateSoftwareCostOriginalResourceToEntityForUpdate(
            SubWorkStreamSoftwareCostResource softwareCostOriginalResource,
            FinancialDetailsResource financialDetails) {
        SubWorkstreamSoftwareCost subWorkstreamSoftwareCostDetails = subWorkstreamSoftwareCostRepo.findAllBySwsSwSurrId(softwareCostOriginalResource.getSurrId());
        SubWorkstreamSoftwareCost subWorkstreamSoftwareCost = new SubWorkstreamSoftwareCost();
        subWorkstreamSoftwareCost.setSwsSwSurrId(softwareCostOriginalResource.getSurrId());
        subWorkstreamSoftwareCost.setWorkStreamId(financialDetails.getWorkStreamId());
        subWorkstreamSoftwareCost.setSubWorkStreamId(financialDetails.getSubWorkStreamId());
        subWorkstreamSoftwareCost.setSubWorkStreamName(financialDetails.getSubWorkStreamName());
        subWorkstreamSoftwareCost.setScenario(financialDetails.getScenario());
        subWorkstreamSoftwareCost.setSoftwareName(softwareCostOriginalResource.getSoftwareName());
        subWorkstreamSoftwareCost.setSoftwareType(softwareCostOriginalResource.getSoftwareType());
        subWorkstreamSoftwareCost.setVendorName(softwareCostOriginalResource.getVendor());
        subWorkstreamSoftwareCost.setEffectiveStartDate(new Timestamp(financialDetails.getStartDate().getTime()));
        subWorkstreamSoftwareCost.setEffectiveEndDate(new Timestamp(financialDetails.getGoLiveDate().getTime()));
        subWorkstreamSoftwareCost.setActiveInd(softwareCostOriginalResource.getActiveInd());
        subWorkstreamSoftwareCost.setAdd_software(PortfolioConstants.ADD_SOFTWARE_PQ);
        subWorkstreamSoftwareCost.setGlCategory(subWorkstreamSoftwareCostDetails.getGlCategory());
        subWorkstreamSoftwareCost.setOriginalInd(PortfolioConstants.TRUE);
        subWorkstreamSoftwareCost.setQuantity(softwareCostOriginalResource.getQty());
        subWorkstreamSoftwareCost.setUnitPrice(softwareCostOriginalResource.getUnitPrice());
        subWorkstreamSoftwareCost.setPeriod(getCurrentPeriodAsMonthYear());
        if (softwareCostOriginalResource.getUnitPrice() != null && softwareCostOriginalResource.getQty() != null) {
            updateCurrencyValuesForSoftware(subWorkstreamSoftwareCost, softwareCostOriginalResource.getCurrency(),
                    softwareCostOriginalResource.getCostPerMonth(), financialDetails);
        }
        return subWorkstreamSoftwareCost;
    }

    private void populateSoftwareCostResourceToEntityForUpdate(
            SubWorkStreamSoftwareCostResource subWorkstreamSoftwareCostResource,
            List<SubWorkstreamSoftwareCost> subWorkstreamSoftwareCosts, int noOfMonths,
            FinancialDetailsResource financialDetails) {
        subWorkstreamSoftwareCosts.forEach(subWorkstreamSoftwareCost -> {
            subWorkstreamSoftwareCost.setWorkStreamId(financialDetails.getWorkStreamId());
            subWorkstreamSoftwareCost.setSubWorkStreamId(financialDetails.getSubWorkStreamId());
            subWorkstreamSoftwareCost.setSubWorkStreamName(financialDetails.getSubWorkStreamName());
            subWorkstreamSoftwareCost.setScenario(financialDetails.getScenario());
            subWorkstreamSoftwareCost.setSoftwareName(subWorkstreamSoftwareCostResource.getSoftwareName());
            subWorkstreamSoftwareCost.setSoftwareType(subWorkstreamSoftwareCostResource.getSoftwareType());
            subWorkstreamSoftwareCost.setVendorName(subWorkstreamSoftwareCostResource.getVendor());
            subWorkstreamSoftwareCost.setActiveInd(subWorkstreamSoftwareCostResource.getActiveInd());
            subWorkstreamSoftwareCost.setLocalCcy(subWorkstreamSoftwareCostResource.getCurrency());
            subWorkstreamSoftwareCost.setGroupCcy(subWorkstreamSoftwareCostResource.getCostInCurrency());
            subWorkstreamSoftwareCost.setCostPerMonthLcy(subWorkstreamSoftwareCostResource.getCostPerMonth());
            subWorkstreamSoftwareCost.setCostPerMonthGcy(subWorkstreamSoftwareCostResource.getCostPerMonth());
            subWorkstreamSoftwareCost.setAdd_software(PortfolioConstants.ADD_SOFTWARE_PQ);
            subWorkstreamSoftwareCost.setGlCategory(subWorkstreamSoftwareCost.getGlCategory());
            subWorkstreamSoftwareCost.setOriginalInd(PortfolioConstants.FALSE);
            subWorkstreamSoftwareCost.setUnitPrice(subWorkstreamSoftwareCostResource.getUnitPrice());
            subWorkstreamSoftwareCost.setQuantity(subWorkstreamSoftwareCostResource.getQty());

            if (subWorkstreamSoftwareCostResource.getUnitPrice() != null && subWorkstreamSoftwareCostResource.getQty() != null) {
                updateCurrencyValuesForSoftware(subWorkstreamSoftwareCost, subWorkstreamSoftwareCostResource.getCurrency(),
                        subWorkstreamSoftwareCostResource.getCostPerMonth(),
                        financialDetails);
                //Monthly Split
                subWorkstreamSoftwareCost.setQuantity(subWorkstreamSoftwareCostResource.getQty());
                subWorkstreamSoftwareCost.setCostPerMonthLcy(subWorkstreamSoftwareCost.getCostPerMonthLcy());
                subWorkstreamSoftwareCost.setCostPerMonthGcy(subWorkstreamSoftwareCost.getCostPerMonthGcy());
            }

        });
    }

    private String calculateOpexCapexForSoftware(String softwareType, String addSoftware, BigDecimal unitPrice) {
        if (PortfolioConstants.SOFTWARE_TYPE_PERPETUAL.equals(softwareType)) {
            int compartResult = unitPrice.compareTo(BigDecimal.valueOf(2000));
            if (compartResult >= 0) {
                return PortfolioConstants.CAPEX;
            }
        }
        return PortfolioConstants.OPEX;
    }

    private void updateCurrencyValuesForSoftware(SubWorkstreamSoftwareCost subWorkstreamSoftwareCost,
                                                 String loggedInCurrencyCode, BigDecimal costPerMonth, FinancialDetailsResource financialDetails) {
        if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(loggedInCurrencyCode)) {
            subWorkstreamSoftwareCost.setLocalCcy(loggedInCurrencyCode);
            subWorkstreamSoftwareCost.setCostPerMonthLcy(costPerMonth);
            subWorkstreamSoftwareCost.setGroupCcy(loggedInCurrencyCode);
            subWorkstreamSoftwareCost.setCostPerMonthGcy(costPerMonth);

        } else {
            subWorkstreamSoftwareCost.setLocalCcy(loggedInCurrencyCode);
            subWorkstreamSoftwareCost.setCostPerMonthLcy(costPerMonth);
            subWorkstreamSoftwareCost.setGroupCcy(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD);
            ExchangeRatesEntity exchangeRatesEntity = financialDetailsService.getExchangeRatesEntity(subWorkstreamSoftwareCost.getPeriod(),
                    loggedInCurrencyCode, financialDetails.getWorkStreamId());
            subWorkstreamSoftwareCost.setCostPerMonthGcy((costPerMonth).multiply(
                    (exchangeRatesEntity != null && exchangeRatesEntity.getRateValue() != null) ? exchangeRatesEntity.getRateValue() : BigDecimal.ZERO));
        }
    }

    public List<SubWorkStreamSoftwareCostResource> convertSubWorkStreamSoftwareCostEntityToResource(
            String workStreamId,
            List<SubWorkstreamSoftwareCost> subWorkStreamSoftwareCosts,
            String loggedInUserCurrency) {
        List<SubWorkStreamSoftwareCostResource> subWorkStreamSoftwareCostResources = new ArrayList<>();
        subWorkStreamSoftwareCosts.forEach(softwareCost -> {
            SubWorkStreamSoftwareCostResource subWorkStreamSoftwareCostResource = new SubWorkStreamSoftwareCostResource();
            subWorkStreamSoftwareCostResource.setSoftwareName(softwareCost.getSoftwareName());
            subWorkStreamSoftwareCostResource.setSoftwareType(softwareCost.getSoftwareType());
            subWorkStreamSoftwareCostResource.setQty(softwareCost.getQuantity());
            subWorkStreamSoftwareCostResource.setVendor(softwareCost.getVendorName());
            subWorkStreamSoftwareCostResource.setActiveInd(softwareCost.getActiveInd());
            subWorkStreamSoftwareCostResource.setSurrId(softwareCost.getSwsSwSurrId());

            convertCurrencyToLoggedInCurrencyForView(subWorkStreamSoftwareCostResource, loggedInUserCurrency,
                    workStreamId, softwareCost);
            subWorkStreamSoftwareCostResources.add(subWorkStreamSoftwareCostResource);
        });
        return subWorkStreamSoftwareCostResources;
    }

    private void convertCurrencyToLoggedInCurrencyForView(
            SubWorkStreamSoftwareCostResource subWorkStreamSoftwareCostResource,
            String loggedInUserCurrency, String workStreamId, SubWorkstreamSoftwareCost softwareCost) {
        subWorkStreamSoftwareCostResource.setCurrency(loggedInUserCurrency);
        subWorkStreamSoftwareCostResource.setCostInCurrency(loggedInUserCurrency);
        if (loggedInUserCurrency.equalsIgnoreCase(softwareCost.getLocalCcy())) {
            //When loggedInCurrency is same to previous localCurrency
            subWorkStreamSoftwareCostResource.setUnitPrice(softwareCost.getUnitPrice());
        } else if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(loggedInUserCurrency)) {
            //When loggedInCurrency is also SGD
            subWorkStreamSoftwareCostResource.setUnitPrice(softwareCost.getUnitPrice().multiply(
                    financialDetailsService.getExchangeRatesEntity(softwareCost.getPeriod(),
                            softwareCost.getLocalCcy(), workStreamId).getRateValue()));
        } else {
            // When loggedInCurrency is different from currnet localCcy/globalCcy in db
            BigDecimal rateValueLocalCcyValToSgd = financialDetailsService.getExchangeRatesEntity(softwareCost.getPeriod(),
                    softwareCost.getLocalCcy(), workStreamId).getRateValue();
            BigDecimal valueLocalCcyValToSgd = softwareCost.getUnitPrice().multiply(rateValueLocalCcyValToSgd);
            BigDecimal rateValueLoggedInCurrencyToSgd = financialDetailsService.getExchangeRatesEntity(softwareCost.getPeriod(),
                    loggedInUserCurrency, workStreamId).getRateValue();
            BigDecimal convertedValueForLoggedInCurrency = divideWithScaleHalfUp(valueLocalCcyValToSgd, rateValueLoggedInCurrencyToSgd);
            subWorkStreamSoftwareCostResource.setUnitPrice(convertedValueForLoggedInCurrency);
        }
        subWorkStreamSoftwareCostResource.setCostPerMonth(subWorkStreamSoftwareCostResource.getUnitPrice().
                multiply(softwareCost.getQuantity()));
    }
}