package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class SeedFundingOperationCostResource {

    Date startDate;
    Date goLiveDate;
    String currencyCode;
    String scenario;
    String workStreamId;
    String subWorkStreamId;
    String subWorkStreamName;
    List<SeedFundingCostType> seedFundingCostTypes;
    Timestamp dateCreated;
    Timestamp modifiedDate;
    String createdBy;
    String modifiedBy;
}
