package com.dbs.genesis.portfolio;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Delete4 {

    public static void main(String[] args) {
        List<String> list1 = new ArrayList<>();
        list1.add("08");
        list1.add("01");
        list1.add("03");
        list1.add("02");

        List<Delete> deleteList = new ArrayList<>();

        Delete delete = new Delete();
        delete.setGetMonthNumber("08");
        delete.setGetMonthNumber("01");
        delete.setGetMonthNumber("03");
        delete.setGetMonthNumber("02");
        deleteList.add(delete);


        List<Delete> collect = deleteList.stream().sorted(Comparator.comparing(Delete::getGetMonthNumber)).collect(Collectors.toList());
        collect.stream().forEach(delete1 -> {
            System.out.println(delete1);
        });


//        Collections.sort(deleteList, (o1, o2) -> (o1.getMonthNumber().compareTo(o2.getMonthNumber())));

//        /Collections.sort(deleteList,Comparator.comparingInt(Integer::valueOf(Delete::getGetMonthNumber)));


        System.out.println(list1.stream().sorted(String::compareToIgnoreCase).collect(Collectors.toList()));

        List<String> list = Arrays.asList("3", "2", "4", "10", "11", "6", "5", "8", "9", "7");
        list.sort(Comparator.comparingInt(Integer::valueOf));
        list.forEach(System.out::println);

        ArrayList<Delete5> dates = new ArrayList<>();

        dates.add(new Delete5("DDD", 2020, "02"));
        dates.add(new Delete5("AAA", 2022, "11"));
        dates.add(new Delete5("ZZZ", 2020, "05"));
        dates.add(new Delete5("AAA", 2021, "08"));
        dates.add(new Delete5("AAA", 2021, "07"));
        dates.add(new Delete5("DDD", 2021, "06"));
        dates.add(new Delete5("ZZZ", 2020, "01"));
        dates.add(new Delete5("AAA", 2021, "03"));
        dates.add(new Delete5("AAA", 2021, "04"));
        dates.add(new Delete5("DDD", 2021, "09"));
        dates.add(new Delete5("ZZZ", 2020, "10"));
        dates.add(new Delete5("ZZZ", 2020, "12"));

//        Collections.sort(dates, Comparator.comparing(Delete5::getMonth));
//        dates.sort(Comparator.comparing(Delete5::getNumericMonth));
//        Collections.sort(dates,new MonthComparator());

        dates.forEach(System.out::println);

    }

}
