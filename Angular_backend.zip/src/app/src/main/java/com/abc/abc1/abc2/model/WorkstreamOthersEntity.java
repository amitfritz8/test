package com.dbs.genesis.portfolio.model;

import com.dbs.genesis.portfolio.common.DateExtensions;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Data
@Entity
@Table(name = "workstream_others")
@EntityListeners(AuditingEntityListener.class)
@ToString
public class WorkstreamOthersEntity extends CommonEntity<String>  {


    @Id
    @Column(name = "ws_others_surr_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer wsOthersSurrId;
    @Column(name = "workstream_id")
    private String workStreamId;
    @Column(name = "portfolio_id")
    private String portfolioId;
    @Column(name = "workstream_name")
    private String workStreamName;
    @Column(name = "active_ind")
    private String activeInd;
    @Column(name = "document_type")
    private String documentType;
    @Column(name = "document_name")
    private String documentName;
    @Column(name = "description")
    private String description;
    @Column(name = "file_path")
    private String filePath;

    public static WorkstreamOthersEntity build(Integer workstreamOthersSurrId, String portfolioId,
                                                         String workStreamId, String documentName,
                                                         String documentType, String description,
                                                         String activeInd, String filePath,String createdBy,
                                                         String dateCreated, String modifiedBy,
                                                         String dateModified,String workstreamName){

        WorkstreamOthersEntity workstreamOthersEntity = new WorkstreamOthersEntity();
        workstreamOthersEntity.setWsOthersSurrId(workstreamOthersSurrId);
        workstreamOthersEntity.setPortfolioId(portfolioId);
        workstreamOthersEntity.setWorkStreamId(workStreamId);
        workstreamOthersEntity.setDocumentName(documentName);
        workstreamOthersEntity.setDocumentType(documentType);
        workstreamOthersEntity.setDescription(description);
        workstreamOthersEntity.setActiveInd(activeInd);
        workstreamOthersEntity.setFilePath(filePath);
        workstreamOthersEntity.setCreatedBy(createdBy);
        workstreamOthersEntity.setDateCreated(convertStrToTimestamp(dateCreated));
        workstreamOthersEntity.setModifiedBy(modifiedBy);
        workstreamOthersEntity.setDateModified(convertStrToTimestamp(dateModified));
        workstreamOthersEntity.setWorkStreamName(workstreamName);
        return workstreamOthersEntity;
    }

    private static Timestamp convertStrToTimestamp(String timestamp) {
        SimpleDateFormat sfdate = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        try {
            Date date = sfdate.parse(timestamp);
            return new Timestamp(date.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
}
