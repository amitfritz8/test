package com.dbs.genesis.portfolio.mapper;

import com.amazonaws.util.CollectionUtils;
import com.dbs.genesis.portfolio.common.MathExtentions;
import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.DataValues;
import com.dbs.genesis.portfolio.model.SubWorkStreamResourceCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamOtherCost;
import com.dbs.genesis.portfolio.resources.*;
import com.dbs.genesis.portfolio.service.DataSummaryService;
import com.dbs.genesis.portfolio.service.EmployeeRateCardService;
import com.dbs.genesis.portfolio.service.costsettings.FinancialDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
public class CostSettingsResourceMapper implements MathExtentions{

    @Autowired
    private EmployeeRateCardService employeeRateCardService;
    @Autowired
    private DataSummaryService dataSummaryService;
    @Autowired
    private FinancialDetailsService financialDetailsService;

    public List<SubWorkStreamResourceCostResource> mapSubWorkStreamResourceCostEntityToResource(
            List<SubWorkStreamResourceCost> subWorkStreamResourceCosts, String workStreamId, String loggedInUserCurrency) {
        return subWorkStreamResourceCosts.stream().map(resourceCost -> mapEntityToResource(resourceCost,
                workStreamId, loggedInUserCurrency)).collect(Collectors.toList());
    }

    private SubWorkStreamResourceCostResource mapEntityToResource(
            SubWorkStreamResourceCost resourceCost,
            String workStreamId, String loggedInUserCurrency){
        SubWorkStreamResourceCostResource subWorkStreamResourceCostResource = new SubWorkStreamResourceCostResource();
        subWorkStreamResourceCostResource.setSurrId(resourceCost.getSwsResourceSurrId());
        subWorkStreamResourceCostResource.setActiveInd(resourceCost.getActiveInd());
        subWorkStreamResourceCostResource.setRole(resourceCost.getTeamRole());
        subWorkStreamResourceCostResource.setLocation(resourceCost.getLocation());
        subWorkStreamResourceCostResource.setStaffType(resourceCost.getStaffType());
        subWorkStreamResourceCostResource.setVendor(resourceCost.getVendor());
        subWorkStreamResourceCostResource.setLevel(resourceCost.getStaffLevel());
        subWorkStreamResourceCostResource.setRateSource(resourceCost.getRateSource());
        subWorkStreamResourceCostResource.setFte(resourceCost.getFte());
        subWorkStreamResourceCostResource.setFdManDaysPerMonth(getFDManDaysPerMonth());
        convertCurrencyToLoggedInCurrencyForView(
                subWorkStreamResourceCostResource, loggedInUserCurrency, workStreamId, resourceCost);
        subWorkStreamResourceCostResource.setStaffRate(
                employeeRateCardService.getStaffRate(getStaffRateSource(subWorkStreamResourceCostResource)));
        return subWorkStreamResourceCostResource;
    }

    private void convertCurrencyToLoggedInCurrencyForView(
            SubWorkStreamResourceCostResource subWorkStreamResourceCostResource,
            String loggedInUserCurrency, String workStreamId, SubWorkStreamResourceCost resourceCost){
        BigDecimal fdManDaysPerMonth = subWorkStreamResourceCostResource.getFdManDaysPerMonth();
        subWorkStreamResourceCostResource.setCurrency(loggedInUserCurrency);
        if(loggedInUserCurrency.equalsIgnoreCase(resourceCost.getLocalCcy())) {
            //When loggedInCurrency is same to previous localCurrency
            subWorkStreamResourceCostResource.setCostPerDay(
                    divideWithScaleHalfUp(resourceCost.getBlendedCostLocalCcy(), fdManDaysPerMonth));
        }else if(PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(loggedInUserCurrency)){
            //When loggedInCurrency is also SGD
            BigDecimal currencyConvertedValue = resourceCost.getBlendedCostLocalCcy().multiply(
                    financialDetailsService.getExchangeRatesEntity(resourceCost.getPeriod(),
                            resourceCost.getLocalCcy(), workStreamId).getRateValue());
            subWorkStreamResourceCostResource.setCostPerDay(divideWithScaleHalfUp(currencyConvertedValue, fdManDaysPerMonth));
        }else {
            // When loggedInCurrency is different from currnet localCcy/globalCcy in db
            BigDecimal rateValueLocalCcyValToSgd = financialDetailsService.getExchangeRatesEntity(resourceCost.getPeriod(),
                    resourceCost.getLocalCcy(), workStreamId).getRateValue();
            BigDecimal valueLocalCcyValToSgd = resourceCost.getBlendedCostLocalCcy().multiply(rateValueLocalCcyValToSgd);
            BigDecimal rateValueLoggedInCurrencyToSgd = financialDetailsService.getExchangeRatesEntity(resourceCost.getPeriod(),
                    loggedInUserCurrency, workStreamId).getRateValue();
            BigDecimal convertedValueForLoggedInCurrency = divideWithScaleHalfUp(valueLocalCcyValToSgd, rateValueLoggedInCurrencyToSgd);
            subWorkStreamResourceCostResource.setCostPerDay(
                    divideWithScaleHalfUp(convertedValueForLoggedInCurrency, fdManDaysPerMonth));
        }
    }

    private StaffRateResource getStaffRateSource(SubWorkStreamResourceCostResource resourceCost){
        StaffRateResource staffRateResource = new StaffRateResource();
        staffRateResource.setCountryCode(resourceCost.getLocation());
        staffRateResource.setCurrencyCode(resourceCost.getCurrency());
        staffRateResource.setStaffType(resourceCost.getStaffType());
        staffRateResource.setVendorCode(resourceCost.getVendor());
        staffRateResource.setRateResource(resourceCost.getRateSource());
        staffRateResource.setRateLevel(resourceCost.getLevel());
        return staffRateResource;
    }

    private BigDecimal getFDManDaysPerMonth(){
        List<DataValues> dataValuesList = dataSummaryService.getDataValuesBySummary(PortfolioConstants.FD_MAN_DAYS_PER_MONTH);
        if(!CollectionUtils.isNullOrEmpty(dataValuesList)){
            return BigDecimal.valueOf(Double.parseDouble(dataValuesList.get(0).getValue()));
        }
        return null;
    }
}
