package com.dbs.genesis.portfolio.service.financials;

import com.dbs.genesis.portfolio.common.PortfolioConstants;
import com.dbs.genesis.portfolio.model.CommonEntity;
import com.dbs.genesis.portfolio.model.SubWorkstreamHardwareCost;
import com.dbs.genesis.portfolio.model.SubWorkstreamOtherCost;
import com.dbs.genesis.portfolio.repository.SubWorkstreamHardwareCostRepo;
import com.dbs.genesis.portfolio.resources.MonthlyCostTypeData;
import com.dbs.genesis.portfolio.resources.MonthlyFinancialDetailsResource;
import com.dbs.genesis.portfolio.resources.MonthlyFinancialResource;
import com.dbs.genesis.portfolio.service.costsettings.FinancialDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class FinancialHardwareService {

    private final SubWorkstreamHardwareCostRepo subWorkstreamHardwareCostRepo;
    private final FinancialDetailsService financialDetailsService;
    private final FinancialOthersService financialOthersService;
    private FinancialService financialService;

    public FinancialHardwareService(SubWorkstreamHardwareCostRepo subWorkstreamHardwareCostRepo, FinancialDetailsService financialDetailsService, FinancialOthersService financialOthersService, FinancialService financialService) {
        this.subWorkstreamHardwareCostRepo = subWorkstreamHardwareCostRepo;
        this.financialDetailsService = financialDetailsService;
        this.financialOthersService = financialOthersService;
        this.financialService = financialService;
    }

    public void persistHardware(MonthlyFinancialResource monthlyFinancialResource, MonthlyFinancialDetailsResource financialDetail, String year) {
         financialDetail.getMonthlyCostTypeDataList().stream().forEach(monthlyHardware -> {
            if(monthlyHardware.getName().startsWith(PortfolioConstants.OTHER_HARDWARE)){
                 financialOthersService.persistOthersIndividual(monthlyFinancialResource, monthlyHardware, year);
            }else {
                SubWorkstreamHardwareCost subWorkstreamHardwareCost = subWorkstreamHardwareCostRepo.findById(monthlyHardware.getSurrId()).get();
                List<SubWorkstreamHardwareCost> subWorkStreamHardwareCosts = getHardwareCostEntity(subWorkstreamHardwareCost,monthlyFinancialResource, monthlyHardware, year);
                 subWorkstreamHardwareCostRepo.saveAll(subWorkStreamHardwareCosts);
                if(PortfolioConstants.OPEX.equalsIgnoreCase(subWorkstreamHardwareCost.getGlCategory())){
                    List<SubWorkstreamHardwareCost> subWorkstreamHardwareCostOwnerships = createSubWorkstreamHardwareCostsOwnershipForMonthly(
                            subWorkStreamHardwareCosts,monthlyFinancialResource.getSubWorkStreamId(),
                            monthlyFinancialResource.getSubWorkStreamName(),monthlyFinancialResource.getScenario(),monthlyHardware.getSurrId());
                    subWorkstreamHardwareCostRepo.saveAll(subWorkstreamHardwareCostOwnerships);
                }
            }
        });
    }

    private List<SubWorkstreamHardwareCost> getHardwareCostEntity(SubWorkstreamHardwareCost subWorkstreamHardwareCost,MonthlyFinancialResource monthlyFinancialResource, MonthlyCostTypeData monthlyHardware, String year) {

        List<SubWorkstreamHardwareCost> subWorkstreamHardwareCosts = monthlyHardware.getMonthlyData().stream().map(monthlyData -> {
            if (monthlyData.getSurrId() == null || monthlyData.getSurrId().intValue() == 0) {
                SubWorkstreamHardwareCost newSubWorkStreamHardwareCost = getNewHardwareMonthlyData(subWorkstreamHardwareCost,
                        monthlyFinancialResource.getScenario()
                        , PortfolioConstants.ORIGINAL_INDICATOR_FALSE, monthlyData.getMonthNumber(), year);
                updateCurrencyValuesForHardware(newSubWorkStreamHardwareCost, monthlyFinancialResource.getCurrencyCode(),
                        subWorkstreamHardwareCost.getItcRate(), monthlyData.getUnit(), monthlyFinancialResource.getCurrencyCodes());
                return newSubWorkStreamHardwareCost;
            } else {
                SubWorkstreamHardwareCost existingSubWorkStreamHardwareCost = subWorkstreamHardwareCostRepo.findById(monthlyData.getSurrId()).get();
                updateCurrencyValuesForHardware(existingSubWorkStreamHardwareCost, monthlyFinancialResource.getCurrencyCode(),
                        subWorkstreamHardwareCost.getItcRate(), monthlyData.getUnit(), monthlyFinancialResource.getCurrencyCodes());
                return existingSubWorkStreamHardwareCost;
            }
        }).collect(Collectors.toList());
        return subWorkstreamHardwareCosts;
    }

    private SubWorkstreamHardwareCost getNewHardwareMonthlyData(SubWorkstreamHardwareCost subWorkstreamHardwareCost, String scenario,
                                                                String orgInd, String month, String year) {
        SubWorkstreamHardwareCost newSubWorkStreamHardwareCost = new SubWorkstreamHardwareCost();
        newSubWorkStreamHardwareCost.setWorkStreamId(subWorkstreamHardwareCost.getWorkStreamId());
        newSubWorkStreamHardwareCost.setSubWorkStreamId(subWorkstreamHardwareCost.getSubWorkStreamId());
        newSubWorkStreamHardwareCost.setSubWorkStreamName(subWorkstreamHardwareCost.getSubWorkStreamName());
        newSubWorkStreamHardwareCost.setGlCategory(subWorkstreamHardwareCost.getGlCategory());
        newSubWorkStreamHardwareCost.setCostSettings(subWorkstreamHardwareCost.getCostSettings());
        newSubWorkStreamHardwareCost.setDriverDetail(subWorkstreamHardwareCost.getDriverDetail());
        newSubWorkStreamHardwareCost.setTower(subWorkstreamHardwareCost.getTower());
        newSubWorkStreamHardwareCost.setUom(subWorkstreamHardwareCost.getUom());
        newSubWorkStreamHardwareCost.setAddHardware(subWorkstreamHardwareCost.getAddHardware());
        newSubWorkStreamHardwareCost.setActiveInd(subWorkstreamHardwareCost.getActiveInd());
        newSubWorkStreamHardwareCost.setScenario(scenario);
        newSubWorkStreamHardwareCost.setItcRate(subWorkstreamHardwareCost.getItcRate());
        newSubWorkStreamHardwareCost.setHardwareDesc(subWorkstreamHardwareCost.getHardwareDesc());
        newSubWorkStreamHardwareCost.setOriginalInd(orgInd);
        newSubWorkStreamHardwareCost.setRefSwsHwSurrId(subWorkstreamHardwareCost.getSwsHwSurrId());
        newSubWorkStreamHardwareCost.setPeriod(year + month);
        return newSubWorkStreamHardwareCost;
    }

    public void updateCurrencyValuesForHardware(SubWorkstreamHardwareCost subWorkstreamHardwareCost,
                                                String currencyCode,
                                                BigDecimal itcRate, BigDecimal quantity, HashSet<String> currencyCodes) {
        if (PortfolioConstants.DEFAULT_GROUP_CURRENCY_CODE_SGD.equalsIgnoreCase(currencyCode))
            updateCurrencyValuesForGroupForHardware(subWorkstreamHardwareCost, currencyCode, itcRate, quantity, currencyCodes);
        else
            updateCurrencyValuesForLocalForHardware(subWorkstreamHardwareCost, currencyCode, itcRate, quantity, currencyCodes);
    }

    private SubWorkstreamHardwareCost
    updateCurrencyValuesForLocalForHardware(SubWorkstreamHardwareCost subWorkstreamHardwareCost,
                                            String currencyCode,
                                            BigDecimal itcRate, BigDecimal quantity,
                                            HashSet<String> currencyCodes) {
        subWorkstreamHardwareCost.setQuantity(quantity);
        subWorkstreamHardwareCost.setCostPerMonthLcy(quantity.multiply(itcRate));
        subWorkstreamHardwareCost.setLocalCcy(currencyCode);
        currencyCodes.remove(currencyCode);
        if (!currencyCodes.isEmpty()) {
            subWorkstreamHardwareCost.setGroupCcy(currencyCodes.iterator().next());
            subWorkstreamHardwareCost.setCostPerMonthGcy(quantity.multiply(itcRate.multiply(financialDetailsService.getExchangeValue
                    (subWorkstreamHardwareCost.getPeriod(), currencyCode, subWorkstreamHardwareCost.getWorkStreamId()))));
        } else {
            subWorkstreamHardwareCost.setGroupCcy(currencyCode);
            subWorkstreamHardwareCost.setCostPerMonthGcy(quantity.multiply(itcRate));
        }

        return subWorkstreamHardwareCost;
    }

    private SubWorkstreamHardwareCost
    updateCurrencyValuesForGroupForHardware(SubWorkstreamHardwareCost subWorkstreamHardwareCost,
                                            String loggedInCurrencyCode,
                                            BigDecimal itcRate, BigDecimal quantity,
                                            HashSet<String> currencyCodes) {
        subWorkstreamHardwareCost.setQuantity(quantity);
        subWorkstreamHardwareCost.setCostPerMonthGcy(quantity.multiply(itcRate));
        subWorkstreamHardwareCost.setGroupCcy(loggedInCurrencyCode);
        currencyCodes.remove(loggedInCurrencyCode);
        if (!currencyCodes.isEmpty()) {
            subWorkstreamHardwareCost.setLocalCcy(currencyCodes.iterator().next());
            BigDecimal exchangedValue = financialDetailsService.getExchangeValue
                    (subWorkstreamHardwareCost.getPeriod(), subWorkstreamHardwareCost.getLocalCcy(), subWorkstreamHardwareCost.getWorkStreamId());
            subWorkstreamHardwareCost.setCostPerMonthLcy(quantity.multiply(itcRate.divide(exchangedValue, 9, RoundingMode.HALF_UP)));
        } else {
            subWorkstreamHardwareCost.setLocalCcy(loggedInCurrencyCode);
            subWorkstreamHardwareCost.setCostPerMonthLcy(quantity.multiply(itcRate));
        }
        return subWorkstreamHardwareCost;
    }

    public List<SubWorkstreamHardwareCost> createSubWorkstreamHardwareCostsOwnershipForMonthly(List<SubWorkstreamHardwareCost> subWorkStreamHardwareCosts,
                                                                                         String subWorkstreamId, String subWorkstreamName, String scenario, Integer refSurrId) {
        SubWorkstreamHardwareCost subWorkstreamHardwareCostOwnershipParent = subWorkstreamHardwareCostRepo.findByScenarioAndCapexOpexSurrIdAndGlCategoryAndOriginalIndAndActiveInd(
                scenario,refSurrId,PortfolioConstants.OWNERSHIP,PortfolioConstants.TRUE,PortfolioConstants.TRUE);
        Date ownerShipDate = financialService.startingOwnershipPeriod(subWorkstreamId,subWorkstreamName,scenario);
        List<SubWorkstreamHardwareCost> subWorkstreamHardwareCostsToSave = subWorkStreamHardwareCosts.stream().filter(subWorkStreamHardwareCost ->
                financialService.checkOwnershipDate(ownerShipDate,subWorkStreamHardwareCost.getPeriod()))
                .map(subWorkstreamHardwareCost -> {
                    SubWorkstreamHardwareCost subWorkstreamHardwareCostOwnership = new SubWorkstreamHardwareCost();
                    subWorkstreamHardwareCostOwnership.setWorkStreamId(subWorkstreamHardwareCost.getWorkStreamId());
                    subWorkstreamHardwareCostOwnership.setSubWorkStreamId(subWorkstreamHardwareCost.getSubWorkStreamId());
                    subWorkstreamHardwareCostOwnership.setSubWorkStreamName(subWorkstreamHardwareCost.getSubWorkStreamName());
                    subWorkstreamHardwareCostOwnership.setActiveInd(PortfolioConstants.TRUE);
                    subWorkstreamHardwareCostOwnership.setOriginalInd(PortfolioConstants.FALSE);
                    subWorkstreamHardwareCostOwnership.setPeriod(subWorkstreamHardwareCost.getPeriod());
                    subWorkstreamHardwareCostOwnership.setUom(subWorkstreamHardwareCost.getUom());
                    subWorkstreamHardwareCostOwnership.setTower(subWorkstreamHardwareCost.getTower());
                    subWorkstreamHardwareCostOwnership.setDriverDetail(subWorkstreamHardwareCost.getDriverDetail());
                    subWorkstreamHardwareCostOwnership.setHardwareDesc(subWorkstreamHardwareCost.getHardwareDesc());
                    subWorkstreamHardwareCostOwnership.setQuantity(subWorkstreamHardwareCost.getQuantity());
                    subWorkstreamHardwareCostOwnership.setItcRate(subWorkstreamHardwareCost.getItcRate());
                    subWorkstreamHardwareCostOwnership.setCostPerMonthLcy(subWorkstreamHardwareCost.getCostPerMonthLcy());
                    subWorkstreamHardwareCostOwnership.setCostPerMonthGcy(subWorkstreamHardwareCost.getCostPerMonthGcy());
                    subWorkstreamHardwareCostOwnership.setGroupCcy(subWorkstreamHardwareCost.getGroupCcy());
                    subWorkstreamHardwareCostOwnership.setLocalCcy(subWorkstreamHardwareCost.getLocalCcy());
                    subWorkstreamHardwareCostOwnership.setAddHardware(subWorkstreamHardwareCost.getAddHardware());
                    subWorkstreamHardwareCostOwnership.setCostTypeDetail(subWorkstreamHardwareCost.getCostTypeDetail());
                    subWorkstreamHardwareCostOwnership.setCostSettings(subWorkstreamHardwareCost.getCostSettings());
                    subWorkstreamHardwareCostOwnership.setScenario(subWorkstreamHardwareCost.getScenario());
                    subWorkstreamHardwareCostOwnership.setRefSwsHwSurrId(subWorkstreamHardwareCostOwnershipParent.getSwsHwSurrId());
                    subWorkstreamHardwareCostOwnership.setCapexOpexSurrId(refSurrId);
                    subWorkstreamHardwareCostOwnership.setGlCategory(PortfolioConstants.OWNERSHIP);
                    return subWorkstreamHardwareCostOwnership;
                }).collect(Collectors.toList());
        List<String> OwnerShipPeriods = subWorkstreamHardwareCostsToSave.stream().map(subWorkstreamHardwareCost -> subWorkstreamHardwareCost.getPeriod()).collect(Collectors.toList());
        deleteOwnerships(subWorkstreamId, subWorkstreamName, scenario,subWorkstreamHardwareCostOwnershipParent.getSwsHwSurrId(), OwnerShipPeriods);
        return subWorkstreamHardwareCostsToSave;
    }

    public void deleteOwnerships(String subWorkstreamId, String subWorkstreamName, String scenario, Integer refSurrId, List<String> ownerShipPeriods) {
        List<SubWorkstreamHardwareCost> subWorkstreamHardwareCosts =subWorkstreamHardwareCostRepo.findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndGlCategoryAndRefSwsHwSurrIdAndPeriodInAndActiveIndAndOriginalInd(
                subWorkstreamId,subWorkstreamName,scenario,PortfolioConstants.OWNERSHIP,refSurrId,ownerShipPeriods,PortfolioConstants.TRUE,PortfolioConstants.FALSE);
        subWorkstreamHardwareCostRepo.deleteAll(subWorkstreamHardwareCosts);
    }
}
