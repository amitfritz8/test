package com.dbs.genesis.portfolio.repository;

import com.dbs.genesis.portfolio.model.SubWorkstreamSoftwareCost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Repository
public interface SubWorkstreamSoftwareCostRepo extends JpaRepository<SubWorkstreamSoftwareCost, Integer> {

    List<SubWorkstreamSoftwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalInd(
            String subWorkStreamId, String subWorkStreamName, String scenario, String activeInd, String originalInd);

    List<SubWorkstreamSoftwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotIn(
            String subWorkStreamId, String subWorkStreamName, String scenario, String activeInd, String originalInd, List<String> glCategories);

    List<SubWorkstreamSoftwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndGlCategoryNotInAndPeriodContaining(
            String subWorkStreamId, String subWorkStreamName, String scenario,String activeInd,String originalInd, List<String> glCategory, String period);
    
    List<SubWorkstreamSoftwareCost> findAllByRefSwsSwSurrIdIn(List<Integer> refSurrIds);

    @Query(value = "FROM SubWorkstreamSoftwareCost e where " +
            "e.swsSwSurrId IN (?1) or e.capexOpexSurrId IN (?2)")
    List<SubWorkstreamSoftwareCost> findAllByParentOrChildIdIn(Set<Integer> swsSwSurrId, Set<Integer> capexOpexSurrId);

    List<SubWorkstreamSoftwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndActiveIndAndOriginalIndAndPeriodContaining(
            String subWorkStreamId, String subWorkStreamName, String scenario,String activeInd,String originalInd, String period);


    List<SubWorkstreamSoftwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndVendorNameAndActiveIndAndOriginalInd(
            String subWorkStreamId, String subWorkStreamName, String scenario, String vendorName,String activeInd,String orgInd);

    List<SubWorkstreamSoftwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndVendorNameAndActiveIndAndOriginalIndAndGlCategoryNotIn(
            String subWorkStreamId, String subWorkStreamName, String scenario, String vendorName,String activeInd,String orgInd,List<String> glCategories);

    @Query(value = " SELECT DISTINCT substring(e.period,1,4) FROM sub_workstream_software_cost e where e.sub_workstream_id = :subWorkStreamId " +
            " and e.sub_workstream_name = :subWorkStreamName and scenario=:scenario and period is not null and active_ind='true' and original_ind='false' ",nativeQuery = true)
    List<String> findDistinctOfPeriodsFromSoftwareCost(@Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName, @Param("scenario") String scenario);

    @Query(value = " SELECT DISTINCT substring(e.period,1,4) FROM sub_workstream_software_cost e where e.sub_workstream_id = :subWorkStreamId and e.sub_workstream_name = :subWorkStreamName and " +
            " scenario = :scenario and active_ind='true' and original_ind='false' and e.gl_category not in :glCategories and period is not null" +
            " union SELECT DISTINCT substring(e.period,1,4) FROM sub_workstream_other_cost e where e.sub_workstream_id = :subWorkStreamId and e.sub_workstream_name = :subWorkStreamName and " +
            " e.scenario = :scenario and e.type = 'software' and e.gl_category not in :glCategories and period is not null and original_ind='false' and active_ind='true' ",nativeQuery = true)
    List<String> findDistinctOfPeriodsFromSoftwareCostAndOtherSoftwareCost(@Param("subWorkStreamId") String subWorkStreamId, @Param("subWorkStreamName") String subWorkStreamName,@Param("scenario") String scenario,
                                                                           @Param("glCategories")  List<String> glCategories);

    List<SubWorkstreamSoftwareCost> findAllByWorkStreamIdAndSubWorkStreamIdInAndScenario(
            String workStreamId, List<String> subWorkStreamIds, String scenario);

    Integer deleteAllByWorkStreamIdAndSubWorkStreamIdAndScenarioIn(
            String workStreamId, String subWorkStreamId, List<String> scenarios);

    @Query(value = "select coalesce (sum(cost_per_month_gcy),0) from sub_workstream_software_cost where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name =:subWorkStreamName and scenario = :scenario and vendor_name = :vendorName  and gl_category not in :glCategories and active_ind = 'true' and original_ind='false' " ,
            nativeQuery = true)
    BigDecimal getTotalSoftwareCostByTypeAndGrpCcy(String subWorkStreamId, String subWorkStreamName, String scenario, String vendorName, List<String> glCategories);

    @Query(value = "select coalesce (sum(cost_per_month_lcy),0) from sub_workstream_software_cost where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name =:subWorkStreamName and scenario = :scenario and vendor_name = :vendorName  and gl_category not in :glCategories and active_ind = 'true' and original_ind='false' " ,
            nativeQuery = true)
    BigDecimal getTotalSoftwareCostByTypeAndLocalCcy(String subWorkStreamId, String subWorkStreamName, String scenario, String vendorName, List<String> glCategories);

    SubWorkstreamSoftwareCost findAllBySwsSwSurrId(Integer swsSwSurrId);

    @Query(value = "select coalesce (sum(cost_per_month_gcy),0) from sub_workstream_software_cost where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name =:subWorkStreamName and scenario = :scenario and gl_category = :glCategory and ref_sw_cost_surr_id = :refSurrId and active_ind = 'true' and original_ind='false' " ,
            nativeQuery = true)
    BigDecimal getTotalCapexForSoftwareByGrpCcy(String subWorkStreamId, String subWorkStreamName, String scenario, String glCategory, Integer refSurrId);

    @Query(value = "select coalesce (sum(cost_per_month_lcy),0) from sub_workstream_software_cost where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name =:subWorkStreamName and scenario = :scenario and gl_category = :glCategory and ref_sw_cost_surr_id = :refSurrId and active_ind = 'true' and original_ind='false' " ,
            nativeQuery = true)
    BigDecimal getTotalCapexForSoftwareByLocalCcy(String subWorkStreamId, String subWorkStreamName, String scenario, String glCategory, Integer refSurrId);


    @Query(value = "select * from sub_workstream_software_cost where sub_workstream_id = :subWorkStreamId " +
            " and sub_workstream_name =:subWorkStreamName and scenario = :scenario and gl_category = :glCategory and ref_sw_cost_surr_id = :refSurrId and active_ind = 'true' and original_ind='false' " ,
            nativeQuery = true)
    void findAllItDepreciationBySoftware(String subWorkStreamId, String subWorkStreamName, String scenario, String glCategory, Integer refSurrId);

    List<SubWorkstreamSoftwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndGlCategoryAndRefSwsSwSurrIdAndActiveIndAndOriginalInd(String subWorkstreamId, String subWorkstreamName, String scenario,  String glCategory,Integer refSurrId, String activeInd,String orgInd);

    SubWorkstreamSoftwareCost findByScenarioAndCapexOpexSurrIdAndGlCategoryAndOriginalIndAndActiveInd(String scenario,Integer capexOpexSurrId,String glCategory,String orgInd,String activeInd);

    @Query(value = "delete from sub_workstream_software_cost where sub_workstream_id = :subWorkstreamId " +
            " and sub_workstream_name =:subWorkstreamName and scenario = :scenario and gl_category = :glCategory and ref_sw_cost_surr_id = :refSurrId and period in :ownerShipPeriods and active_ind = 'true' and original_ind='false' " ,
            nativeQuery = true)
    void deleteAllOwnershipByPeriod(String subWorkstreamId, String subWorkstreamName, String scenario,  String glCategory,Integer refSurrId, List<String> ownerShipPeriods);

    List<SubWorkstreamSoftwareCost> findBySubWorkStreamIdAndSubWorkStreamNameAndScenarioAndGlCategoryAndRefSwsSwSurrIdAndPeriodInAndActiveIndAndOriginalInd(String subWorkstreamId, String subWorkstreamName, String scenario,  String glCategory,Integer refSurrId, List<String> periods, String activeInd,String orgInd);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update SubWorkstreamSoftwareCost swCost set swCost.scenario =:approvalScenario " +
            "where swCost.workStreamId in (:workStreamIds) and swCost.scenario=:scenario")
    Integer updateApprovalScenarioForWorkStreamsAndScenario(@Param("workStreamIds") List<String> workStreamIds,
                                                            @Param("scenario") String scenario,
                                                            @Param("approvalScenario") String approvalScenario);
}
