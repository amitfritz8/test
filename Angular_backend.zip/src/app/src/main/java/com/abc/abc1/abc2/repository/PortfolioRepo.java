package com.dbs.genesis.portfolio.repository;



import com.dbs.genesis.portfolio.model.PortfolioEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface PortfolioRepo extends JpaRepository<PortfolioEntity, String> {


    PortfolioEntity findByPortfolioId(String portFolioId);

    boolean existsByPortfolioName(String dataName);

    @Query(value = "select distinct  c.* from sub_workstream_dates a,workstream_profile b,portfolio_profile c, portfolio_managers m" +
            " where a.scenario_name = ?1 and a.workstream_id = b.workstream_id and b.portfolio_id = c.portfolio_id and m.portfolio_id = b.portfolio_id" +
            "       and ((c.primary_platform_index in (?2) and c.reporting_flag in (?3) and b.country in (?4) and m.1bank_id = ?5 and m.active_ind = 'true') or (m.1bank_id=?5 and m.active_ind='true'))",nativeQuery = true)
    List<PortfolioEntity> findAllByOneBankId(String scenario,List<String> platforms, List<String> reportingFlag, List<String> countries,String oneBankId);

    @Query(value = "select * from portfolio_profile where portfolio_id in (" +
            "  select distinct a.portfolio_id from portfolio_profile a,work_hierarchy b,sub_workstream_fin_details c where" +
            "    c.scenario = ?1 and" +
            "    c.sub_workstream_id=b.sub_workstream_id" +
            "    and b.portfolio_id =a.portfolio_id)",nativeQuery = true)
    List<PortfolioEntity> findAllByCategory(String category);


   @Query(value = "select distinct c.* from sub_workstream_dates a,workstream_profile b,portfolio_profile c \n" +
           "where a.scenario_name = ?1 and a.workstream_id = b.workstream_id and b.portfolio_id = c.portfolio_id\n" +
           "and c.primary_platform_index in (?2) and c.reporting_flag in (?3) and b.country in (?4)",nativeQuery = true)
    List<PortfolioEntity> findAllByScenarioPlatformAndCountry(String scenario,List<String> platforms, List<String> reportingFlag, List<String> countries);


    @Query(value = "select distinct platform_role from xref_platform_stakeholders where platform_index =:platformIndex ",nativeQuery = true)
    Set<String> getRolesByPlatformIndex(@Param("platformIndex") String platformIndex);


}
