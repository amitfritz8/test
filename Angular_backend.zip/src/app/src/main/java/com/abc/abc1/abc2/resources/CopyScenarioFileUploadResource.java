package com.dbs.genesis.portfolio.resources;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.springframework.web.bind.annotation.RequestParam;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class CopyScenarioFileUploadResource {

    private String workstreamOthersSurrId;
    private String portfolioId;
    private String workStreamId;
    private String documentName;
    private String documentType;
    private String description;
    private String activeInd;
    private String filePath;
    private String createdBy;
    private String dateCreated;
    private String modifiedBy;
    private String dateModified;
    private String workstreamName;

}
