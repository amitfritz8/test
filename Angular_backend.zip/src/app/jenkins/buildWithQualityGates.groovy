#!groovy
@Library('itss-shared-lib@master')
def gitInfo = {}
def groupId="com.dbs.app"
def artifactIdValue = "${APPNAME}"
buildID = "${env.BUILD_NUMBER}"

pipeline {
    agent { label 'DSLAVE2_UAT' }
    options {
        skipDefaultCheckout()
    }
    stages {
        stage('Checkout from GIT') {
            steps {
                script {
                    echo "repo : ${REPOSITORY}"
                    gitInfo = checkout scm
                    print gitInfo
                    nexus_version = sh(script: 'git rev-parse --short HEAD', returnStdout: true).trim()
                    println nexus_version
                   gitRepoUrl =  "https://bitbucket.sgp.dbs.com:8443/dcifgit/scm/gene/${REPOSITORY}.git"
                    sh 'ls -ltr'
                    sh 'pwd'
                }
            }
        }
        stage('Build & Run Tests') {
            steps {
                script {
                    echo "repo : ${REPOSITORY}"
                    sh "date"
                    sh "du -sh ${WORKSPACE}"
                    sh "mvn clean org.jacoco:jacoco-maven-plugin:prepare-agent package -Dspring.profiles.active=local -Dbuild.number=" + buildID
                    sh "cp cloudfoundry/*.yml target"
                    sh "find target/ -type f | grep -i jar\$ | xargs -i cp {} ${WORKSPACE}"
                    sh "ls"
                    sh "mv gene-portfolio-finance-0.0.1-SNAPSHOT.jar target/${artifactIdValue}-${buildID}.${gitInfo.GIT_COMMIT}.jar"
                    sh "ls target/"
                    sh "tar czvf ${artifactIdValue}.tar.gz target/${artifactIdValue}-${buildID}.${gitInfo.GIT_COMMIT}.jar cloudfoundry/*.yml"
                    sh "du -sh ${WORKSPACE}"
                    echo "******************Completed the NEXUS ARITIFACT upload***************************"
                }
            }
        }
        stage('UploadPackage to Nexus repo') {
            steps {
                nexusArtifactUploader artifacts: [[artifactId: artifactIdValue, file: "${artifactIdValue}.tar.gz", type: 'tar.gz']],
                        credentialsId: 'nexusArtifactUploader',
                        groupId: groupId,
                        nexusUrl: 'nexuscimgmt.sgp.dbs.com:8443/nexus',
                        nexusVersion: 'nexus3',
                        protocol: 'https',
                        repository: 'GENE',
                        version: "${BUILD_NUMBER}.${gitInfo.GIT_COMMIT}"
                echo "******************Completed the NEXUS ARITIFACT upload***************************"
            }
        }

        stage("NEXUS IQ Scan") {
            steps{
                script{
                    echo "repo : ${REPOSITORY}"
                    echo "Git Url :  ${gitRepoUrl}"
                    Map mp = [commitID: gitInfo.GIT_COMMIT,
                              branch: gitInfo.GIT_BRANCH,
                              repourl: "${gitRepoUrl}",
                              iqProjectName: "GENE_gene-portfolio-finance",
                              mailto: "selvakumaresra@dbs.com,vamshikrishnag@dbs.com,karunakaran@dbs.com,saikrishnan@dbs.com,vladimir@dbs.com",
                              organization: "Others",
                              appCategory: "Internal-Shared"
                    ]
                    performIQScan(mp)
                }
            }
        }

        stage("Sonar Scan") {
            steps{
                script {
                    echo "repo : ${REPOSITORY}"
                    echo "Git Url :  ${gitRepoUrl}"
                    Map mp =[commitID: gitInfo.GIT_COMMIT,
                             branch: "master",
                             repourl: "${gitRepoUrl}",
                             "sonar.projectKey": "GENE_gene-portfolio-finance",
                             "sonar.projectName": "GENE_gene-portfolio-finance",
                             "sonar.sources": "./src/main",
                             "sonar.exclusions": "**/config/*,**/model/*,**/exception/*,**/repository/*,**/utils/*,**/entities/*,**/constants/*,**/mapper/*,**/launcher/*,**/assembler/*,**/handler/*,**/client/*,**/controller/data/*,**/repository/xref/*,**/model/xref/*,**/resource/*,**/security/*",
                             "sonar.java.binaries" : "./target/classes",
                             // "sonar.branch": gitInfo.GIT_BRANCH,
                             "sonar.branch.name": "master",
                             "sonar.junit.reportPaths":"./target/surefire-reports",
                             "sonar.jacoco.reportPath":"./target/jacoco.exec",
                             qualityGateCheck: false
                    ]
                    performSonarScan(mp)
                }
            }
        }

        stage('Static analysis by fortify') {
            steps {
                script {
                    echo "repo : ${REPOSITORY}"
                    echo "Git Url :  ${gitRepoUrl}"
                    Map scmmap = [commitID: gitInfo.GIT_COMMIT,
                                  branch: gitInfo.GIT_BRANCH,
                                  repourl: "${gitRepoUrl}",
                                  fortifyProjectName: "GENE",
                                  fortifyVersionName: "gene-portfolio-finance",
                                  buildCommand:        "mvn clean package -Dmaven.test.skip=true"]
                    performFortifyScan(scmmap)
                }
            }
        }
    }


    post {
        always {
            script
                    {
                        def status = currentBuild.currentResult == 'SUCCESS' ? 'Success' : 'Fail'
                        Map jiramap = [
                                "projectKey": "GENE",
                                "ENVIRONMENT": "Build",
                                "status" : status,
                                "JIRA_KEY" : "${JIRA_KEY}",
                                'APP_VERSION':"${BUILD_NUMBER}.${gitInfo.GIT_COMMIT}",
                                'CommitID':gitInfo.GIT_COMMIT,
                                'Nexus Artifact ID':"${artifactIdValue}",
                                'Nexus Group ID':'com.dbs.app',
                                'Repo URL': "${gitRepoUrl}",
                                'addComment': "Build Status: " +status
                        ]
                        updateJiraTicket(jiramap)
                    }
            deleteDir() /* clean up our workspace */
        }
    }
}
