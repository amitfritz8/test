#!groovy

def CF = [
        ORG                 : "${PCF_ORG}",
        CF_URL                           : "${PCF_API_ENDPOINT}",
        SPACE               : "${PCF_SPACE}",
        APP_NAME            : "${APPNAME}",
        SERVICE_NAME        : "${APPNAME}",
        PCF_DOMAIN                                     : "apps.cs.sgp.dbs.com",
        groupIdUrl          : "com/dbs/app",
        CREATE_RELEASE_JIRA : "FALSE",
        BRANCH                                                               : "${GIT_BRANCH}",
        PROD_API_ENDPOINT    : "NA FOR SIT",
        RQUEST_SUMMARY                        : "NA FOR SIT",
        nexusUrl            : "https://nexuscimgmt.sgp.dbs.com:8443/nexus",
        CF_NON_PROD1 : "https://api.dev.sys.cs.sgp.dbs.com",
        CF_NON_PROD2 : "https://api.dev2.sys.cs.sgp.dbs.com",
        CF_PROD1 : "https://api.prod.sys1.cs.sgp.dbs.com",
        CF_PROD2 : "https://api.prod.sys2.cs.sgp.dbs.com"
]

def NEXUSARTIFACTS = [
        BUILD_NUMBER        : "${AppVersion}",
        GROUP_NAME          : "com/dbs/app",
        GROUP_NAME_NO_PATH  : "GENE",
        FILENAME            : "${APPNAME}",
        FILE_PREFIX         : "GENE_",
        REPOSITORY_NAME     : "GENE",
        JIRA_KEY            : "${env.JIRA_KEY}",
        NEXUS_URL           : "nexuscimgmt.sgp.dbs.com:8443/nexus"

]

pipeline {
    agent {label 'DSLAVE2'}

    options {
        skipDefaultCheckout()
    }

    stages {
        stage('Nexus') {
            steps {
                script {

                    sh "curl -k https://${NEXUSARTIFACTS.NEXUS_URL}/repository/${NEXUSARTIFACTS.REPOSITORY_NAME}/${NEXUSARTIFACTS.GROUP_NAME}/${NEXUSARTIFACTS.FILENAME}/${NEXUSARTIFACTS.BUILD_NUMBER}/${NEXUSARTIFACTS.FILENAME}-${NEXUSARTIFACTS.BUILD_NUMBER}.tar.gz -o ${NEXUSARTIFACTS.BUILD_NUMBER}.tar"
                    sh "tar xvf ${WORKSPACE}/${NEXUSARTIFACTS.BUILD_NUMBER}.tar"
                    sh "curl https://bitbucket.sgp.dbs.com:8443/dcifgit/projects/GENE/repos/gene-portfolio-finance/raw/cloudfoundry/${PCF_SPACE}.yml?at=refs%2Fheads%2F${GIT_BRANCH} -o manifest.yml -k"
                    sh "ls -ltr"
                    sh "cat manifest.yml"
                }
            }
        }
        stage('Deploy') {
            steps {
                script{
                    pcfEnv = "${PCF_SPACE}"
                    echo "Logging in to PCF..."
                    loginAndDeployToPCF(CF)
                }
            }
        }
    }
    post {
        always {
            deleteDir()
            echo "Attempted build number ${NEXUSARTIFACTS.BUILD_NUMBER} into ${CF.SPACE}"
            script {
                def status = currentBuild.currentResult == 'SUCCESS' ? 'Success' : 'Fail'
                Map jiramap = [
                        "ENVIRONMENT": "${PCF_SPACE}",
                        "status" : status,
                        "JIRA_KEY" : "${JIRA_KEY}",
                        'addComment': "${PCF_SPACE} Deployment Status: " +status

                ]
                updateJiraTicket(jiramap)
            }
        }
        success {
            echo "Succesful deployment of ${NEXUSARTIFACTS.BUILD_NUMBER} into ${CF.SPACE}"
        }
        failure {
            echo 'Failed deployment'
        }
        unstable {
            echo 'Unstable deployment'
        }
        changed {
            echo "Pipeline state has changed from $currentBuild.previousBuild"
        }
    }
}

def loginAndDeployToPCF(CF)
{

    if (pcfEnv == "prod"){
        echo 'logging in to Prod Sys1'
        sh "set +x && cf login -a ${CF.CF_PROD1} -u ${PCF_USERNAME} -p ${PCF_PASSWORD}  -o ${PCF_ORG} -s ${PCF_SPACE} --skip-ssl-validation"
        deployToCloudFoundry(CF)
        echo 'logging in to Prod Sys2'
        sh "set +x && cf login -a ${CF.CF_PROD2} -u ${PCF_USERNAME} -p ${PCF_PASSWORD} -o ${PCF_ORG} -s ${PCF_SPACE} --skip-ssl-validation"
        deployToCloudFoundry(CF)
    } else {
//        sh "set +x && cf login -a ${CF.CF_NON_PROD2} -u ${PCF_USERNAME} -p ${PCF_PASSWORD} -o ${PCF_ORG} -s ${PCF_SPACE} --skip-ssl-validation"
//        deployToCloudFoundry(CF)

        echo 'logging in to Dev Sys 1'

        sh "set +x && cf login -a ${CF.CF_NON_PROD1} -u ${PCF_USERNAME} -p ${PCF_PASSWORD} -o ${PCF_ORG} -s ${PCF_SPACE} --skip-ssl-validation"
        deployToCloudFoundry(CF)
    }

}
def deployToCloudFoundry(CF) {
    echo "Deploying To CloudFoundry ${CF.APP_NAME}..."
    sh "ls"
    echo "appName ${CF.APP_NAME}"
    def appNameNew =  "${CF.APP_NAME}" + "-new"
    def appNameOld = "${CF.APP_NAME}" + "-old"
    echo "Debug before push ${AppVersion}"
    def appNameBuildUrl = "${CF.APP_NAME}"
    def appNameBuildJarName = "${CF.APP_NAME}" + "-" + "${AppVersion}" + ".jar"
    echo "Debug before push ${appNameBuildUrl}"
    sh "ls"
    def pcfDomain = "${CF.SPACE}" + "." + "${CF.PCF_DOMAIN}"
    sh "cf push ${appNameNew} -p target/${appNameBuildJarName} --hostname ${CF.APP_NAME} --no-start -d ${pcfDomain} -u port -t 120 -s cflinuxfs3"
    sh "ls"

    sh "cf se ${appNameNew} SPRING_PROFILES_ACTIVE ${CF.SPACE}"
    try {
        sh "cf start ${appNameNew}"
    } catch (Exception e) {
        echo("================================================")
        echo("FAILED TO DEPLOY FLYWAY, STOPPING AUTO-RESTARTS.")
        echo("================================================")
        sh "cf stop ${appNameNew}"
        throw e
    }
    //integrationTest(appNameNew)
    try {
        sh "cf delete ${appNameOld} -f"
        sh "cf rename ${appName} ${appNameOld}"
    } catch (e)
    {
        echo e.message
    }

    try {
        sh "cf map-route ${appNameNew} ${CF.SPACE}.apps.cs.sgp.dbs.com --hostname=${appNameBuildUrl}"
        sh "cf map-route ${appNameNew} ${CF.SPACE}.apps.cs.sgp.dbs.com --hostname=${appName}"
        sh "cf rename ${appNameNew} ${appName}"
    } catch (e)
    {
        echo e.message
    }

    try {
        sh "cf unmap-route ${appNameOld} ${CF.SPACE}.apps.cs.sgp.dbs.com --hostname=${appName}"
    } catch (e){
        echo e.message
    }
    try{
        sh "cf stop ${appNameOld}"
    } catch (e){
        echo e.message
    }
}